# user_worker.py
# ==================================================
# NOTE:
# - Koi function remove nahi kiya
# - Sirf ADD / FIX / MERGE
# ==================================================

# job_id -> status
_JOB_STATUS = {}

# job_id -> asyncio.Queue
_JOB_QUEUES = {}

# job_id -> currently running
_JOB_RUNNING = set()

# job_id -> active bot (for sync)
_ACTIVE_BOT = {}

import os
import re
import asyncio

from telethon import TelegramClient, events
from telethon.sessions import StringSession
from telethon.errors import FloodWaitError

from config import API_ID, API_HASH, DATA_DIR, REPLACE_AT
from storage import load_map, sent_exists, mark_sent
from logger import send_log


# ================= SESSION =================

SESSION_FILE = os.path.join(DATA_DIR, "user.session")

_ACTIVE_CLIENT = None
_DM_WATCHER = None
_STARTED_DM = set()


# ================= LOG HELPERS =================

async def update_log(job_id, text, client=None):
    await send_log(text=text, client=client, job_id=job_id)


async def success_log(job_id, text):
    await send_log(
        text=f"✅ **SUCCESS**\n{text}",
        client=_ACTIVE_CLIENT,
        job_id=job_id
    )


async def fail_log(job_id, text):
    await send_log(
        text=f"❌ **FAILED**\n{text}",
        client=_ACTIVE_CLIENT,
        job_id=job_id
    )


# ================= HELPERS =================

def detect_episode(text: str):
    """
    EXTREME Universal Episode Detector
    Covers 99% anime / series naming formats
    """
    if not text:
        return None

    text = text.replace("_", " ").replace(".", " ")

    patterns = [
        # S01E07 / S1E7 / S01 E07
        r"S\d{1,2}\s*E\s*(\d{1,3})",

        # S01 - 07 / S01 – 07
        r"S\d{1,2}\s*[-–]\s*(\d{1,3})",

        # Season 1 Episode 07
        r"Season\s*\d+\s*Episode\s*(\d{1,3})",

        # Episode 07 / Episode-07 / Episode.07
        r"Episode\s*[:\-]?\s*(\d{1,3})",

        # EP07 / EP-07 / EP 07
        r"\bEP\s*[:\-]?\s*(\d{1,3})\b",

        # E07 / E-07 / E 07
        r"\bE\s*[:\-]?\s*(\d{1,3})\b",

        # - 07  (fallback, very common)
        r"[-–]\s*(\d{1,3})",

        # [07] / (07)
        r"[\[\(]\s*(\d{1,3})\s*[\]\)]"
    ]

    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            ep = match.group(1)
            return ep.zfill(2)

    return None



def detect_quality(text: str):
    if not text:
        return None

    m = re.search(r"\b(360p|480p|720p|1080p|1440p|2160p|4k)\b", text, re.I)
    if not m:
        return None

    q = m.group(1).upper()
    return "2160p" if q == "4K" else q


def build_caption(text: str):
    ep = detect_episode(text) or "?"
    q = detect_quality(text) or "?"

    return (
        f"📟 **Episode** = **{ep}**\n"
        f"🎧 **Language** = **Hindi**\n"
        f"💿 **Quality** = **{q}**\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"**🔥 {REPLACE_AT} 🔥**"
    )


def extract_bot_and_payload(msg):
    if not msg.buttons:
        return []

    results = []

    for row in msg.buttons:
        for btn in row:
            if not btn.url:
                continue

            if "t.me/" not in btn.url and "telegram.me/" not in btn.url:
                results.append(("__INVALID__", btn.url))
                continue

            path = btn.url.split("t.me/")[-1].split("telegram.me/")[-1]

            if "?start=" in path:
                bot, payload = path.split("?start=", 1)
                results.append((bot.strip("/"), payload))
            else:
                results.append((path.strip("/"), None))

    return results


def is_force_sub(msg):
    if msg.media:
        return False

    text = (msg.text or "").lower()
    return any(k in text for k in ["join", "subscribe", "request", "membership", "access"])


# ================= DM WATCHER =================

class DMWatcher:
    def __init__(self, client: TelegramClient):
        self.client = client
        self.last_ids = {}

    async def watch(self, bot, source, job_id):
        _ACTIVE_BOT[job_id] = bot

        await update_log(
            job_id,
            f"👀 **DM WATCH STARTED**\n"
            f"• Bot: @{bot}\n"
            f"• Source: `{source}`\n\n"
            f"⏳ Waiting for files…",
            self.client
        )

        idle = 0

        while True:
            try:
                msgs = await self.client.get_messages(bot, limit=15)
                found = False

                for msg in reversed(msgs):
                    last = self.last_ids.get(job_id, 0)
                    if msg.id <= last:
                        continue

                    self.last_ids[job_id] = msg.id

                    if is_force_sub(msg):
                        await fail_log(
                            job_id,
                            f"• Bot: @{bot}\n• Reason: Force-sub detected"
                        )
                        _ACTIVE_BOT.pop(job_id, None)
                        return

                    if not msg.video:
                        continue

                    found = True
                    await self.forward(msg, bot, source, job_id)

                idle = 0 if found else idle + 1

                if idle >= 10:
                    _ACTIVE_BOT.pop(job_id, None)
                    return

            except FloodWaitError as fw:
                await asyncio.sleep(fw.seconds)
            except Exception as e:
                await fail_log(job_id, f"• Bot: @{bot}\n• Error: {e}")
                _ACTIVE_BOT.pop(job_id, None)
                return

            await asyncio.sleep(3)

    async def forward(self, msg, bot, source, job_id):
        vid = msg.video
        key = f"{bot}_{vid.id}_{vid.access_hash}"

        if sent_exists(key):
            return

        mark_sent(key)

        text = msg.text or msg.file.name or ""
        caption = build_caption(text)

        ep = detect_episode(text) or "N/A"
        q = detect_quality(text) or "N/A"

        targets = load_map().get(str(source), [])

        await update_log(
            job_id,
            f"📁 **VIDEO RECEIVED**\n"
            f"• Bot: @{bot}\n"
            f"• Episode: {ep}\n"
            f"• Quality: {q}\n\n"
            f"⏳ Forwarding…",
            self.client
        )

        for tgt in set(map(int, targets)):
            await self.client.send_file(tgt, msg.media, caption=caption)


# ================= QUEUE PROCESSOR =================

async def process_job_queue(job_id: str, source: str):
    if job_id in _JOB_RUNNING:
        return

    _JOB_RUNNING.add(job_id)
    queue = _JOB_QUEUES.get(job_id)

    while not queue.empty():
        bot, payload = await queue.get()

        await update_log(
            job_id,
            f"▶️ **PROCESSING BOT**\n• @{bot}",
            _ACTIVE_CLIENT
        )

        await trigger_bot(bot, payload, source, job_id)

        while _ACTIVE_BOT.get(job_id) == bot:
            await asyncio.sleep(2)

    await success_log(job_id, "🎉 All bots processed successfully")
    _JOB_RUNNING.discard(job_id)
    _JOB_QUEUES.pop(job_id, None)


# ================= CHANNEL WATCHER =================

def setup_channel_watcher(client: TelegramClient):
    @client.on(events.NewMessage)
    async def channel_listener(event):
        if not event.is_channel:
            return

        source = str(event.chat_id)
        mappings = load_map()

        if source not in mappings:
            return

        buttons = extract_bot_and_payload(event.message)
        if not buttons:
            return

        job_id = f"{source}_{event.id}"

        await send_log(
            f"📡 **CHANNEL DETECTED**\n"
            f"• Name: {event.chat.title}\n"
            f"• ID: `{source}`\n"
            f"• Buttons: {len(buttons)}",
            client,
            job_id=job_id,
            title=event.chat.title
        )

        _JOB_QUEUES[job_id] = asyncio.Queue()

        for bot, payload in buttons:
            if bot == "__INVALID__":
                continue
            await _JOB_QUEUES[job_id].put((bot, payload))

        asyncio.create_task(process_job_queue(job_id, source))


# ================= PUBLIC API =================

async def start_dm_watch_for(bot, source, job):
    asyncio.create_task(_DM_WATCHER.watch(bot, source, job))


async def trigger_bot(bot, payload, source, job):
    await _ACTIVE_CLIENT.send_message(bot, f"/start {payload}".strip())
    await start_dm_watch_for(bot, source, job)


# ================= ENTRY =================

async def start_worker():
    global _ACTIVE_CLIENT, _DM_WATCHER

    session = open(SESSION_FILE).read().strip()
    client = TelegramClient(StringSession(session), API_ID, API_HASH)
    await client.start()

    _ACTIVE_CLIENT = client
    _DM_WATCHER = DMWatcher(client)

    setup_channel_watcher(client)

    await send_log(
        "🚀 **USERBOT STARTED**\n"
        "• Channel Watcher: ON\n"
        "• DM Watcher: ON\n"
        "• Mode: ADVANCED",
        client
    )

    await client.run_until_disconnected()


async def get_last_channel_message(channel_id):
    msgs = await _ACTIVE_CLIENT.get_messages(int(channel_id), limit=1)
    return msgs[0]
