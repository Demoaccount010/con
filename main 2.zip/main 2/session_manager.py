from telethon import TelegramClient
from telethon.sessions import StringSession
from config import API_ID, API_HASH, DATA_DIR
from logger import log
import os

SESSION_FILE = os.path.join(DATA_DIR, "user.session")

class SessionManager:
    def __init__(self):
        self.state = "WAIT_PHONE"
        self.phone = None
        self.client = None

    def has_session(self):
        return os.path.exists(SESSION_FILE)

    async def start_phone(self, phone):
        log.info(f"OTP requested for {phone}")
        self.phone = phone
        self.client = TelegramClient(StringSession(), API_ID, API_HASH)
        await self.client.connect()
        await self.client.send_code_request(phone)
        self.state = "WAIT_OTP"

    async def submit_otp(self, otp):
        await self.client.sign_in(self.phone, otp)
        session = self.client.session.save()
        with open(SESSION_FILE, "w") as f:
            f.write(session)
        await self.client.disconnect()
        self.state = "READY"
        log.info("String session generated & saved")
