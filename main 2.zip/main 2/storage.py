# storage.py

import json
import os
import time
from config import DATA_DIR

# ---------------- FILE PATHS ----------------

MAP_FILE = os.path.join(DATA_DIR, "mapping.json")
SENT_FILE = os.path.join(DATA_DIR, "sent.json")


# ---------------- INTERNAL HELPERS ----------------

def _load(path, default):
    if not os.path.exists(path):
        return default
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def _save(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


# ---------------- MAPPING ----------------

def load_map():
    """
    Load source -> target channel mapping
    """
    return _load(MAP_FILE, {})


def save_map(mapping: dict):
    """
    Save mapping to disk
    """
    _save(MAP_FILE, mapping)


# ---------------- DUPLICATE PROTECTION ----------------

def sent_exists(key: str) -> bool:
    """
    Check if a file/key was already processed
    """
    return key in _load(SENT_FILE, {})

def remove_map(source_id: str):
    data = load_map()

    if source_id not in data:
        return False

    del data[source_id]
    save_map(data)
    return True

def mark_sent(key: str):
    """
    Mark a file/key as processed with timestamp
    """
    data = _load(SENT_FILE, {})
    data[key] = int(time.time())
    _save(SENT_FILE, data)
