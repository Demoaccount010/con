# logger.py

import logging
from config import LOG_CHANNEL

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

log = logging.getLogger("AUTO-BOT")

# ================= INTERNAL STORAGE =================
# job_id -> {"msg_id": int, "text": str}
_LOG_MESSAGES = {}


# ================= CORE HELPERS =================

async def _send_new(job_id, text, client):
    msg = await client.send_message(LOG_CHANNEL, text)
    _LOG_MESSAGES[job_id] = {
        "msg_id": msg.id,
        "text": text
    }


async def _edit_existing(job_id, new_line, client):
    data = _LOG_MESSAGES.get(job_id)
    if not data:
        await _send_new(job_id, new_line, client)
        return

    # 🔥 APPEND (NOT REPLACE)
    data["text"] += f"\n{new_line}"

    await client.edit_message(
        LOG_CHANNEL,
        data["msg_id"],
        data["text"]
    )


# ================= PUBLIC LOGGER API =================

async def start_log(job_id: str, text: str, client=None, title: str = None):
    log.info(text)
    if not client:
        return

    header = "🧩 **JOB STARTED**"
    if title:
        header += f"\n📺 **Channel:** {title}"

    full_text = f"{header}\n\n{text}"

    if job_id in _LOG_MESSAGES:
        return

    try:
        await _send_new(job_id, full_text, client)
    except Exception as e:
        log.warning(f"start_log failed: {e}")


async def append_log(job_id: str, text: str, client=None):
    log.info(text)
    if not client:
        return

    try:
        await _edit_existing(job_id, text, client)
    except Exception as e:
        log.warning(f"append_log failed: {e}")


async def success_log(job_id: str, text: str, client=None):
    await append_log(job_id, f"✅ **SUCCESS**\n{text}", client)
    _LOG_MESSAGES.pop(job_id, None)


async def fail_log(job_id: str, text: str, client=None):
    await append_log(job_id, f"❌ **FAILED**\n{text}", client)
    _LOG_MESSAGES.pop(job_id, None)


# ================= BACKWARD COMPATIBLE =================

async def send_log(text: str, client=None, job_id: str = None, title: str = None):
    """
    IMPORTANT:
    - job_id MUST be passed to avoid spam
    """
    log.info(text)
    if not client:
        return

    try:
        if job_id:
            if job_id not in _LOG_MESSAGES:
                await start_log(job_id, text, client, title)
            else:
                await append_log(job_id, text, client)
        else:
            # ⚠️ fallback (new message)
            await client.send_message(LOG_CHANNEL, text)
    except Exception as e:
        log.warning(f"send_log failed: {e}")
