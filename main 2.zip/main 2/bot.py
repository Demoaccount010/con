import json, os
from pyrogram import Client, filters
from config import *
from userbot import start_userbot, stop_userbot

def load():
    if not os.path.exists(CHANNEL_FILE):
        with open(CHANNEL_FILE, "w") as f:
            json.dump({"sources": [], "targets": []}, f)
    with open(CHANNEL_FILE) as f:
        return json.load(f)

def save(data):
    with open(CHANNEL_FILE, "w") as f:
        json.dump(data, f, indent=2)

bot = Client(
    "controller_bot",
    api_id=API_ID,
    api_hash=API_HASH,
    bot_token=BOT_TOKEN
)

@bot.on_message(filters.command("addsource") & filters.user(ADMINS))
async def add_source(_, m):
    if len(m.command) < 2:
        return await m.reply("❌ Usage: /addsource -100xxxxxxxxxx")
    cid = int(m.command[1])
    data = load()
    if cid not in data["sources"]:
        data["sources"].append(cid)
        save(data)
    await m.reply("✅ Source added")

@bot.on_message(filters.command("addtarget") & filters.user(ADMINS))
async def add_target(_, m):
    if len(m.command) < 2:
        return await m.reply("❌ Usage: /addtarget -100xxxxxxxxxx")
    cid = int(m.command[1])
    data = load()
    if cid not in data["targets"]:
        data["targets"].append(cid)
        save(data)
    await m.reply("✅ Target added")

@bot.on_message(filters.command("startub") & filters.user(ADMINS))
async def start_ub(_, m):
    await start_userbot()
    await m.reply("▶️ Userbot started")

@bot.on_message(filters.command("stopub") & filters.user(ADMINS))
async def stop_ub(_, m):
    await stop_userbot()
    await m.reply("⛔ Userbot stopped")

bot.run()
