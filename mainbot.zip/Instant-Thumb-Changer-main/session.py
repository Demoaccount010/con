from pyrogram import Client
from config import API_ID, API_HASH

def generate():
    with Client("gen", api_id=API_ID, api_hash=API_HASH) as app:
        s = app.export_session_string()
        with open("user.session", "w") as f:
            f.write(s)
        print("✅ String session saved to user.session")

if __name__ == "__main__":
    generate()
