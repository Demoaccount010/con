from pyrogram import filters
from core.forwarder import forward_video
from utils.logger import log_update


def register_watcher(user, bot, DATA):
    """
    Real-time channel watcher

    ✅ Only VIDEO
    ✅ Only mapped SOURCE channels
    ✅ Ignores TARGET channels (loop safe)
    ✅ No old messages
    ✅ Silent failure (never crash)
    """

    @user.on_message(filters.channel)
    async def watcher(_, m):

        # 🔴 SYSTEM OFF
        if not DATA.get("enabled"):
            return

        # 🛑 SAFETY
        if not m or not m.chat:
            return

        src_id = m.chat.id
        src = str(src_id)

        # 🎯 BUILD TARGET SET (ANTI LOOP)
        all_targets = set()
        for tgts in DATA.get("maps", {}).values():
            for t in tgts:
                all_targets.add(str(t))

        # ❌ IGNORE TARGET CHANNELS
        if src in all_targets:
            return

        # ❌ IGNORE NON-SOURCE CHANNELS
        if src not in DATA.get("maps", {}):
            return

        # ❌ ONLY VIDEO
        if not m.video:
            await log_update(
                bot,
                src_id,
                m.chat.title or "Unknown",
                "ignored"
            )
            return

        # ✅ FORWARD VIDEO
        try:
            await forward_video(m, DATA["maps"][src])

            await log_update(
                bot,
                src_id,
                m.chat.title or "Unknown",
                "video"
            )

        except Exception as e:
            # 🧠 NEVER CRASH WATCHER
            print(f"[WATCHER ERROR] {src_id}: {e}")
