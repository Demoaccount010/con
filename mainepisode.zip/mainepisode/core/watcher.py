from pyrogram import filters
from core.forwarder import forward_video
from utils.logger import log_update
from utils.episode import extract_episode, is_episode_done, mark_episode_done
from utils.quality import extract_quality


def register_watcher(user, bot, DATA):
    """
    Real-time channel watcher
    """

    @user.on_message(filters.channel)
    async def watcher(_, m):

        # 🔴 SYSTEM OFF
        if not DATA.get("enabled"):
            return

        # 🛑 SAFETY
        if not m or not m.chat:
            return

        src_id = m.chat.id
        src = str(src_id)

        # 🎯 BUILD TARGET SET (ANTI LOOP)
        all_targets = set()
        for tgts in DATA.get("maps", {}).values():
            for t in tgts:
                all_targets.add(str(t))

        # ❌ IGNORE TARGET CHANNELS
        if src in all_targets:
            return

        # ❌ IGNORE NON-SOURCE CHANNELS
        if src not in DATA.get("maps", {}):
            return

        # ❌ STRICT VIDEO FILTER (MP4/MKV ONLY, NO GIFS)
        is_video = False
        
        # 🟢 Pyrogram Animation is usually GIF
        if m.animation:
            return

        if m.video:
            # Check mime for video
            if "video" in (m.video.mime_type or "").lower():
                is_video = True
        
        elif m.document:
            mime = (m.document.mime_type or "").lower()
            name = (m.document.file_name or "").lower()
            # Strict extension check for documents
            if name.endswith((".mp4", ".mkv")):
                is_video = True
            elif "video" in mime and not name.endswith(".gif"):
                is_video = True

        if not is_video:
            return

        # 🔍 EXTRACT INFO
        text = m.caption or m.text or ""
        ep = extract_episode(text)
        q = extract_quality(text)
        key = f"{ep}|{q}"

        # ❌ DEDUPLICATION (Async Hybrid)
        if await is_episode_done(src, key):
            return

        # ✅ FORWARD VIDEO
        try:
            print(f"🔥 [WATCHER] New message in {src_id} ({m.chat.title})")
            await forward_video(m, DATA["maps"][src])

            # ✅ MARK DONE (Async Hybrid)
            await mark_episode_done(src, key)

            await log_update(
                bot,
                src_id,
                m.chat.title or "Unknown",
                "video"
            )

        except Exception as e:
            # 🧠 NEVER CRASH WATCHER
            print(f"[WATCHER ERROR] {src_id}: {e}")
