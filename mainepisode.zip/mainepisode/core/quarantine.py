import asyncio

async def quarantine_watcher(user, DATA):
    while True:
        for src in DATA["maps"]:
            try:
                await user.send_chat_action(int(src), "typing")
            except:
                pass
        await asyncio.sleep(300)
