import asyncio

async def force_activate(user, chat_id: int):
    try:
        async for d in user.get_dialogs():
            if d.chat and d.chat.id == chat_id:
                return True

        await user.send_chat_action(chat_id, "typing")
        await asyncio.sleep(1)

        async for d in user.get_dialogs():
            if d.chat and d.chat.id == chat_id:
                return True
    except:
        pass
    return False
