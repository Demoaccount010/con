API_ID = 35163791
API_HASH = "9ca25c5054cdb8ab4aec8f7041fd7757"

BOT_TOKEN = "8466021018:AAHFknVHO_dgQh8GnDJRgGWUGPhPBCc6Nk4"

OWNER_ID = 2034253345  # only you

REPLACE_AT = "@Hindi_Animes_Series"
DEFAULT_LANGUAGE = "Hindi"

LOG_CHANNEL = -1003304342972  # private log channel

# Leave this as is, bot will fallback to JSON if auth fails
MONGO_URI = "mongodb+srv://rdx27652:nancyrawat@cluster0.d7v1xoh.mongodb.net/?appName=Cluster0"

LOG_CHANNEL = -1003304342972  # private log channel
