import asyncio
import time
import os

from pyrogram import Client, filters

from core.scanner import background_scanner
from config import *
from utils.db import load_json, save_json
from core.access import force_activate
from core.quarantine import quarantine_watcher
from core.watcher import register_watcher

# ================= BASIC =================
START_TIME = time.time()

DATA = load_json(
    "storage.json",
    {
        "enabled": True,
        "maps": {},
        "replace_at": REPLACE_AT,
        "language": DEFAULT_LANGUAGE
    }
)

# ================= CLIENTS =================
bot = Client(
    "bot",
    bot_token=BOT_TOKEN,
    api_id=API_ID,
    api_hash=API_HASH
)

user = Client(
    "user",
    session_string=open("user.session").read(),
    api_id=API_ID,
    api_hash=API_HASH
)

# ================= COMMAND HANDLER =================
@bot.on_message(filters.private & filters.user(OWNER_ID))
async def commands(_, m):
    cmd = m.text.strip().split()

    if not cmd:
        return

    # ================= START =================
    if cmd[0] == "/start":
        await m.reply(
            "🔥 **Modular Auto Forwarder**\n\n"
            "/add source target1 target2\n"
            "/remove source\n"
            "/list\n"
            "/on\n"
            "/off\n"
            "/status\n"
            "/restart"
        )

    # ================= ADD =================
    elif cmd[0] == "/add":
        if len(cmd) < 3:
            return await m.reply("❌ Usage:\n/add source target1 target2")

        try:
            src = int(cmd[1])
            tgts = [int(x) for x in cmd[2:]]
        except:
            return await m.reply("❌ Channel IDs numeric hone chahiye")

        # force activate dialogs
        await force_activate(user, src)
        for t in tgts:
            await force_activate(user, t)

        DATA["maps"][str(src)] = [str(x) for x in tgts]
        save_json("storage.json", DATA)

        await m.reply(
            f"✅ **Source Added**\n"
            f"📡 `{src}`\n"
            f"🎯 Targets: {len(tgts)}"
        )

    # ================= REMOVE =================
    elif cmd[0] == "/remove":
        if len(cmd) != 2:
            return await m.reply("❌ Usage:\n/remove source")

        removed = DATA["maps"].pop(cmd[1], None)
        save_json("storage.json", DATA)

        if removed:
            await m.reply("❌ Source removed")
        else:
            await m.reply("⚠️ Source not found")

    # ================= LIST =================
    elif cmd[0] == "/list":
        if not DATA["maps"]:
            return await m.reply("❌ No mappings found")

        text = "📋 **Channel Mapping**\n\n"
        for src, tgts in DATA["maps"].items():
            text += f"📡 `{src}`\n"
            for t in tgts:
                text += f" └➤ 🎯 `{t}`\n"
            text += "━━━━━━━━━━━━━━━━━━\n"

        await m.reply(text)

    # ================= ON =================
    elif cmd[0] == "/on":
        DATA["enabled"] = True
        save_json("storage.json", DATA)
        await m.reply("🟢 **Userbot ENABLED**")

    # ================= OFF =================
    elif cmd[0] == "/off":
        DATA["enabled"] = False
        save_json("storage.json", DATA)
        await m.reply("🔴 **Userbot DISABLED**")

    # ================= STATUS =================
    elif cmd[0] == "/status":
        up = int(time.time() - START_TIME)
        await m.reply(
            f"📊 **Status**\n\n"
            f"State: {'ON' if DATA['enabled'] else 'OFF'}\n"
            f"Sources: {len(DATA['maps'])}\n"
            f"Uptime: {up//3600}h {(up%3600)//60}m"
        )

    # ================= RESTART =================
    elif cmd[0] == "/restart":
        await m.reply("♻️ Restarting system...")
        save_json("storage.json", DATA)
        await asyncio.sleep(1)
        os._exit(1)

    # ================= UNKNOWN =================
    else:
        await m.reply("❓ Unknown command. Use /start")

# ================= START SYSTEM =================
async def start():
    await bot.start()
    await user.start()

    register_watcher(user, bot, DATA)
    asyncio.create_task(background_scanner(user, bot, DATA))

    print("🔥 MODULAR AUTO FORWARDER RUNNING")

asyncio.get_event_loop().run_until_complete(start())
asyncio.get_event_loop().run_forever()

