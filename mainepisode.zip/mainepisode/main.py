import re
import asyncio
import time
import os

from pyrogram import Client, filters

from core.scanner import background_scanner
from config import *
from utils.db import init_db, get_settings, save_settings
from core.access import force_activate
from core.quarantine import quarantine_watcher
from core.watcher import register_watcher

# ================= BASIC =================
START_TIME = time.time()
DATA = {} # Will be loaded in start()

# ================= CLIENTS =================
bot = Client(
    "bot",
    bot_token=BOT_TOKEN,
    api_id=API_ID,
    api_hash=API_HASH
)

user = Client(
    "user",
    session_string=open("user.session").read(),
    api_id=API_ID,
    api_hash=API_HASH
)

# ================= COMMAND HANDLER =================
@bot.on_message(filters.private & filters.user(OWNER_ID))
async def commands(_, m):
    cmd = m.text.strip().split() if m.text else []

    if not cmd:
        return

    # ================= START =================
    if cmd[0] == "/start":
        await m.reply(
            "🔥 **Modular Auto Forwarder**\n\n"
            "/add source target1 target2\n"
            "/mass (reply/text) - Batch add\n"
            "/remove source\n"
            "/list\n"
            "/on\n"
            "/off\n"
            "/status\n"
            "/restart"
        )

    # ================= ADD =================
    elif cmd[0] == "/add":
        if len(cmd) < 3:
            return await m.reply("❌ Usage:\n/add source target1 target2")

        try:
            src = int(cmd[1])
            tgts = [int(x) for x in cmd[2:]]
        except:
            return await m.reply("❌ Channel IDs numeric hone chahiye")

        # force activate dialogs
        await force_activate(user, src)
        for t in tgts:
            await force_activate(user, t)

        DATA["maps"][str(src)] = [str(x) for x in tgts]
        await save_settings(DATA)

        await m.reply(
            f"✅ **Source Added**\n"
            f"📡 `{src}`\n"
            f"🎯 Targets: {len(tgts)}"
        )

    # ================= MASS =================
    elif cmd[0] == "/mass":
        text = ""
        if m.reply_to_message and m.reply_to_message.text:
            text = m.reply_to_message.text
        elif len(cmd) > 1:
            text = m.text.split(None, 1)[1]
        else:
            return await m.reply("💡 **Batch Format Bhejo**\nReply to layout or send with command.")

        # Regex to find: 📡 -100... \n 🎯 -100...
        # Using a flexible regex for channel IDs
        matches = re.findall(r'📡\s*(-?\d+)[\s\S]*?🎯\s*(-?\d+)', text)

        if not matches:
            return await m.reply("❌ Koi mappings nahi mili format check karo.")

        status = await m.reply(f"⏳ **Processing {len(matches)} mappings...**")
        added = 0
        
        for src, tgt in matches:
            try:
                # force activate
                await force_activate(user, int(src))
                await force_activate(user, int(tgt))
                
                DATA["maps"][str(src)] = [str(tgt)]
                added += 1
            except Exception as e:
                print(f"[MASS ERROR] {src}->{tgt}: {e}")

        await save_settings(DATA)
        await status.edit(f"✅ **Mass Add Success**\nTotal: `{added}` mappings added.")

    # ================= REMOVE =================
    elif cmd[0] == "/remove":
        if len(cmd) != 2:
            return await m.reply("❌ Usage:\n/remove source")

        removed = DATA["maps"].pop(cmd[1], None)
        await save_settings(DATA)

        if removed:
            await m.reply("❌ Source removed")
        else:
            await m.reply("⚠️ Source not found")

    # ================= LIST =================
    elif cmd[0] == "/list":
        if not DATA["maps"]:
            return await m.reply("❌ No mappings found")

        text = "📋 **Channel Mapping**\n\n"
        for src, tgts in DATA["maps"].items():
            text += f"📡 `{src}`\n"
            for t in tgts:
                text += f" └➤ 🎯 `{t}`\n"
            text += "━━━━━━━━━━━━━━━━━━\n"

        await m.reply(text)

    # ================= ON =================
    elif cmd[0] == "/on":
        DATA["enabled"] = True
        await save_settings(DATA)
        await m.reply("🟢 **Userbot ENABLED**")

    # ================= OFF =================
    elif cmd[0] == "/off":
        DATA["enabled"] = False
        await save_settings(DATA)
        await m.reply("🔴 **Userbot DISABLED**")

    # ================= STATUS =================
    elif cmd[0] == "/status":
        up = int(time.time() - START_TIME)
        await m.reply(
            f"📊 **Status**\n\n"
            f"State: {'ON' if DATA['enabled'] else 'OFF'}\n"
            f"Sources: {len(DATA['maps'])}\n"
            f"Uptime: {up//3600}h {(up%3600)//60}m"
        )

    # ================= RESTART =================
    elif cmd[0] == "/restart":
        await m.reply("♻️ Restarting system...")
        await save_settings(DATA)
        await asyncio.sleep(1)
        os._exit(1)

    # ================= NEW START COMMAND =================
    elif cmd[0] == "/start":
        await m.reply("👋 Hello! I am Modular Auto Forwarder (Hybrid Mode)")

    # ================= UNKNOWN =================
    else:
        await m.reply("❓ Unknown command. Use /start")

# ================= START SYSTEM =================
async def start():
    global DATA
    await init_db() # Connect to MongoDB or setup Fallback
    DATA = await get_settings() # Load from DB or JSON

    await bot.start()
    await user.start()

    register_watcher(user, bot, DATA)
    asyncio.create_task(background_scanner(user, bot, DATA))

    print(f"🔥 MODULAR AUTO FORWARDER RUNNING ({'MONGODB' if DATA.get('mongodb') else 'HYBRID'})")

async def run():
    await start()
    while True:
        await asyncio.sleep(1000)

if __name__ == "__main__":
    asyncio.get_event_loop().run_until_complete(run())

