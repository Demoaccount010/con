import os
import json
import re

# We will import USE_MONGODB and episodes_col dynamically or use simple flag
# To keep it clean, let's use the DB objects from utils.db
import utils.db as db_utils

EP_DB = "episodes.json"

# ===============================
# CHECK IF EPISODE ALREADY DONE
# ===============================
async def is_episode_done(source_id: str, episode: str) -> bool:
    if not episode or episode == "NA": return False
    source_id = str(source_id)

    if db_utils.USE_MONGODB:
        try:
            doc = await db_utils.episodes_col.find_one({"source_id": source_id})
            if doc: return episode in doc.get("episodes", [])
        except:
            pass

    # Fallback to JSON
    data = db_utils.load_json(EP_DB, {})
    return episode in data.get(source_id, [])


# ===============================
# MARK EPISODE AS DONE
# ===============================
async def mark_episode_done(source_id: str, episode: str):
    if not episode or episode == "NA": return
    source_id = str(source_id)

    if db_utils.USE_MONGODB:
        try:
            await db_utils.episodes_col.update_one(
                {"source_id": source_id},
                {"$addToSet": {"episodes": episode}},
                upsert=True
            )
            return
        except:
            pass

    # Fallback to JSON
    data = db_utils.load_json(EP_DB, {})
    eps = data.get(source_id, [])
    if episode not in eps:
        eps.append(episode)
        if len(eps) > 1000: eps = eps[-1000:]
        data[source_id] = eps
        db_utils.save_json(EP_DB, data)

def extract_episode(text: str) -> str:
    _, ep = extract_season_episode(text)
    return ep

def extract_season_episode(text: str):
    if not text: return None, "NA"
    t = text.lower()
    season = None
    m = re.search(r'season\s*[:\-]?\s*(\d{1,2})', t)
    if m: season = m.group(1)
    
    m = re.search(r'\[(\d{1,4})\]', t)
    if m: return season, m.group(1)

    patterns = [
        r's\d{1,2}\s*e(\d{1,4})',
        r'episode\s*[:\-]?\s*(\d{1,4})',
        r'\bep\s*(\d{1,4})',
        r'\be(\d{1,4})\b',
        r'(?:^|\s)-?\s*(\d{1,4})(?:\s|$)',
        r'(\d{1,4})\s*(?:v\d|\[)',
    ]
    for p in patterns:
        m = re.search(p, t, re.I)
        if m:
            ep = int(m.group(1))
            if 1 <= ep <= 5000: return season, str(ep)
    return season, "NA"
