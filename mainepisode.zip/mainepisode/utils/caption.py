import re
from config import DEFAULT_LANGUAGE, REPLACE_AT
from utils.episode import extract_episode

def extract_quality(text):
    for q in ["2160p","1080p","720p","480p"]:
        if q in text.lower():
            return q.upper()
    return "Unknown"

def build_caption(text):
    text = re.sub(r'@\w+', REPLACE_AT, text or "")
    ep = extract_episode(text)
    q = extract_quality(text)

    return (
        f"**📟 Episode = {ep}**\n"
        f"**🎧 Language = {DEFAULT_LANGUAGE}**\n"
        f"**💿 Quality = {q}**\n"
        f"**━━━━━━━━━━━━━━━━━━**\n"
        f"**🔥 {REPLACE_AT} 🔥**"
    )
