"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                          LEARNING ENGINE                                      ║
║                Core Learning System for Autonomous Agent                      ║
╚══════════════════════════════════════════════════════════════════════════════╝

The Learning Engine is the brain's ability to:
- Learn from user feedback
- Learn from successes and failures
- Recognize patterns
- Improve over time
- Never repeat mistakes
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Set, Tuple, Callable, Awaitable
from dataclasses import dataclass, field
from enum import Enum
import hashlib
import json
from collections import defaultdict

logger = logging.getLogger(__name__)


class LearningType(Enum):
    """Types of learning"""
    EXPLICIT = "explicit"           # User explicitly teaches
    IMPLICIT = "implicit"           # Learned from context
    CORRECTION = "correction"       # Learned from correction
    FEEDBACK = "feedback"           # Learned from feedback
    SUCCESS = "success"             # Learned from success
    FAILURE = "failure"             # Learned from failure
    OBSERVATION = "observation"     # Learned from observation
    RESEARCH = "research"           # Learned from research
    PATTERN = "pattern"             # Learned pattern


class LearningPriority(Enum):
    """Priority of learned information"""
    CRITICAL = 1      # Must remember (owner info, safety)
    HIGH = 2          # Should remember (preferences)
    NORMAL = 3        # Nice to remember
    LOW = 4           # Can forget if needed
    TEMPORARY = 5     # Session only


class LearningStatus(Enum):
    """Status of learning item"""
    PENDING = "pending"
    PROCESSING = "processing"
    LEARNED = "learned"
    VERIFIED = "verified"
    REJECTED = "rejected"
    SUPERSEDED = "superseded"


@dataclass
class LearningItem:
    """Something to be learned"""
    id: str
    type: LearningType
    priority: LearningPriority
    content: Dict[str, Any]
    source: str
    context: str
    
    # Status tracking
    status: LearningStatus = LearningStatus.PENDING
    created_at: datetime = field(default_factory=datetime.now)
    learned_at: Optional[datetime] = None
    
    # Verification
    verified: bool = False
    verification_count: int = 0
    confidence: float = 0.5
    
    # Metadata
    tags: List[str] = field(default_factory=list)
    related_to: Optional[str] = None
    supersedes: Optional[str] = None


@dataclass
class LearnedKnowledge:
    """Knowledge that has been learned"""
    id: str
    key: str
    value: Any
    type: LearningType
    priority: LearningPriority
    
    # Source tracking
    source: str
    context: str
    
    # Timing
    learned_at: datetime = field(default_factory=datetime.now)
    last_used: Optional[datetime] = None
    last_verified: Optional[datetime] = None
    
    # Usage tracking
    use_count: int = 0
    success_count: int = 0
    failure_count: int = 0
    
    # Confidence
    confidence: float = 0.5
    verified: bool = False
    
    # Relations
    tags: List[str] = field(default_factory=list)
    related_knowledge: List[str] = field(default_factory=list)
    
    @property
    def success_rate(self) -> float:
        total = self.success_count + self.failure_count
        return self.success_count / total if total > 0 else 0.5
    
    @property
    def is_reliable(self) -> bool:
        return self.confidence >= 0.7 and self.success_rate >= 0.7


@dataclass
class FailureRecord:
    """Record of a failure to learn from"""
    id: str
    action: str
    error: str
    context: Dict[str, Any]
    occurred_at: datetime = field(default_factory=datetime.now)
    
    # Analysis
    cause: Optional[str] = None
    prevention: Optional[str] = None
    learned: bool = False
    
    # Recurrence tracking
    occurrence_count: int = 1
    last_occurred: datetime = field(default_factory=datetime.now)


@dataclass
class SuccessRecord:
    """Record of a success to learn from"""
    id: str
    action: str
    result: str
    context: Dict[str, Any]
    occurred_at: datetime = field(default_factory=datetime.now)
    
    # Analysis
    success_factors: List[str] = field(default_factory=list)
    replicable: bool = True
    
    # Usage
    replicated_count: int = 0


@dataclass
class LearningConfig:
    """Configuration for learning engine"""
    enabled: bool = True
    
    # Learning behavior
    learn_from_success: bool = True
    learn_from_failure: bool = True
    learn_from_feedback: bool = True
    learn_from_corrections: bool = True
    
    # Confidence thresholds
    min_confidence_to_apply: float = 0.5
    high_confidence_threshold: float = 0.8
    auto_verify_threshold: float = 0.95
    
    # Failure handling
    track_failures: bool = True
    max_failures_before_alert: int = 3
    failure_cooldown_minutes: int = 30
    
    # Memory integration
    store_in_memory: bool = True
    memory_sync_interval_minutes: int = 30
    
    # Cleanup
    cleanup_old_learnings: bool = True
    max_age_days: int = 365
    
    # Generalization
    enable_generalization: bool = True
    min_examples_for_generalization: int = 3


class KnowledgeBase:
    """Storage for learned knowledge"""
    
    def __init__(self):
        self._knowledge: Dict[str, LearnedKnowledge] = {}
        self._by_type: Dict[LearningType, Set[str]] = defaultdict(set)
        self._by_tag: Dict[str, Set[str]] = defaultdict(set)
        self._by_key: Dict[str, str] = {}  # key -> id mapping
        self._lock = asyncio.Lock()
    
    async def store(self, knowledge: LearnedKnowledge) -> None:
        """Store learned knowledge"""
        async with self._lock:
            self._knowledge[knowledge.id] = knowledge
            self._by_type[knowledge.type].add(knowledge.id)
            self._by_key[knowledge.key] = knowledge.id
            
            for tag in knowledge.tags:
                self._by_tag[tag].add(knowledge.id)
    
    async def get(self, id: str) -> Optional[LearnedKnowledge]:
        """Get knowledge by ID"""
        return self._knowledge.get(id)
    
    async def get_by_key(self, key: str) -> Optional[LearnedKnowledge]:
        """Get knowledge by key"""
        id = self._by_key.get(key)
        return self._knowledge.get(id) if id else None
    
    async def get_by_type(self, type: LearningType) -> List[LearnedKnowledge]:
        """Get all knowledge of a type"""
        ids = self._by_type.get(type, set())
        return [self._knowledge[id] for id in ids if id in self._knowledge]
    
    async def get_by_tag(self, tag: str) -> List[LearnedKnowledge]:
        """Get all knowledge with a tag"""
        ids = self._by_tag.get(tag, set())
        return [self._knowledge[id] for id in ids if id in self._knowledge]
    
    async def update(self, id: str, updates: Dict[str, Any]) -> bool:
        """Update knowledge"""
        async with self._lock:
            if id not in self._knowledge:
                return False
            
            knowledge = self._knowledge[id]
            for key, value in updates.items():
                if hasattr(knowledge, key):
                    setattr(knowledge, key, value)
            
            return True
    
    async def record_use(
        self,
        id: str,
        success: bool = True
    ) -> None:
        """Record usage of knowledge"""
        async with self._lock:
            if id in self._knowledge:
                knowledge = self._knowledge[id]
                knowledge.use_count += 1
                knowledge.last_used = datetime.now()
                
                if success:
                    knowledge.success_count += 1
                else:
                    knowledge.failure_count += 1
                
                # Update confidence based on success rate
                if knowledge.use_count > 5:
                    knowledge.confidence = min(0.95, knowledge.success_rate * 1.1)
    
    async def remove(self, id: str) -> bool:
        """Remove knowledge"""
        async with self._lock:
            if id not in self._knowledge:
                return False
            
            knowledge = self._knowledge.pop(id)
            self._by_type[knowledge.type].discard(id)
            
            if knowledge.key in self._by_key:
                del self._by_key[knowledge.key]
            
            for tag in knowledge.tags:
                self._by_tag[tag].discard(id)
            
            return True
    
    async def search(
        self,
        query: str,
        limit: int = 10
    ) -> List[LearnedKnowledge]:
        """Search knowledge base"""
        results = []
        query_lower = query.lower()
        
        for knowledge in self._knowledge.values():
            score = 0
            
            # Check key
            if query_lower in knowledge.key.lower():
                score += 2
            
            # Check value
            value_str = str(knowledge.value).lower()
            if query_lower in value_str:
                score += 1
            
            # Check tags
            for tag in knowledge.tags:
                if query_lower in tag.lower():
                    score += 0.5
            
            if score > 0:
                results.append((score, knowledge))
        
        results.sort(key=lambda x: x[0], reverse=True)
        return [k for _, k in results[:limit]]
    
    async def get_stats(self) -> Dict[str, Any]:
        """Get knowledge base statistics"""
        total = len(self._knowledge)
        by_type = {t.value: len(ids) for t, ids in self._by_type.items()}
        
        verified_count = sum(1 for k in self._knowledge.values() if k.verified)
        reliable_count = sum(1 for k in self._knowledge.values() if k.is_reliable)
        
        return {
            "total": total,
            "by_type": by_type,
            "verified": verified_count,
            "reliable": reliable_count,
            "tags_count": len(self._by_tag)
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """Export knowledge base"""
        return {
            id: {
                "key": k.key,
                "value": k.value,
                "type": k.type.value,
                "confidence": k.confidence,
                "use_count": k.use_count,
                "success_rate": k.success_rate
            }
            for id, k in self._knowledge.items()
        }


class FailureTracker:
    """Track and learn from failures"""
    
    def __init__(self, max_history: int = 1000):
        self._failures: Dict[str, FailureRecord] = {}
        self._by_action: Dict[str, List[str]] = defaultdict(list)
        self._action_counts: Dict[str, int] = defaultdict(int)
        self._max_history = max_history
        self._lock = asyncio.Lock()
    
    async def record(self, failure: FailureRecord) -> None:
        """Record a failure"""
        async with self._lock:
            # Check for similar existing failure
            failure_hash = self._hash_failure(failure)
            
            if failure_hash in self._failures:
                # Update existing
                existing = self._failures[failure_hash]
                existing.occurrence_count += 1
                existing.last_occurred = datetime.now()
            else:
                # Add new
                failure.id = failure_hash
                self._failures[failure_hash] = failure
                self._by_action[failure.action].append(failure_hash)
            
            self._action_counts[failure.action] += 1
            
            # Cleanup if too many
            if len(self._failures) > self._max_history:
                await self._cleanup()
    
    def _hash_failure(self, failure: FailureRecord) -> str:
        """Create hash for failure identification"""
        key = f"{failure.action}:{failure.error}"
        return hashlib.md5(key.encode()).hexdigest()[:12]
    
    async def _cleanup(self) -> None:
        """Remove old failures"""
        if not self._failures:
            return
        
        # Remove oldest 20%
        sorted_failures = sorted(
            self._failures.items(),
            key=lambda x: x[1].last_occurred
        )
        
        to_remove = len(sorted_failures) // 5
        for id, _ in sorted_failures[:to_remove]:
            del self._failures[id]
    
    async def get_failures_for_action(self, action: str) -> List[FailureRecord]:
        """Get failures for an action"""
        ids = self._by_action.get(action, [])
        return [self._failures[id] for id in ids if id in self._failures]
    
    async def get_recurring_failures(
        self,
        min_occurrences: int = 3
    ) -> List[FailureRecord]:
        """Get recurring failures"""
        return [
            f for f in self._failures.values()
            if f.occurrence_count >= min_occurrences
        ]
    
    async def should_prevent_action(
        self,
        action: str,
        cooldown_minutes: int = 30
    ) -> Tuple[bool, Optional[str]]:
        """Check if action should be prevented due to recent failures"""
        failures = await self.get_failures_for_action(action)
        
        if not failures:
            return False, None
        
        recent_failures = [
            f for f in failures
            if (datetime.now() - f.last_occurred).total_seconds() < cooldown_minutes * 60
        ]
        
        if len(recent_failures) >= 3:
            return True, f"Action '{action}' failed {len(recent_failures)} times recently"
        
        return False, None
    
    async def mark_learned(self, failure_id: str, prevention: str) -> None:
        """Mark failure as learned with prevention"""
        if failure_id in self._failures:
            self._failures[failure_id].learned = True
            self._failures[failure_id].prevention = prevention


class SuccessTracker:
    """Track and learn from successes"""
    
    def __init__(self, max_history: int = 1000):
        self._successes: Dict[str, SuccessRecord] = {}
        self._by_action: Dict[str, List[str]] = defaultdict(list)
        self._max_history = max_history
        self._lock = asyncio.Lock()
    
    async def record(self, success: SuccessRecord) -> None:
        """Record a success"""
        async with self._lock:
            success_id = f"success_{datetime.now().timestamp()}"
            success.id = success_id
            
            self._successes[success_id] = success
            self._by_action[success.action].append(success_id)
            
            # Cleanup if needed
            if len(self._successes) > self._max_history:
                await self._cleanup()
    
    async def _cleanup(self) -> None:
        """Remove old successes"""
        sorted_successes = sorted(
            self._successes.items(),
            key=lambda x: x[1].occurred_at
        )
        
        to_remove = len(sorted_successes) // 5
        for id, _ in sorted_successes[:to_remove]:
            del self._successes[id]
    
    async def get_successes_for_action(self, action: str) -> List[SuccessRecord]:
        """Get successes for an action"""
        ids = self._by_action.get(action, [])
        return [self._successes[id] for id in ids if id in self._successes]
    
    async def get_success_pattern(
        self,
        action: str
    ) -> Optional[Dict[str, Any]]:
        """Analyze success pattern for action"""
        successes = await self.get_successes_for_action(action)
        
        if len(successes) < 3:
            return None
        
        # Analyze common factors
        all_factors = []
        for s in successes:
            all_factors.extend(s.success_factors)
        
        # Find common factors
        factor_counts = defaultdict(int)
        for factor in all_factors:
            factor_counts[factor] += 1
        
        common_factors = [
            f for f, count in factor_counts.items()
            if count >= len(successes) // 2
        ]
        
        return {
            "action": action,
            "success_count": len(successes),
            "common_factors": common_factors,
            "replicable": all(s.replicable for s in successes)
        }


class LearningEngine:
    """
    Core learning engine for the autonomous agent
    
    Features:
    - Learn from explicit teaching
    - Learn from feedback/corrections
    - Learn from successes and failures
    - Pattern recognition
    - Knowledge generalization
    - Memory integration
    """
    
    def __init__(
        self,
        config: Optional[LearningConfig] = None,
        memory_manager: Optional[Any] = None,
        brain_controller: Optional[Any] = None
    ):
        self.config = config or LearningConfig()
        self.memory_manager = memory_manager
        self.brain_controller = brain_controller
        
        # Components
        self._knowledge_base = KnowledgeBase()
        self._failure_tracker = FailureTracker()
        self._success_tracker = SuccessTracker()
        
        # Learning queue
        self._learning_queue: asyncio.Queue = asyncio.Queue()
        self._processing = False
        
        # Callbacks
        self._on_learned_callbacks: List[Callable] = []
        self._on_failure_callbacks: List[Callable] = []
        
        # Statistics
        self._stats = {
            "total_learned": 0,
            "from_explicit": 0,
            "from_feedback": 0,
            "from_success": 0,
            "from_failure": 0,
            "from_pattern": 0,
            "generalizations": 0
        }
        
        logger.info("LearningEngine initialized")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CORE LEARNING METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def learn(
        self,
        key: str,
        value: Any,
        learning_type: LearningType = LearningType.EXPLICIT,
        priority: LearningPriority = LearningPriority.NORMAL,
        source: str = "user",
        context: str = "",
        tags: Optional[List[str]] = None,
        confidence: float = 0.7
    ) -> LearnedKnowledge:
        """
        Learn something new
        
        Args:
            key: Unique key for the knowledge
            value: The knowledge value
            learning_type: How it was learned
            priority: Importance level
            source: Where it came from
            context: Why it was learned
            tags: Tags for categorization
            confidence: Initial confidence
        
        Returns:
            LearnedKnowledge object
        """
        if not self.config.enabled:
            raise RuntimeError("Learning engine is disabled")
        
        # Check if already known
        existing = await self._knowledge_base.get_by_key(key)
        
        if existing:
            # Update existing knowledge
            updates = {
                "value": value,
                "last_verified": datetime.now(),
                "confidence": min(0.95, existing.confidence + 0.1)
            }
            await self._knowledge_base.update(existing.id, updates)
            
            logger.info(f"Updated existing knowledge: {key}")
            return existing
        
        # Create new knowledge
        knowledge_id = f"learn_{hashlib.md5(key.encode()).hexdigest()[:8]}"
        
        knowledge = LearnedKnowledge(
            id=knowledge_id,
            key=key,
            value=value,
            type=learning_type,
            priority=priority,
            source=source,
            context=context,
            tags=tags or [],
            confidence=confidence
        )
        
        # Store in knowledge base
        await self._knowledge_base.store(knowledge)
        
        # Store in memory if configured
        if self.config.store_in_memory and self.memory_manager:
            await self._store_in_memory(knowledge)
        
        # Update stats
        self._stats["total_learned"] += 1
        self._stats[f"from_{learning_type.value}"] = \
            self._stats.get(f"from_{learning_type.value}", 0) + 1
        
        # Trigger callbacks
        for callback in self._on_learned_callbacks:
            try:
                await callback(knowledge)
            except Exception as e:
                logger.error(f"Learning callback error: {e}")
        
        logger.info(f"Learned: {key} = {value} (type: {learning_type.value})")
        
        return knowledge
    
    async def learn_from_teaching(
        self,
        topic: str,
        content: str,
        teacher: str = "user"
    ) -> LearnedKnowledge:
        """Learn from explicit teaching"""
        return await self.learn(
            key=f"teaching:{topic}",
            value=content,
            learning_type=LearningType.EXPLICIT,
            priority=LearningPriority.HIGH,
            source=teacher,
            context=f"Explicitly taught by {teacher}",
            tags=["teaching", topic.lower().replace(" ", "_")]
        )
    
    async def learn_from_correction(
        self,
        original_key: str,
        correct_value: Any,
        wrong_value: Any,
        explanation: str = ""
    ) -> LearnedKnowledge:
        """Learn from a correction"""
        if not self.config.learn_from_corrections:
            raise RuntimeError("Learning from corrections is disabled")
        
        # Store the correction
        knowledge = await self.learn(
            key=original_key,
            value=correct_value,
            learning_type=LearningType.CORRECTION,
            priority=LearningPriority.HIGH,
            source="correction",
            context=f"Corrected from '{wrong_value}'. {explanation}",
            tags=["correction"],
            confidence=0.9  # High confidence for corrections
        )
        
        # Also learn what NOT to do
        await self.learn_failure(
            action=f"use_value:{original_key}",
            error=f"Used incorrect value: {wrong_value}",
            context={"key": original_key, "wrong_value": wrong_value},
            cause="Incorrect initial knowledge",
            prevention=f"Use {correct_value} instead of {wrong_value}"
        )
        
        return knowledge
    
    async def learn_from_feedback(
        self,
        topic: str,
        feedback: str,
        is_positive: bool
    ) -> Optional[LearnedKnowledge]:
        """Learn from user feedback"""
        if not self.config.learn_from_feedback:
            return None
        
        if is_positive:
            return await self.learn(
                key=f"feedback:positive:{topic}",
                value=feedback,
                learning_type=LearningType.FEEDBACK,
                priority=LearningPriority.NORMAL,
                source="feedback",
                context="Positive user feedback",
                tags=["feedback", "positive"],
                confidence=0.7
            )
        else:
            # Negative feedback - learn what to avoid
            await self.learn(
                key=f"feedback:negative:{topic}",
                value=feedback,
                learning_type=LearningType.FEEDBACK,
                priority=LearningPriority.HIGH,
                source="feedback",
                context="Negative user feedback - avoid this",
                tags=["feedback", "negative", "avoid"],
                confidence=0.8
            )
            
            return None
    
    # ═══════════════════════════════════════════════════════════════════════════
    # SUCCESS/FAILURE LEARNING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def learn_success(
        self,
        action: str,
        result: str,
        context: Dict[str, Any],
        success_factors: Optional[List[str]] = None
    ) -> Optional[Dict[str, Any]]:
        """Learn from a success"""
        if not self.config.learn_from_success:
            return None
        
        record = SuccessRecord(
            id="",  # Will be set by tracker
            action=action,
            result=result,
            context=context,
            success_factors=success_factors or []
        )
        
        await self._success_tracker.record(record)
        self._stats["from_success"] += 1
        
        # Check for pattern
        pattern = await self._success_tracker.get_success_pattern(action)
        
        if pattern and pattern.get("success_count", 0) >= 3:
            # Learn the pattern
            await self.learn(
                key=f"success_pattern:{action}",
                value=pattern,
                learning_type=LearningType.PATTERN,
                priority=LearningPriority.NORMAL,
                source="success_analysis",
                context=f"Pattern from {pattern['success_count']} successes",
                tags=["pattern", "success"]
            )
            self._stats["from_pattern"] += 1
        
        return pattern
    
    async def learn_failure(
        self,
        action: str,
        error: str,
        context: Dict[str, Any],
        cause: Optional[str] = None,
        prevention: Optional[str] = None
    ) -> FailureRecord:
        """Learn from a failure"""
        if not self.config.learn_from_failure:
            raise RuntimeError("Learning from failure is disabled")
        
        record = FailureRecord(
            id="",  # Will be set by tracker
            action=action,
            error=error,
            context=context,
            cause=cause,
            prevention=prevention
        )
        
        await self._failure_tracker.record(record)
        self._stats["from_failure"] += 1
        
        # Check for recurring failure
        recurring = await self._failure_tracker.get_recurring_failures(
            min_occurrences=self.config.max_failures_before_alert
        )
        
        for failure in recurring:
            if failure.action == action and not failure.learned:
                # Trigger callback for recurring failure
                for callback in self._on_failure_callbacks:
                    try:
                        await callback(failure)
                    except Exception as e:
                        logger.error(f"Failure callback error: {e}")
        
        # Store failure knowledge
        await self.learn(
            key=f"failure:{action}:{hashlib.md5(error.encode()).hexdigest()[:6]}",
            value={
                "action": action,
                "error": error,
                "cause": cause,
                "prevention": prevention
            },
            learning_type=LearningType.FAILURE,
            priority=LearningPriority.HIGH,
            source="failure_analysis",
            context=f"Failure in action: {action}",
            tags=["failure", "avoid"],
            confidence=0.85
        )
        
        return record
    
    # ═══════════════════════════════════════════════════════════════════════════
    # KNOWLEDGE RETRIEVAL
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def recall(self, key: str) -> Optional[Any]:
        """Recall learned knowledge by key"""
        knowledge = await self._knowledge_base.get_by_key(key)
        
        if knowledge:
            # Record usage
            await self._knowledge_base.record_use(knowledge.id, success=True)
            return knowledge.value
        
        # Try memory if not in knowledge base
        if self.memory_manager:
            try:
                memories = await self.memory_manager.search_memories(
                    query=key,
                    memory_type="skill",
                    limit=1
                )
                if memories:
                    return memories[0].get("content")
            except Exception:
                pass
        
        return None
    
    async def search(
        self,
        query: str,
        limit: int = 10
    ) -> List[LearnedKnowledge]:
        """Search learned knowledge"""
        return await self._knowledge_base.search(query, limit)
    
    async def get_failures_for_action(self, action: str) -> List[FailureRecord]:
        """Get recorded failures for an action"""
        return await self._failure_tracker.get_failures_for_action(action)
    
    async def should_prevent_action(
        self,
        action: str
    ) -> Tuple[bool, Optional[str]]:
        """Check if action should be prevented due to failures"""
        return await self._failure_tracker.should_prevent_action(
            action,
            cooldown_minutes=self.config.failure_cooldown_minutes
        )
    
    async def get_success_pattern(self, action: str) -> Optional[Dict[str, Any]]:
        """Get success pattern for action"""
        return await self._success_tracker.get_success_pattern(action)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # KNOWLEDGE VERIFICATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def verify(
        self,
        key: str,
        is_correct: bool
    ) -> bool:
        """Verify if knowledge is correct"""
        knowledge = await self._knowledge_base.get_by_key(key)
        
        if not knowledge:
            return False
        
        if is_correct:
            await self._knowledge_base.update(knowledge.id, {
                "verified": True,
                "last_verified": datetime.now(),
                "verification_count": knowledge.verification_count + 1,
                "confidence": min(0.98, knowledge.confidence + 0.1)
            })
        else:
            await self._knowledge_base.update(knowledge.id, {
                "confidence": max(0.1, knowledge.confidence - 0.2)
            })
            
            # Mark for review if too many failures
            if knowledge.confidence < 0.3:
                knowledge.status = LearningStatus.REJECTED
        
        return True
    
    async def record_application(
        self,
        key: str,
        success: bool
    ) -> None:
        """Record that knowledge was applied"""
        knowledge = await self._knowledge_base.get_by_key(key)
        
        if knowledge:
            await self._knowledge_base.record_use(knowledge.id, success)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MEMORY INTEGRATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _store_in_memory(self, knowledge: LearnedKnowledge) -> None:
        """Store knowledge in memory system"""
        if not self.memory_manager:
            return
        
        try:
            memory_type = "skill" if knowledge.type == LearningType.EXPLICIT else "fact"
            
            if knowledge.priority == LearningPriority.CRITICAL:
                memory_type = "permanent"
            
            await self.memory_manager.store_memory(
                content={
                    "key": knowledge.key,
                    "value": knowledge.value,
                    "learned_at": knowledge.learned_at.isoformat(),
                    "source": knowledge.source
                },
                memory_type=memory_type,
                tags=["learned"] + knowledge.tags,
                metadata={
                    "learning_type": knowledge.type.value,
                    "confidence": knowledge.confidence
                }
            )
        except Exception as e:
            logger.error(f"Failed to store in memory: {e}")
    
    async def sync_with_memory(self) -> int:
        """Sync knowledge base with memory"""
        if not self.memory_manager:
            return 0
        
        synced = 0
        
        try:
            # Get all learned facts from memory
            memories = await self.memory_manager.search_memories(
                query="",
                memory_type="skill",
                limit=1000
            )
            
            for memory in memories:
                content = memory.get("content", {})
                if isinstance(content, dict) and "key" in content:
                    key = content["key"]
                    
                    # Check if in knowledge base
                    existing = await self._knowledge_base.get_by_key(key)
                    if not existing:
                        # Add to knowledge base
                        await self.learn(
                            key=key,
                            value=content.get("value"),
                            learning_type=LearningType.IMPLICIT,
                            source="memory_sync",
                            tags=memory.get("tags", [])
                        )
                        synced += 1
        
        except Exception as e:
            logger.error(f"Memory sync error: {e}")
        
        return synced
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CALLBACKS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def on_learned(
        self,
        callback: Callable[[LearnedKnowledge], Awaitable[None]]
    ) -> None:
        """Register callback for learning events"""
        self._on_learned_callbacks.append(callback)
    
    def on_failure(
        self,
        callback: Callable[[FailureRecord], Awaitable[None]]
    ) -> None:
        """Register callback for recurring failures"""
        self._on_failure_callbacks.append(callback)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # UTILITIES
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def get_stats(self) -> Dict[str, Any]:
        """Get learning statistics"""
        kb_stats = await self._knowledge_base.get_stats()
        
        return {
            **self._stats,
            "knowledge_base": kb_stats,
            "config": {
                "enabled": self.config.enabled,
                "learn_from_success": self.config.learn_from_success,
                "learn_from_failure": self.config.learn_from_failure
            }
        }
    
    async def export(self) -> Dict[str, Any]:
        """Export all learned knowledge"""
        return {
            "knowledge": self._knowledge_base.to_dict(),
            "stats": await self.get_stats(),
            "exported_at": datetime.now().isoformat()
        }


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

async def create_learning_engine(
    memory_manager: Optional[Any] = None,
    brain_controller: Optional[Any] = None,
    **kwargs
) -> LearningEngine:
    """Create configured learning engine"""
    config = LearningConfig(**kwargs)
    
    engine = LearningEngine(
        config=config,
        memory_manager=memory_manager,
        brain_controller=brain_controller
    )
    
    return engine