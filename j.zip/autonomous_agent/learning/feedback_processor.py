"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                        FEEDBACK PROCESSOR                                     ║
║              Process User Feedback and Corrections for Learning               ║
╚══════════════════════════════════════════════════════════════════════════════╝

The Feedback Processor handles:
- Explicit corrections ("No, it should be X")
- Implicit feedback (user modifying results)
- Ratings and satisfaction
- Error reports
- Improvement suggestions
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Tuple, Callable, Awaitable
from dataclasses import dataclass, field
from enum import Enum
import re

logger = logging.getLogger(__name__)


class FeedbackType(Enum):
    """Types of feedback"""
    CORRECTION = "correction"       # "No, it's actually X"
    POSITIVE = "positive"           # "That's right", "Good job"
    NEGATIVE = "negative"           # "That's wrong", "Not what I wanted"
    RATING = "rating"               # 1-5 star rating
    SUGGESTION = "suggestion"       # "You should also..."
    CLARIFICATION = "clarification" # "I meant X, not Y"
    PREFERENCE = "preference"       # "I prefer X over Y"
    ERROR_REPORT = "error_report"   # "There's an error in..."


class FeedbackSentiment(Enum):
    """Sentiment of feedback"""
    VERY_POSITIVE = "very_positive"
    POSITIVE = "positive"
    NEUTRAL = "neutral"
    NEGATIVE = "negative"
    VERY_NEGATIVE = "very_negative"


class CorrectionType(Enum):
    """Types of corrections"""
    VALUE = "value"           # Wrong value
    FORMAT = "format"         # Wrong format
    BEHAVIOR = "behavior"     # Wrong behavior
    PREFERENCE = "preference" # Doesn't match preference
    FACTUAL = "factual"       # Factually incorrect
    CONTEXT = "context"       # Wrong context understanding


@dataclass
class Feedback:
    """A piece of feedback from user"""
    id: str
    type: FeedbackType
    content: str
    sentiment: FeedbackSentiment
    timestamp: datetime = field(default_factory=datetime.now)
    
    # Context
    related_action: Optional[str] = None
    related_response: Optional[str] = None
    context: Dict[str, Any] = field(default_factory=dict)
    
    # Processing
    processed: bool = False
    processed_at: Optional[datetime] = None
    learning_applied: bool = False
    
    # Extraction
    correction_value: Optional[Any] = None
    original_value: Optional[Any] = None
    rating: Optional[int] = None
    suggestion: Optional[str] = None


@dataclass
class Correction:
    """A correction from user"""
    id: str
    type: CorrectionType
    
    # Values
    original_value: Any
    corrected_value: Any
    
    # Context
    key: Optional[str] = None
    action: Optional[str] = None
    explanation: str = ""
    
    # Timing
    occurred_at: datetime = field(default_factory=datetime.now)
    
    # Learning
    learned: bool = False
    confidence: float = 0.9


@dataclass
class FeedbackAnalysis:
    """Analysis of feedback"""
    feedback_id: str
    type: FeedbackType
    sentiment: FeedbackSentiment
    sentiment_score: float  # -1 to 1
    
    # Extracted information
    is_correction: bool
    correction: Optional[Correction] = None
    
    is_rating: bool = False
    rating_value: Optional[int] = None
    
    is_actionable: bool = False
    suggested_action: Optional[str] = None
    
    # Key phrases
    key_phrases: List[str] = field(default_factory=list)
    
    # Confidence
    analysis_confidence: float = 0.5


@dataclass
class ProcessorConfig:
    """Configuration for feedback processor"""
    enabled: bool = True
    
    # Sentiment detection
    detect_sentiment: bool = True
    sentiment_threshold: float = 0.6
    
    # Correction handling
    handle_corrections: bool = True
    auto_apply_corrections: bool = True
    min_correction_confidence: float = 0.7
    
    # Rating
    accept_ratings: bool = True
    rating_scale: int = 5
    
    # Learning integration
    forward_to_learning: bool = True
    store_all_feedback: bool = True
    
    # Patterns
    track_patterns: bool = True
    min_pattern_occurrences: int = 3


class SentimentAnalyzer:
    """Analyze sentiment of feedback"""
    
    # Positive indicators
    POSITIVE_WORDS = {
        'good', 'great', 'excellent', 'perfect', 'correct', 'right',
        'yes', 'thanks', 'thank', 'helpful', 'useful', 'awesome',
        'wonderful', 'amazing', 'exactly', 'precisely', 'love'
    }
    
    # Negative indicators
    NEGATIVE_WORDS = {
        'bad', 'wrong', 'incorrect', 'no', 'not', 'never', 'error',
        'mistake', 'fail', 'failed', 'useless', 'terrible', 'awful',
        'hate', 'annoying', 'frustrating', 'disappointed'
    }
    
    # Intensifiers
    INTENSIFIERS = {
        'very', 'really', 'extremely', 'absolutely', 'totally',
        'completely', 'quite', 'so'
    }
    
    # Negators
    NEGATORS = {'not', "n't", 'no', 'never', 'neither', 'nor'}
    
    def analyze(self, text: str) -> Tuple[FeedbackSentiment, float]:
        """Analyze sentiment of text"""
        text_lower = text.lower()
        words = re.findall(r'\w+', text_lower)
        
        positive_score = 0.0
        negative_score = 0.0
        
        is_negated = False
        has_intensifier = False
        
        for i, word in enumerate(words):
            # Check for negation
            if word in self.NEGATORS:
                is_negated = True
                continue
            
            # Check for intensifier
            if word in self.INTENSIFIERS:
                has_intensifier = True
                continue
            
            # Score positive words
            if word in self.POSITIVE_WORDS:
                score = 1.0
                if has_intensifier:
                    score *= 1.5
                if is_negated:
                    negative_score += score
                else:
                    positive_score += score
                is_negated = False
                has_intensifier = False
            
            # Score negative words
            elif word in self.NEGATIVE_WORDS:
                score = 1.0
                if has_intensifier:
                    score *= 1.5
                if is_negated:
                    positive_score += score
                else:
                    negative_score += score
                is_negated = False
                has_intensifier = False
        
        # Calculate overall sentiment
        total = positive_score + negative_score
        if total == 0:
            return FeedbackSentiment.NEUTRAL, 0.0
        
        sentiment_score = (positive_score - negative_score) / total
        
        # Map to sentiment enum
        if sentiment_score >= 0.5:
            sentiment = FeedbackSentiment.VERY_POSITIVE
        elif sentiment_score >= 0.2:
            sentiment = FeedbackSentiment.POSITIVE
        elif sentiment_score <= -0.5:
            sentiment = FeedbackSentiment.VERY_NEGATIVE
        elif sentiment_score <= -0.2:
            sentiment = FeedbackSentiment.NEGATIVE
        else:
            sentiment = FeedbackSentiment.NEUTRAL
        
        return sentiment, sentiment_score


class CorrectionExtractor:
    """Extract corrections from user feedback"""
    
    # Correction patterns
    CORRECTION_PATTERNS = [
        # "it's actually X"
        (r"(?:it'?s|that'?s|the answer is)\s+(?:actually\s+)?(.+)", CorrectionType.VALUE),
        # "should be X"
        (r"(?:should|must)\s+be\s+(.+)", CorrectionType.VALUE),
        # "I meant X"
        (r"I\s+meant\s+(.+)", CorrectionType.CLARIFICATION),
        # "not X, but Y"
        (r"not\s+(.+?),?\s+but\s+(.+)", CorrectionType.VALUE),
        # "X, not Y"
        (r"(.+?),?\s+not\s+(.+)", CorrectionType.VALUE),
        # "change X to Y"
        (r"change\s+(.+?)\s+to\s+(.+)", CorrectionType.VALUE),
        # "use X instead"
        (r"use\s+(.+?)\s+instead", CorrectionType.PREFERENCE),
        # "I prefer X"
        (r"I\s+prefer\s+(.+)", CorrectionType.PREFERENCE),
    ]
    
    def extract(
        self,
        text: str,
        context: Optional[Dict] = None
    ) -> Optional[Correction]:
        """Extract correction from text"""
        text = text.strip()
        
        for pattern, correction_type in self.CORRECTION_PATTERNS:
            match = re.search(pattern, text, re.IGNORECASE)
            
            if match:
                groups = match.groups()
                
                if len(groups) == 1:
                    # Single value correction
                    corrected_value = groups[0].strip()
                    original_value = context.get("original_value") if context else None
                    
                    return Correction(
                        id=f"correction_{datetime.now().timestamp()}",
                        type=correction_type,
                        original_value=original_value,
                        corrected_value=corrected_value,
                        key=context.get("key") if context else None,
                        action=context.get("action") if context else None
                    )
                
                elif len(groups) == 2:
                    # Two values (original and corrected)
                    if "not" in pattern:
                        # "X, not Y" pattern
                        corrected_value = groups[0].strip()
                        original_value = groups[1].strip()
                    else:
                        # "not X, but Y" or "change X to Y" pattern
                        original_value = groups[0].strip()
                        corrected_value = groups[1].strip()
                    
                    return Correction(
                        id=f"correction_{datetime.now().timestamp()}",
                        type=correction_type,
                        original_value=original_value,
                        corrected_value=corrected_value,
                        key=context.get("key") if context else None
                    )
        
        return None


class RatingExtractor:
    """Extract ratings from feedback"""
    
    # Rating patterns
    RATING_PATTERNS = [
        r'(\d)\s*(?:/\s*\d+)?\s*(?:stars?|points?)?',
        r'rate\s*(?:it)?\s*(\d)',
        r'(\d)\s*out\s*of\s*\d+',
    ]
    
    # Word ratings
    WORD_RATINGS = {
        'terrible': 1, 'awful': 1, 'horrible': 1,
        'bad': 2, 'poor': 2,
        'okay': 3, 'ok': 3, 'average': 3, 'fine': 3,
        'good': 4, 'nice': 4,
        'great': 5, 'excellent': 5, 'perfect': 5, 'amazing': 5
    }
    
    def extract(self, text: str, max_rating: int = 5) -> Optional[int]:
        """Extract rating from text"""
        text_lower = text.lower()
        
        # Try numeric patterns
        for pattern in self.RATING_PATTERNS:
            match = re.search(pattern, text_lower)
            if match:
                rating = int(match.group(1))
                if 1 <= rating <= max_rating:
                    return rating
        
        # Try word ratings
        words = text_lower.split()
        for word in words:
            if word in self.WORD_RATINGS:
                return self.WORD_RATINGS[word]
        
        return None


class FeedbackProcessor:
    """
    Process user feedback for learning
    
    Features:
    - Feedback type detection
    - Sentiment analysis
    - Correction extraction
    - Rating extraction
    - Learning integration
    """
    
    def __init__(
        self,
        config: Optional[ProcessorConfig] = None,
        learning_engine: Optional[Any] = None,
        memory_manager: Optional[Any] = None
    ):
        self.config = config or ProcessorConfig()
        self.learning_engine = learning_engine
        self.memory_manager = memory_manager
        
        # Components
        self._sentiment_analyzer = SentimentAnalyzer()
        self._correction_extractor = CorrectionExtractor()
        self._rating_extractor = RatingExtractor()
        
        # History
        self._feedback_history: List[Feedback] = []
        self._correction_history: List[Correction] = []
        
        # Pattern tracking
        self._feedback_patterns: Dict[str, int] = {}
        
        # Statistics
        self._stats = {
            "total_feedback": 0,
            "positive_feedback": 0,
            "negative_feedback": 0,
            "corrections_processed": 0,
            "ratings_received": 0,
            "suggestions_received": 0
        }
        
        logger.info("FeedbackProcessor initialized")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MAIN PROCESSING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def process(
        self,
        content: str,
        context: Optional[Dict] = None,
        related_action: Optional[str] = None,
        related_response: Optional[str] = None
    ) -> FeedbackAnalysis:
        """
        Process user feedback
        
        Args:
            content: The feedback content
            context: Additional context
            related_action: The action this feedback is about
            related_response: The response being commented on
        
        Returns:
            FeedbackAnalysis with extracted information
        """
        if not self.config.enabled:
            raise RuntimeError("Feedback processor is disabled")
        
        self._stats["total_feedback"] += 1
        
        # Detect feedback type
        feedback_type = self._detect_type(content)
        
        # Analyze sentiment
        sentiment, sentiment_score = FeedbackSentiment.NEUTRAL, 0.0
        if self.config.detect_sentiment:
            sentiment, sentiment_score = self._sentiment_analyzer.analyze(content)
        
        # Track sentiment stats
        if sentiment in [FeedbackSentiment.POSITIVE, FeedbackSentiment.VERY_POSITIVE]:
            self._stats["positive_feedback"] += 1
        elif sentiment in [FeedbackSentiment.NEGATIVE, FeedbackSentiment.VERY_NEGATIVE]:
            self._stats["negative_feedback"] += 1
        
        # Create feedback object
        feedback = Feedback(
            id=f"feedback_{datetime.now().timestamp()}",
            type=feedback_type,
            content=content,
            sentiment=sentiment,
            related_action=related_action,
            related_response=related_response,
            context=context or {}
        )
        
        # Create analysis
        analysis = FeedbackAnalysis(
            feedback_id=feedback.id,
            type=feedback_type,
            sentiment=sentiment,
            sentiment_score=sentiment_score,
            is_correction=False
        )
        
        # Extract correction if applicable
        if self.config.handle_corrections:
            correction = self._correction_extractor.extract(content, context)
            if correction:
                analysis.is_correction = True
                analysis.correction = correction
                feedback.correction_value = correction.corrected_value
                feedback.original_value = correction.original_value
                self._stats["corrections_processed"] += 1
        
        # Extract rating
        if self.config.accept_ratings:
            rating = self._rating_extractor.extract(content, self.config.rating_scale)
            if rating:
                analysis.is_rating = True
                analysis.rating_value = rating
                feedback.rating = rating
                self._stats["ratings_received"] += 1
        
        # Check if actionable
        analysis.is_actionable = self._is_actionable(analysis)
        if analysis.is_actionable:
            analysis.suggested_action = self._suggest_action(analysis)
        
        # Extract key phrases
        analysis.key_phrases = self._extract_key_phrases(content)
        
        # Calculate confidence
        analysis.analysis_confidence = self._calculate_confidence(analysis)
        
        # Store feedback
        feedback.processed = True
        feedback.processed_at = datetime.now()
        self._feedback_history.append(feedback)
        
        # Apply learning if configured
        if self.config.forward_to_learning:
            await self._apply_learning(feedback, analysis)
        
        # Store in memory if configured
        if self.config.store_all_feedback and self.memory_manager:
            await self._store_feedback(feedback, analysis)
        
        # Track patterns
        if self.config.track_patterns:
            self._track_pattern(feedback_type, content)
        
        return analysis
    
    async def process_correction(
        self,
        original_value: Any,
        corrected_value: Any,
        key: Optional[str] = None,
        explanation: str = ""
    ) -> Correction:
        """Process an explicit correction"""
        correction = Correction(
            id=f"correction_{datetime.now().timestamp()}",
            type=CorrectionType.VALUE,
            original_value=original_value,
            corrected_value=corrected_value,
            key=key,
            explanation=explanation
        )
        
        self._correction_history.append(correction)
        self._stats["corrections_processed"] += 1
        
        # Apply to learning engine
        if self.learning_engine:
            await self.learning_engine.learn_from_correction(
                original_key=key or "unknown",
                correct_value=corrected_value,
                wrong_value=original_value,
                explanation=explanation
            )
            correction.learned = True
        
        return correction
    
    async def process_rating(
        self,
        rating: int,
        topic: Optional[str] = None,
        context: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Process a rating"""
        self._stats["ratings_received"] += 1
        
        # Normalize rating
        normalized = rating / self.config.rating_scale
        
        # Determine sentiment
        if normalized >= 0.8:
            sentiment = FeedbackSentiment.VERY_POSITIVE
        elif normalized >= 0.6:
            sentiment = FeedbackSentiment.POSITIVE
        elif normalized >= 0.4:
            sentiment = FeedbackSentiment.NEUTRAL
        elif normalized >= 0.2:
            sentiment = FeedbackSentiment.NEGATIVE
        else:
            sentiment = FeedbackSentiment.VERY_NEGATIVE
        
        result = {
            "rating": rating,
            "normalized": normalized,
            "sentiment": sentiment.value,
            "topic": topic,
            "processed": True
        }
        
        # Store if configured
        if self.memory_manager:
            await self.memory_manager.store_memory(
                content={
                    "type": "rating",
                    "rating": rating,
                    "topic": topic,
                    "context": context
                },
                memory_type="preference",
                tags=["feedback", "rating"]
            )
        
        return result
    
    async def process_suggestion(
        self,
        suggestion: str,
        context: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Process a user suggestion"""
        self._stats["suggestions_received"] += 1
        
        result = {
            "suggestion": suggestion,
            "processed": True,
            "category": self._categorize_suggestion(suggestion)
        }
        
        # Store for future reference
        if self.memory_manager:
            await self.memory_manager.store_memory(
                content={
                    "type": "suggestion",
                    "suggestion": suggestion,
                    "category": result["category"],
                    "context": context
                },
                memory_type="preference",
                tags=["feedback", "suggestion"]
            )
        
        return result
    
    # ═══════════════════════════════════════════════════════════════════════════
    # TYPE DETECTION
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _detect_type(self, content: str) -> FeedbackType:
        """Detect feedback type from content"""
        content_lower = content.lower()
        
        # Correction indicators
        correction_words = ['wrong', 'incorrect', 'should be', 'actually', 'instead', 'meant']
        if any(word in content_lower for word in correction_words):
            return FeedbackType.CORRECTION
        
        # Rating indicators
        if re.search(r'\d\s*(?:/|out of)\s*\d', content_lower):
            return FeedbackType.RATING
        
        # Suggestion indicators
        suggestion_words = ['could you', 'would be nice', 'suggest', 'should also', 'how about']
        if any(word in content_lower for word in suggestion_words):
            return FeedbackType.SUGGESTION
        
        # Preference indicators
        preference_words = ['i prefer', 'i like', 'i want', "i'd rather"]
        if any(word in content_lower for word in preference_words):
            return FeedbackType.PREFERENCE
        
        # Error report indicators
        error_words = ['error', 'bug', 'broken', 'doesn\'t work', 'failed']
        if any(word in content_lower for word in error_words):
            return FeedbackType.ERROR_REPORT
        
        # Check sentiment for positive/negative
        sentiment, score = self._sentiment_analyzer.analyze(content)
        if sentiment in [FeedbackSentiment.POSITIVE, FeedbackSentiment.VERY_POSITIVE]:
            return FeedbackType.POSITIVE
        elif sentiment in [FeedbackSentiment.NEGATIVE, FeedbackSentiment.VERY_NEGATIVE]:
            return FeedbackType.NEGATIVE
        
        return FeedbackType.CLARIFICATION
    
    # ═══════════════════════════════════════════════════════════════════════════
    # HELPERS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _is_actionable(self, analysis: FeedbackAnalysis) -> bool:
        """Check if feedback is actionable"""
        if analysis.is_correction:
            return True
        if analysis.type == FeedbackType.SUGGESTION:
            return True
        if analysis.type == FeedbackType.ERROR_REPORT:
            return True
        if analysis.type == FeedbackType.PREFERENCE:
            return True
        return False
    
    def _suggest_action(self, analysis: FeedbackAnalysis) -> Optional[str]:
        """Suggest action based on analysis"""
        if analysis.is_correction:
            return "apply_correction"
        if analysis.type == FeedbackType.SUGGESTION:
            return "review_suggestion"
        if analysis.type == FeedbackType.ERROR_REPORT:
            return "investigate_error"
        if analysis.type == FeedbackType.PREFERENCE:
            return "update_preference"
        if analysis.type == FeedbackType.NEGATIVE:
            return "review_for_improvement"
        return None
    
    def _extract_key_phrases(self, content: str) -> List[str]:
        """Extract key phrases from feedback"""
        # Simple extraction - find quoted text and important phrases
        phrases = []
        
        # Quoted text
        quotes = re.findall(r'"([^"]+)"', content)
        phrases.extend(quotes)
        
        quotes = re.findall(r"'([^']+)'", content)
        phrases.extend(quotes)
        
        # Key phrases after important words
        key_patterns = [
            r'(?:should|must)\s+(.+?)(?:\.|$)',
            r'(?:prefer|like|want)\s+(.+?)(?:\.|$)',
            r'(?:instead of)\s+(.+?)(?:\.|$)',
        ]
        
        for pattern in key_patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            phrases.extend(matches)
        
        return phrases[:5]  # Limit to 5 phrases
    
    def _calculate_confidence(self, analysis: FeedbackAnalysis) -> float:
        """Calculate confidence in analysis"""
        confidence = 0.5
        
        # Higher confidence for clear types
        if analysis.is_correction and analysis.correction:
            confidence += 0.3
        
        if analysis.is_rating and analysis.rating_value:
            confidence += 0.2
        
        # Sentiment confidence
        if abs(analysis.sentiment_score) > 0.5:
            confidence += 0.1
        
        # Key phrases boost confidence
        confidence += len(analysis.key_phrases) * 0.05
        
        return min(0.95, confidence)
    
    def _categorize_suggestion(self, suggestion: str) -> str:
        """Categorize a suggestion"""
        suggestion_lower = suggestion.lower()
        
        if any(word in suggestion_lower for word in ['feature', 'add', 'new', 'implement']):
            return "feature_request"
        if any(word in suggestion_lower for word in ['improve', 'better', 'enhance']):
            return "improvement"
        if any(word in suggestion_lower for word in ['ui', 'interface', 'display', 'show']):
            return "ui_ux"
        if any(word in suggestion_lower for word in ['fast', 'slow', 'performance']):
            return "performance"
        
        return "general"
    
    def _track_pattern(self, feedback_type: FeedbackType, content: str) -> None:
        """Track feedback patterns"""
        # Simple pattern: feedback type + first significant word
        words = content.lower().split()[:3]
        pattern_key = f"{feedback_type.value}:{' '.join(words)}"
        
        self._feedback_patterns[pattern_key] = \
            self._feedback_patterns.get(pattern_key, 0) + 1
    
    async def _apply_learning(
        self,
        feedback: Feedback,
        analysis: FeedbackAnalysis
    ) -> None:
        """Apply feedback to learning engine"""
        if not self.learning_engine:
            return
        
        try:
            if analysis.is_correction and analysis.correction:
                # Apply correction
                await self.learning_engine.learn_from_correction(
                    original_key=analysis.correction.key or "feedback_correction",
                    correct_value=analysis.correction.corrected_value,
                    wrong_value=analysis.correction.original_value,
                    explanation=f"User correction: {feedback.content}"
                )
                feedback.learning_applied = True
            
            elif feedback.type == FeedbackType.PREFERENCE:
                # Learn preference
                await self.learning_engine.learn(
                    key=f"preference:from_feedback:{feedback.id[:8]}",
                    value=feedback.content,
                    learning_type=LearningType.FEEDBACK,
                    priority=LearningPriority.NORMAL,
                    source="user_feedback",
                    tags=["preference", "feedback"]
                )
                feedback.learning_applied = True
            
            elif analysis.sentiment in [FeedbackSentiment.NEGATIVE, FeedbackSentiment.VERY_NEGATIVE]:
                # Learn from negative feedback
                if feedback.related_action:
                    await self.learning_engine.learn_from_feedback(
                        topic=feedback.related_action,
                        feedback=feedback.content,
                        is_positive=False
                    )
                    feedback.learning_applied = True
        
        except Exception as e:
            logger.error(f"Failed to apply learning: {e}")
    
    async def _store_feedback(
        self,
        feedback: Feedback,
        analysis: FeedbackAnalysis
    ) -> None:
        """Store feedback in memory"""
        try:
            await self.memory_manager.store_memory(
                content={
                    "feedback_id": feedback.id,
                    "type": feedback.type.value,
                    "content": feedback.content,
                    "sentiment": feedback.sentiment.value,
                    "is_correction": analysis.is_correction,
                    "is_actionable": analysis.is_actionable,
                    "related_action": feedback.related_action
                },
                memory_type="episode",
                tags=["feedback", feedback.type.value],
                metadata={
                    "sentiment_score": analysis.sentiment_score,
                    "confidence": analysis.analysis_confidence
                }
            )
        except Exception as e:
            logger.error(f"Failed to store feedback: {e}")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PATTERN ANALYSIS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def get_recurring_patterns(
        self,
        min_occurrences: int = 3
    ) -> List[Dict[str, Any]]:
        """Get recurring feedback patterns"""
        patterns = []
        
        for pattern, count in self._feedback_patterns.items():
            if count >= min_occurrences:
                type_str, words = pattern.split(":", 1)
                patterns.append({
                    "pattern": pattern,
                    "type": type_str,
                    "keywords": words,
                    "occurrences": count
                })
        
        patterns.sort(key=lambda x: x["occurrences"], reverse=True)
        return patterns
    
    async def get_sentiment_trend(
        self,
        days: int = 7
    ) -> Dict[str, Any]:
        """Get sentiment trend over time"""
        cutoff = datetime.now() - timedelta(days=days)
        
        recent_feedback = [
            f for f in self._feedback_history
            if f.timestamp > cutoff
        ]
        
        if not recent_feedback:
            return {"trend": "neutral", "data": []}
        
        positive = sum(1 for f in recent_feedback 
                      if f.sentiment in [FeedbackSentiment.POSITIVE, FeedbackSentiment.VERY_POSITIVE])
        negative = sum(1 for f in recent_feedback 
                      if f.sentiment in [FeedbackSentiment.NEGATIVE, FeedbackSentiment.VERY_NEGATIVE])
        
        total = len(recent_feedback)
        
        return {
            "total": total,
            "positive": positive,
            "negative": negative,
            "neutral": total - positive - negative,
            "positive_ratio": positive / total if total > 0 else 0,
            "trend": "positive" if positive > negative else ("negative" if negative > positive else "neutral")
        }
    
    def get_stats(self) -> Dict[str, Any]:
        """Get processor statistics"""
        return {
            **self._stats,
            "feedback_history_size": len(self._feedback_history),
            "correction_history_size": len(self._correction_history),
            "patterns_tracked": len(self._feedback_patterns)
        }


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

async def create_feedback_processor(
    learning_engine: Optional[Any] = None,
    memory_manager: Optional[Any] = None,
    **kwargs
) -> FeedbackProcessor:
    """Create configured feedback processor"""
    config = ProcessorConfig(**kwargs)
    
    processor = FeedbackProcessor(
        config=config,
        learning_engine=learning_engine,
        memory_manager=memory_manager
    )
    
    return processor