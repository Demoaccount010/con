"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                          SKILL BUILDER                                        ║
║              Build and Improve Skills Through Practice                        ║
╚══════════════════════════════════════════════════════════════════════════════╝

The Skill Builder helps the agent:
- Build new skills from successful actions
- Improve existing skills through practice
- Combine skills into complex procedures
- Track skill proficiency
- Identify skill gaps
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Set, Tuple, Callable, Awaitable
from dataclasses import dataclass, field
from enum import Enum
import hashlib
from collections import defaultdict

logger = logging.getLogger(__name__)


class SkillLevel(Enum):
    """Skill proficiency levels"""
    NOVICE = 1          # Just learned
    BEGINNER = 2        # Few successful uses
    INTERMEDIATE = 3    # Regular use with good success
    ADVANCED = 4        # High success rate, many uses
    EXPERT = 5          # Mastered, can teach others


class SkillCategory(Enum):
    """Categories of skills"""
    SYSTEM = "system"           # System operations
    FILE = "file"               # File operations
    NETWORK = "network"         # Network operations
    DATA = "data"               # Data processing
    CODE = "code"               # Code-related
    COMMUNICATION = "communication"  # Communication
    REASONING = "reasoning"     # Thinking/reasoning
    MEMORY = "memory"           # Memory operations
    LEARNING = "learning"       # Learning/teaching
    CUSTOM = "custom"           # User-defined


class SkillStatus(Enum):
    """Skill status"""
    LEARNING = "learning"       # Still learning
    ACTIVE = "active"           # Ready to use
    RUSTY = "rusty"             # Not used recently
    DEPRECATED = "deprecated"   # Outdated
    FAILED = "failed"           # Too many failures


@dataclass
class SkillStep:
    """A step in a skill procedure"""
    order: int
    action: str
    description: str
    parameters: Dict[str, Any] = field(default_factory=dict)
    is_optional: bool = False
    condition: Optional[str] = None
    fallback: Optional[str] = None


@dataclass
class Skill:
    """A learned skill"""
    id: str
    name: str
    description: str
    category: SkillCategory
    
    # Procedure
    steps: List[SkillStep] = field(default_factory=list)
    prerequisites: List[str] = field(default_factory=list)
    
    # Proficiency
    level: SkillLevel = SkillLevel.NOVICE
    status: SkillStatus = SkillStatus.LEARNING
    
    # Tracking
    created_at: datetime = field(default_factory=datetime.now)
    last_used: Optional[datetime] = None
    last_improved: Optional[datetime] = None
    
    # Usage stats
    use_count: int = 0
    success_count: int = 0
    failure_count: int = 0
    
    # Learning
    examples: List[Dict[str, Any]] = field(default_factory=list)
    variations: List[str] = field(default_factory=list)
    
    # Metadata
    tags: List[str] = field(default_factory=list)
    source: str = "learned"
    confidence: float = 0.5
    
    @property
    def success_rate(self) -> float:
        total = self.success_count + self.failure_count
        return self.success_count / total if total > 0 else 0.5
    
    @property
    def is_mastered(self) -> bool:
        return self.level == SkillLevel.EXPERT
    
    @property
    def needs_practice(self) -> bool:
        if not self.last_used:
            return True
        days_since_use = (datetime.now() - self.last_used).days
        return days_since_use > 30 or self.status == SkillStatus.RUSTY
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "category": self.category.value,
            "level": self.level.value,
            "status": self.status.value,
            "success_rate": self.success_rate,
            "use_count": self.use_count,
            "steps": len(self.steps)
        }


@dataclass
class SkillExecution:
    """Record of skill execution"""
    skill_id: str
    started_at: datetime
    completed_at: Optional[datetime] = None
    
    # Result
    success: bool = False
    result: Optional[Any] = None
    error: Optional[str] = None
    
    # Context
    parameters: Dict[str, Any] = field(default_factory=dict)
    context: Dict[str, Any] = field(default_factory=dict)
    
    # Steps executed
    steps_completed: int = 0
    total_steps: int = 0
    
    @property
    def duration_seconds(self) -> float:
        if not self.completed_at:
            return 0.0
        return (self.completed_at - self.started_at).total_seconds()


@dataclass
class SkillGap:
    """Identified skill gap"""
    action: str
    description: str
    occurrences: int
    last_occurred: datetime
    suggested_skill: Optional[str] = None
    importance: float = 0.5


@dataclass
class BuilderConfig:
    """Configuration for skill builder"""
    enabled: bool = True
    
    # Skill creation
    min_successes_for_skill: int = 3
    auto_create_skills: bool = True
    
    # Proficiency thresholds
    beginner_uses: int = 5
    intermediate_uses: int = 20
    advanced_uses: int = 50
    expert_uses: int = 100
    expert_success_rate: float = 0.95
    
    # Maintenance
    rusty_days: int = 30
    deprecate_after_failures: int = 10
    
    # Memory integration
    store_in_memory: bool = True
    load_from_memory: bool = True
    
    # Improvement
    track_improvements: bool = True
    suggest_practice: bool = True


class SkillRegistry:
    """Registry of all skills"""
    
    def __init__(self):
        self._skills: Dict[str, Skill] = {}
        self._by_category: Dict[SkillCategory, Set[str]] = defaultdict(set)
        self._by_tag: Dict[str, Set[str]] = defaultdict(set)
        self._by_name: Dict[str, str] = {}  # name -> id
        self._lock = asyncio.Lock()
    
    async def register(self, skill: Skill) -> None:
        """Register a skill"""
        async with self._lock:
            self._skills[skill.id] = skill
            self._by_category[skill.category].add(skill.id)
            self._by_name[skill.name.lower()] = skill.id
            
            for tag in skill.tags:
                self._by_tag[tag].add(skill.id)
    
    async def get(self, skill_id: str) -> Optional[Skill]:
        """Get skill by ID"""
        return self._skills.get(skill_id)
    
    async def get_by_name(self, name: str) -> Optional[Skill]:
        """Get skill by name"""
        skill_id = self._by_name.get(name.lower())
        return self._skills.get(skill_id) if skill_id else None
    
    async def get_by_category(self, category: SkillCategory) -> List[Skill]:
        """Get skills by category"""
        ids = self._by_category.get(category, set())
        return [self._skills[id] for id in ids if id in self._skills]
    
    async def get_by_tag(self, tag: str) -> List[Skill]:
        """Get skills by tag"""
        ids = self._by_tag.get(tag, set())
        return [self._skills[id] for id in ids if id in self._skills]
    
    async def update(self, skill_id: str, updates: Dict[str, Any]) -> bool:
        """Update a skill"""
        async with self._lock:
            if skill_id not in self._skills:
                return False
            
            skill = self._skills[skill_id]
            for key, value in updates.items():
                if hasattr(skill, key):
                    setattr(skill, key, value)
            
            return True
    
    async def remove(self, skill_id: str) -> bool:
        """Remove a skill"""
        async with self._lock:
            if skill_id not in self._skills:
                return False
            
            skill = self._skills.pop(skill_id)
            self._by_category[skill.category].discard(skill_id)
            
            if skill.name.lower() in self._by_name:
                del self._by_name[skill.name.lower()]
            
            for tag in skill.tags:
                self._by_tag[tag].discard(skill_id)
            
            return True
    
    async def search(self, query: str, limit: int = 10) -> List[Skill]:
        """Search skills"""
        results = []
        query_lower = query.lower()
        
        for skill in self._skills.values():
            score = 0
            
            if query_lower in skill.name.lower():
                score += 2
            if query_lower in skill.description.lower():
                score += 1
            for tag in skill.tags:
                if query_lower in tag.lower():
                    score += 0.5
            
            if score > 0:
                results.append((score, skill))
        
        results.sort(key=lambda x: x[0], reverse=True)
        return [s for _, s in results[:limit]]
    
    async def get_all(self) -> List[Skill]:
        """Get all skills"""
        return list(self._skills.values())
    
    async def get_active(self) -> List[Skill]:
        """Get active skills"""
        return [s for s in self._skills.values() if s.status == SkillStatus.ACTIVE]
    
    async def get_stats(self) -> Dict[str, Any]:
        """Get registry statistics"""
        skills = list(self._skills.values())
        
        by_level = defaultdict(int)
        by_category = defaultdict(int)
        by_status = defaultdict(int)
        
        for skill in skills:
            by_level[skill.level.name] += 1
            by_category[skill.category.value] += 1
            by_status[skill.status.value] += 1
        
        return {
            "total": len(skills),
            "by_level": dict(by_level),
            "by_category": dict(by_category),
            "by_status": dict(by_status),
            "mastered": sum(1 for s in skills if s.is_mastered),
            "needs_practice": sum(1 for s in skills if s.needs_practice)
        }


class SkillBuilder:
    """
    Build and improve skills through practice
    
    Features:
    - Create skills from successful actions
    - Track skill usage and success
    - Improve skills through practice
    - Combine skills into procedures
    - Identify skill gaps
    """
    
    def __init__(
        self,
        config: Optional[BuilderConfig] = None,
        memory_manager: Optional[Any] = None,
        learning_engine: Optional[Any] = None
    ):
        self.config = config or BuilderConfig()
        self.memory_manager = memory_manager
        self.learning_engine = learning_engine
        
        # Components
        self._registry = SkillRegistry()
        
        # Tracking
        self._action_successes: Dict[str, List[Dict]] = defaultdict(list)
        self._skill_gaps: Dict[str, SkillGap] = {}
        self._execution_history: List[SkillExecution] = []
        
        # Statistics
        self._stats = {
            "skills_created": 0,
            "skills_improved": 0,
            "total_executions": 0,
            "successful_executions": 0,
            "failed_executions": 0,
            "gaps_identified": 0
        }
        
        logger.info("SkillBuilder initialized")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # SKILL CREATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def create_skill(
        self,
        name: str,
        description: str,
        category: SkillCategory,
        steps: Optional[List[Dict[str, Any]]] = None,
        tags: Optional[List[str]] = None,
        source: str = "created"
    ) -> Skill:
        """
        Create a new skill
        
        Args:
            name: Skill name
            description: What the skill does
            category: Skill category
            steps: Procedure steps
            tags: Tags for categorization
            source: How the skill was created
        
        Returns:
            Created Skill
        """
        skill_id = f"skill_{hashlib.md5(name.encode()).hexdigest()[:8]}"
        
        # Convert steps
        skill_steps = []
        if steps:
            for i, step in enumerate(steps):
                skill_steps.append(SkillStep(
                    order=i + 1,
                    action=step.get("action", ""),
                    description=step.get("description", ""),
                    parameters=step.get("parameters", {}),
                    is_optional=step.get("optional", False),
                    condition=step.get("condition"),
                    fallback=step.get("fallback")
                ))
        
        skill = Skill(
            id=skill_id,
            name=name,
            description=description,
            category=category,
            steps=skill_steps,
            tags=tags or [],
            source=source
        )
        
        await self._registry.register(skill)
        self._stats["skills_created"] += 1
        
        # Store in memory
        if self.config.store_in_memory and self.memory_manager:
            await self._store_skill(skill)
        
        logger.info(f"Created skill: {name}")
        return skill
    
    async def create_from_success(
        self,
        action: str,
        result: Any,
        context: Dict[str, Any]
    ) -> Optional[Skill]:
        """Create skill from successful action"""
        if not self.config.auto_create_skills:
            return None
        
        # Record success
        self._action_successes[action].append({
            "result": result,
            "context": context,
            "timestamp": datetime.now()
        })
        
        # Check if enough successes
        successes = self._action_successes[action]
        if len(successes) < self.config.min_successes_for_skill:
            return None
        
        # Check if skill already exists
        existing = await self._registry.get_by_name(action)
        if existing:
            # Record usage instead
            await self.record_usage(existing.id, success=True)
            return existing
        
        # Analyze successes to create skill
        skill = await self._analyze_and_create_skill(action, successes)
        
        return skill
    
    async def _analyze_and_create_skill(
        self,
        action: str,
        successes: List[Dict]
    ) -> Skill:
        """Analyze successes and create skill"""
        # Find common patterns
        common_params = {}
        all_params = [s.get("context", {}).get("parameters", {}) for s in successes]
        
        if all_params:
            # Find parameters that appear in most successes
            param_counts = defaultdict(int)
            for params in all_params:
                for key in params:
                    param_counts[key] += 1
            
            threshold = len(successes) * 0.6
            for key, count in param_counts.items():
                if count >= threshold:
                    common_params[key] = "variable"
        
        # Determine category
        category = self._categorize_action(action)
        
        # Create skill
        skill = await self.create_skill(
            name=action,
            description=f"Skill for: {action}",
            category=category,
            steps=[{
                "action": action,
                "description": f"Execute {action}",
                "parameters": common_params
            }],
            tags=["auto_created", category.value],
            source="success_analysis"
        )
        
        # Add examples
        skill.examples = successes[:5]  # Keep last 5 examples
        
        return skill
    
    def _categorize_action(self, action: str) -> SkillCategory:
        """Categorize action into skill category"""
        action_lower = action.lower()
        
        if any(word in action_lower for word in ['file', 'read', 'write', 'save', 'load']):
            return SkillCategory.FILE
        if any(word in action_lower for word in ['http', 'request', 'api', 'fetch', 'download']):
            return SkillCategory.NETWORK
        if any(word in action_lower for word in ['process', 'service', 'system', 'shell']):
            return SkillCategory.SYSTEM
        if any(word in action_lower for word in ['data', 'json', 'parse', 'transform']):
            return SkillCategory.DATA
        if any(word in action_lower for word in ['code', 'execute', 'run', 'compile']):
            return SkillCategory.CODE
        if any(word in action_lower for word in ['send', 'message', 'notify', 'communicate']):
            return SkillCategory.COMMUNICATION
        if any(word in action_lower for word in ['think', 'reason', 'analyze', 'decide']):
            return SkillCategory.REASONING
        if any(word in action_lower for word in ['memory', 'remember', 'recall', 'store']):
            return SkillCategory.MEMORY
        
        return SkillCategory.CUSTOM
    
    # ═══════════════════════════════════════════════════════════════════════════
    # SKILL USAGE
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def record_usage(
        self,
        skill_id: str,
        success: bool,
        execution_time: float = 0.0,
        context: Optional[Dict] = None
    ) -> bool:
        """Record skill usage"""
        skill = await self._registry.get(skill_id)
        if not skill:
            return False
        
        # Update stats
        skill.use_count += 1
        skill.last_used = datetime.now()
        
        if success:
            skill.success_count += 1
            self._stats["successful_executions"] += 1
        else:
            skill.failure_count += 1
            self._stats["failed_executions"] += 1
        
        self._stats["total_executions"] += 1
        
        # Update level based on usage
        await self._update_skill_level(skill)
        
        # Update status
        await self._update_skill_status(skill)
        
        # Record execution
        execution = SkillExecution(
            skill_id=skill_id,
            started_at=datetime.now() - timedelta(seconds=execution_time),
            completed_at=datetime.now(),
            success=success,
            context=context or {}
        )
        self._execution_history.append(execution)
        
        # Trim history
        if len(self._execution_history) > 1000:
            self._execution_history = self._execution_history[-1000:]
        
        return True
    
    async def _update_skill_level(self, skill: Skill) -> None:
        """Update skill level based on usage"""
        uses = skill.use_count
        rate = skill.success_rate
        
        new_level = skill.level
        
        if uses >= self.config.expert_uses and rate >= self.config.expert_success_rate:
            new_level = SkillLevel.EXPERT
        elif uses >= self.config.advanced_uses and rate >= 0.85:
            new_level = SkillLevel.ADVANCED
        elif uses >= self.config.intermediate_uses and rate >= 0.7:
            new_level = SkillLevel.INTERMEDIATE
        elif uses >= self.config.beginner_uses:
            new_level = SkillLevel.BEGINNER
        
        if new_level != skill.level:
            old_level = skill.level
            skill.level = new_level
            skill.last_improved = datetime.now()
            self._stats["skills_improved"] += 1
            
            logger.info(f"Skill '{skill.name}' improved: {old_level.name} -> {new_level.name}")
    
    async def _update_skill_status(self, skill: Skill) -> None:
        """Update skill status"""
        # Check for too many failures
        if skill.failure_count >= self.config.deprecate_after_failures:
            if skill.success_rate < 0.3:
                skill.status = SkillStatus.FAILED
                return
        
        # Check for rust
        if skill.last_used:
            days_since_use = (datetime.now() - skill.last_used).days
            if days_since_use > self.config.rusty_days:
                skill.status = SkillStatus.RUSTY
                return
        
        # Active if has been used successfully
        if skill.success_count > 0:
            skill.status = SkillStatus.ACTIVE
        else:
            skill.status = SkillStatus.LEARNING
    
    # ═══════════════════════════════════════════════════════════════════════════
    # SKILL IMPROVEMENT
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def add_step(
        self,
        skill_id: str,
        step: Dict[str, Any],
        position: Optional[int] = None
    ) -> bool:
        """Add step to skill"""
        skill = await self._registry.get(skill_id)
        if not skill:
            return False
        
        skill_step = SkillStep(
            order=position or len(skill.steps) + 1,
            action=step.get("action", ""),
            description=step.get("description", ""),
            parameters=step.get("parameters", {}),
            is_optional=step.get("optional", False)
        )
        
        if position:
            skill.steps.insert(position - 1, skill_step)
            # Reorder
            for i, s in enumerate(skill.steps):
                s.order = i + 1
        else:
            skill.steps.append(skill_step)
        
        skill.last_improved = datetime.now()
        return True
    
    async def add_variation(
        self,
        skill_id: str,
        variation: str
    ) -> bool:
        """Add variation to skill"""
        skill = await self._registry.get(skill_id)
        if not skill:
            return False
        
        if variation not in skill.variations:
            skill.variations.append(variation)
            skill.last_improved = datetime.now()
        
        return True
    
    async def add_example(
        self,
        skill_id: str,
        example: Dict[str, Any]
    ) -> bool:
        """Add example to skill"""
        skill = await self._registry.get(skill_id)
        if not skill:
            return False
        
        skill.examples.append({
            **example,
            "added_at": datetime.now().isoformat()
        })
        
        # Keep only recent examples
        if len(skill.examples) > 10:
            skill.examples = skill.examples[-10:]
        
        return True
    
    async def improve_from_feedback(
        self,
        skill_id: str,
        feedback: str,
        is_positive: bool
    ) -> bool:
        """Improve skill based on feedback"""
        skill = await self._registry.get(skill_id)
        if not skill:
            return False
        
        if is_positive:
            # Boost confidence
            skill.confidence = min(0.95, skill.confidence + 0.05)
        else:
            # Add as variation to handle
            skill.variations.append(f"Handle: {feedback}")
            skill.confidence = max(0.3, skill.confidence - 0.1)
        
        skill.last_improved = datetime.now()
        return True
    
    # ═══════════════════════════════════════════════════════════════════════════
    # SKILL COMBINATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def combine_skills(
        self,
        name: str,
        description: str,
        skill_ids: List[str],
        category: Optional[SkillCategory] = None
    ) -> Optional[Skill]:
        """Combine multiple skills into one"""
        skills = []
        for skill_id in skill_ids:
            skill = await self._registry.get(skill_id)
            if skill:
                skills.append(skill)
        
        if len(skills) < 2:
            return None
        
        # Combine steps
        combined_steps = []
        order = 1
        
        for skill in skills:
            for step in skill.steps:
                combined_steps.append({
                    "action": step.action,
                    "description": f"[{skill.name}] {step.description}",
                    "parameters": step.parameters,
                    "optional": step.is_optional
                })
        
        # Determine category
        if not category:
            # Use most common category
            categories = [s.category for s in skills]
            category = max(set(categories), key=categories.count)
        
        # Combine tags
        all_tags = set()
        for skill in skills:
            all_tags.update(skill.tags)
        all_tags.add("combined")
        
        # Create combined skill
        combined = await self.create_skill(
            name=name,
            description=description,
            category=category,
            steps=combined_steps,
            tags=list(all_tags),
            source="combined"
        )
        
        # Set prerequisites
        combined.prerequisites = skill_ids
        
        return combined
    
    # ═══════════════════════════════════════════════════════════════════════════
    # SKILL GAPS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def record_gap(
        self,
        action: str,
        description: str
    ) -> SkillGap:
        """Record a skill gap"""
        self._stats["gaps_identified"] += 1
        
        if action in self._skill_gaps:
            gap = self._skill_gaps[action]
            gap.occurrences += 1
            gap.last_occurred = datetime.now()
        else:
            gap = SkillGap(
                action=action,
                description=description,
                occurrences=1,
                last_occurred=datetime.now()
            )
            self._skill_gaps[action] = gap
        
        # Suggest skill to learn
        gap.importance = min(1.0, gap.occurrences / 10)
        
        return gap
    
    async def get_gaps(
        self,
        min_occurrences: int = 2
    ) -> List[SkillGap]:
        """Get identified skill gaps"""
        gaps = [
            g for g in self._skill_gaps.values()
            if g.occurrences >= min_occurrences
        ]
        gaps.sort(key=lambda g: g.importance, reverse=True)
        return gaps
    
    async def get_practice_suggestions(
        self,
        limit: int = 5
    ) -> List[Skill]:
        """Get skills that need practice"""
        if not self.config.suggest_practice:
            return []
        
        all_skills = await self._registry.get_all()
        
        needs_practice = [
            s for s in all_skills
            if s.needs_practice and s.status != SkillStatus.DEPRECATED
        ]
        
        # Prioritize by importance and rustiness
        def priority(skill: Skill) -> float:
            score = 0.0
            
            # Level matters (higher level = more to lose)
            score += skill.level.value * 0.2
            
            # Days since use
            if skill.last_used:
                days = (datetime.now() - skill.last_used).days
                score += min(days / 30, 1.0) * 0.3
            else:
                score += 0.5
            
            # Success rate (lower = needs more practice)
            score += (1 - skill.success_rate) * 0.3
            
            return score
        
        needs_practice.sort(key=priority, reverse=True)
        return needs_practice[:limit]
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MEMORY INTEGRATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _store_skill(self, skill: Skill) -> None:
        """Store skill in memory"""
        if not self.memory_manager:
            return
        
        try:
            await self.memory_manager.store_memory(
                content={
                    "skill_id": skill.id,
                    "name": skill.name,
                    "description": skill.description,
                    "category": skill.category.value,
                    "steps": [
                        {"action": s.action, "description": s.description}
                        for s in skill.steps
                    ],
                    "level": skill.level.value
                },
                memory_type="skill",
                tags=["skill"] + skill.tags,
                metadata={
                    "source": skill.source,
                    "created_at": skill.created_at.isoformat()
                }
            )
        except Exception as e:
            logger.error(f"Failed to store skill: {e}")
    
    async def load_from_memory(self) -> int:
        """Load skills from memory"""
        if not self.memory_manager or not self.config.load_from_memory:
            return 0
        
        loaded = 0
        
        try:
            memories = await self.memory_manager.search_memories(
                query="",
                memory_type="skill",
                limit=1000
            )
            
            for memory in memories:
                content = memory.get("content", {})
                
                if isinstance(content, dict) and "skill_id" in content:
                    # Check if already loaded
                    existing = await self._registry.get(content["skill_id"])
                    if existing:
                        continue
                    
                    # Create skill from memory
                    try:
                        category = SkillCategory(content.get("category", "custom"))
                    except ValueError:
                        category = SkillCategory.CUSTOM
                    
                    steps = []
                    for step_data in content.get("steps", []):
                        steps.append({
                            "action": step_data.get("action", ""),
                            "description": step_data.get("description", "")
                        })
                    
                    await self.create_skill(
                        name=content.get("name", "unknown"),
                        description=content.get("description", ""),
                        category=category,
                        steps=steps,
                        tags=memory.get("tags", []),
                        source="memory"
                    )
                    loaded += 1
        
        except Exception as e:
            logger.error(f"Failed to load skills from memory: {e}")
        
        return loaded
    
    # ═══════════════════════════════════════════════════════════════════════════
    # QUERIES
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def get_skill(self, skill_id: str) -> Optional[Skill]:
        """Get skill by ID"""
        return await self._registry.get(skill_id)
    
    async def find_skill(self, name: str) -> Optional[Skill]:
        """Find skill by name"""
        return await self._registry.get_by_name(name)
    
    async def search_skills(self, query: str, limit: int = 10) -> List[Skill]:
        """Search skills"""
        return await self._registry.search(query, limit)
    
    async def get_skills_by_category(self, category: SkillCategory) -> List[Skill]:
        """Get skills by category"""
        return await self._registry.get_by_category(category)
    
    async def get_all_skills(self) -> List[Skill]:
        """Get all skills"""
        return await self._registry.get_all()
    
    async def get_mastered_skills(self) -> List[Skill]:
        """Get mastered skills"""
        all_skills = await self._registry.get_all()
        return [s for s in all_skills if s.is_mastered]
    
    async def get_stats(self) -> Dict[str, Any]:
        """Get skill builder statistics"""
        registry_stats = await self._registry.get_stats()
        
        return {
            **self._stats,
            "registry": registry_stats,
            "gaps_count": len(self._skill_gaps),
            "execution_history_size": len(self._execution_history)
        }
    
    async def export_skills(self) -> Dict[str, Any]:
        """Export all skills"""
        all_skills = await self._registry.get_all()
        
        return {
            "skills": [s.to_dict() for s in all_skills],
            "stats": await self.get_stats(),
            "exported_at": datetime.now().isoformat()
        }


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

async def create_skill_builder(
    memory_manager: Optional[Any] = None,
    learning_engine: Optional[Any] = None,
    **kwargs
) -> SkillBuilder:
    """Create configured skill builder"""
    config = BuilderConfig(**kwargs)
    
    builder = SkillBuilder(
        config=config,
        memory_manager=memory_manager,
        learning_engine=learning_engine
    )
    
    # Load from memory if configured
    if config.load_from_memory:
        await builder.load_from_memory()
    
    return builder