#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 MEMORY AS HINT - USE MEMORY AS CONTEXT, NOT ANSWER
═══════════════════════════════════════════════════════════════════════════════

 CRITICAL PHILOSOPHY:
 ────────────────────
 Memory is a HINT to guide thinking, NOT a direct answer.
 
 The agent MUST:
 1. Retrieve relevant memories as HINTS
 2. Think FRESH with hints as context
 3. VERIFY hints against current reality
 4. Form NEW conclusions (not just repeat memory)
 5. UPDATE memory if reality differs
 
 WHY THIS MATTERS:
 ─────────────────
 • Memory can be outdated
 • Memory can be wrong
 • Reality changes
 • Agent must think, not just recall
 • Prevents stale/incorrect answers
 
 WHEN MEMORY SPIKES (gets large):
 ─────────────────────────────────
 • Don't just dump all memory
 • Rank by relevance
 • Use as hints, not answers
 • Think fresh with hints
 • Verify before trusting
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Tuple, TYPE_CHECKING
from dataclasses import dataclass, field
from enum import Enum

if TYPE_CHECKING:
    from memory.memory_manager import MemoryManager, MemoryEntry


class HintRelevance(Enum):
    """Relevance level of a memory hint."""
    HIGH = "high"           # Directly relevant
    MEDIUM = "medium"       # Somewhat relevant
    LOW = "low"             # Tangentially relevant
    STALE = "stale"         # Old, may be outdated


class HintTrustLevel(Enum):
    """How much to trust this hint."""
    VERIFIED = "verified"       # Recently verified, high trust
    TRUSTED = "trusted"         # From reliable source
    UNCERTAIN = "uncertain"     # May be outdated
    SUSPICIOUS = "suspicious"   # Conflicts exist, verify before use


@dataclass
class MemoryHint:
    """
    A memory presented as a HINT for thinking.
    
    NOT an answer - just context to guide reasoning.
    """
    key: str
    value: Any
    
    # Hint metadata
    relevance: HintRelevance
    trust_level: HintTrustLevel
    confidence: float
    
    # Source info
    source: str
    category: str
    
    # Age info
    age_days: int
    last_verified: Optional[datetime]
    
    # Flags
    is_hint: bool = True  # Always True - reminder that this is a hint
    needs_verification: bool = False
    may_be_outdated: bool = False
    
    # Related hints
    related_keys: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for LLM context."""
        return {
            'key': self.key,
            'value': self.value,
            'relevance': self.relevance.value,
            'trust_level': self.trust_level.value,
            'confidence': self.confidence,
            'age_days': self.age_days,
            'is_hint': True,
            'needs_verification': self.needs_verification,
            'may_be_outdated': self.may_be_outdated,
            '_note': 'USE AS HINT ONLY - VERIFY BEFORE TRUSTING'
        }


@dataclass
class HintCollection:
    """Collection of hints for a query."""
    query: str
    hints: List[MemoryHint]
    
    # Collection metadata
    total_found: int
    returned_count: int
    truncated: bool
    
    # Quality indicators
    has_verified_hints: bool
    has_stale_hints: bool
    needs_fresh_thinking: bool
    
    # Warning
    warning: str = "These are HINTS only. Think fresh and verify."
    
    def get_high_relevance(self) -> List[MemoryHint]:
        """Get only high relevance hints."""
        return [h for h in self.hints if h.relevance == HintRelevance.HIGH]
        
    def get_verified(self) -> List[MemoryHint]:
        """Get only verified hints."""
        return [h for h in self.hints if h.trust_level == HintTrustLevel.VERIFIED]
        
    def to_context_dict(self) -> Dict[str, Any]:
        """Convert to context for LLM."""
        return {
            '_important': 'USE THESE AS HINTS ONLY - DO NOT TRUST BLINDLY',
            'hints': [h.to_dict() for h in self.hints],
            'has_stale_hints': self.has_stale_hints,
            'needs_fresh_thinking': self.needs_fresh_thinking,
            'instruction': 'Think fresh using these as context. Verify before trusting.'
        }


class MemoryAsHint:
    """
    ═══════════════════════════════════════════════════════════════════════════
    MEMORY HINT SYSTEM
    ═══════════════════════════════════════════════════════════════════════════
    
    Transforms memory entries into HINTS for thinking.
    Ensures agent thinks fresh instead of just recalling.
    """
    
    # Age thresholds
    VERIFIED_THRESHOLD_HOURS = 24     # Consider verified if checked within 24h
    STALE_THRESHOLD_DAYS = 7          # Consider stale after 7 days
    OUTDATED_THRESHOLD_DAYS = 30      # Consider potentially outdated after 30 days
    
    # Relevance scoring weights
    WEIGHTS = {
        'keyword_match': 0.3,
        'category_match': 0.2,
        'recency': 0.2,
        'confidence': 0.2,
        'verified': 0.1,
    }
    
    def __init__(self, memory_manager: 'MemoryManager', config: Dict[str, Any] = None):
        """
        Initialize hint system.
        
        Args:
            memory_manager: Parent memory manager
            config: Configuration
        """
        self.logger = logging.getLogger("memory.hints")
        self.memory = memory_manager
        self.config = config or {}
        
        # Configuration
        self.max_hints = self.config.get('max_hints', 10)
        self.stale_threshold = self.config.get('stale_days', self.STALE_THRESHOLD_DAYS)
        
        # Statistics
        self.stats = {
            'hints_generated': 0,
            'stale_hints_flagged': 0,
            'verifications_recommended': 0,
        }
        
    async def initialize(self) -> None:
        """Initialize hint system."""
        self.logger.info("Memory-as-hint system initialized")
        
    async def get_hints_for_query(
        self,
        query: str,
        context: Dict[str, Any] = None,
        max_hints: int = None,
        include_stale: bool = True
    ) -> HintCollection:
        """
        Get memory hints for a query.
        
        IMPORTANT: These are HINTS, not answers. The agent must think fresh.
        
        Args:
            query: The query to find hints for
            context: Additional context
            max_hints: Maximum hints to return
            include_stale: Include stale hints (with warning)
            
        Returns:
            HintCollection with ranked hints
        """
        max_hints = max_hints or self.max_hints
        
        self.logger.debug(f"Getting hints for: {query[:50]}...")
        
        # Search memory
        entries = await self.memory.search(query, limit=max_hints * 2)
        
        # Convert to hints with ranking
        hints = []
        for entry in entries:
            hint = self._entry_to_hint(entry, query, context)
            
            # Skip stale if not wanted
            if not include_stale and hint.relevance == HintRelevance.STALE:
                continue
                
            hints.append(hint)
            
        # Sort by relevance score
        hints = self._rank_hints(hints, query)[:max_hints]
        
        # Check for stale hints
        has_stale = any(h.relevance == HintRelevance.STALE for h in hints)
        has_verified = any(h.trust_level == HintTrustLevel.VERIFIED for h in hints)
        
        # Determine if fresh thinking is needed
        needs_fresh = (
            has_stale or 
            not has_verified or 
            len(hints) == 0 or
            any(h.needs_verification for h in hints)
        )
        
        self.stats['hints_generated'] += len(hints)
        if has_stale:
            self.stats['stale_hints_flagged'] += 1
            
        collection = HintCollection(
            query=query,
            hints=hints,
            total_found=len(entries),
            returned_count=len(hints),
            truncated=len(entries) > len(hints),
            has_verified_hints=has_verified,
            has_stale_hints=has_stale,
            needs_fresh_thinking=needs_fresh
        )
        
        self.logger.debug(
            f"Returning {len(hints)} hints "
            f"(stale: {has_stale}, verified: {has_verified})"
        )
        
        return collection
        
    async def get_hints_by_category(
        self,
        categories: List[str],
        max_per_category: int = 3
    ) -> Dict[str, List[MemoryHint]]:
        """
        Get hints organized by category.
        
        Args:
            categories: Categories to fetch
            max_per_category: Max hints per category
            
        Returns:
            Dictionary of category -> hints
        """
        result = {}
        
        for category in categories:
            entries = await self.memory.get_by_category(category, limit=max_per_category)
            
            hints = [
                self._entry_to_hint(entry, "", {})
                for entry in entries
            ]
            
            result[category] = hints
            
        return result
        
    async def check_hint_validity(
        self,
        hint: MemoryHint,
        actual_value: Any
    ) -> Tuple[bool, Optional[str]]:
        """
        Check if a hint is still valid against reality.
        
        Args:
            hint: The hint to check
            actual_value: The actual current value
            
        Returns:
            Tuple of (is_valid, conflict_reason if invalid)
        """
        if hint.value == actual_value:
            return True, None
            
        # Values differ - hint is invalid
        self.stats['verifications_recommended'] += 1
        
        conflict_reason = (
            f"Memory hint '{hint.key}' has value '{hint.value}' "
            f"but reality shows '{actual_value}'"
        )
        
        self.logger.warning(f"Hint validity check failed: {conflict_reason}")
        
        return False, conflict_reason
        
    async def mark_hint_verified(
        self,
        hint: MemoryHint,
        verified_value: Any
    ) -> None:
        """
        Mark a hint as verified (updates underlying memory).
        
        Args:
            hint: The hint that was verified
            verified_value: The verified value
        """
        # Update the memory entry
        await self.memory.verify_against_reality(
            hint.key,
            verified_value,
            hint.category
        )
        
        self.logger.debug(f"Hint verified: {hint.key}")
        
    def _entry_to_hint(
        self,
        entry: 'MemoryEntry',
        query: str,
        context: Dict[str, Any]
    ) -> MemoryHint:
        """Convert a memory entry to a hint."""
        now = datetime.utcnow()
        
        # Calculate age
        age_days = (now - entry.created_at).days if entry.created_at else 0
        
        # Determine staleness
        is_stale = age_days > self.stale_threshold
        may_be_outdated = age_days > self.OUTDATED_THRESHOLD_DAYS
        
        # Determine trust level
        if entry.is_verified:
            if entry.accessed_at and (now - entry.accessed_at).total_seconds() < self.VERIFIED_THRESHOLD_HOURS * 3600:
                trust_level = HintTrustLevel.VERIFIED
            else:
                trust_level = HintTrustLevel.TRUSTED
        elif is_stale:
            trust_level = HintTrustLevel.SUSPICIOUS
        else:
            trust_level = HintTrustLevel.UNCERTAIN
            
        # Determine relevance
        if is_stale:
            relevance = HintRelevance.STALE
        else:
            # Simple keyword matching for relevance
            query_words = set(query.lower().split())
            key_words = set(entry.key.lower().split('_'))
            
            overlap = len(query_words & key_words)
            if overlap > 1:
                relevance = HintRelevance.HIGH
            elif overlap == 1:
                relevance = HintRelevance.MEDIUM
            else:
                relevance = HintRelevance.LOW
                
        return MemoryHint(
            key=entry.key,
            value=entry.value,
            relevance=relevance,
            trust_level=trust_level,
            confidence=entry.confidence,
            source=entry.source,
            category=entry.category,
            age_days=age_days,
            last_verified=entry.accessed_at if entry.is_verified else None,
            is_hint=True,
            needs_verification=trust_level in (HintTrustLevel.UNCERTAIN, HintTrustLevel.SUSPICIOUS),
            may_be_outdated=may_be_outdated
        )
        
    def _rank_hints(
        self,
        hints: List[MemoryHint],
        query: str
    ) -> List[MemoryHint]:
        """
        Rank hints by relevance score.
        
        Higher score = more relevant.
        """
        def score_hint(hint: MemoryHint) -> float:
            score = 0.0
            
            # Relevance score
            relevance_scores = {
                HintRelevance.HIGH: 1.0,
                HintRelevance.MEDIUM: 0.6,
                HintRelevance.LOW: 0.3,
                HintRelevance.STALE: 0.1,
            }
            score += relevance_scores.get(hint.relevance, 0.5) * self.WEIGHTS['keyword_match']
            
            # Trust score
            trust_scores = {
                HintTrustLevel.VERIFIED: 1.0,
                HintTrustLevel.TRUSTED: 0.8,
                HintTrustLevel.UNCERTAIN: 0.4,
                HintTrustLevel.SUSPICIOUS: 0.2,
            }
            score += trust_scores.get(hint.trust_level, 0.5) * self.WEIGHTS['verified']
            
            # Recency score (newer = better)
            if hint.age_days == 0:
                recency = 1.0
            elif hint.age_days < 7:
                recency = 0.8
            elif hint.age_days < 30:
                recency = 0.5
            else:
                recency = 0.2
            score += recency * self.WEIGHTS['recency']
            
            # Confidence score
            score += hint.confidence * self.WEIGHTS['confidence']
            
            return score
            
        return sorted(hints, key=score_hint, reverse=True)
        
    def format_hints_for_llm(
        self,
        collection: HintCollection
    ) -> str:
        """
        Format hints as context for LLM prompt.
        
        ALWAYS includes warning about hints vs answers.
        """
        lines = [
            "═══ MEMORY HINTS (Use as context, NOT answers) ═══",
            "",
            "⚠️ IMPORTANT: These are HINTS to guide your thinking.",
            "   DO NOT treat these as facts.",
            "   VERIFY before trusting.",
            "   THINK FRESH with these as context.",
            ""
        ]
        
        if not collection.hints:
            lines.append("No relevant hints found. Think from first principles.")
        else:
            for hint in collection.hints:
                trust_icon = {
                    HintTrustLevel.VERIFIED: "✓",
                    HintTrustLevel.TRUSTED: "~",
                    HintTrustLevel.UNCERTAIN: "?",
                    HintTrustLevel.SUSPICIOUS: "⚠",
                }.get(hint.trust_level, "?")
                
                lines.append(f"[{trust_icon}] {hint.key}:")
                lines.append(f"    Value: {hint.value}")
                lines.append(f"    Trust: {hint.trust_level.value} | Age: {hint.age_days} days")
                
                if hint.needs_verification:
                    lines.append(f"    ⚠️ NEEDS VERIFICATION")
                    
                lines.append("")
                
        if collection.has_stale_hints:
            lines.append("⚠️ Some hints are STALE and may be outdated.")
            
        lines.append("")
        lines.append("═══ END HINTS ═══")
        
        return "\n".join(lines)
        
    def get_stats(self) -> Dict[str, Any]:
        """Get hint system statistics."""
        return self.stats.copy()