#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 MEMORY REWRITER - AGENT-CONTROLLED MEMORY OVERWRITE
═══════════════════════════════════════════════════════════════════════════════

 Allows the agent to REWRITE memories when it believes they are wrong.
 
 THIS IS A CRITICAL FEATURE:
 ───────────────────────────
 The agent has the power to:
 • Identify incorrect memories
 • Decide to overwrite them
 • Provide reasoning for the change
 • Make the change VISIBLE with tags
 
 WHEN AGENT SHOULD REWRITE:
 ──────────────────────────
 • Tool output contradicts memory
 • User corrects the agent
 • Research reveals memory is wrong
 • Logic determines memory is inconsistent
 
 VISIBILITY REQUIREMENTS:
 ────────────────────────
 Every rewrite MUST:
 1. Show [MEMORY OVERWRITTEN] tag
 2. Show old value
 3. Show new value
 4. Show reason for change
 5. Record in version history
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
from datetime import datetime
from typing import Optional, Dict, Any, List, TYPE_CHECKING
from dataclasses import dataclass, field
from enum import Enum

if TYPE_CHECKING:
    from memory.memory_manager import MemoryManager

from memory.core_memory.memory_tagger import MemoryTagger, MemoryTag, TaggedMemory
from memory.core_memory.memory_versioning import MemoryVersioning


class RewriteReason(Enum):
    """Reasons for rewriting memory."""
    TOOL_CONTRADICTION = "tool_output_contradicted"
    USER_CORRECTION = "user_corrected"
    RESEARCH_DISCOVERY = "research_discovered"
    LOGIC_INCONSISTENCY = "logic_inconsistent"
    REALITY_CHECK = "reality_check_failed"
    AGENT_LEARNING = "agent_learned_better"
    EXPLICIT_UPDATE = "explicit_update_requested"


@dataclass
class RewriteResult:
    """Result of a memory rewrite operation."""
    success: bool
    key: str
    old_value: Any
    new_value: Any
    reason: str
    rewrite_reason: RewriteReason
    
    # The tag for display
    tag: TaggedMemory
    
    # Version info
    old_version: int
    new_version: int
    
    # Metadata
    timestamp: datetime = field(default_factory=datetime.utcnow)
    rewritten_by: str = "agent"
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for display/logging."""
        return {
            'success': self.success,
            'key': self.key,
            'old_value': self.old_value,
            'new_value': self.new_value,
            'reason': self.reason,
            'rewrite_reason': self.rewrite_reason.value,
            'old_version': self.old_version,
            'new_version': self.new_version,
            'timestamp': self.timestamp.isoformat(),
            'tag': str(self.tag) if self.tag else None
        }


class MemoryRewriter:
    """
    ═══════════════════════════════════════════════════════════════════════════
    MEMORY REWRITE CONTROLLER
    ═══════════════════════════════════════════════════════════════════════════
    
    Handles agent-initiated memory rewrites with full visibility.
    """
    
    def __init__(
        self,
        memory_manager: 'MemoryManager',
        tagger: MemoryTagger,
        versioning: MemoryVersioning
    ):
        """
        Initialize rewriter.
        
        Args:
            memory_manager: Parent memory manager
            tagger: Memory tagging system
            versioning: Version control system
        """
        self.logger = logging.getLogger("memory.rewriter")
        self.memory = memory_manager
        self.tagger = tagger
        self.versioning = versioning
        
        # Track rewrites for auditing
        self.rewrite_history: List[RewriteResult] = []
        self.max_history = 1000
        
        # Statistics
        self.stats = {
            'total_rewrites': 0,
            'by_reason': {},
        }
        
    async def initialize(self) -> None:
        """Initialize rewriter."""
        self.logger.info("Memory rewriter initialized")
        
    async def rewrite(
        self,
        key: str,
        new_value: Any,
        reason: str,
        category: str = None,
        rewrite_reason: RewriteReason = RewriteReason.AGENT_LEARNING
    ) -> RewriteResult:
        """
        Rewrite a memory with a new value.
        
        ALWAYS produces visible [MEMORY OVERWRITTEN] tag.
        
        Args:
            key: Memory key to rewrite
            new_value: New value to set
            reason: Human-readable reason for the change
            category: Memory category
            rewrite_reason: Enum reason for the change
            
        Returns:
            RewriteResult with all details
        """
        self.logger.info(f"Agent rewriting memory: {key}")
        self.logger.info(f"Reason: {reason}")
        
        # Get existing memory
        existing = await self.memory.get(key, category)
        
        if not existing:
            # No existing memory - this is a new memory, not a rewrite
            entry, tag = await self.memory.store(
                key=key,
                value=new_value,
                category=category or "general",
                source="agent"
            )
            
            return RewriteResult(
                success=True,
                key=key,
                old_value=None,
                new_value=new_value,
                reason=reason,
                rewrite_reason=rewrite_reason,
                tag=tag,
                old_version=0,
                new_version=1,
                rewritten_by="agent"
            )
            
        old_value = existing.value
        old_version = existing.version
        
        # Check if rewrite is actually needed
        if old_value == new_value:
            self.logger.debug(f"Memory {key} already has this value, skipping rewrite")
            tag = self.tagger.create_tag(MemoryTag.VERIFIED, key, new_value)
            return RewriteResult(
                success=True,
                key=key,
                old_value=old_value,
                new_value=new_value,
                reason="Value unchanged",
                rewrite_reason=rewrite_reason,
                tag=tag,
                old_version=old_version,
                new_version=old_version,
                rewritten_by="agent"
            )
            
        # ═══════════════════════════════════════════════════════════════════
        # PERFORM THE REWRITE
        # ═══════════════════════════════════════════════════════════════════
        
        # 1. Save old version to history
        await self.versioning.save_version(
            memory_id=existing.id,
            version=old_version,
            value=old_value,
            reason=f"Overwritten by agent: {reason}"
        )
        
        # 2. Update the memory
        import json
        new_version = old_version + 1
        now = datetime.utcnow()
        
        await self.memory._main_conn.execute("""
            UPDATE memories 
            SET value = ?, version = ?, updated_at = ?, source = ?, is_verified = 1
            WHERE id = ?
        """, (
            json.dumps(new_value, default=str),
            new_version,
            now.isoformat(),
            "agent_rewrite",
            existing.id
        ))
        
        await self.memory._main_conn.commit()
        
        # 3. Create the visible tag
        tag = self.tagger.create_tag(
            MemoryTag.OVERWRITTEN,
            key,
            new_value,
            old_value,
            f"Agent decision: {reason}"
        )
        
        # 4. Record the rewrite
        result = RewriteResult(
            success=True,
            key=key,
            old_value=old_value,
            new_value=new_value,
            reason=reason,
            rewrite_reason=rewrite_reason,
            tag=tag,
            old_version=old_version,
            new_version=new_version,
            rewritten_by="agent"
        )
        
        self._record_rewrite(result)
        
        # 5. Add to pending changes for notification
        from memory.memory_manager import MemoryChange
        self.memory._pending_changes.append(MemoryChange(
            change_type='overwritten',
            key=key,
            old_value=old_value,
            new_value=new_value,
            reason=reason,
            category=category or existing.category
        ))
        
        self.logger.info(
            f"Memory rewritten: {key} | v{old_version} → v{new_version} | "
            f"{str(old_value)[:30]} → {str(new_value)[:30]}"
        )
        
        return result
        
    async def rewrite_from_tool_output(
        self,
        key: str,
        tool_output: Any,
        tool_name: str,
        category: str = None
    ) -> RewriteResult:
        """
        Rewrite memory based on tool output (e.g., when reality differs).
        
        Args:
            key: Memory key
            tool_output: Output from a tool that contradicts memory
            tool_name: Name of the tool
            category: Memory category
        """
        existing = await self.memory.get(key, category)
        
        if existing:
            reason = (
                f"Tool '{tool_name}' output contradicts memory. "
                f"Memory had: {existing.value}, Tool shows: {tool_output}"
            )
        else:
            reason = f"Learned from tool '{tool_name}' output"
            
        return await self.rewrite(
            key=key,
            new_value=tool_output,
            reason=reason,
            category=category,
            rewrite_reason=RewriteReason.TOOL_CONTRADICTION
        )
        
    async def rewrite_from_user_correction(
        self,
        key: str,
        corrected_value: Any,
        user_statement: str,
        category: str = None
    ) -> RewriteResult:
        """
        Rewrite memory based on user correction.
        
        Args:
            key: Memory key
            corrected_value: The correct value from user
            user_statement: What the user said
            category: Memory category
        """
        reason = f"User corrected: '{user_statement}'"
        
        return await self.rewrite(
            key=key,
            new_value=corrected_value,
            reason=reason,
            category=category,
            rewrite_reason=RewriteReason.USER_CORRECTION
        )
        
    async def rewrite_from_research(
        self,
        key: str,
        researched_value: Any,
        source: str,
        category: str = None
    ) -> RewriteResult:
        """
        Rewrite memory based on autonomous research findings.
        
        Args:
            key: Memory key
            researched_value: Value discovered through research
            source: Source of the research (URL, documentation, etc.)
            category: Memory category
        """
        reason = f"Research discovery from: {source}"
        
        return await self.rewrite(
            key=key,
            new_value=researched_value,
            reason=reason,
            category=category,
            rewrite_reason=RewriteReason.RESEARCH_DISCOVERY
        )
        
    async def rewrite_from_logic(
        self,
        key: str,
        logical_value: Any,
        reasoning: str,
        category: str = None
    ) -> RewriteResult:
        """
        Rewrite memory because logic determined it was inconsistent.
        
        Args:
            key: Memory key
            logical_value: Value determined through logical reasoning
            reasoning: The logical reasoning that led to this conclusion
            category: Memory category
        """
        reason = f"Logical inconsistency detected: {reasoning}"
        
        return await self.rewrite(
            key=key,
            new_value=logical_value,
            reason=reason,
            category=category,
            rewrite_reason=RewriteReason.LOGIC_INCONSISTENCY
        )
        
    async def bulk_rewrite(
        self,
        rewrites: List[Dict[str, Any]]
    ) -> List[RewriteResult]:
        """
        Perform multiple rewrites in batch.
        
        Args:
            rewrites: List of dicts with 'key', 'new_value', 'reason', etc.
            
        Returns:
            List of RewriteResults
        """
        results = []
        
        for rewrite_data in rewrites:
            result = await self.rewrite(
                key=rewrite_data['key'],
                new_value=rewrite_data['new_value'],
                reason=rewrite_data.get('reason', 'Bulk update'),
                category=rewrite_data.get('category'),
                rewrite_reason=RewriteReason(
                    rewrite_data.get('rewrite_reason', 'agent_learned_better')
                )
            )
            results.append(result)
            
        return results
        
    def _record_rewrite(self, result: RewriteResult) -> None:
        """Record a rewrite for auditing."""
        self.rewrite_history.append(result)
        
        # Trim history if too large
        if len(self.rewrite_history) > self.max_history:
            self.rewrite_history = self.rewrite_history[-self.max_history:]
            
        # Update stats
        self.stats['total_rewrites'] += 1
        reason_key = result.rewrite_reason.value
        self.stats['by_reason'][reason_key] = (
            self.stats['by_reason'].get(reason_key, 0) + 1
        )
        
    def get_rewrite_history(
        self,
        key: str = None,
        limit: int = 50
    ) -> List[RewriteResult]:
        """Get rewrite history, optionally filtered by key."""
        history = self.rewrite_history
        
        if key:
            history = [r for r in history if r.key == key]
            
        return history[-limit:]
        
    def get_stats(self) -> Dict[str, Any]:
        """Get rewriter statistics."""
        return {
            **self.stats,
            'history_size': len(self.rewrite_history),
        }