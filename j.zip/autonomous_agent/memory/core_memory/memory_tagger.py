#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 MEMORY TAGGER - VISIBLE MEMORY OPERATION TAGS
═══════════════════════════════════════════════════════════════════════════════

 Creates visible tags for ALL memory operations.
 
 TAG TYPES:
 ──────────
 🏷️ [MEMORY SAVED]      → New information stored
 🔄 [MEMORY UPDATED]    → Existing information changed  
 ♻️ [MEMORY OVERWRITTEN]→ Agent decided to rewrite
 ✅ [MEMORY VERIFIED]   → Information verified against reality
 📚 [MEMORY LEARNED]    → Learned from research
 ⚠️ [MEMORY CONFLICT]   → Conflict between memory and reality
 🗑️ [MEMORY ARCHIVED]   → Old version archived
 📍 [MEMORY PERMANENT]  → Stored in permanent memory
 💡 [MEMORY HINT]       → Using as hint, not fact
 ❌ [MEMORY DELETED]    → Memory removed
 
 VISIBILITY REQUIREMENTS:
 ────────────────────────
 • ALL memory operations MUST produce a tag
 • Tags MUST be shown to user in output
 • Tags MUST include relevant details
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import logging
from datetime import datetime
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
from enum import Enum


class MemoryTag(Enum):
    """Types of memory tags."""
    SAVED = ("🏷️", "[MEMORY SAVED]", "green")
    UPDATED = ("🔄", "[MEMORY UPDATED]", "yellow")
    OVERWRITTEN = ("♻️", "[MEMORY OVERWRITTEN]", "orange")
    VERIFIED = ("✅", "[MEMORY VERIFIED]", "green")
    LEARNED = ("📚", "[MEMORY LEARNED]", "cyan")
    CONFLICT = ("⚠️", "[MEMORY CONFLICT]", "red")
    ARCHIVED = ("🗑️", "[MEMORY ARCHIVED]", "gray")
    PERMANENT = ("📍", "[MEMORY PERMANENT]", "purple")
    HINT = ("💡", "[MEMORY HINT]", "blue")
    DELETED = ("❌", "[MEMORY DELETED]", "red")
    
    @property
    def icon(self) -> str:
        return self.value[0]
        
    @property
    def label(self) -> str:
        return self.value[1]
        
    @property
    def color(self) -> str:
        return self.value[2]


@dataclass
class TaggedMemory:
    """A tagged memory operation for display."""
    tag_type: MemoryTag
    key: str
    
    # Values
    new_value: Any = None
    old_value: Any = None
    
    # Additional info
    reason: str = ""
    category: str = ""
    source: str = ""
    
    # Display
    icon: str = ""
    label: str = ""
    color: str = ""
    
    # Timing
    timestamp: datetime = field(default_factory=datetime.utcnow)
    
    def __post_init__(self):
        self.icon = self.tag_type.icon
        self.label = self.tag_type.label
        self.color = self.tag_type.color
        
    def __str__(self) -> str:
        """String representation for display."""
        return self.format_for_display()
        
    def format_for_display(self, include_values: bool = True) -> str:
        """
        Format the tag for display in output.
        
        Returns:
            Formatted string ready for display
        """
        parts = [f"{self.icon} {self.label} {self.key}"]
        
        if include_values:
            if self.old_value is not None and self.new_value is not None:
                # Show change
                old_str = self._format_value(self.old_value)
                new_str = self._format_value(self.new_value)
                parts.append(f"   {old_str} → {new_str}")
            elif self.new_value is not None:
                # Show new value
                new_str = self._format_value(self.new_value)
                parts.append(f"   = {new_str}")
                
        if self.reason:
            parts.append(f"   Reason: {self.reason}")
            
        return "\n".join(parts)
        
    def format_for_telegram(self) -> str:
        """Format for Telegram output."""
        text = f"{self.icon} `{self.label}` *{self.key}*"
        
        if self.old_value is not None and self.new_value is not None:
            old_str = self._format_value(self.old_value, max_len=30)
            new_str = self._format_value(self.new_value, max_len=30)
            text += f"\n   `{old_str}` → `{new_str}`"
        elif self.new_value is not None:
            new_str = self._format_value(self.new_value, max_len=50)
            text += f"\n   = `{new_str}`"
            
        if self.reason:
            text += f"\n   _{self.reason}_"
            
        return text
        
    def format_for_log(self) -> str:
        """Format for logging."""
        return (
            f"{self.label} key={self.key} "
            f"old={self.old_value} new={self.new_value} "
            f"reason={self.reason}"
        )
        
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'type': self.tag_type.name,
            'icon': self.icon,
            'label': self.label,
            'key': self.key,
            'old_value': self.old_value,
            'new_value': self.new_value,
            'reason': self.reason,
            'category': self.category,
            'timestamp': self.timestamp.isoformat(),
        }
        
    def _format_value(self, value: Any, max_len: int = 50) -> str:
        """Format a value for display."""
        if value is None:
            return "null"
        if isinstance(value, str):
            if len(value) > max_len:
                return f'"{value[:max_len]}..."'
            return f'"{value}"'
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, (int, float)):
            return str(value)
        if isinstance(value, dict):
            return f"{{...}} ({len(value)} keys)"
        if isinstance(value, list):
            return f"[...] ({len(value)} items)"
        
        str_val = str(value)
        if len(str_val) > max_len:
            return str_val[:max_len] + "..."
        return str_val


class MemoryTagger:
    """
    ═══════════════════════════════════════════════════════════════════════════
    MEMORY TAG GENERATOR
    ═══════════════════════════════════════════════════════════════════════════
    
    Creates tags for all memory operations.
    """
    
    def __init__(self):
        """Initialize tagger."""
        self.logger = logging.getLogger("memory.tagger")
        
        # Track recent tags
        self.recent_tags: List[TaggedMemory] = []
        self.max_recent = 100
        
        # Statistics
        self.stats = {
            'tags_created': 0,
            'by_type': {},
        }
        
    async def initialize(self) -> None:
        """Initialize tagger."""
        self.logger.debug("Memory tagger initialized")
        
    def create_tag(
        self,
        tag_type: MemoryTag,
        key: str,
        new_value: Any = None,
        old_value: Any = None,
        reason: str = "",
        category: str = "",
        source: str = ""
    ) -> TaggedMemory:
        """
        Create a memory tag.
        
        Args:
            tag_type: Type of tag
            key: Memory key
            new_value: New value (if applicable)
            old_value: Old value (if applicable)
            reason: Reason for the operation
            category: Memory category
            source: Source of the operation
            
        Returns:
            TaggedMemory ready for display
        """
        tag = TaggedMemory(
            tag_type=tag_type,
            key=key,
            new_value=new_value,
            old_value=old_value,
            reason=reason,
            category=category,
            source=source
        )
        
        # Track
        self._record_tag(tag)
        
        # Log
        self.logger.debug(tag.format_for_log())
        
        return tag
        
    def create_saved_tag(
        self,
        key: str,
        value: Any,
        category: str = ""
    ) -> TaggedMemory:
        """Create [MEMORY SAVED] tag."""
        return self.create_tag(
            MemoryTag.SAVED,
            key,
            new_value=value,
            category=category
        )
        
    def create_updated_tag(
        self,
        key: str,
        new_value: Any,
        old_value: Any,
        reason: str = ""
    ) -> TaggedMemory:
        """Create [MEMORY UPDATED] tag."""
        return self.create_tag(
            MemoryTag.UPDATED,
            key,
            new_value=new_value,
            old_value=old_value,
            reason=reason
        )
        
    def create_overwritten_tag(
        self,
        key: str,
        new_value: Any,
        old_value: Any,
        reason: str
    ) -> TaggedMemory:
        """
        Create [MEMORY OVERWRITTEN] tag.
        
        This is for agent-initiated rewrites.
        """
        return self.create_tag(
            MemoryTag.OVERWRITTEN,
            key,
            new_value=new_value,
            old_value=old_value,
            reason=f"Agent decision: {reason}"
        )
        
    def create_verified_tag(
        self,
        key: str,
        value: Any
    ) -> TaggedMemory:
        """Create [MEMORY VERIFIED] tag."""
        return self.create_tag(
            MemoryTag.VERIFIED,
            key,
            new_value=value,
            reason="Verified against reality"
        )
        
    def create_learned_tag(
        self,
        key: str,
        value: Any,
        source: str
    ) -> TaggedMemory:
        """Create [MEMORY LEARNED] tag for research discoveries."""
        return self.create_tag(
            MemoryTag.LEARNED,
            key,
            new_value=value,
            source=source,
            reason=f"Learned from: {source}"
        )
        
    def create_conflict_tag(
        self,
        key: str,
        memory_value: Any,
        reality_value: Any
    ) -> TaggedMemory:
        """Create [MEMORY CONFLICT] tag."""
        return self.create_tag(
            MemoryTag.CONFLICT,
            key,
            new_value=reality_value,
            old_value=memory_value,
            reason="Memory conflicts with reality - reality wins"
        )
        
    def create_permanent_tag(
        self,
        key: str,
        value: Any,
        old_value: Any = None
    ) -> TaggedMemory:
        """Create [MEMORY PERMANENT] tag."""
        return self.create_tag(
            MemoryTag.PERMANENT,
            key,
            new_value=value,
            old_value=old_value,
            reason="Stored in permanent memory (never expires)"
        )
        
    def create_hint_tag(
        self,
        key: str,
        value: Any
    ) -> TaggedMemory:
        """Create [MEMORY HINT] tag when using memory as hint."""
        return self.create_tag(
            MemoryTag.HINT,
            key,
            new_value=value,
            reason="Using as hint only - will verify before trusting"
        )
        
    def create_deleted_tag(
        self,
        key: str,
        old_value: Any = None,
        reason: str = ""
    ) -> TaggedMemory:
        """Create [MEMORY DELETED] tag."""
        return self.create_tag(
            MemoryTag.DELETED,
            key,
            old_value=old_value,
            reason=reason
        )
        
    def create_archived_tag(
        self,
        key: str,
        value: Any,
        reason: str = ""
    ) -> TaggedMemory:
        """Create [MEMORY ARCHIVED] tag."""
        return self.create_tag(
            MemoryTag.ARCHIVED,
            key,
            old_value=value,
            reason=reason or "Archived to version history"
        )
        
    def _record_tag(self, tag: TaggedMemory) -> None:
        """Record a tag for tracking."""
        self.recent_tags.append(tag)
        
        # Trim if too large
        if len(self.recent_tags) > self.max_recent:
            self.recent_tags = self.recent_tags[-self.max_recent:]
            
        # Update stats
        self.stats['tags_created'] += 1
        type_key = tag.tag_type.name
        self.stats['by_type'][type_key] = self.stats['by_type'].get(type_key, 0) + 1
        
    def get_recent_tags(
        self,
        tag_type: MemoryTag = None,
        limit: int = 20
    ) -> List[TaggedMemory]:
        """Get recent tags, optionally filtered by type."""
        tags = self.recent_tags
        
        if tag_type:
            tags = [t for t in tags if t.tag_type == tag_type]
            
        return tags[-limit:]
        
    def format_tags_for_display(
        self,
        tags: List[TaggedMemory],
        telegram_mode: bool = False
    ) -> str:
        """
        Format multiple tags for display.
        
        Args:
            tags: List of tags to format
            telegram_mode: Use Telegram formatting
            
        Returns:
            Formatted string
        """
        if not tags:
            return ""
            
        lines = []
        for tag in tags:
            if telegram_mode:
                lines.append(tag.format_for_telegram())
            else:
                lines.append(tag.format_for_display())
            lines.append("")  # Blank line between tags
            
        return "\n".join(lines)
        
    def get_stats(self) -> Dict[str, Any]:
        """Get tagger statistics."""
        return {
            **self.stats,
            'recent_count': len(self.recent_tags),
        }


# ═══════════════════════════════════════════════════════════════════════════════
# HELPER FUNCTIONS FOR EASY TAG CREATION
# ═══════════════════════════════════════════════════════════════════════════════

def format_memory_change(
    change_type: str,
    key: str,
    old_value: Any = None,
    new_value: Any = None,
    reason: str = ""
) -> str:
    """
    Quick format a memory change for display.
    
    Args:
        change_type: Type of change (saved, updated, overwritten, etc.)
        key: Memory key
        old_value: Old value
        new_value: New value
        reason: Reason for change
        
    Returns:
        Formatted string for display
    """
    tag_map = {
        'saved': MemoryTag.SAVED,
        'updated': MemoryTag.UPDATED,
        'overwritten': MemoryTag.OVERWRITTEN,
        'verified': MemoryTag.VERIFIED,
        'learned': MemoryTag.LEARNED,
        'conflict': MemoryTag.CONFLICT,
        'archived': MemoryTag.ARCHIVED,
        'permanent': MemoryTag.PERMANENT,
        'hint': MemoryTag.HINT,
        'deleted': MemoryTag.DELETED,
    }
    
    tag_type = tag_map.get(change_type.lower(), MemoryTag.SAVED)
    
    tag = TaggedMemory(
        tag_type=tag_type,
        key=key,
        new_value=new_value,
        old_value=old_value,
        reason=reason
    )
    
    return tag.format_for_display()