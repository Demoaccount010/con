#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 MEMORY VERSIONING - TRACK ALL MEMORY CHANGES
═══════════════════════════════════════════════════════════════════════════════

 Every memory update creates a new version. Old versions are preserved.
 
 VERSIONING PHILOSOPHY:
 ──────────────────────
 • EVERY change is recorded
 • Old values are NEVER lost
 • Can rollback to any version
 • Audit trail for all modifications
 • Reason for change is always stored
 
 VERSION RECORD INCLUDES:
 ────────────────────────
 • Version number
 • Old value
 • New value
 • Timestamp
 • Who changed it (system/agent/user)
 • Why it was changed
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import aiosqlite
import logging
import json
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass, field
from enum import Enum


class ChangeSource(Enum):
    """Source of the change."""
    SYSTEM = "system"           # Automatic system update
    AGENT = "agent"             # Agent decided to change
    USER = "user"               # User explicitly changed
    TOOL = "tool"               # Tool output caused change
    RESEARCH = "research"       # Research discovery
    CORRECTION = "correction"   # Error correction
    DECAY = "decay"             # Memory decay/cleanup


@dataclass
class MemoryVersion:
    """A single version of a memory entry."""
    version_id: str
    memory_id: str
    version_number: int
    value: Any
    
    # Change info
    changed_at: datetime
    changed_by: ChangeSource
    change_reason: str
    
    # Previous reference
    previous_version: Optional[int] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'version_id': self.version_id,
            'memory_id': self.memory_id,
            'version_number': self.version_number,
            'value': self.value,
            'changed_at': self.changed_at.isoformat(),
            'changed_by': self.changed_by.value,
            'change_reason': self.change_reason,
            'previous_version': self.previous_version,
        }


@dataclass
class VersionDiff:
    """Difference between two versions."""
    memory_id: str
    key: str
    from_version: int
    to_version: int
    old_value: Any
    new_value: Any
    change_reason: str
    changed_at: datetime
    
    def format_for_display(self) -> str:
        """Format diff for display."""
        old_str = self._format_value(self.old_value)
        new_str = self._format_value(self.new_value)
        
        return (
            f"Memory: {self.key}\n"
            f"Version: {self.from_version} → {self.to_version}\n"
            f"Change: {old_str} → {new_str}\n"
            f"Reason: {self.change_reason}\n"
            f"When: {self.changed_at.isoformat()}"
        )
        
    def _format_value(self, value: Any, max_len: int = 50) -> str:
        """Format value for display."""
        if value is None:
            return "null"
        str_val = str(value)
        if len(str_val) > max_len:
            return str_val[:max_len] + "..."
        return str_val


@dataclass 
class VersionHistory:
    """Complete version history for a memory."""
    memory_id: str
    key: str
    current_version: int
    versions: List[MemoryVersion]
    total_changes: int
    first_created: datetime
    last_modified: datetime


class MemoryVersioning:
    """
    ═══════════════════════════════════════════════════════════════════════════
    MEMORY VERSION CONTROL SYSTEM
    ═══════════════════════════════════════════════════════════════════════════
    
    Tracks all versions of every memory entry.
    """
    
    def __init__(self, db_connection: aiosqlite.Connection):
        """
        Initialize versioning system.
        
        Args:
            db_connection: Database connection from memory manager
        """
        self.logger = logging.getLogger("memory.versioning")
        self.db = db_connection
        
        # Cache recent versions for quick access
        self._version_cache: Dict[str, List[MemoryVersion]] = {}
        self.cache_max_per_memory = 10
        
        # Statistics
        self.stats = {
            'versions_created': 0,
            'rollbacks': 0,
            'diffs_generated': 0,
        }
        
    async def initialize(self) -> None:
        """Initialize versioning tables."""
        self.logger.info("Initializing memory versioning system")
        
        # Create versions table if not exists
        await self.db.execute("""
            CREATE TABLE IF NOT EXISTS memory_versions (
                id TEXT PRIMARY KEY,
                memory_id TEXT NOT NULL,
                version INTEGER NOT NULL,
                value TEXT NOT NULL,
                changed_at TEXT NOT NULL,
                changed_by TEXT DEFAULT 'system',
                change_reason TEXT,
                previous_version INTEGER,
                metadata TEXT DEFAULT '{}',
                UNIQUE(memory_id, version)
            )
        """)
        
        # Index for fast lookups
        await self.db.execute("""
            CREATE INDEX IF NOT EXISTS idx_versions_memory_id 
            ON memory_versions(memory_id)
        """)
        
        await self.db.execute("""
            CREATE INDEX IF NOT EXISTS idx_versions_changed_at 
            ON memory_versions(changed_at)
        """)
        
        await self.db.commit()
        
        self.logger.info("Memory versioning system initialized")
        
    async def save_version(
        self,
        memory_id: str,
        version: int,
        value: Any,
        reason: str = "",
        changed_by: ChangeSource = ChangeSource.SYSTEM
    ) -> MemoryVersion:
        """
        Save a version to history.
        
        Called BEFORE a memory is updated to preserve the old value.
        
        Args:
            memory_id: ID of the memory
            version: Current version number (before update)
            value: Current value (before update)
            reason: Why this is being changed
            changed_by: Source of the change
            
        Returns:
            MemoryVersion that was saved
        """
        import hashlib
        
        version_id = hashlib.sha256(
            f"{memory_id}:{version}:{datetime.utcnow().isoformat()}".encode()
        ).hexdigest()[:16]
        
        now = datetime.utcnow()
        
        # Serialize value
        value_json = json.dumps(value, default=str)
        
        # Get previous version number
        previous_version = version - 1 if version > 1 else None
        
        # Insert version record
        await self.db.execute("""
            INSERT OR REPLACE INTO memory_versions 
            (id, memory_id, version, value, changed_at, changed_by, change_reason, previous_version)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            version_id,
            memory_id,
            version,
            value_json,
            now.isoformat(),
            changed_by.value,
            reason,
            previous_version
        ))
        
        await self.db.commit()
        
        # Create version object
        mem_version = MemoryVersion(
            version_id=version_id,
            memory_id=memory_id,
            version_number=version,
            value=value,
            changed_at=now,
            changed_by=changed_by,
            change_reason=reason,
            previous_version=previous_version
        )
        
        # Update cache
        self._update_cache(memory_id, mem_version)
        
        self.stats['versions_created'] += 1
        self.logger.debug(f"Saved version {version} for memory {memory_id}")
        
        return mem_version
        
    async def get_version(
        self,
        memory_id: str,
        version: int
    ) -> Optional[MemoryVersion]:
        """
        Get a specific version of a memory.
        
        Args:
            memory_id: Memory ID
            version: Version number to retrieve
            
        Returns:
            MemoryVersion or None if not found
        """
        # Check cache first
        if memory_id in self._version_cache:
            for v in self._version_cache[memory_id]:
                if v.version_number == version:
                    return v
                    
        # Query database
        cursor = await self.db.execute("""
            SELECT id, memory_id, version, value, changed_at, changed_by, 
                   change_reason, previous_version
            FROM memory_versions
            WHERE memory_id = ? AND version = ?
        """, (memory_id, version))
        
        row = await cursor.fetchone()
        
        if row:
            return self._row_to_version(row)
            
        return None
        
    async def get_all_versions(
        self,
        memory_id: str,
        limit: int = 50
    ) -> List[MemoryVersion]:
        """
        Get all versions of a memory, newest first.
        
        Args:
            memory_id: Memory ID
            limit: Maximum versions to return
            
        Returns:
            List of MemoryVersion objects
        """
        cursor = await self.db.execute("""
            SELECT id, memory_id, version, value, changed_at, changed_by, 
                   change_reason, previous_version
            FROM memory_versions
            WHERE memory_id = ?
            ORDER BY version DESC
            LIMIT ?
        """, (memory_id, limit))
        
        rows = await cursor.fetchall()
        
        return [self._row_to_version(row) for row in rows]
        
    async def get_history(self, memory_id: str, key: str = "") -> VersionHistory:
        """
        Get complete version history for a memory.
        
        Args:
            memory_id: Memory ID
            key: Memory key (for display)
            
        Returns:
            VersionHistory object
        """
        versions = await self.get_all_versions(memory_id)
        
        if not versions:
            return VersionHistory(
                memory_id=memory_id,
                key=key,
                current_version=0,
                versions=[],
                total_changes=0,
                first_created=datetime.utcnow(),
                last_modified=datetime.utcnow()
            )
            
        return VersionHistory(
            memory_id=memory_id,
            key=key,
            current_version=versions[0].version_number if versions else 0,
            versions=versions,
            total_changes=len(versions),
            first_created=versions[-1].changed_at if versions else datetime.utcnow(),
            last_modified=versions[0].changed_at if versions else datetime.utcnow()
        )
        
    async def get_diff(
        self,
        memory_id: str,
        from_version: int,
        to_version: int,
        key: str = ""
    ) -> Optional[VersionDiff]:
        """
        Get difference between two versions.
        
        Args:
            memory_id: Memory ID
            from_version: Starting version
            to_version: Ending version
            key: Memory key (for display)
            
        Returns:
            VersionDiff or None if versions not found
        """
        from_v = await self.get_version(memory_id, from_version)
        to_v = await self.get_version(memory_id, to_version)
        
        if not from_v or not to_v:
            return None
            
        self.stats['diffs_generated'] += 1
        
        return VersionDiff(
            memory_id=memory_id,
            key=key,
            from_version=from_version,
            to_version=to_version,
            old_value=from_v.value,
            new_value=to_v.value,
            change_reason=to_v.change_reason,
            changed_at=to_v.changed_at
        )
        
    async def rollback(
        self,
        memory_id: str,
        to_version: int,
        reason: str = "Manual rollback"
    ) -> Optional[MemoryVersion]:
        """
        Rollback a memory to a previous version.
        
        This creates a NEW version with the old value (doesn't delete versions).
        
        Args:
            memory_id: Memory ID
            to_version: Version to rollback to
            reason: Reason for rollback
            
        Returns:
            The new version after rollback
        """
        target_version = await self.get_version(memory_id, to_version)
        
        if not target_version:
            self.logger.error(f"Cannot rollback: version {to_version} not found")
            return None
            
        # Get current version number
        cursor = await self.db.execute("""
            SELECT MAX(version) FROM memory_versions WHERE memory_id = ?
        """, (memory_id,))
        row = await cursor.fetchone()
        current_version = row[0] if row and row[0] else 0
        
        # Create new version with old value
        new_version = await self.save_version(
            memory_id=memory_id,
            version=current_version + 1,
            value=target_version.value,
            reason=f"Rollback to v{to_version}: {reason}",
            changed_by=ChangeSource.CORRECTION
        )
        
        self.stats['rollbacks'] += 1
        self.logger.info(f"Rolled back {memory_id} to version {to_version}")
        
        return new_version
        
    async def get_changes_since(
        self,
        since: datetime,
        limit: int = 100
    ) -> List[MemoryVersion]:
        """
        Get all version changes since a timestamp.
        
        Args:
            since: Datetime to look back from
            limit: Maximum results
            
        Returns:
            List of versions changed since the timestamp
        """
        cursor = await self.db.execute("""
            SELECT id, memory_id, version, value, changed_at, changed_by, 
                   change_reason, previous_version
            FROM memory_versions
            WHERE changed_at > ?
            ORDER BY changed_at DESC
            LIMIT ?
        """, (since.isoformat(), limit))
        
        rows = await cursor.fetchall()
        
        return [self._row_to_version(row) for row in rows]
        
    async def get_changes_by_source(
        self,
        source: ChangeSource,
        limit: int = 50
    ) -> List[MemoryVersion]:
        """
        Get changes by source (agent, user, system, etc.).
        
        Args:
            source: Change source to filter
            limit: Maximum results
            
        Returns:
            List of versions from that source
        """
        cursor = await self.db.execute("""
            SELECT id, memory_id, version, value, changed_at, changed_by, 
                   change_reason, previous_version
            FROM memory_versions
            WHERE changed_by = ?
            ORDER BY changed_at DESC
            LIMIT ?
        """, (source.value, limit))
        
        rows = await cursor.fetchall()
        
        return [self._row_to_version(row) for row in rows]
        
    async def cleanup_old_versions(
        self,
        keep_versions: int = 10,
        older_than_days: int = 90
    ) -> int:
        """
        Clean up old versions to save space.
        
        Keeps at least `keep_versions` per memory and removes versions
        older than `older_than_days`.
        
        Args:
            keep_versions: Minimum versions to keep per memory
            older_than_days: Age threshold for deletion
            
        Returns:
            Number of versions deleted
        """
        cutoff = datetime.utcnow() - timedelta(days=older_than_days)
        
        # This is a complex operation - delete old versions but keep minimum
        # First, identify memories with more than keep_versions versions
        cursor = await self.db.execute("""
            SELECT memory_id, COUNT(*) as cnt 
            FROM memory_versions 
            GROUP BY memory_id 
            HAVING cnt > ?
        """, (keep_versions,))
        
        rows = await cursor.fetchall()
        
        deleted_count = 0
        
        for memory_id, count in rows:
            # Get versions to delete (oldest beyond keep_versions)
            to_delete = count - keep_versions
            
            if to_delete > 0:
                cursor = await self.db.execute("""
                    DELETE FROM memory_versions 
                    WHERE id IN (
                        SELECT id FROM memory_versions 
                        WHERE memory_id = ? AND changed_at < ?
                        ORDER BY version ASC
                        LIMIT ?
                    )
                """, (memory_id, cutoff.isoformat(), to_delete))
                
                deleted_count += cursor.rowcount
                
        await self.db.commit()
        
        if deleted_count > 0:
            self.logger.info(f"Cleaned up {deleted_count} old versions")
            
        return deleted_count
        
    def _row_to_version(self, row: tuple) -> MemoryVersion:
        """Convert database row to MemoryVersion."""
        return MemoryVersion(
            version_id=row[0],
            memory_id=row[1],
            version_number=row[2],
            value=json.loads(row[3]) if row[3] else None,
            changed_at=datetime.fromisoformat(row[4]) if row[4] else datetime.utcnow(),
            changed_by=ChangeSource(row[5]) if row[5] else ChangeSource.SYSTEM,
            change_reason=row[6] or "",
            previous_version=row[7]
        )
        
    def _update_cache(self, memory_id: str, version: MemoryVersion) -> None:
        """Update version cache."""
        if memory_id not in self._version_cache:
            self._version_cache[memory_id] = []
            
        self._version_cache[memory_id].insert(0, version)
        
        # Trim cache
        if len(self._version_cache[memory_id]) > self.cache_max_per_memory:
            self._version_cache[memory_id] = self._version_cache[memory_id][:self.cache_max_per_memory]
            
    def clear_cache(self) -> None:
        """Clear version cache."""
        self._version_cache.clear()
        
    def get_stats(self) -> Dict[str, Any]:
        """Get versioning statistics."""
        return {
            **self.stats,
            'cached_memories': len(self._version_cache),
        }