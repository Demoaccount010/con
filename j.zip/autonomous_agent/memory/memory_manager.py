#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 MEMORY MANAGER - CENTRAL MEMORY INTELLIGENCE
═══════════════════════════════════════════════════════════════════════════════

 The central coordinator for ALL memory operations.
 
 MEMORY PHILOSOPHY:
 ──────────────────
 • Memory is HINT, not ANSWER - always think fresh
 • Reality wins over memory when conflicts exist
 • All changes are VISIBLE with tags
 • Agent CAN rewrite memory when it believes correction is needed
 • Some memories are PERMANENT (owner details, identity)
 
 MEMORY TYPES:
 ─────────────
 • PERMANENT  - Never forgotten (owner, identity, core config)
 • FACT       - Verified information
 • SKILL      - Learned procedures
 • FAILURE    - What NOT to do
 • PREFERENCE - User preferences
 • EPISODE    - Events and experiences
 • RESEARCH   - Self-discovered knowledge
 • WORKING    - Current session only
 
 CRITICAL FEATURES:
 ──────────────────
 • Versioning - Track all changes
 • Tagging    - Visible memory operations
 • Rewriting  - Agent can overwrite with reason
 • Validation - Verify before storing
 • Decay      - Forget unimportant old memories
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import aiosqlite
import logging
import json
import hashlib
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Tuple, Union
from dataclasses import dataclass, field
from enum import Enum
from contextlib import asynccontextmanager

from memory.core_memory.memory_rewriter import MemoryRewriter, RewriteResult
from memory.core_memory.memory_tagger import MemoryTagger, MemoryTag
from memory.core_memory.memory_versioning import MemoryVersioning


class MemoryType(Enum):
    """Types of memory."""
    PERMANENT = "permanent"      # Never forgotten
    FACT = "fact"                # Verified facts
    SKILL = "skill"              # Procedures
    FAILURE = "failure"          # What not to do
    PREFERENCE = "preference"    # User preferences
    EPISODE = "episode"          # Events
    RESEARCH = "research"        # Self-discovered
    WORKING = "working"          # Current session
    CONVERSATION = "conversation"  # Chat history
    SYSTEM = "system"            # System config


class MemoryCategory(Enum):
    """Categories for organization."""
    OWNER = "owner"
    AGENT = "agent"
    SYSTEM = "system"
    TOOLS = "tools"
    TASKS = "tasks"
    KNOWLEDGE = "knowledge"
    GENERAL = "general"


@dataclass
class MemoryEntry:
    """A single memory entry."""
    id: str
    key: str
    value: Any
    memory_type: MemoryType
    category: str
    
    # Metadata
    confidence: float = 1.0
    source: str = "unknown"
    version: int = 1
    
    # Timestamps
    created_at: datetime = None
    updated_at: datetime = None
    accessed_at: datetime = None
    expires_at: datetime = None
    
    # Flags
    is_permanent: bool = False
    is_verified: bool = False
    is_hint_only: bool = True  # IMPORTANT: Default to hint
    
    # Tags for display
    tags: List[str] = field(default_factory=list)
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.utcnow()
        if self.updated_at is None:
            self.updated_at = self.created_at
        if self.accessed_at is None:
            self.accessed_at = self.created_at
            
    @property
    def age_days(self) -> int:
        """Age in days."""
        return (datetime.utcnow() - self.created_at).days
        
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'id': self.id,
            'key': self.key,
            'value': self.value,
            'memory_type': self.memory_type.value,
            'category': self.category,
            'confidence': self.confidence,
            'source': self.source,
            'version': self.version,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'is_permanent': self.is_permanent,
            'is_verified': self.is_verified,
            'is_hint_only': self.is_hint_only,
            'tags': self.tags,
        }


@dataclass
class MemorySearchResult:
    """Result from memory search."""
    entries: List[MemoryEntry]
    total_count: int
    query: str
    search_time_ms: int


@dataclass
class MemoryChange:
    """Represents a memory change for notification."""
    change_type: str  # saved, updated, deleted, overwritten, learned
    key: str
    old_value: Any = None
    new_value: Any = None
    reason: str = ""
    category: str = ""
    timestamp: datetime = field(default_factory=datetime.utcnow)


class MemoryManager:
    """
    ═══════════════════════════════════════════════════════════════════════════
    CENTRAL MEMORY COORDINATOR
    ═══════════════════════════════════════════════════════════════════════════
    
    Manages all memory operations with versioning, tagging, and validation.
    """
    
    # Schema version for migrations
    SCHEMA_VERSION = 1
    
    def __init__(self, db_path: Path, config: Dict[str, Any] = None):
        """
        Initialize memory manager.
        
        Args:
            db_path: Path to database directory
            config: Memory configuration
        """
        self.logger = logging.getLogger("memory.manager")
        self.db_path = Path(db_path)
        self.config = config or {}
        
        # Database paths
        self.db_path.mkdir(parents=True, exist_ok=True)
        self.main_db = self.db_path / "memory.db"
        self.permanent_db = self.db_path / "permanent.db"
        
        # Configuration
        self.max_entries = self.config.get('max_entries', 100000)
        self.decay_enabled = self.config.get('decay_enabled', True)
        self.decay_days = self.config.get('decay_days', 90)
        
        # Sub-components
        self.rewriter: Optional[MemoryRewriter] = None
        self.tagger: Optional[MemoryTagger] = None
        self.versioning: Optional[MemoryVersioning] = None
        
        # Database connections
        self._main_conn: Optional[aiosqlite.Connection] = None
        self._permanent_conn: Optional[aiosqlite.Connection] = None
        
        # Pending changes for notification
        self._pending_changes: List[MemoryChange] = []
        
        # Working memory (session only)
        self._working_memory: Dict[str, Any] = {}
        
        # Statistics
        self.total_entries = 0
        self.stats = {
            'reads': 0,
            'writes': 0,
            'updates': 0,
            'deletes': 0,
            'rewrites': 0,
            'cache_hits': 0,
        }
        
    async def initialize(self) -> None:
        """Initialize memory manager and create tables."""
        self.logger.info("Initializing memory manager...")
        
        # Connect to databases
        self._main_conn = await aiosqlite.connect(str(self.main_db))
        self._permanent_conn = await aiosqlite.connect(str(self.permanent_db))
        
        # Enable foreign keys and WAL mode
        await self._main_conn.execute("PRAGMA foreign_keys = ON")
        await self._main_conn.execute("PRAGMA journal_mode = WAL")
        await self._permanent_conn.execute("PRAGMA foreign_keys = ON")
        await self._permanent_conn.execute("PRAGMA journal_mode = WAL")
        
        # Create tables
        await self._create_tables()
        
        # Initialize sub-components
        self.tagger = MemoryTagger()
        await self.tagger.initialize()
        
        self.versioning = MemoryVersioning(self._main_conn)
        await self.versioning.initialize()
        
        self.rewriter = MemoryRewriter(
            memory_manager=self,
            tagger=self.tagger,
            versioning=self.versioning
        )
        await self.rewriter.initialize()
        
        # Count entries
        self.total_entries = await self.get_entry_count()
        
        self.logger.info(f"Memory manager initialized ({self.total_entries} entries)")
        
    async def _create_tables(self) -> None:
        """Create database tables."""
        # Main memory table
        await self._main_conn.execute("""
            CREATE TABLE IF NOT EXISTS memories (
                id TEXT PRIMARY KEY,
                key TEXT NOT NULL,
                value TEXT NOT NULL,
                memory_type TEXT NOT NULL,
                category TEXT DEFAULT 'general',
                confidence REAL DEFAULT 1.0,
                source TEXT DEFAULT 'unknown',
                version INTEGER DEFAULT 1,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                accessed_at TEXT NOT NULL,
                expires_at TEXT,
                is_permanent INTEGER DEFAULT 0,
                is_verified INTEGER DEFAULT 0,
                is_hint_only INTEGER DEFAULT 1,
                tags TEXT DEFAULT '[]',
                metadata TEXT DEFAULT '{}',
                UNIQUE(key, category)
            )
        """)
        
        # Index for fast lookups
        await self._main_conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_memories_key ON memories(key)
        """)
        await self._main_conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_memories_type ON memories(memory_type)
        """)
        await self._main_conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_memories_category ON memories(category)
        """)
        
        # Version history table
        await self._main_conn.execute("""
            CREATE TABLE IF NOT EXISTS memory_versions (
                id TEXT PRIMARY KEY,
                memory_id TEXT NOT NULL,
                version INTEGER NOT NULL,
                value TEXT NOT NULL,
                changed_at TEXT NOT NULL,
                change_reason TEXT,
                changed_by TEXT DEFAULT 'system',
                FOREIGN KEY(memory_id) REFERENCES memories(id) ON DELETE CASCADE
            )
        """)
        
        # Permanent memory table (separate DB)
        await self._permanent_conn.execute("""
            CREATE TABLE IF NOT EXISTS permanent (
                id TEXT PRIMARY KEY,
                key TEXT NOT NULL UNIQUE,
                value TEXT NOT NULL,
                category TEXT DEFAULT 'general',
                source TEXT DEFAULT 'owner',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                never_expires INTEGER DEFAULT 1,
                metadata TEXT DEFAULT '{}'
            )
        """)
        
        await self._main_conn.commit()
        await self._permanent_conn.commit()
        
    # ═══════════════════════════════════════════════════════════════════════════
    # CORE MEMORY OPERATIONS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def store(
        self,
        key: str,
        value: Any,
        memory_type: MemoryType = MemoryType.FACT,
        category: str = "general",
        confidence: float = 1.0,
        source: str = "agent",
        is_verified: bool = False,
        expires_in_days: int = None,
        metadata: Dict[str, Any] = None
    ) -> Tuple[MemoryEntry, MemoryTag]:
        """
        Store a memory entry.
        
        Args:
            key: Unique key for the memory
            value: Value to store
            memory_type: Type of memory
            category: Category for organization
            confidence: Confidence level (0-1)
            source: Where this information came from
            is_verified: Whether the value has been verified
            expires_in_days: Optional expiration
            metadata: Additional metadata
            
        Returns:
            Tuple of (MemoryEntry, MemoryTag) for display
        """
        self.stats['writes'] += 1
        
        # Check if exists
        existing = await self.get(key, category)
        
        if existing:
            # Update existing - this is an overwrite
            return await self.update(
                key=key,
                value=value,
                category=category,
                reason="Updated via store()",
                source=source
            )
            
        # Create new entry
        entry_id = self._generate_id(key, category)
        now = datetime.utcnow()
        
        expires_at = None
        if expires_in_days:
            expires_at = now + timedelta(days=expires_in_days)
            
        entry = MemoryEntry(
            id=entry_id,
            key=key,
            value=value,
            memory_type=memory_type,
            category=category,
            confidence=confidence,
            source=source,
            version=1,
            created_at=now,
            updated_at=now,
            accessed_at=now,
            expires_at=expires_at,
            is_permanent=memory_type == MemoryType.PERMANENT,
            is_verified=is_verified,
            is_hint_only=True,
            tags=[]
        )
        
        # Serialize value
        value_json = json.dumps(value, default=str)
        metadata_json = json.dumps(metadata or {})
        
        # Insert
        await self._main_conn.execute("""
            INSERT INTO memories (
                id, key, value, memory_type, category, confidence, source,
                version, created_at, updated_at, accessed_at, expires_at,
                is_permanent, is_verified, is_hint_only, tags, metadata
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            entry.id, entry.key, value_json, memory_type.value, category,
            confidence, source, 1, now.isoformat(), now.isoformat(),
            now.isoformat(), expires_at.isoformat() if expires_at else None,
            int(entry.is_permanent), int(is_verified), 1, '[]', metadata_json
        ))
        
        await self._main_conn.commit()
        self.total_entries += 1
        
        # Generate tag
        tag = self.tagger.create_tag(MemoryTag.SAVED, key, value)
        entry.tags.append(tag.tag_type.value)
        
        # Record change
        self._pending_changes.append(MemoryChange(
            change_type='saved',
            key=key,
            new_value=value,
            category=category
        ))
        
        self.logger.debug(f"Memory saved: {key} = {str(value)[:50]}...")
        
        return entry, tag
        
    async def store_permanent(
        self,
        key: str,
        value: Any,
        category: str = "general",
        source: str = "owner"
    ) -> Tuple[MemoryEntry, MemoryTag]:
        """
        Store a PERMANENT memory (never expires, never forgotten).
        
        Use for: owner details, agent identity, core configuration
        """
        self.stats['writes'] += 1
        
        now = datetime.utcnow()
        value_json = json.dumps(value, default=str)
        
        # Check if exists
        cursor = await self._permanent_conn.execute(
            "SELECT value FROM permanent WHERE key = ?", (key,)
        )
        existing = await cursor.fetchone()
        
        if existing:
            old_value = json.loads(existing[0])
            # Update
            await self._permanent_conn.execute("""
                UPDATE permanent SET value = ?, updated_at = ? WHERE key = ?
            """, (value_json, now.isoformat(), key))
            
            tag = self.tagger.create_tag(MemoryTag.PERMANENT, key, value, old_value)
            change_type = 'updated'
        else:
            # Insert
            entry_id = self._generate_id(key, "permanent")
            await self._permanent_conn.execute("""
                INSERT INTO permanent (id, key, value, category, source, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (entry_id, key, value_json, category, source, now.isoformat(), now.isoformat()))
            
            tag = self.tagger.create_tag(MemoryTag.PERMANENT, key, value)
            change_type = 'saved'
            old_value = None
            
        await self._permanent_conn.commit()
        
        # Create entry object
        entry = MemoryEntry(
            id=self._generate_id(key, "permanent"),
            key=key,
            value=value,
            memory_type=MemoryType.PERMANENT,
            category=category,
            confidence=1.0,
            source=source,
            is_permanent=True,
            is_verified=True,
            is_hint_only=False  # Permanent memories are trusted
        )
        
        # Record change
        self._pending_changes.append(MemoryChange(
            change_type=change_type,
            key=key,
            old_value=old_value if existing else None,
            new_value=value,
            category="permanent"
        ))
        
        self.logger.info(f"Permanent memory stored: {key}")
        
        return entry, tag
        
    async def get(
        self,
        key: str,
        category: str = None,
        include_expired: bool = False
    ) -> Optional[MemoryEntry]:
        """
        Get a memory entry by key.
        
        Args:
            key: Memory key
            category: Optional category filter
            include_expired: Include expired entries
            
        Returns:
            MemoryEntry or None
        """
        self.stats['reads'] += 1
        
        # Check working memory first
        working_key = f"{category or 'general'}:{key}"
        if working_key in self._working_memory:
            self.stats['cache_hits'] += 1
            return self._working_memory[working_key]
            
        # Check permanent memory
        cursor = await self._permanent_conn.execute(
            "SELECT * FROM permanent WHERE key = ?", (key,)
        )
        row = await cursor.fetchone()
        
        if row:
            return self._row_to_entry_permanent(row)
            
        # Check main memory
        query = "SELECT * FROM memories WHERE key = ?"
        params = [key]
        
        if category:
            query += " AND category = ?"
            params.append(category)
            
        if not include_expired:
            query += " AND (expires_at IS NULL OR expires_at > ?)"
            params.append(datetime.utcnow().isoformat())
            
        cursor = await self._main_conn.execute(query, params)
        row = await cursor.fetchone()
        
        if row:
            entry = self._row_to_entry(row)
            # Update accessed time
            await self._update_accessed(entry.id)
            return entry
            
        return None
        
    async def get_permanent(self, key: str) -> Optional[Any]:
        """Get a permanent memory value directly."""
        cursor = await self._permanent_conn.execute(
            "SELECT value FROM permanent WHERE key = ?", (key,)
        )
        row = await cursor.fetchone()
        
        if row:
            return json.loads(row[0])
        return None
        
    async def update(
        self,
        key: str,
        value: Any,
        category: str = None,
        reason: str = "",
        source: str = "agent"
    ) -> Tuple[MemoryEntry, MemoryTag]:
        """
        Update an existing memory.
        
        Creates a new version and notifies with [MEMORY UPDATED] tag.
        """
        self.stats['updates'] += 1
        
        # Get existing
        existing = await self.get(key, category)
        
        if not existing:
            # Doesn't exist - create new
            return await self.store(key, value, category=category or "general", source=source)
            
        old_value = existing.value
        now = datetime.utcnow()
        
        # Store version history
        await self.versioning.save_version(
            memory_id=existing.id,
            version=existing.version,
            value=old_value,
            reason=reason
        )
        
        # Update entry
        new_version = existing.version + 1
        value_json = json.dumps(value, default=str)
        
        await self._main_conn.execute("""
            UPDATE memories 
            SET value = ?, version = ?, updated_at = ?, source = ?
            WHERE id = ?
        """, (value_json, new_version, now.isoformat(), source, existing.id))
        
        await self._main_conn.commit()
        
        # Create updated entry
        existing.value = value
        existing.version = new_version
        existing.updated_at = now
        existing.source = source
        
        # Generate tag
        tag = self.tagger.create_tag(MemoryTag.UPDATED, key, value, old_value, reason)
        
        # Record change
        self._pending_changes.append(MemoryChange(
            change_type='updated',
            key=key,
            old_value=old_value,
            new_value=value,
            reason=reason,
            category=category or existing.category
        ))
        
        self.logger.info(f"Memory updated: {key} (v{new_version})")
        
        return existing, tag
        
    async def delete(
        self,
        key: str,
        category: str = None,
        reason: str = ""
    ) -> Optional[MemoryTag]:
        """Delete a memory entry."""
        self.stats['deletes'] += 1
        
        existing = await self.get(key, category)
        
        if not existing:
            return None
            
        if existing.is_permanent:
            self.logger.warning(f"Cannot delete permanent memory: {key}")
            return None
            
        # Archive before delete
        await self.versioning.save_version(
            memory_id=existing.id,
            version=existing.version,
            value=existing.value,
            reason=f"Deleted: {reason}"
        )
        
        # Delete
        await self._main_conn.execute(
            "DELETE FROM memories WHERE id = ?", (existing.id,)
        )
        await self._main_conn.commit()
        
        self.total_entries -= 1
        
        # Generate tag
        tag = self.tagger.create_tag(MemoryTag.ARCHIVED, key, reason=reason)
        
        # Record change
        self._pending_changes.append(MemoryChange(
            change_type='deleted',
            key=key,
            old_value=existing.value,
            reason=reason
        ))
        
        self.logger.info(f"Memory deleted: {key}")
        
        return tag
        
    # ═══════════════════════════════════════════════════════════════════════════
    # AGENT MEMORY REWRITE - CRITICAL FEATURE
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def agent_rewrite(
        self,
        key: str,
        new_value: Any,
        reason: str,
        category: str = None
    ) -> RewriteResult:
        """
        Agent decides to rewrite a memory.
        
        This is when the agent believes the stored memory is WRONG
        and wants to correct it. Always visible with [MEMORY OVERWRITTEN] tag.
        
        Args:
            key: Memory key to rewrite
            new_value: New value
            reason: Why the agent is rewriting
            category: Memory category
            
        Returns:
            RewriteResult with details and tag
        """
        self.stats['rewrites'] += 1
        
        return await self.rewriter.rewrite(
            key=key,
            new_value=new_value,
            reason=reason,
            category=category
        )
        
    # ═══════════════════════════════════════════════════════════════════════════
    # SEARCH AND RETRIEVAL
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def search(
        self,
        query: str,
        memory_type: MemoryType = None,
        category: str = None,
        limit: int = 10
    ) -> List[MemoryEntry]:
        """Search memories by keyword."""
        import time
        start = time.perf_counter()
        
        sql = "SELECT * FROM memories WHERE 1=1"
        params = []
        
        if query:
            sql += " AND (key LIKE ? OR value LIKE ?)"
            params.extend([f"%{query}%", f"%{query}%"])
            
        if memory_type:
            sql += " AND memory_type = ?"
            params.append(memory_type.value)
            
        if category:
            sql += " AND category = ?"
            params.append(category)
            
        sql += " AND (expires_at IS NULL OR expires_at > ?)"
        params.append(datetime.utcnow().isoformat())
        
        sql += " ORDER BY updated_at DESC LIMIT ?"
        params.append(limit)
        
        cursor = await self._main_conn.execute(sql, params)
        rows = await cursor.fetchall()
        
        entries = [self._row_to_entry(row) for row in rows]
        
        return entries
        
    async def search_facts(self, query: str, limit: int = 5) -> List[MemoryEntry]:
        """Search fact memories."""
        return await self.search(query, MemoryType.FACT, limit=limit)
        
    async def search_skills(self, query: str, limit: int = 5) -> List[MemoryEntry]:
        """Search skill memories."""
        return await self.search(query, MemoryType.SKILL, limit=limit)
        
    async def get_by_category(
        self,
        category: str,
        limit: int = 50
    ) -> List[MemoryEntry]:
        """Get all memories in a category."""
        cursor = await self._main_conn.execute("""
            SELECT * FROM memories 
            WHERE category = ? AND (expires_at IS NULL OR expires_at > ?)
            ORDER BY updated_at DESC LIMIT ?
        """, (category, datetime.utcnow().isoformat(), limit))
        
        rows = await cursor.fetchall()
        return [self._row_to_entry(row) for row in rows]
        
    async def get_by_type(
        self,
        memory_type: MemoryType,
        limit: int = 50
    ) -> List[MemoryEntry]:
        """Get all memories of a type."""
        cursor = await self._main_conn.execute("""
            SELECT * FROM memories 
            WHERE memory_type = ? AND (expires_at IS NULL OR expires_at > ?)
            ORDER BY updated_at DESC LIMIT ?
        """, (memory_type.value, datetime.utcnow().isoformat(), limit))
        
        rows = await cursor.fetchall()
        return [self._row_to_entry(row) for row in rows]
        
    async def get_recent_failures(self, limit: int = 10) -> List[MemoryEntry]:
        """Get recent failure memories."""
        return await self.get_by_type(MemoryType.FAILURE, limit)
        
    async def get_preferences(self) -> Dict[str, Any]:
        """Get all user preferences."""
        entries = await self.get_by_type(MemoryType.PREFERENCE, limit=100)
        return {e.key: e.value for e in entries}
        
    async def get_facts(self, category: str = None) -> List[MemoryEntry]:
        """Get all facts, optionally by category."""
        if category:
            return await self.search("", MemoryType.FACT, category)
        return await self.get_by_type(MemoryType.FACT)
        
    async def get_skills(self, task_type: str = None) -> List[MemoryEntry]:
        """Get learned skills."""
        if task_type:
            return await self.search(task_type, MemoryType.SKILL)
        return await self.get_by_type(MemoryType.SKILL)
        
    # ═══════════════════════════════════════════════════════════════════════════
    # WORKING MEMORY (SESSION ONLY)
    # ═══════════════════════════════════════════════════════════════════════════
    
    def set_working(self, key: str, value: Any) -> None:
        """Set working memory (current session only)."""
        self._working_memory[key] = value
        
    def get_working(self, key: str) -> Optional[Any]:
        """Get working memory."""
        return self._working_memory.get(key)
        
    def clear_working(self) -> None:
        """Clear all working memory."""
        self._working_memory.clear()
        
    # ═══════════════════════════════════════════════════════════════════════════
    # MEMORY HINTS SYSTEM
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def get_hints(
        self,
        query: str,
        include_facts: bool = True,
        include_skills: bool = True,
        include_failures: bool = True,
        limit: int = 10
    ) -> Dict[str, List[Dict[str, Any]]]:
        """
        Get memory HINTS (not answers!) for a query.
        
        These are meant to guide thinking, not provide direct answers.
        """
        hints = {
            '_note': 'USE AS HINTS ONLY - VERIFY BEFORE TRUSTING',
            'facts': [],
            'skills': [],
            'failures': [],
            'preferences': []
        }
        
        if include_facts:
            facts = await self.search_facts(query, limit)
            hints['facts'] = [
                {
                    'key': f.key,
                    'value': f.value,
                    'confidence': f.confidence,
                    'age_days': f.age_days,
                    'is_hint': True
                }
                for f in facts
            ]
            
        if include_skills:
            skills = await self.search_skills(query, limit)
            hints['skills'] = [
                {
                    'name': s.key,
                    'procedure': s.value,
                    'is_hint': True
                }
                for s in skills
            ]
            
        if include_failures:
            failures = await self.get_recent_failures(limit=5)
            hints['failures'] = [
                {
                    'action': f.key,
                    'reason': f.value,
                    'avoid': True
                }
                for f in failures
            ]
            
        # Always include preferences
        prefs = await self.get_preferences()
        hints['preferences'] = prefs
        
        return hints
        
    # ═══════════════════════════════════════════════════════════════════════════
    # VERIFICATION AND CONFLICT RESOLUTION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def verify_against_reality(
        self,
        key: str,
        actual_value: Any,
        category: str = None
    ) -> Tuple[bool, Optional[MemoryTag]]:
        """
        Verify memory against reality.
        
        If conflict found, REALITY WINS and memory is updated.
        """
        existing = await self.get(key, category)
        
        if not existing:
            # No memory - store the reality
            entry, tag = await self.store(
                key, actual_value, MemoryType.FACT, 
                category or "general", is_verified=True
            )
            return True, tag
            
        # Compare
        if existing.value == actual_value:
            # Memory matches reality - mark as verified
            await self._mark_verified(existing.id)
            tag = self.tagger.create_tag(MemoryTag.VERIFIED, key, actual_value)
            return True, tag
        else:
            # CONFLICT! Reality wins
            self.logger.warning(
                f"Memory conflict for {key}: memory={existing.value}, reality={actual_value}"
            )
            
            # Record conflict
            conflict_tag = self.tagger.create_tag(
                MemoryTag.CONFLICT, key, actual_value, existing.value
            )
            
            # Update to reality
            result = await self.agent_rewrite(
                key=key,
                new_value=actual_value,
                reason=f"Reality check: memory was {existing.value}, actual is {actual_value}",
                category=category or existing.category
            )
            
            return False, result.tag
            
    async def _mark_verified(self, memory_id: str) -> None:
        """Mark a memory as verified."""
        now = datetime.utcnow()
        await self._main_conn.execute("""
            UPDATE memories SET is_verified = 1, accessed_at = ? WHERE id = ?
        """, (now.isoformat(), memory_id))
        await self._main_conn.commit()
        
    # ═══════════════════════════════════════════════════════════════════════════
    # CHANGE TRACKING
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_pending_changes(self) -> List[Dict[str, Any]]:
        """Get pending memory changes for notification."""
        changes = []
        for change in self._pending_changes:
            changes.append({
                'type': change.change_type.upper(),
                'key': change.key,
                'old_value': change.old_value,
                'new_value': change.new_value,
                'reason': change.reason,
                'category': change.category,
                'timestamp': change.timestamp.isoformat()
            })
        return changes
        
    def clear_pending_changes(self) -> None:
        """Clear pending changes after they've been processed."""
        self._pending_changes.clear()
        
    # ═══════════════════════════════════════════════════════════════════════════
    # STATISTICS AND MAINTENANCE
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def get_entry_count(self) -> int:
        """Get total number of entries."""
        cursor = await self._main_conn.execute("SELECT COUNT(*) FROM memories")
        row = await cursor.fetchone()
        main_count = row[0] if row else 0
        
        cursor = await self._permanent_conn.execute("SELECT COUNT(*) FROM permanent")
        row = await cursor.fetchone()
        permanent_count = row[0] if row else 0
        
        return main_count + permanent_count
        
    async def get_stats(self) -> Dict[str, Any]:
        """Get memory statistics."""
        # Count by type
        cursor = await self._main_conn.execute("""
            SELECT memory_type, COUNT(*) FROM memories GROUP BY memory_type
        """)
        type_counts = dict(await cursor.fetchall())
        
        # Count by category
        cursor = await self._main_conn.execute("""
            SELECT category, COUNT(*) FROM memories GROUP BY category
        """)
        category_counts = dict(await cursor.fetchall())
        
        # Permanent count
        cursor = await self._permanent_conn.execute("SELECT COUNT(*) FROM permanent")
        permanent_count = (await cursor.fetchone())[0]
        
        return {
            'total_entries': await self.get_entry_count(),
            'permanent_entries': permanent_count,
            'by_type': type_counts,
            'by_category': category_counts,
            'working_memory_size': len(self._working_memory),
            'operations': self.stats,
        }
        
    async def decay_old_memories(self) -> int:
        """Remove old, unimportant memories."""
        if not self.decay_enabled:
            return 0
            
        cutoff = datetime.utcnow() - timedelta(days=self.decay_days)
        
        # Don't decay permanent, verified, or high-confidence memories
        cursor = await self._main_conn.execute("""
            DELETE FROM memories 
            WHERE is_permanent = 0 
            AND is_verified = 0 
            AND confidence < 0.8
            AND accessed_at < ?
            AND memory_type NOT IN ('permanent', 'preference')
        """, (cutoff.isoformat(),))
        
        deleted = cursor.rowcount
        await self._main_conn.commit()
        
        if deleted > 0:
            self.total_entries -= deleted
            self.logger.info(f"Decayed {deleted} old memories")
            
        return deleted
        
    async def ping(self) -> bool:
        """Check if memory system is working."""
        try:
            cursor = await self._main_conn.execute("SELECT 1")
            await cursor.fetchone()
            return True
        except:
            return False
            
    # ═══════════════════════════════════════════════════════════════════════════
    # HELPER METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _generate_id(self, key: str, category: str) -> str:
        """Generate unique ID for a memory."""
        content = f"{key}:{category}:{datetime.utcnow().isoformat()}"
        return hashlib.sha256(content.encode()).hexdigest()[:16]
        
    def _row_to_entry(self, row: tuple) -> MemoryEntry:
        """Convert database row to MemoryEntry."""
        return MemoryEntry(
            id=row[0],
            key=row[1],
            value=json.loads(row[2]),
            memory_type=MemoryType(row[3]),
            category=row[4],
            confidence=row[5],
            source=row[6],
            version=row[7],
            created_at=datetime.fromisoformat(row[8]) if row[8] else None,
            updated_at=datetime.fromisoformat(row[9]) if row[9] else None,
            accessed_at=datetime.fromisoformat(row[10]) if row[10] else None,
            expires_at=datetime.fromisoformat(row[11]) if row[11] else None,
            is_permanent=bool(row[12]),
            is_verified=bool(row[13]),
            is_hint_only=bool(row[14]),
            tags=json.loads(row[15]) if row[15] else []
        )
        
    def _row_to_entry_permanent(self, row: tuple) -> MemoryEntry:
        """Convert permanent database row to MemoryEntry."""
        return MemoryEntry(
            id=row[0],
            key=row[1],
            value=json.loads(row[2]),
            memory_type=MemoryType.PERMANENT,
            category=row[3],
            confidence=1.0,
            source=row[4],
            version=1,
            created_at=datetime.fromisoformat(row[5]) if row[5] else None,
            updated_at=datetime.fromisoformat(row[6]) if row[6] else None,
            is_permanent=True,
            is_verified=True,
            is_hint_only=False
        )
        
    async def _update_accessed(self, memory_id: str) -> None:
        """Update last accessed time."""
        now = datetime.utcnow()
        await self._main_conn.execute(
            "UPDATE memories SET accessed_at = ? WHERE id = ?",
            (now.isoformat(), memory_id)
        )
        # Don't commit for every access - batch these
        
    async def close(self) -> None:
        """Close database connections."""
        if self._main_conn:
            await self._main_conn.close()
        if self._permanent_conn:
            await self._permanent_conn.close()
        self.logger.info("Memory manager closed")