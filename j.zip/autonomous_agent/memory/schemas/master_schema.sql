-- ═══════════════════════════════════════════════════════════════════════════════
--  MASTER MEMORY SCHEMA - Core database structure for all memory types
-- ═══════════════════════════════════════════════════════════════════════════════
--
--  This schema defines the complete database structure for the memory system.
--
--  TABLES:
--  ───────
--  • memories          - Main memory storage
--  • memory_versions   - Version history for all memories
--  • memory_tags       - Tags and categorization
--  • memory_relations  - Relationships between memories
--  • memory_access_log - Access tracking
--  • memory_conflicts  - Conflict resolution history
--  • memory_index      - Full-text search index
--
--  Version: 3.0.0
-- ═══════════════════════════════════════════════════════════════════════════════

-- Enable foreign keys
PRAGMA foreign_keys = ON;

-- Enable WAL mode for better concurrency
PRAGMA journal_mode = WAL;

-- ═══════════════════════════════════════════════════════════════════════════════
--                          MAIN MEMORIES TABLE
-- ═══════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS memories (
    -- Primary identification
    id TEXT PRIMARY KEY,
    key TEXT NOT NULL,                          -- Unique key within type
    
    -- Memory classification
    memory_type TEXT NOT NULL,                  -- fact, skill, preference, failure, episode, research, working, system
    category TEXT,                              -- Sub-category
    
    -- Content
    value TEXT NOT NULL,                        -- JSON-encoded value
    value_type TEXT DEFAULT 'string',           -- string, json, number, boolean, list
    summary TEXT,                               -- Short summary for quick retrieval
    
    -- Metadata
    source TEXT DEFAULT 'user',                 -- user, system, research, inference, tool
    confidence REAL DEFAULT 1.0,                -- 0.0 to 1.0
    importance REAL DEFAULT 0.5,                -- 0.0 to 1.0 (affects decay)
    
    -- Versioning
    version INTEGER DEFAULT 1,
    previous_version_id TEXT,                   -- Link to previous version
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    accessed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP,                       -- NULL = never expires
    
    -- Status
    is_active INTEGER DEFAULT 1,                -- 1 = active, 0 = archived
    is_verified INTEGER DEFAULT 0,              -- 1 = verified against reality
    is_permanent INTEGER DEFAULT 0,             -- 1 = never delete/decay
    
    -- Access tracking
    access_count INTEGER DEFAULT 0,
    last_used_in_task TEXT,                     -- Task ID where last used
    
    -- Relationships
    parent_id TEXT,                             -- Parent memory (for hierarchies)
    
    -- Constraints
    UNIQUE(memory_type, key),
    FOREIGN KEY (previous_version_id) REFERENCES memories(id),
    FOREIGN KEY (parent_id) REFERENCES memories(id)
);

-- Indexes for fast retrieval
CREATE INDEX IF NOT EXISTS idx_memories_type ON memories(memory_type);
CREATE INDEX IF NOT EXISTS idx_memories_key ON memories(key);
CREATE INDEX IF NOT EXISTS idx_memories_type_key ON memories(memory_type, key);
CREATE INDEX IF NOT EXISTS idx_memories_category ON memories(category);
CREATE INDEX IF NOT EXISTS idx_memories_active ON memories(is_active);
CREATE INDEX IF NOT EXISTS idx_memories_permanent ON memories(is_permanent);
CREATE INDEX IF NOT EXISTS idx_memories_accessed ON memories(accessed_at);
CREATE INDEX IF NOT EXISTS idx_memories_importance ON memories(importance DESC);
CREATE INDEX IF NOT EXISTS idx_memories_confidence ON memories(confidence DESC);

-- ═══════════════════════════════════════════════════════════════════════════════
--                          VERSION HISTORY TABLE
-- ═══════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS memory_versions (
    id TEXT PRIMARY KEY,
    memory_id TEXT NOT NULL,                    -- Reference to current memory
    
    -- Version info
    version INTEGER NOT NULL,
    
    -- Snapshot of values at this version
    key TEXT NOT NULL,
    value TEXT NOT NULL,
    value_type TEXT,
    memory_type TEXT NOT NULL,
    confidence REAL,
    
    -- Change tracking
    change_type TEXT NOT NULL,                  -- created, updated, overwritten, deleted, restored
    change_reason TEXT,                         -- Why the change was made
    changed_by TEXT DEFAULT 'system',           -- user, system, agent, research
    
    -- What triggered the change
    trigger_source TEXT,                        -- user_input, tool_result, verification, conflict_resolution
    trigger_context TEXT,                       -- JSON with context details
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- For rollback support
    is_rollback_point INTEGER DEFAULT 0,        -- 1 = can rollback to this version
    
    FOREIGN KEY (memory_id) REFERENCES memories(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_versions_memory ON memory_versions(memory_id);
CREATE INDEX IF NOT EXISTS idx_versions_version ON memory_versions(memory_id, version);
CREATE INDEX IF NOT EXISTS idx_versions_type ON memory_versions(change_type);
CREATE INDEX IF NOT EXISTS idx_versions_created ON memory_versions(created_at);

-- ═══════════════════════════════════════════════════════════════════════════════
--                          TAGS TABLE
-- ═══════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS memory_tags (
    id TEXT PRIMARY KEY,
    memory_id TEXT NOT NULL,
    tag TEXT NOT NULL,
    
    -- Tag metadata
    tag_type TEXT DEFAULT 'user',               -- user, system, auto
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(memory_id, tag),
    FOREIGN KEY (memory_id) REFERENCES memories(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_tags_memory ON memory_tags(memory_id);
CREATE INDEX IF NOT EXISTS idx_tags_tag ON memory_tags(tag);

-- ═══════════════════════════════════════════════════════════════════════════════
--                          RELATIONS TABLE
-- ═══════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS memory_relations (
    id TEXT PRIMARY KEY,
    source_id TEXT NOT NULL,                    -- Source memory
    target_id TEXT NOT NULL,                    -- Target memory
    
    -- Relationship type
    relation_type TEXT NOT NULL,                -- related_to, derived_from, contradicts, supports, obsoletes
    
    -- Relationship strength
    strength REAL DEFAULT 1.0,                  -- 0.0 to 1.0
    
    -- Bidirectional?
    is_bidirectional INTEGER DEFAULT 0,
    
    -- Metadata
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by TEXT DEFAULT 'system',
    
    UNIQUE(source_id, target_id, relation_type),
    FOREIGN KEY (source_id) REFERENCES memories(id) ON DELETE CASCADE,
    FOREIGN KEY (target_id) REFERENCES memories(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_relations_source ON memory_relations(source_id);
CREATE INDEX IF NOT EXISTS idx_relations_target ON memory_relations(target_id);
CREATE INDEX IF NOT EXISTS idx_relations_type ON memory_relations(relation_type);

-- ═══════════════════════════════════════════════════════════════════════════════
--                          ACCESS LOG TABLE
-- ═══════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS memory_access_log (
    id TEXT PRIMARY KEY,
    memory_id TEXT NOT NULL,
    
    -- Access details
    access_type TEXT NOT NULL,                  -- read, write, update, delete, hint
    access_context TEXT,                        -- What the access was for
    
    -- Who/what accessed
    accessor TEXT DEFAULT 'agent',              -- agent, user, system, tool
    task_id TEXT,                               -- Task that triggered access
    
    -- Result
    was_useful INTEGER,                         -- 1 = contributed to result, 0 = not used
    
    -- Timestamp
    accessed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (memory_id) REFERENCES memories(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_access_memory ON memory_access_log(memory_id);
CREATE INDEX IF NOT EXISTS idx_access_time ON memory_access_log(accessed_at);
CREATE INDEX IF NOT EXISTS idx_access_type ON memory_access_log(access_type);

-- ═══════════════════════════════════════════════════════════════════════════════
--                          CONFLICTS TABLE
-- ═══════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS memory_conflicts (
    id TEXT PRIMARY KEY,
    memory_id TEXT NOT NULL,
    
    -- Conflict details
    memory_value TEXT NOT NULL,                 -- What memory said
    reality_value TEXT NOT NULL,                -- What reality showed
    
    -- Resolution
    resolution TEXT NOT NULL,                   -- reality_wins, memory_kept, merged, asked_user
    resolution_reason TEXT,
    
    -- Source of conflict detection
    detected_by TEXT,                           -- verification_chain, tool_result, user_correction
    detection_context TEXT,                     -- JSON with context
    
    -- Timestamps
    detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP,
    
    -- Was user notified?
    user_notified INTEGER DEFAULT 0,
    
    FOREIGN KEY (memory_id) REFERENCES memories(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_conflicts_memory ON memory_conflicts(memory_id);
CREATE INDEX IF NOT EXISTS idx_conflicts_time ON memory_conflicts(detected_at);

-- ═══════════════════════════════════════════════════════════════════════════════
--                          FULL-TEXT SEARCH INDEX
-- ═══════════════════════════════════════════════════════════════════════════════

-- FTS5 virtual table for full-text search
CREATE VIRTUAL TABLE IF NOT EXISTS memory_fts USING fts5(
    memory_id,
    key,
    value,
    summary,
    category,
    tags,
    content='memories',
    content_rowid='rowid'
);

-- Triggers to keep FTS in sync
CREATE TRIGGER IF NOT EXISTS memory_fts_insert AFTER INSERT ON memories BEGIN
    INSERT INTO memory_fts(memory_id, key, value, summary, category, tags)
    VALUES (NEW.id, NEW.key, NEW.value, NEW.summary, NEW.category, '');
END;

CREATE TRIGGER IF NOT EXISTS memory_fts_update AFTER UPDATE ON memories BEGIN
    UPDATE memory_fts SET
        key = NEW.key,
        value = NEW.value,
        summary = NEW.summary,
        category = NEW.category
    WHERE memory_id = NEW.id;
END;

CREATE TRIGGER IF NOT EXISTS memory_fts_delete AFTER DELETE ON memories BEGIN
    DELETE FROM memory_fts WHERE memory_id = OLD.id;
END;

-- ═══════════════════════════════════════════════════════════════════════════════
--                          EMBEDDINGS TABLE (Future: Vector Search)
-- ═══════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS memory_embeddings (
    id TEXT PRIMARY KEY,
    memory_id TEXT NOT NULL UNIQUE,
    
    -- Embedding vector (stored as JSON array or blob)
    embedding BLOB,                             -- Binary embedding data
    embedding_model TEXT,                       -- Model used to generate
    embedding_dim INTEGER,                      -- Dimension of embedding
    
    -- Metadata
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (memory_id) REFERENCES memories(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_embeddings_memory ON memory_embeddings(memory_id);

-- ═══════════════════════════════════════════════════════════════════════════════
--                          STATISTICS TABLE
-- ═══════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS memory_stats (
    id TEXT PRIMARY KEY,
    stat_date DATE NOT NULL,
    
    -- Counts by type
    total_memories INTEGER DEFAULT 0,
    facts_count INTEGER DEFAULT 0,
    skills_count INTEGER DEFAULT 0,
    preferences_count INTEGER DEFAULT 0,
    failures_count INTEGER DEFAULT 0,
    episodes_count INTEGER DEFAULT 0,
    research_count INTEGER DEFAULT 0,
    
    -- Activity
    reads_today INTEGER DEFAULT 0,
    writes_today INTEGER DEFAULT 0,
    updates_today INTEGER DEFAULT 0,
    conflicts_today INTEGER DEFAULT 0,
    
    -- Performance
    avg_retrieval_ms REAL DEFAULT 0,
    cache_hit_rate REAL DEFAULT 0,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(stat_date)
);

-- ═══════════════════════════════════════════════════════════════════════════════
--                          VIEWS FOR COMMON QUERIES
-- ═══════════════════════════════════════════════════════════════════════════════

-- Active memories view
CREATE VIEW IF NOT EXISTS active_memories AS
SELECT * FROM memories WHERE is_active = 1;

-- Recent memories view
CREATE VIEW IF NOT EXISTS recent_memories AS
SELECT * FROM memories 
WHERE is_active = 1 
ORDER BY accessed_at DESC 
LIMIT 100;

-- Important memories view
CREATE VIEW IF NOT EXISTS important_memories AS
SELECT * FROM memories 
WHERE is_active = 1 AND (is_permanent = 1 OR importance > 0.7)
ORDER BY importance DESC;

-- Memory type summary view
CREATE VIEW IF NOT EXISTS memory_type_summary AS
SELECT 
    memory_type,
    COUNT(*) as count,
    AVG(confidence) as avg_confidence,
    AVG(importance) as avg_importance,
    SUM(access_count) as total_accesses
FROM memories
WHERE is_active = 1
GROUP BY memory_type;

-- Unverified memories view
CREATE VIEW IF NOT EXISTS unverified_memories AS
SELECT * FROM memories 
WHERE is_active = 1 AND is_verified = 0 AND confidence < 0.8
ORDER BY importance DESC, created_at DESC;

-- ═══════════════════════════════════════════════════════════════════════════════
--                          INITIAL DATA
-- ═══════════════════════════════════════════════════════════════════════════════

-- Insert initial system memory entry
INSERT OR IGNORE INTO memories (id, key, value, memory_type, category, source, is_permanent)
VALUES (
    'system-init',
    'database_initialized',
    '{"version": "3.0.0", "schema": "master"}',
    'system',
    'initialization',
    'system',
    1
);