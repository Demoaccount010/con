-- ═══════════════════════════════════════════════════════════════════════════════
--  PERMANENT MEMORY SCHEMA - Never-forgotten critical information
-- ═══════════════════════════════════════════════════════════════════════════════
--
--  This schema stores information that must NEVER be forgotten:
--  • Owner identity and preferences
--  • Agent identity and configuration
--  • Core learned facts
--  • Critical system settings
--
--  RULES:
--  ──────
--  • Data here is NEVER automatically deleted
--  • Changes create versions but don't delete
--  • Separate database file for safety
--  • Regular backups required
--
--  Version: 3.0.0
-- ═══════════════════════════════════════════════════════════════════════════════

-- Enable foreign keys
PRAGMA foreign_keys = ON;

-- WAL mode for safety
PRAGMA journal_mode = WAL;

-- ═══════════════════════════════════════════════════════════════════════════════
--                          OWNER PROFILE TABLE
-- ═══════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS owner_profile (
    id TEXT PRIMARY KEY DEFAULT 'owner',        -- Single owner, always 'owner'
    
    -- Identity
    name TEXT,                                  -- Owner's real name
    nickname TEXT,                              -- How to address owner
    
    -- Contact (for notifications)
    telegram_chat_id TEXT,
    telegram_username TEXT,
    email TEXT,
    
    -- Preferences
    timezone TEXT,
    language TEXT DEFAULT 'en',
    date_format TEXT DEFAULT 'YYYY-MM-DD',
    time_format TEXT DEFAULT '24h',
    
    -- Communication style
    communication_style TEXT DEFAULT 'balanced', -- casual, balanced, formal
    verbosity TEXT DEFAULT 'normal',            -- brief, normal, detailed
    show_reasoning INTEGER DEFAULT 1,           -- Show thinking process
    show_confidence INTEGER DEFAULT 0,          -- Show confidence levels
    
    -- Notification preferences
    notify_learnings INTEGER DEFAULT 1,
    notify_errors INTEGER DEFAULT 1,
    notify_research INTEGER DEFAULT 1,
    quiet_hours_start TEXT,                     -- e.g., "23:00"
    quiet_hours_end TEXT,                       -- e.g., "07:00"
    
    -- Metadata
    first_interaction_at TIMESTAMP,
    total_interactions INTEGER DEFAULT 0,
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Ensure single owner record
INSERT OR IGNORE INTO owner_profile (id) VALUES ('owner');

-- ═══════════════════════════════════════════════════════════════════════════════
--                          AGENT IDENTITY TABLE
-- ═══════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS agent_identity (
    id TEXT PRIMARY KEY DEFAULT 'agent',        -- Single agent, always 'agent'
    
    -- Identity
    name TEXT DEFAULT 'Axiom',                  -- Agent's name
    version TEXT DEFAULT '3.0.0',
    
    -- Personality
    personality_traits TEXT,                    -- JSON array of traits
    core_values TEXT,                           -- JSON array of values
    
    -- Capabilities (learned over time)
    known_capabilities TEXT,                    -- JSON array
    known_limitations TEXT,                     -- JSON array
    
    -- Statistics
    total_tasks_completed INTEGER DEFAULT 0,
    total_learnings INTEGER DEFAULT 0,
    total_research_items INTEGER DEFAULT 0,
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_active_at TIMESTAMP
);

-- Ensure single agent record
INSERT OR IGNORE INTO agent_identity (id) VALUES ('agent');

-- ═══════════════════════════════════════════════════════════════════════════════
--                          CORE FACTS TABLE
-- ═══════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS core_facts (
    id TEXT PRIMARY KEY,
    
    -- Fact identification
    fact_key TEXT NOT NULL UNIQUE,              -- Unique key for the fact
    category TEXT NOT NULL,                     -- owner, system, world, custom
    
    -- Fact content
    fact_value TEXT NOT NULL,                   -- The fact itself
    value_type TEXT DEFAULT 'string',           -- string, json, number, boolean
    
    -- Importance
    importance TEXT DEFAULT 'high',             -- critical, high, normal
    
    -- Learning context
    learned_from TEXT,                          -- How this was learned
    learned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Verification
    verified INTEGER DEFAULT 0,
    verified_at TIMESTAMP,
    verification_method TEXT,
    
    -- Usage tracking
    times_used INTEGER DEFAULT 0,
    last_used_at TIMESTAMP,
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_core_facts_key ON core_facts(fact_key);
CREATE INDEX IF NOT EXISTS idx_core_facts_category ON core_facts(category);

-- ═══════════════════════════════════════════════════════════════════════════════
--                          PERMANENT PREFERENCES TABLE
-- ═══════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS permanent_preferences (
    id TEXT PRIMARY KEY,
    
    -- Preference identification
    preference_key TEXT NOT NULL UNIQUE,
    category TEXT,                              -- tools, output, behavior, etc.
    
    -- Preference content
    preference_value TEXT NOT NULL,
    value_type TEXT DEFAULT 'string',
    
    -- Context
    learned_context TEXT,                       -- When/how this was learned
    
    -- Usage
    times_applied INTEGER DEFAULT 0,
    last_applied_at TIMESTAMP,
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_prefs_key ON permanent_preferences(preference_key);
CREATE INDEX IF NOT EXISTS idx_prefs_category ON permanent_preferences(category);

-- ═══════════════════════════════════════════════════════════════════════════════
--                          SYSTEM CONFIGURATION TABLE
-- ═══════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS system_config (
    id TEXT PRIMARY KEY,
    
    -- Config identification
    config_key TEXT NOT NULL UNIQUE,
    config_section TEXT,                        -- ollama, telegram, security, etc.
    
    -- Config content
    config_value TEXT NOT NULL,
    value_type TEXT DEFAULT 'string',
    
    -- Metadata
    is_sensitive INTEGER DEFAULT 0,             -- 1 = don't log/display
    is_auto_detected INTEGER DEFAULT 0,         -- 1 = was auto-detected
    can_override INTEGER DEFAULT 1,             -- 1 = user can change
    
    -- Source
    set_by TEXT DEFAULT 'wizard',               -- wizard, user, auto, default
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_config_key ON system_config(config_key);
CREATE INDEX IF NOT EXISTS idx_config_section ON system_config(config_section);

-- ═══════════════════════════════════════════════════════════════════════════════
--                          FIRST RUN STATE TABLE
-- ═══════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS first_run_state (
    id TEXT PRIMARY KEY DEFAULT 'first_run',
    
    -- Completion status
    is_completed INTEGER DEFAULT 0,
    completed_at TIMESTAMP,
    
    -- Wizard progress
    current_step TEXT,
    steps_completed TEXT,                       -- JSON array of completed steps
    
    -- Auto-detection results
    auto_detected_values TEXT,                  -- JSON object of auto-detected values
    
    -- User answers
    user_answers TEXT,                          -- JSON object of user answers
    
    -- Validation
    validation_passed INTEGER DEFAULT 0,
    validation_errors TEXT,                     -- JSON array of errors
    
    -- Timestamps
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Ensure single record
INSERT OR IGNORE INTO first_run_state (id) VALUES ('first_run');

-- ═══════════════════════════════════════════════════════════════════════════════
--                          VERSION HISTORY (PERMANENT)
-- ═══════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS permanent_versions (
    id TEXT PRIMARY KEY,
    
    -- Reference
    table_name TEXT NOT NULL,                   -- Which table was changed
    record_id TEXT NOT NULL,                    -- ID of the changed record
    field_name TEXT NOT NULL,                   -- Which field changed
    
    -- Values
    old_value TEXT,
    new_value TEXT,
    
    -- Change info
    change_reason TEXT,
    changed_by TEXT DEFAULT 'user',
    
    -- Timestamp
    changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_perm_versions_table ON permanent_versions(table_name);
CREATE INDEX IF NOT EXISTS idx_perm_versions_record ON permanent_versions(record_id);
CREATE INDEX IF NOT EXISTS idx_perm_versions_time ON permanent_versions(changed_at);

-- ═══════════════════════════════════════════════════════════════════════════════
--                          TRIGGERS FOR VERSION TRACKING
-- ═══════════════════════════════════════════════════════════════════════════════

-- Track owner profile changes
CREATE TRIGGER IF NOT EXISTS track_owner_changes
AFTER UPDATE ON owner_profile
FOR EACH ROW
BEGIN
    -- Track name change
    INSERT INTO permanent_versions (id, table_name, record_id, field_name, old_value, new_value, change_reason)
    SELECT 
        lower(hex(randomblob(4))),
        'owner_profile',
        OLD.id,
        'name',
        OLD.name,
        NEW.name,
        'Owner name updated'
    WHERE OLD.name IS NOT NEW.name;
    
    -- Track nickname change
    INSERT INTO permanent_versions (id, table_name, record_id, field_name, old_value, new_value, change_reason)
    SELECT 
        lower(hex(randomblob(4))),
        'owner_profile',
        OLD.id,
        'nickname',
        OLD.nickname,
        NEW.nickname,
        'Owner nickname updated'
    WHERE OLD.nickname IS NOT NEW.nickname;
    
    -- Update timestamp
    UPDATE owner_profile SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

-- Track agent identity changes
CREATE TRIGGER IF NOT EXISTS track_agent_changes
AFTER UPDATE ON agent_identity
FOR EACH ROW
BEGIN
    INSERT INTO permanent_versions (id, table_name, record_id, field_name, old_value, new_value, change_reason)
    SELECT 
        lower(hex(randomblob(4))),
        'agent_identity',
        OLD.id,
        'name',
        OLD.name,
        NEW.name,
        'Agent name updated'
    WHERE OLD.name IS NOT NEW.name;
    
    UPDATE agent_identity SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

-- Track core facts changes
CREATE TRIGGER IF NOT EXISTS track_core_facts_changes
AFTER UPDATE ON core_facts
FOR EACH ROW
BEGIN
    INSERT INTO permanent_versions (id, table_name, record_id, field_name, old_value, new_value, change_reason)
    SELECT 
        lower(hex(randomblob(4))),
        'core_facts',
        OLD.id,
        'fact_value',
        OLD.fact_value,
        NEW.fact_value,
        'Core fact updated'
    WHERE OLD.fact_value IS NOT NEW.fact_value;
    
    UPDATE core_facts SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

-- ═══════════════════════════════════════════════════════════════════════════════
--                          BACKUP METADATA TABLE
-- ═══════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS backup_metadata (
    id TEXT PRIMARY KEY,
    
    -- Backup info
    backup_path TEXT NOT NULL,
    backup_size_bytes INTEGER,
    
    -- Content
    tables_backed_up TEXT,                      -- JSON array of table names
    record_counts TEXT,                         -- JSON object of counts
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Verification
    checksum TEXT,
    verified INTEGER DEFAULT 0
);

-- ═══════════════════════════════════════════════════════════════════════════════
--                          VIEWS
-- ═══════════════════════════════════════════════════════════════════════════════

-- Complete owner view
CREATE VIEW IF NOT EXISTS owner_complete AS
SELECT 
    o.*,
    (SELECT COUNT(*) FROM core_facts WHERE category = 'owner') as owner_facts_count,
    (SELECT COUNT(*) FROM permanent_preferences) as preferences_count
FROM owner_profile o
WHERE o.id = 'owner';

-- Complete agent view
CREATE VIEW IF NOT EXISTS agent_complete AS
SELECT 
    a.*,
    (SELECT COUNT(*) FROM core_facts) as total_facts,
    (SELECT is_completed FROM first_run_state) as setup_completed
FROM agent_identity a
WHERE a.id = 'agent';

-- All permanent data summary
CREATE VIEW IF NOT EXISTS permanent_summary AS
SELECT
    (SELECT name FROM owner_profile WHERE id = 'owner') as owner_name,
    (SELECT name FROM agent_identity WHERE id = 'agent') as agent_name,
    (SELECT COUNT(*) FROM core_facts) as facts_count,
    (SELECT COUNT(*) FROM permanent_preferences) as preferences_count,
    (SELECT COUNT(*) FROM system_config) as config_count,
    (SELECT is_completed FROM first_run_state) as setup_completed;

-- ═══════════════════════════════════════════════════════════════════════════════
--                          INITIAL CORE FACTS
-- ═══════════════════════════════════════════════════════════════════════════════

-- Insert fundamental facts
INSERT OR IGNORE INTO core_facts (id, fact_key, category, fact_value, importance, learned_from)
VALUES
    ('fact-agent-purpose', 'agent_purpose', 'system', 
     'I am an autonomous AI assistant that thinks, learns, and acts. I never guess - I verify. I use memory as hints, not answers. Reality always wins over memory.', 
     'critical', 'core_design'),
    
    ('fact-agent-principles', 'agent_principles', 'system',
     '["Never guess - verify everything", "Memory is a hint, not the answer", "Reality wins over memory", "Ask when uncertain", "Learn from every interaction", "Follow owner commands"]',
     'critical', 'core_design'),
    
    ('fact-memory-rules', 'memory_rules', 'system',
     'Memory provides context and hints but should not be blindly trusted. Always think fresh. When memory conflicts with verified reality, update memory to match reality.',
     'critical', 'core_design');