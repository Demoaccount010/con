# 🚀 QUICK START GUIDE

## Bhai, 5 Minute Mein Shuru Kar!

### Step 1: Go to Project Directory
```bash
cd Downloads/autonomous_agent
```

### Step 2: Start the Agent
```bash
python core/main.py --interface cli
```

### Step 3: Try Self-Development!

**Hinglish:**
```
mujhe ek plugin chahiye jo hello world print kare
```

**English:**
```
create a feature that shows current time
```

**Hindi:**
```
bhai ek plugin banao jo test message dikhaye
```

---

## ✅ What Will Happen:

1. 🔨 Agent detects development request
2. 📋 Shows what it understood
3. ⚙️  Creates development plan
4. 🔐 Asks for YOUR approval
5. ⚙️  Generates code
6. 🔐 Shows code and asks for YOUR approval again
7. ✅ Tests the code
8. ✅ Deploys the feature
9. 🎉 Feature is ready!

---

## 🔒 Safety Features Active:

- ✅ **ALWAYS asks for approval** before doing anything
- ✅ Blocks dangerous code (file deletion, system calls)
- ✅ Creates automatic backups
- ✅ Can rollback anytime
- ✅ Rate limited (5 features/hour)
- ✅ Complete audit trail

---

## 📁 Where Things Go:

**Generated Plugins:** `plugins/installed/<feature-id>/`
**Backups:** `data/backups/`
**Audit Log:** `data/security/audit_log.jsonl`
**Deployments:** `data/deployments.json`

---

## 🎯 Example Commands:

### Development Requests:
- `mujhe ek plugin chahiye jo...`
- `bhai banao ek feature jo...`
- `create a plugin that...`
- `implement a feature for...`

### Owner Commands:
- `/status` - Check system status
- `/features` - List generated features
- `/approve <id>` - Approve pending request
- `/reject <id>` - Reject pending request
- `/rollback <id>` - Rollback a feature
- `/exit` - Exit agent

---

## ⚠️ Important Notes:

1. **OWNER APPROVAL REQUIRED** - Agent will NEVER do anything without your permission
2. **Backup Created** - Original code backed up at: `Downloads/autonomous_agent_backup_20260204_162810`
3. **Rate Limited** - Max 5 features per hour (for safety)
4. **Ollama Optional** - Works with templates if Ollama not available

---

## 🆘 If Something Goes Wrong:

### Restore from Backup:
```bash
cd Downloads
rm -rf autonomous_agent
mv autonomous_agent_backup_20260204_162810 autonomous_agent
```

### Check Logs:
```bash
tail -f logs/agent.log
```

### Emergency Stop:
In agent CLI:
```
/emergency_stop
```

---

## 📚 More Info:

- **Full Implementation Details:** `IMPLEMENTATION_COMPLETE.md`
- **Complete Plan:** `IMPLEMENTATION_PLAN.md`
- **Test Guide:** `TEST_SELF_DEVELOPMENT.md`

---

**Bas itna hi! Ab start karo aur dekho magic! 🎉**
