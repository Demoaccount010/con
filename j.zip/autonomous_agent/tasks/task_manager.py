#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 TASK MANAGER - Central task orchestration system
═══════════════════════════════════════════════════════════════════════════════

 Manages all tasks in the system:
 • User-initiated tasks
 • Scheduled tasks
 • Background tasks
 • Research tasks
 • System maintenance tasks

 TASK LIFECYCLE:
 ───────────────
 CREATED → QUEUED → RUNNING → COMPLETED/FAILED/CANCELLED

 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Callable, Awaitable, Union
from dataclasses import dataclass, field
from enum import Enum
from uuid import uuid4
import traceback


class TaskStatus(Enum):
    """Task status states."""
    CREATED = "created"
    QUEUED = "queued"
    WAITING = "waiting"       # Waiting for dependency
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"


class TaskPriority(Enum):
    """Task priority levels."""
    CRITICAL = 0    # Execute immediately
    HIGH = 1        # Execute soon
    NORMAL = 2      # Normal queue
    LOW = 3         # When idle
    BACKGROUND = 4  # Only when nothing else


class TaskType(Enum):
    """Types of tasks."""
    USER = "user"             # User-initiated
    SYSTEM = "system"         # System maintenance
    SCHEDULED = "scheduled"   # Scheduled/cron tasks
    BACKGROUND = "background" # Background processing
    RESEARCH = "research"     # Autonomous research
    NOTIFICATION = "notification"  # Notification tasks
    CLEANUP = "cleanup"       # Cleanup tasks


@dataclass
class TaskResult:
    """Result of task execution."""
    success: bool
    output: Any = None
    error: Optional[str] = None
    error_traceback: Optional[str] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    duration_ms: int = 0
    retries: int = 0
    
    @property
    def is_error(self) -> bool:
        return not self.success and self.error is not None


@dataclass
class Task:
    """
    Represents a single task in the system.
    """
    id: str
    name: str
    task_type: TaskType
    
    # Execution
    callable: Callable[..., Awaitable[Any]]
    args: tuple = field(default_factory=tuple)
    kwargs: Dict[str, Any] = field(default_factory=dict)
    
    # Status
    status: TaskStatus = TaskStatus.CREATED
    priority: TaskPriority = TaskPriority.NORMAL
    
    # Timing
    created_at: datetime = field(default_factory=datetime.utcnow)
    queued_at: Optional[datetime] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    timeout_seconds: int = 300  # 5 minutes default
    
    # Scheduling
    scheduled_at: Optional[datetime] = None  # When to run
    recurring: bool = False
    recurring_interval: Optional[timedelta] = None
    
    # Dependencies
    depends_on: List[str] = field(default_factory=list)  # Task IDs
    
    # Retry
    max_retries: int = 3
    retry_count: int = 0
    retry_delay_seconds: int = 5
    
    # Result
    result: Optional[TaskResult] = None
    
    # Metadata
    metadata: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    
    # Callbacks
    on_complete: Optional[Callable] = None
    on_failure: Optional[Callable] = None
    on_progress: Optional[Callable] = None
    
    # Progress tracking
    progress: float = 0.0  # 0.0 to 1.0
    progress_message: str = ""
    
    @classmethod
    def create(
        cls,
        name: str,
        callable: Callable,
        task_type: TaskType = TaskType.USER,
        priority: TaskPriority = TaskPriority.NORMAL,
        **kwargs
    ) -> 'Task':
        """Create a new task."""
        return cls(
            id=str(uuid4())[:8],
            name=name,
            task_type=task_type,
            callable=callable,
            priority=priority,
            **kwargs
        )
    
    @property
    def is_pending(self) -> bool:
        return self.status in [TaskStatus.CREATED, TaskStatus.QUEUED, TaskStatus.WAITING]
    
    @property
    def is_running(self) -> bool:
        return self.status == TaskStatus.RUNNING
    
    @property
    def is_completed(self) -> bool:
        return self.status in [TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED, TaskStatus.TIMEOUT]
    
    @property
    def is_successful(self) -> bool:
        return self.status == TaskStatus.COMPLETED and self.result and self.result.success
    
    @property
    def duration_ms(self) -> int:
        if self.started_at and self.completed_at:
            return int((self.completed_at - self.started_at).total_seconds() * 1000)
        return 0
    
    def update_progress(self, progress: float, message: str = "") -> None:
        """Update task progress."""
        self.progress = max(0.0, min(1.0, progress))
        self.progress_message = message
        if self.on_progress:
            try:
                self.on_progress(self.progress, message)
            except Exception:
                pass
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'id': self.id,
            'name': self.name,
            'type': self.task_type.value,
            'status': self.status.value,
            'priority': self.priority.value,
            'progress': self.progress,
            'progress_message': self.progress_message,
            'created_at': self.created_at.isoformat(),
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'duration_ms': self.duration_ms,
            'result': {
                'success': self.result.success,
                'error': self.result.error,
            } if self.result else None,
            'retry_count': self.retry_count,
            'tags': self.tags,
        }


class TaskManager:
    """
    ═══════════════════════════════════════════════════════════════════════════
    CENTRAL TASK MANAGER
    ═══════════════════════════════════════════════════════════════════════════
    
    Orchestrates all task operations:
    • Task creation and submission
    • Task lifecycle management
    • Dependency resolution
    • Result collection
    • Statistics and monitoring
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize task manager.
        
        Args:
            config: Configuration dictionary
        """
        self.logger = logging.getLogger("tasks.manager")
        self.config = config or {}
        
        # Task storage
        self.tasks: Dict[str, Task] = {}
        self.completed_tasks: Dict[str, Task] = {}
        
        # Task queue reference (set by initialize)
        self._queue = None
        
        # Background runner reference
        self._runner = None
        
        # Configuration
        self.max_completed_history = self.config.get('max_completed_history', 1000)
        self.default_timeout = self.config.get('default_timeout', 300)
        
        # Statistics
        self.stats = {
            'total_created': 0,
            'total_completed': 0,
            'total_failed': 0,
            'total_cancelled': 0,
            'avg_duration_ms': 0,
        }
        
        # Locks
        self._lock = asyncio.Lock()
        
        # Event for task completion notifications
        self._completion_events: Dict[str, asyncio.Event] = {}
        
    async def initialize(self, queue=None, runner=None) -> None:
        """
        Initialize task manager.
        
        Args:
            queue: TaskQueue instance
            runner: BackgroundRunner instance
        """
        self.logger.info("Initializing task manager...")
        
        self._queue = queue
        self._runner = runner
        
        self.logger.info("Task manager initialized")
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          TASK CREATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def create_task(
        self,
        name: str,
        callable: Callable[..., Awaitable[Any]],
        args: tuple = (),
        kwargs: Dict[str, Any] = None,
        task_type: TaskType = TaskType.USER,
        priority: TaskPriority = TaskPriority.NORMAL,
        timeout_seconds: Optional[int] = None,
        depends_on: List[str] = None,
        scheduled_at: Optional[datetime] = None,
        recurring: bool = False,
        recurring_interval: Optional[timedelta] = None,
        max_retries: int = 3,
        tags: List[str] = None,
        metadata: Dict[str, Any] = None,
        on_complete: Optional[Callable] = None,
        on_failure: Optional[Callable] = None,
    ) -> Task:
        """
        Create a new task.
        
        Args:
            name: Task name/description
            callable: Async function to execute
            args: Positional arguments
            kwargs: Keyword arguments
            task_type: Type of task
            priority: Priority level
            timeout_seconds: Timeout for execution
            depends_on: List of task IDs this depends on
            scheduled_at: When to execute (for scheduled tasks)
            recurring: Whether task recurs
            recurring_interval: Interval for recurring tasks
            max_retries: Maximum retry attempts
            tags: Tags for categorization
            metadata: Additional metadata
            on_complete: Callback on completion
            on_failure: Callback on failure
            
        Returns:
            Created Task object
        """
        async with self._lock:
            task = Task(
                id=str(uuid4())[:8],
                name=name,
                task_type=task_type,
                callable=callable,
                args=args,
                kwargs=kwargs or {},
                priority=priority,
                timeout_seconds=timeout_seconds or self.default_timeout,
                depends_on=depends_on or [],
                scheduled_at=scheduled_at,
                recurring=recurring,
                recurring_interval=recurring_interval,
                max_retries=max_retries,
                tags=tags or [],
                metadata=metadata or {},
                on_complete=on_complete,
                on_failure=on_failure,
            )
            
            self.tasks[task.id] = task
            self.stats['total_created'] += 1
            
            self.logger.debug(f"Created task: {task.id} - {name}")
            
            return task
    
    async def submit(self, task: Task) -> str:
        """
        Submit a task for execution.
        
        Args:
            task: Task to submit
            
        Returns:
            Task ID
        """
        if task.id not in self.tasks:
            self.tasks[task.id] = task
            
        # Check dependencies
        if task.depends_on:
            unmet = await self._check_dependencies(task)
            if unmet:
                task.status = TaskStatus.WAITING
                self.logger.debug(f"Task {task.id} waiting for dependencies: {unmet}")
                return task.id
        
        # Check if scheduled for later
        if task.scheduled_at and task.scheduled_at > datetime.utcnow():
            task.status = TaskStatus.QUEUED
            self.logger.debug(f"Task {task.id} scheduled for {task.scheduled_at}")
            return task.id
        
        # Add to queue
        if self._queue:
            await self._queue.put(task)
            task.status = TaskStatus.QUEUED
            task.queued_at = datetime.utcnow()
        
        return task.id
    
    async def submit_and_wait(
        self,
        task: Task,
        timeout: Optional[float] = None
    ) -> TaskResult:
        """
        Submit a task and wait for completion.
        
        Args:
            task: Task to submit
            timeout: Maximum wait time
            
        Returns:
            TaskResult
        """
        # Create completion event
        event = asyncio.Event()
        self._completion_events[task.id] = event
        
        try:
            # Submit task
            await self.submit(task)
            
            # Wait for completion
            if timeout:
                await asyncio.wait_for(event.wait(), timeout)
            else:
                await event.wait()
            
            return task.result or TaskResult(success=False, error="No result")
            
        except asyncio.TimeoutError:
            task.status = TaskStatus.TIMEOUT
            return TaskResult(success=False, error="Task timed out waiting for result")
            
        finally:
            self._completion_events.pop(task.id, None)
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          TASK EXECUTION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def execute_task(self, task: Task) -> TaskResult:
        """
        Execute a single task.
        
        Args:
            task: Task to execute
            
        Returns:
            TaskResult
        """
        task.status = TaskStatus.RUNNING
        task.started_at = datetime.utcnow()
        
        self.logger.info(f"Executing task: {task.id} - {task.name}")
        
        try:
            # Execute with timeout
            result = await asyncio.wait_for(
                task.callable(*task.args, **task.kwargs),
                timeout=task.timeout_seconds
            )
            
            # Success
            task.completed_at = datetime.utcnow()
            task.status = TaskStatus.COMPLETED
            
            task.result = TaskResult(
                success=True,
                output=result,
                started_at=task.started_at,
                completed_at=task.completed_at,
                duration_ms=task.duration_ms,
                retries=task.retry_count
            )
            
            self.stats['total_completed'] += 1
            self._update_avg_duration(task.duration_ms)
            
            # Call completion callback
            if task.on_complete:
                try:
                    if asyncio.iscoroutinefunction(task.on_complete):
                        await task.on_complete(task.result)
                    else:
                        task.on_complete(task.result)
                except Exception as e:
                    self.logger.error(f"Error in completion callback: {e}")
            
            self.logger.info(f"Task completed: {task.id} in {task.duration_ms}ms")
            
        except asyncio.TimeoutError:
            task.completed_at = datetime.utcnow()
            task.status = TaskStatus.TIMEOUT
            
            task.result = TaskResult(
                success=False,
                error=f"Task timed out after {task.timeout_seconds}s",
                started_at=task.started_at,
                completed_at=task.completed_at,
                duration_ms=task.duration_ms,
            )
            
            self.stats['total_failed'] += 1
            self.logger.warning(f"Task timeout: {task.id}")
            
        except asyncio.CancelledError:
            task.completed_at = datetime.utcnow()
            task.status = TaskStatus.CANCELLED
            
            task.result = TaskResult(
                success=False,
                error="Task was cancelled",
                started_at=task.started_at,
                completed_at=task.completed_at,
            )
            
            self.stats['total_cancelled'] += 1
            self.logger.info(f"Task cancelled: {task.id}")
            
        except Exception as e:
            error_tb = traceback.format_exc()
            
            # Check for retry
            if task.retry_count < task.max_retries:
                task.retry_count += 1
                task.status = TaskStatus.QUEUED
                
                self.logger.warning(
                    f"Task failed, retrying ({task.retry_count}/{task.max_retries}): {task.id} - {e}"
                )
                
                # Re-queue with delay
                await asyncio.sleep(task.retry_delay_seconds)
                if self._queue:
                    await self._queue.put(task)
                    
                return TaskResult(success=False, error=str(e), retries=task.retry_count)
            
            # Max retries exceeded
            task.completed_at = datetime.utcnow()
            task.status = TaskStatus.FAILED
            
            task.result = TaskResult(
                success=False,
                error=str(e),
                error_traceback=error_tb,
                started_at=task.started_at,
                completed_at=task.completed_at,
                duration_ms=task.duration_ms,
                retries=task.retry_count
            )
            
            self.stats['total_failed'] += 1
            self.logger.error(f"Task failed: {task.id} - {e}")
            
            # Call failure callback
            if task.on_failure:
                try:
                    if asyncio.iscoroutinefunction(task.on_failure):
                        await task.on_failure(task.result)
                    else:
                        task.on_failure(task.result)
                except Exception as cb_error:
                    self.logger.error(f"Error in failure callback: {cb_error}")
        
        # Notify completion
        await self._notify_completion(task)
        
        # Move to completed history
        await self._archive_completed(task)
        
        # Handle recurring tasks
        if task.recurring and task.recurring_interval and task.status == TaskStatus.COMPLETED:
            await self._reschedule_recurring(task)
        
        # Check waiting tasks
        await self._check_waiting_tasks(task.id)
        
        return task.result
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          TASK CONTROL
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def cancel(self, task_id: str) -> bool:
        """
        Cancel a task.
        
        Args:
            task_id: ID of task to cancel
            
        Returns:
            True if cancelled
        """
        task = self.tasks.get(task_id)
        if not task:
            return False
            
        if task.is_completed:
            return False
            
        task.status = TaskStatus.CANCELLED
        task.completed_at = datetime.utcnow()
        task.result = TaskResult(success=False, error="Cancelled by user")
        
        self.stats['total_cancelled'] += 1
        self.logger.info(f"Task cancelled: {task_id}")
        
        await self._notify_completion(task)
        
        return True
    
    async def pause(self, task_id: str) -> bool:
        """Pause a task (if supported)."""
        task = self.tasks.get(task_id)
        if not task or task.status != TaskStatus.QUEUED:
            return False
            
        task.status = TaskStatus.PAUSED
        return True
    
    async def resume(self, task_id: str) -> bool:
        """Resume a paused task."""
        task = self.tasks.get(task_id)
        if not task or task.status != TaskStatus.PAUSED:
            return False
            
        task.status = TaskStatus.QUEUED
        if self._queue:
            await self._queue.put(task)
        return True
    
    async def retry(self, task_id: str) -> Optional[str]:
        """
        Retry a failed task.
        
        Returns:
            New task ID if retried
        """
        task = self.completed_tasks.get(task_id) or self.tasks.get(task_id)
        if not task or task.status not in [TaskStatus.FAILED, TaskStatus.TIMEOUT]:
            return None
        
        # Create new task with same parameters
        new_task = await self.create_task(
            name=f"{task.name} (retry)",
            callable=task.callable,
            args=task.args,
            kwargs=task.kwargs,
            task_type=task.task_type,
            priority=task.priority,
            timeout_seconds=task.timeout_seconds,
            max_retries=task.max_retries,
            tags=task.tags + ['retry'],
            metadata={**task.metadata, 'retry_of': task_id}
        )
        
        await self.submit(new_task)
        return new_task.id
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          TASK QUERIES
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_task(self, task_id: str) -> Optional[Task]:
        """Get a task by ID."""
        return self.tasks.get(task_id) or self.completed_tasks.get(task_id)
    
    def get_tasks(
        self,
        status: Optional[TaskStatus] = None,
        task_type: Optional[TaskType] = None,
        tags: Optional[List[str]] = None,
        limit: int = 100
    ) -> List[Task]:
        """
        Get tasks matching criteria.
        
        Args:
            status: Filter by status
            task_type: Filter by type
            tags: Filter by tags (any match)
            limit: Maximum results
            
        Returns:
            List of matching tasks
        """
        results = []
        
        for task in list(self.tasks.values()) + list(self.completed_tasks.values()):
            if status and task.status != status:
                continue
            if task_type and task.task_type != task_type:
                continue
            if tags and not any(t in task.tags for t in tags):
                continue
                
            results.append(task)
            
            if len(results) >= limit:
                break
                
        return results
    
    def get_pending_count(self) -> int:
        """Get count of pending tasks."""
        return sum(1 for t in self.tasks.values() if t.is_pending)
    
    def get_running_count(self) -> int:
        """Get count of running tasks."""
        return sum(1 for t in self.tasks.values() if t.is_running)
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          INTERNAL METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _check_dependencies(self, task: Task) -> List[str]:
        """Check for unmet dependencies."""
        unmet = []
        for dep_id in task.depends_on:
            dep_task = self.tasks.get(dep_id) or self.completed_tasks.get(dep_id)
            if not dep_task or not dep_task.is_successful:
                unmet.append(dep_id)
        return unmet
    
    async def _check_waiting_tasks(self, completed_task_id: str) -> None:
        """Check if any waiting tasks can now run."""
        for task in self.tasks.values():
            if task.status == TaskStatus.WAITING:
                if completed_task_id in task.depends_on:
                    unmet = await self._check_dependencies(task)
                    if not unmet:
                        await self.submit(task)
    
    async def _notify_completion(self, task: Task) -> None:
        """Notify that a task has completed."""
        event = self._completion_events.get(task.id)
        if event:
            event.set()
    
    async def _archive_completed(self, task: Task) -> None:
        """Move completed task to history."""
        if task.is_completed:
            self.completed_tasks[task.id] = task
            self.tasks.pop(task.id, None)
            
            # Trim history
            if len(self.completed_tasks) > self.max_completed_history:
                oldest = sorted(
                    self.completed_tasks.values(),
                    key=lambda t: t.completed_at or datetime.min
                )[:len(self.completed_tasks) - self.max_completed_history]
                
                for t in oldest:
                    self.completed_tasks.pop(t.id, None)
    
    async def _reschedule_recurring(self, task: Task) -> None:
        """Reschedule a recurring task."""
        if not task.recurring_interval:
            return
            
        next_run = datetime.utcnow() + task.recurring_interval
        
        new_task = await self.create_task(
            name=task.name,
            callable=task.callable,
            args=task.args,
            kwargs=task.kwargs,
            task_type=task.task_type,
            priority=task.priority,
            timeout_seconds=task.timeout_seconds,
            scheduled_at=next_run,
            recurring=True,
            recurring_interval=task.recurring_interval,
            max_retries=task.max_retries,
            tags=task.tags,
            metadata=task.metadata,
        )
        
        self.logger.info(f"Rescheduled recurring task {task.name} for {next_run}")
    
    def _update_avg_duration(self, duration_ms: int) -> None:
        """Update average duration statistic."""
        n = self.stats['total_completed']
        if n == 1:
            self.stats['avg_duration_ms'] = duration_ms
        else:
            current = self.stats['avg_duration_ms']
            self.stats['avg_duration_ms'] = (current * (n - 1) + duration_ms) / n
    
    def get_stats(self) -> Dict[str, Any]:
        """Get task manager statistics."""
        return {
            **self.stats,
            'pending': self.get_pending_count(),
            'running': self.get_running_count(),
            'total_in_memory': len(self.tasks) + len(self.completed_tasks),
        }
    
    async def shutdown(self) -> None:
        """Shutdown task manager."""
        self.logger.info("Shutting down task manager...")
        
        # Cancel pending tasks
        for task in list(self.tasks.values()):
            if task.is_pending:
                await self.cancel(task.id)
        
        self.logger.info("Task manager shutdown complete")