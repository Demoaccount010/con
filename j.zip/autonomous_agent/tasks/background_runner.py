#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 BACKGROUND RUNNER - Executes tasks from the queue
═══════════════════════════════════════════════════════════════════════════════

 Features:
 • Multiple worker tasks
 • Graceful shutdown
 • Resource limits
 • Health monitoring
 • Adaptive scaling

 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
from datetime import datetime
from typing import Optional, Dict, Any, List, Set
from dataclasses import dataclass
from enum import Enum


# Import from task modules
from tasks.task_manager import TaskManager, Task, TaskStatus, TaskResult
from tasks.task_queue import TaskQueue


class WorkerState(Enum):
    """Worker states."""
    IDLE = "idle"
    RUNNING = "running"
    STOPPING = "stopping"
    STOPPED = "stopped"


@dataclass
class WorkerStats:
    """Statistics for a single worker."""
    worker_id: str
    state: WorkerState
    tasks_processed: int
    tasks_failed: int
    current_task: Optional[str]
    last_task_at: Optional[datetime]
    total_runtime_ms: int


class BackgroundRunner:
    """
    ═══════════════════════════════════════════════════════════════════════════
    BACKGROUND TASK RUNNER
    ═══════════════════════════════════════════════════════════════════════════
    
    Manages worker tasks that process tasks from the queue.
    """
    
    def __init__(
        self,
        task_manager: TaskManager,
        task_queue: TaskQueue,
        config: Optional[Dict[str, Any]] = None
    ):
        """
        Initialize background runner.
        
        Args:
            task_manager: TaskManager instance
            task_queue: TaskQueue instance
            config: Configuration dictionary
        """
        self.logger = logging.getLogger("tasks.runner")
        self.task_manager = task_manager
        self.task_queue = task_queue
        self.config = config or {}
        
        # Configuration
        self.num_workers = self.config.get('num_workers', 4)
        self.min_workers = self.config.get('min_workers', 1)
        self.max_workers = self.config.get('max_workers', 10)
        self.poll_interval = self.config.get('poll_interval', 0.1)
        self.shutdown_timeout = self.config.get('shutdown_timeout', 30)
        
        # Worker management
        self._workers: Dict[str, asyncio.Task] = {}
        self._worker_stats: Dict[str, WorkerStats] = {}
        self._worker_id_counter = 0
        
        # Running state
        self._running = False
        self._shutdown_event = asyncio.Event()
        
        # Currently processing tasks
        self._processing: Set[str] = set()
        
        # Statistics
        self.stats = {
            'total_processed': 0,
            'total_failed': 0,
            'uptime_seconds': 0,
            'peak_workers': 0,
        }
        
        self._started_at: Optional[datetime] = None
        
    async def initialize(self) -> None:
        """Initialize the runner."""
        self.logger.info("Initializing background runner...")
        self.logger.info(f"Configured for {self.num_workers} workers")
    
    async def start(self) -> None:
        """Start the background runner."""
        if self._running:
            self.logger.warning("Runner already running")
            return
        
        self.logger.info(f"Starting background runner with {self.num_workers} workers...")
        
        self._running = True
        self._shutdown_event.clear()
        self._started_at = datetime.utcnow()
        
        # Start workers
        for _ in range(self.num_workers):
            await self._spawn_worker()
        
        self.stats['peak_workers'] = len(self._workers)
        self.logger.info("Background runner started")
    
    async def stop(self, timeout: Optional[float] = None) -> None:
        """
        Stop the background runner.
        
        Args:
            timeout: Maximum wait time for workers to finish
        """
        if not self._running:
            return
        
        self.logger.info("Stopping background runner...")
        
        self._running = False
        self._shutdown_event.set()
        
        # Wait for workers to finish
        if self._workers:
            timeout = timeout or self.shutdown_timeout
            
            try:
                await asyncio.wait_for(
                    asyncio.gather(*self._workers.values(), return_exceptions=True),
                    timeout=timeout
                )
            except asyncio.TimeoutError:
                self.logger.warning("Timeout waiting for workers, cancelling...")
                for worker in self._workers.values():
                    worker.cancel()
                    
                await asyncio.gather(*self._workers.values(), return_exceptions=True)
        
        self._workers.clear()
        self._worker_stats.clear()
        
        self.logger.info("Background runner stopped")
    
    async def _spawn_worker(self) -> str:
        """
        Spawn a new worker task.
        
        Returns:
            Worker ID
        """
        self._worker_id_counter += 1
        worker_id = f"worker-{self._worker_id_counter}"
        
        # Initialize stats
        self._worker_stats[worker_id] = WorkerStats(
            worker_id=worker_id,
            state=WorkerState.IDLE,
            tasks_processed=0,
            tasks_failed=0,
            current_task=None,
            last_task_at=None,
            total_runtime_ms=0
        )
        
        # Create worker task
        worker = asyncio.create_task(self._worker_loop(worker_id))
        self._workers[worker_id] = worker
        
        self.logger.debug(f"Spawned worker: {worker_id}")
        return worker_id
    
    async def _remove_worker(self, worker_id: str) -> None:
        """Remove a worker."""
        if worker_id in self._workers:
            self._workers[worker_id].cancel()
            try:
                await self._workers[worker_id]
            except asyncio.CancelledError:
                pass
            
            del self._workers[worker_id]
            del self._worker_stats[worker_id]
            
            self.logger.debug(f"Removed worker: {worker_id}")
    
    async def _worker_loop(self, worker_id: str) -> None:
        """
        Main worker loop.
        
        Args:
            worker_id: ID of this worker
        """
        self.logger.debug(f"Worker {worker_id} started")
        stats = self._worker_stats[worker_id]
        
        while self._running and not self._shutdown_event.is_set():
            try:
                # Get task from queue
                task = await self.task_queue.get(block=True, timeout=self.poll_interval)
                
                if task is None:
                    # No task available, continue polling
                    stats.state = WorkerState.IDLE
                    continue
                
                # Process task
                stats.state = WorkerState.RUNNING
                stats.current_task = task.id
                self._processing.add(task.id)
                
                start_time = datetime.utcnow()
                
                try:
                    result = await self.task_manager.execute_task(task)
                    
                    if result.success:
                        stats.tasks_processed += 1
                        self.stats['total_processed'] += 1
                    else:
                        stats.tasks_failed += 1
                        self.stats['total_failed'] += 1
                        
                except Exception as e:
                    self.logger.error(f"Worker {worker_id} error: {e}", exc_info=True)
                    stats.tasks_failed += 1
                    self.stats['total_failed'] += 1
                
                finally:
                    duration = int((datetime.utcnow() - start_time).total_seconds() * 1000)
                    stats.total_runtime_ms += duration
                    stats.last_task_at = datetime.utcnow()
                    stats.current_task = None
                    self._processing.discard(task.id)
                    
            except asyncio.CancelledError:
                break
                
            except Exception as e:
                self.logger.error(f"Worker {worker_id} unexpected error: {e}", exc_info=True)
                await asyncio.sleep(1)  # Backoff on error
        
        stats.state = WorkerState.STOPPED
        self.logger.debug(f"Worker {worker_id} stopped")
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          SCALING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def scale_up(self, count: int = 1) -> int:
        """
        Add more workers.
        
        Args:
            count: Number of workers to add
            
        Returns:
            Number of workers added
        """
        added = 0
        for _ in range(count):
            if len(self._workers) >= self.max_workers:
                break
            await self._spawn_worker()
            added += 1
        
        self.stats['peak_workers'] = max(self.stats['peak_workers'], len(self._workers))
        self.logger.info(f"Scaled up by {added} workers (total: {len(self._workers)})")
        return added
    
    async def scale_down(self, count: int = 1) -> int:
        """
        Remove workers.
        
        Args:
            count: Number of workers to remove
            
        Returns:
            Number of workers removed
        """
        removed = 0
        
        # Find idle workers to remove
        idle_workers = [
            wid for wid, stats in self._worker_stats.items()
            if stats.state == WorkerState.IDLE
        ]
        
        for worker_id in idle_workers[:count]:
            if len(self._workers) <= self.min_workers:
                break
            await self._remove_worker(worker_id)
            removed += 1
        
        self.logger.info(f"Scaled down by {removed} workers (total: {len(self._workers)})")
        return removed
    
    async def auto_scale(self) -> None:
        """
        Automatically adjust worker count based on queue size.
        """
        queue_size = self.task_queue.size()
        current_workers = len(self._workers)
        
        # Calculate desired workers based on queue size
        desired = min(
            max(self.min_workers, queue_size // 10 + 1),
            self.max_workers
        )
        
        if desired > current_workers:
            await self.scale_up(desired - current_workers)
        elif desired < current_workers:
            await self.scale_down(current_workers - desired)
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          STATUS & MONITORING
    # ═══════════════════════════════════════════════════════════════════════════
    
    def is_running(self) -> bool:
        """Check if runner is running."""
        return self._running
    
    def get_worker_count(self) -> int:
        """Get current worker count."""
        return len(self._workers)
    
    def get_idle_count(self) -> int:
        """Get count of idle workers."""
        return sum(
            1 for stats in self._worker_stats.values()
            if stats.state == WorkerState.IDLE
        )
    
    def get_active_count(self) -> int:
        """Get count of active (running) workers."""
        return sum(
            1 for stats in self._worker_stats.values()
            if stats.state == WorkerState.RUNNING
        )
    
    def get_processing_tasks(self) -> Set[str]:
        """Get IDs of tasks currently being processed."""
        return self._processing.copy()
    
    def get_worker_stats(self) -> List[Dict[str, Any]]:
        """Get stats for all workers."""
        return [
            {
                'worker_id': stats.worker_id,
                'state': stats.state.value,
                'tasks_processed': stats.tasks_processed,
                'tasks_failed': stats.tasks_failed,
                'current_task': stats.current_task,
                'last_task_at': stats.last_task_at.isoformat() if stats.last_task_at else None,
                'total_runtime_ms': stats.total_runtime_ms,
            }
            for stats in self._worker_stats.values()
        ]
    
    def get_stats(self) -> Dict[str, Any]:
        """Get runner statistics."""
        uptime = 0
        if self._started_at:
            uptime = (datetime.utcnow() - self._started_at).total_seconds()
        
        return {
            **self.stats,
            'uptime_seconds': uptime,
            'running': self._running,
            'worker_count': len(self._workers),
            'idle_workers': self.get_idle_count(),
            'active_workers': self.get_active_count(),
            'processing_count': len(self._processing),
            'queue_size': self.task_queue.size(),
        }
    
    async def health_check(self) -> Dict[str, Any]:
        """
        Perform health check.
        
        Returns:
            Health status
        """
        healthy = True
        issues = []
        
        # Check if running
        if not self._running:
            healthy = False
            issues.append("Runner not running")
        
        # Check worker count
        if len(self._workers) == 0:
            healthy = False
            issues.append("No workers available")
        
        # Check for stuck workers
        now = datetime.utcnow()
        for stats in self._worker_stats.values():
            if stats.state == WorkerState.RUNNING and stats.last_task_at:
                running_time = (now - stats.last_task_at).total_seconds()
                if running_time > 300:  # 5 minutes
                    issues.append(f"Worker {stats.worker_id} may be stuck")
        
        # Check queue health
        if self.task_queue.size() > 1000:
            issues.append("Queue backlog detected")
        
        return {
            'healthy': healthy and len(issues) == 0,
            'issues': issues,
            'stats': self.get_stats(),
        }


class ScheduledRunner:
    """
    ═══════════════════════════════════════════════════════════════════════════
    SCHEDULED TASK RUNNER
    ═══════════════════════════════════════════════════════════════════════════
    
    Manages scheduled/recurring tasks separate from the main queue.
    """
    
    def __init__(
        self,
        task_manager: TaskManager,
        config: Optional[Dict[str, Any]] = None
    ):
        """Initialize scheduled runner."""
        self.logger = logging.getLogger("tasks.scheduled")
        self.task_manager = task_manager
        self.config = config or {}
        
        # Scheduled tasks
        self._scheduled_tasks: Dict[str, Dict[str, Any]] = {}
        
        # Runner task
        self._runner_task: Optional[asyncio.Task] = None
        self._running = False
        
        # Check interval
        self.check_interval = self.config.get('check_interval', 1.0)
    
    async def start(self) -> None:
        """Start the scheduled runner."""
        if self._running:
            return
        
        self.logger.info("Starting scheduled runner...")
        self._running = True
        self._runner_task = asyncio.create_task(self._run_loop())
    
    async def stop(self) -> None:
        """Stop the scheduled runner."""
        self._running = False
        
        if self._runner_task:
            self._runner_task.cancel()
            try:
                await self._runner_task
            except asyncio.CancelledError:
                pass
        
        self.logger.info("Scheduled runner stopped")
    
    def schedule(
        self,
        name: str,
        callable: Any,
        interval_seconds: int,
        start_immediately: bool = False,
        args: tuple = (),
        kwargs: Dict[str, Any] = None
    ) -> str:
        """
        Schedule a recurring task.
        
        Returns:
            Schedule ID
        """
        from uuid import uuid4
        
        schedule_id = str(uuid4())[:8]
        
        self._scheduled_tasks[schedule_id] = {
            'id': schedule_id,
            'name': name,
            'callable': callable,
            'args': args,
            'kwargs': kwargs or {},
            'interval_seconds': interval_seconds,
            'last_run': None if start_immediately else datetime.utcnow(),
            'next_run': datetime.utcnow() if start_immediately else None,
            'run_count': 0,
            'enabled': True,
        }
        
        self.logger.info(f"Scheduled task: {name} (every {interval_seconds}s)")
        return schedule_id
    
    def unschedule(self, schedule_id: str) -> bool:
        """Remove a scheduled task."""
        if schedule_id in self._scheduled_tasks:
            del self._scheduled_tasks[schedule_id]
            return True
        return False
    
    def pause(self, schedule_id: str) -> bool:
        """Pause a scheduled task."""
        if schedule_id in self._scheduled_tasks:
            self._scheduled_tasks[schedule_id]['enabled'] = False
            return True
        return False
    
    def resume(self, schedule_id: str) -> bool:
        """Resume a paused scheduled task."""
        if schedule_id in self._scheduled_tasks:
            self._scheduled_tasks[schedule_id]['enabled'] = True
            return True
        return False
    
    async def _run_loop(self) -> None:
        """Main scheduler loop."""
        self.logger.debug("Scheduler loop started")
        
        while self._running:
            try:
                await asyncio.sleep(self.check_interval)
                now = datetime.utcnow()
                
                for schedule_id, schedule in list(self._scheduled_tasks.items()):
                    if not schedule['enabled']:
                        continue
                    
                    # Check if time to run
                    should_run = False
                    
                    if schedule['next_run'] and now >= schedule['next_run']:
                        should_run = True
                    elif schedule['last_run']:
                        elapsed = (now - schedule['last_run']).total_seconds()
                        if elapsed >= schedule['interval_seconds']:
                            should_run = True
                    
                    if should_run:
                        # Create and submit task
                        from tasks.task_manager import TaskType
                        
                        task = await self.task_manager.create_task(
                            name=f"{schedule['name']} (scheduled)",
                            callable=schedule['callable'],
                            args=schedule['args'],
                            kwargs=schedule['kwargs'],
                            task_type=TaskType.SCHEDULED,
                            tags=['scheduled', schedule_id],
                        )
                        
                        await self.task_manager.submit(task)
                        
                        # Update schedule
                        schedule['last_run'] = now
                        schedule['next_run'] = now + asyncio.timedelta(
                            seconds=schedule['interval_seconds']
                        ) if hasattr(asyncio, 'timedelta') else None
                        schedule['run_count'] += 1
                        
                        self.logger.debug(f"Ran scheduled task: {schedule['name']}")
                        
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Scheduler error: {e}")
    
    def get_scheduled_tasks(self) -> List[Dict[str, Any]]:
        """Get all scheduled tasks."""
        return [
            {
                'id': s['id'],
                'name': s['name'],
                'interval_seconds': s['interval_seconds'],
                'last_run': s['last_run'].isoformat() if s['last_run'] else None,
                'run_count': s['run_count'],
                'enabled': s['enabled'],
            }
            for s in self._scheduled_tasks.values()
        ]