#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 TASK QUEUE - Priority-based task queue implementation
═══════════════════════════════════════════════════════════════════════════════

 Features:
 • Priority queue with multiple levels
 • Async-safe operations
 • Task deduplication
 • Queue statistics
 • Overflow handling

 PRIORITY ORDER:
 ───────────────
 CRITICAL (0) → HIGH (1) → NORMAL (2) → LOW (3) → BACKGROUND (4)

 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
from datetime import datetime
from typing import Optional, Dict, Any, List, Set
from dataclasses import dataclass, field
from heapq import heappush, heappop
import time


# Import from task_manager
from tasks.task_manager import Task, TaskStatus, TaskPriority


@dataclass(order=True)
class PrioritizedTask:
    """
    Wrapper for tasks in priority queue.
    
    Orders by:
    1. Priority (lower = higher priority)
    2. Timestamp (earlier = higher priority)
    """
    priority: int
    timestamp: float
    task: Task = field(compare=False)
    
    @classmethod
    def wrap(cls, task: Task) -> 'PrioritizedTask':
        """Wrap a task for queue insertion."""
        return cls(
            priority=task.priority.value,
            timestamp=time.time(),
            task=task
        )


class TaskQueue:
    """
    ═══════════════════════════════════════════════════════════════════════════
    PRIORITY TASK QUEUE
    ═══════════════════════════════════════════════════════════════════════════
    
    Thread-safe, async-friendly priority queue for tasks.
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize task queue.
        
        Args:
            config: Configuration dictionary
        """
        self.logger = logging.getLogger("tasks.queue")
        self.config = config or {}
        
        # Priority heap
        self._heap: List[PrioritizedTask] = []
        
        # Set for quick duplicate checking
        self._task_ids: Set[str] = set()
        
        # Locks
        self._lock = asyncio.Lock()
        self._not_empty = asyncio.Condition()
        
        # Configuration
        self.max_size = self.config.get('max_size', 10000)
        self.allow_duplicates = self.config.get('allow_duplicates', False)
        
        # Statistics
        self.stats = {
            'total_enqueued': 0,
            'total_dequeued': 0,
            'total_dropped': 0,
            'peak_size': 0,
        }
        
        # Scheduled tasks (waiting for their time)
        self._scheduled: List[PrioritizedTask] = []
        self._scheduler_task: Optional[asyncio.Task] = None
        
    async def initialize(self) -> None:
        """Initialize the queue and start scheduler."""
        self.logger.info("Initializing task queue...")
        
        # Start scheduler for scheduled tasks
        self._scheduler_task = asyncio.create_task(self._scheduler_loop())
        
        self.logger.info("Task queue initialized")
    
    async def put(
        self,
        task: Task,
        block: bool = True,
        timeout: Optional[float] = None
    ) -> bool:
        """
        Add a task to the queue.
        
        Args:
            task: Task to add
            block: Whether to block if queue is full
            timeout: Maximum wait time if blocking
            
        Returns:
            True if task was added
        """
        async with self._lock:
            # Check for duplicates
            if not self.allow_duplicates and task.id in self._task_ids:
                self.logger.debug(f"Duplicate task rejected: {task.id}")
                return False
            
            # Check queue size
            if len(self._heap) >= self.max_size:
                if not block:
                    self.stats['total_dropped'] += 1
                    self.logger.warning(f"Queue full, task dropped: {task.id}")
                    return False
                    
                # Could implement blocking wait here
                self.stats['total_dropped'] += 1
                return False
            
            # Check if scheduled for later
            if task.scheduled_at and task.scheduled_at > datetime.utcnow():
                wrapped = PrioritizedTask.wrap(task)
                heappush(self._scheduled, wrapped)
                self._task_ids.add(task.id)
                self.logger.debug(f"Task scheduled for later: {task.id} at {task.scheduled_at}")
                return True
            
            # Add to queue
            wrapped = PrioritizedTask.wrap(task)
            heappush(self._heap, wrapped)
            self._task_ids.add(task.id)
            
            # Update stats
            self.stats['total_enqueued'] += 1
            self.stats['peak_size'] = max(self.stats['peak_size'], len(self._heap))
            
            self.logger.debug(f"Task enqueued: {task.id} (priority={task.priority.name})")
        
        # Notify waiters
        async with self._not_empty:
            self._not_empty.notify()
            
        return True
    
    async def get(
        self,
        block: bool = True,
        timeout: Optional[float] = None
    ) -> Optional[Task]:
        """
        Get the next task from the queue.
        
        Args:
            block: Whether to block if queue is empty
            timeout: Maximum wait time if blocking
            
        Returns:
            Next task or None
        """
        async with self._not_empty:
            while True:
                async with self._lock:
                    if self._heap:
                        wrapped = heappop(self._heap)
                        self._task_ids.discard(wrapped.task.id)
                        self.stats['total_dequeued'] += 1
                        
                        self.logger.debug(f"Task dequeued: {wrapped.task.id}")
                        return wrapped.task
                
                if not block:
                    return None
                
                # Wait for task
                try:
                    if timeout:
                        await asyncio.wait_for(
                            self._not_empty.wait(),
                            timeout=timeout
                        )
                    else:
                        await self._not_empty.wait()
                except asyncio.TimeoutError:
                    return None
    
    async def peek(self) -> Optional[Task]:
        """Peek at the next task without removing it."""
        async with self._lock:
            if self._heap:
                return self._heap[0].task
            return None
    
    async def remove(self, task_id: str) -> bool:
        """
        Remove a task from the queue.
        
        Args:
            task_id: ID of task to remove
            
        Returns:
            True if task was removed
        """
        async with self._lock:
            if task_id not in self._task_ids:
                return False
            
            # Find and remove from heap
            self._heap = [p for p in self._heap if p.task.id != task_id]
            # Re-heapify
            import heapq
            heapq.heapify(self._heap)
            
            # Also check scheduled
            self._scheduled = [p for p in self._scheduled if p.task.id != task_id]
            heapq.heapify(self._scheduled)
            
            self._task_ids.discard(task_id)
            
            self.logger.debug(f"Task removed from queue: {task_id}")
            return True
    
    async def clear(self) -> int:
        """
        Clear all tasks from the queue.
        
        Returns:
            Number of tasks cleared
        """
        async with self._lock:
            count = len(self._heap) + len(self._scheduled)
            self._heap.clear()
            self._scheduled.clear()
            self._task_ids.clear()
            
            self.logger.info(f"Queue cleared: {count} tasks removed")
            return count
    
    def size(self) -> int:
        """Get current queue size."""
        return len(self._heap)
    
    def scheduled_size(self) -> int:
        """Get number of scheduled tasks."""
        return len(self._scheduled)
    
    def is_empty(self) -> bool:
        """Check if queue is empty."""
        return len(self._heap) == 0
    
    def contains(self, task_id: str) -> bool:
        """Check if task is in queue."""
        return task_id in self._task_ids
    
    async def get_by_priority(self, priority: TaskPriority, limit: int = 10) -> List[Task]:
        """Get tasks of a specific priority."""
        async with self._lock:
            return [
                p.task for p in self._heap
                if p.task.priority == priority
            ][:limit]
    
    def get_stats(self) -> Dict[str, Any]:
        """Get queue statistics."""
        return {
            **self.stats,
            'current_size': self.size(),
            'scheduled_size': self.scheduled_size(),
            'is_empty': self.is_empty(),
        }
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          SCHEDULER
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _scheduler_loop(self) -> None:
        """Background loop to move scheduled tasks to main queue."""
        self.logger.debug("Scheduler loop started")
        
        while True:
            try:
                await asyncio.sleep(1)  # Check every second
                
                now = datetime.utcnow()
                
                async with self._lock:
                    # Find tasks ready to run
                    ready = []
                    remaining = []
                    
                    for wrapped in self._scheduled:
                        if wrapped.task.scheduled_at and wrapped.task.scheduled_at <= now:
                            ready.append(wrapped)
                        else:
                            remaining.append(wrapped)
                    
                    self._scheduled = remaining
                    
                    # Move ready tasks to main queue
                    for wrapped in ready:
                        heappush(self._heap, wrapped)
                        self.stats['total_enqueued'] += 1
                        self.logger.debug(f"Scheduled task now ready: {wrapped.task.id}")
                
                # Notify if tasks were added
                if ready:
                    async with self._not_empty:
                        self._not_empty.notify_all()
                        
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Scheduler error: {e}")
                await asyncio.sleep(5)
    
    async def shutdown(self) -> None:
        """Shutdown the queue."""
        self.logger.info("Shutting down task queue...")
        
        if self._scheduler_task:
            self._scheduler_task.cancel()
            try:
                await self._scheduler_task
            except asyncio.CancelledError:
                pass
        
        self.logger.info("Task queue shutdown complete")


class MultiQueue:
    """
    ═══════════════════════════════════════════════════════════════════════════
    MULTI-LEVEL QUEUE
    ═══════════════════════════════════════════════════════════════════════════
    
    Separate queues for each priority level with round-robin balancing.
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize multi-queue."""
        self.logger = logging.getLogger("tasks.multiqueue")
        self.config = config or {}
        
        # Separate queue for each priority
        self.queues: Dict[TaskPriority, asyncio.Queue] = {
            priority: asyncio.Queue(maxsize=self.config.get('queue_size', 1000))
            for priority in TaskPriority
        }
        
        # Track task IDs
        self._task_ids: Set[str] = set()
        self._lock = asyncio.Lock()
        
        # Round-robin state
        self._rr_index = 0
        
    async def put(self, task: Task) -> bool:
        """Add task to appropriate queue."""
        async with self._lock:
            if task.id in self._task_ids:
                return False
                
            try:
                self.queues[task.priority].put_nowait(task)
                self._task_ids.add(task.id)
                return True
            except asyncio.QueueFull:
                self.logger.warning(f"Queue full for priority {task.priority.name}")
                return False
    
    async def get(self) -> Optional[Task]:
        """
        Get next task, checking higher priorities first.
        """
        for priority in TaskPriority:
            queue = self.queues[priority]
            if not queue.empty():
                task = await queue.get()
                async with self._lock:
                    self._task_ids.discard(task.id)
                return task
        return None
    
    def total_size(self) -> int:
        """Get total size across all queues."""
        return sum(q.qsize() for q in self.queues.values())
    
    def size_by_priority(self) -> Dict[str, int]:
        """Get size of each priority queue."""
        return {
            priority.name: self.queues[priority].qsize()
            for priority in TaskPriority
        }