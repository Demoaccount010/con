#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 PLUGIN LOADER - Safely loads plugins from disk
═══════════════════════════════════════════════════════════════════════════════

 Handles:
 • Plugin discovery
 • Metadata loading (from plugin.yaml or class)
 • Safe module loading
 • Sandboxing (optional)
 • Hot reload support

 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
import importlib
import importlib.util
import sys
from pathlib import Path
from typing import Optional, Dict, Any, Type, List
from dataclasses import dataclass

import yaml

from plugins.plugin_base import PluginBase, PluginMetadata


class PluginLoadError(Exception):
    """Error during plugin loading."""
    pass


class PluginValidationError(Exception):
    """Error during plugin validation."""
    pass


@dataclass
class LoadedModule:
    """Information about a loaded plugin module."""
    module_name: str
    module: Any
    plugin_class: Type[PluginBase]
    metadata: PluginMetadata
    source_path: Path


class PluginLoader:
    """
    ═══════════════════════════════════════════════════════════════════════════
    PLUGIN LOADER
    ═══════════════════════════════════════════════════════════════════════════
    
    Safely loads plugin modules from disk.
    """
    
    # Files to look for in plugin directories
    PLUGIN_FILE = 'plugin.py'
    METADATA_FILE = 'plugin.yaml'
    REQUIREMENTS_FILE = 'requirements.txt'
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize plugin loader.
        
        Args:
            config: Configuration dictionary
        """
        self.logger = logging.getLogger("plugins.loader")
        self.config = config or {}
        
        # Loaded modules cache
        self._loaded_modules: Dict[str, LoadedModule] = {}
        
        # Configuration
        self.validate_metadata = self.config.get('validate_metadata', True)
        self.check_requirements = self.config.get('check_requirements', True)
        self.sandbox_enabled = self.config.get('sandbox_enabled', False)
        
        # Module counter for unique names
        self._module_counter = 0
    
    async def initialize(self) -> None:
        """Initialize the loader."""
        self.logger.info("Initializing plugin loader")
    
    async def load_metadata(self, path: Path) -> Optional[PluginMetadata]:
        """
        Load plugin metadata without fully loading the plugin.
        
        Args:
            path: Path to plugin file or directory
            
        Returns:
            PluginMetadata if found
        """
        try:
            # Determine paths
            if path.is_dir():
                plugin_dir = path
                plugin_file = path / self.PLUGIN_FILE
                metadata_file = path / self.METADATA_FILE
            else:
                plugin_dir = path.parent
                plugin_file = path
                metadata_file = plugin_dir / self.METADATA_FILE
            
            # Try loading from plugin.yaml first
            if metadata_file.exists():
                metadata = await self._load_yaml_metadata(metadata_file)
                if metadata:
                    return metadata
            
            # Fall back to loading from plugin class
            if plugin_file.exists():
                metadata = await self._load_class_metadata(plugin_file)
                if metadata:
                    return metadata
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error loading metadata from {path}: {e}")
            return None
    
    async def _load_yaml_metadata(self, metadata_file: Path) -> Optional[PluginMetadata]:
        """Load metadata from YAML file."""
        try:
            with open(metadata_file, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
            
            if not data:
                return None
            
            return PluginMetadata.from_dict(data)
            
        except Exception as e:
            self.logger.error(f"Error parsing metadata YAML: {e}")
            return None
    
    async def _load_class_metadata(self, plugin_file: Path) -> Optional[PluginMetadata]:
        """Load metadata from plugin class without full import."""
        try:
            # Read file content
            content = plugin_file.read_text(encoding='utf-8')
            
            # Quick check for PluginBase inheritance
            if 'PluginBase' not in content and 'PluginMetadata' not in content:
                return None
            
            # Load temporarily to get metadata
            module = await self._load_module(plugin_file, temp=True)
            
            if not module:
                return None
            
            # Find plugin class
            plugin_class = self._find_plugin_class(module)
            
            if not plugin_class:
                return None
            
            # Get metadata from class
            try:
                metadata = plugin_class.get_metadata()
                return metadata
            except Exception:
                # Try METADATA class attribute
                if hasattr(plugin_class, 'METADATA') and plugin_class.METADATA:
                    return plugin_class.METADATA
            
            return None
            
        except Exception as e:
            self.logger.debug(f"Could not load class metadata: {e}")
            return None
    
    async def load_plugin(self, path: Path) -> Optional[Type[PluginBase]]:
        """
        Load a plugin and return its class.
        
        Args:
            path: Path to plugin file or directory
            
        Returns:
            Plugin class if loaded successfully
        """
        try:
            # Determine plugin file
            if path.is_dir():
                plugin_file = path / self.PLUGIN_FILE
            else:
                plugin_file = path
            
            if not plugin_file.exists():
                raise PluginLoadError(f"Plugin file not found: {plugin_file}")
            
            # Check requirements
            if self.check_requirements:
                requirements_file = plugin_file.parent / self.REQUIREMENTS_FILE
                if requirements_file.exists():
                    await self._check_requirements(requirements_file)
            
            # Load module
            module = await self._load_module(plugin_file)
            
            if not module:
                raise PluginLoadError("Failed to load module")
            
            # Find plugin class
            plugin_class = self._find_plugin_class(module)
            
            if not plugin_class:
                raise PluginLoadError("No PluginBase subclass found in module")
            
            # Validate plugin class
            if self.validate_metadata:
                await self._validate_plugin_class(plugin_class)
            
            return plugin_class
            
        except PluginLoadError:
            raise
        except Exception as e:
            raise PluginLoadError(f"Error loading plugin: {e}")
    
    async def _load_module(self, plugin_file: Path, temp: bool = False) -> Optional[Any]:
        """
        Load a Python module from file.
        
        Args:
            plugin_file: Path to Python file
            temp: If True, use temporary module name
            
        Returns:
            Loaded module
        """
        try:
            # Generate unique module name
            self._module_counter += 1
            
            if temp:
                module_name = f"_temp_plugin_{self._module_counter}"
            else:
                module_name = f"plugin_{plugin_file.stem}_{self._module_counter}"
            
            # Create module spec
            spec = importlib.util.spec_from_file_location(
                module_name,
                plugin_file
            )
            
            if not spec or not spec.loader:
                return None
            
            # Create module
            module = importlib.util.module_from_spec(spec)
            
            # Add to sys.modules temporarily
            sys.modules[module_name] = module
            
            try:
                # Execute module
                spec.loader.exec_module(module)
                
                if not temp:
                    # Cache loaded module
                    self._loaded_modules[str(plugin_file)] = LoadedModule(
                        module_name=module_name,
                        module=module,
                        plugin_class=self._find_plugin_class(module),
                        metadata=None,  # Will be set later
                        source_path=plugin_file,
                    )
                
                return module
                
            finally:
                if temp:
                    # Clean up temporary module
                    sys.modules.pop(module_name, None)
                    
        except Exception as e:
            self.logger.error(f"Error loading module {plugin_file}: {e}")
            return None
    
    def _find_plugin_class(self, module: Any) -> Optional[Type[PluginBase]]:
        """
        Find the PluginBase subclass in a module.
        
        Args:
            module: Loaded Python module
            
        Returns:
            Plugin class if found
        """
        for name in dir(module):
            if name.startswith('_'):
                continue
            
            obj = getattr(module, name)
            
            try:
                if (
                    isinstance(obj, type) and
                    issubclass(obj, PluginBase) and
                    obj is not PluginBase
                ):
                    return obj
            except TypeError:
                continue
        
        return None
    
    async def _validate_plugin_class(self, plugin_class: Type[PluginBase]) -> None:
        """
        Validate a plugin class.
        
        Args:
            plugin_class: Plugin class to validate
            
        Raises:
            PluginValidationError: If validation fails
        """
        errors = []
        
        # Check required methods
        if not hasattr(plugin_class, 'get_metadata'):
            errors.append("Missing get_metadata() method")
        
        if not hasattr(plugin_class, 'initialize'):
            errors.append("Missing initialize() method")
        
        # Check metadata
        try:
            metadata = plugin_class.get_metadata()
            
            if not metadata.id:
                errors.append("Metadata missing 'id'")
            
            if not metadata.name:
                errors.append("Metadata missing 'name'")
            
            if not metadata.version:
                errors.append("Metadata missing 'version'")
                
        except Exception as e:
            errors.append(f"Error getting metadata: {e}")
        
        if errors:
            raise PluginValidationError(f"Plugin validation failed: {', '.join(errors)}")
    
    async def _check_requirements(self, requirements_file: Path) -> None:
        """
        Check if plugin requirements are satisfied.
        
        Args:
            requirements_file: Path to requirements.txt
            
        Raises:
            PluginLoadError: If requirements not met
        """
        missing = []
        
        try:
            with open(requirements_file, 'r') as f:
                for line in f:
                    line = line.strip()
                    
                    if not line or line.startswith('#'):
                        continue
                    
                    # Parse requirement (simple version)
                    package = line.split('>=')[0].split('==')[0].split('<')[0].strip()
                    
                    try:
                        importlib.import_module(package)
                    except ImportError:
                        missing.append(package)
            
            if missing:
                raise PluginLoadError(
                    f"Missing required packages: {', '.join(missing)}. "
                    f"Install with: pip install {' '.join(missing)}"
                )
                
        except PluginLoadError:
            raise
        except Exception as e:
            self.logger.warning(f"Could not check requirements: {e}")
    
    async def reload_plugin(self, path: Path) -> Optional[Type[PluginBase]]:
        """
        Reload a plugin (hot reload).
        
        Args:
            path: Path to plugin
            
        Returns:
            Reloaded plugin class
        """
        path_str = str(path)
        
        # Unload existing
        if path_str in self._loaded_modules:
            loaded = self._loaded_modules[path_str]
            
            # Remove from sys.modules
            sys.modules.pop(loaded.module_name, None)
            
            # Remove from cache
            del self._loaded_modules[path_str]
        
        # Reload
        return await self.load_plugin(path)
    
    async def unload_plugin(self, path: Path) -> bool:
        """
        Unload a plugin module.
        
        Args:
            path: Path to plugin
            
        Returns:
            True if unloaded
        """
        path_str = str(path)
        
        if path_str not in self._loaded_modules:
            return False
        
        loaded = self._loaded_modules[path_str]
        
        # Remove from sys.modules
        sys.modules.pop(loaded.module_name, None)
        
        # Remove from cache
        del self._loaded_modules[path_str]
        
        return True
    
    def get_loaded_modules(self) -> Dict[str, LoadedModule]:
        """Get all loaded modules."""
        return self._loaded_modules.copy()


class PluginSandbox:
    """
    ═══════════════════════════════════════════════════════════════════════════
    PLUGIN SANDBOX
    ═══════════════════════════════════════════════════════════════════════════
    
    Provides isolation for plugin execution (optional security feature).
    """
    
    # Restricted modules
    BLOCKED_MODULES = {
        'os.system',
        'subprocess',
        'shutil.rmtree',
        'pathlib.Path.unlink',
        '__builtins__.eval',
        '__builtins__.exec',
        '__builtins__.compile',
    }
    
    # Allowed modules
    ALLOWED_MODULES = {
        'json',
        'yaml',
        'datetime',
        'typing',
        'dataclasses',
        'enum',
        'logging',
        'asyncio',
        're',
        'math',
        'random',
        'hashlib',
        'base64',
        'urllib.parse',
        'collections',
        'itertools',
        'functools',
    }
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize sandbox."""
        self.config = config or {}
        self.logger = logging.getLogger("plugins.sandbox")
        
        self.enabled = self.config.get('enabled', False)
        self.strict_mode = self.config.get('strict_mode', False)
    
    def check_import(self, module_name: str) -> bool:
        """
        Check if a module import is allowed.
        
        Args:
            module_name: Module being imported
            
        Returns:
            True if allowed
        """
        if not self.enabled:
            return True
        
        # Check blocked
        for blocked in self.BLOCKED_MODULES:
            if module_name.startswith(blocked):
                self.logger.warning(f"Blocked import: {module_name}")
                return False
        
        # In strict mode, only allow whitelisted
        if self.strict_mode:
            allowed = any(
                module_name.startswith(m) for m in self.ALLOWED_MODULES
            )
            if not allowed:
                self.logger.warning(f"Module not in whitelist: {module_name}")
                return False
        
        return True
    
    def wrap_execution(self, func: Any) -> Any:
        """
        Wrap a function for sandboxed execution.
        
        Args:
            func: Function to wrap
            
        Returns:
            Wrapped function
        """
        if not self.enabled:
            return func
        
        async def wrapper(*args, **kwargs):
            # Add execution limits here if needed
            try:
                if asyncio.iscoroutinefunction(func):
                    return await asyncio.wait_for(
                        func(*args, **kwargs),
                        timeout=30.0  # 30 second timeout
                    )
                else:
                    return func(*args, **kwargs)
            except asyncio.TimeoutError:
                raise PluginLoadError("Plugin execution timed out")
        
        return wrapper


# ═══════════════════════════════════════════════════════════════════════════════
#                          EXAMPLE PLUGIN TEMPLATE
# ═══════════════════════════════════════════════════════════════════════════════

EXAMPLE_PLUGIN_TEMPLATE = '''
"""
Example Plugin for Autonomous Agent
"""

from plugins.plugin_base import PluginBase, PluginMetadata, PluginCapability


class ExamplePlugin(PluginBase):
    """Example plugin implementation."""
    
    @classmethod
    def get_metadata(cls) -> PluginMetadata:
        return PluginMetadata(
            id="example_plugin",
            name="Example Plugin",
            version="1.0.0",
            description="An example plugin demonstrating the plugin system",
            author="Your Name",
            capabilities=[PluginCapability.MESSAGE_HANDLER],
            dependencies=[],
            tags=["example", "demo"],
        )
    
    async def initialize(self) -> None:
        """Initialize the plugin."""
        self.logger.info("Example plugin initialized!")
        
        # Register hooks
        self.register_hook("on_message", self.on_message)
    
    async def on_message(self, message: str, context: dict) -> str | None:
        """Handle incoming messages."""
        
        # Example: respond to specific keywords
        if "hello plugin" in message.lower():
            return "Hello from the example plugin!"
        
        return None
    
    async def cleanup(self) -> None:
        """Cleanup when unloaded."""
        self.logger.info("Example plugin cleanup")
'''

EXAMPLE_METADATA_TEMPLATE = '''
# Plugin Metadata
id: example_plugin
name: Example Plugin
version: 1.0.0
description: An example plugin demonstrating the plugin system

author: Your Name
author_email: your.email@example.com
homepage: https://github.com/yourusername/example-plugin

capabilities:
  - message_handler

dependencies: []

min_agent_version: "3.0.0"

permissions:
  - memory_read
  - memory_write

priority: 100

tags:
  - example
  - demo

license: MIT
'''