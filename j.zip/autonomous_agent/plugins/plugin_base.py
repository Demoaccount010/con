#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 PLUGIN BASE - Abstract base class for all plugins
═══════════════════════════════════════════════════════════════════════════════

 All plugins MUST inherit from this class.
 
 PLUGIN STRUCTURE:
 ─────────────────
 /plugins/installed/my_plugin/
 ├── plugin.py          # Main plugin file (contains MyPlugin class)
 ├── plugin.yaml        # Plugin metadata
 ├── requirements.txt   # Python dependencies (optional)
 └── README.md          # Documentation (optional)

 PLUGIN CAPABILITIES:
 ────────────────────
 • TOOL_PROVIDER      - Provides new tools
 • MESSAGE_HANDLER    - Handles messages
 • MEMORY_PROVIDER    - Provides memory storage
 • NOTIFICATION       - Sends notifications
 • RESEARCH           - Research capabilities
 • INTEGRATION        - External integrations
 • UI_EXTENSION       - UI extensions
 • SCHEDULER          - Scheduling capabilities

 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import logging
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Optional, Dict, Any, List, Callable
from dataclasses import dataclass, field
from enum import Enum


class PluginCapability(Enum):
    """Capabilities a plugin can provide."""
    TOOL_PROVIDER = "tool_provider"
    MESSAGE_HANDLER = "message_handler"
    MEMORY_PROVIDER = "memory_provider"
    NOTIFICATION = "notification"
    RESEARCH = "research"
    INTEGRATION = "integration"
    UI_EXTENSION = "ui_extension"
    SCHEDULER = "scheduler"
    CUSTOM = "custom"


@dataclass
class PluginMetadata:
    """
    Metadata describing a plugin.
    
    This information is loaded from plugin.yaml or defined in the plugin class.
    """
    # Required
    id: str                                     # Unique identifier
    name: str                                   # Display name
    version: str                                # Semantic version
    
    # Description
    description: str = ""
    long_description: str = ""
    
    # Author info
    author: str = ""
    author_email: str = ""
    homepage: str = ""
    repository: str = ""
    
    # Capabilities
    capabilities: List[PluginCapability] = field(default_factory=list)
    
    # Dependencies
    dependencies: List[str] = field(default_factory=list)  # Python packages or plugin:id
    
    # Compatibility
    min_agent_version: str = "3.0.0"
    max_agent_version: Optional[str] = None
    
    # Permissions required
    permissions: List[str] = field(default_factory=list)
    
    # Priority (lower = higher priority)
    priority: int = 100
    
    # Tags for categorization
    tags: List[str] = field(default_factory=list)
    
    # License
    license: str = "MIT"
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'PluginMetadata':
        """Create from dictionary."""
        # Convert capability strings to enums
        capabilities = []
        for cap in data.get('capabilities', []):
            try:
                if isinstance(cap, str):
                    capabilities.append(PluginCapability(cap))
                else:
                    capabilities.append(cap)
            except ValueError:
                capabilities.append(PluginCapability.CUSTOM)
        
        return cls(
            id=data.get('id', ''),
            name=data.get('name', ''),
            version=data.get('version', '1.0.0'),
            description=data.get('description', ''),
            long_description=data.get('long_description', ''),
            author=data.get('author', ''),
            author_email=data.get('author_email', ''),
            homepage=data.get('homepage', ''),
            repository=data.get('repository', ''),
            capabilities=capabilities,
            dependencies=data.get('dependencies', []),
            min_agent_version=data.get('min_agent_version', '3.0.0'),
            max_agent_version=data.get('max_agent_version'),
            permissions=data.get('permissions', []),
            priority=data.get('priority', 100),
            tags=data.get('tags', []),
            license=data.get('license', 'MIT'),
        )


class PluginContext:
    """
    Context provided to plugins for accessing agent functionality.
    """
    
    def __init__(self, plugin: 'PluginBase'):
        self._plugin = plugin
    
    @property
    def agent(self):
        """Access to agent functionality."""
        return self._plugin._agent
    
    @property
    def memory(self):
        """Access to memory system."""
        return self._plugin._memory
    
    @property
    def tools(self):
        """Access to tool registry."""
        return self._plugin._tools
    
    @property
    def plugin_manager(self):
        """Access to plugin manager."""
        return self._plugin._plugin_manager
    
    @property
    def logger(self):
        """Plugin-specific logger."""
        return self._plugin.logger
    
    @property
    def config(self):
        """Plugin configuration."""
        return self._plugin.config
    
    async def send_notification(self, message: str, **kwargs) -> bool:
        """Send a notification (if notification system available)."""
        if self._plugin._agent:
            # Would use notification manager
            pass
        return False
    
    async def store_memory(self, key: str, value: Any, **kwargs) -> bool:
        """Store something in memory."""
        if self._plugin._memory:
            await self._plugin._memory.store(
                key=key,
                value=value,
                source=f"plugin:{self._plugin.plugin_id}",
                **kwargs
            )
            return True
        return False
    
    async def get_memory(self, key: str, **kwargs) -> Optional[Any]:
        """Retrieve from memory."""
        if self._plugin._memory:
            return await self._plugin._memory.get(key, **kwargs)
        return None


class PluginBase(ABC):
    """
    ═══════════════════════════════════════════════════════════════════════════
    ABSTRACT PLUGIN BASE CLASS
    ═══════════════════════════════════════════════════════════════════════════
    
    All plugins must inherit from this class and implement:
    - get_metadata() - Return plugin metadata
    - initialize() - Initialize the plugin
    - execute() - Main plugin functionality (optional)
    """
    
    # Class-level metadata (can be overridden by plugin.yaml)
    METADATA: Optional[PluginMetadata] = None
    
    def __init__(
        self,
        plugin_id: str,
        config: Optional[Dict[str, Any]] = None
    ):
        """
        Initialize plugin base.
        
        Args:
            plugin_id: Unique plugin identifier
            config: Plugin configuration
        """
        self.plugin_id = plugin_id
        self.config = config or {}
        self.logger = logging.getLogger(f"plugins.{plugin_id}")
        
        # These are injected by PluginManager
        self._agent = None
        self._memory = None
        self._tools = None
        self._plugin_manager = None
        
        # Plugin state
        self._initialized = False
        self._enabled = False
        
        # Context for easy access
        self._context: Optional[PluginContext] = None
        
        # Registered hooks
        self._hooks: Dict[str, Callable] = {}
        
        # Statistics
        self.stats = {
            'calls': 0,
            'errors': 0,
            'last_called': None,
        }
    
    @property
    def context(self) -> PluginContext:
        """Get plugin context for accessing agent functionality."""
        if not self._context:
            self._context = PluginContext(self)
        return self._context
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          ABSTRACT METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    @classmethod
    @abstractmethod
    def get_metadata(cls) -> PluginMetadata:
        """
        Return plugin metadata.
        
        Must be implemented by all plugins.
        
        Returns:
            PluginMetadata instance
        """
        pass
    
    @abstractmethod
    async def initialize(self) -> None:
        """
        Initialize the plugin.
        
        Called once when the plugin is first loaded.
        Use this for:
        - Setting up resources
        - Loading configuration
        - Initializing state
        """
        pass
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          LIFECYCLE HOOKS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def on_enable(self) -> None:
        """
        Called when the plugin is enabled.
        
        Override to perform actions when enabled.
        """
        self._enabled = True
        self.logger.debug(f"Plugin {self.plugin_id} enabled")
    
    async def on_disable(self) -> None:
        """
        Called when the plugin is disabled.
        
        Override to perform cleanup when disabled.
        """
        self._enabled = False
        self.logger.debug(f"Plugin {self.plugin_id} disabled")
    
    async def cleanup(self) -> None:
        """
        Cleanup resources when plugin is unloaded.
        
        Override to clean up resources.
        """
        self.logger.debug(f"Plugin {self.plugin_id} cleanup")
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          HOOKS REGISTRATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    def register_hook(self, hook_name: str, handler: Callable) -> None:
        """
        Register a hook handler.
        
        Args:
            hook_name: Name of the hook
            handler: Function to handle the hook
        """
        self._hooks[hook_name] = handler
        self.logger.debug(f"Registered hook: {hook_name}")
    
    def unregister_hook(self, hook_name: str) -> None:
        """Unregister a hook handler."""
        if hook_name in self._hooks:
            del self._hooks[hook_name]
    
    def get_hooks(self) -> Dict[str, Callable]:
        """Get all registered hooks."""
        return self._hooks.copy()
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          COMMON HOOKS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def on_message(self, message: str, context: Dict[str, Any]) -> Optional[str]:
        """
        Hook for processing messages.
        
        Override to handle messages.
        
        Args:
            message: User message
            context: Message context
            
        Returns:
            Optional response to inject
        """
        return None
    
    async def on_before_think(self, input_text: str, context: Dict[str, Any]) -> Optional[str]:
        """
        Hook called before thinking phase.
        
        Can modify the input or add context.
        
        Args:
            input_text: Original input
            context: Current context
            
        Returns:
            Modified input or None
        """
        return None
    
    async def on_after_think(self, result: Any, context: Dict[str, Any]) -> Optional[Any]:
        """
        Hook called after thinking phase.
        
        Can modify or extend the result.
        """
        return None
    
    async def on_before_execute(self, tool_name: str, params: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Hook called before tool execution.
        
        Can modify parameters or block execution (return None to block).
        """
        return params
    
    async def on_after_execute(self, tool_name: str, result: Any) -> Optional[Any]:
        """
        Hook called after tool execution.
        
        Can modify or log the result.
        """
        return result
    
    async def on_memory_change(self, change_type: str, key: str, value: Any) -> None:
        """
        Hook called when memory changes.
        
        Can react to memory updates.
        """
        pass
    
    async def on_error(self, error: Exception, context: Dict[str, Any]) -> Optional[str]:
        """
        Hook called when an error occurs.
        
        Can provide error handling or recovery.
        """
        return None
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          UTILITY METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_config_value(self, key: str, default: Any = None) -> Any:
        """Get a configuration value."""
        return self.config.get(key, default)
    
    def is_enabled(self) -> bool:
        """Check if plugin is enabled."""
        return self._enabled
    
    def is_initialized(self) -> bool:
        """Check if plugin is initialized."""
        return self._initialized
    
    def record_call(self) -> None:
        """Record a plugin call for statistics."""
        self.stats['calls'] += 1
        self.stats['last_called'] = datetime.utcnow()
    
    def record_error(self) -> None:
        """Record an error for statistics."""
        self.stats['errors'] += 1
    
    def __repr__(self) -> str:
        return f"<Plugin {self.plugin_id} enabled={self._enabled}>"


class ToolProviderPlugin(PluginBase):
    """
    Base class for plugins that provide tools.
    
    Inherit from this for easy tool registration.
    """
    
    @abstractmethod
    def get_tools(self) -> List[Dict[str, Any]]:
        """
        Return list of tools this plugin provides.
        
        Returns:
            List of tool definitions
        """
        pass
    
    async def on_enable(self) -> None:
        """Register tools when enabled."""
        await super().on_enable()
        
        if self._tools:
            for tool_def in self.get_tools():
                # Register tool with tool registry
                pass


class IntegrationPlugin(PluginBase):
    """
    Base class for integration plugins.
    
    Inherit from this for external service integrations.
    """
    
    @abstractmethod
    async def connect(self) -> bool:
        """Connect to the external service."""
        pass
    
    @abstractmethod
    async def disconnect(self) -> None:
        """Disconnect from the external service."""
        pass
    
    @abstractmethod
    async def is_connected(self) -> bool:
        """Check if connected."""
        pass
    
    async def on_enable(self) -> None:
        """Connect when enabled."""
        await super().on_enable()
        await self.connect()
    
    async def on_disable(self) -> None:
        """Disconnect when disabled."""
        await self.disconnect()
        await super().on_disable()