#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 PLUGIN MANAGER - Central plugin orchestration system
═══════════════════════════════════════════════════════════════════════════════

 Manages the complete plugin lifecycle:
 • Discovery and loading
 • Initialization and configuration
 • Enable/Disable controls
 • Dependency resolution
 • Hot reload support
 • Plugin isolation

 PLUGIN STATES:
 ──────────────
 DISCOVERED → LOADED → INITIALIZED → ENABLED → DISABLED → UNLOADED

 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
import importlib
import sys
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any, List, Type, Set, Callable
from dataclasses import dataclass, field
from enum import Enum

from plugins.plugin_base import PluginBase, PluginMetadata, PluginCapability
from plugins.plugin_loader import PluginLoader, PluginLoadError


class PluginState(Enum):
    """Plugin lifecycle states."""
    DISCOVERED = "discovered"
    LOADING = "loading"
    LOADED = "loaded"
    INITIALIZING = "initializing"
    INITIALIZED = "initialized"
    ENABLING = "enabling"
    ENABLED = "enabled"
    DISABLING = "disabling"
    DISABLED = "disabled"
    UNLOADING = "unloading"
    UNLOADED = "unloaded"
    ERROR = "error"


@dataclass
class PluginInfo:
    """Complete information about a loaded plugin."""
    # Identification
    id: str
    name: str
    version: str
    
    # Metadata
    metadata: PluginMetadata
    
    # State
    state: PluginState = PluginState.DISCOVERED
    error: Optional[str] = None
    
    # Instance
    instance: Optional[PluginBase] = None
    plugin_class: Optional[Type[PluginBase]] = None
    
    # Source
    source_path: Optional[Path] = None
    module_name: Optional[str] = None
    
    # Timing
    discovered_at: datetime = field(default_factory=datetime.utcnow)
    loaded_at: Optional[datetime] = None
    enabled_at: Optional[datetime] = None
    
    # Statistics
    call_count: int = 0
    error_count: int = 0
    total_execution_ms: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'id': self.id,
            'name': self.name,
            'version': self.version,
            'state': self.state.value,
            'error': self.error,
            'description': self.metadata.description,
            'author': self.metadata.author,
            'capabilities': [c.value for c in self.metadata.capabilities],
            'dependencies': self.metadata.dependencies,
            'enabled_at': self.enabled_at.isoformat() if self.enabled_at else None,
            'call_count': self.call_count,
            'error_count': self.error_count,
        }


class PluginManager:
    """
    ═══════════════════════════════════════════════════════════════════════════
    CENTRAL PLUGIN MANAGER
    ═══════════════════════════════════════════════════════════════════════════
    
    Manages all plugins in the system.
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize plugin manager.
        
        Args:
            config: Configuration dictionary
        """
        self.logger = logging.getLogger("plugins.manager")
        self.config = config or {}
        
        # Plugin storage
        self.plugins: Dict[str, PluginInfo] = {}
        
        # Plugin loader
        self.loader = PluginLoader(config.get('loader', {}))
        
        # Configuration
        self.plugins_dir = Path(self.config.get('plugins_dir', './plugins/installed'))
        self.auto_enable = self.config.get('auto_enable', True)
        self.sandbox_enabled = self.config.get('sandbox_enabled', True)
        
        # Hooks registry
        self._hooks: Dict[str, List[Callable]] = {}
        
        # Agent reference (set during initialization)
        self._agent = None
        self._memory = None
        self._tools = None
        
        # Lock for thread safety
        self._lock = asyncio.Lock()
        
        # Statistics
        self.stats = {
            'total_loaded': 0,
            'total_enabled': 0,
            'total_errors': 0,
            'total_calls': 0,
        }
    
    async def initialize(
        self,
        agent=None,
        memory=None,
        tools=None
    ) -> None:
        """
        Initialize the plugin manager.
        
        Args:
            agent: Agent instance for plugins to use
            memory: Memory manager for plugins
            tools: Tool registry for plugins
        """
        self.logger.info("Initializing plugin manager...")
        
        self._agent = agent
        self._memory = memory
        self._tools = tools
        
        # Create plugins directory if not exists
        self.plugins_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize loader
        await self.loader.initialize()
        
        # Discover plugins
        await self.discover()
        
        self.logger.info(f"Plugin manager initialized. Found {len(self.plugins)} plugins.")
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          PLUGIN DISCOVERY
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def discover(self) -> List[str]:
        """
        Discover all available plugins.
        
        Returns:
            List of discovered plugin IDs
        """
        self.logger.info(f"Discovering plugins in {self.plugins_dir}")
        discovered = []
        
        async with self._lock:
            # Scan plugins directory
            if self.plugins_dir.exists():
                for item in self.plugins_dir.iterdir():
                    if item.is_dir() and not item.name.startswith('_'):
                        plugin_file = item / 'plugin.py'
                        if plugin_file.exists():
                            try:
                                plugin_id = await self._discover_plugin(item)
                                if plugin_id:
                                    discovered.append(plugin_id)
                            except Exception as e:
                                self.logger.error(f"Error discovering plugin in {item}: {e}")
                    
                    elif item.is_file() and item.suffix == '.py' and not item.name.startswith('_'):
                        try:
                            plugin_id = await self._discover_plugin(item)
                            if plugin_id:
                                discovered.append(plugin_id)
                        except Exception as e:
                            self.logger.error(f"Error discovering plugin {item}: {e}")
        
        self.logger.info(f"Discovered {len(discovered)} plugins")
        return discovered
    
    async def _discover_plugin(self, path: Path) -> Optional[str]:
        """Discover a single plugin."""
        try:
            # Load metadata without fully loading the plugin
            metadata = await self.loader.load_metadata(path)
            
            if not metadata:
                return None
            
            plugin_id = metadata.id
            
            # Create plugin info
            info = PluginInfo(
                id=plugin_id,
                name=metadata.name,
                version=metadata.version,
                metadata=metadata,
                state=PluginState.DISCOVERED,
                source_path=path,
            )
            
            self.plugins[plugin_id] = info
            self.logger.debug(f"Discovered plugin: {plugin_id}")
            
            return plugin_id
            
        except Exception as e:
            self.logger.error(f"Failed to discover plugin at {path}: {e}")
            return None
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          PLUGIN LOADING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def load(self, plugin_id: str) -> bool:
        """
        Load a plugin.
        
        Args:
            plugin_id: ID of plugin to load
            
        Returns:
            True if loaded successfully
        """
        async with self._lock:
            info = self.plugins.get(plugin_id)
            if not info:
                self.logger.error(f"Plugin not found: {plugin_id}")
                return False
            
            if info.state not in [PluginState.DISCOVERED, PluginState.UNLOADED, PluginState.ERROR]:
                self.logger.warning(f"Plugin {plugin_id} already loaded (state: {info.state})")
                return True
            
            try:
                info.state = PluginState.LOADING
                
                # Check dependencies
                missing_deps = await self._check_dependencies(info)
                if missing_deps:
                    raise PluginLoadError(f"Missing dependencies: {missing_deps}")
                
                # Load plugin class
                plugin_class = await self.loader.load_plugin(info.source_path)
                
                if not plugin_class:
                    raise PluginLoadError("Failed to load plugin class")
                
                # Validate plugin class
                if not issubclass(plugin_class, PluginBase):
                    raise PluginLoadError("Plugin must inherit from PluginBase")
                
                info.plugin_class = plugin_class
                info.state = PluginState.LOADED
                info.loaded_at = datetime.utcnow()
                
                self.stats['total_loaded'] += 1
                self.logger.info(f"Loaded plugin: {plugin_id}")
                
                return True
                
            except Exception as e:
                info.state = PluginState.ERROR
                info.error = str(e)
                self.stats['total_errors'] += 1
                self.logger.error(f"Failed to load plugin {plugin_id}: {e}")
                return False
    
    async def load_all(self) -> Dict[str, bool]:
        """
        Load all discovered plugins.
        
        Returns:
            Dict mapping plugin_id to success status
        """
        results = {}
        
        for plugin_id in list(self.plugins.keys()):
            results[plugin_id] = await self.load(plugin_id)
        
        return results
    
    async def unload(self, plugin_id: str) -> bool:
        """
        Unload a plugin.
        
        Args:
            plugin_id: ID of plugin to unload
            
        Returns:
            True if unloaded successfully
        """
        async with self._lock:
            info = self.plugins.get(plugin_id)
            if not info:
                return False
            
            # Disable first if enabled
            if info.state == PluginState.ENABLED:
                await self._disable_internal(info)
            
            try:
                info.state = PluginState.UNLOADING
                
                # Cleanup instance
                if info.instance:
                    try:
                        await info.instance.cleanup()
                    except Exception as e:
                        self.logger.error(f"Error during plugin cleanup: {e}")
                    info.instance = None
                
                info.plugin_class = None
                info.state = PluginState.UNLOADED
                
                self.logger.info(f"Unloaded plugin: {plugin_id}")
                return True
                
            except Exception as e:
                info.state = PluginState.ERROR
                info.error = str(e)
                self.logger.error(f"Failed to unload plugin {plugin_id}: {e}")
                return False
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          PLUGIN ENABLE/DISABLE
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def enable(self, plugin_id: str) -> bool:
        """
        Enable a plugin.
        
        Args:
            plugin_id: ID of plugin to enable
            
        Returns:
            True if enabled successfully
        """
        async with self._lock:
            info = self.plugins.get(plugin_id)
            if not info:
                self.logger.error(f"Plugin not found: {plugin_id}")
                return False
            
            # Load first if needed
            if info.state == PluginState.DISCOVERED:
                if not await self.load(plugin_id):
                    return False
                info = self.plugins[plugin_id]
            
            if info.state == PluginState.ENABLED:
                return True
            
            if info.state not in [PluginState.LOADED, PluginState.INITIALIZED, PluginState.DISABLED]:
                self.logger.error(f"Cannot enable plugin in state: {info.state}")
                return False
            
            return await self._enable_internal(info)
    
    async def _enable_internal(self, info: PluginInfo) -> bool:
        """Internal enable logic."""
        try:
            info.state = PluginState.ENABLING
            
            # Create instance if needed
            if not info.instance:
                info.state = PluginState.INITIALIZING
                
                info.instance = info.plugin_class(
                    plugin_id=info.id,
                    config=self.config.get('plugin_configs', {}).get(info.id, {})
                )
                
                # Inject dependencies
                info.instance._agent = self._agent
                info.instance._memory = self._memory
                info.instance._tools = self._tools
                info.instance._plugin_manager = self
                
                # Initialize
                await info.instance.initialize()
                info.state = PluginState.INITIALIZED
            
            # Enable
            info.state = PluginState.ENABLING
            await info.instance.on_enable()
            
            # Register hooks
            await self._register_plugin_hooks(info)
            
            info.state = PluginState.ENABLED
            info.enabled_at = datetime.utcnow()
            info.error = None
            
            self.stats['total_enabled'] += 1
            self.logger.info(f"Enabled plugin: {info.id}")
            
            return True
            
        except Exception as e:
            info.state = PluginState.ERROR
            info.error = str(e)
            self.stats['total_errors'] += 1
            self.logger.error(f"Failed to enable plugin {info.id}: {e}")
            return False
    
    async def disable(self, plugin_id: str) -> bool:
        """
        Disable a plugin.
        
        Args:
            plugin_id: ID of plugin to disable
            
        Returns:
            True if disabled successfully
        """
        async with self._lock:
            info = self.plugins.get(plugin_id)
            if not info:
                return False
            
            if info.state != PluginState.ENABLED:
                return True
            
            return await self._disable_internal(info)
    
    async def _disable_internal(self, info: PluginInfo) -> bool:
        """Internal disable logic."""
        try:
            info.state = PluginState.DISABLING
            
            # Unregister hooks
            await self._unregister_plugin_hooks(info)
            
            # Call disable handler
            if info.instance:
                await info.instance.on_disable()
            
            info.state = PluginState.DISABLED
            self.stats['total_enabled'] -= 1
            
            self.logger.info(f"Disabled plugin: {info.id}")
            return True
            
        except Exception as e:
            info.state = PluginState.ERROR
            info.error = str(e)
            self.logger.error(f"Failed to disable plugin {info.id}: {e}")
            return False
    
    async def enable_all(self) -> Dict[str, bool]:
        """Enable all loaded plugins."""
        results = {}
        
        # Sort by dependencies
        sorted_plugins = await self._sort_by_dependencies()
        
        for plugin_id in sorted_plugins:
            results[plugin_id] = await self.enable(plugin_id)
        
        return results
    
    async def disable_all(self) -> Dict[str, bool]:
        """Disable all enabled plugins."""
        results = {}
        
        # Disable in reverse dependency order
        sorted_plugins = await self._sort_by_dependencies()
        sorted_plugins.reverse()
        
        for plugin_id in sorted_plugins:
            info = self.plugins.get(plugin_id)
            if info and info.state == PluginState.ENABLED:
                results[plugin_id] = await self.disable(plugin_id)
        
        return results
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          HOOKS SYSTEM
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _register_plugin_hooks(self, info: PluginInfo) -> None:
        """Register hooks from a plugin."""
        if not info.instance:
            return
        
        hooks = info.instance.get_hooks()
        
        for hook_name, handler in hooks.items():
            if hook_name not in self._hooks:
                self._hooks[hook_name] = []
            
            self._hooks[hook_name].append({
                'plugin_id': info.id,
                'handler': handler,
                'priority': info.metadata.priority,
            })
            
            # Sort by priority
            self._hooks[hook_name].sort(key=lambda x: x.get('priority', 100))
            
            self.logger.debug(f"Registered hook '{hook_name}' from plugin {info.id}")
    
    async def _unregister_plugin_hooks(self, info: PluginInfo) -> None:
        """Unregister hooks from a plugin."""
        for hook_name in list(self._hooks.keys()):
            self._hooks[hook_name] = [
                h for h in self._hooks[hook_name]
                if h['plugin_id'] != info.id
            ]
            
            # Remove empty hook lists
            if not self._hooks[hook_name]:
                del self._hooks[hook_name]
    
    async def trigger_hook(
        self,
        hook_name: str,
        *args,
        stop_on_result: bool = False,
        **kwargs
    ) -> List[Any]:
        """
        Trigger a hook and collect results from all handlers.
        
        Args:
            hook_name: Name of hook to trigger
            *args: Arguments to pass to handlers
            stop_on_result: Stop after first non-None result
            **kwargs: Keyword arguments to pass to handlers
            
        Returns:
            List of results from handlers
        """
        results = []
        
        handlers = self._hooks.get(hook_name, [])
        
        for handler_info in handlers:
            try:
                handler = handler_info['handler']
                
                if asyncio.iscoroutinefunction(handler):
                    result = await handler(*args, **kwargs)
                else:
                    result = handler(*args, **kwargs)
                
                results.append(result)
                
                # Track call
                plugin_info = self.plugins.get(handler_info['plugin_id'])
                if plugin_info:
                    plugin_info.call_count += 1
                    self.stats['total_calls'] += 1
                
                if stop_on_result and result is not None:
                    break
                    
            except Exception as e:
                self.logger.error(
                    f"Error in hook '{hook_name}' from plugin {handler_info['plugin_id']}: {e}"
                )
                plugin_info = self.plugins.get(handler_info['plugin_id'])
                if plugin_info:
                    plugin_info.error_count += 1
        
        return results
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          DEPENDENCY MANAGEMENT
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _check_dependencies(self, info: PluginInfo) -> List[str]:
        """Check for missing dependencies."""
        missing = []
        
        for dep in info.metadata.dependencies:
            # Check if it's a plugin dependency
            if dep.startswith('plugin:'):
                plugin_id = dep[7:]
                if plugin_id not in self.plugins:
                    missing.append(dep)
                    
            # Check if it's a Python package
            else:
                try:
                    importlib.import_module(dep)
                except ImportError:
                    missing.append(dep)
        
        return missing
    
    async def _sort_by_dependencies(self) -> List[str]:
        """Sort plugins by dependencies (topological sort)."""
        # Build dependency graph
        graph: Dict[str, Set[str]] = {}
        
        for plugin_id, info in self.plugins.items():
            graph[plugin_id] = set()
            
            for dep in info.metadata.dependencies:
                if dep.startswith('plugin:'):
                    dep_id = dep[7:]
                    if dep_id in self.plugins:
                        graph[plugin_id].add(dep_id)
        
        # Topological sort (Kahn's algorithm)
        result = []
        no_deps = [pid for pid, deps in graph.items() if not deps]
        
        while no_deps:
            plugin_id = no_deps.pop(0)
            result.append(plugin_id)
            
            for pid, deps in graph.items():
                if plugin_id in deps:
                    deps.remove(plugin_id)
                    if not deps and pid not in result and pid not in no_deps:
                        no_deps.append(pid)
        
        # Add any remaining (circular dependencies)
        for plugin_id in graph:
            if plugin_id not in result:
                result.append(plugin_id)
        
        return result
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          PLUGIN QUERIES
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_plugin(self, plugin_id: str) -> Optional[PluginInfo]:
        """Get plugin info by ID."""
        return self.plugins.get(plugin_id)
    
    def get_plugin_instance(self, plugin_id: str) -> Optional[PluginBase]:
        """Get plugin instance by ID."""
        info = self.plugins.get(plugin_id)
        return info.instance if info else None
    
    def get_enabled_plugins(self) -> List[PluginInfo]:
        """Get all enabled plugins."""
        return [
            info for info in self.plugins.values()
            if info.state == PluginState.ENABLED
        ]
    
    def get_plugins_by_capability(self, capability: PluginCapability) -> List[PluginInfo]:
        """Get plugins that have a specific capability."""
        return [
            info for info in self.plugins.values()
            if capability in info.metadata.capabilities
        ]
    
    def list_plugins(self) -> List[Dict[str, Any]]:
        """List all plugins with their status."""
        return [info.to_dict() for info in self.plugins.values()]
    
    def get_stats(self) -> Dict[str, Any]:
        """Get plugin manager statistics."""
        return {
            **self.stats,
            'total_plugins': len(self.plugins),
            'by_state': {
                state.value: sum(
                    1 for info in self.plugins.values()
                    if info.state == state
                )
                for state in PluginState
            }
        }
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          LIFECYCLE
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def shutdown(self) -> None:
        """Shutdown the plugin manager."""
        self.logger.info("Shutting down plugin manager...")
        
        # Disable all plugins
        await self.disable_all()
        
        # Unload all plugins
        for plugin_id in list(self.plugins.keys()):
            await self.unload(plugin_id)
        
        self.logger.info("Plugin manager shutdown complete")