"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                          SEARCH ENGINE                                        ║
║                  Web Search Integration for Research                          ║
╚══════════════════════════════════════════════════════════════════════════════╝

Provides integration with multiple search engines:
- DuckDuckGo (default, no API key needed)
- Google Custom Search (optional)
- Bing Search (optional)
- Wikipedia Search
"""

import asyncio
import logging
import re
from datetime import datetime
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
from enum import Enum
from abc import ABC, abstractmethod
from urllib.parse import quote_plus, urlencode

logger = logging.getLogger(__name__)


class SearchEngine(Enum):
    """Available search engines"""
    DUCKDUCKGO = "duckduckgo"
    GOOGLE = "google"
    BING = "bing"
    WIKIPEDIA = "wikipedia"
    GITHUB = "github"
    STACKOVERFLOW = "stackoverflow"


class SearchType(Enum):
    """Types of search"""
    WEB = "web"
    NEWS = "news"
    IMAGES = "images"
    VIDEOS = "videos"
    CODE = "code"
    DOCS = "docs"


@dataclass
class SearchResult:
    """A single search result"""
    title: str
    url: str
    snippet: str
    source: SearchEngine
    position: int = 0
    published_date: Optional[str] = None
    thumbnail: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "title": self.title,
            "url": self.url,
            "snippet": self.snippet,
            "source": self.source.value,
            "position": self.position,
            "published_date": self.published_date
        }


@dataclass
class SearchResponse:
    """Search response containing results"""
    query: str
    engine: SearchEngine
    results: List[SearchResult]
    total_results: Optional[int] = None
    search_time_ms: float = 0.0
    error: Optional[str] = None
    cached: bool = False
    searched_at: datetime = field(default_factory=datetime.now)
    
    @property
    def success(self) -> bool:
        return self.error is None and len(self.results) > 0
    
    @property
    def result_count(self) -> int:
        return len(self.results)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "query": self.query,
            "engine": self.engine.value,
            "results": [r.to_dict() for r in self.results],
            "total_results": self.total_results,
            "search_time_ms": self.search_time_ms,
            "result_count": self.result_count,
            "success": self.success
        }


@dataclass
class SearchConfig:
    """Search engine configuration"""
    # Engine selection
    default_engine: SearchEngine = SearchEngine.DUCKDUCKGO
    fallback_engines: List[SearchEngine] = field(default_factory=lambda: [
        SearchEngine.WIKIPEDIA
    ])
    
    # API keys (optional)
    google_api_key: Optional[str] = None
    google_cx: Optional[str] = None  # Custom Search Engine ID
    bing_api_key: Optional[str] = None
    
    # Search settings
    default_max_results: int = 10
    safe_search: bool = True
    language: str = "en"
    region: str = "us"
    
    # Caching
    cache_enabled: bool = True
    cache_ttl_minutes: int = 60
    
    # Rate limiting
    rate_limit_per_minute: int = 30


class SearchProvider(ABC):
    """Abstract base for search providers"""
    
    @property
    @abstractmethod
    def engine(self) -> SearchEngine:
        pass
    
    @abstractmethod
    async def search(
        self,
        query: str,
        max_results: int = 10,
        search_type: SearchType = SearchType.WEB
    ) -> SearchResponse:
        pass


class DuckDuckGoProvider(SearchProvider):
    """DuckDuckGo search provider (no API key needed)"""
    
    def __init__(self, internet_manager: Optional[Any] = None):
        self.internet_manager = internet_manager
        self.base_url = "https://html.duckduckgo.com/html/"
        self.api_url = "https://api.duckduckgo.com/"
    
    @property
    def engine(self) -> SearchEngine:
        return SearchEngine.DUCKDUCKGO
    
    async def search(
        self,
        query: str,
        max_results: int = 10,
        search_type: SearchType = SearchType.WEB
    ) -> SearchResponse:
        """Search using DuckDuckGo"""
        start_time = datetime.now()
        results: List[SearchResult] = []
        error = None
        
        try:
            if self.internet_manager:
                # Use HTML endpoint for web search
                response = await self.internet_manager.post(
                    self.base_url,
                    data={"q": query, "b": ""}
                )
                
                if response.ok and response.text:
                    results = self._parse_html_results(response.text, max_results)
                else:
                    error = f"HTTP {response.status_code}"
            else:
                error = "No internet manager"
                
        except Exception as e:
            error = str(e)
            logger.error(f"DuckDuckGo search error: {e}")
        
        elapsed = (datetime.now() - start_time).total_seconds() * 1000
        
        return SearchResponse(
            query=query,
            engine=self.engine,
            results=results,
            search_time_ms=elapsed,
            error=error
        )
    
    def _parse_html_results(self, html: str, max_results: int) -> List[SearchResult]:
        """Parse DuckDuckGo HTML results"""
        results = []
        
        # Find result blocks
        # Pattern for DuckDuckGo result divs
        result_pattern = re.compile(
            r'<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>([^<]+)</a>.*?'
            r'<a[^>]*class="result__snippet"[^>]*>([^<]*)</a>',
            re.DOTALL | re.IGNORECASE
        )
        
        # Alternative simpler pattern
        link_pattern = re.compile(
            r'<a[^>]*rel="nofollow"[^>]*href="([^"]+)"[^>]*>([^<]+)</a>',
            re.IGNORECASE
        )
        
        # Try to find results
        matches = result_pattern.findall(html)
        
        if not matches:
            # Try simpler pattern
            matches = link_pattern.findall(html)
            matches = [(url, title, "") for url, title in matches]
        
        for i, match in enumerate(matches):
            if i >= max_results:
                break
            
            url, title, snippet = match[0], match[1], match[2] if len(match) > 2 else ""
            
            # Skip DuckDuckGo internal links
            if "duckduckgo.com" in url:
                continue
            
            # Clean up redirect URLs
            if url.startswith("//duckduckgo.com/l/?"):
                # Extract actual URL from redirect
                url_match = re.search(r'uddg=([^&]+)', url)
                if url_match:
                    from urllib.parse import unquote
                    url = unquote(url_match.group(1))
            
            if url.startswith("http"):
                results.append(SearchResult(
                    title=self._clean_text(title),
                    url=url,
                    snippet=self._clean_text(snippet),
                    source=self.engine,
                    position=len(results) + 1
                ))
        
        return results
    
    def _clean_text(self, text: str) -> str:
        """Clean extracted text"""
        # Remove HTML tags
        text = re.sub(r'<[^>]+>', '', text)
        # Decode entities
        from html import unescape
        text = unescape(text)
        # Normalize whitespace
        text = ' '.join(text.split())
        return text.strip()
    
    async def instant_answer(self, query: str) -> Optional[Dict[str, Any]]:
        """Get DuckDuckGo instant answer"""
        if not self.internet_manager:
            return None
        
        try:
            params = {
                "q": query,
                "format": "json",
                "no_html": "1",
                "skip_disambig": "1"
            }
            
            response = await self.internet_manager.get(
                self.api_url,
                params=params
            )
            
            if response.ok and response.json_data:
                data = response.json_data
                
                if data.get("Abstract"):
                    return {
                        "answer": data["Abstract"],
                        "source": data.get("AbstractSource", ""),
                        "url": data.get("AbstractURL", ""),
                        "type": data.get("Type", "")
                    }
                
                if data.get("Answer"):
                    return {
                        "answer": data["Answer"],
                        "type": "instant"
                    }
        
        except Exception as e:
            logger.error(f"Instant answer error: {e}")
        
        return None


class WikipediaProvider(SearchProvider):
    """Wikipedia search provider"""
    
    def __init__(self, internet_manager: Optional[Any] = None, language: str = "en"):
        self.internet_manager = internet_manager
        self.language = language
        self.api_url = f"https://{language}.wikipedia.org/api/rest_v1"
        self.search_url = f"https://{language}.wikipedia.org/w/api.php"
    
    @property
    def engine(self) -> SearchEngine:
        return SearchEngine.WIKIPEDIA
    
    async def search(
        self,
        query: str,
        max_results: int = 10,
        search_type: SearchType = SearchType.WEB
    ) -> SearchResponse:
        """Search Wikipedia"""
        start_time = datetime.now()
        results: List[SearchResult] = []
        error = None
        
        try:
            if self.internet_manager:
                params = {
                    "action": "query",
                    "list": "search",
                    "srsearch": query,
                    "srlimit": max_results,
                    "format": "json",
                    "utf8": "1"
                }
                
                response = await self.internet_manager.get(
                    self.search_url,
                    params=params
                )
                
                if response.ok and response.json_data:
                    results = self._parse_results(response.json_data)
                else:
                    error = f"HTTP {response.status_code}"
            else:
                error = "No internet manager"
                
        except Exception as e:
            error = str(e)
            logger.error(f"Wikipedia search error: {e}")
        
        elapsed = (datetime.now() - start_time).total_seconds() * 1000
        
        return SearchResponse(
            query=query,
            engine=self.engine,
            results=results,
            search_time_ms=elapsed,
            error=error
        )
    
    def _parse_results(self, data: Dict) -> List[SearchResult]:
        """Parse Wikipedia API response"""
        results = []
        
        search_results = data.get("query", {}).get("search", [])
        
        for i, item in enumerate(search_results):
            title = item.get("title", "")
            snippet = item.get("snippet", "")
            
            # Clean snippet (remove HTML)
            snippet = re.sub(r'<[^>]+>', '', snippet)
            
            # Build URL
            url = f"https://{self.language}.wikipedia.org/wiki/{quote_plus(title.replace(' ', '_'))}"
            
            results.append(SearchResult(
                title=title,
                url=url,
                snippet=snippet,
                source=self.engine,
                position=i + 1
            ))
        
        return results
    
    async def get_summary(self, title: str) -> Optional[str]:
        """Get Wikipedia article summary"""
        if not self.internet_manager:
            return None
        
        try:
            url = f"{self.api_url}/page/summary/{quote_plus(title)}"
            response = await self.internet_manager.get(url)
            
            if response.ok and response.json_data:
                return response.json_data.get("extract")
        
        except Exception as e:
            logger.error(f"Wikipedia summary error: {e}")
        
        return None


class GitHubProvider(SearchProvider):
    """GitHub code search provider"""
    
    def __init__(self, internet_manager: Optional[Any] = None, token: Optional[str] = None):
        self.internet_manager = internet_manager
        self.token = token
        self.api_url = "https://api.github.com"
    
    @property
    def engine(self) -> SearchEngine:
        return SearchEngine.GITHUB
    
    async def search(
        self,
        query: str,
        max_results: int = 10,
        search_type: SearchType = SearchType.CODE
    ) -> SearchResponse:
        """Search GitHub"""
        start_time = datetime.now()
        results: List[SearchResult] = []
        error = None
        
        try:
            if self.internet_manager:
                headers = {}
                if self.token:
                    headers["Authorization"] = f"token {self.token}"
                
                # Determine search endpoint
                if search_type == SearchType.CODE:
                    endpoint = "/search/code"
                else:
                    endpoint = "/search/repositories"
                
                params = {
                    "q": query,
                    "per_page": max_results
                }
                
                response = await self.internet_manager.get(
                    f"{self.api_url}{endpoint}",
                    params=params,
                    headers=headers
                )
                
                if response.ok and response.json_data:
                    results = self._parse_results(response.json_data, search_type)
                else:
                    error = f"HTTP {response.status_code}"
            else:
                error = "No internet manager"
                
        except Exception as e:
            error = str(e)
            logger.error(f"GitHub search error: {e}")
        
        elapsed = (datetime.now() - start_time).total_seconds() * 1000
        
        return SearchResponse(
            query=query,
            engine=self.engine,
            results=results,
            search_time_ms=elapsed,
            error=error
        )
    
    def _parse_results(self, data: Dict, search_type: SearchType) -> List[SearchResult]:
        """Parse GitHub API response"""
        results = []
        
        items = data.get("items", [])
        
        for i, item in enumerate(items):
            if search_type == SearchType.CODE:
                title = item.get("name", "")
                url = item.get("html_url", "")
                snippet = f"Repository: {item.get('repository', {}).get('full_name', '')}"
            else:
                title = item.get("full_name", "")
                url = item.get("html_url", "")
                snippet = item.get("description", "") or ""
            
            results.append(SearchResult(
                title=title,
                url=url,
                snippet=snippet,
                source=self.engine,
                position=i + 1,
                metadata={
                    "stars": item.get("stargazers_count"),
                    "language": item.get("language")
                }
            ))
        
        return results


class StackOverflowProvider(SearchProvider):
    """StackOverflow search provider"""
    
    def __init__(self, internet_manager: Optional[Any] = None):
        self.internet_manager = internet_manager
        self.api_url = "https://api.stackexchange.com/2.3"
    
    @property
    def engine(self) -> SearchEngine:
        return SearchEngine.STACKOVERFLOW
    
    async def search(
        self,
        query: str,
        max_results: int = 10,
        search_type: SearchType = SearchType.WEB
    ) -> SearchResponse:
        """Search StackOverflow"""
        start_time = datetime.now()
        results: List[SearchResult] = []
        error = None
        
        try:
            if self.internet_manager:
                params = {
                    "order": "desc",
                    "sort": "relevance",
                    "intitle": query,
                    "site": "stackoverflow",
                    "pagesize": max_results
                }
                
                response = await self.internet_manager.get(
                    f"{self.api_url}/search",
                    params=params
                )
                
                if response.ok and response.json_data:
                    results = self._parse_results(response.json_data)
                else:
                    error = f"HTTP {response.status_code}"
            else:
                error = "No internet manager"
                
        except Exception as e:
            error = str(e)
            logger.error(f"StackOverflow search error: {e}")
        
        elapsed = (datetime.now() - start_time).total_seconds() * 1000
        
        return SearchResponse(
            query=query,
            engine=self.engine,
            results=results,
            search_time_ms=elapsed,
            error=error
        )
    
    def _parse_results(self, data: Dict) -> List[SearchResult]:
        """Parse StackOverflow API response"""
        results = []
        
        items = data.get("items", [])
        
        for i, item in enumerate(items):
            title = item.get("title", "")
            url = item.get("link", "")
            
            # Build snippet from tags
            tags = item.get("tags", [])
            snippet = f"Tags: {', '.join(tags)}" if tags else ""
            
            results.append(SearchResult(
                title=title,
                url=url,
                snippet=snippet,
                source=self.engine,
                position=i + 1,
                metadata={
                    "score": item.get("score"),
                    "answers": item.get("answer_count"),
                    "accepted": item.get("is_answered")
                }
            ))
        
        return results


class SearchEngineManager:
    """
    Central manager for search operations
    
    Features:
    - Multiple search engine support
    - Fallback search
    - Result caching
    - Unified API
    """
    
    def __init__(
        self,
        config: Optional[SearchConfig] = None,
        internet_manager: Optional[Any] = None
    ):
        self.config = config or SearchConfig()
        self.internet_manager = internet_manager
        
        # Initialize providers
        self._providers: Dict[SearchEngine, SearchProvider] = {}
        self._init_providers()
        
        # Cache
        self._cache: Dict[str, SearchResponse] = {}
        
        # Statistics
        self._stats = {
            "total_searches": 0,
            "successful_searches": 0,
            "failed_searches": 0,
            "cache_hits": 0
        }
        
        logger.info("SearchEngineManager initialized")
    
    def _init_providers(self) -> None:
        """Initialize search providers"""
        # Always add DuckDuckGo (no API key needed)
        self._providers[SearchEngine.DUCKDUCKGO] = DuckDuckGoProvider(
            self.internet_manager
        )
        
        # Add Wikipedia
        self._providers[SearchEngine.WIKIPEDIA] = WikipediaProvider(
            self.internet_manager,
            language=self.config.language
        )
        
        # Add GitHub
        self._providers[SearchEngine.GITHUB] = GitHubProvider(
            self.internet_manager
        )
        
        # Add StackOverflow
        self._providers[SearchEngine.STACKOVERFLOW] = StackOverflowProvider(
            self.internet_manager
        )
    
    async def search(
        self,
        query: str,
        engine: Optional[SearchEngine] = None,
        max_results: int = 10,
        search_type: SearchType = SearchType.WEB,
        use_cache: bool = True
    ) -> SearchResponse:
        """
        Perform search
        
        Args:
            query: Search query
            engine: Search engine to use (None = default)
            max_results: Maximum results
            search_type: Type of search
            use_cache: Whether to use cache
        
        Returns:
            SearchResponse with results
        """
        self._stats["total_searches"] += 1
        
        engine = engine or self.config.default_engine
        
        # Check cache
        if use_cache and self.config.cache_enabled:
            cache_key = f"{engine.value}:{query}:{max_results}"
            if cache_key in self._cache:
                cached = self._cache[cache_key]
                # Check if still valid (simple TTL check)
                age = (datetime.now() - cached.searched_at).total_seconds() / 60
                if age < self.config.cache_ttl_minutes:
                    self._stats["cache_hits"] += 1
                    cached.cached = True
                    return cached
        
        # Perform search
        response = await self._do_search(query, engine, max_results, search_type)
        
        # Try fallback if failed
        if not response.success and self.config.fallback_engines:
            for fallback_engine in self.config.fallback_engines:
                if fallback_engine != engine:
                    logger.info(f"Trying fallback: {fallback_engine.value}")
                    response = await self._do_search(
                        query, fallback_engine, max_results, search_type
                    )
                    if response.success:
                        break
        
        # Cache successful response
        if response.success and self.config.cache_enabled:
            cache_key = f"{engine.value}:{query}:{max_results}"
            self._cache[cache_key] = response
        
        # Update stats
        if response.success:
            self._stats["successful_searches"] += 1
        else:
            self._stats["failed_searches"] += 1
        
        return response
    
    async def _do_search(
        self,
        query: str,
        engine: SearchEngine,
        max_results: int,
        search_type: SearchType
    ) -> SearchResponse:
        """Execute search with specific engine"""
        if engine not in self._providers:
            return SearchResponse(
                query=query,
                engine=engine,
                results=[],
                error=f"Engine not available: {engine.value}"
            )
        
        provider = self._providers[engine]
        return await provider.search(query, max_results, search_type)
    
    async def multi_search(
        self,
        query: str,
        engines: List[SearchEngine],
        max_results_per_engine: int = 5
    ) -> Dict[SearchEngine, SearchResponse]:
        """Search across multiple engines"""
        tasks = []
        
        for engine in engines:
            if engine in self._providers:
                tasks.append(self.search(
                    query=query,
                    engine=engine,
                    max_results=max_results_per_engine
                ))
        
        responses = await asyncio.gather(*tasks, return_exceptions=True)
        
        results = {}
        for engine, response in zip(engines, responses):
            if isinstance(response, Exception):
                results[engine] = SearchResponse(
                    query=query,
                    engine=engine,
                    results=[],
                    error=str(response)
                )
            else:
                results[engine] = response
        
        return results
    
    async def quick_search(self, query: str) -> List[SearchResult]:
        """Quick search returning just results list"""
        response = await self.search(query)
        return response.results
    
    async def instant_answer(self, query: str) -> Optional[str]:
        """Get instant answer if available"""
        if SearchEngine.DUCKDUCKGO in self._providers:
            provider = self._providers[SearchEngine.DUCKDUCKGO]
            if isinstance(provider, DuckDuckGoProvider):
                result = await provider.instant_answer(query)
                if result:
                    return result.get("answer")
        return None
    
    def clear_cache(self) -> None:
        """Clear search cache"""
        self._cache.clear()
    
    def get_stats(self) -> Dict[str, Any]:
        """Get search statistics"""
        return {
            **self._stats,
            "available_engines": list(self._providers.keys()),
            "default_engine": self.config.default_engine.value,
            "cache_size": len(self._cache)
        }


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

async def create_search_engine(
    internet_manager: Optional[Any] = None,
    default_engine: SearchEngine = SearchEngine.DUCKDUCKGO,
    **kwargs
) -> SearchEngineManager:
    """Create configured search engine manager"""
    config = SearchConfig(
        default_engine=default_engine,
        **kwargs
    )
    
    manager = SearchEngineManager(
        config=config,
        internet_manager=internet_manager
    )
    
    return manager