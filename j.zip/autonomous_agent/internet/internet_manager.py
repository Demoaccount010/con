"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                         INTERNET MANAGER                                      ║
║              Central Controller for All Internet Operations                   ║
╚══════════════════════════════════════════════════════════════════════════════╝

The Internet Manager provides unified access to:
- HTTP requests (GET, POST, etc.)
- Web scraping
- Search engines
- API access
- Content fetching and parsing
- Rate limiting and caching
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Union, Tuple
from dataclasses import dataclass, field
from enum import Enum
import aiohttp
import hashlib
import json
from pathlib import Path
from urllib.parse import urlparse, urljoin
import ssl

logger = logging.getLogger(__name__)


class RequestMethod(Enum):
    """HTTP request methods"""
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    DELETE = "DELETE"
    PATCH = "PATCH"
    HEAD = "HEAD"
    OPTIONS = "OPTIONS"


class ContentType(Enum):
    """Content types"""
    HTML = "html"
    JSON = "json"
    XML = "xml"
    TEXT = "text"
    BINARY = "binary"
    UNKNOWN = "unknown"


@dataclass
class HttpResponse:
    """HTTP response wrapper"""
    url: str
    status_code: int
    headers: Dict[str, str]
    content: Optional[bytes] = None
    text: Optional[str] = None
    json_data: Optional[Any] = None
    content_type: ContentType = ContentType.UNKNOWN
    encoding: str = "utf-8"
    elapsed_ms: float = 0.0
    error: Optional[str] = None
    cached: bool = False
    fetched_at: datetime = field(default_factory=datetime.now)
    
    @property
    def ok(self) -> bool:
        return 200 <= self.status_code < 300
    
    @property
    def is_redirect(self) -> bool:
        return 300 <= self.status_code < 400
    
    @property
    def is_error(self) -> bool:
        return self.status_code >= 400


@dataclass
class InternetConfig:
    """Configuration for internet manager"""
    enabled: bool = True
    
    # Timeouts (seconds)
    connect_timeout: float = 10.0
    read_timeout: float = 30.0
    total_timeout: float = 60.0
    
    # Rate limiting
    rate_limit_enabled: bool = True
    max_requests_per_minute: int = 60
    max_requests_per_domain: int = 10
    domain_cooldown_seconds: float = 1.0
    
    # Caching
    cache_enabled: bool = True
    cache_ttl_minutes: int = 60
    max_cache_size_mb: int = 100
    
    # Retries
    max_retries: int = 3
    retry_delay_seconds: float = 1.0
    retry_backoff_multiplier: float = 2.0
    
    # User agent
    user_agent: str = "AxiomAgent/3.0 (Autonomous AI Agent)"
    
    # Security
    verify_ssl: bool = True
    allowed_domains: List[str] = field(default_factory=list)  # Empty = all allowed
    blocked_domains: List[str] = field(default_factory=list)
    
    # Content limits
    max_content_size_mb: int = 10
    max_redirects: int = 5
    
    # Headers
    default_headers: Dict[str, str] = field(default_factory=dict)


class ResponseCache:
    """Cache for HTTP responses"""
    
    def __init__(self, ttl_minutes: int = 60, max_size_mb: int = 100):
        self.ttl_minutes = ttl_minutes
        self.max_size_bytes = max_size_mb * 1024 * 1024
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._current_size = 0
        self._lock = asyncio.Lock()
    
    def _make_key(self, url: str, method: str = "GET", params: Optional[Dict] = None) -> str:
        """Create cache key"""
        key_data = f"{method}:{url}"
        if params:
            key_data += f":{json.dumps(params, sort_keys=True)}"
        return hashlib.md5(key_data.encode()).hexdigest()
    
    async def get(
        self,
        url: str,
        method: str = "GET",
        params: Optional[Dict] = None
    ) -> Optional[HttpResponse]:
        """Get cached response"""
        async with self._lock:
            key = self._make_key(url, method, params)
            
            if key not in self._cache:
                return None
            
            entry = self._cache[key]
            
            # Check expiry
            if datetime.now() > entry["expires_at"]:
                self._current_size -= entry.get("size", 0)
                del self._cache[key]
                return None
            
            response = entry["response"]
            response.cached = True
            return response
    
    async def set(
        self,
        url: str,
        response: HttpResponse,
        method: str = "GET",
        params: Optional[Dict] = None
    ) -> None:
        """Cache a response"""
        async with self._lock:
            key = self._make_key(url, method, params)
            
            # Calculate size
            size = len(response.content) if response.content else 0
            
            # Check if we need to make room
            while self._current_size + size > self.max_size_bytes and self._cache:
                # Remove oldest entry
                oldest_key = min(
                    self._cache.keys(),
                    key=lambda k: self._cache[k]["created_at"]
                )
                self._current_size -= self._cache[oldest_key].get("size", 0)
                del self._cache[oldest_key]
            
            self._cache[key] = {
                "response": response,
                "created_at": datetime.now(),
                "expires_at": datetime.now() + timedelta(minutes=self.ttl_minutes),
                "size": size
            }
            self._current_size += size
    
    async def clear(self) -> None:
        """Clear cache"""
        async with self._lock:
            self._cache.clear()
            self._current_size = 0
    
    async def cleanup(self) -> int:
        """Remove expired entries"""
        async with self._lock:
            now = datetime.now()
            expired = [
                key for key, entry in self._cache.items()
                if now > entry["expires_at"]
            ]
            
            for key in expired:
                self._current_size -= self._cache[key].get("size", 0)
                del self._cache[key]
            
            return len(expired)
    
    @property
    def size_mb(self) -> float:
        return self._current_size / (1024 * 1024)
    
    @property
    def entry_count(self) -> int:
        return len(self._cache)


class RateLimiter:
    """Rate limiter for HTTP requests"""
    
    def __init__(
        self,
        max_per_minute: int = 60,
        max_per_domain: int = 10,
        domain_cooldown: float = 1.0
    ):
        self.max_per_minute = max_per_minute
        self.max_per_domain = max_per_domain
        self.domain_cooldown = domain_cooldown
        
        self._global_requests: List[datetime] = []
        self._domain_requests: Dict[str, List[datetime]] = {}
        self._domain_last_request: Dict[str, datetime] = {}
        self._lock = asyncio.Lock()
    
    def _get_domain(self, url: str) -> str:
        """Extract domain from URL"""
        parsed = urlparse(url)
        return parsed.netloc.lower()
    
    async def acquire(self, url: str) -> bool:
        """Try to acquire permission for request"""
        async with self._lock:
            now = datetime.now()
            domain = self._get_domain(url)
            
            # Clean old entries
            minute_ago = now - timedelta(minutes=1)
            self._global_requests = [t for t in self._global_requests if t > minute_ago]
            
            if domain in self._domain_requests:
                self._domain_requests[domain] = [
                    t for t in self._domain_requests[domain] if t > minute_ago
                ]
            
            # Check global limit
            if len(self._global_requests) >= self.max_per_minute:
                return False
            
            # Check domain limit
            domain_reqs = self._domain_requests.get(domain, [])
            if len(domain_reqs) >= self.max_per_domain:
                return False
            
            # Check domain cooldown
            last_req = self._domain_last_request.get(domain)
            if last_req:
                elapsed = (now - last_req).total_seconds()
                if elapsed < self.domain_cooldown:
                    return False
            
            # Record request
            self._global_requests.append(now)
            if domain not in self._domain_requests:
                self._domain_requests[domain] = []
            self._domain_requests[domain].append(now)
            self._domain_last_request[domain] = now
            
            return True
    
    async def wait_and_acquire(self, url: str, max_wait: float = 30.0) -> bool:
        """Wait until we can make request"""
        start = datetime.now()
        
        while (datetime.now() - start).total_seconds() < max_wait:
            if await self.acquire(url):
                return True
            await asyncio.sleep(0.5)
        
        return False


class InternetManager:
    """
    Central manager for all internet operations
    
    Features:
    - HTTP client with retries
    - Response caching
    - Rate limiting
    - Content parsing
    - Domain filtering
    - Connection pooling
    """
    
    def __init__(self, config: Optional[InternetConfig] = None):
        self.config = config or InternetConfig()
        
        # Components
        self._cache = ResponseCache(
            ttl_minutes=self.config.cache_ttl_minutes,
            max_size_mb=self.config.max_cache_size_mb
        )
        self._rate_limiter = RateLimiter(
            max_per_minute=self.config.max_requests_per_minute,
            max_per_domain=self.config.max_requests_per_domain,
            domain_cooldown=self.config.domain_cooldown_seconds
        )
        
        # Session
        self._session: Optional[aiohttp.ClientSession] = None
        self._session_lock = asyncio.Lock()
        
        # Statistics
        self._stats = {
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "cache_hits": 0,
            "rate_limited": 0,
            "bytes_downloaded": 0
        }
        
        logger.info("InternetManager initialized")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # SESSION MANAGEMENT
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create HTTP session"""
        async with self._session_lock:
            if self._session is None or self._session.closed:
                timeout = aiohttp.ClientTimeout(
                    connect=self.config.connect_timeout,
                    sock_read=self.config.read_timeout,
                    total=self.config.total_timeout
                )
                
                # SSL context
                ssl_context = None
                if not self.config.verify_ssl:
                    ssl_context = ssl.create_default_context()
                    ssl_context.check_hostname = False
                    ssl_context.verify_mode = ssl.CERT_NONE
                
                connector = aiohttp.TCPConnector(
                    limit=100,
                    limit_per_host=10,
                    ssl=ssl_context
                )
                
                headers = {
                    "User-Agent": self.config.user_agent,
                    **self.config.default_headers
                }
                
                self._session = aiohttp.ClientSession(
                    timeout=timeout,
                    connector=connector,
                    headers=headers
                )
            
            return self._session
    
    async def close(self) -> None:
        """Close the HTTP session"""
        async with self._session_lock:
            if self._session and not self._session.closed:
                await self._session.close()
                self._session = None
        logger.info("InternetManager closed")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # URL VALIDATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _is_url_allowed(self, url: str) -> Tuple[bool, Optional[str]]:
        """Check if URL is allowed"""
        parsed = urlparse(url)
        domain = parsed.netloc.lower()
        
        # Check blocked domains
        for blocked in self.config.blocked_domains:
            if blocked.lower() in domain:
                return False, f"Domain blocked: {blocked}"
        
        # Check allowed domains (if list is not empty)
        if self.config.allowed_domains:
            allowed = False
            for allow in self.config.allowed_domains:
                if allow.lower() in domain:
                    allowed = True
                    break
            if not allowed:
                return False, f"Domain not in allowed list: {domain}"
        
        return True, None
    
    def _normalize_url(self, url: str) -> str:
        """Normalize URL"""
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        return url
    
    # ═══════════════════════════════════════════════════════════════════════════
    # HTTP METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def request(
        self,
        url: str,
        method: RequestMethod = RequestMethod.GET,
        params: Optional[Dict] = None,
        data: Optional[Dict] = None,
        json_body: Optional[Dict] = None,
        headers: Optional[Dict[str, str]] = None,
        use_cache: bool = True,
        follow_redirects: bool = True
    ) -> HttpResponse:
        """Make HTTP request"""
        if not self.config.enabled:
            return HttpResponse(
                url=url,
                status_code=0,
                headers={},
                error="Internet access disabled"
            )
        
        url = self._normalize_url(url)
        
        # Check if URL is allowed
        allowed, reason = self._is_url_allowed(url)
        if not allowed:
            return HttpResponse(
                url=url,
                status_code=403,
                headers={},
                error=reason
            )
        
        # Check cache for GET requests
        if use_cache and method == RequestMethod.GET:
            cached = await self._cache.get(url, method.value, params)
            if cached:
                self._stats["cache_hits"] += 1
                return cached
        
        # Rate limiting
        if self.config.rate_limit_enabled:
            if not await self._rate_limiter.wait_and_acquire(url):
                self._stats["rate_limited"] += 1
                return HttpResponse(
                    url=url,
                    status_code=429,
                    headers={},
                    error="Rate limited"
                )
        
        self._stats["total_requests"] += 1
        
        # Make request with retries
        last_error = None
        for attempt in range(self.config.max_retries):
            try:
                response = await self._make_request(
                    url=url,
                    method=method,
                    params=params,
                    data=data,
                    json_body=json_body,
                    headers=headers,
                    follow_redirects=follow_redirects
                )
                
                if response.ok:
                    self._stats["successful_requests"] += 1
                    
                    # Cache successful GET responses
                    if use_cache and method == RequestMethod.GET:
                        await self._cache.set(url, response, method.value, params)
                    
                    return response
                
                # Don't retry client errors (4xx)
                if 400 <= response.status_code < 500:
                    self._stats["failed_requests"] += 1
                    return response
                
                last_error = f"HTTP {response.status_code}"
                
            except asyncio.TimeoutError:
                last_error = "Request timeout"
            except aiohttp.ClientError as e:
                last_error = str(e)
            except Exception as e:
                last_error = str(e)
            
            # Wait before retry
            if attempt < self.config.max_retries - 1:
                delay = self.config.retry_delay_seconds * (
                    self.config.retry_backoff_multiplier ** attempt
                )
                await asyncio.sleep(delay)
        
        self._stats["failed_requests"] += 1
        
        return HttpResponse(
            url=url,
            status_code=0,
            headers={},
            error=last_error
        )
    
    async def _make_request(
        self,
        url: str,
        method: RequestMethod,
        params: Optional[Dict],
        data: Optional[Dict],
        json_body: Optional[Dict],
        headers: Optional[Dict[str, str]],
        follow_redirects: bool
    ) -> HttpResponse:
        """Execute the actual HTTP request"""
        session = await self._get_session()
        start_time = datetime.now()
        
        async with session.request(
            method=method.value,
            url=url,
            params=params,
            data=data,
            json=json_body,
            headers=headers,
            allow_redirects=follow_redirects,
            max_redirects=self.config.max_redirects
        ) as response:
            # Read content with size limit
            max_size = self.config.max_content_size_mb * 1024 * 1024
            content = await response.content.read(max_size)
            
            self._stats["bytes_downloaded"] += len(content)
            
            # Determine content type
            content_type_header = response.headers.get("Content-Type", "")
            content_type = self._parse_content_type(content_type_header)
            
            # Parse content
            text = None
            json_data = None
            
            try:
                encoding = response.charset or "utf-8"
                text = content.decode(encoding)
                
                if content_type == ContentType.JSON:
                    json_data = json.loads(text)
            except Exception:
                pass
            
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            
            return HttpResponse(
                url=str(response.url),
                status_code=response.status,
                headers=dict(response.headers),
                content=content,
                text=text,
                json_data=json_data,
                content_type=content_type,
                encoding=response.charset or "utf-8",
                elapsed_ms=elapsed
            )
    
    def _parse_content_type(self, header: str) -> ContentType:
        """Parse content type from header"""
        header_lower = header.lower()
        
        if "json" in header_lower:
            return ContentType.JSON
        elif "html" in header_lower:
            return ContentType.HTML
        elif "xml" in header_lower:
            return ContentType.XML
        elif "text" in header_lower:
            return ContentType.TEXT
        elif any(t in header_lower for t in ["image", "video", "audio", "octet-stream"]):
            return ContentType.BINARY
        
        return ContentType.UNKNOWN
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CONVENIENCE METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def get(
        self,
        url: str,
        params: Optional[Dict] = None,
        headers: Optional[Dict[str, str]] = None,
        use_cache: bool = True
    ) -> HttpResponse:
        """Make GET request"""
        return await self.request(
            url=url,
            method=RequestMethod.GET,
            params=params,
            headers=headers,
            use_cache=use_cache
        )
    
    async def post(
        self,
        url: str,
        data: Optional[Dict] = None,
        json_body: Optional[Dict] = None,
        headers: Optional[Dict[str, str]] = None
    ) -> HttpResponse:
        """Make POST request"""
        return await self.request(
            url=url,
            method=RequestMethod.POST,
            data=data,
            json_body=json_body,
            headers=headers,
            use_cache=False
        )
    
    async def fetch_text(self, url: str, **kwargs) -> Optional[str]:
        """Fetch URL and return text content"""
        response = await self.get(url, **kwargs)
        return response.text if response.ok else None
    
    async def fetch_json(self, url: str, **kwargs) -> Optional[Any]:
        """Fetch URL and return JSON content"""
        response = await self.get(url, **kwargs)
        return response.json_data if response.ok else None
    
    async def fetch_page(self, url: str, **kwargs) -> Optional[str]:
        """Fetch webpage content"""
        response = await self.get(url, **kwargs)
        return response.text if response.ok else None
    
    async def download(
        self,
        url: str,
        save_path: Union[str, Path],
        **kwargs
    ) -> bool:
        """Download file to disk"""
        response = await self.get(url, use_cache=False, **kwargs)
        
        if not response.ok or not response.content:
            return False
        
        try:
            path = Path(save_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(response.content)
            return True
        except Exception as e:
            logger.error(f"Download failed: {e}")
            return False
    
    async def head(self, url: str) -> HttpResponse:
        """Make HEAD request"""
        return await self.request(
            url=url,
            method=RequestMethod.HEAD,
            use_cache=False
        )
    
    async def check_url(self, url: str) -> Tuple[bool, int]:
        """Check if URL is accessible"""
        response = await self.head(url)
        return response.ok, response.status_code
    
    # ═══════════════════════════════════════════════════════════════════════════
    # SEARCH INTEGRATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def search(
        self,
        query: str,
        max_results: int = 10,
        search_engine: str = "duckduckgo"
    ) -> List[Dict[str, str]]:
        """
        Search the web using search engine
        
        Returns list of results with 'title', 'url', 'snippet'
        """
        # This is a simplified implementation
        # Real implementation would use search_engine.py
        
        if search_engine == "duckduckgo":
            url = "https://html.duckduckgo.com/html/"
            response = await self.post(url, data={"q": query})
            
            if not response.ok:
                return []
            
            # Parse results (simplified - real impl would use web_scraper)
            results = []
            if response.text:
                # Very basic parsing - real implementation uses BeautifulSoup
                import re
                links = re.findall(r'href="([^"]+)"[^>]*>([^<]+)</a>', response.text)
                for link_url, title in links[:max_results]:
                    if link_url.startswith("http") and "duckduckgo" not in link_url:
                        results.append({
                            "title": title.strip(),
                            "url": link_url,
                            "snippet": ""
                        })
            
            return results
        
        return []
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MANAGEMENT
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def clear_cache(self) -> None:
        """Clear response cache"""
        await self._cache.clear()
    
    async def cleanup_cache(self) -> int:
        """Cleanup expired cache entries"""
        return await self._cache.cleanup()
    
    def block_domain(self, domain: str) -> None:
        """Block a domain"""
        if domain not in self.config.blocked_domains:
            self.config.blocked_domains.append(domain)
    
    def unblock_domain(self, domain: str) -> None:
        """Unblock a domain"""
        if domain in self.config.blocked_domains:
            self.config.blocked_domains.remove(domain)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get manager statistics"""
        return {
            **self._stats,
            "cache_size_mb": self._cache.size_mb,
            "cache_entries": self._cache.entry_count,
            "enabled": self.config.enabled,
            "blocked_domains": len(self.config.blocked_domains)
        }
    
    async def health_check(self) -> bool:
        """Check if internet is accessible"""
        try:
            response = await self.get(
                "https://www.google.com",
                use_cache=False
            )
            return response.ok
        except Exception:
            return False


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

async def create_internet_manager(
    cache_enabled: bool = True,
    rate_limit_enabled: bool = True,
    **kwargs
) -> InternetManager:
    """Create configured internet manager"""
    config = InternetConfig(
        cache_enabled=cache_enabled,
        rate_limit_enabled=rate_limit_enabled,
        **kwargs
    )
    
    manager = InternetManager(config=config)
    return manager