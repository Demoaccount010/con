#!/usr/bin/env python3
"""
Config Loader
=============
Loads and manages YAML configuration files.
"""

import logging
from pathlib import Path
from typing import Dict, Any, Optional

try:
    import yaml
    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False


class ConfigLoader:
    """
    Loads and manages configuration files.
    
    Configuration files:
    - system.yaml - System settings
    - ollama.yaml - Ollama configuration
    - telegram.yaml - Telegram bot config
    - development.yaml - Development settings
    """
    
    def __init__(self, agent=None):
        self.agent = agent
        self.logger = logging.getLogger("config_loader")
        
        # Config directory
        if agent and hasattr(agent, 'project_root'):
            self.config_dir = agent.project_root / "config" / "required"
        else:
            self.config_dir = Path(__file__).parent / "required"
        
        self.configs = {}
        self._initialized = False
    
    async def initialize(self) -> bool:
        """Initialize config loader."""
        if not YAML_AVAILABLE:
            self.logger.warning("PyYAML not installed. Config loading disabled.")
            return False
        
        self.logger.info("Initializing config loader...")
        
        # Load all configs
        config_files = ['system.yaml', 'ollama.yaml', 'telegram.yaml', 'development.yaml']
        
        loaded = 0
        for config_file in config_files:
            config_path = self.config_dir / config_file
            
            if config_path.exists():
                try:
                    data = self.load_config(config_file)
                    if data:
                        self.configs[config_file.replace('.yaml', '')] = data
                        loaded += 1
                except Exception as e:
                    self.logger.warning(f"Failed to load {config_file}: {e}")
        
        self.logger.info(f"Loaded {loaded}/{len(config_files)} config files")
        self._initialized = True
        return True
    
    def load_config(self, config_name: str) -> Optional[Dict[str, Any]]:
        """
        Load a specific configuration file.
        
        Args:
            config_name: Config file name (e.g., 'system.yaml' or 'system')
            
        Returns:
            Configuration dict or None
        """
        if not YAML_AVAILABLE:
            return None
        
        # Add .yaml if not present
        if not config_name.endswith('.yaml'):
            config_name = f"{config_name}.yaml"
        
        config_path = self.config_dir / config_name
        
        if not config_path.exists():
            self.logger.warning(f"Config file not found: {config_path}")
            return None
        
        try:
            with open(config_path, 'r') as f:
                data = yaml.safe_load(f)
            
            self.logger.debug(f"Loaded config: {config_name}")
            return data
            
        except Exception as e:
            self.logger.error(f"Failed to load {config_name}: {e}")
            return None
    
    def get_config(self, config_name: str) -> Optional[Dict[str, Any]]:
        """
        Get a loaded configuration.
        
        Args:
            config_name: Config name without .yaml extension
            
        Returns:
            Configuration dict or None
        """
        return self.configs.get(config_name)
    
    def get_value(self, config_name: str, key_path: str, default: Any = None) -> Any:
        """
        Get a specific value from a config.
        
        Args:
            config_name: Config name (e.g., 'system')
            key_path: Dot-separated path (e.g., 'ollama.url')
            default: Default value if not found
            
        Returns:
            Config value or default
        """
        config = self.get_config(config_name)
        if not config:
            return default
        
        # Navigate nested keys
        keys = key_path.split('.')
        value = config
        
        for key in keys:
            if isinstance(value, dict) and key in value:
                value = value[key]
            else:
                return default
        
        return value
    
    def list_configs(self) -> Dict[str, bool]:
        """
        List all configuration files.
        
        Returns:
            Dict of config_name: is_loaded
        """
        config_files = ['system', 'ollama', 'telegram', 'development']
        
        return {
            name: name in self.configs
            for name in config_files
        }
    
    def reload_config(self, config_name: str) -> bool:
        """
        Reload a specific configuration.
        
        Args:
            config_name: Config name to reload
            
        Returns:
            True if successful
        """
        data = self.load_config(config_name)
        
        if data:
            config_key = config_name.replace('.yaml', '')
            self.configs[config_key] = data
            self.logger.info(f"Reloaded config: {config_name}")
            return True
        
        return False
    
    @property
    def is_initialized(self) -> bool:
        """Check if loader is initialized."""
        return self._initialized
    
    @property
    def yaml_available(self) -> bool:
        """Check if PyYAML is available."""
        return YAML_AVAILABLE
