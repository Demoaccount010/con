#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 OLLAMA CLIENT - LLM INTEGRATION
═══════════════════════════════════════════════════════════════════════════════

 Direct integration with Ollama REST API.
 
 FEATURES:
 ─────────
 • Auto-connection with retry
 • Model listing and selection
 • Streaming responses
 • Token counting
 • Context window management
 • Response caching
 • Error handling with fallback
 
 API ENDPOINTS USED:
 ───────────────────
 • GET  /api/version     - Check connection
 • GET  /api/tags        - List models
 • POST /api/generate    - Generate completion
 • POST /api/chat        - Chat completion
 • POST /api/embeddings  - Generate embeddings
 • POST /api/pull        - Pull model
 • DELETE /api/delete    - Delete model
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import aiohttp
import json
import logging
import hashlib
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, AsyncGenerator, Tuple
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path


@dataclass
class OllamaConfig:
    """Ollama client configuration."""
    base_url: str = "http://localhost:11434"
    default_model: str = "llama3:8b"
    timeout_connect: int = 10
    timeout_read: int = 120
    max_retries: int = 3
    retry_delay: float = 1.0
    cache_enabled: bool = True
    cache_ttl_seconds: int = 3600
    context_size: int = 4096
    temperature: float = 0.7
    top_p: float = 0.9
    

@dataclass
class GenerateResponse:
    """Response from generate/chat endpoint."""
    text: str
    model: str
    done: bool
    total_duration: Optional[int] = None
    load_duration: Optional[int] = None
    prompt_eval_count: Optional[int] = None
    eval_count: Optional[int] = None
    context: Optional[List[int]] = None
    error: Optional[str] = None
    cached: bool = False
    

@dataclass
class ModelInfo:
    """Information about an Ollama model."""
    name: str
    size: int
    digest: str
    modified_at: str
    family: str = ""
    parameter_size: str = ""
    quantization: str = ""


class OllamaClient:
    """
    ═══════════════════════════════════════════════════════════════════════════
    OLLAMA REST API CLIENT
    ═══════════════════════════════════════════════════════════════════════════
    
    Handles all communication with Ollama server.
    Supports auto-reconnection and response caching.
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize Ollama client.
        
        Args:
            config: Configuration dictionary (uses defaults if not provided)
        """
        self.logger = logging.getLogger("llm.ollama")
        
        # Parse configuration
        config = config or {}
        self.config = OllamaConfig(
            base_url=config.get('base_url', 'http://localhost:11434'),
            default_model=config.get('model', 'llama3:8b'),
            timeout_connect=config.get('timeout_connect', 10),
            timeout_read=config.get('timeout_read', 120),
            max_retries=config.get('max_retries', 3),
            retry_delay=config.get('retry_delay', 1.0),
            cache_enabled=config.get('cache_enabled', True),
            cache_ttl_seconds=config.get('cache_ttl', 3600),
            context_size=config.get('context_size', 4096),
            temperature=config.get('temperature', 0.7),
            top_p=config.get('top_p', 0.9),
        )
        
        # State
        self.is_connected: bool = False
        self.server_version: Optional[str] = None
        self.available_models: List[ModelInfo] = []
        self.current_model: Optional[str] = None
        
        # HTTP session (created in initialize)
        self._session: Optional[aiohttp.ClientSession] = None
        
        # Response cache
        self._cache: Dict[str, Tuple[GenerateResponse, datetime]] = {}
        
        # Statistics
        self.stats = {
            'requests': 0,
            'cache_hits': 0,
            'errors': 0,
            'total_tokens_in': 0,
            'total_tokens_out': 0,
        }
        
    @property
    def base_url(self) -> str:
        """Get base URL."""
        return self.config.base_url
        
    async def initialize(self) -> bool:
        """
        Initialize the client and verify connection.
        
        Returns:
            True if connected successfully
        """
        self.logger.info(f"Initializing Ollama client for {self.config.base_url}")
        
        # Create HTTP session
        timeout = aiohttp.ClientTimeout(
            connect=self.config.timeout_connect,
            total=self.config.timeout_read
        )
        self._session = aiohttp.ClientSession(timeout=timeout)
        
        # Verify connection
        if await self._verify_connection():
            self.is_connected = True
            
            # Load available models
            await self.refresh_models()
            
            # Set default model
            if self.available_models:
                # Use configured model if available
                model_names = [m.name for m in self.available_models]
                if self.config.default_model in model_names:
                    self.current_model = self.config.default_model
                else:
                    # Find partial match
                    default_base = self.config.default_model.split(':')[0]
                    for name in model_names:
                        if default_base in name:
                            self.current_model = name
                            break
                    else:
                        # Use first available
                        self.current_model = model_names[0]
                        
                self.logger.info(f"Using model: {self.current_model}")
            else:
                self.logger.warning("No models available!")
                
            return True
        else:
            self.logger.error("Failed to connect to Ollama")
            return False
            
    async def _verify_connection(self) -> bool:
        """Verify connection to Ollama server."""
        for attempt in range(self.config.max_retries):
            try:
                async with self._session.get(
                    f"{self.config.base_url}/api/version"
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        self.server_version = data.get('version', 'unknown')
                        self.logger.info(f"Connected to Ollama v{self.server_version}")
                        return True
                    else:
                        self.logger.warning(f"Ollama returned status {response.status}")
                        
            except aiohttp.ClientConnectorError as e:
                self.logger.warning(f"Connection attempt {attempt + 1} failed: {e}")
                
            except asyncio.TimeoutError:
                self.logger.warning(f"Connection attempt {attempt + 1} timed out")
                
            except Exception as e:
                self.logger.error(f"Unexpected error: {e}")
                
            # Wait before retry
            if attempt < self.config.max_retries - 1:
                await asyncio.sleep(self.config.retry_delay * (attempt + 1))
                
        return False
        
    async def refresh_models(self) -> List[ModelInfo]:
        """Refresh list of available models."""
        try:
            async with self._session.get(
                f"{self.config.base_url}/api/tags"
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    self.available_models = []
                    
                    for model_data in data.get('models', []):
                        model = ModelInfo(
                            name=model_data.get('name', ''),
                            size=model_data.get('size', 0),
                            digest=model_data.get('digest', ''),
                            modified_at=model_data.get('modified_at', ''),
                            family=model_data.get('details', {}).get('family', ''),
                            parameter_size=model_data.get('details', {}).get('parameter_size', ''),
                            quantization=model_data.get('details', {}).get('quantization_level', ''),
                        )
                        self.available_models.append(model)
                        
                    self.logger.info(f"Found {len(self.available_models)} models")
                    return self.available_models
                    
        except Exception as e:
            self.logger.error(f"Error refreshing models: {e}")
            
        return []
        
    async def generate(
        self,
        prompt: str,
        model: Optional[str] = None,
        system: Optional[str] = None,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        max_tokens: Optional[int] = None,
        context: Optional[List[int]] = None,
        stream: bool = False,
        use_cache: bool = True,
    ) -> GenerateResponse:
        """
        Generate a completion.
        
        Args:
            prompt: The prompt to complete
            model: Model to use (defaults to current_model)
            system: System prompt
            temperature: Sampling temperature
            top_p: Top-p sampling
            max_tokens: Maximum tokens to generate
            context: Previous context for continuation
            stream: Whether to stream response
            use_cache: Whether to use response cache
            
        Returns:
            GenerateResponse with the completion
        """
        # Use defaults
        model = model or self.current_model
        temperature = temperature if temperature is not None else self.config.temperature
        top_p = top_p if top_p is not None else self.config.top_p
        
        if not model:
            return GenerateResponse(
                text="",
                model="",
                done=True,
                error="No model available"
            )
            
        # Check cache
        cache_key = self._make_cache_key(prompt, model, system, temperature)
        if use_cache and self.config.cache_enabled:
            cached = self._get_cached(cache_key)
            if cached:
                self.stats['cache_hits'] += 1
                return cached
                
        # Build request
        request_data = {
            "model": model,
            "prompt": prompt,
            "stream": stream,
            "options": {
                "temperature": temperature,
                "top_p": top_p,
            }
        }
        
        if system:
            request_data["system"] = system
        if max_tokens:
            request_data["options"]["num_predict"] = max_tokens
        if context:
            request_data["context"] = context
            
        self.stats['requests'] += 1
        
        try:
            if stream:
                return await self._generate_stream(request_data, cache_key)
            else:
                return await self._generate_sync(request_data, cache_key)
                
        except asyncio.TimeoutError:
            self.stats['errors'] += 1
            return GenerateResponse(
                text="",
                model=model,
                done=True,
                error="Request timed out"
            )
            
        except Exception as e:
            self.stats['errors'] += 1
            self.logger.error(f"Generate error: {e}")
            return GenerateResponse(
                text="",
                model=model,
                done=True,
                error=str(e)
            )
            
    async def _generate_sync(
        self,
        request_data: Dict[str, Any],
        cache_key: str
    ) -> GenerateResponse:
        """Non-streaming generation."""
        async with self._session.post(
            f"{self.config.base_url}/api/generate",
            json=request_data
        ) as response:
            if response.status != 200:
                error_text = await response.text()
                return GenerateResponse(
                    text="",
                    model=request_data.get("model", ""),
                    done=True,
                    error=f"HTTP {response.status}: {error_text}"
                )
                
            data = await response.json()
            
            result = GenerateResponse(
                text=data.get("response", ""),
                model=data.get("model", ""),
                done=data.get("done", True),
                total_duration=data.get("total_duration"),
                load_duration=data.get("load_duration"),
                prompt_eval_count=data.get("prompt_eval_count"),
                eval_count=data.get("eval_count"),
                context=data.get("context"),
            )
            
            # Update stats
            if result.prompt_eval_count:
                self.stats['total_tokens_in'] += result.prompt_eval_count
            if result.eval_count:
                self.stats['total_tokens_out'] += result.eval_count
                
            # Cache result
            if self.config.cache_enabled:
                self._set_cached(cache_key, result)
                
            return result
            
    async def _generate_stream(
        self,
        request_data: Dict[str, Any],
        cache_key: str
    ) -> GenerateResponse:
        """Streaming generation (collects all chunks)."""
        full_text = ""
        last_data = {}
        
        async with self._session.post(
            f"{self.config.base_url}/api/generate",
            json=request_data
        ) as response:
            if response.status != 200:
                error_text = await response.text()
                return GenerateResponse(
                    text="",
                    model=request_data.get("model", ""),
                    done=True,
                    error=f"HTTP {response.status}: {error_text}"
                )
                
            async for line in response.content:
                if line:
                    try:
                        data = json.loads(line.decode('utf-8'))
                        full_text += data.get("response", "")
                        last_data = data
                        
                        if data.get("done", False):
                            break
                    except json.JSONDecodeError:
                        continue
                        
        result = GenerateResponse(
            text=full_text,
            model=last_data.get("model", request_data.get("model", "")),
            done=True,
            total_duration=last_data.get("total_duration"),
            prompt_eval_count=last_data.get("prompt_eval_count"),
            eval_count=last_data.get("eval_count"),
            context=last_data.get("context"),
        )
        
        # Update stats
        if result.prompt_eval_count:
            self.stats['total_tokens_in'] += result.prompt_eval_count
        if result.eval_count:
            self.stats['total_tokens_out'] += result.eval_count
            
        # Cache result
        if self.config.cache_enabled:
            self._set_cached(cache_key, result)
            
        return result
        
    async def generate_stream(
        self,
        prompt: str,
        model: Optional[str] = None,
        system: Optional[str] = None,
        temperature: Optional[float] = None,
    ) -> AsyncGenerator[str, None]:
        """
        Stream generation token by token.
        
        Yields:
            Individual tokens as they're generated
        """
        model = model or self.current_model
        temperature = temperature if temperature is not None else self.config.temperature
        
        if not model:
            yield "[ERROR: No model available]"
            return
            
        request_data = {
            "model": model,
            "prompt": prompt,
            "stream": True,
            "options": {
                "temperature": temperature,
            }
        }
        
        if system:
            request_data["system"] = system
            
        try:
            async with self._session.post(
                f"{self.config.base_url}/api/generate",
                json=request_data
            ) as response:
                if response.status != 200:
                    yield f"[ERROR: HTTP {response.status}]"
                    return
                    
                async for line in response.content:
                    if line:
                        try:
                            data = json.loads(line.decode('utf-8'))
                            token = data.get("response", "")
                            if token:
                                yield token
                            if data.get("done", False):
                                break
                        except json.JSONDecodeError:
                            continue
                            
        except Exception as e:
            yield f"[ERROR: {e}]"
            
    async def chat(
        self,
        messages: List[Dict[str, str]],
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        stream: bool = False,
    ) -> GenerateResponse:
        """
        Chat completion.
        
        Args:
            messages: List of {"role": "user/assistant/system", "content": "..."}
            model: Model to use
            temperature: Sampling temperature
            stream: Whether to stream
            
        Returns:
            GenerateResponse with the assistant's reply
        """
        model = model or self.current_model
        temperature = temperature if temperature is not None else self.config.temperature
        
        if not model:
            return GenerateResponse(
                text="",
                model="",
                done=True,
                error="No model available"
            )
            
        request_data = {
            "model": model,
            "messages": messages,
            "stream": stream,
            "options": {
                "temperature": temperature,
            }
        }
        
        self.stats['requests'] += 1
        
        try:
            async with self._session.post(
                f"{self.config.base_url}/api/chat",
                json=request_data
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    return GenerateResponse(
                        text="",
                        model=model,
                        done=True,
                        error=f"HTTP {response.status}: {error_text}"
                    )
                    
                if stream:
                    full_text = ""
                    async for line in response.content:
                        if line:
                            try:
                                data = json.loads(line.decode('utf-8'))
                                msg = data.get("message", {})
                                full_text += msg.get("content", "")
                                if data.get("done", False):
                                    break
                            except json.JSONDecodeError:
                                continue
                    return GenerateResponse(
                        text=full_text,
                        model=model,
                        done=True
                    )
                else:
                    data = await response.json()
                    message = data.get("message", {})
                    return GenerateResponse(
                        text=message.get("content", ""),
                        model=data.get("model", model),
                        done=data.get("done", True),
                        total_duration=data.get("total_duration"),
                        prompt_eval_count=data.get("prompt_eval_count"),
                        eval_count=data.get("eval_count"),
                    )
                    
        except Exception as e:
            self.stats['errors'] += 1
            return GenerateResponse(
                text="",
                model=model,
                done=True,
                error=str(e)
            )
            
    async def embeddings(
        self,
        text: str,
        model: Optional[str] = None
    ) -> Optional[List[float]]:
        """
        Generate embeddings for text.
        
        Args:
            text: Text to embed
            model: Model to use (defaults to current)
            
        Returns:
            List of floats representing the embedding, or None on error
        """
        model = model or self.current_model
        
        try:
            async with self._session.post(
                f"{self.config.base_url}/api/embeddings",
                json={"model": model, "prompt": text}
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    return data.get("embedding")
                    
        except Exception as e:
            self.logger.error(f"Embeddings error: {e}")
            
        return None
        
    async def pull_model(self, model_name: str) -> bool:
        """
        Pull a model from Ollama registry.
        
        Args:
            model_name: Name of model to pull
            
        Returns:
            True if successful
        """
        self.logger.info(f"Pulling model: {model_name}")
        
        try:
            async with self._session.post(
                f"{self.config.base_url}/api/pull",
                json={"name": model_name},
                timeout=aiohttp.ClientTimeout(total=3600)  # Long timeout for downloads
            ) as response:
                if response.status == 200:
                    # Stream progress
                    async for line in response.content:
                        if line:
                            try:
                                data = json.loads(line.decode('utf-8'))
                                status = data.get("status", "")
                                self.logger.info(f"Pull progress: {status}")
                            except json.JSONDecodeError:
                                continue
                    
                    # Refresh models
                    await self.refresh_models()
                    return True
                else:
                    self.logger.error(f"Pull failed: HTTP {response.status}")
                    
        except Exception as e:
            self.logger.error(f"Pull error: {e}")
            
        return False
        
    def _make_cache_key(
        self,
        prompt: str,
        model: str,
        system: Optional[str],
        temperature: float
    ) -> str:
        """Create a cache key for a request."""
        content = f"{model}|{system or ''}|{temperature}|{prompt}"
        return hashlib.sha256(content.encode()).hexdigest()[:16]
        
    def _get_cached(self, key: str) -> Optional[GenerateResponse]:
        """Get cached response if valid."""
        if key not in self._cache:
            return None
            
        response, timestamp = self._cache[key]
        
        # Check TTL
        if datetime.utcnow() - timestamp > timedelta(seconds=self.config.cache_ttl_seconds):
            del self._cache[key]
            return None
            
        response.cached = True
        return response
        
    def _set_cached(self, key: str, response: GenerateResponse) -> None:
        """Cache a response."""
        # Limit cache size
        if len(self._cache) > 1000:
            # Remove oldest entries
            sorted_keys = sorted(
                self._cache.keys(),
                key=lambda k: self._cache[k][1]
            )
            for old_key in sorted_keys[:100]:
                del self._cache[old_key]
                
        self._cache[key] = (response, datetime.utcnow())
        
    def clear_cache(self) -> None:
        """Clear the response cache."""
        self._cache.clear()
        
    def get_stats(self) -> Dict[str, Any]:
        """Get client statistics."""
        return {
            **self.stats,
            'connected': self.is_connected,
            'server_version': self.server_version,
            'current_model': self.current_model,
            'models_available': len(self.available_models),
            'cache_size': len(self._cache),
        }
        
    async def close(self) -> None:
        """Close the client and release resources."""
        if self._session:
            await self._session.close()
            self._session = None
        self.is_connected = False
        self.logger.info("Ollama client closed")