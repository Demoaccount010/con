#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 PLANNER - TASK DECOMPOSITION ENGINE
═══════════════════════════════════════════════════════════════════════════════

 Breaks down user requests into ordered, executable plan steps.
 
 PLANNING PHILOSOPHY:
 ────────────────────
 • Each step must be atomic (single action)
 • Each step specifies which tool to use
 • Steps have dependencies and order
 • Risks are identified upfront
 • Fallbacks are considered
 
 PLAN STRUCTURE:
 ───────────────
 • Steps - Ordered actions to take
 • Dependencies - What each step needs
 • Tools - Which tool each step uses
 • Risks - What could go wrong
 • Confirmations - What needs user approval
 
 CRITICAL RULES:
 ───────────────
 • NEVER plan a tool that doesn't exist
 • NEVER assume permissions
 • ALWAYS consider failures
 • ALWAYS identify dangerous operations
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
import re
from datetime import datetime
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass, field
from enum import Enum
from uuid import uuid4

from memory.memory_manager import MemoryManager
from tools.registry import ToolRegistry
from brain.brain_controller import BrainOutput


class StepPriority(Enum):
    """Priority level for plan steps."""
    CRITICAL = "critical"      # Must succeed
    IMPORTANT = "important"    # Should succeed
    OPTIONAL = "optional"      # Nice to have


class StepStatus(Enum):
    """Status of a plan step."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class PlanStep:
    """
    A single step in an execution plan.
    """
    step_id: str
    step_number: int
    description: str
    
    # Tool to use
    tool_name: Optional[str] = None
    tool_params: Dict[str, Any] = field(default_factory=dict)
    
    # Expectations
    expected_outcome: str = ""
    failure_modes: List[str] = field(default_factory=list)
    fallback_action: str = ""
    
    # Control
    priority: StepPriority = StepPriority.IMPORTANT
    requires_confirmation: bool = False
    timeout_seconds: int = 60
    max_retries: int = 1
    
    # Dependencies
    depends_on: List[str] = field(default_factory=list)
    provides: List[str] = field(default_factory=list)
    
    # Status tracking
    status: StepStatus = StepStatus.PENDING
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'step_id': self.step_id,
            'step_number': self.step_number,
            'description': self.description,
            'tool_name': self.tool_name,
            'tool_params': self.tool_params,
            'expected_outcome': self.expected_outcome,
            'priority': self.priority.value,
            'requires_confirmation': self.requires_confirmation,
            'status': self.status.value,
        }


@dataclass
class Plan:
    """
    Complete execution plan.
    """
    plan_id: str
    task: str
    task_type: str
    
    # Steps
    steps: List[PlanStep]
    
    # Metadata
    created_at: datetime = field(default_factory=datetime.utcnow)
    estimated_duration_seconds: int = 0
    
    # Flags
    is_chat_only: bool = False          # No tools needed
    requires_confirmation: bool = False  # Any step needs confirmation
    has_dangerous_steps: bool = False    # Contains risky operations
    
    # Risk assessment
    risk_level: str = "low"  # low, medium, high
    identified_risks: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'plan_id': self.plan_id,
            'task': self.task,
            'task_type': self.task_type,
            'steps': [s.to_dict() for s in self.steps],
            'is_chat_only': self.is_chat_only,
            'requires_confirmation': self.requires_confirmation,
            'risk_level': self.risk_level,
            'estimated_duration_seconds': self.estimated_duration_seconds,
        }


class Planner:
    """
    ═══════════════════════════════════════════════════════════════════════════
    TASK DECOMPOSITION ENGINE
    ═══════════════════════════════════════════════════════════════════════════
    
    Converts high-level tasks into executable plans.
    """
    
    # Dangerous keywords that require confirmation
    DANGEROUS_KEYWORDS = [
        'delete', 'remove', 'rm', 'drop', 'truncate', 'format',
        'kill', 'stop', 'shutdown', 'reboot', 'restart',
        'sudo', 'chmod', 'chown', 'mv',
    ]
    
    def __init__(
        self,
        memory: MemoryManager,
        tools: ToolRegistry,
        config: Dict[str, Any] = None
    ):
        """
        Initialize planner.
        
        Args:
            memory: Memory manager
            tools: Tool registry
            config: Configuration
        """
        self.logger = logging.getLogger("core.planner")
        self.memory = memory
        self.tools = tools
        self.config = config or {}
        
        # Cache of available tools
        self._available_tools: Dict[str, Dict] = {}
        
        # Statistics
        self.stats = {
            'plans_created': 0,
            'chat_only_plans': 0,
            'dangerous_plans': 0,
        }
        
    async def initialize(self) -> None:
        """Initialize planner."""
        self.logger.info("Initializing planner...")
        
        # Cache available tools
        tools = self.tools.list_all()
        self._available_tools = {t['name']: t for t in tools}
        
        self.logger.info(f"Planner initialized with {len(self._available_tools)} available tools")
        
    async def create_plan(
        self,
        task: str,
        task_type: 'TaskType',
        brain_output: BrainOutput,
        memory_hints: Dict[str, Any] = None
    ) -> Plan:
        """
        Create an execution plan for a task.
        
        Args:
            task: Original user task
            task_type: Classified task type
            brain_output: Output from brain/thinking
            memory_hints: Relevant memory hints
            
        Returns:
            Plan with steps to execute
        """
        plan_id = str(uuid4())[:8]
        self.logger.info(f"Creating plan {plan_id} for task type: {task_type}")
        
        self.stats['plans_created'] += 1
        
        # Check if this is chat only (no tools needed)
        if self._is_chat_only(task, task_type):
            self.stats['chat_only_plans'] += 1
            return Plan(
                plan_id=plan_id,
                task=task,
                task_type=str(task_type),
                steps=[],
                is_chat_only=True,
                risk_level="low"
            )
            
        # Create steps based on task type
        steps = await self._create_steps(task, task_type, brain_output, memory_hints)
        
        # Assess risks
        risk_level, risks = self._assess_risks(task, steps)
        
        # Check for dangerous operations
        has_dangerous = self._has_dangerous_operations(task, steps)
        if has_dangerous:
            self.stats['dangerous_plans'] += 1
            
        # Check if any step requires confirmation
        requires_confirmation = any(s.requires_confirmation for s in steps)
        
        # Calculate estimated duration
        estimated_duration = sum(s.timeout_seconds for s in steps)
        
        plan = Plan(
            plan_id=plan_id,
            task=task,
            task_type=str(task_type),
            steps=steps,
            is_chat_only=False,
            requires_confirmation=requires_confirmation,
            has_dangerous_steps=has_dangerous,
            risk_level=risk_level,
            identified_risks=risks,
            estimated_duration_seconds=estimated_duration
        )
        
        self.logger.info(
            f"Plan {plan_id} created with {len(steps)} steps, "
            f"risk: {risk_level}, dangerous: {has_dangerous}"
        )
        
        return plan
        
    def _is_chat_only(self, task: str, task_type) -> bool:
        """Check if task is chat-only (no tools needed)."""
        task_lower = task.lower()
        
        # Chat patterns
        chat_patterns = [
            r'^(hi|hello|hey|good\s+(morning|afternoon|evening))[\s!]*$',
            r'^thanks?(\s+you)?[\s!]*$',
            r'^(who|what)\s+(are|is)\s+you',
            r'^help[\s!]*$',
        ]
        
        for pattern in chat_patterns:
            if re.match(pattern, task_lower):
                return True
                
        # Check task type
        if str(task_type) in ['chat', 'TaskType.CHAT']:
            return True
            
        return False
        
    async def _create_steps(
        self,
        task: str,
        task_type,
        brain_output: BrainOutput,
        memory_hints: Dict[str, Any]
    ) -> List[PlanStep]:
        """Create plan steps based on task type."""
        task_lower = task.lower()
        steps = []
        
        # Route to appropriate planner
        task_type_str = str(task_type).split('.')[-1].lower()
        
        if task_type_str == 'system':
            steps = await self._plan_system_task(task, task_lower)
        elif task_type_str == 'file':
            steps = await self._plan_file_task(task, task_lower)
        elif task_type_str == 'code':
            steps = await self._plan_code_task(task, task_lower)
        elif task_type_str == 'data':
            steps = await self._plan_data_task(task, task_lower)
        elif task_type_str == 'network':
            steps = await self._plan_network_task(task, task_lower)
        elif task_type_str == 'query':
            steps = await self._plan_query_task(task, task_lower)
        elif task_type_str == 'command':
            steps = await self._plan_command_task(task, task_lower)
        else:
            steps = await self._plan_generic_task(task, task_lower)
            
        # Apply memory hints (skills from past)
        steps = await self._apply_memory_hints(steps, memory_hints)
        
        return steps
        
    async def _plan_system_task(self, task: str, task_lower: str) -> List[PlanStep]:
        """Plan system-related tasks."""
        steps = []
        
        # Check system status
        if any(word in task_lower for word in ['status', 'check', 'health', 'info']):
            if 'disk' in task_lower:
                steps.append(self._create_step(
                    1, "Check disk usage",
                    tool_name="disk_usage",
                    expected="Disk usage information"
                ))
            elif 'memory' in task_lower or 'ram' in task_lower:
                steps.append(self._create_step(
                    1, "Check memory usage",
                    tool_name="memory_usage",
                    expected="Memory usage statistics"
                ))
            elif 'cpu' in task_lower:
                steps.append(self._create_step(
                    1, "Check CPU usage",
                    tool_name="cpu_usage",
                    expected="CPU usage information"
                ))
            elif 'process' in task_lower:
                process_name = self._extract_process_name(task_lower)
                steps.append(self._create_step(
                    1, f"List processes{' matching ' + process_name if process_name else ''}",
                    tool_name="process_list",
                    tool_params={'filter': process_name} if process_name else {},
                    expected="Process list"
                ))
            else:
                # General system status
                steps.extend([
                    self._create_step(1, "Get system information", tool_name="system_info"),
                    self._create_step(2, "Check disk usage", tool_name="disk_usage", depends_on=["step_1"]),
                    self._create_step(3, "Check memory usage", tool_name="memory_usage", depends_on=["step_1"]),
                ])
                
        # Service operations
        elif any(word in task_lower for word in ['restart', 'start', 'stop', 'service']):
            service_name = self._extract_service_name(task_lower)
            action = 'restart' if 'restart' in task_lower else ('stop' if 'stop' in task_lower else 'start')
            
            if service_name:
                steps.append(self._create_step(
                    1, f"Check service {service_name} status",
                    tool_name="service_status",
                    tool_params={'service': service_name}
                ))
                steps.append(self._create_step(
                    2, f"{action.capitalize()} service {service_name}",
                    tool_name="service_control",
                    tool_params={'service': service_name, 'action': action},
                    requires_confirmation=True,
                    priority=StepPriority.CRITICAL,
                    depends_on=["step_1"]
                ))
            else:
                steps.append(self._create_step(
                    1, "Cannot proceed: service name not specified",
                    expected="Need clarification"
                ))
                
        return steps
        
    async def _plan_file_task(self, task: str, task_lower: str) -> List[PlanStep]:
        """Plan file-related tasks."""
        steps = []
        
        file_path = self._extract_file_path(task)
        
        if 'read' in task_lower or 'show' in task_lower or 'cat' in task_lower:
            if file_path:
                steps.append(self._create_step(
                    1, f"Read file: {file_path}",
                    tool_name="file_read",
                    tool_params={'path': file_path},
                    expected="File contents"
                ))
            else:
                steps.append(self._create_step(1, "Need file path", expected="Clarification needed"))
                
        elif 'write' in task_lower or 'create' in task_lower:
            if file_path:
                steps.append(self._create_step(
                    1, f"Check if file exists: {file_path}",
                    tool_name="file_info",
                    tool_params={'path': file_path, 'check_exists': True}
                ))
                steps.append(self._create_step(
                    2, f"Write to file: {file_path}",
                    tool_name="file_write",
                    tool_params={'path': file_path},
                    requires_confirmation=True,
                    depends_on=["step_1"]
                ))
                
        elif 'delete' in task_lower or 'remove' in task_lower:
            if file_path:
                steps.append(self._create_step(
                    1, f"Check file: {file_path}",
                    tool_name="file_info",
                    tool_params={'path': file_path}
                ))
                steps.append(self._create_step(
                    2, f"Delete file: {file_path}",
                    tool_name="file_delete",
                    tool_params={'path': file_path},
                    requires_confirmation=True,
                    priority=StepPriority.CRITICAL,
                    depends_on=["step_1"]
                ))
                
        elif 'list' in task_lower or 'ls' in task_lower:
            dir_path = file_path or '.'
            steps.append(self._create_step(
                1, f"List directory: {dir_path}",
                tool_name="dir_list",
                tool_params={'path': dir_path},
                expected="Directory listing"
            ))
            
        elif 'move' in task_lower or 'mv' in task_lower:
            # Try to extract source and destination
            steps.append(self._create_step(
                1, "Move file",
                tool_name="file_move",
                requires_confirmation=True
            ))
            
        elif 'copy' in task_lower or 'cp' in task_lower:
            steps.append(self._create_step(
                1, "Copy file",
                tool_name="file_copy"
            ))
            
        return steps
        
    async def _plan_code_task(self, task: str, task_lower: str) -> List[PlanStep]:
        """Plan code-related tasks."""
        steps = []
        
        if 'run' in task_lower or 'execute' in task_lower:
            if 'python' in task_lower:
                steps.append(self._create_step(
                    1, "Run Python code",
                    tool_name="python_run",
                    requires_confirmation=True
                ))
            elif 'bash' in task_lower or 'shell' in task_lower:
                steps.append(self._create_step(
                    1, "Run shell command",
                    tool_name="shell_executor",
                    requires_confirmation=True
                ))
            else:
                steps.append(self._create_step(
                    1, "Run code",
                    tool_name="code_runner",
                    requires_confirmation=True
                ))
                
        elif 'format' in task_lower:
            steps.append(self._create_step(
                1, "Format code",
                tool_name="code_format"
            ))
            
        elif 'lint' in task_lower or 'check' in task_lower:
            steps.append(self._create_step(
                1, "Lint code",
                tool_name="code_lint"
            ))
            
        return steps
        
    async def _plan_data_task(self, task: str, task_lower: str) -> List[PlanStep]:
        """Plan data processing tasks."""
        steps = []
        
        file_path = self._extract_file_path(task)
        
        if 'json' in task_lower:
            if 'read' in task_lower or 'parse' in task_lower:
                steps.append(self._create_step(
                    1, f"Parse JSON: {file_path or 'input'}",
                    tool_name="json_read",
                    tool_params={'path': file_path} if file_path else {}
                ))
            elif 'write' in task_lower:
                steps.append(self._create_step(
                    1, f"Write JSON: {file_path or 'output'}",
                    tool_name="json_write",
                    tool_params={'path': file_path} if file_path else {}
                ))
                
        elif 'yaml' in task_lower:
            if 'read' in task_lower:
                steps.append(self._create_step(
                    1, f"Parse YAML: {file_path or 'input'}",
                    tool_name="yaml_read",
                    tool_params={'path': file_path} if file_path else {}
                ))
                
        elif 'csv' in task_lower:
            if 'read' in task_lower:
                steps.append(self._create_step(
                    1, f"Parse CSV: {file_path or 'input'}",
                    tool_name="csv_read",
                    tool_params={'path': file_path} if file_path else {}
                ))
                
        return steps
        
    async def _plan_network_task(self, task: str, task_lower: str) -> List[PlanStep]:
        """Plan network-related tasks."""
        steps = []
        
        if 'ping' in task_lower:
            host = self._extract_host(task)
            steps.append(self._create_step(
                1, f"Ping {host or 'host'}",
                tool_name="ping",
                tool_params={'host': host} if host else {}
            ))
            
        elif 'http' in task_lower or 'request' in task_lower or 'get' in task_lower or 'api' in task_lower:
            url = self._extract_url(task)
            steps.append(self._create_step(
                1, f"HTTP request to {url or 'URL'}",
                tool_name="http_request",
                tool_params={'url': url} if url else {}
            ))
            
        elif 'dns' in task_lower:
            host = self._extract_host(task)
            steps.append(self._create_step(
                1, f"DNS lookup for {host or 'host'}",
                tool_name="dns_lookup",
                tool_params={'host': host} if host else {}
            ))
            
        elif 'download' in task_lower:
            url = self._extract_url(task)
            steps.append(self._create_step(
                1, f"Download from {url or 'URL'}",
                tool_name="download_file",
                tool_params={'url': url} if url else {}
            ))
            
        return steps
        
    async def _plan_query_task(self, task: str, task_lower: str) -> List[PlanStep]:
        """Plan information query tasks."""
        steps = []
        
        # These usually don't need tools - brain handles them
        if 'what time' in task_lower or 'current time' in task_lower:
            steps.append(self._create_step(
                1, "Get current time",
                tool_name="datetime_now"
            ))
        elif 'system' in task_lower or 'os' in task_lower:
            steps.append(self._create_step(
                1, "Get system information",
                tool_name="system_info"
            ))
            
        return steps
        
    async def _plan_command_task(self, task: str, task_lower: str) -> List[PlanStep]:
        """Plan direct command execution tasks."""
        steps = []
        
        # Extract command after "run", "execute", etc.
        command = None
        for prefix in ['run', 'execute', 'do']:
            if prefix in task_lower:
                idx = task_lower.find(prefix)
                command = task[idx + len(prefix):].strip()
                break
                
        if command:
            steps.append(self._create_step(
                1, f"Execute: {command[:50]}...",
                tool_name="shell_executor",
                tool_params={'command': command},
                requires_confirmation=True,
                priority=StepPriority.CRITICAL
            ))
            
        return steps
        
    async def _plan_generic_task(self, task: str, task_lower: str) -> List[PlanStep]:
        """Plan generic/unknown tasks."""
        # For unknown tasks, return empty - brain will handle
        return []
        
    async def _apply_memory_hints(
        self,
        steps: List[PlanStep],
        memory_hints: Dict[str, Any]
    ) -> List[PlanStep]:
        """Apply memory hints to improve plan."""
        if not memory_hints:
            return steps
            
        # Check for past failures to avoid
        failures = memory_hints.get('failures', [])
        for failure in failures:
            action = failure.get('action', '')
            for step in steps:
                if action in str(step.tool_name) or action in step.description.lower():
                    step.failure_modes.append(f"Previously failed: {failure.get('reason', 'unknown')}")
                    
        # Check for known successful procedures
        skills = memory_hints.get('skills', [])
        # Could enhance steps based on known procedures
        
        return steps
        
    def _create_step(
        self,
        number: int,
        description: str,
        tool_name: str = None,
        tool_params: Dict[str, Any] = None,
        expected: str = "",
        requires_confirmation: bool = False,
        priority: StepPriority = StepPriority.IMPORTANT,
        depends_on: List[str] = None,
        timeout: int = 60
    ) -> PlanStep:
        """Create a plan step."""
        # Validate tool exists
        if tool_name and tool_name not in self._available_tools:
            self.logger.warning(f"Tool '{tool_name}' not found in registry")
            # Don't fail - might be valid later or we'll handle in execution
            
        return PlanStep(
            step_id=f"step_{number}",
            step_number=number,
            description=description,
            tool_name=tool_name,
            tool_params=tool_params or {},
            expected_outcome=expected,
            priority=priority,
            requires_confirmation=requires_confirmation,
            timeout_seconds=timeout,
            depends_on=depends_on or []
        )
        
    def _assess_risks(self, task: str, steps: List[PlanStep]) -> Tuple[str, List[str]]:
        """Assess risk level of the plan."""
        risks = []
        risk_level = "low"
        
        task_lower = task.lower()
        
        # Check for dangerous keywords
        for keyword in self.DANGEROUS_KEYWORDS:
            if keyword in task_lower:
                risks.append(f"Contains dangerous keyword: {keyword}")
                risk_level = "high"
                
        # Check steps
        for step in steps:
            if step.requires_confirmation:
                if risk_level == "low":
                    risk_level = "medium"
                    
            if step.priority == StepPriority.CRITICAL:
                risks.append(f"Step '{step.description}' is critical")
                
        return risk_level, risks
        
    def _has_dangerous_operations(self, task: str, steps: List[PlanStep]) -> bool:
        """Check if plan contains dangerous operations."""
        task_lower = task.lower()
        
        for keyword in self.DANGEROUS_KEYWORDS:
            if keyword in task_lower:
                return True
                
        for step in steps:
            if step.requires_confirmation and step.priority == StepPriority.CRITICAL:
                return True
                
        return False
        
    # ═══════════════════════════════════════════════════════════════════════
    # EXTRACTION HELPERS
    # ═══════════════════════════════════════════════════════════════════════
    
    def _extract_file_path(self, task: str) -> Optional[str]:
        """Extract file path from task."""
        # Match paths like /path/to/file, ./file, ~/file, file.ext
        patterns = [
            r'(/[\w./\-]+)',           # Absolute path
            r'(\.\.?/[\w./\-]+)',      # Relative path
            r'(~/[\w./\-]+)',          # Home path
            r'([\w\-]+\.[\w]+)',       # file.ext
        ]
        
        for pattern in patterns:
            match = re.search(pattern, task)
            if match:
                return match.group(1)
                
        return None
        
    def _extract_service_name(self, task: str) -> Optional[str]:
        """Extract service name from task."""
        # Common services
        services = [
            'nginx', 'apache', 'apache2', 'httpd',
            'mysql', 'mariadb', 'postgresql', 'postgres',
            'redis', 'mongodb', 'docker', 'ssh', 'sshd',
            'cron', 'systemd', 'NetworkManager',
        ]
        
        task_lower = task.lower()
        for service in services:
            if service in task_lower:
                return service
                
        # Try to find after "service" keyword
        match = re.search(r'service\s+(\w+)', task_lower)
        if match:
            return match.group(1)
            
        return None
        
    def _extract_process_name(self, task: str) -> Optional[str]:
        """Extract process name from task."""
        # Common processes
        processes = ['python', 'node', 'java', 'nginx', 'apache', 'mysql', 'postgres']
        
        task_lower = task.lower()
        for proc in processes:
            if proc in task_lower:
                return proc
                
        return None
        
    def _extract_host(self, task: str) -> Optional[str]:
        """Extract hostname or IP from task."""
        # IP pattern
        ip_pattern = r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'
        match = re.search(ip_pattern, task)
        if match:
            return match.group(1)
            
        # Hostname pattern
        host_pattern = r'([a-zA-Z0-9][a-zA-Z0-9\-]*\.[\w.\-]+)'
        match = re.search(host_pattern, task)
        if match:
            return match.group(1)
            
        return None
        
    def _extract_url(self, task: str) -> Optional[str]:
        """Extract URL from task."""
        url_pattern = r'(https?://[^\s]+)'
        match = re.search(url_pattern, task)
        if match:
            return match.group(1)
        return None
        
    def get_stats(self) -> Dict[str, Any]:
        """Get planner statistics."""
        return self.stats.copy()