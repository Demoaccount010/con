#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 AUTONOMOUS AGENT - MAIN ENTRY POINT
═══════════════════════════════════════════════════════════════════════════════

 This is the main entry point for the autonomous agent.
 
 Usage:
   python -m core.main              # Default CLI mode
   python -m core.main --interface telegram
   python -m core.main --interface api
   python -m core.main --help
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import os
import sys
import asyncio
import logging
import argparse
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))


def setup_logging(level: str = "INFO"):
    """Setup logging configuration."""
    log_level = getattr(logging, level.upper(), logging.INFO)
    
    # Create logs directory
    logs_dir = PROJECT_ROOT / "logs"
    logs_dir.mkdir(exist_ok=True)
    
    # Configure logging
    logging.basicConfig(
        level=log_level,
        format='%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(logs_dir / "agent.log"),
        ]
    )
    
    # Reduce noise from other libraries
    logging.getLogger("aiohttp").setLevel(logging.WARNING)
    logging.getLogger("urllib3").setLevel(logging.WARNING)


def check_first_run() -> bool:
    """Check if first run setup is needed."""
    flag_file = PROJECT_ROOT / "identity" / "permanent_data" / "first_run_complete.flag"
    return not flag_file.exists()


def run_first_run_wizard():
    """Run the first-run setup wizard."""
    print("\n" + "=" * 60)
    print("  🚀 First-time setup required!")
    print("=" * 60)
    
    # Try to import and run the wizard
    try:
        # Add scripts to path
        scripts_path = PROJECT_ROOT / "scripts"
        sys.path.insert(0, str(scripts_path))
        
        from first_run import FirstRunWizard
        wizard = FirstRunWizard()
        success = wizard.run()
        return success
    except ImportError as e:
        print(f"\nCould not import first_run wizard: {e}")
        print("Please run: python scripts/first_run.py")
        return False
    except Exception as e:
        print(f"\nFirst run wizard failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Autonomous AI Agent",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m core.main                       # Start CLI interface
  python -m core.main --interface telegram  # Start Telegram bot
  python -m core.main --log-level DEBUG     # Enable debug logging
        """
    )
    
    parser.add_argument(
        '--interface', '-i',
        choices=['cli', 'telegram', 'api'],
        default='cli',
        help='Interface mode (default: cli)'
    )
    
    parser.add_argument(
        '--log-level', '-l',
        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
        default='INFO',
        help='Logging level (default: INFO)'
    )
    
    parser.add_argument(
        '--skip-first-run',
        action='store_true',
        help='Skip first run check'
    )
    
    parser.add_argument(
        '--version', '-v',
        action='version',
        version='Autonomous Agent v3.0.0'
    )
    
    return parser.parse_args()


async def run_cli():
    """Run CLI interface."""
    try:
        from core.agent import Agent
    except ImportError as e:
        print(f"Error importing Agent: {e}")
        print("Make sure core/agent.py exists")
        return
    
    agent = Agent()
    try:
        await agent.run_cli()
    finally:
        await agent.shutdown()


async def run_telegram():
    """Run Telegram interface."""
    logger = logging.getLogger("main")
    
    # Check for telegram token
    env_file = PROJECT_ROOT / ".env"
    telegram_token = None
    
    if env_file.exists():
        with open(env_file, 'r') as f:
            for line in f:
                if line.startswith('TELEGRAM_BOT_TOKEN='):
                    telegram_token = line.split('=', 1)[1].strip().strip('"').strip("'")
                    break
    
    if not telegram_token:
        print("\n❌ Telegram bot token not found!")
        print("\nTo set up Telegram:")
        print("1. Get a token from @BotFather on Telegram")
        print("2. Add it to .env file:")
        print("   TELEGRAM_BOT_TOKEN=your_token_here")
        print("3. Run again")
        return
    
    print("\n📱 Telegram bot mode")
    print("Token found, but Telegram interface is not fully implemented yet.")
    print("\nBasic structure exists in /telegram/ directory.")
    print("Full implementation coming soon!")
    
    # Start telegram bot
    try:
        from telegram.telegram_bot import TelegramBot
        
        # Get bot token from config
        telegram_config = load_yaml_config('telegram.yaml')
        bot_token = telegram_config.get('bot', {}).get('token')
        
        if bot_token and bot_token != 'YOUR_BOT_TOKEN_HERE':
            logger.info("Starting Telegram bot...")
            bot = TelegramBot(agent, bot_token)
            await bot.start()
            logger.info("✅ Telegram bot started successfully")
        else:
            logger.warning("Telegram bot token not configured")
    except Exception as e:
        logger.error(f"Failed to start Telegram bot: {e}")


async def run_api():
    """Run API interface."""
    print("\n🌐 API server mode")
    print("API interface is not fully implemented yet.")
    print("\nBasic structure exists in /interfaces/api_interface.py")
    print("Full implementation coming soon!")
    
    # Start API server
    try:
        from interfaces.api_interface import APIInterface
        
        # Load API config
        system_config = load_yaml_config('system.yaml')
        api_config = system_config.get('api', {})
        
        if api_config.get('enabled', False):
            logger.info("Starting API server...")
            api = APIInterface(agent)
            host = api_config.get('host', '0.0.0.0')
            port = api_config.get('port', 8000)
            await api.start(host=host, port=port)
            logger.info(f"✅ API server started at http://{host}:{port}")
    except Exception as e:
        logger.error(f"Failed to start API server: {e}")


def main():
    """Main entry point."""
    # Parse arguments
    args = parse_arguments()
    
    # Setup logging
    setup_logging(args.log_level)
    logger = logging.getLogger("main")
    
    logger.info("=" * 60)
    logger.info("  Autonomous AI Agent v3.0.0")
    logger.info("=" * 60)
    
    # Check for first run
    if not args.skip_first_run and check_first_run():
        success = run_first_run_wizard()
        if not success:
            logger.error("First run setup failed or was cancelled.")
            print("\nRun setup manually: python scripts/first_run.py")
            sys.exit(1)
    
    # Run appropriate interface
    try:
        if args.interface == 'cli':
            asyncio.run(run_cli())
        
        elif args.interface == 'telegram':
            asyncio.run(run_telegram())
        
        elif args.interface == 'api':
            asyncio.run(run_api())
        
        else:
            logger.error(f"Unknown interface: {args.interface}")
            sys.exit(1)
    
    except KeyboardInterrupt:
        logger.info("Interrupted by user")
    
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)
    
    logger.info("Agent shutdown complete")


if __name__ == "__main__":
    main()