#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 AGENT - Main Agent Class
═══════════════════════════════════════════════════════════════════════════════

 The central agent that coordinates all components.
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
import sys
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any

# Try imports with graceful fallbacks
try:
    import yaml
    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False

try:
    import aiohttp
    AIOHTTP_AVAILABLE = True
except ImportError:
    AIOHTTP_AVAILABLE = False

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.prompt import Prompt
    from rich import box
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False


class Agent:
    """
    Main Autonomous Agent class.
    
    Coordinates:
    - Configuration loading
    - LLM connection (Ollama)
    - User interaction
    - Memory management
    - Tool execution
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the agent."""
        self.logger = logging.getLogger("agent")
        self.config = config or {}
        
        # Console for output
        self.console = Console() if RICH_AVAILABLE else None
        
        # Project paths
        self.project_root = Path(__file__).parent.parent
        self.identity_dir = self.project_root / "identity" / "permanent_data"
        self.data_dir = self.project_root / "data"
        
        # Agent identity
        self.agent_name = "Axiom"
        self.owner_name = "User"
        self.owner_nickname = "User"
        self.communication_style = "balanced"
        self.show_reasoning = True
        
        # Ollama settings
        self.ollama_url = "http://localhost:11434"
        self.ollama_model = None
        
        # State
        self.initialized = False
        self.running = False
        
        # Conversation history
        self.conversation_history = []
        
        # New systems (will be initialized later)
        self.owner_verification = None
        self.self_developer = None
        
    def print(self, message: str, style: str = None):
        """Print with optional styling."""
        if self.console and style:
            self.console.print(message, style=style)
        elif self.console:
            self.console.print(message)
        else:
            print(message)
    
    async def initialize(self) -> bool:
        """Initialize all agent components."""
        self.logger.info("Initializing agent...")
        
        try:
            # Load configuration
            await self._load_configuration()
            
            # Check Ollama connection
            await self._check_ollama()
            
            # Initialize owner verification system
            await self._initialize_owner_verification()
            
            # Initialize self-development system
            await self._initialize_self_development()
            
            self.initialized = True
            self.logger.info("Agent initialized successfully")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to initialize agent: {e}")
            return False
    
    async def _load_configuration(self):
        """Load configuration from files."""
        self.logger.debug("Loading configuration...")
        
        # Load owner profile
        owner_file = self.identity_dir / "owner_profile.yaml"
        if owner_file.exists() and YAML_AVAILABLE:
            try:
                with open(owner_file, 'r') as f:
                    owner_data = yaml.safe_load(f)
                
                self.owner_name = owner_data.get('name', 'User')
                self.owner_nickname = owner_data.get('nickname', self.owner_name)
                self.communication_style = owner_data.get('communication_style', 'balanced')
                self.show_reasoning = owner_data.get('show_reasoning', True)
                
                self.logger.debug(f"Loaded owner profile: {self.owner_nickname}")
            except Exception as e:
                self.logger.warning(f"Could not load owner profile: {e}")
        
        # Load agent identity
        agent_file = self.identity_dir / "agent_identity.yaml"
        if agent_file.exists() and YAML_AVAILABLE:
            try:
                with open(agent_file, 'r') as f:
                    agent_data = yaml.safe_load(f)
                
                self.agent_name = agent_data.get('name', 'Axiom')
                self.logger.debug(f"Loaded agent identity: {self.agent_name}")
            except Exception as e:
                self.logger.warning(f"Could not load agent identity: {e}")
        
        # Load system config
        system_file = self.identity_dir / "system_config.yaml"
        if system_file.exists() and YAML_AVAILABLE:
            try:
                with open(system_file, 'r') as f:
                    system_data = yaml.safe_load(f)
                
                ollama_config = system_data.get('ollama', {})
                self.ollama_url = ollama_config.get('url', 'http://localhost:11434')
                self.ollama_model = ollama_config.get('model')
                
                self.logger.debug(f"Loaded system config: Ollama at {self.ollama_url}")
            except Exception as e:
                self.logger.warning(f"Could not load system config: {e}")
        
        # Also check .env file
        env_file = self.project_root / ".env"
        if env_file.exists():
            try:
                with open(env_file, 'r') as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith('#') and '=' in line:
                            key, value = line.split('=', 1)
                            key = key.strip()
                            value = value.strip().strip('"').strip("'")
                            
                            if key == 'OLLAMA_URL' and value:
                                self.ollama_url = value
                            elif key == 'OLLAMA_MODEL' and value:
                                self.ollama_model = value
            except Exception as e:
                self.logger.warning(f"Could not load .env: {e}")
    
    async def _check_ollama(self) -> bool:
        """Check Ollama connection and get model."""
        self.logger.debug("Checking Ollama connection...")
        
        if not AIOHTTP_AVAILABLE:
            self.logger.warning("aiohttp not available, skipping Ollama check")
            return False
        
        try:
            async with aiohttp.ClientSession() as session:
                # Check connection
                async with session.get(
                    f"{self.ollama_url}/api/tags",
                    timeout=aiohttp.ClientTimeout(total=5)
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        models = [m.get('name', '') for m in data.get('models', [])]
                        
                        if models:
                            # Use configured model or first available
                            if self.ollama_model and self.ollama_model in models:
                                pass  # Already set
                            else:
                                self.ollama_model = models[0]
                            
                            self.logger.info(f"Ollama connected. Using model: {self.ollama_model}")
                            return True
                        else:
                            self.logger.warning("Ollama running but no models available")
                            return False
                    else:
                        self.logger.warning(f"Ollama returned status {response.status}")
                        return False
                        
        except asyncio.TimeoutError:
            self.logger.warning("Ollama connection timeout")
            return False
        except Exception as e:
            self.logger.warning(f"Could not connect to Ollama: {e}")
            return False
    
    async def think(self, user_input: str) -> str:
        """
        Process user input and generate response.
        
        This is the core thinking method that:
        1. Understands the input
        2. Queries the LLM
        3. Returns response
        """
        if not AIOHTTP_AVAILABLE:
            return "I need aiohttp to communicate with Ollama. Please install it: pip install aiohttp"
        
        if not self.ollama_model:
            return "No Ollama model available. Please install a model: ollama pull llama3.2"
        
        # Build system prompt based on style
        if self.communication_style == "casual":
            style_instruction = "Be friendly, casual, and use occasional emoji. Keep responses concise but helpful."
        elif self.communication_style == "formal":
            style_instruction = "Be professional and precise. Use formal language."
        else:
            style_instruction = "Be professional but friendly. Balance formality with approachability."
        
        system_prompt = f"""You are {self.agent_name}, an autonomous AI assistant.

Your owner is {self.owner_name} (address them as {self.owner_nickname}).

{style_instruction}

Key principles:
- Never guess. If unsure, say so or ask for clarification.
- Be helpful and proactive.
- Admit when you don't know something.
- Be concise but thorough.
"""
        
        # Build messages
        messages = [
            {"role": "system", "content": system_prompt}
        ]
        
        # Add recent conversation history (last 10 messages)
        for msg in self.conversation_history[-10:]:
            messages.append(msg)
        
        # Add current message
        messages.append({"role": "user", "content": user_input})
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self.ollama_url}/api/chat",
                    json={
                        "model": self.ollama_model,
                        "messages": messages,
                        "stream": False,
                        "options": {
                            "temperature": 0.7,
                        }
                    },
                    timeout=aiohttp.ClientTimeout(total=120)
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        assistant_message = data.get('message', {}).get('content', '')
                        
                        # Save to conversation history
                        self.conversation_history.append({"role": "user", "content": user_input})
                        self.conversation_history.append({"role": "assistant", "content": assistant_message})
                        
                        return assistant_message
                    else:
                        error_text = await response.text()
                        return f"Error from Ollama: {response.status} - {error_text[:100]}"
                        
        except asyncio.TimeoutError:
            return "Request to Ollama timed out. The model might be loading or busy."
        except Exception as e:
            return f"Error communicating with Ollama: {str(e)}"
    
    def show_banner(self):
        """Show welcome banner."""
        if self.console:
            banner = Panel(
                f"[bold cyan]{self.agent_name}[/bold cyan] v3.0.0\n"
                f"[dim]Autonomous AI Agent[/dim]\n\n"
                f"Type [cyan]/help[/cyan] for commands or just start chatting!",
                title="🤖 Agent Ready",
                border_style="green",
                box=box.ROUNDED
            )
            self.console.print(banner)
            self.console.print(f"\nHey {self.owner_nickname}! 👋\n", style="green")
        else:
            print(f"\n{'='*60}")
            print(f"  🤖 {self.agent_name} v3.0.0 - Autonomous AI Agent")
            print(f"{'='*60}")
            print(f"\nHey {self.owner_nickname}! 👋")
            print("Type /help for commands or just start chatting!\n")
    
    def show_help(self):
        """Show help message."""
        help_text = """
Available Commands:
─────────────────
  /help     - Show this help message
  /status   - Show agent status
  /clear    - Clear conversation history
  /exit     - Exit the agent
  /quit     - Exit the agent

Just type normally to chat with me!
"""
        self.print(help_text)
    
    def show_status(self):
        """Show agent status."""
        status = f"""
Agent Status:
─────────────
  Name: {self.agent_name}
  Owner: {self.owner_nickname}
  Style: {self.communication_style}
  Ollama: {self.ollama_url}
  Model: {self.ollama_model or 'Not set'}
  History: {len(self.conversation_history)} messages
"""
        self.print(status)
    
    async def handle_command(self, command: str) -> bool:
        """
        Handle special commands.
        
        Returns:
            True if should continue, False if should exit
        """
        cmd = command.lower().strip()
        
        if cmd in ['/exit', '/quit']:
            self.print("\nGoodbye! 👋\n", style="yellow")
            return False
        
        elif cmd == '/help':
            self.show_help()
        
        elif cmd == '/status':
            self.show_status()
        
        elif cmd == '/clear':
            self.conversation_history.clear()
            self.print("Conversation history cleared.", style="green")
        
        else:
            self.print(f"Unknown command: {cmd}. Type /help for available commands.", style="yellow")
        
        return True
    
    async def run_cli(self):
        """Run the CLI interface."""
        if not self.initialized:
            if not await self.initialize():
                self.print("Failed to initialize agent.", style="red")
                return
        
        self.running = True
        self.show_banner()
        
        # Get prompt
        prompt = f"{self.owner_nickname} › "
        
        while self.running:
            try:
                # Get user input
                if self.console:
                    try:
                        user_input = Prompt.ask(f"[cyan]{self.owner_nickname}[/cyan]")
                    except:
                        user_input = input(prompt)
                else:
                    user_input = input(prompt)
                
                user_input = user_input.strip()
                
                if not user_input:
                    continue
                
                # Handle commands
                if user_input.startswith('/'):
                    should_continue = await self.handle_command(user_input)
                    if not should_continue:
                        break
                    continue
                
                # Check for self-development requests
                if self.self_developer and self._is_development_request(user_input):
                    await self._handle_development_request(user_input)
                    continue
                
                # Show thinking indicator
                if self.console:
                    self.console.print("[dim]Thinking...[/dim]", end="\r")
                
                # Get response
                response = await self.think(user_input)
                
                # Clear thinking indicator and show response
                if self.console:
                    self.console.print(" " * 20, end="\r")  # Clear line
                    self.console.print(Panel(
                        response,
                        title=f"🤖 {self.agent_name}",
                        border_style="green",
                        box=box.ROUNDED
                    ))
                    self.console.print()
                else:
                    print(f"\n{self.agent_name}: {response}\n")
                
            except KeyboardInterrupt:
                self.print("\n\nUse /exit to quit.", style="yellow")
            
            except EOFError:
                break
            
            except Exception as e:
                self.logger.error(f"Error in CLI loop: {e}")
                self.print(f"Error: {e}", style="red")
        
        self.running = False
    
    async def _initialize_owner_verification(self):
        """Initialize owner verification system."""
        try:
            from security.owner_verification import create_owner_verification_system
            
            self.logger.info("Initializing owner verification system...")
            
            self.owner_verification = await create_owner_verification_system(
                identity_manager=None,  # Will be added when identity manager is available
                notification_manager=None,  # Will be added when notification manager is available
                data_dir=self.data_dir / "security"
            )
            
            self.logger.info("Owner verification system initialized")
            
        except Exception as e:
            self.logger.warning(f"Could not initialize owner verification: {e}")
            # Continue without it
    
    async def _initialize_self_development(self):
        """Initialize self-development system."""
        try:
            from development.self_developer import create_self_developer
            from development.code_generator import create_code_generator
            from development.code_analyzer import create_code_analyzer
            from development.test_runner import create_test_runner
            from development.deployment_manager import create_deployment_manager
            
            self.logger.info("Initializing self-development system...")
            
            # Load development config
            dev_config_path = self.project_root / "config" / "required" / "development.yaml"
            dev_config = {}
            
            if dev_config_path.exists() and YAML_AVAILABLE:
                with open(dev_config_path, 'r') as f:
                    dev_config = yaml.safe_load(f)
            
            # Create components
            code_generator = create_code_generator(
                llm_client=None,  # Will be set when LLM client is available
                config=dev_config.get('code_generation', {})
            )
            
            code_analyzer = create_code_analyzer(
                config=dev_config.get('safety', {})
            )
            
            test_runner = create_test_runner(
                config=dev_config.get('self_development', {})
            )
            
            deployment_manager = create_deployment_manager(
                base_dir=self.project_root,
                config=dev_config.get('safety', {})
            )
            
            # Create self developer
            self.self_developer = await create_self_developer(
                llm_client=None,  # Will be set when LLM client is available
                owner_verification=self.owner_verification,
                config=dev_config.get('self_development', {})
            )
            
            # Set components
            self.self_developer.code_generator = code_generator
            self.self_developer.code_analyzer = code_analyzer
            self.self_developer.test_runner = test_runner
            self.self_developer.deployment_manager = deployment_manager
            
            self.logger.info("Self-development system initialized")
            
        except Exception as e:
            self.logger.warning(f"Could not initialize self-development: {e}")
            # Continue without it
    
    def _is_development_request(self, user_input: str) -> bool:
        """Check if user input is a development request."""
        dev_keywords = [
            'feature chahiye', 'bana de', 'banao', 'create feature',
            'add feature', 'new plugin', 'naya plugin', 'develop',
            'mujhe chahiye', 'implement karo', 'make a'
        ]
        
        user_lower = user_input.lower()
        return any(keyword in user_lower for keyword in dev_keywords)
    
    async def _handle_development_request(self, user_input: str):
        """Handle development request from user."""
        try:
            from development.self_developer import FeatureRequest, FeatureType
            
            self.print("\n🔨 Development request detected!", style="bold cyan")
            self.print("Starting feature development process...\n", style="cyan")
            
            # Create feature request
            request = FeatureRequest(
                description=user_input,
                requested_by="owner",  # In real system, use actual owner ID
                priority="medium"
            )
            
            # Show what we're building
            self.print(f"📋 Request: {user_input}\n", style="yellow")
            
            # Develop feature
            self.print("⚙️  Phase 1: Understanding requirement...", style="dim")
            
            result = await self.self_developer.develop_feature(
                request=request,
                owner_id="owner"  # In real system, use actual owner ID
            )
            
            # Show result
            if result.success:
                self.print("\n✅ Feature developed successfully!", style="bold green")
                self.print(f"Feature ID: {result.feature_id}", style="green")
                self.print(f"Deployed at: {result.deployment_path}", style="green")
                
                if result.generated_files:
                    self.print(f"\nGenerated files:", style="green")
                    for file in result.generated_files:
                        self.print(f"  • {file}", style="dim green")
                
                self.print(f"\n🎉 Feature is now active and ready to use!\n", style="bold green")
            else:
                self.print(f"\n❌ Feature development failed", style="bold red")
                self.print(f"Phase: {result.phase.value}", style="red")
                if result.error:
                    self.print(f"Error: {result.error}", style="red")
                if result.warnings:
                    self.print("\nWarnings:", style="yellow")
                    for warning in result.warnings:
                        self.print(f"  • {warning}", style="yellow")
                self.print()
            
        except Exception as e:
            self.logger.error(f"Error handling development request: {e}")
            self.print(f"\n❌ Error: {e}\n", style="red")
    
    async def shutdown(self):
        """Shutdown the agent."""
        self.logger.info("Shutting down agent...")
        self.running = False


async def main():
    """Main entry point."""
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s | %(levelname)-8s | %(name)s | %(message)s'
    )
    
    # Create and run agent
    agent = Agent()
    
    try:
        await agent.run_cli()
    finally:
        await agent.shutdown()


if __name__ == "__main__":
    asyncio.run(main())