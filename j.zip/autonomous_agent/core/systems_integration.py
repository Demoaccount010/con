"""
Systems Integration Module
===========================
Integrates all system components into the agent.
"""

import logging
from typing import Optional, Any, Dict

# Import system modules with fallbacks
try:
    from plugins.plugin_manager import PluginManager
except ImportError:
    PluginManager = None

try:
    from tasks.task_manager import TaskManager
except ImportError:
    TaskManager = None

try:
    from notifications.notification_manager import NotificationManager
except ImportError:
    NotificationManager = None

try:
    from internet.internet_manager import InternetManager
except ImportError:
    InternetManager = None

try:
    from conversation.dialogue_manager import DialogueManager
except ImportError:
    DialogueManager = None

try:
    from performance.performance_manager import PerformanceManager
except ImportError:
    PerformanceManager = None

try:
    from health.health_monitor import HealthMonitor
except ImportError:
    HealthMonitor = None

try:
    from autonomous.autonomous_controller import AutonomousController
except ImportError:
    AutonomousController = None

try:
    from learning.learning_engine import LearningEngine
except ImportError:
    LearningEngine = None

try:
    from brain.brain_controller import BrainController
except ImportError:
    BrainController = None

try:
    from interfaces.cli_interface import CLIInterface
except ImportError:
    CLIInterface = None

try:
    from interfaces.api_interface import APIInterface
except ImportError:
    APIInterface = None

try:
    from core.config_validator import ConfigValidator
except ImportError:
    ConfigValidator = None

try:
    from scripts.scripts_manager import ScriptsManager
except ImportError:
    ScriptsManager = None

try:
    from config.config_loader import ConfigLoader
except ImportError:
    ConfigLoader = None


async def initialize_all_systems(agent) -> Dict[str, Any]:
    """
    Initialize all system components for the agent.
    
    Args:
        agent: The main agent instance
        
    Returns:
        Dict with initialized systems
    """
    logger = logging.getLogger("systems_integration")
    logger.info("Initializing all system components...")
    
    systems = {}
    
    # Plugin Manager
    if PluginManager:
        try:
            systems['plugin_manager'] = PluginManager(agent)
            await systems['plugin_manager'].initialize()
            logger.info("✅ Plugin Manager")
        except Exception as e:
            logger.warning(f"Plugin Manager: {e}")
    
    # Task Manager
    if TaskManager:
        try:
            systems['task_manager'] = TaskManager(agent)
            await systems['task_manager'].initialize()
            logger.info("✅ Task Manager")
        except Exception as e:
            logger.warning(f"Task Manager: {e}")
    
    # Notification Manager
    if NotificationManager:
        try:
            systems['notification_manager'] = NotificationManager(agent)
            await systems['notification_manager'].initialize()
            logger.info("✅ Notification Manager")
        except Exception as e:
            logger.warning(f"Notification Manager: {e}")
    
    # Internet Manager
    if InternetManager:
        try:
            systems['internet_manager'] = InternetManager(agent)
            await systems['internet_manager'].initialize()
            logger.info("✅ Internet Manager")
        except Exception as e:
            logger.warning(f"Internet Manager: {e}")
    
    # Dialogue Manager
    if DialogueManager:
        try:
            systems['dialogue_manager'] = DialogueManager(agent)
            await systems['dialogue_manager'].initialize()
            logger.info("✅ Dialogue Manager")
        except Exception as e:
            logger.warning(f"Dialogue Manager: {e}")
    
    # Performance Manager
    if PerformanceManager:
        try:
            systems['performance_manager'] = PerformanceManager(agent)
            await systems['performance_manager'].initialize()
            logger.info("✅ Performance Manager")
        except Exception as e:
            logger.warning(f"Performance Manager: {e}")
    
    # Health Monitor
    if HealthMonitor:
        try:
            systems['health_monitor'] = HealthMonitor(agent)
            await systems['health_monitor'].initialize()
            logger.info("✅ Health Monitor")
        except Exception as e:
            logger.warning(f"Health Monitor: {e}")
    
    # Learning Engine (used by multiple systems)
    if LearningEngine:
        try:
            from learning.learning_engine import create_learning_engine
            systems['learning_engine'] = await create_learning_engine(
                memory_manager=getattr(agent, 'memory_manager', None),
                brain_controller=None  # Will be set after brain controller initializes
            )
            logger.info("✅ Learning Engine")
        except Exception as e:
            logger.warning(f"Learning Engine: {e}")
    
    # Brain Controller (used by autonomous mode)
    if BrainController:
        try:
            from llm.ollama_client import OllamaClient
            from llm.model_manager import ModelManager
            
            # Create LLM components if available
            ollama_client = None
            model_manager = None
            
            try:
                ollama_url = getattr(agent, 'ollama_url', 'http://localhost:11434')
                ollama_client = OllamaClient(base_url=ollama_url)
                await ollama_client.initialize()
                
                model_manager = ModelManager(ollama=ollama_client)
                await model_manager.initialize()
            except Exception as llm_error:
                logger.debug(f"LLM components unavailable: {llm_error}")
            
            if ollama_client and model_manager:
                systems['brain_controller'] = BrainController(
                    ollama=ollama_client,
                    model_manager=model_manager,
                    memory_manager=getattr(agent, 'memory_manager', None)
                )
                await systems['brain_controller'].initialize()
                
                # Update learning engine with brain controller
                if systems.get('learning_engine'):
                    systems['learning_engine'].brain_controller = systems['brain_controller']
                
                logger.info("✅ Brain Controller")
            else:
                logger.info("⚠️  Brain Controller: Ollama not available")
        except Exception as e:
            logger.warning(f"Brain Controller: {e}")
    
    # Autonomous Controller
    if AutonomousController:
        try:
            from autonomous.autonomous_controller import create_autonomous_controller
            systems['autonomous_controller'] = await create_autonomous_controller(
                memory_manager=getattr(agent, 'memory_manager', None),
                brain_controller=systems.get('brain_controller'),
                notification_sender=systems.get('notification_manager'),
                research_engine=None,  # Will be created internally if needed
                idle_detector=None  # Will be created internally if needed
            )
            logger.info("✅ Autonomous Controller")
        except Exception as e:
            logger.warning(f"Autonomous Controller: {e}")
    
    # Scripts Manager (setup scripts)
    if ScriptsManager:
        try:
            systems['scripts_manager'] = ScriptsManager(agent)
            await systems['scripts_manager'].initialize()
            logger.info("✅ Scripts Manager (Setup Scripts)")
        except Exception as e:
            logger.warning(f"Scripts Manager: {e}")
    
    # Code Runner (for executing code)
    try:
        from tools.code_ops.code_runner import get_code_runner
        systems['code_runner'] = get_code_runner()
        logger.info("✅ Code Runner")
    except Exception as e:
        logger.warning(f"Code Runner: {e}")
    
    # Interfaces
    systems['interfaces'] = {}
    if CLIInterface:
        systems['interfaces']['cli'] = CLIInterface
    
    if APIInterface:
        systems['interfaces']['api'] = APIInterface
    
    if systems['interfaces']:
        logger.info(f"✅ Interfaces: {', '.join(systems['interfaces'].keys())}")
    
    # Config Loader (loads YAML configs)
    if ConfigLoader:
        try:
            systems['config_loader'] = ConfigLoader(agent)
            await systems['config_loader'].initialize()
            logger.info("✅ Config Loader (YAML Configs)")
        except Exception as e:
            logger.warning(f"Config Loader: {e}")
    
    # Config Validator
    if ConfigValidator:
        try:
            systems['config_validator'] = ConfigValidator()
            logger.info("✅ Config Validator")
        except Exception as e:
            logger.warning(f"Config Validator: {e}")
    
    # Config Manager (legacy support)
    try:
        import yaml
        systems['config_manager'] = {
            'loaded': True, 
            'yaml_available': True,
            'config_dir': agent.project_root / 'config' / 'required'
        }
    except:
        systems['config_manager'] = {'loaded': True, 'yaml_available': False}
    
    active_count = len([s for s in systems.values() if s])
    logger.info(f"✅ {active_count} systems initialized")
    
    return systems


def get_systems_status(agent) -> Dict[str, bool]:
    """Get status of all systems."""
    return {
        'plugin_manager': hasattr(agent, 'plugin_manager') and agent.plugin_manager is not None,
        'task_manager': hasattr(agent, 'task_manager') and agent.task_manager is not None,
        'notification_manager': hasattr(agent, 'notification_manager') and agent.notification_manager is not None,
        'internet_manager': hasattr(agent, 'internet_manager') and agent.internet_manager is not None,
        'dialogue_manager': hasattr(agent, 'dialogue_manager') and agent.dialogue_manager is not None,
        'performance_manager': hasattr(agent, 'performance_manager') and agent.performance_manager is not None,
        'health_monitor': hasattr(agent, 'health_monitor') and agent.health_monitor is not None,
        'scripts_manager': hasattr(agent, 'scripts_manager') and agent.scripts_manager is not None,
        'code_runner': hasattr(agent, 'code_runner') and agent.code_runner is not None,
        'interfaces': hasattr(agent, 'interfaces') and bool(agent.interfaces),
        'config_loader': hasattr(agent, 'config_loader') and agent.config_loader is not None,
        'config_validator': hasattr(agent, 'config_validator') and agent.config_validator is not None,
        'config_manager': hasattr(agent, 'config_manager') and agent.config_manager is not None,
        'learning_engine': hasattr(agent, 'learning_engine') and agent.learning_engine is not None,
        'brain_controller': hasattr(agent, 'brain_controller') and agent.brain_controller is not None,
        'autonomous_controller': hasattr(agent, 'autonomous_controller') and agent.autonomous_controller is not None,
    }


def count_active_systems(agent) -> int:
    """Count active systems."""
    status = get_systems_status(agent)
    return sum(1 for active in status.values() if active)
