#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 AUDITOR - SAFETY VALIDATION AND VERIFICATION
═══════════════════════════════════════════════════════════════════════════════

 Validates plans and actions for safety and compliance.
 
 AUDITING PHILOSOPHY:
 ────────────────────
 • Every plan must be validated before execution
 • Dangerous operations require confirmation
 • Security constraints are NEVER bypassed
 • All actions are logged for audit trail
 • No guessing - verify everything
 
 VALIDATION CHECKS:
 ──────────────────
 • Tool existence and permissions
 • Path safety (no escape attacks)
 • Command safety (no dangerous patterns)
 • Resource limits
 • User confirmation requirements
 
 AUDIT TRAIL:
 ────────────
 • All validations are logged
 • Denied actions are recorded
 • Confirmations are tracked
 • Security events are flagged
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
import re
from datetime import datetime
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

from core.planner import Plan, PlanStep, StepPriority
from security.security_manager import SecurityManager
from memory.memory_manager import MemoryManager


class ValidationStatus(Enum):
    """Status of validation."""
    PASSED = "passed"
    FAILED = "failed"
    NEEDS_CONFIRMATION = "needs_confirmation"
    NEEDS_CLARIFICATION = "needs_clarification"
    BLOCKED = "blocked"


class RiskLevel(Enum):
    """Risk level assessment."""
    SAFE = "safe"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class ValidationIssue:
    """A single validation issue."""
    issue_type: str
    severity: RiskLevel
    message: str
    step_id: Optional[str] = None
    fixable: bool = False
    fix_suggestion: str = ""


@dataclass
class PlanValidation:
    """Result of plan validation."""
    passed: bool
    status: ValidationStatus
    
    # Issues found
    issues: List[ValidationIssue] = field(default_factory=list)
    
    # Requirements
    needs_confirmation: bool = False
    confirmation_items: List[str] = field(default_factory=list)
    needs_clarification: bool = False
    questions: List[str] = field(default_factory=list)
    
    # Blocking
    blocked: bool = False
    block_reasons: List[str] = field(default_factory=list)
    reason: str = ""
    
    # Risk assessment
    overall_risk: RiskLevel = RiskLevel.SAFE
    
    # Audit
    validated_at: datetime = field(default_factory=datetime.utcnow)
    validator_version: str = "3.0.0"
    
    def add_issue(self, issue: ValidationIssue) -> None:
        """Add a validation issue."""
        self.issues.append(issue)
        
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'passed': self.passed,
            'status': self.status.value,
            'issues_count': len(self.issues),
            'needs_confirmation': self.needs_confirmation,
            'blocked': self.blocked,
            'overall_risk': self.overall_risk.value,
        }


@dataclass
class ToolPermission:
    """Permission check result for a tool."""
    allowed: bool
    reason: str = ""
    requires_confirmation: bool = False
    risk_level: RiskLevel = RiskLevel.LOW


@dataclass
class AuditLogEntry:
    """An entry in the audit log."""
    timestamp: datetime
    event_type: str
    action: str
    result: str
    details: Dict[str, Any]
    user: str = "agent"
    risk_level: RiskLevel = RiskLevel.LOW


class Auditor:
    """
    ═══════════════════════════════════════════════════════════════════════════
    SAFETY VALIDATION AND AUDIT SYSTEM
    ═══════════════════════════════════════════════════════════════════════════
    
    Validates all plans and actions for safety and compliance.
    """
    
    # Dangerous commands that are NEVER allowed
    BLOCKED_COMMANDS = [
        r'rm\s+-rf\s+/',                    # rm -rf /
        r'rm\s+-rf\s+/\*',                  # rm -rf /*
        r'dd\s+if=.*of=/dev/sd',            # dd to disk
        r'mkfs\.',                          # Format filesystem
        r':\(\)\{:\|:&\};:',                # Fork bomb
        r'>\s*/dev/sd',                     # Write to disk
        r'chmod\s+-R\s+777\s+/',            # chmod 777 /
        r'chown\s+-R.*:.*/',                # chown /
    ]
    
    # Dangerous patterns that require confirmation
    CONFIRMATION_PATTERNS = [
        (r'rm\s+', 'delete files'),
        (r'rmdir', 'delete directories'),
        (r'drop\s+', 'drop database objects'),
        (r'truncate', 'truncate data'),
        (r'delete\s+from', 'delete database records'),
        (r'kill\s+', 'kill processes'),
        (r'shutdown', 'shutdown system'),
        (r'reboot', 'reboot system'),
        (r'systemctl\s+(stop|restart)', 'control services'),
        (r'service\s+\w+\s+(stop|restart)', 'control services'),
        (r'docker\s+rm', 'remove containers'),
        (r'docker\s+rmi', 'remove images'),
    ]
    
    # Safe path prefixes
    SAFE_PATHS = [
        '/tmp',
        '/var/tmp',
        '/home',
        '~',
        '.',
        './/',
    ]
    
    # Blocked path prefixes
    BLOCKED_PATHS = [
        '/etc/passwd',
        '/etc/shadow',
        '/etc/sudoers',
        '/boot',
        '/dev',
        '/proc',
        '/sys',
    ]
    
    def __init__(
        self,
        security: SecurityManager,
        memory: MemoryManager,
        config: Dict[str, Any] = None
    ):
        """
        Initialize auditor.
        
        Args:
            security: Security manager
            memory: Memory manager
            config: Configuration
        """
        self.logger = logging.getLogger("core.auditor")
        self.security = security
        self.memory = memory
        self.config = config or {}
        
        # Compile patterns
        self._blocked_patterns = [
            re.compile(pattern, re.IGNORECASE)
            for pattern in self.BLOCKED_COMMANDS
        ]
        self._confirmation_patterns = [
            (re.compile(pattern, re.IGNORECASE), desc)
            for pattern, desc in self.CONFIRMATION_PATTERNS
        ]
        
        # Audit log
        self._audit_log: List[AuditLogEntry] = []
        self.max_log_entries = self.config.get('max_log_entries', 10000)
        
        # Statistics
        self.stats = {
            'validations': 0,
            'passed': 0,
            'failed': 0,
            'blocked': 0,
            'confirmations_required': 0,
        }
        
    async def initialize(self) -> None:
        """Initialize auditor."""
        self.logger.info("Initializing auditor...")
        self.logger.info("Auditor initialized")
        
    async def verify_plan(self, plan: Plan) -> PlanValidation:
        """
        Verify a complete plan for safety.
        
        Args:
            plan: The plan to verify
            
        Returns:
            PlanValidation with results
        """
        self.logger.info(f"Verifying plan {plan.plan_id} with {len(plan.steps)} steps")
        self.stats['validations'] += 1
        
        validation = PlanValidation(
            passed=True,
            status=ValidationStatus.PASSED
        )
        
        # ═══════════════════════════════════════════════════════════════════
        # CHECK 1: Validate each step
        # ═══════════════════════════════════════════════════════════════════
        for step in plan.steps:
            step_validation = await self._validate_step(step)
            
            for issue in step_validation:
                validation.add_issue(issue)
                
                if issue.severity == RiskLevel.CRITICAL:
                    validation.blocked = True
                    validation.block_reasons.append(issue.message)
                elif issue.severity == RiskLevel.HIGH:
                    validation.needs_confirmation = True
                    validation.confirmation_items.append(
                        f"Step {step.step_number}: {issue.message}"
                    )
                    
        # ═══════════════════════════════════════════════════════════════════
        # CHECK 2: Check for blocked commands
        # ═══════════════════════════════════════════════════════════════════
        for step in plan.steps:
            blocked_check = self._check_blocked_commands(step)
            if blocked_check:
                validation.blocked = True
                validation.block_reasons.append(blocked_check)
                validation.add_issue(ValidationIssue(
                    issue_type='blocked_command',
                    severity=RiskLevel.CRITICAL,
                    message=blocked_check,
                    step_id=step.step_id
                ))
                
        # ═══════════════════════════════════════════════════════════════════
        # CHECK 3: Check for confirmation requirements
        # ═══════════════════════════════════════════════════════════════════
        for step in plan.steps:
            # Check if step already marked for confirmation
            if step.requires_confirmation:
                validation.needs_confirmation = True
                validation.confirmation_items.append(
                    f"Step {step.step_number}: {step.description}"
                )
                
            # Check patterns
            confirm_check = self._check_confirmation_required(step)
            if confirm_check and confirm_check not in validation.confirmation_items:
                validation.needs_confirmation = True
                validation.confirmation_items.append(confirm_check)
                
        # ═══════════════════════════════════════════════════════════════════
        # CHECK 4: Path safety
        # ═══════════════════════════════════════════════════════════════════
        for step in plan.steps:
            path_issues = self._validate_paths(step)
            for issue in path_issues:
                validation.add_issue(issue)
                if issue.severity == RiskLevel.CRITICAL:
                    validation.blocked = True
                    validation.block_reasons.append(issue.message)
                    
        # ═══════════════════════════════════════════════════════════════════
        # CHECK 5: Calculate overall risk
        # ═══════════════════════════════════════════════════════════════════
        validation.overall_risk = self._calculate_overall_risk(validation.issues)
        
        # ═══════════════════════════════════════════════════════════════════
        # DETERMINE FINAL STATUS
        # ═══════════════════════════════════════════════════════════════════
        if validation.blocked:
            validation.passed = False
            validation.status = ValidationStatus.BLOCKED
            validation.reason = "; ".join(validation.block_reasons)
            self.stats['blocked'] += 1
        elif validation.needs_clarification:
            validation.passed = False
            validation.status = ValidationStatus.NEEDS_CLARIFICATION
            self.stats['failed'] += 1
        elif validation.needs_confirmation:
            validation.passed = True  # Can proceed after confirmation
            validation.status = ValidationStatus.NEEDS_CONFIRMATION
            self.stats['confirmations_required'] += 1
            self.stats['passed'] += 1
        else:
            validation.passed = True
            validation.status = ValidationStatus.PASSED
            self.stats['passed'] += 1
            
        # Log audit entry
        self._log_audit(
            event_type='plan_validation',
            action=f"Validated plan {plan.plan_id}",
            result=validation.status.value,
            details={
                'plan_id': plan.plan_id,
                'steps': len(plan.steps),
                'issues': len(validation.issues),
                'blocked': validation.blocked,
            },
            risk_level=validation.overall_risk
        )
        
        self.logger.info(
            f"Plan validation complete: status={validation.status.value}, "
            f"risk={validation.overall_risk.value}"
        )
        
        return validation
        
    async def _validate_step(self, step: PlanStep) -> List[ValidationIssue]:
        """Validate a single step."""
        issues = []
        
        # Check tool permissions
        if step.tool_name:
            permission = await self.security.check_tool_permission(
                tool_name=step.tool_name,
                params=step.tool_params
            )
            
            if not permission.allowed:
                issues.append(ValidationIssue(
                    issue_type='permission_denied',
                    severity=RiskLevel.HIGH,
                    message=f"Tool '{step.tool_name}' not allowed: {permission.reason}",
                    step_id=step.step_id
                ))
                
        # Check critical priority steps
        if step.priority == StepPriority.CRITICAL:
            issues.append(ValidationIssue(
                issue_type='critical_step',
                severity=RiskLevel.MEDIUM,
                message=f"Critical step requires careful execution: {step.description}",
                step_id=step.step_id
            ))
            
        return issues
        
    def _check_blocked_commands(self, step: PlanStep) -> Optional[str]:
        """Check if step contains blocked commands."""
        # Check tool params for commands
        command = step.tool_params.get('command', '')
        
        if not command:
            return None
            
        for pattern in self._blocked_patterns:
            if pattern.search(command):
                return f"Blocked dangerous command pattern detected: {command[:50]}"
                
        return None
        
    def _check_confirmation_required(self, step: PlanStep) -> Optional[str]:
        """Check if step requires confirmation."""
        command = step.tool_params.get('command', '')
        description = step.description.lower()
        
        text_to_check = f"{command} {description}"
        
        for pattern, desc in self._confirmation_patterns:
            if pattern.search(text_to_check):
                return f"Step {step.step_number}: {desc} - requires confirmation"
                
        return None
        
    def _validate_paths(self, step: PlanStep) -> List[ValidationIssue]:
        """Validate paths in step parameters."""
        issues = []
        
        # Extract paths from params
        paths = []
        for key in ['path', 'source', 'destination', 'file', 'directory']:
            if key in step.tool_params:
                paths.append(step.tool_params[key])
                
        for path in paths:
            if not path:
                continue
                
            path_str = str(path)
            
            # Check blocked paths
            for blocked in self.BLOCKED_PATHS:
                if path_str.startswith(blocked):
                    issues.append(ValidationIssue(
                        issue_type='blocked_path',
                        severity=RiskLevel.CRITICAL,
                        message=f"Access to {blocked} is not allowed",
                        step_id=step.step_id
                    ))
                    
            # Check path traversal
            if '..' in path_str:
                # Normalize and check
                try:
                    normalized = str(Path(path_str).resolve())
                    for blocked in self.BLOCKED_PATHS:
                        if normalized.startswith(blocked):
                            issues.append(ValidationIssue(
                                issue_type='path_traversal',
                                severity=RiskLevel.CRITICAL,
                                message=f"Path traversal attempt detected: {path_str}",
                                step_id=step.step_id
                            ))
                except Exception:
                    issues.append(ValidationIssue(
                        issue_type='invalid_path',
                        severity=RiskLevel.MEDIUM,
                        message=f"Could not validate path: {path_str}",
                        step_id=step.step_id
                    ))
                    
        return issues
        
    def _calculate_overall_risk(self, issues: List[ValidationIssue]) -> RiskLevel:
        """Calculate overall risk level from issues."""
        if not issues:
            return RiskLevel.SAFE
            
        severities = [issue.severity for issue in issues]
        
        if RiskLevel.CRITICAL in severities:
            return RiskLevel.CRITICAL
        elif RiskLevel.HIGH in severities:
            return RiskLevel.HIGH
        elif RiskLevel.MEDIUM in severities:
            return RiskLevel.MEDIUM
        elif RiskLevel.LOW in severities:
            return RiskLevel.LOW
        else:
            return RiskLevel.SAFE
            
    async def check_tool_permission(
        self,
        tool_name: str,
        params: Dict[str, Any]
    ) -> ToolPermission:
        """
        Check if a tool is allowed with given parameters.
        
        Args:
            tool_name: Name of the tool
            params: Tool parameters
            
        Returns:
            ToolPermission result
        """
        # Delegate to security manager
        permission = await self.security.check_tool_permission(tool_name, params)
        
        # Log the check
        self._log_audit(
            event_type='permission_check',
            action=f"Check permission for {tool_name}",
            result='allowed' if permission.allowed else 'denied',
            details={'tool': tool_name, 'reason': permission.reason}
        )
        
        return ToolPermission(
            allowed=permission.allowed,
            reason=permission.reason,
            requires_confirmation=getattr(permission, 'requires_confirmation', False),
            risk_level=RiskLevel.LOW if permission.allowed else RiskLevel.HIGH
        )
        
    async def log_event(
        self,
        event_type: str,
        details: Dict[str, Any],
        risk_level: RiskLevel = RiskLevel.LOW
    ) -> None:
        """Log a security/audit event."""
        self._log_audit(
            event_type=event_type,
            action=details.get('action', 'unknown'),
            result=details.get('result', 'unknown'),
            details=details,
            risk_level=risk_level
        )
        
    def _log_audit(
        self,
        event_type: str,
        action: str,
        result: str,
        details: Dict[str, Any],
        risk_level: RiskLevel = RiskLevel.LOW
    ) -> None:
        """Add entry to audit log."""
        entry = AuditLogEntry(
            timestamp=datetime.utcnow(),
            event_type=event_type,
            action=action,
            result=result,
            details=details,
            risk_level=risk_level
        )
        
        self._audit_log.append(entry)
        
        # Trim if too large
        if len(self._audit_log) > self.max_log_entries:
            self._audit_log = self._audit_log[-self.max_log_entries:]
            
        # Log to file for high risk
        if risk_level in (RiskLevel.HIGH, RiskLevel.CRITICAL):
            self.logger.warning(
                f"High risk audit event: {event_type} - {action} - {result}"
            )
            
    def get_audit_log(
        self,
        event_type: str = None,
        risk_level: RiskLevel = None,
        limit: int = 100
    ) -> List[AuditLogEntry]:
        """
        Get audit log entries.
        
        Args:
            event_type: Filter by event type
            risk_level: Filter by risk level
            limit: Maximum entries
            
        Returns:
            List of audit entries
        """
        entries = self._audit_log
        
        if event_type:
            entries = [e for e in entries if e.event_type == event_type]
            
        if risk_level:
            entries = [e for e in entries if e.risk_level == risk_level]
            
        return entries[-limit:]
        
    def get_stats(self) -> Dict[str, Any]:
        """Get auditor statistics."""
        return {
            **self.stats,
            'audit_log_size': len(self._audit_log),
        }