"""
═══════════════════════════════════════════════════════════════════════════════════════
COMMAND OBEDIENCE - USER COMMAND COMPLIANCE SYSTEM
═══════════════════════════════════════════════════════════════════════════════════════
Ensures the agent follows ALL user commands while maintaining safety boundaries.
Handles command parsing, priority, override, and execution tracking.

PHILOSOPHY:
- User commands are PARAMOUNT (within safety limits)
- Agent explains reasoning when asked
- Never refuses without valid safety reason
- Tracks command history for accountability
"""

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Callable, Tuple, Set
import re
import json
import hashlib

logger = logging.getLogger(__name__)


class CommandType(Enum):
    """Types of user commands."""
    DIRECT = auto()          # Direct instruction ("delete file X")
    QUERY = auto()           # Question ("what is X?")
    REQUEST = auto()         # Polite request ("could you X?")
    DELEGATION = auto()      # Autonomous task ("figure out how to X")
    OVERRIDE = auto()        # Override previous decision
    CANCEL = auto()          # Cancel current action
    CONFIRM = auto()         # Confirm pending action
    DENY = auto()            # Deny pending action
    PREFERENCE = auto()      # Set preference
    TEACHING = auto()        # Teaching/correction
    META = auto()            # Meta command (about the agent itself)


class CommandPriority(Enum):
    """Priority levels for commands."""
    CRITICAL = 100    # Safety overrides, emergencies
    HIGH = 80         # Direct user commands
    NORMAL = 50       # Regular requests
    LOW = 20          # Background tasks
    DEFERRED = 10     # Can wait


class CommandStatus(Enum):
    """Status of a command."""
    PENDING = "pending"
    EXECUTING = "executing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    BLOCKED = "blocked"      # Blocked by safety
    WAITING = "waiting"      # Waiting for confirmation
    DEFERRED = "deferred"    # Deferred for later


class ObedienceLevel(Enum):
    """How strictly to follow commands."""
    STRICT = auto()      # Follow exactly as stated
    INTERPRETED = auto() # Interpret intent, may adjust
    GUIDED = auto()      # User guides, agent decides details
    AUTONOMOUS = auto()  # Agent has full discretion


@dataclass
class ParsedCommand:
    """A parsed user command."""
    raw_input: str
    command_type: CommandType
    intent: str
    action: str
    target: Optional[str] = None
    parameters: Dict[str, Any] = field(default_factory=dict)
    priority: CommandPriority = CommandPriority.NORMAL
    obedience_level: ObedienceLevel = ObedienceLevel.INTERPRETED
    requires_confirmation: bool = False
    safety_concerns: List[str] = field(default_factory=list)
    confidence: float = 1.0
    timestamp: datetime = field(default_factory=datetime.now)
    command_id: str = ""
    
    def __post_init__(self):
        if not self.command_id:
            self.command_id = hashlib.md5(
                f"{self.raw_input}{self.timestamp.isoformat()}".encode()
            ).hexdigest()[:12]


@dataclass
class CommandResult:
    """Result of command execution."""
    command_id: str
    status: CommandStatus
    success: bool
    output: Any = None
    error: Optional[str] = None
    execution_time_ms: float = 0.0
    steps_completed: int = 0
    steps_total: int = 0
    memory_tags: List[str] = field(default_factory=list)
    follow_up_needed: bool = False
    follow_up_question: Optional[str] = None


@dataclass
class CommandOverride:
    """An override of a previous decision."""
    original_command_id: str
    override_reason: str
    new_instruction: str
    timestamp: datetime = field(default_factory=datetime.now)
    user_confirmed: bool = True


class CommandParser:
    """Parses user input into structured commands."""
    
    def __init__(self, llm_client=None):
        self.llm_client = llm_client
        
        # Pattern matchers for command types
        self._patterns = {
            CommandType.CANCEL: [
                r"^(stop|cancel|abort|halt|nevermind|forget it)",
                r"don'?t (do|continue|proceed)",
            ],
            CommandType.CONFIRM: [
                r"^(yes|yeah|yep|sure|ok|okay|confirm|do it|proceed|go ahead)",
                r"^(approved?|accepted?)",
            ],
            CommandType.DENY: [
                r"^(no|nope|don'?t|cancel|stop|deny|reject)",
            ],
            CommandType.OVERRIDE: [
                r"^(actually|instead|no wait|change that|override)",
                r"I (meant|want|need) .* instead",
            ],
            CommandType.QUERY: [
                r"^(what|who|where|when|why|how|is|are|can|could|would|will|do|does)",
                r"\?$",
            ],
            CommandType.REQUEST: [
                r"^(please|could you|would you|can you|will you)",
                r"^(help me|I need|I want)",
            ],
            CommandType.PREFERENCE: [
                r"^(always|never|prefer|default|remember that)",
                r"^(from now on|in the future)",
            ],
            CommandType.TEACHING: [
                r"^(note that|remember|learn|FYI|just so you know)",
                r"^(that'?s (wrong|incorrect|right|correct))",
                r"^(actually|correction)",
            ],
            CommandType.META: [
                r"^(who are you|what are you|your name|about you)",
                r"^(explain|why did you|how did you)",
                r"^(show|display|list) .* (memory|history|status)",
            ],
        }
        
        # Dangerous action patterns
        self._dangerous_patterns = [
            (r"(rm|remove|delete)\s+(-rf?|--recursive)", "recursive deletion"),
            (r"(drop|truncate)\s+(database|table|collection)", "database destruction"),
            (r"format\s+(disk|drive|partition)", "disk formatting"),
            (r"(shutdown|reboot|halt)\s*(system|server|machine)?", "system shutdown"),
            (r"chmod\s+777", "insecure permissions"),
            (r">\s*/dev/(sd|hd|nvme)", "direct device write"),
            (r"mkfs\.", "filesystem creation"),
            (r"dd\s+if=.*/dev/", "raw disk operation"),
        ]
    
    async def parse(self, user_input: str) -> ParsedCommand:
        """Parse user input into a structured command."""
        input_clean = user_input.strip()
        input_lower = input_clean.lower()
        
        # Detect command type
        command_type = self._detect_command_type(input_lower)
        
        # Check for safety concerns
        safety_concerns = self._check_safety(input_clean)
        
        # Determine priority
        priority = self._determine_priority(command_type, safety_concerns)
        
        # Use LLM for deeper parsing if available
        intent = input_clean
        action = ""
        target = None
        parameters = {}
        confidence = 0.8
        
        if self.llm_client:
            try:
                parsed = await self._llm_parse(input_clean, command_type)
                intent = parsed.get("intent", intent)
                action = parsed.get("action", "")
                target = parsed.get("target")
                parameters = parsed.get("parameters", {})
                confidence = parsed.get("confidence", 0.8)
            except Exception as e:
                logger.warning(f"LLM parsing failed: {e}")
        else:
            # Simple extraction
            action = self._extract_action(input_clean)
            target = self._extract_target(input_clean)
        
        # Determine if confirmation needed
        requires_confirmation = bool(safety_concerns) or command_type == CommandType.OVERRIDE
        
        return ParsedCommand(
            raw_input=user_input,
            command_type=command_type,
            intent=intent,
            action=action,
            target=target,
            parameters=parameters,
            priority=priority,
            requires_confirmation=requires_confirmation,
            safety_concerns=safety_concerns,
            confidence=confidence
        )
    
    def _detect_command_type(self, input_lower: str) -> CommandType:
        """Detect the type of command from input."""
        for cmd_type, patterns in self._patterns.items():
            for pattern in patterns:
                if re.search(pattern, input_lower, re.IGNORECASE):
                    return cmd_type
        
        # Default to direct command or delegation
        if len(input_lower.split()) > 10:
            return CommandType.DELEGATION
        return CommandType.DIRECT
    
    def _check_safety(self, input_text: str) -> List[str]:
        """Check for safety concerns in the input."""
        concerns = []
        
        for pattern, description in self._dangerous_patterns:
            if re.search(pattern, input_text, re.IGNORECASE):
                concerns.append(f"Potentially dangerous: {description}")
        
        return concerns
    
    def _determine_priority(
        self,
        command_type: CommandType,
        safety_concerns: List[str]
    ) -> CommandPriority:
        """Determine command priority."""
        if safety_concerns:
            return CommandPriority.HIGH  # Safety-related = high priority for review
        
        priority_map = {
            CommandType.CANCEL: CommandPriority.CRITICAL,
            CommandType.OVERRIDE: CommandPriority.CRITICAL,
            CommandType.CONFIRM: CommandPriority.HIGH,
            CommandType.DENY: CommandPriority.HIGH,
            CommandType.DIRECT: CommandPriority.HIGH,
            CommandType.REQUEST: CommandPriority.NORMAL,
            CommandType.QUERY: CommandPriority.NORMAL,
            CommandType.PREFERENCE: CommandPriority.LOW,
            CommandType.TEACHING: CommandPriority.LOW,
            CommandType.META: CommandPriority.NORMAL,
            CommandType.DELEGATION: CommandPriority.NORMAL,
        }
        
        return priority_map.get(command_type, CommandPriority.NORMAL)
    
    async def _llm_parse(
        self,
        input_text: str,
        detected_type: CommandType
    ) -> Dict[str, Any]:
        """Use LLM for deeper command parsing."""
        prompt = f"""
        Parse this user command:
        Input: {input_text}
        Detected Type: {detected_type.name}
        
        Extract:
        1. The core intent (what does the user want?)
        2. The action to take
        3. The target (file, service, object)
        4. Any parameters or options
        5. Confidence in parsing (0-1)
        
        Respond with JSON:
        {{
            "intent": "...",
            "action": "...",
            "target": "..." or null,
            "parameters": {{}},
            "confidence": 0.0-1.0
        }}
        """
        
        response = await self.llm_client.generate(prompt, temperature=0.1)
        return json.loads(response)
    
    def _extract_action(self, input_text: str) -> str:
        """Simple action extraction."""
        # Get first verb-like word
        words = input_text.split()
        action_words = [
            "create", "delete", "read", "write", "update", "list", "show",
            "run", "execute", "start", "stop", "restart", "check", "verify",
            "find", "search", "get", "set", "install", "remove", "backup"
        ]
        
        for word in words:
            if word.lower() in action_words:
                return word.lower()
        
        return words[0].lower() if words else ""
    
    def _extract_target(self, input_text: str) -> Optional[str]:
        """Simple target extraction."""
        # Look for quoted strings
        quoted = re.findall(r'["\']([^"\']+)["\']', input_text)
        if quoted:
            return quoted[0]
        
        # Look for file paths
        paths = re.findall(r'[/~][\w./\-]+', input_text)
        if paths:
            return paths[0]
        
        return None


class CommandQueue:
    """Priority queue for commands."""
    
    def __init__(self, max_size: int = 100):
        self.max_size = max_size
        self._queue: List[ParsedCommand] = []
        self._lock = asyncio.Lock()
    
    async def add(self, command: ParsedCommand) -> bool:
        """Add command to queue."""
        async with self._lock:
            if len(self._queue) >= self.max_size:
                # Remove lowest priority
                self._queue.sort(key=lambda c: c.priority.value)
                if command.priority.value > self._queue[0].priority.value:
                    self._queue.pop(0)
                else:
                    return False
            
            self._queue.append(command)
            self._queue.sort(key=lambda c: -c.priority.value)
            return True
    
    async def get_next(self) -> Optional[ParsedCommand]:
        """Get highest priority command."""
        async with self._lock:
            if self._queue:
                return self._queue.pop(0)
            return None
    
    async def peek(self) -> Optional[ParsedCommand]:
        """Peek at next command without removing."""
        async with self._lock:
            if self._queue:
                return self._queue[0]
            return None
    
    async def cancel_all(self) -> int:
        """Cancel all pending commands."""
        async with self._lock:
            count = len(self._queue)
            self._queue.clear()
            return count
    
    def __len__(self) -> int:
        return len(self._queue)


class CommandObedience:
    """
    Main command obedience system.
    
    Ensures the agent follows user commands while maintaining safety.
    Tracks all commands for accountability and learning.
    """
    
    def __init__(
        self,
        llm_client=None,
        security_manager=None,
        memory_manager=None
    ):
        self.llm_client = llm_client
        self.security_manager = security_manager
        self.memory_manager = memory_manager
        
        # Components
        self.parser = CommandParser(llm_client)
        self.queue = CommandQueue()
        
        # State
        self._current_command: Optional[ParsedCommand] = None
        self._pending_confirmation: Optional[ParsedCommand] = None
        self._command_history: List[Tuple[ParsedCommand, CommandResult]] = []
        self._overrides: List[CommandOverride] = []
        
        # Configuration
        self.max_history = 1000
        self.auto_confirm_safe = True
        self.explain_refusals = True
        
        # Callbacks
        self._on_command_complete: List[Callable] = []
        self._on_confirmation_needed: List[Callable] = []
        
        logger.info("CommandObedience system initialized")
    
    async def process_input(
        self,
        user_input: str,
        context: Optional[Dict[str, Any]] = None
    ) -> Tuple[ParsedCommand, Optional[str]]:
        """
        Process user input and prepare for execution.
        
        Args:
            user_input: Raw user input
            context: Additional context
        
        Returns:
            Tuple of (parsed_command, immediate_response_if_any)
        """
        context = context or {}
        
        # Parse the command
        command = await self.parser.parse(user_input)
        
        logger.info(
            f"Parsed command: type={command.command_type.name}, "
            f"action={command.action}, priority={command.priority.name}"
        )
        
        # Handle special command types immediately
        immediate_response = await self._handle_special_commands(command)
        if immediate_response:
            return command, immediate_response
        
        # Check if confirmation is needed
        if command.requires_confirmation and not context.get("pre_confirmed"):
            self._pending_confirmation = command
            confirmation_msg = self._generate_confirmation_request(command)
            return command, confirmation_msg
        
        # Security check
        if self.security_manager:
            security_result = await self.security_manager.check_command_safety(
                command.action,
                command.target,
                command.parameters
            )
            
            if not security_result.get("allowed", True):
                blocked_msg = self._handle_blocked_command(
                    command, security_result.get("reason", "Security policy")
                )
                return command, blocked_msg
        
        # Add to queue
        await self.queue.add(command)
        
        return command, None
    
    async def _handle_special_commands(
        self,
        command: ParsedCommand
    ) -> Optional[str]:
        """Handle special command types that need immediate response."""
        
        if command.command_type == CommandType.CANCEL:
            cancelled = await self.cancel_current()
            if cancelled:
                return "✓ Cancelled current operation."
            else:
                return "No operation in progress to cancel."
        
        if command.command_type == CommandType.CONFIRM:
            if self._pending_confirmation:
                # Clear pending and proceed
                cmd = self._pending_confirmation
                self._pending_confirmation = None
                await self.queue.add(cmd)
                return f"✓ Confirmed. Proceeding with: {cmd.intent[:100]}"
            else:
                return "Nothing pending confirmation."
        
        if command.command_type == CommandType.DENY:
            if self._pending_confirmation:
                denied = self._pending_confirmation
                self._pending_confirmation = None
                return f"✓ Cancelled: {denied.intent[:100]}"
            else:
                return "Nothing pending to deny."
        
        if command.command_type == CommandType.OVERRIDE:
            return await self._handle_override(command)
        
        return None
    
    async def _handle_override(self, command: ParsedCommand) -> Optional[str]:
        """Handle command override."""
        if not self._current_command:
            return "No current command to override."
        
        override = CommandOverride(
            original_command_id=self._current_command.command_id,
            override_reason=command.raw_input,
            new_instruction=command.intent
        )
        self._overrides.append(override)
        
        # Cancel current and queue new
        await self.cancel_current()
        
        # Re-parse the new instruction
        new_command = await self.parser.parse(command.intent)
        await self.queue.add(new_command)
        
        return f"✓ Override accepted. Switching to: {new_command.intent[:100]}"
    
    def _generate_confirmation_request(self, command: ParsedCommand) -> str:
        """Generate confirmation request message."""
        parts = ["⚠️ This action requires confirmation:"]
        parts.append(f"\n📋 Action: {command.intent}")
        
        if command.safety_concerns:
            parts.append("\n⚠️ Safety concerns:")
            for concern in command.safety_concerns:
                parts.append(f"  • {concern}")
        
        parts.append("\n\nReply 'yes' to confirm or 'no' to cancel.")
        
        return "\n".join(parts)
    
    def _handle_blocked_command(
        self,
        command: ParsedCommand,
        reason: str
    ) -> str:
        """Handle a blocked command."""
        parts = ["🚫 Command blocked by security policy."]
        
        if self.explain_refusals:
            parts.append(f"\nReason: {reason}")
            parts.append(f"\nCommand: {command.intent[:100]}")
            
            if command.safety_concerns:
                parts.append("\nConcerns detected:")
                for concern in command.safety_concerns[:3]:
                    parts.append(f"  • {concern}")
        
        parts.append("\n\nIf you believe this is an error, please rephrase or contact the administrator.")
        
        # Record in history as blocked
        result = CommandResult(
            command_id=command.command_id,
            status=CommandStatus.BLOCKED,
            success=False,
            error=reason
        )
        self._add_to_history(command, result)
        
        return "\n".join(parts)
    
    async def get_next_command(self) -> Optional[ParsedCommand]:
        """Get the next command to execute."""
        command = await self.queue.get_next()
        if command:
            self._current_command = command
        return command
    
    async def complete_command(
        self,
        command_id: str,
        success: bool,
        output: Any = None,
        error: Optional[str] = None,
        memory_tags: Optional[List[str]] = None
    ) -> CommandResult:
        """Mark a command as complete."""
        result = CommandResult(
            command_id=command_id,
            status=CommandStatus.COMPLETED if success else CommandStatus.FAILED,
            success=success,
            output=output,
            error=error,
            memory_tags=memory_tags or []
        )
        
        # Find the command
        if self._current_command and self._current_command.command_id == command_id:
            self._add_to_history(self._current_command, result)
            self._current_command = None
        
        # Notify callbacks
        for callback in self._on_command_complete:
            try:
                await callback(result)
            except Exception as e:
                logger.error(f"Command complete callback failed: {e}")
        
        # Learn from result if memory available
        if self.memory_manager and not success:
            await self._learn_from_failure(command_id, error)
        
        return result
    
    async def cancel_current(self) -> bool:
        """Cancel the current command."""
        if not self._current_command:
            return False
        
        result = CommandResult(
            command_id=self._current_command.command_id,
            status=CommandStatus.CANCELLED,
            success=False,
            error="Cancelled by user"
        )
        
        self._add_to_history(self._current_command, result)
        self._current_command = None
        
        logger.info("Current command cancelled by user")
        return True
    
    def _add_to_history(
        self,
        command: ParsedCommand,
        result: CommandResult
    ) -> None:
        """Add command and result to history."""
        self._command_history.append((command, result))
        
        # Trim if needed
        if len(self._command_history) > self.max_history:
            self._command_history = self._command_history[-self.max_history:]
    
    async def _learn_from_failure(
        self,
        command_id: str,
        error: Optional[str]
    ) -> None:
        """Learn from command failure."""
        try:
            # Find the command
            for cmd, result in reversed(self._command_history):
                if cmd.command_id == command_id:
                    await self.memory_manager.save(
                        memory_type="failure",
                        content=f"Command failed: {cmd.intent[:200]}",
                        metadata={
                            "command_type": cmd.command_type.name,
                            "action": cmd.action,
                            "target": cmd.target,
                            "error": error,
                            "timestamp": datetime.now().isoformat()
                        }
                    )
                    logger.info(f"Learned from failure: {command_id}")
                    break
        except Exception as e:
            logger.warning(f"Failed to learn from failure: {e}")
    
    async def explain_decision(
        self,
        command_id: str
    ) -> str:
        """Explain why a decision was made for a command."""
        # Find command in history
        for cmd, result in reversed(self._command_history):
            if cmd.command_id == command_id:
                return self._generate_explanation(cmd, result)
        
        return f"No record found for command: {command_id}"
    
    def _generate_explanation(
        self,
        command: ParsedCommand,
        result: CommandResult
    ) -> str:
        """Generate explanation for a command decision."""
        parts = [f"📋 Command Analysis: {command.intent[:100]}"]
        parts.append(f"\nType: {command.command_type.name}")
        parts.append(f"Priority: {command.priority.name}")
        parts.append(f"Confidence: {command.confidence:.0%}")
        
        if command.safety_concerns:
            parts.append("\n⚠️ Safety concerns detected:")
            for concern in command.safety_concerns:
                parts.append(f"  • {concern}")
        
        parts.append(f"\nStatus: {result.status.value}")
        
        if result.success:
            parts.append("✓ Completed successfully")
        elif result.error:
            parts.append(f"✗ Failed: {result.error}")
        
        if result.memory_tags:
            parts.append(f"\nMemory tags: {', '.join(result.memory_tags)}")
        
        return "\n".join(parts)
    
    def get_pending_confirmation(self) -> Optional[ParsedCommand]:
        """Get any command pending confirmation."""
        return self._pending_confirmation
    
    def get_current_command(self) -> Optional[ParsedCommand]:
        """Get the currently executing command."""
        return self._current_command
    
    def get_history(
        self,
        limit: int = 10,
        status_filter: Optional[CommandStatus] = None
    ) -> List[Tuple[ParsedCommand, CommandResult]]:
        """Get command history."""
        history = self._command_history
        
        if status_filter:
            history = [
                (cmd, res) for cmd, res in history
                if res.status == status_filter
            ]
        
        return list(reversed(history[-limit:]))
    
    def get_stats(self) -> Dict[str, Any]:
        """Get command statistics."""
        total = len(self._command_history)
        if total == 0:
            return {"total_commands": 0}
        
        successes = sum(1 for _, r in self._command_history if r.success)
        
        type_counts = {}
        for cmd, _ in self._command_history:
            type_name = cmd.command_type.name
            type_counts[type_name] = type_counts.get(type_name, 0) + 1
        
        return {
            "total_commands": total,
            "success_rate": successes / total,
            "command_types": type_counts,
            "pending_queue": len(self.queue),
            "overrides": len(self._overrides),
            "has_pending_confirmation": self._pending_confirmation is not None
        }
    
    def on_command_complete(self, callback: Callable) -> None:
        """Register callback for command completion."""
        self._on_command_complete.append(callback)
    
    def on_confirmation_needed(self, callback: Callable) -> None:
        """Register callback for confirmation requests."""
        self._on_confirmation_needed.append(callback)


# Factory function
def create_command_obedience(
    llm_client=None,
    security_manager=None,
    memory_manager=None
) -> CommandObedience:
    """Create a command obedience system."""
    return CommandObedience(
        llm_client=llm_client,
        security_manager=security_manager,
        memory_manager=memory_manager
    )