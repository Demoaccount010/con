#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 OBSERVER - RESULT ANALYSIS AND LEARNING ENGINE
═══════════════════════════════════════════════════════════════════════════════

 Analyzes execution results and extracts insights for learning.
 
 OBSERVATION PHILOSOPHY:
 ───────────────────────
 • Every result is an opportunity to learn
 • Compare results against expectations
 • Detect patterns in successes and failures
 • Update memory based on observations
 • Extract actionable insights
 
 OBSERVATION TASKS:
 ──────────────────
 1. Analyze execution result
 2. Compare against expected outcome
 3. Detect success/failure/partial
 4. Check for memory conflicts
 5. Extract learnings
 6. Recommend next action
 
 LEARNING TRIGGERS:
 ──────────────────
 • Successful execution → Store as skill
 • Failed execution → Store as failure pattern
 • Unexpected output → Update knowledge
 • Memory conflict → Reality wins, update memory
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
import re
from datetime import datetime
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass, field
from enum import Enum

from core.planner import PlanStep
from core.executor import ExecutionResult, ExecutionStatus
from memory.memory_manager import MemoryManager, MemoryType, MemoryChange


class ObservationOutcome(Enum):
    """Outcome of observation."""
    SUCCESS = "success"
    PARTIAL_SUCCESS = "partial_success"
    FAILURE = "failure"
    UNEXPECTED = "unexpected"
    TIMEOUT = "timeout"
    ERROR = "error"


class NextAction(Enum):
    """Recommended next action."""
    CONTINUE = "continue"           # Proceed to next step
    RETRY = "retry"                 # Retry same step
    SKIP = "skip"                   # Skip and move on
    STOP = "stop"                   # Stop execution
    ALTERNATIVE = "alternative"     # Try alternative approach
    ASK_USER = "ask_user"          # Need user input


@dataclass
class ObservationResult:
    """Result of observing an execution."""
    observation_id: str
    step_id: str
    
    # Outcome
    outcome: ObservationOutcome
    success: bool
    
    # Analysis
    matched_expectation: bool
    expectation_diff: str = ""
    
    # Insights
    insights: str = ""
    learnings: List[str] = field(default_factory=list)
    
    # Memory updates detected
    memory_updates: List[MemoryChange] = field(default_factory=list)
    memory_conflicts: List[Dict[str, Any]] = field(default_factory=list)
    
    # Next action recommendation
    recommended_action: NextAction = NextAction.CONTINUE
    should_retry: bool = False
    should_stop: bool = False
    stop_reason: str = ""
    
    # Patterns detected
    patterns: List[str] = field(default_factory=list)
    
    # Timing
    observation_time_ms: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'observation_id': self.observation_id,
            'step_id': self.step_id,
            'outcome': self.outcome.value,
            'success': self.success,
            'matched_expectation': self.matched_expectation,
            'insights': self.insights,
            'recommended_action': self.recommended_action.value,
            'memory_updates': len(self.memory_updates),
        }


@dataclass
class PatternMatch:
    """A detected pattern in execution results."""
    pattern_name: str
    pattern_type: str  # success, failure, warning
    description: str
    confidence: float
    suggested_action: str


class Observer:
    """
    ═══════════════════════════════════════════════════════════════════════════
    RESULT ANALYSIS AND LEARNING ENGINE
    ═══════════════════════════════════════════════════════════════════════════
    
    Observes execution results and extracts insights for continuous learning.
    """
    
    # Known error patterns and their meanings
    ERROR_PATTERNS = {
        r'permission denied': {
            'type': 'permission',
            'action': NextAction.ASK_USER,
            'learning': 'Need elevated permissions for this operation',
            'retryable': False
        },
        r'file not found|no such file': {
            'type': 'not_found',
            'action': NextAction.STOP,
            'learning': 'Resource does not exist',
            'retryable': False
        },
        r'connection refused|connection timed out': {
            'type': 'network',
            'action': NextAction.RETRY,
            'learning': 'Network connectivity issue',
            'retryable': True
        },
        r'timeout|timed out': {
            'type': 'timeout',
            'action': NextAction.RETRY,
            'learning': 'Operation took too long',
            'retryable': True
        },
        r'disk full|no space left': {
            'type': 'resource',
            'action': NextAction.STOP,
            'learning': 'Disk space exhausted',
            'retryable': False
        },
        r'memory|out of memory|oom': {
            'type': 'resource',
            'action': NextAction.STOP,
            'learning': 'Memory exhausted',
            'retryable': False
        },
        r'already exists': {
            'type': 'exists',
            'action': NextAction.ASK_USER,
            'learning': 'Resource already exists',
            'retryable': False
        },
        r'not running|stopped|inactive': {
            'type': 'state',
            'action': NextAction.CONTINUE,
            'learning': 'Service/process not running',
            'retryable': False
        },
    }
    
    # Success patterns to learn from
    SUCCESS_PATTERNS = {
        r'successfully|completed|done|ok|success': {
            'type': 'success',
            'confidence': 0.9
        },
        r'created|written|saved': {
            'type': 'create_success',
            'confidence': 0.85
        },
        r'started|running|active': {
            'type': 'service_success',
            'confidence': 0.9
        },
        r'deleted|removed': {
            'type': 'delete_success',
            'confidence': 0.85
        },
    }
    
    def __init__(self, memory: MemoryManager, config: Dict[str, Any] = None):
        """
        Initialize observer.
        
        Args:
            memory: Memory manager
            config: Configuration
        """
        self.logger = logging.getLogger("core.observer")
        self.memory = memory
        self.config = config or {}
        
        # Compile regex patterns
        self._error_patterns = {
            re.compile(pattern, re.IGNORECASE): info
            for pattern, info in self.ERROR_PATTERNS.items()
        }
        self._success_patterns = {
            re.compile(pattern, re.IGNORECASE): info
            for pattern, info in self.SUCCESS_PATTERNS.items()
        }
        
        # Statistics
        self.stats = {
            'observations': 0,
            'successes': 0,
            'failures': 0,
            'patterns_detected': 0,
            'memory_updates': 0,
            'learnings_extracted': 0,
        }
        
    async def initialize(self) -> None:
        """Initialize observer."""
        self.logger.info("Initializing observer...")
        self.logger.info("Observer initialized")
        
    async def observe(
        self,
        step: PlanStep,
        result: ExecutionResult,
        memory_hints: Dict[str, Any] = None
    ) -> ObservationResult:
        """
        Observe and analyze an execution result.
        
        Args:
            step: The plan step that was executed
            result: The execution result
            memory_hints: Relevant memory hints
            
        Returns:
            ObservationResult with analysis and recommendations
        """
        import time
        from uuid import uuid4
        
        start_time = time.perf_counter()
        observation_id = str(uuid4())[:8]
        
        self.logger.debug(f"Observing result for step {step.step_number}")
        self.stats['observations'] += 1
        
        # Initialize observation
        observation = ObservationResult(
            observation_id=observation_id,
            step_id=step.step_id,
            outcome=ObservationOutcome.SUCCESS if result.success else ObservationOutcome.FAILURE,
            success=result.success,
            matched_expectation=False
        )
        
        # ═══════════════════════════════════════════════════════════════════
        # STEP 1: Analyze outcome
        # ═══════════════════════════════════════════════════════════════════
        observation.outcome = self._determine_outcome(result)
        
        if result.success:
            self.stats['successes'] += 1
        else:
            self.stats['failures'] += 1
            
        # ═══════════════════════════════════════════════════════════════════
        # STEP 2: Compare against expectation
        # ═══════════════════════════════════════════════════════════════════
        observation.matched_expectation, observation.expectation_diff = \
            self._compare_expectation(step.expected_outcome, result)
            
        # ═══════════════════════════════════════════════════════════════════
        # STEP 3: Detect patterns
        # ═══════════════════════════════════════════════════════════════════
        patterns = self._detect_patterns(result)
        observation.patterns = [p.pattern_name for p in patterns]
        
        if patterns:
            self.stats['patterns_detected'] += len(patterns)
            
        # ═══════════════════════════════════════════════════════════════════
        # STEP 4: Check for memory conflicts
        # ═══════════════════════════════════════════════════════════════════
        conflicts = await self._check_memory_conflicts(result, memory_hints)
        observation.memory_conflicts = conflicts
        
        # ═══════════════════════════════════════════════════════════════════
        # STEP 5: Determine memory updates
        # ═══════════════════════════════════════════════════════════════════
        memory_updates = await self._determine_memory_updates(
            step, result, observation.outcome, patterns
        )
        observation.memory_updates = memory_updates
        self.stats['memory_updates'] += len(memory_updates)
        
        # ═══════════════════════════════════════════════════════════════════
        # STEP 6: Extract learnings
        # ═══════════════════════════════════════════════════════════════════
        learnings = self._extract_learnings(step, result, patterns)
        observation.learnings = learnings
        self.stats['learnings_extracted'] += len(learnings)
        
        # ═══════════════════════════════════════════════════════════════════
        # STEP 7: Generate insights
        # ═══════════════════════════════════════════════════════════════════
        observation.insights = self._generate_insights(
            step, result, observation.outcome, patterns, learnings
        )
        
        # ═══════════════════════════════════════════════════════════════════
        # STEP 8: Recommend next action
        # ═══════════════════════════════════════════════════════════════════
        action, should_retry, should_stop, stop_reason = \
            self._recommend_action(result, patterns, step)
            
        observation.recommended_action = action
        observation.should_retry = should_retry
        observation.should_stop = should_stop
        observation.stop_reason = stop_reason
        
        # Record timing
        observation.observation_time_ms = int((time.perf_counter() - start_time) * 1000)
        
        self.logger.debug(
            f"Observation complete: outcome={observation.outcome.value}, "
            f"action={observation.recommended_action.value}"
        )
        
        return observation
        
    def _determine_outcome(self, result: ExecutionResult) -> ObservationOutcome:
        """Determine the observation outcome from execution result."""
        if result.success:
            return ObservationOutcome.SUCCESS
            
        if result.status == ExecutionStatus.TIMEOUT:
            return ObservationOutcome.TIMEOUT
            
        if result.status == ExecutionStatus.PERMISSION_DENIED:
            return ObservationOutcome.FAILURE
            
        if result.error:
            error_lower = result.error.lower()
            
            # Check for partial success indicators
            if any(word in error_lower for word in ['partial', 'some', 'incomplete']):
                return ObservationOutcome.PARTIAL_SUCCESS
                
            # Check for unexpected results
            if any(word in error_lower for word in ['unexpected', 'strange', 'unusual']):
                return ObservationOutcome.UNEXPECTED
                
        return ObservationOutcome.FAILURE
        
    def _compare_expectation(
        self,
        expected: str,
        result: ExecutionResult
    ) -> Tuple[bool, str]:
        """Compare result against expected outcome."""
        if not expected:
            return True, ""  # No expectation set
            
        output_str = str(result.output or "").lower()
        expected_lower = expected.lower()
        
        # Check if expected keywords are in output
        expected_words = expected_lower.split()
        matched_words = sum(1 for word in expected_words if word in output_str)
        
        match_ratio = matched_words / len(expected_words) if expected_words else 0
        
        if match_ratio > 0.5:
            return True, ""
        elif result.success:
            return True, "Success but output differs from expectation"
        else:
            return False, f"Expected: {expected[:50]}, Got: {str(result.output)[:50]}"
            
    def _detect_patterns(self, result: ExecutionResult) -> List[PatternMatch]:
        """Detect patterns in execution result."""
        patterns = []
        
        # Combine output and error for pattern matching
        text_to_check = ""
        if result.output:
            text_to_check += str(result.output) + " "
        if result.error:
            text_to_check += result.error
            
        if not text_to_check:
            return patterns
            
        # Check error patterns
        for pattern, info in self._error_patterns.items():
            if pattern.search(text_to_check):
                patterns.append(PatternMatch(
                    pattern_name=info['type'],
                    pattern_type='failure',
                    description=info['learning'],
                    confidence=0.9,
                    suggested_action=info['action'].value
                ))
                
        # Check success patterns (only if result was successful)
        if result.success:
            for pattern, info in self._success_patterns.items():
                if pattern.search(text_to_check):
                    patterns.append(PatternMatch(
                        pattern_name=info['type'],
                        pattern_type='success',
                        description=f"Matched success pattern: {info['type']}",
                        confidence=info['confidence'],
                        suggested_action='continue'
                    ))
                    
        return patterns
        
    async def _check_memory_conflicts(
        self,
        result: ExecutionResult,
        memory_hints: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """Check if result conflicts with memory."""
        conflicts = []
        
        if not memory_hints or not result.output:
            return conflicts
            
        # Check facts from hints
        facts = memory_hints.get('facts', [])
        output_str = str(result.output).lower()
        
        for fact in facts:
            fact_value = str(fact.get('value', '')).lower()
            fact_key = fact.get('key', '')
            
            # Simple conflict detection - value in output differs
            if fact_key and fact_value:
                # Check if fact key is mentioned in output
                if fact_key.lower() in output_str:
                    # Check if value differs
                    if fact_value not in output_str:
                        conflicts.append({
                            'key': fact_key,
                            'memory_value': fact.get('value'),
                            'actual_value': result.output,
                            'type': 'value_mismatch'
                        })
                        
        return conflicts
        
    async def _determine_memory_updates(
        self,
        step: PlanStep,
        result: ExecutionResult,
        outcome: ObservationOutcome,
        patterns: List[PatternMatch]
    ) -> List[MemoryChange]:
        """Determine what memory updates should be made."""
        updates = []
        
        # Store successful skill
        if outcome == ObservationOutcome.SUCCESS and step.tool_name:
            # Store as a learned skill
            skill_key = f"skill_{step.tool_name}_{step.step_id[:4]}"
            updates.append(MemoryChange(
                change_type='learned',
                key=skill_key,
                new_value={
                    'tool': step.tool_name,
                    'params': step.tool_params,
                    'description': step.description,
                    'success': True
                },
                reason='Successful execution - learned as skill'
            ))
            
        # Store failure pattern
        elif outcome == ObservationOutcome.FAILURE and result.error:
            failure_key = f"failure_{step.tool_name}_{step.step_id[:4]}"
            updates.append(MemoryChange(
                change_type='saved',
                key=failure_key,
                new_value={
                    'tool': step.tool_name,
                    'error': result.error[:200],
                    'patterns': [p.pattern_name for p in patterns],
                    'avoid': True
                },
                reason='Failed execution - stored to avoid repeating'
            ))
            
        return updates
        
    def _extract_learnings(
        self,
        step: PlanStep,
        result: ExecutionResult,
        patterns: List[PatternMatch]
    ) -> List[str]:
        """Extract learnings from the execution."""
        learnings = []
        
        # Learn from success
        if result.success:
            learnings.append(
                f"Successfully executed {step.tool_name or 'step'} - can use this approach again"
            )
            
        # Learn from failure patterns
        for pattern in patterns:
            if pattern.pattern_type == 'failure':
                learnings.append(pattern.description)
                
        # Learn from timeout
        if result.status == ExecutionStatus.TIMEOUT:
            learnings.append(
                f"Operation timed out after {step.timeout_seconds}s - may need longer timeout"
            )
            
        # Learn from permission denied
        if result.status == ExecutionStatus.PERMISSION_DENIED:
            learnings.append(
                f"Permission denied for {step.tool_name} - need elevated privileges"
            )
            
        return learnings
        
    def _generate_insights(
        self,
        step: PlanStep,
        result: ExecutionResult,
        outcome: ObservationOutcome,
        patterns: List[PatternMatch],
        learnings: List[str]
    ) -> str:
        """Generate human-readable insights."""
        parts = []
        
        # Outcome summary
        if outcome == ObservationOutcome.SUCCESS:
            parts.append(f"Step '{step.description}' completed successfully.")
        elif outcome == ObservationOutcome.PARTIAL_SUCCESS:
            parts.append(f"Step '{step.description}' partially completed.")
        elif outcome == ObservationOutcome.TIMEOUT:
            parts.append(f"Step '{step.description}' timed out.")
        else:
            parts.append(f"Step '{step.description}' failed.")
            
        # Pattern insights
        if patterns:
            pattern_names = [p.pattern_name for p in patterns]
            parts.append(f"Detected patterns: {', '.join(pattern_names)}")
            
        # Key learnings
        if learnings:
            parts.append(f"Learned: {learnings[0]}")
            
        return " ".join(parts)
        
    def _recommend_action(
        self,
        result: ExecutionResult,
        patterns: List[PatternMatch],
        step: PlanStep
    ) -> Tuple[NextAction, bool, bool, str]:
        """
        Recommend next action based on observation.
        
        Returns:
            Tuple of (action, should_retry, should_stop, stop_reason)
        """
        # Success - continue
        if result.success:
            return NextAction.CONTINUE, False, False, ""
            
        # Check patterns for recommendations
        for pattern in patterns:
            if pattern.pattern_type == 'failure':
                pattern_info = None
                for regex_pattern, info in self._error_patterns.items():
                    if info['type'] == pattern.pattern_name:
                        pattern_info = info
                        break
                        
                if pattern_info:
                    action = pattern_info['action']
                    retryable = pattern_info['retryable']
                    
                    if action == NextAction.STOP:
                        return action, False, True, pattern.description
                    elif action == NextAction.RETRY and retryable:
                        return action, True, False, ""
                    elif action == NextAction.ASK_USER:
                        return action, False, True, f"Need user input: {pattern.description}"
                        
        # Timeout - retry once
        if result.status == ExecutionStatus.TIMEOUT:
            return NextAction.RETRY, True, False, ""
            
        # Permission denied - stop
        if result.status == ExecutionStatus.PERMISSION_DENIED:
            return NextAction.STOP, False, True, "Permission denied"
            
        # Default - continue despite failure (non-critical)
        if step.priority.value != 'critical':
            return NextAction.CONTINUE, False, False, ""
            
        # Critical step failed - stop
        return NextAction.STOP, False, True, "Critical step failed"
        
    async def learn_from_session(
        self,
        observations: List[ObservationResult]
    ) -> Dict[str, Any]:
        """
        Extract session-level learnings from all observations.
        
        Args:
            observations: All observations from a session
            
        Returns:
            Summary of learnings
        """
        total = len(observations)
        successes = sum(1 for o in observations if o.success)
        failures = total - successes
        
        all_learnings = []
        all_patterns = []
        
        for obs in observations:
            all_learnings.extend(obs.learnings)
            all_patterns.extend(obs.patterns)
            
        # Store session summary if significant
        if total > 3:
            summary = {
                'total_steps': total,
                'success_rate': successes / total,
                'common_patterns': list(set(all_patterns)),
                'key_learnings': list(set(all_learnings))[:5]
            }
            
            # Store in memory
            await self.memory.store(
                key=f"session_learning_{datetime.utcnow().strftime('%Y%m%d_%H%M')}",
                value=summary,
                memory_type=MemoryType.EPISODE,
                category='sessions'
            )
            
            return summary
            
        return {'total_steps': total, 'successes': successes, 'failures': failures}
        
    def get_stats(self) -> Dict[str, Any]:
        """Get observer statistics."""
        return self.stats.copy()