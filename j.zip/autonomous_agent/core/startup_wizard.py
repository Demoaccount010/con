#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 STARTUP WIZARD - SMART ONBOARDING WITH AUTO-DETECTION
═══════════════════════════════════════════════════════════════════════════════

 This wizard runs on FIRST LAUNCH ONLY.
 
 PHILOSOPHY:
 ───────────
 • AUTO-DETECT everything possible
 • Only ASK what cannot be detected
 • NEVER ask the same question twice
 • Store answers PERMANENTLY
 
 AUTO-DETECTED:
 ──────────────
 • Ollama URL (scan multiple locations)
 • Available Ollama models
 • Best model based on system RAM
 • System timezone
 • System locale/language
 • OS username
 • System specs (RAM, CPU, disk)
 • Installed tools (git, docker, etc.)
 • Network connectivity
 • Telegram token from .env file
 
 MUST ASK:
 ─────────
 • Owner's name/nickname
 • Agent's name
 • Communication preferences
 • Telegram token (if not auto-detected)
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import os
import sys
import asyncio
import socket
import locale
import platform
import subprocess
import json
import aiohttp
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass, field

# Project imports
PROJECT_ROOT = Path(__file__).parent.parent.absolute()
sys.path.insert(0, str(PROJECT_ROOT))

from output.output_manager import OutputManager


@dataclass
class WizardResult:
    """Result of the startup wizard."""
    success: bool
    config: Dict[str, Any] = field(default_factory=dict)
    owner_config: Dict[str, Any] = field(default_factory=dict)
    agent_config: Dict[str, Any] = field(default_factory=dict)
    errors: List[str] = field(default_factory=list)


@dataclass
class DetectionResult:
    """Result of auto-detection."""
    detected: bool
    value: Any
    source: str
    confidence: float  # 0.0 to 1.0


class StartupWizard:
    """
    ═══════════════════════════════════════════════════════════════════════════
    SMART ONBOARDING WIZARD
    ═══════════════════════════════════════════════════════════════════════════
    
    Automatically detects as much as possible, only asks essential questions.
    """
    
    # Ollama URL candidates to scan
    OLLAMA_URLS = [
        "http://localhost:11434",
        "http://127.0.0.1:11434",
        "http://ollama:11434",          # Docker service name
        "http://host.docker.internal:11434",  # Docker host
    ]
    
    # Model preferences based on available RAM (GB)
    MODEL_PREFERENCES = {
        32: ["llama3:70b", "llama3:8b", "mistral:7b"],
        16: ["llama3:8b", "mistral:7b", "llama2:7b"],
        8: ["llama3:8b", "mistral:7b", "phi3:mini"],
        4: ["phi3:mini", "tinyllama:1b", "gemma:2b"],
        2: ["tinyllama:1b", "gemma:2b"],
    }
    
    def __init__(self, output: OutputManager):
        """Initialize the wizard."""
        self.output = output
        self.detected: Dict[str, DetectionResult] = {}
        self.answers: Dict[str, Any] = {}
        
    async def run(self) -> WizardResult:
        """
        Run the complete setup wizard.
        
        FLOW:
        1. Welcome message
        2. Auto-detection phase
        3. Show what was detected
        4. Ask essential questions
        5. Confirm and save
        """
        try:
            # ═══════════════════════════════════════════════════════════════
            # WELCOME
            # ═══════════════════════════════════════════════════════════════
            
            self._print_welcome()
            
            # ═══════════════════════════════════════════════════════════════
            # AUTO-DETECTION PHASE
            # ═══════════════════════════════════════════════════════════════
            
            self.output.print_header("AUTO-DETECTING SYSTEM", icon="🔍")
            self.output.print_info("Please wait while I detect your system configuration...\n")
            
            await self._run_all_detections()
            
            # ═══════════════════════════════════════════════════════════════
            # SHOW DETECTION RESULTS
            # ═══════════════════════════════════════════════════════════════
            
            self._print_detection_results()
            
            # ═══════════════════════════════════════════════════════════════
            # ASK ESSENTIAL QUESTIONS
            # ═══════════════════════════════════════════════════════════════
            
            self.output.print_header("A FEW QUESTIONS", icon="❓")
            self.output.print_info("I need to ask you a few things I couldn't detect:\n")
            
            await self._ask_essential_questions()
            
            # ═══════════════════════════════════════════════════════════════
            # ASK FOR MISSING REQUIRED ITEMS
            # ═══════════════════════════════════════════════════════════════
            
            await self._ask_missing_required()
            
            # ═══════════════════════════════════════════════════════════════
            # CONFIRMATION
            # ═══════════════════════════════════════════════════════════════
            
            self.output.print_header("CONFIRM SETUP", icon="✅")
            self._print_final_summary()
            
            confirm = await self._ask("Is this correct? (yes/no): ", default="yes")
            
            if confirm.lower() not in ('yes', 'y'):
                self.output.print_warning("Setup cancelled. Please run again.")
                return WizardResult(success=False)
                
            # ═══════════════════════════════════════════════════════════════
            # SAVE CONFIGURATION
            # ═══════════════════════════════════════════════════════════════
            
            self.output.print_status("Saving configuration...")
            config = await self._save_configuration()
            
            self.output.print_success("Configuration saved! Setup complete.")
            self.output.print_info("\n🚀 Starting your AI agent...\n")
            
            return WizardResult(
                success=True,
                config=config,
                owner_config=config.get('owner', {}),
                agent_config=config.get('agent', {})
            )
            
        except KeyboardInterrupt:
            self.output.print_warning("\nSetup interrupted by user.")
            return WizardResult(success=False, errors=["User interrupted"])
            
        except Exception as e:
            self.output.print_error(f"Setup failed: {e}")
            return WizardResult(success=False, errors=[str(e)])
            
    def _print_welcome(self) -> None:
        """Print welcome message."""
        print("""
╔═══════════════════════════════════════════════════════════════════════════╗
║                                                                           ║
║   🎉  WELCOME TO THE AUTONOMOUS AGENT SETUP WIZARD  🎉                   ║
║                                                                           ║
╠═══════════════════════════════════════════════════════════════════════════╣
║                                                                           ║
║   I'm about to become your personal AI assistant.                        ║
║                                                                           ║
║   This setup will only happen ONCE. I will:                              ║
║   • Auto-detect as much as possible                                      ║
║   • Ask you only essential questions                                     ║
║   • Remember everything forever                                          ║
║                                                                           ║
║   Let's get started!                                                      ║
║                                                                           ║
╚═══════════════════════════════════════════════════════════════════════════╝
        """)
        
    async def _run_all_detections(self) -> None:
        """Run all auto-detection tasks."""
        detection_tasks = [
            ("system_info", self._detect_system_info),
            ("timezone", self._detect_timezone),
            ("locale", self._detect_locale),
            ("username", self._detect_username),
            ("ollama_url", self._detect_ollama),
            ("ollama_models", self._detect_ollama_models),
            ("best_model", self._detect_best_model),
            ("installed_tools", self._detect_installed_tools),
            ("telegram_token", self._detect_telegram_token),
            ("network", self._detect_network),
        ]
        
        for name, detector in detection_tasks:
            try:
                self.output.print_status(f"Detecting {name}...")
                result = await detector()
                self.detected[name] = result
                
                if result.detected:
                    self.output.print_success(f"  ✓ {name}: {self._format_detection(result.value)}")
                else:
                    self.output.print_warning(f"  ✗ {name}: Not detected")
                    
            except Exception as e:
                self.detected[name] = DetectionResult(
                    detected=False,
                    value=None,
                    source=f"error: {e}",
                    confidence=0.0
                )
                self.output.print_warning(f"  ✗ {name}: Error ({e})")
                
        print()  # Blank line after detections
        
    def _format_detection(self, value: Any) -> str:
        """Format detection value for display."""
        if isinstance(value, dict):
            return json.dumps(value, default=str)[:50] + "..."
        if isinstance(value, list):
            if len(value) > 3:
                return f"{value[:3]}... ({len(value)} items)"
            return str(value)
        return str(value)[:50]
        
    async def _detect_system_info(self) -> DetectionResult:
        """Detect system information."""
        import psutil
        
        info = {
            "os": platform.system(),
            "os_version": platform.release(),
            "architecture": platform.machine(),
            "python_version": platform.python_version(),
            "cpu_count": psutil.cpu_count(),
            "ram_gb": round(psutil.virtual_memory().total / (1024**3), 1),
            "disk_gb": round(psutil.disk_usage('/').total / (1024**3), 1),
        }
        
        return DetectionResult(
            detected=True,
            value=info,
            source="psutil",
            confidence=1.0
        )
        
    async def _detect_timezone(self) -> DetectionResult:
        """Detect system timezone."""
        import time
        
        # Try multiple methods
        timezone = None
        source = "unknown"
        
        # Method 1: TZ environment variable
        if os.environ.get('TZ'):
            timezone = os.environ['TZ']
            source = "TZ env var"
            
        # Method 2: /etc/timezone (Linux)
        elif Path('/etc/timezone').exists():
            timezone = Path('/etc/timezone').read_text().strip()
            source = "/etc/timezone"
            
        # Method 3: time module
        else:
            try:
                timezone = time.tzname[0]
                source = "time.tzname"
            except:
                pass
                
        if timezone:
            return DetectionResult(
                detected=True,
                value=timezone,
                source=source,
                confidence=0.9
            )
            
        return DetectionResult(detected=False, value=None, source="", confidence=0.0)
        
    async def _detect_locale(self) -> DetectionResult:
        """Detect system locale/language."""
        try:
            lang, encoding = locale.getdefaultlocale()
            
            if lang:
                return DetectionResult(
                    detected=True,
                    value={"language": lang, "encoding": encoding},
                    source="locale.getdefaultlocale",
                    confidence=0.9
                )
        except:
            pass
            
        return DetectionResult(detected=False, value=None, source="", confidence=0.0)
        
    async def _detect_username(self) -> DetectionResult:
        """Detect OS username."""
        username = os.environ.get('USER') or os.environ.get('USERNAME')
        
        if not username:
            try:
                import pwd
                username = pwd.getpwuid(os.getuid()).pw_name
            except:
                pass
                
        if username:
            return DetectionResult(
                detected=True,
                value=username,
                source="os.environ",
                confidence=1.0
            )
            
        return DetectionResult(detected=False, value=None, source="", confidence=0.0)
        
    async def _detect_ollama(self) -> DetectionResult:
        """Detect Ollama server URL."""
        # Check OLLAMA_HOST env var first
        env_url = os.environ.get('OLLAMA_HOST')
        if env_url:
            if await self._check_ollama_url(env_url):
                return DetectionResult(
                    detected=True,
                    value=env_url,
                    source="OLLAMA_HOST env var",
                    confidence=1.0
                )
                
        # Scan known URLs
        for url in self.OLLAMA_URLS:
            if await self._check_ollama_url(url):
                return DetectionResult(
                    detected=True,
                    value=url,
                    source="port scan",
                    confidence=0.95
                )
                
        return DetectionResult(detected=False, value=None, source="", confidence=0.0)
        
    async def _check_ollama_url(self, url: str) -> bool:
        """Check if Ollama is running at URL."""
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=3)) as session:
                async with session.get(f"{url}/api/version") as response:
                    return response.status == 200
        except:
            return False
            
    async def _detect_ollama_models(self) -> DetectionResult:
        """Detect available Ollama models."""
        ollama_url = self.detected.get('ollama_url')
        
        if not ollama_url or not ollama_url.detected:
            return DetectionResult(detected=False, value=None, source="no ollama", confidence=0.0)
            
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"{ollama_url.value}/api/tags") as response:
                    if response.status == 200:
                        data = await response.json()
                        models = [m['name'] for m in data.get('models', [])]
                        
                        return DetectionResult(
                            detected=len(models) > 0,
                            value=models,
                            source="ollama API",
                            confidence=1.0
                        )
        except:
            pass
            
        return DetectionResult(detected=False, value=[], source="", confidence=0.0)
        
    async def _detect_best_model(self) -> DetectionResult:
        """Select best model based on available RAM and installed models."""
        import psutil
        
        # Get RAM
        ram_gb = psutil.virtual_memory().total / (1024**3)
        
        # Get available models
        models_result = self.detected.get('ollama_models')
        available_models = models_result.value if models_result and models_result.detected else []
        
        # Find best preference tier
        best_model = None
        for ram_threshold in sorted(self.MODEL_PREFERENCES.keys(), reverse=True):
            if ram_gb >= ram_threshold:
                for preferred_model in self.MODEL_PREFERENCES[ram_threshold]:
                    # Check if any available model matches (partial match)
                    for available in available_models:
                        if preferred_model.split(':')[0] in available:
                            best_model = available
                            break
                    if best_model:
                        break
            if best_model:
                break
                
        # Fallback to first available
        if not best_model and available_models:
            best_model = available_models[0]
            
        if best_model:
            return DetectionResult(
                detected=True,
                value=best_model,
                source=f"auto-selected for {ram_gb:.1f}GB RAM",
                confidence=0.85
            )
            
        return DetectionResult(detected=False, value=None, source="no models", confidence=0.0)
        
    async def _detect_installed_tools(self) -> DetectionResult:
        """Detect installed system tools."""
        tools_to_check = [
            'git', 'docker', 'python3', 'node', 'npm', 'pip',
            'curl', 'wget', 'ssh', 'rsync', 'vim', 'nano',
            'systemctl', 'journalctl', 'htop', 'nginx', 'mysql',
            'psql', 'redis-cli', 'mongod', 'kubectl', 'helm'
        ]
        
        installed = []
        for tool in tools_to_check:
            try:
                result = subprocess.run(
                    ['which', tool],
                    capture_output=True,
                    timeout=2
                )
                if result.returncode == 0:
                    installed.append(tool)
            except:
                pass
                
        return DetectionResult(
            detected=len(installed) > 0,
            value=installed,
            source="which command",
            confidence=1.0
        )
        
    async def _detect_telegram_token(self) -> DetectionResult:
        """Detect Telegram token from .env or environment."""
        token = None
        source = ""
        
        # Check environment variable
        token = os.environ.get('TELEGRAM_BOT_TOKEN') or os.environ.get('TELEGRAM_TOKEN')
        if token:
            source = "environment variable"
            
        # Check .env file
        if not token:
            env_file = PROJECT_ROOT / '.env'
            if env_file.exists():
                try:
                    content = env_file.read_text()
                    for line in content.splitlines():
                        if line.startswith('TELEGRAM_BOT_TOKEN=') or line.startswith('TELEGRAM_TOKEN='):
                            token = line.split('=', 1)[1].strip().strip('"\'')
                            source = ".env file"
                            break
                except:
                    pass
                    
        if token and len(token) > 20:  # Basic validation
            return DetectionResult(
                detected=True,
                value=token,
                source=source,
                confidence=0.95
            )
            
        return DetectionResult(detected=False, value=None, source="", confidence=0.0)
        
    async def _detect_network(self) -> DetectionResult:
        """Detect network connectivity."""
        try:
            # Try to connect to a reliable host
            socket.create_connection(("8.8.8.8", 53), timeout=3)
            
            return DetectionResult(
                detected=True,
                value={"internet": True},
                source="dns connectivity test",
                confidence=1.0
            )
        except:
            return DetectionResult(
                detected=True,
                value={"internet": False},
                source="connection failed",
                confidence=1.0
            )
            
    def _print_detection_results(self) -> None:
        """Print summary of detections."""
        self.output.print_header("DETECTION SUMMARY", icon="📋")
        
        print("  ╭─────────────────────────────────────────────────────────╮")
        
        # System info
        sys_info = self.detected.get('system_info', DetectionResult(False, {}, "", 0))
        if sys_info.detected:
            info = sys_info.value
            print(f"  │ 💻 System: {info.get('os', '?')} {info.get('os_version', ''):<27} │")
            print(f"  │ 🔧 CPU: {info.get('cpu_count', '?')} cores | RAM: {info.get('ram_gb', '?')}GB{' ' * 25}│")
            
        # Timezone
        tz = self.detected.get('timezone', DetectionResult(False, None, "", 0))
        if tz.detected:
            print(f"  │ 🌍 Timezone: {tz.value:<41} │")
            
        # Username
        user = self.detected.get('username', DetectionResult(False, None, "", 0))
        if user.detected:
            print(f"  │ 👤 Username: {user.value:<41} │")
            
        # Ollama
        ollama = self.detected.get('ollama_url', DetectionResult(False, None, "", 0))
        if ollama.detected:
            print(f"  │ 🤖 Ollama: {ollama.value:<43} │")
        else:
            print(f"  │ 🤖 Ollama: ❌ Not detected{' ' * 28} │")
            
        # Best model
        model = self.detected.get('best_model', DetectionResult(False, None, "", 0))
        if model.detected:
            print(f"  │ 🧠 Model: {model.value:<44} │")
            
        # Models available
        models = self.detected.get('ollama_models', DetectionResult(False, [], "", 0))
        if models.detected and models.value:
            print(f"  │ 📦 Available models: {len(models.value):<33} │")
            
        # Telegram
        telegram = self.detected.get('telegram_token', DetectionResult(False, None, "", 0))
        if telegram.detected:
            print(f"  │ 📱 Telegram: ✓ Token found{' ' * 28} │")
        else:
            print(f"  │ 📱 Telegram: ❌ Token not found{' ' * 23} │")
            
        # Network
        network = self.detected.get('network', DetectionResult(False, {}, "", 0))
        if network.detected:
            internet = network.value.get('internet', False)
            status = "✓ Connected" if internet else "❌ No internet"
            print(f"  │ 🌐 Network: {status:<42} │")
            
        # Tools
        tools = self.detected.get('installed_tools', DetectionResult(False, [], "", 0))
        if tools.detected:
            print(f"  │ 🔧 Tools detected: {len(tools.value):<35} │")
            
        print("  ╰─────────────────────────────────────────────────────────╯\n")
        
    async def _ask_essential_questions(self) -> None:
        """Ask questions that cannot be auto-detected."""
        
        # ═══════════════════════════════════════════════════════════════════
        # OWNER INFORMATION
        # ═══════════════════════════════════════════════════════════════════
        
        print("  ╭─ About You ─────────────────────────────────────────────╮")
        
        # Get username as default
        detected_username = self.detected.get('username', DetectionResult(False, 'User', "", 0))
        default_name = detected_username.value if detected_username.detected else 'User'
        
        # Owner name
        self.answers['owner_name'] = await self._ask(
            f"  │ What's your name? [{default_name}]: ",
            default=default_name
        )
        
        # Nickname
        self.answers['owner_nickname'] = await self._ask(
            f"  │ What should I call you? [{self.answers['owner_name']}]: ",
            default=self.answers['owner_name']
        )
        
        # Technical level
        print("  │")
        print("  │ How technical are you?")
        print("  │   1 = Beginner (explain everything)")
        print("  │   5 = Intermediate (some explanations)")
        print("  │   10 = Expert (minimal explanations)")
        
        tech_level = await self._ask(
            "  │ Your level [5]: ",
            default="5",
            validator=lambda x: x.isdigit() and 1 <= int(x) <= 10
        )
        self.answers['tech_level'] = int(tech_level)
        
        print("  ╰─────────────────────────────────────────────────────────╯\n")
        
        # ═══════════════════════════════════════════════════════════════════
        # AGENT PREFERENCES
        # ═══════════════════════════════════════════════════════════════════
        
        print("  ╭─ About Me (Your Agent) ─────────────────────────────────╮")
        
        # Agent name
        self.answers['agent_name'] = await self._ask(
            "  │ What should my name be? [Axiom]: ",
            default="Axiom"
        )
        
        # Communication style
        print("  │")
        print("  │ How should I communicate?")
        print("  │   1 = Casual (friendly, informal)")
        print("  │   2 = Balanced (professional but warm)")
        print("  │   3 = Formal (strictly professional)")
        
        style_choice = await self._ask(
            "  │ Style [2]: ",
            default="2",
            validator=lambda x: x in ('1', '2', '3')
        )
        style_map = {'1': 'casual', '2': 'balanced', '3': 'formal'}
        self.answers['communication_style'] = style_map[style_choice]
        
        # Show reasoning?
        show_reasoning = await self._ask(
            "  │ Should I explain my reasoning? (yes/no) [yes]: ",
            default="yes"
        )
        self.answers['show_reasoning'] = show_reasoning.lower() in ('yes', 'y')
        
        # Notify learnings?
        notify = await self._ask(
            "  │ Notify when I learn something new? (yes/no) [yes]: ",
            default="yes"
        )
        self.answers['notify_learnings'] = notify.lower() in ('yes', 'y')
        
        print("  ╰─────────────────────────────────────────────────────────╯\n")
        
    async def _ask_missing_required(self) -> None:
        """Ask for required items that weren't auto-detected."""
        missing_required = []
        
        # Check Ollama
        if not self.detected.get('ollama_url', DetectionResult(False, None, "", 0)).detected:
            missing_required.append(('ollama_url', 'Ollama server URL', 'http://localhost:11434'))
            
        # Check Telegram (optional but ask)
        if not self.detected.get('telegram_token', DetectionResult(False, None, "", 0)).detected:
            missing_required.append(('telegram_token', 'Telegram Bot Token (optional, press Enter to skip)', ''))
            
        if missing_required:
            print("  ╭─ Required Configuration ────────────────────────────────╮")
            
            for key, question, default in missing_required:
                value = await self._ask(
                    f"  │ {question}: ",
                    default=default
                )
                if value:
                    self.answers[key] = value
                    
            print("  ╰─────────────────────────────────────────────────────────╯\n")
            
    async def _ask(
        self,
        prompt: str,
        default: str = "",
        validator: callable = None
    ) -> str:
        """
        Ask a question with optional default and validation.
        
        Uses asyncio to be non-blocking.
        """
        while True:
            # Use run_in_executor for blocking input
            answer = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: input(prompt).strip()
            )
            
            # Use default if empty
            if not answer and default:
                answer = default
                
            # Validate if validator provided
            if validator and not validator(answer):
                print("  │ ⚠️  Invalid input, please try again.")
                continue
                
            return answer
            
    def _print_final_summary(self) -> None:
        """Print final configuration summary."""
        # Combine detected and answered values
        ollama_url = self.answers.get('ollama_url') or (
            self.detected.get('ollama_url').value 
            if self.detected.get('ollama_url', DetectionResult(False, None, "", 0)).detected 
            else 'Not configured'
        )
        
        model = (
            self.detected.get('best_model').value 
            if self.detected.get('best_model', DetectionResult(False, None, "", 0)).detected 
            else 'Will be selected'
        )
        
        telegram = "✓ Configured" if (
            self.answers.get('telegram_token') or 
            self.detected.get('telegram_token', DetectionResult(False, None, "", 0)).detected
        ) else "Not configured"
        
        print(f"""
  ╭─ Final Configuration ───────────────────────────────────────╮
  │                                                             │
  │  OWNER                                                      │
  │  ─────                                                      │
  │  Name: {self.answers.get('owner_name', 'Unknown'):<52}│
  │  Nickname: {self.answers.get('owner_nickname', 'Unknown'):<48}│
  │  Tech Level: {self.answers.get('tech_level', 5):<46}│
  │                                                             │
  │  AGENT                                                      │
  │  ─────                                                      │
  │  Name: {self.answers.get('agent_name', 'Axiom'):<52}│
  │  Style: {self.answers.get('communication_style', 'balanced'):<51}│
  │  Show Reasoning: {str(self.answers.get('show_reasoning', True)):<41}│
  │  Notify Learnings: {str(self.answers.get('notify_learnings', True)):<39}│
  │                                                             │
  │  SYSTEM                                                     │
  │  ──────                                                     │
  │  Ollama: {ollama_url:<50}│
  │  Model: {model:<51}│
  │  Telegram: {telegram:<48}│
  │                                                             │
  ╰─────────────────────────────────────────────────────────────╯
        """)
        
    async def _save_configuration(self) -> Dict[str, Any]:
        """Save all configuration to files."""
        # Build complete configuration
        config = {
            'owner': {
                'name': self.answers.get('owner_name', 'User'),
                'nickname': self.answers.get('owner_nickname', 'User'),
                'tech_level': self.answers.get('tech_level', 5),
                'timezone': self.detected.get('timezone', DetectionResult(False, 'UTC', "", 0)).value or 'UTC',
                'language': (self.detected.get('locale', DetectionResult(False, {}, "", 0)).value or {}).get('language', 'en_US'),
            },
            'agent': {
                'name': self.answers.get('agent_name', 'Axiom'),
                'communication_style': self.answers.get('communication_style', 'balanced'),
                'show_reasoning': self.answers.get('show_reasoning', True),
                'notify_learnings': self.answers.get('notify_learnings', True),
            },
            'ollama': {
                'base_url': self.answers.get('ollama_url') or self.detected.get('ollama_url', DetectionResult(False, 'http://localhost:11434', "", 0)).value,
                'model': self.detected.get('best_model', DetectionResult(False, None, "", 0)).value,
                'available_models': self.detected.get('ollama_models', DetectionResult(False, [], "", 0)).value or [],
            },
            'telegram': {
                'token': self.answers.get('telegram_token') or self.detected.get('telegram_token', DetectionResult(False, None, "", 0)).value,
                'enabled': bool(self.answers.get('telegram_token') or self.detected.get('telegram_token', DetectionResult(False, None, "", 0)).detected),
            },
            'system': {
                'info': self.detected.get('system_info', DetectionResult(False, {}, "", 0)).value or {},
                'installed_tools': self.detected.get('installed_tools', DetectionResult(False, [], "", 0)).value or [],
                'internet': (self.detected.get('network', DetectionResult(False, {}, "", 0)).value or {}).get('internet', False),
            },
            'setup': {
                'completed_at': datetime.utcnow().isoformat(),
                'version': '3.0.0',
            }
        }
        
        # Save to YAML files
        import yaml
        
        # Required config
        required_dir = PROJECT_ROOT / 'config' / 'required'
        required_dir.mkdir(parents=True, exist_ok=True)
        
        # Save owner config
        with open(required_dir / 'owner.yaml', 'w') as f:
            yaml.dump({'owner': config['owner']}, f, default_flow_style=False)
            
        # Save ollama config
        with open(required_dir / 'ollama.yaml', 'w') as f:
            yaml.dump({'ollama': config['ollama']}, f, default_flow_style=False)
            
        # Save telegram config
        with open(required_dir / 'telegram.yaml', 'w') as f:
            yaml.dump({'telegram': config['telegram']}, f, default_flow_style=False)
            
        # Save system config
        with open(required_dir / 'system.yaml', 'w') as f:
            yaml.dump({'system': config['system'], 'agent': config['agent']}, f, default_flow_style=False)
            
        # Save to permanent identity storage
        identity_dir = PROJECT_ROOT / 'identity' / 'permanent_data'
        identity_dir.mkdir(parents=True, exist_ok=True)
        
        with open(identity_dir / 'owner_profile.yaml', 'w') as f:
            yaml.dump(config['owner'], f, default_flow_style=False)
            
        with open(identity_dir / 'agent_identity.yaml', 'w') as f:
            yaml.dump(config['agent'], f, default_flow_style=False)
            
        return config