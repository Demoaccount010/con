#!/usr/bin/env python3
"""
Scripts Manager
===============
Manages setup and utility scripts.
"""

import asyncio
import logging
import subprocess
import sys
from pathlib import Path
from typing import Dict, Any, Optional


class ScriptsManager:
    """
    Manages setup and utility scripts.
    
    Provides access to:
    - first_run.py - Initial setup wizard
    - health_check.sh - System health check
    - install.sh - Installation script
    - setup_ollama.sh - Ollama setup
    """
    
    def __init__(self, agent=None):
        self.agent = agent
        self.logger = logging.getLogger("scripts_manager")
        
        # Scripts directory
        if agent and hasattr(agent, 'project_root'):
            self.scripts_dir = agent.project_root / "scripts"
        else:
            self.scripts_dir = Path(__file__).parent
        
        self.scripts = {
            'first_run': self.scripts_dir / 'first_run.py',
            'health_check': self.scripts_dir / 'health_check.sh',
            'install': self.scripts_dir / 'install.sh',
            'setup_ollama': self.scripts_dir / 'setup_ollama.sh',
        }
        
        self._initialized = False
    
    async def initialize(self) -> bool:
        """Initialize scripts manager."""
        self.logger.info("Initializing scripts manager...")
        
        # Check which scripts exist
        available = []
        for name, path in self.scripts.items():
            if path.exists():
                available.append(name)
        
        self.logger.info(f"Available scripts: {', '.join(available)}")
        self._initialized = True
        return True
    
    def run_first_run_wizard(self) -> bool:
        """
        Run the first run setup wizard.
        
        Returns:
            True if successful
        """
        script = self.scripts['first_run']
        if not script.exists():
            self.logger.error("first_run.py not found")
            return False
        
        try:
            self.logger.info("Running first run wizard...")
            result = subprocess.run(
                [sys.executable, str(script)],
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0:
                self.logger.info("First run wizard completed successfully")
                return True
            else:
                self.logger.error(f"First run wizard failed: {result.stderr}")
                return False
                
        except Exception as e:
            self.logger.error(f"Failed to run first run wizard: {e}")
            return False
    
    async def run_health_check(self) -> Dict[str, Any]:
        """
        Run system health check.
        
        Returns:
            Health check results
        """
        script = self.scripts['health_check']
        if not script.exists():
            return {
                'success': False,
                'error': 'health_check.sh not found'
            }
        
        try:
            self.logger.info("Running health check...")
            
            # Run bash script
            process = await asyncio.create_subprocess_exec(
                'bash', str(script),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await process.communicate()
            
            return {
                'success': process.returncode == 0,
                'output': stdout.decode('utf-8'),
                'error': stderr.decode('utf-8') if stderr else None
            }
            
        except Exception as e:
            self.logger.error(f"Health check failed: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def list_available_scripts(self) -> Dict[str, bool]:
        """
        List all available scripts.
        
        Returns:
            Dict of script_name: exists
        """
        return {
            name: path.exists()
            for name, path in self.scripts.items()
        }
    
    def get_script_path(self, script_name: str) -> Optional[Path]:
        """Get path to a specific script."""
        return self.scripts.get(script_name)
    
    @property
    def is_initialized(self) -> bool:
        """Check if manager is initialized."""
        return self._initialized
