#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════
#  AUTONOMOUS AGENT - INSTALLATION SCRIPT
# ═══════════════════════════════════════════════════════════════════════════════
#
#  This script sets up the complete autonomous agent environment:
#  • Checks system requirements
#  • Creates virtual environment
#  • Installs Python dependencies
#  • Sets up directory structure
#  • Initializes databases
#  • Configures environment
#  • Optionally sets up Ollama
#  • Optionally sets up Telegram
#
#  Usage:
#    ./install.sh              # Interactive installation
#    ./install.sh --quick      # Quick install with defaults
#    ./install.sh --dev        # Development installation
#    ./install.sh --help       # Show help
#
#  Author: System Engineer
#  Version: 3.0.0
#
# ═══════════════════════════════════════════════════════════════════════════════

set -e  # Exit on error

# ═══════════════════════════════════════════════════════════════════════════════
#                          CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

# Script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

# Python requirements
MIN_PYTHON_VERSION="3.10"
VENV_DIR="${PROJECT_DIR}/venv"

# Installation flags
QUICK_INSTALL=false
DEV_INSTALL=false
SKIP_OLLAMA=false
SKIP_TELEGRAM=false
FORCE_REINSTALL=false

# ═══════════════════════════════════════════════════════════════════════════════
#                          HELPER FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

print_banner() {
    echo -e "${CYAN}"
    echo "═══════════════════════════════════════════════════════════════════════════════"
    echo "                     AUTONOMOUS AI AGENT - INSTALLER v3.0.0                    "
    echo "═══════════════════════════════════════════════════════════════════════════════"
    echo -e "${NC}"
}

print_step() {
    echo -e "\n${BLUE}▶ ${WHITE}$1${NC}"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_info() {
    echo -e "${CYAN}ℹ $1${NC}"
}

confirm() {
    if [ "$QUICK_INSTALL" = true ]; then
        return 0
    fi
    
    read -p "$(echo -e ${YELLOW}"$1 (y/n): "${NC})" -n 1 -r
    echo
    [[ $REPLY =~ ^[Yy]$ ]]
}

check_command() {
    command -v "$1" &> /dev/null
}

# ═══════════════════════════════════════════════════════════════════════════════
#                          PARSE ARGUMENTS
# ═══════════════════════════════════════════════════════════════════════════════

parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --quick|-q)
                QUICK_INSTALL=true
                shift
                ;;
            --dev|-d)
                DEV_INSTALL=true
                shift
                ;;
            --skip-ollama)
                SKIP_OLLAMA=true
                shift
                ;;
            --skip-telegram)
                SKIP_TELEGRAM=true
                shift
                ;;
            --force|-f)
                FORCE_REINSTALL=true
                shift
                ;;
            --help|-h)
                show_help
                exit 0
                ;;
            *)
                print_error "Unknown option: $1"
                show_help
                exit 1
                ;;
        esac
    done
}

show_help() {
    echo "Usage: ./install.sh [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  --quick, -q       Quick install with defaults (no prompts)"
    echo "  --dev, -d         Development installation (includes dev dependencies)"
    echo "  --skip-ollama     Skip Ollama setup"
    echo "  --skip-telegram   Skip Telegram setup"
    echo "  --force, -f       Force reinstall even if already installed"
    echo "  --help, -h        Show this help message"
    echo ""
    echo "Examples:"
    echo "  ./install.sh              # Interactive installation"
    echo "  ./install.sh --quick      # Quick install with defaults"
    echo "  ./install.sh --dev        # Development environment"
}

# ═══════════════════════════════════════════════════════════════════════════════
#                          SYSTEM CHECKS
# ═══════════════════════════════════════════════════════════════════════════════

check_os() {
    print_step "Checking operating system..."
    
    OS="unknown"
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        OS="linux"
        if check_command apt-get; then
            PKG_MANAGER="apt"
        elif check_command dnf; then
            PKG_MANAGER="dnf"
        elif check_command yum; then
            PKG_MANAGER="yum"
        elif check_command pacman; then
            PKG_MANAGER="pacman"
        fi
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        OS="macos"
        PKG_MANAGER="brew"
    elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "cygwin" ]]; then
        OS="windows"
        PKG_MANAGER="none"
    fi
    
    print_success "Detected OS: $OS"
    
    if [ "$OS" = "unknown" ]; then
        print_warning "Unknown operating system. Some features may not work."
    fi
}

check_python() {
    print_step "Checking Python installation..."
    
    # Try different Python commands
    PYTHON_CMD=""
    for cmd in python3.12 python3.11 python3.10 python3 python; do
        if check_command "$cmd"; then
            version=$($cmd -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
            if [ "$(printf '%s\n' "$MIN_PYTHON_VERSION" "$version" | sort -V | head -n1)" = "$MIN_PYTHON_VERSION" ]; then
                PYTHON_CMD="$cmd"
                print_success "Found Python $version ($cmd)"
                break
            fi
        fi
    done
    
    if [ -z "$PYTHON_CMD" ]; then
        print_error "Python $MIN_PYTHON_VERSION or higher is required but not found."
        echo ""
        echo "Please install Python $MIN_PYTHON_VERSION+ and try again:"
        case $OS in
            linux)
                echo "  Ubuntu/Debian: sudo apt install python3.10 python3.10-venv python3-pip"
                echo "  Fedora: sudo dnf install python3.10"
                echo "  Arch: sudo pacman -S python"
                ;;
            macos)
                echo "  brew install python@3.10"
                ;;
            windows)
                echo "  Download from https://www.python.org/downloads/"
                ;;
        esac
        exit 1
    fi
}

check_pip() {
    print_step "Checking pip installation..."
    
    if ! $PYTHON_CMD -m pip --version &> /dev/null; then
        print_warning "pip not found. Installing..."
        
        case $OS in
            linux)
                case $PKG_MANAGER in
                    apt)
                        sudo apt-get update && sudo apt-get install -y python3-pip
                        ;;
                    dnf|yum)
                        sudo $PKG_MANAGER install -y python3-pip
                        ;;
                    pacman)
                        sudo pacman -S --noconfirm python-pip
                        ;;
                esac
                ;;
            macos)
                $PYTHON_CMD -m ensurepip --upgrade
                ;;
        esac
    fi
    
    print_success "pip is available"
}

check_venv() {
    print_step "Checking venv module..."
    
    if ! $PYTHON_CMD -m venv --help &> /dev/null; then
        print_warning "venv module not found. Installing..."
        
        case $PKG_MANAGER in
            apt)
                sudo apt-get install -y python3-venv
                ;;
            *)
                print_error "Please install python3-venv manually"
                exit 1
                ;;
        esac
    fi
    
    print_success "venv module is available"
}

check_git() {
    print_step "Checking Git installation..."
    
    if ! check_command git; then
        print_warning "Git not found. Installing..."
        
        case $PKG_MANAGER in
            apt)
                sudo apt-get install -y git
                ;;
            dnf|yum)
                sudo $PKG_MANAGER install -y git
                ;;
            pacman)
                sudo pacman -S --noconfirm git
                ;;
            brew)
                brew install git
                ;;
            *)
                print_warning "Please install git manually"
                ;;
        esac
    fi
    
    if check_command git; then
        print_success "Git is available: $(git --version)"
    fi
}

check_system_resources() {
    print_step "Checking system resources..."
    
    # Check RAM
    if [ "$OS" = "linux" ]; then
        TOTAL_RAM=$(free -g | awk '/^Mem:/{print $2}')
    elif [ "$OS" = "macos" ]; then
        TOTAL_RAM=$(($(sysctl -n hw.memsize) / 1024 / 1024 / 1024))
    else
        TOTAL_RAM=8  # Assume 8GB on Windows
    fi
    
    print_info "Total RAM: ${TOTAL_RAM}GB"
    
    if [ "$TOTAL_RAM" -lt 4 ]; then
        print_warning "Low RAM detected. Smaller models will be recommended."
    fi
    
    # Check disk space
    AVAILABLE_SPACE=$(df -BG "$PROJECT_DIR" | awk 'NR==2 {print $4}' | tr -d 'G')
    print_info "Available disk space: ${AVAILABLE_SPACE}GB"
    
    if [ "$AVAILABLE_SPACE" -lt 5 ]; then
        print_warning "Low disk space. At least 5GB recommended."
    fi
}

# ═══════════════════════════════════════════════════════════════════════════════
#                          INSTALLATION STEPS
# ═══════════════════════════════════════════════════════════════════════════════

create_virtual_environment() {
    print_step "Creating virtual environment..."
    
    if [ -d "$VENV_DIR" ]; then
        if [ "$FORCE_REINSTALL" = true ]; then
            print_info "Removing existing virtual environment..."
            rm -rf "$VENV_DIR"
        else
            print_info "Virtual environment already exists"
            return 0
        fi
    fi
    
    $PYTHON_CMD -m venv "$VENV_DIR"
    print_success "Virtual environment created at $VENV_DIR"
}

activate_virtual_environment() {
    print_step "Activating virtual environment..."
    
    if [ "$OS" = "windows" ]; then
        source "$VENV_DIR/Scripts/activate"
    else
        source "$VENV_DIR/bin/activate"
    fi
    
    print_success "Virtual environment activated"
}

upgrade_pip() {
    print_step "Upgrading pip..."
    
    pip install --upgrade pip wheel setuptools
    print_success "pip upgraded"
}

install_dependencies() {
    print_step "Installing Python dependencies..."
    
    cd "$PROJECT_DIR"
    
    # Install main requirements
    if [ -f "requirements.txt" ]; then
        pip install -r requirements.txt
        print_success "Main dependencies installed"
    else
        print_warning "requirements.txt not found, installing core packages..."
        pip install \
            aiohttp \
            aiosqlite \
            pyyaml \
            python-dotenv \
            rich \
            prompt-toolkit \
            httpx \
            psutil
    fi
    
    # Install dev requirements if requested
    if [ "$DEV_INSTALL" = true ] && [ -f "requirements-dev.txt" ]; then
        pip install -r requirements-dev.txt
        print_success "Development dependencies installed"
    fi
}

create_directory_structure() {
    print_step "Creating directory structure..."
    
    cd "$PROJECT_DIR"
    
    # Create required directories
    directories=(
        "data"
        "data/memory"
        "data/cache"
        "data/temp"
        "data/backups"
        "data/telegram"
        "data/telegram/downloads"
        "logs"
        "config/required"
        "config/optional"
        "identity/permanent_data"
        "plugins/installed"
    )
    
    for dir in "${directories[@]}"; do
        mkdir -p "$dir"
    done
    
    print_success "Directory structure created"
}

initialize_databases() {
    print_step "Initializing databases..."
    
    cd "$PROJECT_DIR"
    
    # Create empty database files (will be initialized by Python on first run)
    touch "data/memory/memory.db"
    touch "data/memory/permanent.db"
    
    print_success "Database files created"
}

create_env_file() {
    print_step "Creating environment configuration..."
    
    cd "$PROJECT_DIR"
    
    if [ -f ".env" ]; then
        print_info ".env file already exists, skipping..."
        return 0
    fi
    
    if [ -f ".env.example" ]; then
        cp ".env.example" ".env"
        print_success "Created .env from template"
    else
        # Create basic .env file
        cat > ".env" << 'EOF'
# ═══════════════════════════════════════════════════════════════════════════════
#  AUTONOMOUS AGENT - ENVIRONMENT CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

# Ollama Configuration
OLLAMA_URL=http://localhost:11434
# OLLAMA_MODEL=llama3.2

# Telegram Configuration (optional)
# TELEGRAM_BOT_TOKEN=your_bot_token_here

# Logging
LOG_LEVEL=INFO

# Development
DEBUG=false

# ═══════════════════════════════════════════════════════════════════════════════
EOF
        print_success "Created default .env file"
    fi
    
    print_info "Edit .env to configure your settings"
}

set_permissions() {
    print_step "Setting file permissions..."
    
    cd "$PROJECT_DIR"
    
    # Make scripts executable
    if [ -d "scripts" ]; then
        chmod +x scripts/*.sh 2>/dev/null || true
    fi
    
    # Make main.py executable
    if [ -f "core/main.py" ]; then
        chmod +x core/main.py
    fi
    
    print_success "Permissions set"
}

# ═══════════════════════════════════════════════════════════════════════════════
#                          OLLAMA SETUP
# ═══════════════════════════════════════════════════════════════════════════════

setup_ollama() {
    if [ "$SKIP_OLLAMA" = true ]; then
        print_info "Skipping Ollama setup"
        return 0
    fi
    
    print_step "Checking Ollama installation..."
    
    if check_command ollama; then
        OLLAMA_VERSION=$(ollama --version 2>/dev/null || echo "unknown")
        print_success "Ollama is installed: $OLLAMA_VERSION"
        
        # Check if Ollama is running
        if curl -s http://localhost:11434/api/tags &>/dev/null; then
            print_success "Ollama is running"
            
            # List available models
            print_info "Available models:"
            curl -s http://localhost:11434/api/tags | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    models = data.get('models', [])
    if models:
        for m in models:
            print(f\"  • {m.get('name', 'unknown')}\")
    else:
        print('  No models installed')
except:
    print('  Could not parse response')
"
        else
            print_warning "Ollama is installed but not running"
            print_info "Start Ollama with: ollama serve"
        fi
    else
        print_warning "Ollama is not installed"
        
        if confirm "Would you like to install Ollama?"; then
            bash "$SCRIPT_DIR/setup_ollama.sh"
        else
            print_info "Skipping Ollama installation"
            print_info "Install later with: ./scripts/setup_ollama.sh"
        fi
    fi
}

# ═══════════════════════════════════════════════════════════════════════════════
#                          TELEGRAM SETUP
# ═══════════════════════════════════════════════════════════════════════════════

setup_telegram() {
    if [ "$SKIP_TELEGRAM" = true ]; then
        print_info "Skipping Telegram setup"
        return 0
    fi
    
    if [ "$QUICK_INSTALL" = true ]; then
        print_info "Telegram can be configured later via first-run wizard"
        return 0
    fi
    
    print_step "Telegram Bot Setup"
    
    if confirm "Would you like to set up a Telegram bot now?"; then
        echo ""
        print_info "To create a Telegram bot:"
        echo "  1. Open Telegram and search for @BotFather"
        echo "  2. Send /newbot to create a new bot"
        echo "  3. Follow the instructions to name your bot"
        echo "  4. Copy the bot token"
        echo ""
        
        read -p "Enter your Telegram Bot Token (or press Enter to skip): " telegram_token
        
        if [ -n "$telegram_token" ]; then
            # Update .env file
            if grep -q "TELEGRAM_BOT_TOKEN" "$PROJECT_DIR/.env"; then
                sed -i.bak "s|^#* *TELEGRAM_BOT_TOKEN=.*|TELEGRAM_BOT_TOKEN=$telegram_token|" "$PROJECT_DIR/.env"
            else
                echo "TELEGRAM_BOT_TOKEN=$telegram_token" >> "$PROJECT_DIR/.env"
            fi
            print_success "Telegram token saved to .env"
        else
            print_info "Telegram setup skipped. Configure later in .env"
        fi
    fi
}

# ═══════════════════════════════════════════════════════════════════════════════
#                          FINAL SETUP
# ═══════════════════════════════════════════════════════════════════════════════

verify_installation() {
    print_step "Verifying installation..."
    
    cd "$PROJECT_DIR"
    
    # Activate venv
    if [ "$OS" = "windows" ]; then
        source "$VENV_DIR/Scripts/activate"
    else
        source "$VENV_DIR/bin/activate"
    fi
    
    # Test Python imports
    python3 << 'EOF'
import sys
errors = []

try:
    import aiohttp
except ImportError:
    errors.append("aiohttp")

try:
    import aiosqlite
except ImportError:
    errors.append("aiosqlite")

try:
    import yaml
except ImportError:
    errors.append("pyyaml")

try:
    import dotenv
except ImportError:
    errors.append("python-dotenv")

try:
    import rich
except ImportError:
    errors.append("rich")

if errors:
    print(f"Missing packages: {', '.join(errors)}")
    sys.exit(1)
else:
    print("All core packages available")
    sys.exit(0)
EOF
    
    if [ $? -eq 0 ]; then
        print_success "Installation verified successfully"
    else
        print_error "Some packages are missing. Please run: pip install -r requirements.txt"
        return 1
    fi
}

print_completion() {
    echo ""
    echo -e "${GREEN}═══════════════════════════════════════════════════════════════════════════════${NC}"
    echo -e "${GREEN}                     INSTALLATION COMPLETE! 🎉                                  ${NC}"
    echo -e "${GREEN}═══════════════════════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo -e "${WHITE}Next steps:${NC}"
    echo ""
    echo "  1. Activate the virtual environment:"
    echo -e "     ${CYAN}source venv/bin/activate${NC}"
    echo ""
    echo "  2. Start the agent:"
    echo -e "     ${CYAN}python -m core.main${NC}"
    echo ""
    echo "  3. Or run the first-time setup wizard:"
    echo -e "     ${CYAN}python scripts/first_run.py${NC}"
    echo ""
    
    if ! check_command ollama; then
        echo -e "${YELLOW}Note: Ollama is not installed. Install it with:${NC}"
        echo -e "     ${CYAN}./scripts/setup_ollama.sh${NC}"
        echo ""
    fi
    
    echo -e "${WHITE}Documentation:${NC}"
    echo "  • Setup Guide: docs/setup_guide.md"
    echo "  • Configuration: docs/configuration.md"
    echo "  • Troubleshooting: docs/troubleshooting.md"
    echo ""
    echo -e "${PURPLE}Happy chatting with your autonomous agent! 🤖${NC}"
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════════════
#                          MAIN EXECUTION
# ═══════════════════════════════════════════════════════════════════════════════

main() {
    # Parse command line arguments
    parse_args "$@"
    
    # Print banner
    print_banner
    
    # System checks
    check_os
    check_python
    check_pip
    check_venv
    check_git
    check_system_resources
    
    echo ""
    if [ "$QUICK_INSTALL" = false ]; then
        if ! confirm "Proceed with installation?"; then
            print_info "Installation cancelled"
            exit 0
        fi
    fi
    
    # Installation steps
    create_virtual_environment
    activate_virtual_environment
    upgrade_pip
    install_dependencies
    create_directory_structure
    initialize_databases
    create_env_file
    set_permissions
    
    # Optional setups
    setup_ollama
    setup_telegram
    
    # Verification
    verify_installation
    
    # Done!
    print_completion
}

# Run main
main "$@"