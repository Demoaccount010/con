#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════
#  HEALTH CHECK SCRIPT
# ═══════════════════════════════════════════════════════════════════════════════
#
#  Performs comprehensive health checks on the autonomous agent:
#  • Python environment
#  • Dependencies
#  • Ollama connection
#  • Database integrity
#  • Configuration validity
#  • System resources
#  • Telegram connectivity (if configured)
#
#  Usage:
#    ./health_check.sh              # Full health check
#    ./health_check.sh --quick      # Quick check only
#    ./health_check.sh --json       # Output as JSON
#    ./health_check.sh --fix        # Attempt to fix issues
#
#  Exit codes:
#    0 - All checks passed
#    1 - Some checks failed
#    2 - Critical failure
#
#  Author: System Engineer
#  Version: 3.0.0
#
# ═══════════════════════════════════════════════════════════════════════════════

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m'

# Script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

# Configuration
OLLAMA_URL="${OLLAMA_URL:-http://localhost:11434}"
VENV_DIR="${PROJECT_DIR}/venv"

# Flags
QUICK_CHECK=false
JSON_OUTPUT=false
FIX_ISSUES=false
VERBOSE=false

# Results tracking
CHECKS_PASSED=0
CHECKS_FAILED=0
CHECKS_WARNED=0
ISSUES=()

# ═══════════════════════════════════════════════════════════════════════════════
#                          HELPER FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

print_banner() {
    if [ "$JSON_OUTPUT" = true ]; then
        return
    fi
    
    echo -e "${CYAN}"
    echo "═══════════════════════════════════════════════════════════════════════════════"
    echo "                     AUTONOMOUS AGENT - HEALTH CHECK                            "
    echo "═══════════════════════════════════════════════════════════════════════════════"
    echo -e "${NC}"
}

print_section() {
    if [ "$JSON_OUTPUT" = true ]; then
        return
    fi
    echo -e "\n${BLUE}━━━ $1 ━━━${NC}"
}

check_pass() {
    CHECKS_PASSED=$((CHECKS_PASSED + 1))
    if [ "$JSON_OUTPUT" = false ]; then
        echo -e "${GREEN}  ✓ $1${NC}"
    fi
}

check_fail() {
    CHECKS_FAILED=$((CHECKS_FAILED + 1))
    ISSUES+=("$1")
    if [ "$JSON_OUTPUT" = false ]; then
        echo -e "${RED}  ✗ $1${NC}"
    fi
}

check_warn() {
    CHECKS_WARNED=$((CHECKS_WARNED + 1))
    if [ "$JSON_OUTPUT" = false ]; then
        echo -e "${YELLOW}  ⚠ $1${NC}"
    fi
}

check_info() {
    if [ "$JSON_OUTPUT" = false ] && [ "$VERBOSE" = true ]; then
        echo -e "${CYAN}  ℹ $1${NC}"
    fi
}

# ═══════════════════════════════════════════════════════════════════════════════
#                          PARSE ARGUMENTS
# ═══════════════════════════════════════════════════════════════════════════════

parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --quick|-q)
                QUICK_CHECK=true
                shift
                ;;
            --json|-j)
                JSON_OUTPUT=true
                shift
                ;;
            --fix|-f)
                FIX_ISSUES=true
                shift
                ;;
            --verbose|-v)
                VERBOSE=true
                shift
                ;;
            --help|-h)
                show_help
                exit 0
                ;;
            *)
                echo "Unknown option: $1"
                show_help
                exit 1
                ;;
        esac
    done
}

show_help() {
    echo "Usage: ./health_check.sh [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  --quick, -q     Quick check (essential checks only)"
    echo "  --json, -j      Output results as JSON"
    echo "  --fix, -f       Attempt to automatically fix issues"
    echo "  --verbose, -v   Show detailed information"
    echo "  --help, -h      Show this help message"
    echo ""
    echo "Exit codes:"
    echo "  0 - All checks passed"
    echo "  1 - Some checks failed (non-critical)"
    echo "  2 - Critical failure"
}

# ═══════════════════════════════════════════════════════════════════════════════
#                          HEALTH CHECKS
# ═══════════════════════════════════════════════════════════════════════════════

check_python_environment() {
    print_section "Python Environment"
    
    # Check virtual environment
    if [ -d "$VENV_DIR" ]; then
        check_pass "Virtual environment exists"
        
        # Activate and check
        if [ -f "$VENV_DIR/bin/activate" ]; then
            source "$VENV_DIR/bin/activate"
            
            # Check Python version
            python_version=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
            if [ "$(printf '%s\n' "3.10" "$python_version" | sort -V | head -n1)" = "3.10" ]; then
                check_pass "Python version: $python_version"
            else
                check_fail "Python version too old: $python_version (need 3.10+)"
            fi
        else
            check_fail "Virtual environment activation script not found"
        fi
    else
        check_fail "Virtual environment not found at $VENV_DIR"
        
        if [ "$FIX_ISSUES" = true ]; then
            echo "  Attempting to create virtual environment..."
            python3 -m venv "$VENV_DIR" && check_pass "Created virtual environment"
        fi
    fi
}

check_dependencies() {
    print_section "Python Dependencies"
    
    if [ ! -d "$VENV_DIR" ]; then
        check_fail "Cannot check dependencies - no virtual environment"
        return
    fi
    
    source "$VENV_DIR/bin/activate"
    
    # Core dependencies
    core_packages=("aiohttp" "aiosqlite" "pyyaml" "python-dotenv" "rich" "httpx" "psutil")
    
    for package in "${core_packages[@]}"; do
        if python3 -c "import $package" 2>/dev/null; then
            check_pass "$package installed"
        else
            check_fail "$package missing"
            
            if [ "$FIX_ISSUES" = true ]; then
                echo "  Installing $package..."
                pip install "$package" && check_pass "Installed $package"
            fi
        fi
    done
}

check_ollama() {
    print_section "Ollama"
    
    # Check if ollama command exists
    if command -v ollama &>/dev/null; then
        check_pass "Ollama command available"
    else
        check_warn "Ollama command not found"
        return
    fi
    
    # Check if Ollama is running
    if curl -s "$OLLAMA_URL/api/tags" &>/dev/null; then
        check_pass "Ollama service running at $OLLAMA_URL"
        
        # Check for models
        response=$(curl -s "$OLLAMA_URL/api/tags")
        model_count=$(echo "$response" | python3 -c "import json,sys; print(len(json.load(sys.stdin).get('models',[])))" 2>/dev/null || echo 0)
        
        if [ "$model_count" -gt 0 ]; then
            check_pass "$model_count model(s) available"
            
            if [ "$VERBOSE" = true ]; then
                echo "$response" | python3 -c "
import json,sys
data = json.load(sys.stdin)
for m in data.get('models', []):
    print(f\"    • {m.get('name', 'unknown')}\")
"
            fi
        else
            check_warn "No models installed"
        fi
    else
        check_fail "Ollama service not running"
        
        if [ "$FIX_ISSUES" = true ]; then
            echo "  Attempting to start Ollama..."
            if command -v systemctl &>/dev/null; then
                sudo systemctl start ollama 2>/dev/null && check_pass "Started Ollama service"
            else
                nohup ollama serve > /tmp/ollama.log 2>&1 &
                sleep 2
                if curl -s "$OLLAMA_URL/api/tags" &>/dev/null; then
                    check_pass "Started Ollama"
                fi
            fi
        fi
    fi
}

check_databases() {
    print_section "Databases"
    
    # Check memory database
    memory_db="$PROJECT_DIR/data/memory/memory.db"
    if [ -f "$memory_db" ]; then
        check_pass "Memory database exists"
        
        # Check integrity
        if command -v sqlite3 &>/dev/null; then
            integrity=$(sqlite3 "$memory_db" "PRAGMA integrity_check;" 2>/dev/null || echo "error")
            if [ "$integrity" = "ok" ]; then
                check_pass "Memory database integrity OK"
            else
                check_fail "Memory database integrity check failed"
            fi
        fi
    else
        check_warn "Memory database not found (will be created on first run)"
    fi
    
    # Check permanent database
    permanent_db="$PROJECT_DIR/data/memory/permanent.db"
    if [ -f "$permanent_db" ]; then
        check_pass "Permanent database exists"
        
        if command -v sqlite3 &>/dev/null; then
            integrity=$(sqlite3 "$permanent_db" "PRAGMA integrity_check;" 2>/dev/null || echo "error")
            if [ "$integrity" = "ok" ]; then
                check_pass "Permanent database integrity OK"
            else
                check_fail "Permanent database integrity check failed"
            fi
        fi
    else
        check_warn "Permanent database not found (will be created on first run)"
    fi
}

check_configuration() {
    print_section "Configuration"
    
    # Check .env file
    if [ -f "$PROJECT_DIR/.env" ]; then
        check_pass ".env file exists"
        
        # Check for required values
        if grep -q "OLLAMA_URL" "$PROJECT_DIR/.env"; then
            check_pass "OLLAMA_URL configured"
        else
            check_info "OLLAMA_URL not set (using default)"
        fi
        
        if grep -q "^TELEGRAM_BOT_TOKEN=" "$PROJECT_DIR/.env" && \
           ! grep -q "^TELEGRAM_BOT_TOKEN=$" "$PROJECT_DIR/.env" && \
           ! grep -q "^#.*TELEGRAM_BOT_TOKEN" "$PROJECT_DIR/.env"; then
            check_pass "Telegram token configured"
        else
            check_info "Telegram not configured (optional)"
        fi
    else
        check_warn ".env file not found"
        
        if [ "$FIX_ISSUES" = true ] && [ -f "$PROJECT_DIR/.env.example" ]; then
            cp "$PROJECT_DIR/.env.example" "$PROJECT_DIR/.env"
            check_pass "Created .env from template"
        fi
    fi
    
    # Check config files
    for config in "system.yaml" "ollama.yaml"; do
        if [ -f "$PROJECT_DIR/config/required/$config" ]; then
            check_pass "Config file: $config"
        else
            check_warn "Config file missing: $config"
        fi
    done
}

check_directories() {
    print_section "Directory Structure"
    
    required_dirs=(
        "data"
        "data/memory"
        "data/cache"
        "logs"
        "config"
        "identity/permanent_data"
    )
    
    for dir in "${required_dirs[@]}"; do
        if [ -d "$PROJECT_DIR/$dir" ]; then
            check_pass "Directory: $dir"
        else
            check_fail "Directory missing: $dir"
            
            if [ "$FIX_ISSUES" = true ]; then
                mkdir -p "$PROJECT_DIR/$dir"
                check_pass "Created directory: $dir"
            fi
        fi
    done
    
    # Check permissions
    if [ -w "$PROJECT_DIR/data" ]; then
        check_pass "Data directory writable"
    else
        check_fail "Data directory not writable"
    fi
    
    if [ -w "$PROJECT_DIR/logs" ]; then
        check_pass "Logs directory writable"
    else
        check_fail "Logs directory not writable"
    fi
}

check_system_resources() {
    print_section "System Resources"
    
    # Check RAM
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        total_ram=$(free -g | awk '/^Mem:/{print $2}')
        available_ram=$(free -g | awk '/^Mem:/{print $7}')
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        total_ram=$(($(sysctl -n hw.memsize) / 1024 / 1024 / 1024))
        # macOS doesn't have a simple "available" memory metric
        available_ram=$total_ram
    else
        total_ram=0
        available_ram=0
    fi
    
    if [ "$total_ram" -ge 8 ]; then
        check_pass "Total RAM: ${total_ram}GB"
    elif [ "$total_ram" -ge 4 ]; then
        check_warn "Total RAM: ${total_ram}GB (8GB+ recommended)"
    else
        check_fail "Total RAM: ${total_ram}GB (minimum 4GB required)"
    fi
    
    # Check disk space
    available_space=$(df -BG "$PROJECT_DIR" 2>/dev/null | awk 'NR==2 {print $4}' | tr -d 'G')
    
    if [ "$available_space" -ge 10 ]; then
        check_pass "Available disk: ${available_space}GB"
    elif [ "$available_space" -ge 5 ]; then
        check_warn "Available disk: ${available_space}GB (10GB+ recommended)"
    else
        check_fail "Available disk: ${available_space}GB (low space)"
    fi
    
    # Check CPU load
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        cpu_load=$(cat /proc/loadavg | awk '{print $1}')
        cpu_cores=$(nproc)
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        cpu_load=$(sysctl -n vm.loadavg | awk '{print $2}')
        cpu_cores=$(sysctl -n hw.ncpu)
    fi
    
    if [ -n "$cpu_load" ] && [ -n "$cpu_cores" ]; then
        check_info "CPU cores: $cpu_cores, Load: $cpu_load"
    fi
}

check_telegram() {
    print_section "Telegram (Optional)"
    
    # Read token from .env
    if [ -f "$PROJECT_DIR/.env" ]; then
        token=$(grep "^TELEGRAM_BOT_TOKEN=" "$PROJECT_DIR/.env" 2>/dev/null | cut -d= -f2)
    fi
    
    if [ -z "$token" ] || [ "$token" = "your_bot_token_here" ]; then
        check_info "Telegram not configured (optional)"
        return
    fi
    
    # Test Telegram API
    response=$(curl -s "https://api.telegram.org/bot$token/getMe")
    
    if echo "$response" | grep -q '"ok":true'; then
        bot_name=$(echo "$response" | python3 -c "import json,sys; print(json.load(sys.stdin)['result']['username'])" 2>/dev/null)
        check_pass "Telegram bot connected: @$bot_name"
    else
        check_fail "Telegram bot connection failed"
    fi
}

check_first_run_status() {
    print_section "First Run Status"
    
    flag_file="$PROJECT_DIR/identity/permanent_data/first_run_complete.flag"
    
    if [ -f "$flag_file" ]; then
        check_pass "First run wizard completed"
        
        # Check for owner profile
        if [ -f "$PROJECT_DIR/identity/permanent_data/owner_profile.yaml" ]; then
            check_pass "Owner profile configured"
        fi
        
        if [ -f "$PROJECT_DIR/identity/permanent_data/agent_identity.yaml" ]; then
            check_pass "Agent identity configured"
        fi
    else
        check_info "First run wizard not yet completed"
    fi
}

# ═══════════════════════════════════════════════════════════════════════════════
#                          OUTPUT RESULTS
# ═══════════════════════════════════════════════════════════════════════════════

output_json() {
    echo "{"
    echo "  \"timestamp\": \"$(date -u +%Y-%m-%dT%H:%M:%SZ)\","
    echo "  \"passed\": $CHECKS_PASSED,"
    echo "  \"failed\": $CHECKS_FAILED,"
    echo "  \"warned\": $CHECKS_WARNED,"
    echo "  \"healthy\": $([ $CHECKS_FAILED -eq 0 ] && echo "true" || echo "false"),"
    echo "  \"issues\": ["
    
    first=true
    for issue in "${ISSUES[@]}"; do
        if [ "$first" = true ]; then
            first=false
        else
            echo ","
        fi
        echo -n "    \"$issue\""
    done
    
    echo ""
    echo "  ]"
    echo "}"
}

output_summary() {
    echo ""
    echo -e "${WHITE}═══════════════════════════════════════════════════════════════════════════════${NC}"
    echo -e "${WHITE}                              HEALTH CHECK SUMMARY                              ${NC}"
    echo -e "${WHITE}═══════════════════════════════════════════════════════════════════════════════${NC}"
    echo ""
    
    echo -e "  ${GREEN}Passed:${NC}  $CHECKS_PASSED"
    echo -e "  ${YELLOW}Warned:${NC}  $CHECKS_WARNED"
    echo -e "  ${RED}Failed:${NC}  $CHECKS_FAILED"
    echo ""
    
    if [ $CHECKS_FAILED -eq 0 ]; then
        echo -e "  ${GREEN}★ System is healthy!${NC}"
    elif [ $CHECKS_FAILED -lt 3 ]; then
        echo -e "  ${YELLOW}⚠ Some issues need attention${NC}"
    else
        echo -e "  ${RED}✗ Critical issues detected${NC}"
    fi
    
    if [ ${#ISSUES[@]} -gt 0 ]; then
        echo ""
        echo -e "  ${WHITE}Issues found:${NC}"
        for issue in "${ISSUES[@]}"; do
            echo -e "    ${RED}•${NC} $issue"
        done
    fi
    
    echo ""
    
    if [ $CHECKS_FAILED -gt 0 ] && [ "$FIX_ISSUES" = false ]; then
        echo -e "  ${CYAN}Tip: Run with --fix to attempt automatic fixes${NC}"
        echo ""
    fi
}

# ═══════════════════════════════════════════════════════════════════════════════
#                          MAIN
# ═══════════════════════════════════════════════════════════════════════════════

main() {
    parse_args "$@"
    
    print_banner
    
    # Run checks
    check_python_environment
    check_dependencies
    check_ollama
    
    if [ "$QUICK_CHECK" = false ]; then
        check_databases
        check_configuration
        check_directories
        check_system_resources
        check_telegram
        check_first_run_status
    fi
    
    # Output results
    if [ "$JSON_OUTPUT" = true ]; then
        output_json
    else
        output_summary
    fi
    
    # Exit code
    if [ $CHECKS_FAILED -eq 0 ]; then
        exit 0
    elif [ $CHECKS_FAILED -lt 3 ]; then
        exit 1
    else
        exit 2
    fi
}

main "$@"