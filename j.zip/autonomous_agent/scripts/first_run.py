#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 FIRST RUN WIZARD - Interactive setup for first-time configuration
═══════════════════════════════════════════════════════════════════════════════

 This script runs on first launch to configure the agent.
 
 WHAT IT DOES:
 ─────────────
 1. Auto-detects system information
 2. Checks Ollama connection and models
 3. Asks essential questions (one-time only)
 4. Saves configuration permanently
 5. Creates first_run_complete.flag
 
 Usage:
   python scripts/first_run.py
   
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import os
import sys
import json
import platform
import asyncio
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any

# Add project root to path
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

# Try importing rich for beautiful output
try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.prompt import Prompt, Confirm
    from rich.table import Table
    from rich.progress import Progress, SpinnerColumn, TextColumn
    from rich import box
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False

# Try importing other dependencies
try:
    import yaml
    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False

try:
    import aiohttp
    AIOHTTP_AVAILABLE = True
except ImportError:
    AIOHTTP_AVAILABLE = False

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False


class FirstRunWizard:
    """
    Interactive first-run configuration wizard.
    """
    
    def __init__(self):
        """Initialize the wizard."""
        self.console = Console() if RICH_AVAILABLE else None
        self.project_root = PROJECT_ROOT
        
        # Paths
        self.identity_dir = self.project_root / "identity" / "permanent_data"
        self.data_dir = self.project_root / "data"
        self.memory_dir = self.data_dir / "memory"
        self.config_dir = self.project_root / "config"
        self.logs_dir = self.project_root / "logs"
        
        # Files
        self.first_run_flag = self.identity_dir / "first_run_complete.flag"
        self.owner_profile = self.identity_dir / "owner_profile.yaml"
        self.agent_identity = self.identity_dir / "agent_identity.yaml"
        
        # Collected data
        self.detected = {}
        self.answers = {}
        
    def print(self, message: str, style: str = None):
        """Print message with optional styling."""
        if self.console:
            if style:
                self.console.print(message, style=style)
            else:
                self.console.print(message)
        else:
            print(message)
    
    def print_banner(self):
        """Print welcome banner."""
        if self.console:
            banner = Panel(
                "[bold cyan]Welcome to Your Autonomous AI Agent![/bold cyan]\n\n"
                "I need to learn a few things about you to serve you better.\n"
                "This will only take about 2 minutes, and I'll [bold]never ask again![/bold]",
                title="🚀 First Run Setup",
                border_style="cyan",
                box=box.DOUBLE
            )
            self.console.print(banner)
        else:
            print("\n" + "=" * 60)
            print("    🚀 FIRST RUN SETUP - Autonomous AI Agent")
            print("=" * 60)
            print("\nI need to learn a few things about you.")
            print("This will only take about 2 minutes!\n")
    
    def is_first_run(self) -> bool:
        """Check if this is the first run."""
        return not self.first_run_flag.exists()
    
    def ensure_directories(self):
        """Create required directories."""
        directories = [
            self.identity_dir,
            self.memory_dir,
            self.data_dir / "cache",
            self.data_dir / "temp",
            self.data_dir / "backups",
            self.logs_dir,
            self.config_dir / "required",
            self.config_dir / "optional",
        ]
        
        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          AUTO-DETECTION
    # ═══════════════════════════════════════════════════════════════════════════
    
    def detect_system(self) -> Dict[str, Any]:
        """Auto-detect system information."""
        self.print("\n🔍 Detecting system information...", style="cyan")
        
        detected = {
            'os': platform.system(),
            'os_version': platform.version(),
            'os_release': platform.release(),
            'hostname': platform.node(),
            'python_version': platform.python_version(),
            'architecture': platform.machine(),
        }
        
        # Get username
        try:
            detected['username'] = os.getlogin()
        except:
            detected['username'] = os.environ.get('USER', os.environ.get('USERNAME', 'user'))
        
        # Get RAM
        if PSUTIL_AVAILABLE:
            try:
                ram_bytes = psutil.virtual_memory().total
                detected['ram_gb'] = round(ram_bytes / (1024**3), 1)
            except:
                detected['ram_gb'] = None
        else:
            detected['ram_gb'] = None
        
        # Get timezone
        try:
            import time
            detected['timezone'] = time.tzname[0]
        except:
            detected['timezone'] = 'UTC'
        
        # Display detected info
        if self.console:
            table = Table(title="Detected System Info", box=box.ROUNDED)
            table.add_column("Property", style="cyan")
            table.add_column("Value", style="green")
            
            table.add_row("OS", f"{detected['os']} {detected['os_release']}")
            table.add_row("Hostname", detected['hostname'])
            table.add_row("Username", detected['username'])
            table.add_row("Python", detected['python_version'])
            if detected['ram_gb']:
                table.add_row("RAM", f"{detected['ram_gb']} GB")
            table.add_row("Timezone", detected['timezone'])
            
            self.console.print(table)
        else:
            print(f"  OS: {detected['os']} {detected['os_release']}")
            print(f"  Hostname: {detected['hostname']}")
            print(f"  Username: {detected['username']}")
            print(f"  Python: {detected['python_version']}")
            if detected['ram_gb']:
                print(f"  RAM: {detected['ram_gb']} GB")
            print(f"  Timezone: {detected['timezone']}")
        
        self.detected['system'] = detected
        return detected
    
    async def detect_ollama(self) -> Dict[str, Any]:
        """Detect Ollama installation and models."""
        self.print("\n🔍 Detecting Ollama...", style="cyan")
        
        ollama_info = {
            'installed': False,
            'running': False,
            'url': None,
            'models': [],
            'recommended_model': None,
        }
        
        # URLs to try
        urls_to_try = [
            "http://localhost:11434",
            "http://127.0.0.1:11434",
            "http://ollama:11434",
        ]
        
        if not AIOHTTP_AVAILABLE:
            self.print("  ⚠️ aiohttp not installed, skipping Ollama detection", style="yellow")
            self.detected['ollama'] = ollama_info
            return ollama_info
        
        for url in urls_to_try:
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(f"{url}/api/tags", timeout=aiohttp.ClientTimeout(total=5)) as response:
                        if response.status == 200:
                            data = await response.json()
                            ollama_info['installed'] = True
                            ollama_info['running'] = True
                            ollama_info['url'] = url
                            ollama_info['models'] = [m.get('name', '') for m in data.get('models', [])]
                            break
            except:
                continue
        
        # Determine recommended model based on RAM
        ram_gb = self.detected.get('system', {}).get('ram_gb', 8)
        
        if ram_gb and ollama_info['models']:
            # Prioritized models for different RAM sizes
            if ram_gb < 4:
                preferred = ['tinyllama', 'phi']
            elif ram_gb < 8:
                preferred = ['phi', 'tinyllama', 'gemma:2b']
            elif ram_gb < 16:
                preferred = ['llama3.2', 'mistral', 'gemma2', 'llama2']
            else:
                preferred = ['llama3.1', 'llama3.2', 'codellama', 'mistral']
            
            for pref in preferred:
                for model in ollama_info['models']:
                    if pref in model.lower():
                        ollama_info['recommended_model'] = model
                        break
                if ollama_info['recommended_model']:
                    break
            
            # If no preferred model found, use first available
            if not ollama_info['recommended_model'] and ollama_info['models']:
                ollama_info['recommended_model'] = ollama_info['models'][0]
        
        # Display Ollama info
        if ollama_info['running']:
            self.print(f"  ✅ Ollama running at {ollama_info['url']}", style="green")
            if ollama_info['models']:
                self.print(f"  📦 Models: {', '.join(ollama_info['models'][:5])}", style="green")
                if ollama_info['recommended_model']:
                    self.print(f"  ⭐ Recommended: {ollama_info['recommended_model']}", style="green")
            else:
                self.print("  ⚠️ No models installed", style="yellow")
                self.print("  💡 Install with: ollama pull llama3.2", style="cyan")
        else:
            self.print("  ❌ Ollama not running", style="red")
            self.print("  💡 Start with: ollama serve", style="cyan")
        
        self.detected['ollama'] = ollama_info
        return ollama_info
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          QUESTIONS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def ask_owner_info(self):
        """Ask owner information."""
        if self.console:
            self.console.print(Panel(
                "[bold]👤 Let's Get to Know You[/bold]\n\n"
                "I need to know who I'm working for!",
                border_style="blue"
            ))
        else:
            print("\n" + "=" * 40)
            print("👤 Let's Get to Know You")
            print("=" * 40)
        
        # Ask name
        if self.console:
            name = Prompt.ask("\nWhat's your name?", default=self.detected.get('system', {}).get('username', ''))
        else:
            default_name = self.detected.get('system', {}).get('username', '')
            name = input(f"\nWhat's your name? [{default_name}]: ").strip() or default_name
        
        self.answers['owner_name'] = name
        
        # Ask nickname
        if self.console:
            nickname = Prompt.ask("How should I address you?", default=name)
        else:
            nickname = input(f"How should I address you? [{name}]: ").strip() or name
        
        self.answers['owner_nickname'] = nickname
    
    def ask_agent_name(self):
        """Ask for agent name."""
        if self.console:
            self.console.print(Panel(
                "[bold]🤖 Name Your Agent[/bold]\n\n"
                "What should I call myself?",
                border_style="blue"
            ))
        else:
            print("\n" + "=" * 40)
            print("🤖 Name Your Agent")
            print("=" * 40)
        
        if self.console:
            agent_name = Prompt.ask("\nWhat would you like to name me?", default="Axiom")
        else:
            agent_name = input("\nWhat would you like to name me? [Axiom]: ").strip() or "Axiom"
        
        self.answers['agent_name'] = agent_name
    
    def ask_communication_style(self):
        """Ask communication preferences."""
        if self.console:
            self.console.print(Panel(
                "[bold]💬 Communication Style[/bold]\n\n"
                "How should I communicate with you?",
                border_style="blue"
            ))
            
            self.console.print("\nSelect communication style:")
            self.console.print("  [1] Casual   - Friendly, informal, uses emoji 😊")
            self.console.print("  [2] Balanced - Professional but friendly")
            self.console.print("  [3] Formal   - Professional and precise")
            
            choice = Prompt.ask("\nYour choice", choices=["1", "2", "3"], default="2")
            style_map = {"1": "casual", "2": "balanced", "3": "formal"}
            self.answers['communication_style'] = style_map[choice]
            
            show_reasoning = Confirm.ask("\nShould I show my thinking process?", default=True)
            self.answers['show_reasoning'] = show_reasoning
            
        else:
            print("\n" + "=" * 40)
            print("💬 Communication Style")
            print("=" * 40)
            print("\nSelect communication style:")
            print("  [1] Casual   - Friendly and informal")
            print("  [2] Balanced - Professional but friendly")
            print("  [3] Formal   - Professional and precise")
            
            choice = input("\nYour choice [2]: ").strip() or "2"
            style_map = {"1": "casual", "2": "balanced", "3": "formal"}
            self.answers['communication_style'] = style_map.get(choice, "balanced")
            
            show = input("\nShow my thinking process? (y/n) [y]: ").strip().lower()
            self.answers['show_reasoning'] = show != 'n'
    
    def ask_telegram(self):
        """Ask about Telegram setup."""
        if self.console:
            self.console.print(Panel(
                "[bold]📱 Telegram Setup (Optional)[/bold]\n\n"
                "I can send you notifications via Telegram.",
                border_style="blue"
            ))
            
            setup_telegram = Confirm.ask("\nDo you want to set up Telegram?", default=False)
            
            if setup_telegram:
                self.console.print("\n[dim]Get a token from @BotFather on Telegram[/dim]")
                token = Prompt.ask("Enter your Telegram Bot Token", default="")
                self.answers['telegram_token'] = token if token else None
            else:
                self.answers['telegram_token'] = None
        else:
            print("\n" + "=" * 40)
            print("📱 Telegram Setup (Optional)")
            print("=" * 40)
            
            setup = input("\nSet up Telegram? (y/n) [n]: ").strip().lower()
            
            if setup == 'y':
                print("\nGet a token from @BotFather on Telegram")
                token = input("Enter your Telegram Bot Token: ").strip()
                self.answers['telegram_token'] = token if token else None
            else:
                self.answers['telegram_token'] = None
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          SAVE CONFIGURATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    def save_configuration(self):
        """Save all configuration to files."""
        self.print("\n💾 Saving configuration...", style="cyan")
        
        # Ensure directories exist
        self.ensure_directories()
        
        # Prepare owner profile
        owner_data = {
            'id': 'owner',
            'name': self.answers.get('owner_name', 'User'),
            'nickname': self.answers.get('owner_nickname', 'User'),
            'timezone': self.detected.get('system', {}).get('timezone', 'UTC'),
            'language': 'en',
            'communication_style': self.answers.get('communication_style', 'balanced'),
            'show_reasoning': self.answers.get('show_reasoning', True),
            'notify_learnings': True,
            'telegram_token': self.answers.get('telegram_token'),
            'created_at': datetime.utcnow().isoformat(),
            'updated_at': datetime.utcnow().isoformat(),
        }
        
        # Prepare agent identity
        agent_data = {
            'id': 'agent',
            'name': self.answers.get('agent_name', 'Axiom'),
            'version': '3.0.0',
            'personality_traits': ['helpful', 'curious', 'precise', 'honest'],
            'core_values': [
                'never_guess',
                'always_verify', 
                'memory_is_hint',
                'reality_wins',
                'learn_constantly',
                'follow_commands'
            ],
            'created_at': datetime.utcnow().isoformat(),
        }
        
        # Prepare system config
        system_data = {
            'detected': self.detected.get('system', {}),
            'ollama': {
                'url': self.detected.get('ollama', {}).get('url', 'http://localhost:11434'),
                'model': self.detected.get('ollama', {}).get('recommended_model'),
                'available_models': self.detected.get('ollama', {}).get('models', []),
            },
            'first_run_at': datetime.utcnow().isoformat(),
        }
        
        # Save files
        if YAML_AVAILABLE:
            # Save owner profile
            with open(self.owner_profile, 'w') as f:
                yaml.dump(owner_data, f, default_flow_style=False, sort_keys=False)
            self.print(f"  📍 Saved: {self.owner_profile.name}", style="green")
            
            # Save agent identity
            with open(self.agent_identity, 'w') as f:
                yaml.dump(agent_data, f, default_flow_style=False, sort_keys=False)
            self.print(f"  📍 Saved: {self.agent_identity.name}", style="green")
            
            # Save system config
            system_config_path = self.identity_dir / "system_config.yaml"
            with open(system_config_path, 'w') as f:
                yaml.dump(system_data, f, default_flow_style=False, sort_keys=False)
            self.print(f"  📍 Saved: {system_config_path.name}", style="green")
        else:
            # Fallback to JSON if YAML not available
            with open(self.owner_profile.with_suffix('.json'), 'w') as f:
                json.dump(owner_data, f, indent=2)
            
            with open(self.agent_identity.with_suffix('.json'), 'w') as f:
                json.dump(agent_data, f, indent=2)
        
        # Update .env file with Telegram token if provided
        if self.answers.get('telegram_token'):
            env_file = self.project_root / '.env'
            env_content = ""
            
            if env_file.exists():
                env_content = env_file.read_text()
            
            if 'TELEGRAM_BOT_TOKEN=' in env_content:
                # Replace existing token
                lines = env_content.split('\n')
                for i, line in enumerate(lines):
                    if line.startswith('TELEGRAM_BOT_TOKEN=') or line.startswith('#TELEGRAM_BOT_TOKEN='):
                        lines[i] = f"TELEGRAM_BOT_TOKEN={self.answers['telegram_token']}"
                env_content = '\n'.join(lines)
            else:
                # Add new token
                env_content += f"\nTELEGRAM_BOT_TOKEN={self.answers['telegram_token']}\n"
            
            env_file.write_text(env_content)
            self.print("  📍 Updated: .env (Telegram token)", style="green")
        
        # Create first run flag
        self.first_run_flag.write_text(f"completed_at: {datetime.utcnow().isoformat()}\n")
        self.print(f"  📍 Created: {self.first_run_flag.name}", style="green")
    
    def show_completion(self):
        """Show completion message."""
        agent_name = self.answers.get('agent_name', 'Axiom')
        owner_nickname = self.answers.get('owner_nickname', 'User')
        style = self.answers.get('communication_style', 'balanced')
        
        if self.console:
            completion = Panel(
                f"[bold green]✅ Setup Complete![/bold green]\n\n"
                f"Hey {owner_nickname}! 👋\n\n"
                f"I'm [bold cyan]{agent_name}[/bold cyan], your autonomous AI assistant.\n"
                f"I'm all set up and ready to help!\n\n"
                f"[bold]Quick Summary:[/bold]\n"
                f"  • Your name: {self.answers.get('owner_name')} (I'll call you {owner_nickname})\n"
                f"  • My name: {agent_name}\n"
                f"  • Style: {style.title()}\n"
                f"  • Show reasoning: {'Yes' if self.answers.get('show_reasoning') else 'No'}\n"
                f"  • Telegram: {'Configured' if self.answers.get('telegram_token') else 'Not set up'}\n\n"
                f"[dim]These settings are saved permanently and won't be asked again.[/dim]\n\n"
                f"[bold]Next Steps:[/bold]\n"
                f"  Start the agent with: [cyan]python -m core.main[/cyan]",
                title="🎉 All Done!",
                border_style="green",
                box=box.DOUBLE
            )
            self.console.print(completion)
        else:
            print("\n" + "=" * 60)
            print("    ✅ SETUP COMPLETE!")
            print("=" * 60)
            print(f"\nHey {owner_nickname}! 👋")
            print(f"\nI'm {agent_name}, your autonomous AI assistant.")
            print("I'm all set up and ready to help!")
            print(f"\nQuick Summary:")
            print(f"  • Your name: {self.answers.get('owner_name')} (I'll call you {owner_nickname})")
            print(f"  • My name: {agent_name}")
            print(f"  • Style: {style.title()}")
            print(f"  • Show reasoning: {'Yes' if self.answers.get('show_reasoning') else 'No'}")
            print(f"  • Telegram: {'Configured' if self.answers.get('telegram_token') else 'Not set up'}")
            print("\nThese settings are saved permanently and won't be asked again.")
            print("\nNext Steps:")
            print("  Start the agent with: python -m core.main")
            print("=" * 60)
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          MAIN RUN
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def run_async(self):
        """Run the wizard (async parts)."""
        await self.detect_ollama()
    
    def run(self):
        """Run the complete first-run wizard."""
        # Check if already completed
        if not self.is_first_run():
            self.print("\n✅ First run setup already completed!", style="green")
            self.print("   To run setup again, delete:", style="dim")
            self.print(f"   {self.first_run_flag}", style="dim")
            self.print("\n   Or start the agent with: python -m core.main", style="cyan")
            return True
        
        try:
            # Show banner
            self.print_banner()
            
            # Ensure directories
            self.ensure_directories()
            
            # Auto-detection
            self.detect_system()
            
            # Async detection (Ollama)
            asyncio.run(self.run_async())
            
            # Ask questions
            self.ask_owner_info()
            self.ask_agent_name()
            self.ask_communication_style()
            self.ask_telegram()
            
            # Save configuration
            self.save_configuration()
            
            # Show completion
            self.show_completion()
            
            return True
            
        except KeyboardInterrupt:
            self.print("\n\n❌ Setup cancelled by user.", style="yellow")
            return False
        except Exception as e:
            self.print(f"\n\n❌ Setup failed: {e}", style="red")
            import traceback
            traceback.print_exc()
            return False


def main():
    """Main entry point."""
    wizard = FirstRunWizard()
    success = wizard.run()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()