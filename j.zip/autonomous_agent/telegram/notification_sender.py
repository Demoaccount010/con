"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                    TELEGRAM NOTIFICATION SENDER                               ║
║              Send Notifications, Alerts, and Updates via Telegram             ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Union
from dataclasses import dataclass, field
from enum import Enum
import json
from pathlib import Path

logger = logging.getLogger(__name__)


class NotificationLevel(Enum):
    """Notification importance levels"""
    DEBUG = "debug"
    INFO = "info"
    SUCCESS = "success"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class NotificationType(Enum):
    """Types of notifications"""
    SYSTEM = "system"
    MEMORY = "memory"
    LEARNING = "learning"
    RESEARCH = "research"
    TASK = "task"
    ERROR = "error"
    SECURITY = "security"
    UPDATE = "update"
    REMINDER = "reminder"
    CUSTOM = "custom"


@dataclass
class Notification:
    """Notification data structure"""
    id: str
    type: NotificationType
    level: NotificationLevel
    title: str
    message: str
    created_at: datetime = field(default_factory=datetime.now)
    sent_at: Optional[datetime] = None
    delivered: bool = False
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    # Display options
    silent: bool = False
    disable_preview: bool = True
    parse_mode: str = "HTML"
    keyboard: Optional[Dict] = None


@dataclass
class NotificationTemplate:
    """Template for notification formatting"""
    name: str
    template: str
    level: NotificationLevel = NotificationLevel.INFO
    type: NotificationType = NotificationType.CUSTOM
    icon: str = "📢"


@dataclass
class NotificationConfig:
    """Configuration for notification sender"""
    enabled: bool = True
    owner_chat_id: Optional[int] = None
    
    # Level filtering
    min_level: NotificationLevel = NotificationLevel.INFO
    
    # Type filtering
    enabled_types: List[NotificationType] = field(default_factory=lambda: list(NotificationType))
    
    # Rate limiting
    rate_limit_window: int = 60  # seconds
    rate_limit_max: int = 10  # max notifications per window
    
    # Quiet hours
    quiet_hours_enabled: bool = False
    quiet_hours_start: int = 23  # 11 PM
    quiet_hours_end: int = 7    # 7 AM
    
    # Batching
    batch_enabled: bool = True
    batch_window: int = 30  # seconds
    batch_max_size: int = 5


class NotificationQueue:
    """Queue for managing notifications"""
    
    def __init__(self, max_size: int = 1000):
        self._queue: asyncio.Queue = asyncio.Queue(maxsize=max_size)
        self._pending: List[Notification] = []
        self._history: List[Notification] = []
        self._history_max = 100
    
    async def enqueue(self, notification: Notification) -> None:
        """Add notification to queue"""
        await self._queue.put(notification)
    
    async def dequeue(self) -> Notification:
        """Get next notification"""
        return await self._queue.get()
    
    async def dequeue_batch(self, max_count: int, timeout: float = 0.1) -> List[Notification]:
        """Get batch of notifications"""
        batch = []
        try:
            while len(batch) < max_count:
                notification = await asyncio.wait_for(
                    self._queue.get(),
                    timeout=timeout
                )
                batch.append(notification)
        except asyncio.TimeoutError:
            pass
        return batch
    
    def add_to_history(self, notification: Notification) -> None:
        """Add to history"""
        self._history.append(notification)
        if len(self._history) > self._history_max:
            self._history = self._history[-self._history_max:]
    
    @property
    def pending_count(self) -> int:
        return self._queue.qsize()
    
    @property
    def history(self) -> List[Notification]:
        return self._history.copy()


class NotificationFormatter:
    """Format notifications for display"""
    
    # Level icons
    LEVEL_ICONS = {
        NotificationLevel.DEBUG: "🔍",
        NotificationLevel.INFO: "ℹ️",
        NotificationLevel.SUCCESS: "✅",
        NotificationLevel.WARNING: "⚠️",
        NotificationLevel.ERROR: "❌",
        NotificationLevel.CRITICAL: "🚨"
    }
    
    # Type icons
    TYPE_ICONS = {
        NotificationType.SYSTEM: "🖥️",
        NotificationType.MEMORY: "💾",
        NotificationType.LEARNING: "📚",
        NotificationType.RESEARCH: "🔬",
        NotificationType.TASK: "📋",
        NotificationType.ERROR: "❌",
        NotificationType.SECURITY: "🔐",
        NotificationType.UPDATE: "🔄",
        NotificationType.REMINDER: "⏰",
        NotificationType.CUSTOM: "📢"
    }
    
    def __init__(self):
        self._templates: Dict[str, NotificationTemplate] = {}
        self._load_default_templates()
    
    def _load_default_templates(self) -> None:
        """Load default notification templates"""
        self._templates = {
            "memory_saved": NotificationTemplate(
                name="memory_saved",
                template="{icon} <b>Memory Saved</b>\n\n{message}\n\n<i>{timestamp}</i>",
                level=NotificationLevel.INFO,
                type=NotificationType.MEMORY,
                icon="🏷️"
            ),
            "memory_updated": NotificationTemplate(
                name="memory_updated",
                template="{icon} <b>Memory Updated</b>\n\n{message}\n\n<i>{timestamp}</i>",
                level=NotificationLevel.INFO,
                type=NotificationType.MEMORY,
                icon="🔄"
            ),
            "learning_complete": NotificationTemplate(
                name="learning_complete",
                template="{icon} <b>Learning Complete</b>\n\n📝 Topic: {topic}\n\n{summary}\n\n<i>{timestamp}</i>",
                level=NotificationLevel.SUCCESS,
                type=NotificationType.LEARNING,
                icon="📚"
            ),
            "research_finding": NotificationTemplate(
                name="research_finding",
                template="{icon} <b>Research Finding</b>\n\n🔍 Topic: {topic}\n\n{finding}\n\n<i>{timestamp}</i>",
                level=NotificationLevel.INFO,
                type=NotificationType.RESEARCH,
                icon="🔬"
            ),
            "task_complete": NotificationTemplate(
                name="task_complete",
                template="{icon} <b>Task Complete</b>\n\n📋 {task_name}\n\n✅ {result}\n\n<i>{timestamp}</i>",
                level=NotificationLevel.SUCCESS,
                type=NotificationType.TASK,
                icon="✅"
            ),
            "error_occurred": NotificationTemplate(
                name="error_occurred",
                template="{icon} <b>Error Occurred</b>\n\n❌ {error_type}\n\n{message}\n\n<i>{timestamp}</i>",
                level=NotificationLevel.ERROR,
                type=NotificationType.ERROR,
                icon="🚨"
            ),
            "system_status": NotificationTemplate(
                name="system_status",
                template="{icon} <b>System Status</b>\n\n{status}\n\n<i>{timestamp}</i>",
                level=NotificationLevel.INFO,
                type=NotificationType.SYSTEM,
                icon="🖥️"
            ),
            "security_alert": NotificationTemplate(
                name="security_alert",
                template="{icon} <b>Security Alert</b>\n\n🔐 {alert_type}\n\n{details}\n\n<i>{timestamp}</i>",
                level=NotificationLevel.WARNING,
                type=NotificationType.SECURITY,
                icon="⚠️"
            )
        }
    
    def add_template(self, template: NotificationTemplate) -> None:
        """Add custom template"""
        self._templates[template.name] = template
    
    def format(
        self,
        notification: Notification,
        template_name: Optional[str] = None
    ) -> str:
        """Format notification for display"""
        # Get template
        template = None
        if template_name and template_name in self._templates:
            template = self._templates[template_name]
        
        # Get icons
        level_icon = self.LEVEL_ICONS.get(notification.level, "📢")
        type_icon = self.TYPE_ICONS.get(notification.type, "📢")
        
        # Format timestamp
        timestamp = notification.created_at.strftime("%Y-%m-%d %H:%M:%S")
        
        if template:
            # Use template
            format_data = {
                "icon": template.icon,
                "level_icon": level_icon,
                "type_icon": type_icon,
                "title": notification.title,
                "message": notification.message,
                "timestamp": timestamp,
                **notification.metadata
            }
            try:
                return template.template.format(**format_data)
            except KeyError as e:
                logger.warning(f"Template format error: {e}")
        
        # Default format
        return f"""
{level_icon} <b>{notification.title}</b>

{notification.message}

<i>{timestamp}</i>
        """.strip()
    
    def format_batch(self, notifications: List[Notification]) -> str:
        """Format batch of notifications"""
        if not notifications:
            return ""
        
        if len(notifications) == 1:
            return self.format(notifications[0])
        
        lines = [f"📬 <b>{len(notifications)} Notifications</b>\n"]
        
        for i, notif in enumerate(notifications, 1):
            level_icon = self.LEVEL_ICONS.get(notif.level, "📢")
            lines.append(f"{i}. {level_icon} <b>{notif.title}</b>")
            lines.append(f"   {notif.message[:100]}{'...' if len(notif.message) > 100 else ''}\n")
        
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        lines.append(f"\n<i>{timestamp}</i>")
        
        return "\n".join(lines)


class NotificationSender:
    """
    Send notifications via Telegram
    
    Features:
    - Multiple notification types and levels
    - Rate limiting
    - Quiet hours
    - Batching
    - Templates
    - Queue management
    - Retry logic
    """
    
    def __init__(
        self,
        bot: Any,  # TelegramBot instance
        config: Optional[NotificationConfig] = None
    ):
        self.bot = bot
        self.config = config or NotificationConfig()
        
        self._queue = NotificationQueue()
        self._formatter = NotificationFormatter()
        self._running = False
        self._worker_task: Optional[asyncio.Task] = None
        
        # Rate limiting
        self._rate_limit_tokens: List[datetime] = []
        
        # Statistics
        self._stats = {
            "sent": 0,
            "failed": 0,
            "rate_limited": 0,
            "batched": 0,
            "quiet_hours_skipped": 0
        }
        
        logger.info("NotificationSender initialized")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # LIFECYCLE
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def start(self) -> None:
        """Start notification sender"""
        if self._running:
            return
        
        self._running = True
        self._worker_task = asyncio.create_task(self._worker())
        logger.info("NotificationSender started")
    
    async def stop(self) -> None:
        """Stop notification sender"""
        self._running = False
        
        if self._worker_task:
            self._worker_task.cancel()
            try:
                await self._worker_task
            except asyncio.CancelledError:
                pass
        
        logger.info("NotificationSender stopped")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # NOTIFICATION METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def notify(
        self,
        title: str,
        message: str,
        level: NotificationLevel = NotificationLevel.INFO,
        type_: NotificationType = NotificationType.CUSTOM,
        template: Optional[str] = None,
        silent: bool = False,
        metadata: Optional[Dict[str, Any]] = None,
        keyboard: Optional[Dict] = None
    ) -> Optional[Notification]:
        """Send a notification"""
        if not self.config.enabled:
            return None
        
        # Check level filter
        if not self._should_send_level(level):
            return None
        
        # Check type filter
        if type_ not in self.config.enabled_types:
            return None
        
        # Create notification
        notification = Notification(
            id=f"notif_{datetime.now().timestamp()}",
            type=type_,
            level=level,
            title=title,
            message=message,
            silent=silent,
            metadata=metadata or {},
            keyboard=keyboard
        )
        
        notification.metadata["template"] = template
        
        # Add to queue
        await self._queue.enqueue(notification)
        
        return notification
    
    async def notify_info(self, title: str, message: str, **kwargs) -> Optional[Notification]:
        """Send info notification"""
        return await self.notify(title, message, NotificationLevel.INFO, **kwargs)
    
    async def notify_success(self, title: str, message: str, **kwargs) -> Optional[Notification]:
        """Send success notification"""
        return await self.notify(title, message, NotificationLevel.SUCCESS, **kwargs)
    
    async def notify_warning(self, title: str, message: str, **kwargs) -> Optional[Notification]:
        """Send warning notification"""
        return await self.notify(title, message, NotificationLevel.WARNING, **kwargs)
    
    async def notify_error(self, title: str, message: str, **kwargs) -> Optional[Notification]:
        """Send error notification"""
        return await self.notify(title, message, NotificationLevel.ERROR, **kwargs)
    
    async def notify_critical(self, title: str, message: str, **kwargs) -> Optional[Notification]:
        """Send critical notification (always sent, ignores quiet hours)"""
        notification = await self.notify(title, message, NotificationLevel.CRITICAL, **kwargs)
        # Critical notifications bypass the queue
        if notification:
            await self._send_notification(notification, bypass_checks=True)
        return notification
    
    # ═══════════════════════════════════════════════════════════════════════════
    # SPECIFIC NOTIFICATION TYPES
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def notify_memory_saved(
        self,
        memory_type: str,
        content_preview: str,
        tags: Optional[List[str]] = None
    ) -> Optional[Notification]:
        """Notify about memory being saved"""
        return await self.notify(
            title="Memory Saved",
            message=f"Type: {memory_type}\n\n{content_preview}",
            level=NotificationLevel.INFO,
            type_=NotificationType.MEMORY,
            template="memory_saved",
            metadata={"memory_type": memory_type, "tags": tags or []}
        )
    
    async def notify_memory_updated(
        self,
        memory_type: str,
        what_changed: str
    ) -> Optional[Notification]:
        """Notify about memory being updated"""
        return await self.notify(
            title="Memory Updated",
            message=what_changed,
            level=NotificationLevel.INFO,
            type_=NotificationType.MEMORY,
            template="memory_updated",
            metadata={"memory_type": memory_type}
        )
    
    async def notify_learning(
        self,
        topic: str,
        summary: str
    ) -> Optional[Notification]:
        """Notify about learning completion"""
        return await self.notify(
            title="Learning Complete",
            message=f"Learned about: {topic}\n\n{summary}",
            level=NotificationLevel.SUCCESS,
            type_=NotificationType.LEARNING,
            template="learning_complete",
            metadata={"topic": topic, "summary": summary}
        )
    
    async def notify_research(
        self,
        topic: str,
        finding: str
    ) -> Optional[Notification]:
        """Notify about research finding"""
        return await self.notify(
            title="Research Finding",
            message=f"Topic: {topic}\n\n{finding}",
            level=NotificationLevel.INFO,
            type_=NotificationType.RESEARCH,
            template="research_finding",
            metadata={"topic": topic, "finding": finding}
        )
    
    async def notify_task_complete(
        self,
        task_name: str,
        result: str
    ) -> Optional[Notification]:
        """Notify about task completion"""
        return await self.notify(
            title="Task Complete",
            message=f"Task: {task_name}\n\nResult: {result}",
            level=NotificationLevel.SUCCESS,
            type_=NotificationType.TASK,
            template="task_complete",
            metadata={"task_name": task_name, "result": result}
        )
    
    async def notify_system_error(
        self,
        error_type: str,
        error_message: str
    ) -> Optional[Notification]:
        """Notify about system error"""
        return await self.notify(
            title="System Error",
            message=f"Error: {error_type}\n\n{error_message}",
            level=NotificationLevel.ERROR,
            type_=NotificationType.ERROR,
            template="error_occurred",
            metadata={"error_type": error_type}
        )
    
    async def notify_security(
        self,
        alert_type: str,
        details: str
    ) -> Optional[Notification]:
        """Notify about security event"""
        return await self.notify(
            title="Security Alert",
            message=f"Alert: {alert_type}\n\n{details}",
            level=NotificationLevel.WARNING,
            type_=NotificationType.SECURITY,
            template="security_alert",
            metadata={"alert_type": alert_type, "details": details}
        )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # WORKER AND SENDING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _worker(self) -> None:
        """Background worker for processing notifications"""
        logger.info("Notification worker started")
        
        while self._running:
            try:
                if self.config.batch_enabled:
                    # Batch mode
                    batch = await self._queue.dequeue_batch(
                        max_count=self.config.batch_max_size,
                        timeout=self.config.batch_window
                    )
                    
                    if batch:
                        await self._send_batch(batch)
                else:
                    # Single mode
                    notification = await asyncio.wait_for(
                        self._queue.dequeue(),
                        timeout=1.0
                    )
                    await self._send_notification(notification)
                    
            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Notification worker error: {e}")
                await asyncio.sleep(1)
        
        logger.info("Notification worker stopped")
    
    async def _send_notification(
        self,
        notification: Notification,
        bypass_checks: bool = False
    ) -> bool:
        """Send a single notification"""
        if not self.config.owner_chat_id:
            logger.warning("No owner chat ID configured")
            return False
        
        if not bypass_checks:
            # Check quiet hours
            if self._is_quiet_hours():
                self._stats["quiet_hours_skipped"] += 1
                return False
            
            # Check rate limit
            if not self._check_rate_limit():
                self._stats["rate_limited"] += 1
                return False
        
        try:
            # Format notification
            template = notification.metadata.get("template")
            text = self._formatter.format(notification, template)
            
            # Send via bot
            await self.bot.send_message(
                chat_id=self.config.owner_chat_id,
                text=text,
                parse_mode=notification.parse_mode,
                disable_web_page_preview=notification.disable_preview,
                reply_markup=notification.keyboard
            )
            
            notification.sent_at = datetime.now()
            notification.delivered = True
            
            self._queue.add_to_history(notification)
            self._stats["sent"] += 1
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to send notification: {e}")
            notification.error = str(e)
            self._stats["failed"] += 1
            return False
    
    async def _send_batch(self, notifications: List[Notification]) -> bool:
        """Send batch of notifications"""
        if not notifications:
            return True
        
        if not self.config.owner_chat_id:
            return False
        
        # Check quiet hours (batch respects quiet hours)
        if self._is_quiet_hours():
            self._stats["quiet_hours_skipped"] += len(notifications)
            return False
        
        try:
            # Format batch
            text = self._formatter.format_batch(notifications)
            
            # Send via bot
            await self.bot.send_message(
                chat_id=self.config.owner_chat_id,
                text=text,
                parse_mode="HTML",
                disable_web_page_preview=True
            )
            
            # Update notifications
            now = datetime.now()
            for notif in notifications:
                notif.sent_at = now
                notif.delivered = True
                self._queue.add_to_history(notif)
            
            self._stats["sent"] += len(notifications)
            self._stats["batched"] += 1
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to send batch: {e}")
            self._stats["failed"] += len(notifications)
            return False
    
    # ═══════════════════════════════════════════════════════════════════════════
    # HELPER METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _should_send_level(self, level: NotificationLevel) -> bool:
        """Check if notification level should be sent"""
        level_order = [
            NotificationLevel.DEBUG,
            NotificationLevel.INFO,
            NotificationLevel.SUCCESS,
            NotificationLevel.WARNING,
            NotificationLevel.ERROR,
            NotificationLevel.CRITICAL
        ]
        
        try:
            current_idx = level_order.index(level)
            min_idx = level_order.index(self.config.min_level)
            return current_idx >= min_idx
        except ValueError:
            return True
    
    def _is_quiet_hours(self) -> bool:
        """Check if currently in quiet hours"""
        if not self.config.quiet_hours_enabled:
            return False
        
        now = datetime.now()
        current_hour = now.hour
        
        start = self.config.quiet_hours_start
        end = self.config.quiet_hours_end
        
        if start < end:
            # Same day (e.g., 23:00 to 23:59 or 0:00 to 7:00)
            return start <= current_hour < end
        else:
            # Overnight (e.g., 23:00 to 7:00)
            return current_hour >= start or current_hour < end
    
    def _check_rate_limit(self) -> bool:
        """Check rate limit"""
        now = datetime.now()
        window_start = now - timedelta(seconds=self.config.rate_limit_window)
        
        # Remove old tokens
        self._rate_limit_tokens = [
            t for t in self._rate_limit_tokens
            if t > window_start
        ]
        
        # Check limit
        if len(self._rate_limit_tokens) >= self.config.rate_limit_max:
            return False
        
        self._rate_limit_tokens.append(now)
        return True
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CONFIGURATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    def set_owner_chat(self, chat_id: int) -> None:
        """Set owner chat ID"""
        self.config.owner_chat_id = chat_id
    
    def enable_type(self, type_: NotificationType) -> None:
        """Enable notification type"""
        if type_ not in self.config.enabled_types:
            self.config.enabled_types.append(type_)
    
    def disable_type(self, type_: NotificationType) -> None:
        """Disable notification type"""
        if type_ in self.config.enabled_types:
            self.config.enabled_types.remove(type_)
    
    def set_min_level(self, level: NotificationLevel) -> None:
        """Set minimum notification level"""
        self.config.min_level = level
    
    def set_quiet_hours(
        self,
        enabled: bool,
        start_hour: int = 23,
        end_hour: int = 7
    ) -> None:
        """Configure quiet hours"""
        self.config.quiet_hours_enabled = enabled
        self.config.quiet_hours_start = start_hour
        self.config.quiet_hours_end = end_hour
    
    def add_template(self, template: NotificationTemplate) -> None:
        """Add custom notification template"""
        self._formatter.add_template(template)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get notification statistics"""
        return {
            **self._stats,
            "pending": self._queue.pending_count,
            "history_count": len(self._queue.history),
            "quiet_hours_active": self._is_quiet_hours(),
            "enabled": self.config.enabled
        }
    
    def get_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get notification history"""
        history = self._queue.history[-limit:]
        return [
            {
                "id": n.id,
                "type": n.type.value,
                "level": n.level.value,
                "title": n.title,
                "message": n.message[:100],
                "created_at": n.created_at.isoformat(),
                "sent_at": n.sent_at.isoformat() if n.sent_at else None,
                "delivered": n.delivered
            }
            for n in history
        ]


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

async def create_notification_sender(
    bot: Any,
    owner_chat_id: Optional[int] = None,
    **kwargs
) -> NotificationSender:
    """Create and start notification sender"""
    config = NotificationConfig(
        owner_chat_id=owner_chat_id,
        **kwargs
    )
    
    sender = NotificationSender(bot=bot, config=config)
    await sender.start()
    
    return sender