"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                    TELEGRAM MESSAGE HANDLER                                   ║
║              Advanced Message Processing and Routing                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import asyncio
import logging
import re
from datetime import datetime
from typing import Optional, Dict, Any, List, Callable, Awaitable, Pattern
from dataclasses import dataclass, field
from enum import Enum
from abc import ABC, abstractmethod

logger = logging.getLogger(__name__)


class MessageType(Enum):
    """Types of messages"""
    TEXT = "text"
    COMMAND = "command"
    PHOTO = "photo"
    DOCUMENT = "document"
    VOICE = "voice"
    VIDEO = "video"
    STICKER = "sticker"
    LOCATION = "location"
    CONTACT = "contact"
    POLL = "poll"
    REPLY = "reply"
    FORWARD = "forward"
    MENTION = "mention"
    HASHTAG = "hashtag"
    URL = "url"
    UNKNOWN = "unknown"


class MessagePriority(Enum):
    """Message processing priority"""
    URGENT = 1
    HIGH = 2
    NORMAL = 3
    LOW = 4
    BACKGROUND = 5


@dataclass
class MessageContext:
    """Context for message processing"""
    message_id: int
    chat_id: int
    user_id: Optional[int]
    username: Optional[str]
    is_owner: bool
    is_group: bool
    is_private: bool
    message_type: MessageType
    priority: MessagePriority
    timestamp: datetime
    raw_text: Optional[str]
    entities: List[Dict]
    reply_to: Optional[int]
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ProcessedMessage:
    """Result of message processing"""
    original_text: str
    cleaned_text: str
    intent: Optional[str]
    entities: Dict[str, List[str]]
    mentions: List[str]
    hashtags: List[str]
    urls: List[str]
    commands: List[str]
    is_question: bool
    language: Optional[str]
    sentiment: Optional[str]
    priority: MessagePriority


class MessageFilter(ABC):
    """Abstract base for message filters"""
    
    @abstractmethod
    async def matches(self, context: MessageContext, text: str) -> bool:
        """Check if message matches filter"""
        pass


class TextFilter(MessageFilter):
    """Filter by text content"""
    
    def __init__(self, pattern: str, case_sensitive: bool = False):
        self.pattern = pattern
        self.case_sensitive = case_sensitive
        if case_sensitive:
            self._regex = re.compile(pattern)
        else:
            self._regex = re.compile(pattern, re.IGNORECASE)
    
    async def matches(self, context: MessageContext, text: str) -> bool:
        if not text:
            return False
        return bool(self._regex.search(text))


class CommandFilter(MessageFilter):
    """Filter by command"""
    
    def __init__(self, commands: List[str]):
        self.commands = [cmd.lower().lstrip('/') for cmd in commands]
    
    async def matches(self, context: MessageContext, text: str) -> bool:
        if context.message_type != MessageType.COMMAND:
            return False
        if not text:
            return False
        
        cmd = text.split()[0].lstrip('/').split('@')[0].lower()
        return cmd in self.commands


class UserFilter(MessageFilter):
    """Filter by user"""
    
    def __init__(
        self,
        user_ids: Optional[List[int]] = None,
        usernames: Optional[List[str]] = None,
        owner_only: bool = False
    ):
        self.user_ids = set(user_ids) if user_ids else set()
        self.usernames = set(u.lower().lstrip('@') for u in (usernames or []))
        self.owner_only = owner_only
    
    async def matches(self, context: MessageContext, text: str) -> bool:
        if self.owner_only:
            return context.is_owner
        
        if self.user_ids and context.user_id in self.user_ids:
            return True
        
        if self.usernames and context.username:
            if context.username.lower() in self.usernames:
                return True
        
        return not self.user_ids and not self.usernames


class ChatFilter(MessageFilter):
    """Filter by chat type"""
    
    def __init__(
        self,
        private_only: bool = False,
        group_only: bool = False,
        chat_ids: Optional[List[int]] = None
    ):
        self.private_only = private_only
        self.group_only = group_only
        self.chat_ids = set(chat_ids) if chat_ids else set()
    
    async def matches(self, context: MessageContext, text: str) -> bool:
        if self.private_only and not context.is_private:
            return False
        if self.group_only and not context.is_group:
            return False
        if self.chat_ids and context.chat_id not in self.chat_ids:
            return False
        return True


class RegexFilter(MessageFilter):
    """Filter by regex pattern"""
    
    def __init__(self, pattern: str, flags: int = 0):
        self._regex = re.compile(pattern, flags)
    
    async def matches(self, context: MessageContext, text: str) -> bool:
        if not text:
            return False
        return bool(self._regex.search(text))


class CompositeFilter(MessageFilter):
    """Combine multiple filters"""
    
    def __init__(self, filters: List[MessageFilter], require_all: bool = True):
        self.filters = filters
        self.require_all = require_all
    
    async def matches(self, context: MessageContext, text: str) -> bool:
        results = await asyncio.gather(*[
            f.matches(context, text) for f in self.filters
        ])
        
        if self.require_all:
            return all(results)
        return any(results)


@dataclass
class MessageRoute:
    """Route configuration for message handling"""
    name: str
    filter: MessageFilter
    handler: Callable[[MessageContext, str], Awaitable[Optional[str]]]
    priority: int = 0
    enabled: bool = True
    rate_limit: Optional[int] = None  # Max calls per minute


class MessageProcessor:
    """
    Process and extract information from messages
    """
    
    # Entity patterns
    URL_PATTERN = re.compile(
        r'https?://[^\s<>"{}|\\^`\[\]]+',
        re.IGNORECASE
    )
    
    MENTION_PATTERN = re.compile(r'@(\w+)')
    HASHTAG_PATTERN = re.compile(r'#(\w+)')
    EMAIL_PATTERN = re.compile(r'[\w.+-]+@[\w-]+\.[\w.-]+')
    
    QUESTION_INDICATORS = ['?', 'what', 'why', 'how', 'when', 'where', 'who', 'which', 'can you', 'could you', 'would you']
    
    def __init__(self):
        self._intent_patterns: Dict[str, Pattern] = {}
        self._setup_intent_patterns()
    
    def _setup_intent_patterns(self) -> None:
        """Setup intent recognition patterns"""
        self._intent_patterns = {
            "greeting": re.compile(r'\b(hi|hello|hey|greetings|good\s*(morning|afternoon|evening))\b', re.I),
            "farewell": re.compile(r'\b(bye|goodbye|see\s*you|later|good\s*night)\b', re.I),
            "thanks": re.compile(r'\b(thank|thanks|thx|appreciate)\b', re.I),
            "help": re.compile(r'\b(help|assist|support|how\s*to)\b', re.I),
            "question": re.compile(r'\?|^(what|why|how|when|where|who|which|can|could|would|is|are|do|does)\b', re.I),
            "command": re.compile(r'^(run|execute|do|make|create|delete|show|list|find|search)\b', re.I),
            "affirmative": re.compile(r'\b(yes|yeah|yep|sure|ok|okay|correct|right|agreed)\b', re.I),
            "negative": re.compile(r'\b(no|nope|nah|wrong|incorrect|disagree)\b', re.I),
            "learn": re.compile(r'\b(learn|teach|explain|tell\s*me\s*about)\b', re.I),
            "remember": re.compile(r'\b(remember|save|store|note|memo)\b', re.I),
            "forget": re.compile(r'\b(forget|remove|delete|erase)\b', re.I),
        }
    
    async def process(self, text: str, entities: Optional[List[Dict]] = None) -> ProcessedMessage:
        """Process message and extract information"""
        if not text:
            return ProcessedMessage(
                original_text="",
                cleaned_text="",
                intent=None,
                entities={},
                mentions=[],
                hashtags=[],
                urls=[],
                commands=[],
                is_question=False,
                language=None,
                sentiment=None,
                priority=MessagePriority.NORMAL
            )
        
        # Clean text
        cleaned = self._clean_text(text)
        
        # Extract entities
        extracted_entities = await self._extract_entities(text, entities)
        
        # Extract mentions, hashtags, urls
        mentions = self.MENTION_PATTERN.findall(text)
        hashtags = self.HASHTAG_PATTERN.findall(text)
        urls = self.URL_PATTERN.findall(text)
        
        # Extract commands
        commands = []
        if text.startswith('/'):
            cmd = text.split()[0][1:].split('@')[0]
            commands.append(cmd)
        
        # Detect intent
        intent = self._detect_intent(cleaned)
        
        # Is question?
        is_question = any(
            indicator in cleaned.lower() 
            for indicator in self.QUESTION_INDICATORS
        )
        
        # Determine priority
        priority = self._determine_priority(text, intent, extracted_entities)
        
        return ProcessedMessage(
            original_text=text,
            cleaned_text=cleaned,
            intent=intent,
            entities=extracted_entities,
            mentions=mentions,
            hashtags=hashtags,
            urls=urls,
            commands=commands,
            is_question=is_question,
            language=None,  # TODO: Language detection
            sentiment=None,  # TODO: Sentiment analysis
            priority=priority
        )
    
    def _clean_text(self, text: str) -> str:
        """Clean and normalize text"""
        # Remove extra whitespace
        cleaned = ' '.join(text.split())
        # Remove special characters but keep punctuation
        cleaned = re.sub(r'[^\w\s.,!?\'"-]', '', cleaned)
        return cleaned.strip()
    
    async def _extract_entities(
        self,
        text: str,
        telegram_entities: Optional[List[Dict]]
    ) -> Dict[str, List[str]]:
        """Extract named entities from text"""
        entities: Dict[str, List[str]] = {
            "urls": [],
            "emails": [],
            "mentions": [],
            "hashtags": [],
            "commands": [],
            "numbers": [],
            "dates": [],
            "times": [],
            "paths": [],
        }
        
        # URLs
        entities["urls"] = self.URL_PATTERN.findall(text)
        
        # Emails
        entities["emails"] = self.EMAIL_PATTERN.findall(text)
        
        # Mentions
        entities["mentions"] = self.MENTION_PATTERN.findall(text)
        
        # Hashtags
        entities["hashtags"] = self.HASHTAG_PATTERN.findall(text)
        
        # Numbers
        entities["numbers"] = re.findall(r'\b\d+(?:\.\d+)?\b', text)
        
        # File paths
        entities["paths"] = re.findall(r'[/~][\w/.-]+', text)
        
        # Use Telegram entities if provided
        if telegram_entities:
            for entity in telegram_entities:
                entity_type = entity.get("type")
                offset = entity.get("offset", 0)
                length = entity.get("length", 0)
                value = text[offset:offset + length]
                
                if entity_type == "url":
                    if value not in entities["urls"]:
                        entities["urls"].append(value)
                elif entity_type == "mention":
                    if value.lstrip('@') not in entities["mentions"]:
                        entities["mentions"].append(value.lstrip('@'))
                elif entity_type == "email":
                    if value not in entities["emails"]:
                        entities["emails"].append(value)
                elif entity_type == "bot_command":
                    cmd = value.lstrip('/').split('@')[0]
                    entities["commands"].append(cmd)
        
        return entities
    
    def _detect_intent(self, text: str) -> Optional[str]:
        """Detect message intent"""
        for intent, pattern in self._intent_patterns.items():
            if pattern.search(text):
                return intent
        return None
    
    def _determine_priority(
        self,
        text: str,
        intent: Optional[str],
        entities: Dict[str, List[str]]
    ) -> MessagePriority:
        """Determine message priority"""
        # Commands are higher priority
        if text.startswith('/'):
            return MessagePriority.HIGH
        
        # Questions get normal priority
        if intent == "question":
            return MessagePriority.NORMAL
        
        # Greetings are low priority
        if intent in ("greeting", "farewell", "thanks"):
            return MessagePriority.LOW
        
        # Messages with URLs might need processing
        if entities.get("urls"):
            return MessagePriority.NORMAL
        
        return MessagePriority.NORMAL


class MessageHandler:
    """
    Central message handler with routing and processing
    
    Features:
    - Message routing based on filters
    - Priority-based processing
    - Rate limiting per route
    - Middleware support
    - Context enrichment
    """
    
    def __init__(
        self,
        agent_loop: Optional[Any] = None,
        memory_manager: Optional[Any] = None
    ):
        self.agent_loop = agent_loop
        self.memory_manager = memory_manager
        
        self._routes: List[MessageRoute] = []
        self._middlewares: List[Callable] = []
        self._processor = MessageProcessor()
        self._rate_limits: Dict[str, List[datetime]] = {}
        
        # Statistics
        self._stats = {
            "messages_handled": 0,
            "routes_matched": 0,
            "rate_limited": 0,
            "errors": 0
        }
        
        logger.info("MessageHandler initialized")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # ROUTE MANAGEMENT
    # ═══════════════════════════════════════════════════════════════════════════
    
    def add_route(self, route: MessageRoute) -> None:
        """Add a message route"""
        self._routes.append(route)
        # Sort by priority (lower = higher priority)
        self._routes.sort(key=lambda r: r.priority)
        logger.debug(f"Added route: {route.name}")
    
    def remove_route(self, name: str) -> bool:
        """Remove a route by name"""
        for i, route in enumerate(self._routes):
            if route.name == name:
                del self._routes[i]
                return True
        return False
    
    def route(
        self,
        filter_: MessageFilter,
        priority: int = 0,
        rate_limit: Optional[int] = None
    ):
        """Decorator to add route"""
        def decorator(func: Callable[[MessageContext, str], Awaitable[Optional[str]]]):
            route = MessageRoute(
                name=func.__name__,
                filter=filter_,
                handler=func,
                priority=priority,
                rate_limit=rate_limit
            )
            self.add_route(route)
            return func
        return decorator
    
    def command_route(self, commands: List[str], **kwargs):
        """Decorator for command routes"""
        return self.route(CommandFilter(commands), **kwargs)
    
    def text_route(self, pattern: str, **kwargs):
        """Decorator for text pattern routes"""
        return self.route(TextFilter(pattern), **kwargs)
    
    def owner_route(self, **kwargs):
        """Decorator for owner-only routes"""
        return self.route(UserFilter(owner_only=True), **kwargs)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MIDDLEWARE
    # ═══════════════════════════════════════════════════════════════════════════
    
    def add_middleware(
        self,
        middleware: Callable[[MessageContext, str], Awaitable[Optional[tuple]]]
    ) -> None:
        """
        Add middleware function
        
        Middleware should return (context, text) to continue, or None to stop
        """
        self._middlewares.append(middleware)
    
    def middleware(self):
        """Decorator to add middleware"""
        def decorator(func):
            self.add_middleware(func)
            return func
        return decorator
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MESSAGE HANDLING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def handle(
        self,
        message: Any,  # TelegramMessage from telegram_bot
        bot: Optional[Any] = None
    ) -> Optional[str]:
        """Handle incoming message"""
        self._stats["messages_handled"] += 1
        
        try:
            # Build context
            context = await self._build_context(message)
            text = message.text or message.caption or ""
            
            # Process message
            processed = await self._processor.process(text, message.entities)
            context.metadata["processed"] = processed
            
            # Run middlewares
            result = await self._run_middlewares(context, text)
            if result is None:
                return None  # Middleware stopped processing
            context, text = result
            
            # Find matching route
            for route in self._routes:
                if not route.enabled:
                    continue
                
                if await route.filter.matches(context, text):
                    # Check rate limit
                    if not await self._check_rate_limit(route):
                        self._stats["rate_limited"] += 1
                        continue
                    
                    self._stats["routes_matched"] += 1
                    
                    # Execute handler
                    response = await route.handler(context, text)
                    
                    # Store conversation in memory
                    if self.memory_manager:
                        await self._store_conversation(context, text, response)
                    
                    return response
            
            # No route matched - use agent loop
            if self.agent_loop:
                return await self._process_with_agent(context, text)
            
            return None
            
        except Exception as e:
            self._stats["errors"] += 1
            logger.error(f"Error handling message: {e}")
            raise
    
    async def _build_context(self, message: Any) -> MessageContext:
        """Build message context"""
        # Determine message type
        msg_type = MessageType.TEXT
        if message.is_command:
            msg_type = MessageType.COMMAND
        elif message.photo:
            msg_type = MessageType.PHOTO
        elif message.document:
            msg_type = MessageType.DOCUMENT
        elif message.voice:
            msg_type = MessageType.VOICE
        
        return MessageContext(
            message_id=message.message_id,
            chat_id=message.chat.id,
            user_id=message.from_user.id if message.from_user else None,
            username=message.from_user.username if message.from_user else None,
            is_owner=message.from_user.is_owner if message.from_user else False,
            is_group=message.chat.is_group,
            is_private=message.chat.is_private,
            message_type=msg_type,
            priority=MessagePriority.NORMAL,
            timestamp=message.date,
            raw_text=message.text or message.caption,
            entities=message.entities,
            reply_to=message.reply_to_message.message_id if message.reply_to_message else None
        )
    
    async def _run_middlewares(
        self,
        context: MessageContext,
        text: str
    ) -> Optional[tuple]:
        """Run all middlewares"""
        for middleware in self._middlewares:
            result = await middleware(context, text)
            if result is None:
                return None
            context, text = result
        return context, text
    
    async def _check_rate_limit(self, route: MessageRoute) -> bool:
        """Check if route is rate limited"""
        if not route.rate_limit:
            return True
        
        now = datetime.now()
        route_key = route.name
        
        # Initialize if needed
        if route_key not in self._rate_limits:
            self._rate_limits[route_key] = []
        
        # Remove old entries (older than 1 minute)
        self._rate_limits[route_key] = [
            t for t in self._rate_limits[route_key]
            if (now - t).total_seconds() < 60
        ]
        
        # Check limit
        if len(self._rate_limits[route_key]) >= route.rate_limit:
            return False
        
        self._rate_limits[route_key].append(now)
        return True
    
    async def _process_with_agent(
        self,
        context: MessageContext,
        text: str
    ) -> Optional[str]:
        """Process message through agent loop"""
        if not self.agent_loop:
            return None
        
        agent_context = {
            "user_id": context.user_id,
            "username": context.username,
            "chat_id": context.chat_id,
            "message_id": context.message_id,
            "is_owner": context.is_owner,
            "platform": "telegram",
            "message_type": context.message_type.value,
            "processed": context.metadata.get("processed")
        }
        
        response = await self.agent_loop.process_input(text, context=agent_context)
        return str(response) if response else None
    
    async def _store_conversation(
        self,
        context: MessageContext,
        user_message: str,
        bot_response: Optional[str]
    ) -> None:
        """Store conversation in memory"""
        if not self.memory_manager:
            return
        
        try:
            await self.memory_manager.store_memory(
                content={
                    "user_message": user_message,
                    "bot_response": bot_response,
                    "user_id": context.user_id,
                    "chat_id": context.chat_id,
                    "timestamp": context.timestamp.isoformat()
                },
                memory_type="conversation",
                tags=["telegram", f"user:{context.user_id}"],
                metadata={
                    "platform": "telegram",
                    "message_type": context.message_type.value
                }
            )
        except Exception as e:
            logger.error(f"Failed to store conversation: {e}")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get handler statistics"""
        return {
            **self._stats,
            "routes_count": len(self._routes),
            "middlewares_count": len(self._middlewares)
        }


class ConversationState:
    """Track conversation state for multi-turn dialogues"""
    
    def __init__(self):
        self._states: Dict[int, Dict[str, Any]] = {}  # chat_id -> state
        self._lock = asyncio.Lock()
    
    async def get_state(self, chat_id: int) -> Dict[str, Any]:
        """Get state for chat"""
        async with self._lock:
            return self._states.get(chat_id, {})
    
    async def set_state(self, chat_id: int, key: str, value: Any) -> None:
        """Set state value"""
        async with self._lock:
            if chat_id not in self._states:
                self._states[chat_id] = {}
            self._states[chat_id][key] = value
    
    async def clear_state(self, chat_id: int) -> None:
        """Clear state for chat"""
        async with self._lock:
            if chat_id in self._states:
                del self._states[chat_id]
    
    async def get_current_handler(self, chat_id: int) -> Optional[str]:
        """Get current conversation handler"""
        state = await self.get_state(chat_id)
        return state.get("_handler")
    
    async def set_current_handler(self, chat_id: int, handler: Optional[str]) -> None:
        """Set current conversation handler"""
        await self.set_state(chat_id, "_handler", handler)


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

def create_message_handler(
    agent_loop: Optional[Any] = None,
    memory_manager: Optional[Any] = None
) -> MessageHandler:
    """Create configured message handler"""
    handler = MessageHandler(
        agent_loop=agent_loop,
        memory_manager=memory_manager
    )
    
    # Add logging middleware
    @handler.middleware()
    async def log_messages(context: MessageContext, text: str):
        logger.debug(
            f"Message from {context.username or context.user_id}: "
            f"{text[:50]}{'...' if len(text) > 50 else ''}"
        )
        return context, text
    
    return handler