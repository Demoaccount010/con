"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                         CONTEXT TRACKER                                       ║
║              Track and Maintain Conversation Context                          ║
╚══════════════════════════════════════════════════════════════════════════════╝

The Context Tracker maintains:
- Conversation history for context
- Entity tracking across turns
- Reference resolution (pronouns, "it", "that")
- Topic continuity
- User preferences in context
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Set, Tuple
from dataclasses import dataclass, field
from enum import Enum
from collections import deque
import re

logger = logging.getLogger(__name__)


class EntityType(Enum):
    """Types of entities to track"""
    FILE = "file"
    DIRECTORY = "directory"
    PROCESS = "process"
    SERVICE = "service"
    USER = "user"
    URL = "url"
    COMMAND = "command"
    VARIABLE = "variable"
    NUMBER = "number"
    DATE = "date"
    GENERIC = "generic"


class ReferenceType(Enum):
    """Types of references"""
    PRONOUN = "pronoun"       # it, they, he, she
    DEMONSTRATIVE = "demonstrative"  # this, that, these, those
    DEFINITE = "definite"     # the X (referring back)
    IMPLICIT = "implicit"     # assumed from context


@dataclass
class TrackedEntity:
    """An entity being tracked in context"""
    id: str
    type: EntityType
    value: Any
    name: Optional[str] = None
    
    # Tracking
    first_mentioned: datetime = field(default_factory=datetime.now)
    last_mentioned: datetime = field(default_factory=datetime.now)
    mention_count: int = 1
    
    # Context
    source_turn: Optional[str] = None
    attributes: Dict[str, Any] = field(default_factory=dict)
    
    # Salience
    salience: float = 1.0  # How prominent/recent
    
    def update_mention(self) -> None:
        """Update when entity is mentioned again"""
        self.last_mentioned = datetime.now()
        self.mention_count += 1
        self.salience = 1.0  # Reset salience


@dataclass
class ResolvedReference:
    """Result of reference resolution"""
    reference: str
    resolved_to: TrackedEntity
    reference_type: ReferenceType
    confidence: float
    alternatives: List[TrackedEntity] = field(default_factory=list)


@dataclass
class ConversationContext:
    """Context for a conversation"""
    conversation_id: str
    
    # Entities
    entities: Dict[str, TrackedEntity] = field(default_factory=dict)
    entity_stack: List[str] = field(default_factory=list)  # Most recent first
    
    # Topics
    current_topic: Optional[str] = None
    topic_history: List[str] = field(default_factory=list)
    
    # User info
    user_id: Optional[str] = None
    user_name: Optional[str] = None
    user_preferences: Dict[str, Any] = field(default_factory=dict)
    
    # Dialogue state
    pending_action: Optional[str] = None
    pending_confirmation: Optional[Dict] = None
    last_question: Optional[str] = None
    
    # History
    recent_intents: List[str] = field(default_factory=list)
    recent_commands: List[str] = field(default_factory=list)
    
    # Metadata
    created_at: datetime = field(default_factory=datetime.now)
    last_updated: datetime = field(default_factory=datetime.now)


@dataclass
class TrackerConfig:
    """Configuration for context tracker"""
    # Entity tracking
    max_entities: int = 50
    entity_decay_rate: float = 0.1  # Salience decay per turn
    min_salience_threshold: float = 0.1
    
    # History
    max_topic_history: int = 10
    max_recent_intents: int = 10
    max_recent_commands: int = 10
    
    # Reference resolution
    enable_reference_resolution: bool = True
    pronoun_resolution: bool = True
    demonstrative_resolution: bool = True
    
    # Persistence
    persist_context: bool = True
    context_ttl_hours: int = 24


class EntityExtractor:
    """Extract entities from text"""
    
    # Patterns for entity extraction
    PATTERNS = {
        EntityType.FILE: [
            r'(?:file\s+)?([\'"]?)([/~][\w/.-]+\.\w+)\1',
            r'(?:file\s+)?([\'"]?)([\w.-]+\.\w{2,4})\1'
        ],
        EntityType.DIRECTORY: [
            r'(?:directory|folder|dir)\s+([\'"]?)([/~][\w/.-]+)\1',
            r'([\'"]?)(/[\w/.-]+/)\1'
        ],
        EntityType.URL: [
            r'(https?://[^\s<>"{}|\\^`\[\]]+)'
        ],
        EntityType.PROCESS: [
            r'(?:process|pid)\s+(\d+)',
            r'(?:process\s+)?([a-z][\w-]*(?:\.exe)?)'
        ],
        EntityType.NUMBER: [
            r'\b(\d+(?:\.\d+)?)\b'
        ]
    }
    
    def __init__(self):
        self._compiled = {}
        for entity_type, patterns in self.PATTERNS.items():
            self._compiled[entity_type] = [
                re.compile(p, re.IGNORECASE) for p in patterns
            ]
    
    def extract(self, text: str) -> List[Tuple[EntityType, str]]:
        """Extract entities from text"""
        entities = []
        
        for entity_type, patterns in self._compiled.items():
            for pattern in patterns:
                matches = pattern.findall(text)
                for match in matches:
                    # Handle tuple matches (from groups)
                    if isinstance(match, tuple):
                        value = match[-1]  # Last group is usually the value
                    else:
                        value = match
                    
                    if value and len(value) > 1:
                        entities.append((entity_type, value))
        
        return entities


class ReferenceResolver:
    """Resolve references to entities"""
    
    # Pronoun patterns
    PRONOUNS = {
        'it': ['thing', 'file', 'process', 'service', 'command'],
        'they': ['things', 'files', 'processes', 'items'],
        'them': ['things', 'files', 'processes', 'items'],
        'this': ['thing', 'file', 'item', 'result'],
        'that': ['thing', 'file', 'item', 'result'],
        'these': ['things', 'files', 'items'],
        'those': ['things', 'files', 'items'],
        'he': ['user', 'person'],
        'she': ['user', 'person'],
        'here': ['directory', 'location', 'place'],
        'there': ['directory', 'location', 'place']
    }
    
    def __init__(self, config: Optional[TrackerConfig] = None):
        self.config = config or TrackerConfig()
    
    def find_references(self, text: str) -> List[Tuple[str, ReferenceType]]:
        """Find references in text"""
        references = []
        text_lower = text.lower()
        words = text_lower.split()
        
        for word in words:
            if word in self.PRONOUNS:
                references.append((word, ReferenceType.PRONOUN))
            elif word in ['the', 'that', 'this']:
                # Check for "the file", "that thing", etc.
                idx = words.index(word)
                if idx < len(words) - 1:
                    references.append((f"{word} {words[idx + 1]}", ReferenceType.DEFINITE))
        
        return references
    
    def resolve(
        self,
        reference: str,
        ref_type: ReferenceType,
        context: ConversationContext
    ) -> Optional[ResolvedReference]:
        """Resolve a reference to an entity"""
        if not context.entities:
            return None
        
        candidates = []
        ref_lower = reference.lower().split()[0]  # First word
        
        # Get relevant entity types for this reference
        relevant_types = self.PRONOUNS.get(ref_lower, [])
        
        for entity_id in context.entity_stack:
            if entity_id not in context.entities:
                continue
            
            entity = context.entities[entity_id]
            
            # Skip low salience
            if entity.salience < self.config.min_salience_threshold:
                continue
            
            # Score based on recency and type match
            score = entity.salience
            
            # Type matching
            type_matches = any(
                t in entity.type.value or t in (entity.name or '').lower()
                for t in relevant_types
            )
            if type_matches:
                score += 0.3
            
            candidates.append((score, entity))
        
        if not candidates:
            return None
        
        # Sort by score
        candidates.sort(key=lambda x: x[0], reverse=True)
        
        best_score, best_entity = candidates[0]
        
        return ResolvedReference(
            reference=reference,
            resolved_to=best_entity,
            reference_type=ref_type,
            confidence=min(best_score, 1.0),
            alternatives=[e for _, e in candidates[1:3]]
        )


class ContextTracker:
    """
    Track and maintain conversation context
    
    Features:
    - Entity tracking across turns
    - Reference resolution
    - Topic continuity
    - Context persistence
    """
    
    def __init__(
        self,
        config: Optional[TrackerConfig] = None,
        memory_manager: Optional[Any] = None
    ):
        self.config = config or TrackerConfig()
        self.memory_manager = memory_manager
        
        # Components
        self._entity_extractor = EntityExtractor()
        self._reference_resolver = ReferenceResolver(config)
        
        # Contexts
        self._contexts: Dict[str, ConversationContext] = {}
        
        # Statistics
        self._stats = {
            "entities_tracked": 0,
            "references_resolved": 0,
            "contexts_created": 0
        }
        
        logger.info("ContextTracker initialized")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CONTEXT LIFECYCLE
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def start_conversation(
        self,
        conversation_id: str,
        user_id: Optional[str] = None
    ) -> ConversationContext:
        """Start tracking context for conversation"""
        # Check for existing
        if conversation_id in self._contexts:
            return self._contexts[conversation_id]
        
        # Load from memory if available
        if self.config.persist_context and self.memory_manager and user_id:
            loaded = await self._load_context(user_id)
            if loaded:
                loaded.conversation_id = conversation_id
                self._contexts[conversation_id] = loaded
                return loaded
        
        # Create new
        context = ConversationContext(
            conversation_id=conversation_id,
            user_id=user_id
        )
        
        self._contexts[conversation_id] = context
        self._stats["contexts_created"] += 1
        
        return context
    
    async def end_conversation(self, conversation_id: str) -> None:
        """End context tracking for conversation"""
        if conversation_id not in self._contexts:
            return
        
        context = self._contexts[conversation_id]
        
        # Persist if configured
        if self.config.persist_context and self.memory_manager:
            await self._save_context(context)
        
        # Keep context for a while (don't delete immediately)
        context.last_updated = datetime.now()
    
    async def get_context(
        self,
        conversation_id: str
    ) -> Optional[ConversationContext]:
        """Get context for conversation"""
        return self._contexts.get(conversation_id)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CONTEXT UPDATES
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def update(
        self,
        conversation_id: str,
        turn: Any  # Turn object from dialogue_manager
    ) -> None:
        """Update context with new turn"""
        if conversation_id not in self._contexts:
            await self.start_conversation(conversation_id)
        
        context = self._contexts[conversation_id]
        context.last_updated = datetime.now()
        
        # Decay existing entity salience
        self._decay_salience(context)
        
        # Extract and track entities
        if turn.type.value == "user":
            entities = self._entity_extractor.extract(turn.content)
            for entity_type, value in entities:
                await self._track_entity(context, entity_type, value, turn.id)
        
        # Update intents
        if turn.intent:
            context.recent_intents.append(turn.intent.value)
            if len(context.recent_intents) > self.config.max_recent_intents:
                context.recent_intents = context.recent_intents[-self.config.max_recent_intents:]
        
        # Update commands
        if turn.intent and turn.intent.value == "command":
            context.recent_commands.append(turn.content)
            if len(context.recent_commands) > self.config.max_recent_commands:
                context.recent_commands = context.recent_commands[-self.config.max_recent_commands:]
    
    async def _track_entity(
        self,
        context: ConversationContext,
        entity_type: EntityType,
        value: Any,
        source_turn: str
    ) -> TrackedEntity:
        """Track an entity in context"""
        # Generate entity ID
        entity_id = f"{entity_type.value}:{hash(str(value)) % 10000}"
        
        if entity_id in context.entities:
            # Update existing
            entity = context.entities[entity_id]
            entity.update_mention()
        else:
            # Create new
            entity = TrackedEntity(
                id=entity_id,
                type=entity_type,
                value=value,
                source_turn=source_turn
            )
            context.entities[entity_id] = entity
            self._stats["entities_tracked"] += 1
        
        # Update stack (move to front)
        if entity_id in context.entity_stack:
            context.entity_stack.remove(entity_id)
        context.entity_stack.insert(0, entity_id)
        
        # Limit entities
        if len(context.entities) > self.config.max_entities:
            await self._cleanup_entities(context)
        
        return entity
    
    def _decay_salience(self, context: ConversationContext) -> None:
        """Decay salience of all entities"""
        for entity in context.entities.values():
            entity.salience *= (1 - self.config.entity_decay_rate)
    
    async def _cleanup_entities(self, context: ConversationContext) -> None:
        """Remove low-salience entities"""
        to_remove = []
        
        for entity_id, entity in context.entities.items():
            if entity.salience < self.config.min_salience_threshold:
                to_remove.append(entity_id)
        
        for entity_id in to_remove:
            del context.entities[entity_id]
            if entity_id in context.entity_stack:
                context.entity_stack.remove(entity_id)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # REFERENCE RESOLUTION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def resolve_references(
        self,
        text: str,
        conversation_id: str
    ) -> Dict[str, ResolvedReference]:
        """Resolve references in text"""
        if not self.config.enable_reference_resolution:
            return {}
        
        context = self._contexts.get(conversation_id)
        if not context:
            return {}
        
        # Find references
        references = self._reference_resolver.find_references(text)
        
        resolved = {}
        for ref, ref_type in references:
            result = self._reference_resolver.resolve(ref, ref_type, context)
            if result:
                resolved[ref] = result
                self._stats["references_resolved"] += 1
        
        return resolved
    
    async def get_referent(
        self,
        reference: str,
        conversation_id: str
    ) -> Optional[Any]:
        """Get what a reference refers to"""
        resolved = await self.resolve_references(reference, conversation_id)
        
        if reference.lower() in resolved:
            return resolved[reference.lower()].resolved_to.value
        
        return None
    
    async def get_last_entity(
        self,
        conversation_id: str,
        entity_type: Optional[EntityType] = None
    ) -> Optional[TrackedEntity]:
        """Get most recent entity"""
        context = self._contexts.get(conversation_id)
        if not context or not context.entity_stack:
            return None
        
        for entity_id in context.entity_stack:
            entity = context.entities.get(entity_id)
            if entity:
                if entity_type is None or entity.type == entity_type:
                    return entity
        
        return None
    
    # ═══════════════════════════════════════════════════════════════════════════
    # TOPIC TRACKING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def set_topic(
        self,
        conversation_id: str,
        topic: str
    ) -> None:
        """Set current topic"""
        context = self._contexts.get(conversation_id)
        if not context:
            return
        
        if context.current_topic != topic:
            if context.current_topic:
                context.topic_history.append(context.current_topic)
                if len(context.topic_history) > self.config.max_topic_history:
                    context.topic_history = context.topic_history[-self.config.max_topic_history:]
            
            context.current_topic = topic
    
    async def get_topic_history(
        self,
        conversation_id: str
    ) -> List[str]:
        """Get topic history"""
        context = self._contexts.get(conversation_id)
        if not context:
            return []
        
        history = context.topic_history.copy()
        if context.current_topic:
            history.append(context.current_topic)
        
        return history
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PENDING STATE
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def set_pending_action(
        self,
        conversation_id: str,
        action: str,
        details: Optional[Dict] = None
    ) -> None:
        """Set pending action awaiting confirmation"""
        context = self._contexts.get(conversation_id)
        if context:
            context.pending_action = action
            context.pending_confirmation = details
    
    async def get_pending_action(
        self,
        conversation_id: str
    ) -> Optional[Tuple[str, Optional[Dict]]]:
        """Get pending action"""
        context = self._contexts.get(conversation_id)
        if context and context.pending_action:
            return context.pending_action, context.pending_confirmation
        return None
    
    async def clear_pending_action(
        self,
        conversation_id: str
    ) -> None:
        """Clear pending action"""
        context = self._contexts.get(conversation_id)
        if context:
            context.pending_action = None
            context.pending_confirmation = None
    
    async def set_last_question(
        self,
        conversation_id: str,
        question: str
    ) -> None:
        """Set last question asked"""
        context = self._contexts.get(conversation_id)
        if context:
            context.last_question = question
    
    async def get_last_question(
        self,
        conversation_id: str
    ) -> Optional[str]:
        """Get last question asked"""
        context = self._contexts.get(conversation_id)
        return context.last_question if context else None
    
    # ═══════════════════════════════════════════════════════════════════════════
    # USER PREFERENCES
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def set_preference(
        self,
        conversation_id: str,
        key: str,
        value: Any
    ) -> None:
        """Set user preference in context"""
        context = self._contexts.get(conversation_id)
        if context:
            context.user_preferences[key] = value
    
    async def get_preference(
        self,
        conversation_id: str,
        key: str,
        default: Any = None
    ) -> Any:
        """Get user preference from context"""
        context = self._contexts.get(conversation_id)
        if context:
            return context.user_preferences.get(key, default)
        return default
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CONTEXT EXPORT
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def get_context_summary(
        self,
        conversation_id: str
    ) -> Dict[str, Any]:
        """Get summary of context for prompts"""
        context = self._contexts.get(conversation_id)
        if not context:
            return {}
        
        # Get recent entities
        recent_entities = []
        for entity_id in context.entity_stack[:5]:
            entity = context.entities.get(entity_id)
            if entity:
                recent_entities.append({
                    "type": entity.type.value,
                    "value": entity.value,
                    "name": entity.name
                })
        
        return {
            "current_topic": context.current_topic,
            "recent_topics": context.topic_history[-3:],
            "recent_entities": recent_entities,
            "pending_action": context.pending_action,
            "last_question": context.last_question,
            "user_name": context.user_name,
            "preferences": context.user_preferences,
            "recent_intents": context.recent_intents[-3:]
        }
    
    async def build_context_string(
        self,
        conversation_id: str
    ) -> str:
        """Build context string for LLM prompts"""
        summary = await self.get_context_summary(conversation_id)
        
        if not summary:
            return ""
        
        lines = ["[CONTEXT]"]
        
        if summary.get("user_name"):
            lines.append(f"User: {summary['user_name']}")
        
        if summary.get("current_topic"):
            lines.append(f"Topic: {summary['current_topic']}")
        
        if summary.get("recent_entities"):
            entities_str = ", ".join([
                f"{e['type']}:{e['value']}" 
                for e in summary['recent_entities'][:3]
            ])
            lines.append(f"Recent entities: {entities_str}")
        
        if summary.get("pending_action"):
            lines.append(f"Pending: {summary['pending_action']}")
        
        if summary.get("last_question"):
            lines.append(f"Last question: {summary['last_question']}")
        
        lines.append("[/CONTEXT]")
        
        return "\n".join(lines)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PERSISTENCE
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _save_context(self, context: ConversationContext) -> None:
        """Save context to memory"""
        if not self.memory_manager or not context.user_id:
            return
        
        try:
            await self.memory_manager.store_memory(
                content={
                    "user_id": context.user_id,
                    "user_name": context.user_name,
                    "preferences": context.user_preferences,
                    "recent_topics": context.topic_history[-5:],
                    "recent_intents": context.recent_intents[-5:]
                },
                memory_type="episode",
                tags=["context", f"user:{context.user_id}"],
                metadata={
                    "saved_at": datetime.now().isoformat()
                }
            )
        except Exception as e:
            logger.error(f"Failed to save context: {e}")
    
    async def _load_context(self, user_id: str) -> Optional[ConversationContext]:
        """Load context from memory"""
        if not self.memory_manager:
            return None
        
        try:
            memories = await self.memory_manager.search_memories(
                query=f"user:{user_id}",
                memory_type="episode",
                limit=1
            )
            
            if memories:
                content = memories[0].get("content", {})
                
                context = ConversationContext(
                    conversation_id="",  # Will be set
                    user_id=user_id,
                    user_name=content.get("user_name"),
                    user_preferences=content.get("preferences", {}),
                    topic_history=content.get("recent_topics", []),
                    recent_intents=content.get("recent_intents", [])
                )
                
                return context
        
        except Exception as e:
            logger.error(f"Failed to load context: {e}")
        
        return None
    
    def get_stats(self) -> Dict[str, Any]:
        """Get tracker statistics"""
        return {
            **self._stats,
            "active_contexts": len(self._contexts)
        }


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

async def create_context_tracker(
    memory_manager: Optional[Any] = None,
    **kwargs
) -> ContextTracker:
    """Create configured context tracker"""
    config = TrackerConfig(**kwargs)
    
    tracker = ContextTracker(
        config=config,
        memory_manager=memory_manager
    )
    
    return tracker