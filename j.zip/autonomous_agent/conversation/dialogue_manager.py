"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                         DIALOGUE MANAGER                                      ║
║              Central Manager for Conversation Flow and State                  ║
╚══════════════════════════════════════════════════════════════════════════════╝

The Dialogue Manager handles:
- Conversation flow and turn-taking
- Dialogue state management
- Multi-turn conversation handling
- Intent tracking across turns
- Topic management
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Tuple, Callable, Awaitable
from dataclasses import dataclass, field
from enum import Enum
from collections import deque
import hashlib
import re

logger = logging.getLogger(__name__)


class DialogueState(Enum):
    """States of dialogue"""
    IDLE = "idle"                     # No active conversation
    GREETING = "greeting"             # Initial greeting
    LISTENING = "listening"           # Waiting for user input
    PROCESSING = "processing"         # Processing user input
    RESPONDING = "responding"         # Generating response
    CLARIFYING = "clarifying"         # Asking for clarification
    CONFIRMING = "confirming"         # Waiting for confirmation
    EXECUTING = "executing"           # Executing a task
    TEACHING = "teaching"             # User is teaching
    LEARNING = "learning"             # Agent is learning
    ENDING = "ending"                 # Conversation ending


class TurnType(Enum):
    """Types of conversation turns"""
    USER = "user"
    AGENT = "agent"
    SYSTEM = "system"


class IntentCategory(Enum):
    """Categories of user intent"""
    COMMAND = "command"               # Execute something
    QUESTION = "question"             # Ask for information
    STATEMENT = "statement"           # Provide information
    GREETING = "greeting"             # Hello/Goodbye
    FEEDBACK = "feedback"             # Positive/negative feedback
    CORRECTION = "correction"         # Correct the agent
    CONFIRMATION = "confirmation"     # Yes/No response
    CLARIFICATION = "clarification"   # Clarify something
    TEACHING = "teaching"             # Teach the agent
    CHITCHAT = "chitchat"             # Small talk
    UNKNOWN = "unknown"


@dataclass
class Turn:
    """A single turn in conversation"""
    id: str
    type: TurnType
    content: str
    timestamp: datetime = field(default_factory=datetime.now)
    
    # Intent
    intent: Optional[IntentCategory] = None
    intent_confidence: float = 0.0
    
    # Entities
    entities: Dict[str, Any] = field(default_factory=dict)
    
    # Response info (for agent turns)
    response_time_ms: float = 0.0
    tool_used: Optional[str] = None
    
    # Metadata
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Topic:
    """A conversation topic"""
    name: str
    started_at: datetime = field(default_factory=datetime.now)
    turn_count: int = 0
    is_active: bool = True
    entities: Dict[str, Any] = field(default_factory=dict)
    subtopics: List[str] = field(default_factory=list)


@dataclass
class Conversation:
    """A conversation session"""
    id: str
    started_at: datetime = field(default_factory=datetime.now)
    ended_at: Optional[datetime] = None
    
    # State
    state: DialogueState = DialogueState.IDLE
    
    # Participants
    user_id: Optional[str] = None
    user_name: Optional[str] = None
    
    # Turns
    turns: List[Turn] = field(default_factory=list)
    
    # Topics
    topics: List[Topic] = field(default_factory=list)
    current_topic: Optional[str] = None
    
    # Context
    context: Dict[str, Any] = field(default_factory=dict)
    
    # Tracking
    last_activity: datetime = field(default_factory=datetime.now)
    total_user_turns: int = 0
    total_agent_turns: int = 0
    
    @property
    def is_active(self) -> bool:
        return self.ended_at is None
    
    @property
    def duration(self) -> timedelta:
        end = self.ended_at or datetime.now()
        return end - self.started_at
    
    @property
    def turn_count(self) -> int:
        return len(self.turns)


@dataclass
class DialogueConfig:
    """Configuration for dialogue manager"""
    # Timeouts
    idle_timeout_minutes: int = 30
    turn_timeout_seconds: int = 60
    
    # History
    max_turns_in_memory: int = 100
    max_conversations: int = 50
    
    # Behavior
    greet_on_start: bool = True
    farewell_on_end: bool = True
    acknowledge_long_absence: bool = True
    long_absence_hours: int = 24
    
    # Topic management
    auto_detect_topics: bool = True
    max_topics_tracked: int = 10
    
    # Intent detection
    detect_intent: bool = True
    min_intent_confidence: float = 0.5


class IntentDetector:
    """Detect user intent from message"""
    
    # Intent patterns
    PATTERNS = {
        IntentCategory.GREETING: [
            r'^(hi|hello|hey|greetings|good\s*(morning|afternoon|evening))[\s!.]*$',
            r'^(bye|goodbye|see\s*you|later|good\s*night)[\s!.]*$'
        ],
        IntentCategory.QUESTION: [
            r'^(what|why|how|when|where|who|which|can|could|would|is|are|do|does|did)\s',
            r'\?$'
        ],
        IntentCategory.COMMAND: [
            r'^(run|execute|do|make|create|delete|remove|show|list|find|search|get|set|start|stop)\s',
            r'^(please\s+)?(can you|could you|would you)\s',
        ],
        IntentCategory.CONFIRMATION: [
            r'^(yes|yeah|yep|yup|sure|ok|okay|confirm|go ahead|do it)[\s!.]*$',
            r'^(no|nope|nah|cancel|stop|abort|never)[\s!.]*$'
        ],
        IntentCategory.FEEDBACK: [
            r'^(great|good|nice|awesome|thanks|thank you|perfect|excellent)[\s!.]*$',
            r'^(bad|wrong|incorrect|not right|terrible)[\s!.]*$'
        ],
        IntentCategory.CORRECTION: [
            r"(no,?\s*)?(it'?s|that'?s|should be|actually|i meant)",
            r'(not\s+.+,?\s+but\s+|instead of)'
        ],
        IntentCategory.TEACHING: [
            r'^(let me|i\'ll)\s+(teach|tell|show|explain)',
            r'^(remember|note|learn)\s+that',
            r'(is called|means|refers to)'
        ]
    }
    
    def __init__(self):
        self._compiled_patterns = {}
        for intent, patterns in self.PATTERNS.items():
            self._compiled_patterns[intent] = [
                re.compile(p, re.IGNORECASE) for p in patterns
            ]
    
    def detect(self, text: str) -> Tuple[IntentCategory, float]:
        """Detect intent from text"""
        text = text.strip()
        
        if not text:
            return IntentCategory.UNKNOWN, 0.0
        
        # Check patterns
        for intent, patterns in self._compiled_patterns.items():
            for pattern in patterns:
                if pattern.search(text):
                    confidence = 0.8 if intent in [
                        IntentCategory.GREETING,
                        IntentCategory.CONFIRMATION,
                        IntentCategory.FEEDBACK
                    ] else 0.7
                    return intent, confidence
        
        # Default classification
        if len(text) < 20:
            return IntentCategory.CHITCHAT, 0.5
        
        return IntentCategory.STATEMENT, 0.5


class TopicDetector:
    """Detect and track conversation topics"""
    
    # Topic keywords
    TOPIC_KEYWORDS = {
        "file": ["file", "folder", "directory", "path", "save", "load", "read", "write"],
        "system": ["process", "service", "memory", "cpu", "disk", "system"],
        "network": ["http", "api", "request", "download", "url", "server"],
        "code": ["code", "function", "class", "program", "script", "python"],
        "database": ["database", "sql", "query", "table", "record"],
        "docker": ["docker", "container", "image", "compose"],
        "git": ["git", "commit", "branch", "merge", "push", "pull"],
        "learning": ["learn", "teach", "remember", "know", "understand"],
        "help": ["help", "assist", "support", "guide", "how to"]
    }
    
    def detect(self, text: str) -> List[str]:
        """Detect topics in text"""
        text_lower = text.lower()
        detected = []
        
        for topic, keywords in self.TOPIC_KEYWORDS.items():
            for keyword in keywords:
                if keyword in text_lower:
                    detected.append(topic)
                    break
        
        return detected


class DialogueManager:
    """
    Central manager for conversation handling
    
    Features:
    - Conversation state management
    - Turn-taking and flow control
    - Multi-turn dialogue handling
    - Intent and topic tracking
    - Context maintenance
    """
    
    def __init__(
        self,
        config: Optional[DialogueConfig] = None,
        context_tracker: Optional[Any] = None,
        response_generator: Optional[Any] = None,
        memory_manager: Optional[Any] = None
    ):
        self.config = config or DialogueConfig()
        self.context_tracker = context_tracker
        self.response_generator = response_generator
        self.memory_manager = memory_manager
        
        # Components
        self._intent_detector = IntentDetector()
        self._topic_detector = TopicDetector()
        
        # Conversations
        self._conversations: Dict[str, Conversation] = {}
        self._active_conversation: Optional[str] = None
        
        # Callbacks
        self._on_state_change: List[Callable] = []
        self._on_topic_change: List[Callable] = []
        
        # Statistics
        self._stats = {
            "total_conversations": 0,
            "total_turns": 0,
            "total_user_turns": 0,
            "total_agent_turns": 0,
            "avg_turns_per_conversation": 0.0
        }
        
        logger.info("DialogueManager initialized")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CONVERSATION LIFECYCLE
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def start_conversation(
        self,
        user_id: Optional[str] = None,
        user_name: Optional[str] = None,
        context: Optional[Dict] = None
    ) -> Conversation:
        """Start a new conversation"""
        # Check for existing active conversation with user
        if user_id:
            for conv in self._conversations.values():
                if conv.user_id == user_id and conv.is_active:
                    return await self.resume_conversation(conv.id)
        
        # Create new conversation
        conv_id = f"conv_{datetime.now().timestamp()}"
        
        conversation = Conversation(
            id=conv_id,
            user_id=user_id,
            user_name=user_name,
            state=DialogueState.GREETING if self.config.greet_on_start else DialogueState.LISTENING,
            context=context or {}
        )
        
        self._conversations[conv_id] = conversation
        self._active_conversation = conv_id
        self._stats["total_conversations"] += 1
        
        # Update context tracker
        if self.context_tracker:
            await self.context_tracker.start_conversation(conv_id, user_id)
        
        # Check for long absence
        if self.config.acknowledge_long_absence and user_id:
            last_seen = await self._get_last_seen(user_id)
            if last_seen:
                hours_since = (datetime.now() - last_seen).total_seconds() / 3600
                if hours_since >= self.config.long_absence_hours:
                    conversation.context["long_absence"] = True
                    conversation.context["hours_since"] = int(hours_since)
        
        logger.info(f"Started conversation: {conv_id}")
        
        # Cleanup old conversations
        await self._cleanup_old_conversations()
        
        return conversation
    
    async def resume_conversation(self, conv_id: str) -> Optional[Conversation]:
        """Resume an existing conversation"""
        if conv_id not in self._conversations:
            return None
        
        conversation = self._conversations[conv_id]
        
        if not conversation.is_active:
            # Reactivate ended conversation
            conversation.ended_at = None
        
        conversation.last_activity = datetime.now()
        self._active_conversation = conv_id
        
        # Update state
        if conversation.state == DialogueState.IDLE:
            conversation.state = DialogueState.LISTENING
        
        logger.info(f"Resumed conversation: {conv_id}")
        return conversation
    
    async def end_conversation(
        self,
        conv_id: Optional[str] = None,
        reason: str = "user_ended"
    ) -> bool:
        """End a conversation"""
        conv_id = conv_id or self._active_conversation
        
        if not conv_id or conv_id not in self._conversations:
            return False
        
        conversation = self._conversations[conv_id]
        conversation.ended_at = datetime.now()
        conversation.state = DialogueState.ENDING
        conversation.context["end_reason"] = reason
        
        if self._active_conversation == conv_id:
            self._active_conversation = None
        
        # Update context tracker
        if self.context_tracker:
            await self.context_tracker.end_conversation(conv_id)
        
        # Store in memory
        if self.memory_manager:
            await self._store_conversation(conversation)
        
        # Update stats
        self._update_stats(conversation)
        
        logger.info(f"Ended conversation: {conv_id} (reason: {reason})")
        return True
    
    async def _cleanup_old_conversations(self) -> int:
        """Clean up old/idle conversations"""
        cleaned = 0
        now = datetime.now()
        
        to_remove = []
        for conv_id, conv in self._conversations.items():
            # End idle conversations
            if conv.is_active:
                idle_time = (now - conv.last_activity).total_seconds() / 60
                if idle_time > self.config.idle_timeout_minutes:
                    await self.end_conversation(conv_id, reason="timeout")
                    cleaned += 1
            
            # Remove very old ended conversations
            if not conv.is_active and len(self._conversations) > self.config.max_conversations:
                to_remove.append(conv_id)
        
        for conv_id in to_remove:
            del self._conversations[conv_id]
            cleaned += 1
        
        return cleaned
    
    # ═══════════════════════════════════════════════════════════════════════════
    # TURN HANDLING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def process_user_turn(
        self,
        content: str,
        conv_id: Optional[str] = None,
        metadata: Optional[Dict] = None
    ) -> Turn:
        """Process a user turn"""
        conv_id = conv_id or self._active_conversation
        
        if not conv_id:
            # Start new conversation
            conv = await self.start_conversation()
            conv_id = conv.id
        
        conversation = self._conversations.get(conv_id)
        if not conversation:
            raise ValueError(f"Conversation not found: {conv_id}")
        
        # Update state
        conversation.state = DialogueState.PROCESSING
        conversation.last_activity = datetime.now()
        
        # Detect intent
        intent, confidence = IntentCategory.UNKNOWN, 0.0
        if self.config.detect_intent:
            intent, confidence = self._intent_detector.detect(content)
        
        # Create turn
        turn = Turn(
            id=f"turn_{len(conversation.turns) + 1}",
            type=TurnType.USER,
            content=content,
            intent=intent,
            intent_confidence=confidence,
            metadata=metadata or {}
        )
        
        # Detect topics
        if self.config.auto_detect_topics:
            topics = self._topic_detector.detect(content)
            for topic_name in topics:
                await self._add_topic(conversation, topic_name)
        
        # Add turn
        conversation.turns.append(turn)
        conversation.total_user_turns += 1
        self._stats["total_turns"] += 1
        self._stats["total_user_turns"] += 1
        
        # Trim history if needed
        if len(conversation.turns) > self.config.max_turns_in_memory:
            conversation.turns = conversation.turns[-self.config.max_turns_in_memory:]
        
        # Update context
        if self.context_tracker:
            await self.context_tracker.update(conv_id, turn)
        
        # Update state based on intent
        await self._update_state_for_intent(conversation, intent)
        
        return turn
    
    async def add_agent_turn(
        self,
        content: str,
        conv_id: Optional[str] = None,
        response_time_ms: float = 0.0,
        tool_used: Optional[str] = None,
        metadata: Optional[Dict] = None
    ) -> Turn:
        """Add an agent response turn"""
        conv_id = conv_id or self._active_conversation
        
        if not conv_id or conv_id not in self._conversations:
            raise ValueError(f"No active conversation: {conv_id}")
        
        conversation = self._conversations[conv_id]
        
        # Create turn
        turn = Turn(
            id=f"turn_{len(conversation.turns) + 1}",
            type=TurnType.AGENT,
            content=content,
            response_time_ms=response_time_ms,
            tool_used=tool_used,
            metadata=metadata or {}
        )
        
        # Add turn
        conversation.turns.append(turn)
        conversation.total_agent_turns += 1
        self._stats["total_turns"] += 1
        self._stats["total_agent_turns"] += 1
        
        # Update state
        conversation.state = DialogueState.LISTENING
        conversation.last_activity = datetime.now()
        
        # Update context
        if self.context_tracker:
            await self.context_tracker.update(conv_id, turn)
        
        return turn
    
    async def _update_state_for_intent(
        self,
        conversation: Conversation,
        intent: IntentCategory
    ) -> None:
        """Update dialogue state based on detected intent"""
        old_state = conversation.state
        
        if intent == IntentCategory.GREETING:
            # Check if it's a farewell
            last_content = conversation.turns[-1].content.lower() if conversation.turns else ""
            if any(word in last_content for word in ['bye', 'goodbye', 'later', 'night']):
                conversation.state = DialogueState.ENDING
            else:
                conversation.state = DialogueState.GREETING
        
        elif intent == IntentCategory.CONFIRMATION:
            # If we were confirming, now we're executing
            if old_state == DialogueState.CONFIRMING:
                conversation.state = DialogueState.EXECUTING
            else:
                conversation.state = DialogueState.LISTENING
        
        elif intent == IntentCategory.CLARIFICATION:
            conversation.state = DialogueState.CLARIFYING
        
        elif intent == IntentCategory.TEACHING:
            conversation.state = DialogueState.TEACHING
        
        elif intent == IntentCategory.COMMAND:
            conversation.state = DialogueState.EXECUTING
        
        else:
            conversation.state = DialogueState.RESPONDING
        
        # Trigger state change callback
        if old_state != conversation.state:
            for callback in self._on_state_change:
                try:
                    await callback(conversation, old_state, conversation.state)
                except Exception as e:
                    logger.error(f"State change callback error: {e}")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # TOPIC MANAGEMENT
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _add_topic(
        self,
        conversation: Conversation,
        topic_name: str
    ) -> Topic:
        """Add or update topic in conversation"""
        # Check if topic already exists
        for topic in conversation.topics:
            if topic.name == topic_name:
                topic.turn_count += 1
                topic.is_active = True
                return topic
        
        # Create new topic
        topic = Topic(name=topic_name)
        conversation.topics.append(topic)
        
        # Limit topics
        if len(conversation.topics) > self.config.max_topics_tracked:
            # Remove oldest inactive topic
            inactive = [t for t in conversation.topics if not t.is_active]
            if inactive:
                conversation.topics.remove(inactive[0])
        
        # Update current topic
        old_topic = conversation.current_topic
        conversation.current_topic = topic_name
        
        # Trigger topic change callback
        if old_topic != topic_name:
            for callback in self._on_topic_change:
                try:
                    await callback(conversation, old_topic, topic_name)
                except Exception as e:
                    logger.error(f"Topic change callback error: {e}")
        
        return topic
    
    async def set_topic(
        self,
        topic_name: str,
        conv_id: Optional[str] = None
    ) -> bool:
        """Manually set current topic"""
        conv_id = conv_id or self._active_conversation
        
        if not conv_id or conv_id not in self._conversations:
            return False
        
        conversation = self._conversations[conv_id]
        await self._add_topic(conversation, topic_name)
        
        return True
    
    async def get_current_topic(
        self,
        conv_id: Optional[str] = None
    ) -> Optional[str]:
        """Get current conversation topic"""
        conv_id = conv_id or self._active_conversation
        
        if not conv_id or conv_id not in self._conversations:
            return None
        
        return self._conversations[conv_id].current_topic
    
    # ═══════════════════════════════════════════════════════════════════════════
    # STATE MANAGEMENT
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def set_state(
        self,
        state: DialogueState,
        conv_id: Optional[str] = None
    ) -> bool:
        """Manually set dialogue state"""
        conv_id = conv_id or self._active_conversation
        
        if not conv_id or conv_id not in self._conversations:
            return False
        
        old_state = self._conversations[conv_id].state
        self._conversations[conv_id].state = state
        
        # Trigger callbacks
        for callback in self._on_state_change:
            try:
                await callback(self._conversations[conv_id], old_state, state)
            except Exception as e:
                logger.error(f"State change callback error: {e}")
        
        return True
    
    async def get_state(
        self,
        conv_id: Optional[str] = None
    ) -> Optional[DialogueState]:
        """Get current dialogue state"""
        conv_id = conv_id or self._active_conversation
        
        if not conv_id or conv_id not in self._conversations:
            return None
        
        return self._conversations[conv_id].state
    
    async def is_confirming(self, conv_id: Optional[str] = None) -> bool:
        """Check if waiting for confirmation"""
        state = await self.get_state(conv_id)
        return state == DialogueState.CONFIRMING
    
    async def request_confirmation(
        self,
        conv_id: Optional[str] = None
    ) -> bool:
        """Set state to awaiting confirmation"""
        return await self.set_state(DialogueState.CONFIRMING, conv_id)
    
    async def request_clarification(
        self,
        conv_id: Optional[str] = None
    ) -> bool:
        """Set state to awaiting clarification"""
        return await self.set_state(DialogueState.CLARIFYING, conv_id)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # HISTORY AND CONTEXT
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def get_recent_turns(
        self,
        count: int = 10,
        conv_id: Optional[str] = None
    ) -> List[Turn]:
        """Get recent turns from conversation"""
        conv_id = conv_id or self._active_conversation
        
        if not conv_id or conv_id not in self._conversations:
            return []
        
        turns = self._conversations[conv_id].turns
        return turns[-count:] if len(turns) > count else turns
    
    async def get_last_user_turn(
        self,
        conv_id: Optional[str] = None
    ) -> Optional[Turn]:
        """Get last user turn"""
        conv_id = conv_id or self._active_conversation
        
        if not conv_id or conv_id not in self._conversations:
            return None
        
        for turn in reversed(self._conversations[conv_id].turns):
            if turn.type == TurnType.USER:
                return turn
        
        return None
    
    async def get_last_agent_turn(
        self,
        conv_id: Optional[str] = None
    ) -> Optional[Turn]:
        """Get last agent turn"""
        conv_id = conv_id or self._active_conversation
        
        if not conv_id or conv_id not in self._conversations:
            return None
        
        for turn in reversed(self._conversations[conv_id].turns):
            if turn.type == TurnType.AGENT:
                return turn
        
        return None
    
    async def get_conversation_context(
        self,
        conv_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """Get full conversation context"""
        conv_id = conv_id or self._active_conversation
        
        if not conv_id or conv_id not in self._conversations:
            return {}
        
        conversation = self._conversations[conv_id]
        
        return {
            "conversation_id": conversation.id,
            "state": conversation.state.value,
            "current_topic": conversation.current_topic,
            "topics": [t.name for t in conversation.topics if t.is_active],
            "turn_count": conversation.turn_count,
            "user_id": conversation.user_id,
            "user_name": conversation.user_name,
            "duration_seconds": conversation.duration.total_seconds(),
            "custom_context": conversation.context
        }
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CALLBACKS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def on_state_change(
        self,
        callback: Callable[[Conversation, DialogueState, DialogueState], Awaitable[None]]
    ) -> None:
        """Register state change callback"""
        self._on_state_change.append(callback)
    
    def on_topic_change(
        self,
        callback: Callable[[Conversation, Optional[str], str], Awaitable[None]]
    ) -> None:
        """Register topic change callback"""
        self._on_topic_change.append(callback)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MEMORY INTEGRATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _store_conversation(self, conversation: Conversation) -> None:
        """Store conversation in memory"""
        if not self.memory_manager:
            return
        
        try:
            # Store summary
            await self.memory_manager.store_memory(
                content={
                    "conversation_id": conversation.id,
                    "user_id": conversation.user_id,
                    "user_name": conversation.user_name,
                    "started_at": conversation.started_at.isoformat(),
                    "ended_at": conversation.ended_at.isoformat() if conversation.ended_at else None,
                    "turn_count": conversation.turn_count,
                    "topics": [t.name for t in conversation.topics],
                    "end_reason": conversation.context.get("end_reason")
                },
                memory_type="episode",
                tags=["conversation"],
                metadata={
                    "duration_seconds": conversation.duration.total_seconds()
                }
            )
        except Exception as e:
            logger.error(f"Failed to store conversation: {e}")
    
    async def _get_last_seen(self, user_id: str) -> Optional[datetime]:
        """Get when user was last seen"""
        if not self.memory_manager:
            return None
        
        try:
            memories = await self.memory_manager.search_memories(
                query=f"user_id:{user_id}",
                memory_type="episode",
                limit=1
            )
            
            if memories:
                ended_at = memories[0].get("content", {}).get("ended_at")
                if ended_at:
                    return datetime.fromisoformat(ended_at)
        except Exception:
            pass
        
        return None
    
    # ═══════════════════════════════════════════════════════════════════════════
    # UTILITIES
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _update_stats(self, conversation: Conversation) -> None:
        """Update statistics"""
        total = self._stats["total_conversations"]
        if total > 0:
            current_avg = self._stats["avg_turns_per_conversation"]
            new_avg = ((current_avg * (total - 1)) + conversation.turn_count) / total
            self._stats["avg_turns_per_conversation"] = new_avg
    
    async def get_active_conversation(self) -> Optional[Conversation]:
        """Get currently active conversation"""
        if not self._active_conversation:
            return None
        return self._conversations.get(self._active_conversation)
    
    async def get_conversation(self, conv_id: str) -> Optional[Conversation]:
        """Get conversation by ID"""
        return self._conversations.get(conv_id)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get dialogue manager statistics"""
        return {
            **self._stats,
            "active_conversations": sum(1 for c in self._conversations.values() if c.is_active),
            "total_stored": len(self._conversations)
        }


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

async def create_dialogue_manager(
    context_tracker: Optional[Any] = None,
    response_generator: Optional[Any] = None,
    memory_manager: Optional[Any] = None,
    **kwargs
) -> DialogueManager:
    """Create configured dialogue manager"""
    config = DialogueConfig(**kwargs)
    
    manager = DialogueManager(
        config=config,
        context_tracker=context_tracker,
        response_generator=response_generator,
        memory_manager=memory_manager
    )
    
    return manager