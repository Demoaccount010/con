#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 CACHE MANAGER - MULTI-LEVEL CACHING SYSTEM
═══════════════════════════════════════════════════════════════════════════════

 Provides multi-level caching for ultra-fast performance.
 
 CACHE LEVELS:
 ─────────────
 • L1: Memory   - Fastest, limited size, volatile
 • L2: Redis    - Fast, larger size, shared (optional)
 • L3: SQLite   - Persistent, largest size, slower
 
 FEATURES:
 ─────────
 • TTL support          - Time-to-live for entries
 • LRU eviction         - Least Recently Used eviction
 • Cache warming        - Pre-populate cache
 • Hit/miss tracking    - Performance metrics
 • Namespace support    - Isolated cache spaces
 • Async operations     - Non-blocking
 • Serialization        - JSON/pickle support
 
 USED FOR:
 ─────────
 • Thought caching      - Repeated query optimization
 • LLM response caching - Avoid redundant inference
 • Memory hints         - Quick access to common data
 • Tool results         - Cache expensive operations
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
import time
import json
import hashlib
import pickle
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, TypeVar, Generic, Callable, Union
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from collections import OrderedDict
import aiosqlite


T = TypeVar('T')


class CacheLevel(Enum):
    """Cache levels."""
    L1_MEMORY = "l1_memory"
    L2_REDIS = "l2_redis"
    L3_SQLITE = "l3_sqlite"


class SerializationType(Enum):
    """Serialization types."""
    JSON = "json"
    PICKLE = "pickle"
    STRING = "string"


@dataclass
class CacheEntry:
    """A single cache entry."""
    key: str
    value: Any
    created_at: datetime
    expires_at: Optional[datetime]
    access_count: int = 0
    last_accessed: datetime = None
    size_bytes: int = 0
    namespace: str = "default"
    
    def __post_init__(self):
        if self.last_accessed is None:
            self.last_accessed = self.created_at
            
    def is_expired(self) -> bool:
        """Check if entry is expired."""
        if self.expires_at is None:
            return False
        return datetime.utcnow() > self.expires_at
        
    def touch(self) -> None:
        """Update access time and count."""
        self.access_count += 1
        self.last_accessed = datetime.utcnow()


@dataclass
class CacheStats:
    """Cache statistics."""
    hits: int = 0
    misses: int = 0
    evictions: int = 0
    expirations: int = 0
    writes: int = 0
    deletes: int = 0
    
    @property
    def hit_rate(self) -> float:
        """Calculate hit rate."""
        total = self.hits + self.misses
        return self.hits / total if total > 0 else 0.0
        
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'hits': self.hits,
            'misses': self.misses,
            'evictions': self.evictions,
            'expirations': self.expirations,
            'writes': self.writes,
            'deletes': self.deletes,
            'hit_rate': round(self.hit_rate, 4),
        }


class L1MemoryCache:
    """
    Level 1: In-memory LRU cache.
    Fastest but volatile and size-limited.
    """
    
    def __init__(self, max_size: int = 1000, max_memory_mb: int = 100):
        self.max_size = max_size
        self.max_memory_mb = max_memory_mb
        self._cache: OrderedDict[str, CacheEntry] = OrderedDict()
        self._lock = asyncio.Lock()
        self.stats = CacheStats()
        self._current_memory = 0
        
    async def get(self, key: str) -> Optional[Any]:
        """Get value from cache."""
        async with self._lock:
            if key not in self._cache:
                self.stats.misses += 1
                return None
                
            entry = self._cache[key]
            
            if entry.is_expired():
                del self._cache[key]
                self._current_memory -= entry.size_bytes
                self.stats.expirations += 1
                self.stats.misses += 1
                return None
                
            # Move to end (most recently used)
            self._cache.move_to_end(key)
            entry.touch()
            
            self.stats.hits += 1
            return entry.value
            
    async def set(
        self,
        key: str,
        value: Any,
        ttl_seconds: int = None,
        namespace: str = "default"
    ) -> None:
        """Set value in cache."""
        async with self._lock:
            # Calculate size
            try:
                size = len(pickle.dumps(value))
            except:
                size = 1000  # Estimate
                
            # Check memory limit
            while self._current_memory + size > self.max_memory_mb * 1024 * 1024:
                if not self._cache:
                    break
                self._evict_one()
                
            # Check size limit
            while len(self._cache) >= self.max_size:
                self._evict_one()
                
            # Create entry
            now = datetime.utcnow()
            expires_at = now + timedelta(seconds=ttl_seconds) if ttl_seconds else None
            
            entry = CacheEntry(
                key=key,
                value=value,
                created_at=now,
                expires_at=expires_at,
                size_bytes=size,
                namespace=namespace
            )
            
            # Remove old entry if exists
            if key in self._cache:
                old_entry = self._cache[key]
                self._current_memory -= old_entry.size_bytes
                
            self._cache[key] = entry
            self._current_memory += size
            self.stats.writes += 1
            
    async def delete(self, key: str) -> bool:
        """Delete from cache."""
        async with self._lock:
            if key in self._cache:
                entry = self._cache.pop(key)
                self._current_memory -= entry.size_bytes
                self.stats.deletes += 1
                return True
            return False
            
    async def exists(self, key: str) -> bool:
        """Check if key exists."""
        async with self._lock:
            if key not in self._cache:
                return False
            entry = self._cache[key]
            if entry.is_expired():
                del self._cache[key]
                return False
            return True
            
    async def clear(self, namespace: str = None) -> int:
        """Clear cache."""
        async with self._lock:
            if namespace:
                keys_to_delete = [
                    k for k, v in self._cache.items()
                    if v.namespace == namespace
                ]
                for key in keys_to_delete:
                    entry = self._cache.pop(key)
                    self._current_memory -= entry.size_bytes
                return len(keys_to_delete)
            else:
                count = len(self._cache)
                self._cache.clear()
                self._current_memory = 0
                return count
                
    def _evict_one(self) -> None:
        """Evict the least recently used entry."""
        if self._cache:
            key, entry = self._cache.popitem(last=False)
            self._current_memory -= entry.size_bytes
            self.stats.evictions += 1
            
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        return {
            **self.stats.to_dict(),
            'size': len(self._cache),
            'max_size': self.max_size,
            'memory_bytes': self._current_memory,
            'max_memory_mb': self.max_memory_mb,
        }


class L3SQLiteCache:
    """
    Level 3: SQLite persistent cache.
    Slowest but persistent and large capacity.
    """
    
    def __init__(self, db_path: str = "memory/data/cache.db"):
        self.db_path = db_path
        self._db: Optional[aiosqlite.Connection] = None
        self.stats = CacheStats()
        self.logger = logging.getLogger("cache.sqlite")
        
    async def initialize(self) -> None:
        """Initialize the SQLite cache."""
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        
        self._db = await aiosqlite.connect(self.db_path)
        
        await self._db.execute("""
            CREATE TABLE IF NOT EXISTS cache (
                key TEXT PRIMARY KEY,
                value BLOB,
                namespace TEXT DEFAULT 'default',
                created_at TEXT,
                expires_at TEXT,
                access_count INTEGER DEFAULT 0,
                last_accessed TEXT,
                size_bytes INTEGER DEFAULT 0
            )
        """)
        
        await self._db.execute("""
            CREATE INDEX IF NOT EXISTS idx_namespace ON cache(namespace)
        """)
        
        await self._db.execute("""
            CREATE INDEX IF NOT EXISTS idx_expires ON cache(expires_at)
        """)
        
        await self._db.commit()
        
        # Clean expired entries
        await self._cleanup_expired()
        
    async def get(self, key: str) -> Optional[Any]:
        """Get value from cache."""
        if not self._db:
            return None
            
        cursor = await self._db.execute(
            "SELECT value, expires_at FROM cache WHERE key = ?",
            (key,)
        )
        row = await cursor.fetchone()
        
        if not row:
            self.stats.misses += 1
            return None
            
        value_blob, expires_at = row
        
        # Check expiration
        if expires_at:
            if datetime.fromisoformat(expires_at) < datetime.utcnow():
                await self.delete(key)
                self.stats.expirations += 1
                self.stats.misses += 1
                return None
                
        # Update access
        await self._db.execute(
            """UPDATE cache SET access_count = access_count + 1, 
               last_accessed = ? WHERE key = ?""",
            (datetime.utcnow().isoformat(), key)
        )
        await self._db.commit()
        
        self.stats.hits += 1
        
        try:
            return pickle.loads(value_blob)
        except:
            return None
            
    async def set(
        self,
        key: str,
        value: Any,
        ttl_seconds: int = None,
        namespace: str = "default"
    ) -> None:
        """Set value in cache."""
        if not self._db:
            return
            
        try:
            value_blob = pickle.dumps(value)
        except:
            self.logger.warning(f"Cannot serialize value for key: {key}")
            return
            
        now = datetime.utcnow()
        expires_at = (now + timedelta(seconds=ttl_seconds)).isoformat() if ttl_seconds else None
        
        await self._db.execute(
            """INSERT OR REPLACE INTO cache 
               (key, value, namespace, created_at, expires_at, size_bytes)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (key, value_blob, namespace, now.isoformat(), expires_at, len(value_blob))
        )
        await self._db.commit()
        self.stats.writes += 1
        
    async def delete(self, key: str) -> bool:
        """Delete from cache."""
        if not self._db:
            return False
            
        cursor = await self._db.execute("DELETE FROM cache WHERE key = ?", (key,))
        await self._db.commit()
        
        if cursor.rowcount > 0:
            self.stats.deletes += 1
            return True
        return False
        
    async def exists(self, key: str) -> bool:
        """Check if key exists."""
        if not self._db:
            return False
            
        cursor = await self._db.execute(
            "SELECT 1 FROM cache WHERE key = ? AND (expires_at IS NULL OR expires_at > ?)",
            (key, datetime.utcnow().isoformat())
        )
        row = await cursor.fetchone()
        return row is not None
        
    async def clear(self, namespace: str = None) -> int:
        """Clear cache."""
        if not self._db:
            return 0
            
        if namespace:
            cursor = await self._db.execute(
                "DELETE FROM cache WHERE namespace = ?",
                (namespace,)
            )
        else:
            cursor = await self._db.execute("DELETE FROM cache")
            
        await self._db.commit()
        return cursor.rowcount
        
    async def _cleanup_expired(self) -> int:
        """Clean up expired entries."""
        if not self._db:
            return 0
            
        cursor = await self._db.execute(
            "DELETE FROM cache WHERE expires_at IS NOT NULL AND expires_at < ?",
            (datetime.utcnow().isoformat(),)
        )
        await self._db.commit()
        return cursor.rowcount
        
    async def get_size(self) -> int:
        """Get number of entries."""
        if not self._db:
            return 0
            
        cursor = await self._db.execute("SELECT COUNT(*) FROM cache")
        row = await cursor.fetchone()
        return row[0] if row else 0
        
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        return {
            **self.stats.to_dict(),
            'db_path': self.db_path,
        }
        
    async def close(self) -> None:
        """Close database connection."""
        if self._db:
            await self._db.close()
            self._db = None


class CacheManager:
    """
    ═══════════════════════════════════════════════════════════════════════════
    MULTI-LEVEL CACHE MANAGER
    ═══════════════════════════════════════════════════════════════════════════
    
    Provides unified interface to multi-level caching.
    Automatically promotes/demotes entries between levels.
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize cache manager.
        
        Args:
            config: Configuration dictionary
        """
        self.logger = logging.getLogger("cache.manager")
        self.config = config or {}
        
        # L1: Memory cache
        self.l1 = L1MemoryCache(
            max_size=self.config.get('l1_max_size', 1000),
            max_memory_mb=self.config.get('l1_max_memory_mb', 100)
        )
        
        # L2: Redis (optional, skip for now)
        # L2 Cache: Redis (optional)
        self.l2 = self._init_redis() if redis_url else None
        
        # L3: SQLite
        self.l3 = L3SQLiteCache(
            db_path=self.config.get('l3_db_path', 'memory/data/cache.db')
        )
        
        # Settings
        self.default_ttl = self.config.get('default_ttl', 3600)  # 1 hour
        self.write_through = self.config.get('write_through', True)
        self.read_through = self.config.get('read_through', True)
        
        # Global stats
        self._total_hits = 0
        self._total_misses = 0
        
    def _init_redis(self) -> Optional[Any]:
        """Initialize Redis connection if available."""
        try:
            import redis
            
            if self._redis_url and self._redis_url.startswith('redis://'):
                r = redis.from_url(self._redis_url, decode_responses=True)
                r.ping()  # Test connection
                self.logger.info("Redis L2 cache connected")
                return r
            return None
                
        except ImportError:
            self.logger.warning("Redis not installed. Run: pip install redis")
            return None
        except Exception as e:
            self.logger.warning(f"Redis connection failed: {e}")
            return None
    
    async def initialize(self) -> None:
        """Initialize all cache levels."""
        self.logger.info("Initializing cache manager...")
        
        await self.l3.initialize()
        
        self.logger.info("Cache manager initialized")
        
    async def get(
        self,
        key: str,
        default: T = None
    ) -> Optional[T]:
        """
        Get value from cache.
        
        Checks L1 first, then L2, then L3.
        Promotes values up the cache hierarchy.
        
        Args:
            key: Cache key
            default: Default value if not found
            
        Returns:
            Cached value or default
        """
        # Try L1
        value = await self.l1.get(key)
        if value is not None:
            self._total_hits += 1
            return value
            
        # Try L3
        if self.read_through:
            value = await self.l3.get(key)
            if value is not None:
                # Promote to L1
                await self.l1.set(key, value)
                self._total_hits += 1
                return value
                
        self._total_misses += 1
        return default
        
    async def set(
        self,
        key: str,
        value: Any,
        ttl: int = None,
        namespace: str = "default",
        levels: List[CacheLevel] = None
    ) -> None:
        """
        Set value in cache.
        
        Args:
            key: Cache key
            value: Value to cache
            ttl: Time-to-live in seconds
            namespace: Cache namespace
            levels: Which levels to write to (default: all)
        """
        ttl = ttl or self.default_ttl
        levels = levels or [CacheLevel.L1_MEMORY, CacheLevel.L3_SQLITE]
        
        if CacheLevel.L1_MEMORY in levels:
            await self.l1.set(key, value, ttl, namespace)
            
        if CacheLevel.L3_SQLITE in levels and self.write_through:
            await self.l3.set(key, value, ttl, namespace)
            
    async def delete(self, key: str) -> bool:
        """Delete from all cache levels."""
        l1_deleted = await self.l1.delete(key)
        l3_deleted = await self.l3.delete(key)
        return l1_deleted or l3_deleted
        
    async def exists(self, key: str) -> bool:
        """Check if key exists in any level."""
        if await self.l1.exists(key):
            return True
        if await self.l3.exists(key):
            return True
        return False
        
    async def clear(self, namespace: str = None) -> Dict[str, int]:
        """Clear cache."""
        l1_cleared = await self.l1.clear(namespace)
        l3_cleared = await self.l3.clear(namespace)
        return {'l1': l1_cleared, 'l3': l3_cleared}
        
    # ═══════════════════════════════════════════════════════════════════════════
    # SPECIALIZED CACHING
    # ═══════════════════════════════════════════════════════════════════════════
    
    def generate_key(self, *parts: Any) -> str:
        """Generate a cache key from parts."""
        combined = "|".join(str(p) for p in parts)
        return hashlib.md5(combined.encode()).hexdigest()
        
    async def get_or_set(
        self,
        key: str,
        factory: Callable[[], Any],
        ttl: int = None
    ) -> Any:
        """
        Get from cache or compute and cache.
        
        Args:
            key: Cache key
            factory: Function to compute value if not cached
            ttl: Time-to-live
            
        Returns:
            Cached or computed value
        """
        value = await self.get(key)
        if value is not None:
            return value
            
        # Compute value
        if asyncio.iscoroutinefunction(factory):
            value = await factory()
        else:
            value = factory()
            
        await self.set(key, value, ttl)
        return value
        
    def cached(
        self,
        ttl: int = None,
        namespace: str = "default",
        key_builder: Callable = None
    ):
        """
        Decorator to cache function results.
        
        Usage:
            @cache.cached(ttl=300)
            async def expensive_operation(x, y):
                ...
        """
        def decorator(func):
            async def wrapper(*args, **kwargs):
                # Build cache key
                if key_builder:
                    key = key_builder(*args, **kwargs)
                else:
                    key = self.generate_key(
                        func.__name__,
                        args,
                        tuple(sorted(kwargs.items()))
                    )
                    
                # Check cache
                cached = await self.get(key)
                if cached is not None:
                    return cached
                    
                # Compute and cache
                result = await func(*args, **kwargs)
                await self.set(key, result, ttl, namespace)
                return result
                
            return wrapper
        return decorator
        
    # ═══════════════════════════════════════════════════════════════════════════
    # THOUGHT CACHING (Special case for LLM)
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def cache_thought(
        self,
        query: str,
        response: str,
        model: str,
        ttl: int = 1800  # 30 minutes
    ) -> str:
        """Cache a thought/LLM response."""
        key = self.generate_key("thought", query, model)
        await self.set(key, response, ttl, namespace="thoughts")
        return key
        
    async def get_cached_thought(
        self,
        query: str,
        model: str
    ) -> Optional[str]:
        """Get cached thought."""
        key = self.generate_key("thought", query, model)
        return await self.get(key)
        
    # ═══════════════════════════════════════════════════════════════════════════
    # MEMORY HINTS CACHING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def cache_hints(
        self,
        query: str,
        hints: Dict[str, Any],
        ttl: int = 600  # 10 minutes
    ) -> str:
        """Cache memory hints."""
        key = self.generate_key("hints", query)
        await self.set(key, hints, ttl, namespace="hints")
        return key
        
    async def get_cached_hints(self, query: str) -> Optional[Dict[str, Any]]:
        """Get cached hints."""
        key = self.generate_key("hints", query)
        return await self.get(key)
        
    # ═══════════════════════════════════════════════════════════════════════════
    # STATISTICS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        total = self._total_hits + self._total_misses
        
        return {
            'total_hits': self._total_hits,
            'total_misses': self._total_misses,
            'overall_hit_rate': self._total_hits / total if total > 0 else 0,
            'l1': self.l1.get_stats(),
            'l3': self.l3.get_stats(),
        }
        
    async def get_size(self) -> Dict[str, int]:
        """Get cache sizes."""
        return {
            'l1': len(self.l1._cache),
            'l3': await self.l3.get_size(),
        }
        
    # ═══════════════════════════════════════════════════════════════════════════
    # WARMING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def warm(self, keys: List[str]) -> int:
        """
        Warm cache by promoting L3 entries to L1.
        
        Args:
            keys: Keys to warm
            
        Returns:
            Number of entries warmed
        """
        warmed = 0
        for key in keys:
            value = await self.l3.get(key)
            if value is not None:
                await self.l1.set(key, value)
                warmed += 1
        return warmed
        
    async def shutdown(self) -> None:
        """Shutdown cache manager."""
        self.logger.info("Shutting down cache manager...")
        await self.l3.close()
        self.logger.info("Cache manager shutdown complete")