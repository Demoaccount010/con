#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 PERFORMANCE MANAGER - SYSTEM PERFORMANCE OPTIMIZATION
═══════════════════════════════════════════════════════════════════════════════

 Manages and optimizes performance across the autonomous agent.
 
 OPTIMIZATIONS:
 ──────────────
 • Async operations   - Non-blocking I/O everywhere
 • Parallel execution - Concurrent task processing
 • Caching            - Multi-level caching system
 • Lazy loading       - Load on demand
 • Connection pooling - Reuse connections
 • Batch processing   - Group operations
 • Resource limits    - Prevent overload
 
 METRICS TRACKED:
 ────────────────
 • Response times
 • Throughput
 • Error rates
 • Resource usage
 • Cache hit rates
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
import time
import functools
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Callable, TypeVar, Awaitable, Union
from dataclasses import dataclass, field
from enum import Enum
from collections import deque
from contextlib import asynccontextmanager
import threading


T = TypeVar('T')


class PerformanceLevel(Enum):
    """Performance optimization levels."""
    MINIMAL = "minimal"      # Basic optimizations
    BALANCED = "balanced"    # Default
    AGGRESSIVE = "aggressive"  # Maximum optimization
    CUSTOM = "custom"        # Custom settings


@dataclass
class PerformanceMetrics:
    """Performance metrics for a component or operation."""
    name: str
    
    # Timing
    total_calls: int = 0
    total_time_ms: float = 0
    min_time_ms: float = float('inf')
    max_time_ms: float = 0
    avg_time_ms: float = 0
    
    # Success/Failure
    success_count: int = 0
    failure_count: int = 0
    
    # Recent history
    recent_times: deque = field(default_factory=lambda: deque(maxlen=100))
    
    def record(self, duration_ms: float, success: bool = True) -> None:
        """Record a metric."""
        self.total_calls += 1
        self.total_time_ms += duration_ms
        self.min_time_ms = min(self.min_time_ms, duration_ms)
        self.max_time_ms = max(self.max_time_ms, duration_ms)
        self.avg_time_ms = self.total_time_ms / self.total_calls
        
        if success:
            self.success_count += 1
        else:
            self.failure_count += 1
            
        self.recent_times.append(duration_ms)
        
    @property
    def success_rate(self) -> float:
        """Get success rate."""
        if self.total_calls == 0:
            return 1.0
        return self.success_count / self.total_calls
        
    @property
    def p95_time_ms(self) -> float:
        """Get 95th percentile response time."""
        if not self.recent_times:
            return 0
        sorted_times = sorted(self.recent_times)
        idx = int(len(sorted_times) * 0.95)
        return sorted_times[min(idx, len(sorted_times) - 1)]
        
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'name': self.name,
            'total_calls': self.total_calls,
            'avg_time_ms': round(self.avg_time_ms, 2),
            'min_time_ms': round(self.min_time_ms, 2) if self.min_time_ms != float('inf') else 0,
            'max_time_ms': round(self.max_time_ms, 2),
            'p95_time_ms': round(self.p95_time_ms, 2),
            'success_rate': round(self.success_rate, 4),
            'success_count': self.success_count,
            'failure_count': self.failure_count,
        }


@dataclass
class ResourceLimit:
    """Resource usage limits."""
    max_concurrent_tasks: int = 50
    max_memory_mb: int = 500
    max_cpu_percent: float = 80.0
    max_queue_size: int = 1000
    task_timeout_seconds: int = 120
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'max_concurrent_tasks': self.max_concurrent_tasks,
            'max_memory_mb': self.max_memory_mb,
            'max_cpu_percent': self.max_cpu_percent,
            'max_queue_size': self.max_queue_size,
            'task_timeout_seconds': self.task_timeout_seconds,
        }


class TaskPool:
    """Pool for managing concurrent async tasks."""
    
    def __init__(self, max_size: int = 50):
        self.max_size = max_size
        self._semaphore = asyncio.Semaphore(max_size)
        self._active_tasks: Dict[str, asyncio.Task] = {}
        self._completed_count = 0
        self._failed_count = 0
        
    @asynccontextmanager
    async def acquire(self, task_id: str = None):
        """Acquire a slot from the pool."""
        await self._semaphore.acquire()
        try:
            yield
        finally:
            self._semaphore.release()
            
    async def run(
        self,
        coro: Awaitable[T],
        task_id: str = None,
        timeout: float = None
    ) -> T:
        """Run a coroutine with pool limiting."""
        async with self.acquire(task_id):
            if timeout:
                result = await asyncio.wait_for(coro, timeout=timeout)
            else:
                result = await coro
            self._completed_count += 1
            return result
            
    @property
    def active_count(self) -> int:
        """Get number of active tasks."""
        return self.max_size - self._semaphore._value
        
    @property
    def available_slots(self) -> int:
        """Get available slots."""
        return self._semaphore._value
        
    def get_stats(self) -> Dict[str, Any]:
        """Get pool statistics."""
        return {
            'max_size': self.max_size,
            'active': self.active_count,
            'available': self.available_slots,
            'completed': self._completed_count,
            'failed': self._failed_count,
        }


class BatchProcessor:
    """Process items in batches for efficiency."""
    
    def __init__(
        self,
        processor: Callable[[List[Any]], Awaitable[List[Any]]],
        batch_size: int = 10,
        flush_interval: float = 1.0
    ):
        self.processor = processor
        self.batch_size = batch_size
        self.flush_interval = flush_interval
        
        self._buffer: List[Any] = []
        self._results: Dict[int, Any] = {}
        self._lock = asyncio.Lock()
        self._flush_task: Optional[asyncio.Task] = None
        self._item_counter = 0
        
    async def add(self, item: Any) -> int:
        """Add item to batch. Returns item ID."""
        async with self._lock:
            item_id = self._item_counter
            self._item_counter += 1
            self._buffer.append((item_id, item))
            
            if len(self._buffer) >= self.batch_size:
                await self._flush()
                
            return item_id
            
    async def _flush(self) -> None:
        """Flush the buffer."""
        if not self._buffer:
            return
            
        items = self._buffer.copy()
        self._buffer.clear()
        
        try:
            ids = [i[0] for i in items]
            data = [i[1] for i in items]
            results = await self.processor(data)
            
            for item_id, result in zip(ids, results):
                self._results[item_id] = result
                
        except Exception as e:
            logging.error(f"Batch processing error: {e}")
            
    async def get_result(self, item_id: int, timeout: float = 10.0) -> Any:
        """Get result for an item."""
        start = time.perf_counter()
        while item_id not in self._results:
            if time.perf_counter() - start > timeout:
                raise TimeoutError(f"Result not ready for item {item_id}")
            await asyncio.sleep(0.1)
        return self._results.pop(item_id)


class PerformanceManager:
    """
    ═══════════════════════════════════════════════════════════════════════════
    PERFORMANCE MANAGER
    ═══════════════════════════════════════════════════════════════════════════
    
    Central manager for all performance optimizations.
    Provides tools for async execution, caching, batching, and monitoring.
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize performance manager.
        
        Args:
            config: Configuration dictionary
        """
        self.logger = logging.getLogger("performance.manager")
        self.config = config or {}
        
        # Performance level
        level_str = self.config.get('level', 'balanced')
        self.level = PerformanceLevel(level_str)
        
        # Resource limits
        self.limits = ResourceLimit(
            max_concurrent_tasks=self.config.get('max_concurrent_tasks', 50),
            max_memory_mb=self.config.get('max_memory_mb', 500),
            max_cpu_percent=self.config.get('max_cpu_percent', 80.0),
            max_queue_size=self.config.get('max_queue_size', 1000),
            task_timeout_seconds=self.config.get('task_timeout_seconds', 120),
        )
        
        # Task pool
        self.task_pool = TaskPool(self.limits.max_concurrent_tasks)
        
        # Metrics by operation
        self._metrics: Dict[str, PerformanceMetrics] = {}
        self._metrics_lock = threading.Lock()
        
        # Global stats
        self._global_stats = {
            'start_time': datetime.utcnow(),
            'total_operations': 0,
            'total_time_ms': 0,
        }
        
        # Lazy loaders registry
        self._lazy_loaders: Dict[str, Callable] = {}
        self._lazy_cache: Dict[str, Any] = {}
        
        # Batch processors
        self._batch_processors: Dict[str, BatchProcessor] = {}
        
    async def initialize(self) -> None:
        """Initialize performance manager."""
        self.logger.info(f"Initializing performance manager (level: {self.level.value})")
        
    # ═══════════════════════════════════════════════════════════════════════════
    # TIMING & METRICS
    # ═══════════════════════════════════════════════════════════════════════════
    
    @asynccontextmanager
    async def measure(self, operation: str):
        """
        Context manager to measure operation timing.
        
        Usage:
            async with perf.measure("my_operation"):
                await do_something()
        """
        start = time.perf_counter()
        success = True
        try:
            yield
        except Exception:
            success = False
            raise
        finally:
            duration_ms = (time.perf_counter() - start) * 1000
            self._record_metric(operation, duration_ms, success)
            
    def _record_metric(
        self,
        operation: str,
        duration_ms: float,
        success: bool = True
    ) -> None:
        """Record a metric."""
        with self._metrics_lock:
            if operation not in self._metrics:
                self._metrics[operation] = PerformanceMetrics(name=operation)
            self._metrics[operation].record(duration_ms, success)
            
            self._global_stats['total_operations'] += 1
            self._global_stats['total_time_ms'] += duration_ms
            
    def timed(self, operation: str = None):
        """
        Decorator to time async functions.
        
        Usage:
            @perf.timed("my_function")
            async def my_function():
                pass
        """
        def decorator(func: Callable) -> Callable:
            op_name = operation or func.__name__
            
            @functools.wraps(func)
            async def wrapper(*args, **kwargs):
                async with self.measure(op_name):
                    return await func(*args, **kwargs)
            return wrapper
        return decorator
        
    # ═══════════════════════════════════════════════════════════════════════════
    # PARALLEL EXECUTION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def run_parallel(
        self,
        tasks: List[Awaitable[T]],
        max_concurrent: int = None,
        timeout: float = None,
        return_exceptions: bool = False
    ) -> List[Union[T, Exception]]:
        """
        Run multiple tasks in parallel.
        
        Args:
            tasks: List of coroutines to run
            max_concurrent: Max concurrent tasks (None = use pool limit)
            timeout: Timeout per task
            return_exceptions: If True, return exceptions instead of raising
            
        Returns:
            List of results (or exceptions if return_exceptions=True)
        """
        if not tasks:
            return []
            
        max_concurrent = max_concurrent or self.limits.max_concurrent_tasks
        semaphore = asyncio.Semaphore(max_concurrent)
        
        async def run_with_semaphore(task: Awaitable[T]) -> T:
            async with semaphore:
                if timeout:
                    return await asyncio.wait_for(task, timeout=timeout)
                return await task
                
        wrapped_tasks = [run_with_semaphore(t) for t in tasks]
        
        if return_exceptions:
            return await asyncio.gather(*wrapped_tasks, return_exceptions=True)
        else:
            return await asyncio.gather(*wrapped_tasks)
            
    async def run_with_limit(
        self,
        coro: Awaitable[T],
        timeout: float = None
    ) -> T:
        """Run a coroutine with pool limiting."""
        timeout = timeout or self.limits.task_timeout_seconds
        return await self.task_pool.run(coro, timeout=timeout)
        
    # ═══════════════════════════════════════════════════════════════════════════
    # LAZY LOADING
    # ═══════════════════════════════════════════════════════════════════════════
    
    def register_lazy(
        self,
        name: str,
        loader: Callable[[], Awaitable[Any]]
    ) -> None:
        """
        Register a lazy loader.
        
        Args:
            name: Name of the resource
            loader: Async function to load the resource
        """
        self._lazy_loaders[name] = loader
        
    async def get_lazy(self, name: str) -> Any:
        """
        Get a lazily loaded resource.
        
        Args:
            name: Name of the resource
            
        Returns:
            The loaded resource
        """
        if name in self._lazy_cache:
            return self._lazy_cache[name]
            
        if name not in self._lazy_loaders:
            raise KeyError(f"No lazy loader for: {name}")
            
        resource = await self._lazy_loaders[name]()
        self._lazy_cache[name] = resource
        return resource
        
    def clear_lazy(self, name: str = None) -> None:
        """Clear lazy cache."""
        if name:
            self._lazy_cache.pop(name, None)
        else:
            self._lazy_cache.clear()
            
    # ═══════════════════════════════════════════════════════════════════════════
    # BATCH PROCESSING
    # ═══════════════════════════════════════════════════════════════════════════
    
    def create_batch_processor(
        self,
        name: str,
        processor: Callable[[List[Any]], Awaitable[List[Any]]],
        batch_size: int = 10,
        flush_interval: float = 1.0
    ) -> BatchProcessor:
        """Create a batch processor."""
        bp = BatchProcessor(processor, batch_size, flush_interval)
        self._batch_processors[name] = bp
        return bp
        
    def get_batch_processor(self, name: str) -> Optional[BatchProcessor]:
        """Get a batch processor by name."""
        return self._batch_processors.get(name)
        
    # ═══════════════════════════════════════════════════════════════════════════
    # THROTTLING & RATE LIMITING
    # ═══════════════════════════════════════════════════════════════════════════
    
    def throttle(self, calls_per_second: float = 10):
        """
        Decorator to throttle function calls.
        
        Usage:
            @perf.throttle(calls_per_second=5)
            async def rate_limited_function():
                pass
        """
        min_interval = 1.0 / calls_per_second
        last_call = [0.0]
        lock = asyncio.Lock()
        
        def decorator(func: Callable) -> Callable:
            @functools.wraps(func)
            async def wrapper(*args, **kwargs):
                async with lock:
                    now = time.perf_counter()
                    elapsed = now - last_call[0]
                    if elapsed < min_interval:
                        await asyncio.sleep(min_interval - elapsed)
                    last_call[0] = time.perf_counter()
                    return await func(*args, **kwargs)
            return wrapper
        return decorator
        
    # ═══════════════════════════════════════════════════════════════════════════
    # OPTIMIZATION UTILITIES
    # ═══════════════════════════════════════════════════════════════════════════
    
    def early_exit(self, condition: bool, result: T) -> Optional[T]:
        """
        Helper for early termination optimization.
        
        Usage:
            if result := perf.early_exit(confidence > 0.95, cached_result):
                return result
        """
        if condition:
            return result
        return None
        
    async def with_timeout(
        self,
        coro: Awaitable[T],
        timeout: float,
        default: T = None
    ) -> T:
        """Run coroutine with timeout, returning default on timeout."""
        try:
            return await asyncio.wait_for(coro, timeout=timeout)
        except asyncio.TimeoutError:
            return default
            
    # ═══════════════════════════════════════════════════════════════════════════
    # METRICS & REPORTING
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_metrics(self, operation: str = None) -> Dict[str, Any]:
        """Get performance metrics."""
        with self._metrics_lock:
            if operation:
                if operation in self._metrics:
                    return self._metrics[operation].to_dict()
                return {}
            return {name: m.to_dict() for name, m in self._metrics.items()}
            
    def get_stats(self) -> Dict[str, Any]:
        """Get global performance statistics."""
        uptime = (datetime.utcnow() - self._global_stats['start_time']).total_seconds()
        
        return {
            'uptime_seconds': uptime,
            'total_operations': self._global_stats['total_operations'],
            'total_time_ms': self._global_stats['total_time_ms'],
            'avg_time_ms': (
                self._global_stats['total_time_ms'] / self._global_stats['total_operations']
                if self._global_stats['total_operations'] > 0 else 0
            ),
            'ops_per_second': (
                self._global_stats['total_operations'] / uptime
                if uptime > 0 else 0
            ),
            'task_pool': self.task_pool.get_stats(),
            'limits': self.limits.to_dict(),
            'level': self.level.value,
        }
        
    def get_slow_operations(
        self,
        threshold_ms: float = 1000,
        limit: int = 10
    ) -> List[Dict[str, Any]]:
        """Get operations that exceed threshold."""
        with self._metrics_lock:
            slow = [
                m.to_dict() for m in self._metrics.values()
                if m.avg_time_ms > threshold_ms
            ]
            return sorted(slow, key=lambda x: x['avg_time_ms'], reverse=True)[:limit]
            
    def reset_metrics(self, operation: str = None) -> None:
        """Reset metrics."""
        with self._metrics_lock:
            if operation:
                self._metrics.pop(operation, None)
            else:
                self._metrics.clear()
                
    async def shutdown(self) -> None:
        """Shutdown performance manager."""
        self.logger.info("Shutting down performance manager")
        self._lazy_cache.clear()