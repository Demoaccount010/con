#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 CLI INTERFACE - Command Line Interface for the Agent
═══════════════════════════════════════════════════════════════════════════════

 Interactive command-line interface for direct agent interaction.
 
 FEATURES:
 ─────────
 • Rich colored output
 • Command history
 • Multi-line input support
 • Tab completion
 • Special commands (/help, /status, /exit, etc.)
 • Memory tag display
 • Thinking visualization
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
import sys
import os
from datetime import datetime
from typing import Optional, Dict, Any, List
from pathlib import Path

from interfaces.base_interface import (
    BaseInterface,
    InterfaceType,
    InterfaceState,
    InterfaceMessage,
    InterfaceResponse,
    InterfaceConfig
)

# Try to import rich for beautiful output
try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.progress import Progress, SpinnerColumn, TextColumn
    from rich.syntax import Syntax
    from rich.text import Text
    from rich.live import Live
    from rich import box
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False

# Try to import prompt_toolkit for advanced input
try:
    from prompt_toolkit import PromptSession
    from prompt_toolkit.history import FileHistory
    from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
    from prompt_toolkit.styles import Style
    from prompt_toolkit.formatted_text import HTML
    PROMPT_TOOLKIT_AVAILABLE = True
except ImportError:
    PROMPT_TOOLKIT_AVAILABLE = False


class CLIInterface(BaseInterface):
    """
    ═══════════════════════════════════════════════════════════════════════════
    COMMAND LINE INTERFACE
    ═══════════════════════════════════════════════════════════════════════════
    
    Interactive CLI for direct agent communication.
    """
    
    # Special CLI commands
    CLI_COMMANDS = {
        '/help': 'Show help message',
        '/status': 'Show agent status',
        '/memory': 'Show memory statistics',
        '/tools': 'List available tools',
        '/clear': 'Clear screen',
        '/history': 'Show command history',
        '/config': 'Show configuration',
        '/exit': 'Exit the CLI',
        '/quit': 'Exit the CLI',
        '/thinking': 'Toggle thinking display',
        '/tags': 'Toggle memory tags display',
        '/multiline': 'Toggle multiline input mode',
    }
    
    def __init__(self, config: Optional[InterfaceConfig] = None):
        """Initialize CLI interface."""
        super().__init__(InterfaceType.CLI, config)
        
        # Rich console for output
        self.console = Console() if RICH_AVAILABLE else None
        
        # Prompt session for input
        self.prompt_session: Optional[PromptSession] = None
        self.history_file = Path("./data/cli_history")
        
        # CLI state
        self.multiline_mode = False
        self.running = False
        
        # Agent name (will be loaded from config)
        self.agent_name = "Axiom"
        self.owner_name = "User"
        
        # Display settings
        self.show_thinking = self.config.show_thinking
        self.show_tags = self.config.show_memory_tags
        
        # Colors
        self.colors = {
            'prompt': 'cyan',
            'agent': 'green',
            'error': 'red',
            'warning': 'yellow',
            'info': 'blue',
            'memory': 'magenta',
            'thinking': 'dim cyan',
        }
        
    async def initialize(self) -> bool:
        """Initialize the CLI interface."""
        self.logger.info("Initializing CLI interface...")
        
        try:
            # Create history directory
            self.history_file.parent.mkdir(parents=True, exist_ok=True)
            
            # Initialize prompt session if available
            if PROMPT_TOOLKIT_AVAILABLE:
                self.prompt_session = PromptSession(
                    history=FileHistory(str(self.history_file)),
                    auto_suggest=AutoSuggestFromHistory(),
                    style=Style.from_dict({
                        'prompt': f'ansicyan bold',
                    })
                )
                
            self.state = InterfaceState.READY
            self.logger.info("CLI interface initialized")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to initialize CLI: {e}")
            self.state = InterfaceState.ERROR
            return False
    
    async def start(self) -> None:
        """Start the CLI interface."""
        if self.state != InterfaceState.READY:
            await self.initialize()
            
        self.state = InterfaceState.RUNNING
        self.started_at = datetime.utcnow()
        self.running = True
        
        # Show welcome banner
        self._show_banner()
        
        # Main input loop
        await self._input_loop()
    
    async def stop(self) -> None:
        """Stop the CLI interface."""
        self.running = False
        self.state = InterfaceState.STOPPED
        
        if RICH_AVAILABLE:
            self.console.print("\n[yellow]Goodbye! 👋[/yellow]\n")
        else:
            print("\nGoodbye! 👋\n")
    
    async def send_response(self, response: InterfaceResponse) -> bool:
        """Send/display a response."""
        try:
            self._display_response(response)
            return True
        except Exception as e:
            self.logger.error(f"Error displaying response: {e}")
            return False
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          MAIN INPUT LOOP
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _input_loop(self) -> None:
        """Main input loop."""
        while self.running:
            try:
                # Get user input
                user_input = await self._get_input()
                
                if user_input is None:
                    continue
                    
                user_input = user_input.strip()
                
                if not user_input:
                    continue
                
                # Check for CLI commands
                if user_input.startswith('/'):
                    handled = await self._handle_cli_command(user_input)
                    if handled:
                        continue
                
                # Create message
                message = InterfaceMessage.create(
                    content=user_input,
                    interface_type=InterfaceType.CLI,
                    user_name=self.owner_name
                )
                
                # Show processing indicator
                self._show_processing()
                
                # Process message
                response = await self.process_message(message)
                
                # Display response
                self._display_response(response)
                
            except KeyboardInterrupt:
                if RICH_AVAILABLE:
                    self.console.print("\n[yellow]Use /exit to quit[/yellow]")
                else:
                    print("\nUse /exit to quit")
                    
            except EOFError:
                await self.stop()
                break
                
            except Exception as e:
                self.logger.error(f"Input loop error: {e}", exc_info=True)
                self._show_error(str(e))
    
    async def _get_input(self) -> Optional[str]:
        """Get user input."""
        prompt = self._get_prompt()
        
        if self.multiline_mode:
            return await self._get_multiline_input(prompt)
        
        if PROMPT_TOOLKIT_AVAILABLE and self.prompt_session:
            try:
                # Run prompt in executor to not block
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(
                    None,
                    lambda: self.prompt_session.prompt(HTML(prompt))
                )
                return result
            except (EOFError, KeyboardInterrupt):
                raise
        else:
            # Fallback to basic input
            try:
                return input(self._strip_html(prompt))
            except (EOFError, KeyboardInterrupt):
                raise
    
    async def _get_multiline_input(self, prompt: str) -> str:
        """Get multiline input."""
        if RICH_AVAILABLE:
            self.console.print("[dim]Multiline mode: Enter empty line to submit[/dim]")
        else:
            print("Multiline mode: Enter empty line to submit")
            
        lines = []
        while True:
            line_prompt = prompt if not lines else "... "
            
            try:
                if PROMPT_TOOLKIT_AVAILABLE and self.prompt_session:
                    loop = asyncio.get_event_loop()
                    line = await loop.run_in_executor(
                        None,
                        lambda: self.prompt_session.prompt(line_prompt)
                    )
                else:
                    line = input(self._strip_html(line_prompt))
                    
                if line == "":
                    break
                lines.append(line)
                
            except (EOFError, KeyboardInterrupt):
                break
                
        return "\n".join(lines)
    
    def _get_prompt(self) -> str:
        """Get the prompt string."""
        if PROMPT_TOOLKIT_AVAILABLE:
            return f"<cyan><b>{self.owner_name}</b></cyan> <dim>›</dim> "
        return f"{self.owner_name} › "
    
    def _strip_html(self, text: str) -> str:
        """Strip HTML tags for plain text."""
        import re
        return re.sub(r'<[^>]+>', '', text)
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          CLI COMMANDS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _handle_cli_command(self, command: str) -> bool:
        """Handle CLI-specific commands."""
        cmd = command.split()[0].lower()
        args = command.split()[1:] if len(command.split()) > 1 else []
        
        if cmd in ['/exit', '/quit']:
            await self.stop()
            return True
            
        elif cmd == '/help':
            self._show_help()
            return True
            
        elif cmd == '/status':
            await self._show_status()
            return True
            
        elif cmd == '/memory':
            await self._show_memory()
            return True
            
        elif cmd == '/tools':
            await self._show_tools()
            return True
            
        elif cmd == '/clear':
            self._clear_screen()
            return True
            
        elif cmd == '/history':
            self._show_history()
            return True
            
        elif cmd == '/config':
            self._show_config()
            return True
            
        elif cmd == '/thinking':
            self.show_thinking = not self.show_thinking
            self._show_info(f"Thinking display: {'ON' if self.show_thinking else 'OFF'}")
            return True
            
        elif cmd == '/tags':
            self.show_tags = not self.show_tags
            self._show_info(f"Memory tags display: {'ON' if self.show_tags else 'OFF'}")
            return True
            
        elif cmd == '/multiline':
            self.multiline_mode = not self.multiline_mode
            self._show_info(f"Multiline mode: {'ON' if self.multiline_mode else 'OFF'}")
            return True
            
        return False
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          DISPLAY METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _show_banner(self) -> None:
        """Show welcome banner."""
        if RICH_AVAILABLE:
            banner = Panel(
                f"[bold green]{self.agent_name}[/bold green] v3.0.0\n"
                f"[dim]Autonomous AI Agent[/dim]\n\n"
                f"Type [cyan]/help[/cyan] for commands or just start chatting!",
                title="🤖 Agent Ready",
                border_style="green",
                box=box.ROUNDED
            )
            self.console.print(banner)
            self.console.print()
        else:
            print(f"\n{'='*60}")
            print(f"  {self.agent_name} v3.0.0 - Autonomous AI Agent")
            print(f"{'='*60}")
            print("  Type /help for commands or just start chatting!")
            print(f"{'='*60}\n")
    
    def _show_help(self) -> None:
        """Show help message."""
        if RICH_AVAILABLE:
            table = Table(title="CLI Commands", box=box.ROUNDED)
            table.add_column("Command", style="cyan")
            table.add_column("Description", style="white")
            
            for cmd, desc in self.CLI_COMMANDS.items():
                table.add_row(cmd, desc)
                
            self.console.print(table)
            self.console.print("\n[dim]Or just type naturally to chat with the agent![/dim]\n")
        else:
            print("\nCLI Commands:")
            print("-" * 40)
            for cmd, desc in self.CLI_COMMANDS.items():
                print(f"  {cmd:15} {desc}")
            print("-" * 40)
            print("Or just type naturally to chat with the agent!\n")
    
    async def _show_status(self) -> None:
        """Show agent status."""
        stats = self.get_stats()
        
        if RICH_AVAILABLE:
            table = Table(title="Agent Status", box=box.ROUNDED)
            table.add_column("Property", style="cyan")
            table.add_column("Value", style="green")
            
            table.add_row("Agent", self.agent_name)
            table.add_row("State", stats['state'])
            table.add_row("Messages Received", str(stats['messages_received']))
            table.add_row("Messages Sent", str(stats['messages_sent']))
            table.add_row("Avg Response Time", f"{stats['avg_response_time_ms']:.0f}ms")
            table.add_row("Active Sessions", str(stats['active_sessions']))
            table.add_row("Uptime", f"{stats['uptime_seconds']:.0f}s")
            
            self.console.print(table)
        else:
            print("\nAgent Status:")
            print(f"  Agent: {self.agent_name}")
            print(f"  State: {stats['state']}")
            print(f"  Messages: {stats['messages_received']} received, {stats['messages_sent']} sent")
            print(f"  Avg Response: {stats['avg_response_time_ms']:.0f}ms\n")
    
    async def _show_memory(self) -> None:
        """Show memory statistics."""
        # This would call memory manager
        self._show_info("Memory statistics - coming from memory manager")
    
    async def _show_tools(self) -> None:
        """Show available tools."""
        # This would list tools from registry
        self._show_info("Tools list - coming from tool registry")
    
    def _show_config(self) -> None:
        """Show current configuration."""
        if RICH_AVAILABLE:
            config_info = {
                'Show Thinking': self.show_thinking,
                'Show Memory Tags': self.show_tags,
                'Multiline Mode': self.multiline_mode,
                'Colored Output': self.config.colored_output,
            }
            
            table = Table(title="Configuration", box=box.ROUNDED)
            table.add_column("Setting", style="cyan")
            table.add_column("Value", style="green")
            
            for key, value in config_info.items():
                table.add_row(key, str(value))
                
            self.console.print(table)
        else:
            print("\nConfiguration:")
            print(f"  Show Thinking: {self.show_thinking}")
            print(f"  Show Memory Tags: {self.show_tags}")
            print(f"  Multiline Mode: {self.multiline_mode}\n")
    
    def _show_history(self) -> None:
        """Show command history."""
        if RICH_AVAILABLE:
            self.console.print("[dim]Recent messages:[/dim]")
            for msg in self.message_history[-10:]:
                self.console.print(f"  [cyan]{msg.timestamp.strftime('%H:%M')}[/cyan] {msg.content[:50]}...")
        else:
            print("\nRecent messages:")
            for msg in self.message_history[-10:]:
                print(f"  {msg.timestamp.strftime('%H:%M')} {msg.content[:50]}...")
    
    def _clear_screen(self) -> None:
        """Clear the screen."""
        os.system('cls' if os.name == 'nt' else 'clear')
        self._show_banner()
    
    def _show_processing(self) -> None:
        """Show processing indicator."""
        if RICH_AVAILABLE:
            self.console.print("[dim]Thinking...[/dim]", end="\r")
    
    def _display_response(self, response: InterfaceResponse) -> None:
        """Display an agent response."""
        if RICH_AVAILABLE:
            self._display_response_rich(response)
        else:
            self._display_response_plain(response)
    
    def _display_response_rich(self, response: InterfaceResponse) -> None:
        """Display response with rich formatting."""
        # Clear the "Thinking..." line
        self.console.print(" " * 50, end="\r")
        
        # Show thinking if enabled
        if self.show_thinking and response.thinking:
            self.console.print(Panel(
                f"[dim italic]{response.thinking}[/dim italic]",
                title="💭 Thinking",
                border_style="dim cyan",
                box=box.ROUNDED
            ))
        
        # Show memory tags if enabled
        if self.show_tags and response.memory_tags:
            for tag in response.memory_tags:
                self.console.print(f"[magenta]{tag}[/magenta]")
        
        # Main response
        response_panel = Panel(
            Markdown(response.content) if '```' in response.content or '**' in response.content else response.content,
            title=f"🤖 {self.agent_name}",
            border_style="green" if response.success else "red",
            box=box.ROUNDED
        )
        self.console.print(response_panel)
        
        # Show errors if any
        if response.errors:
            for error in response.errors:
                self.console.print(f"[red]❌ {error}[/red]")
                
        # Show warnings if any
        if response.warnings:
            for warning in response.warnings:
                self.console.print(f"[yellow]⚠️ {warning}[/yellow]")
        
        # Show timing if enabled
        if self.config.show_timing:
            self.console.print(f"[dim]⏱️ {response.processing_time_ms}ms[/dim]")
            
        self.console.print()
    
    def _display_response_plain(self, response: InterfaceResponse) -> None:
        """Display response with plain text."""
        print()
        
        # Show thinking if enabled
        if self.show_thinking and response.thinking:
            print(f"💭 Thinking: {response.thinking}")
            print()
        
        # Show memory tags if enabled
        if self.show_tags and response.memory_tags:
            for tag in response.memory_tags:
                print(f"  {tag}")
        
        # Main response
        print(f"🤖 {self.agent_name}:")
        print("-" * 40)
        print(response.content)
        print("-" * 40)
        
        # Show errors
        for error in response.errors:
            print(f"❌ ERROR: {error}")
            
        # Show warnings
        for warning in response.warnings:
            print(f"⚠️ WARNING: {warning}")
            
        print()
    
    def _show_error(self, message: str) -> None:
        """Show an error message."""
        if RICH_AVAILABLE:
            self.console.print(f"[red]❌ Error: {message}[/red]")
        else:
            print(f"❌ Error: {message}")
    
    def _show_info(self, message: str) -> None:
        """Show an info message."""
        if RICH_AVAILABLE:
            self.console.print(f"[blue]ℹ️ {message}[/blue]")
        else:
            print(f"ℹ️ {message}")
    
    def _show_warning(self, message: str) -> None:
        """Show a warning message."""
        if RICH_AVAILABLE:
            self.console.print(f"[yellow]⚠️ {message}[/yellow]")
        else:
            print(f"⚠️ {message}")


# ═══════════════════════════════════════════════════════════════════════════════
#                          STANDALONE EXECUTION
# ═══════════════════════════════════════════════════════════════════════════════

async def main():
    """Run CLI interface standalone (for testing)."""
    cli = CLIInterface()
    
    if await cli.initialize():
        await cli.start()
    else:
        print("Failed to initialize CLI interface")


if __name__ == "__main__":
    asyncio.run(main())