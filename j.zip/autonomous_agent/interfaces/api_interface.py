#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 API INTERFACE - REST API for programmatic access
═══════════════════════════════════════════════════════════════════════════════

 Provides REST API endpoints for:
 • Sending messages to the agent
 • Getting agent status
 • Memory operations
 • Tool execution
 • Health checks

 ENDPOINTS:
 ──────────
 POST   /api/v1/message      - Send message to agent
 GET    /api/v1/status       - Get agent status
 GET    /api/v1/memory       - Get memory statistics
 GET    /api/v1/tools        - List available tools
 GET    /api/v1/health       - Health check
 POST   /api/v1/command      - Execute direct command
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
from datetime import datetime
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, asdict
import json

# Try to import aiohttp for web server
try:
    from aiohttp import web
    from aiohttp.web import Request, Response, json_response
    AIOHTTP_AVAILABLE = True
except ImportError:
    AIOHTTP_AVAILABLE = False
    Request = Any
    Response = Any

from interfaces.base_interface import (
    BaseInterface,
    InterfaceType,
    InterfaceState,
    InterfaceMessage,
    InterfaceResponse,
    InterfaceConfig
)


@dataclass
class APIConfig:
    """API-specific configuration."""
    host: str = "127.0.0.1"
    port: int = 8080
    cors_enabled: bool = True
    cors_origins: List[str] = None
    api_key_required: bool = False
    api_key: Optional[str] = None
    rate_limit_enabled: bool = True
    rate_limit_per_minute: int = 60
    
    def __post_init__(self):
        if self.cors_origins is None:
            self.cors_origins = ["*"]


class APIInterface(BaseInterface):
    """
    ═══════════════════════════════════════════════════════════════════════════
    REST API INTERFACE
    ═══════════════════════════════════════════════════════════════════════════
    
    HTTP API for programmatic agent access.
    """
    
    def __init__(
        self,
        config: Optional[InterfaceConfig] = None,
        api_config: Optional[APIConfig] = None
    ):
        """Initialize API interface."""
        super().__init__(InterfaceType.API, config)
        
        self.api_config = api_config or APIConfig()
        
        # Web application
        self.app: Optional[web.Application] = None
        self.runner: Optional[web.AppRunner] = None
        self.site: Optional[web.TCPSite] = None
        
        # Rate limiting
        self.request_counts: Dict[str, List[datetime]] = {}
        
        # API version
        self.api_version = "v1"
        
    async def initialize(self) -> bool:
        """Initialize the API interface."""
        if not AIOHTTP_AVAILABLE:
            self.logger.error("aiohttp not installed. Install with: pip install aiohttp")
            self.state = InterfaceState.ERROR
            return False
            
        self.logger.info("Initializing API interface...")
        
        try:
            # Create web application
            self.app = web.Application(middlewares=[
                self._error_middleware,
                self._cors_middleware,
                self._auth_middleware,
                self._rate_limit_middleware,
            ])
            
            # Setup routes
            self._setup_routes()
            
            self.state = InterfaceState.READY
            self.logger.info(f"API interface initialized on {self.api_config.host}:{self.api_config.port}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to initialize API: {e}")
            self.state = InterfaceState.ERROR
            return False
    
    async def start(self) -> None:
        """Start the API server."""
        if self.state != InterfaceState.READY:
            if not await self.initialize():
                raise RuntimeError("Failed to initialize API interface")
        
        self.logger.info(f"Starting API server on {self.api_config.host}:{self.api_config.port}")
        
        try:
            self.runner = web.AppRunner(self.app)
            await self.runner.setup()
            
            self.site = web.TCPSite(
                self.runner,
                self.api_config.host,
                self.api_config.port
            )
            await self.site.start()
            
            self.state = InterfaceState.RUNNING
            self.started_at = datetime.utcnow()
            
            self.logger.info(f"API server running at http://{self.api_config.host}:{self.api_config.port}")
            
            # Keep running
            while self.state == InterfaceState.RUNNING:
                await asyncio.sleep(1)
                
        except Exception as e:
            self.logger.error(f"API server error: {e}")
            self.state = InterfaceState.ERROR
            raise
    
    async def stop(self) -> None:
        """Stop the API server."""
        self.logger.info("Stopping API server...")
        self.state = InterfaceState.STOPPING
        
        if self.site:
            await self.site.stop()
            
        if self.runner:
            await self.runner.cleanup()
            
        self.state = InterfaceState.STOPPED
        self.logger.info("API server stopped")
    
    async def send_response(self, response: InterfaceResponse) -> bool:
        """Send response - handled by request handlers."""
        # Responses are returned directly from handlers
        return True
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          ROUTE SETUP
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _setup_routes(self) -> None:
        """Setup API routes."""
        prefix = f"/api/{self.api_version}"
        
        # Message endpoint
        self.app.router.add_post(f"{prefix}/message", self._handle_message)
        
        # Status endpoints
        self.app.router.add_get(f"{prefix}/status", self._handle_status)
        self.app.router.add_get(f"{prefix}/health", self._handle_health)
        
        # Memory endpoints
        self.app.router.add_get(f"{prefix}/memory", self._handle_memory_get)
        self.app.router.add_post(f"{prefix}/memory", self._handle_memory_post)
        
        # Tools endpoints
        self.app.router.add_get(f"{prefix}/tools", self._handle_tools_list)
        self.app.router.add_post(f"{prefix}/tools/execute", self._handle_tool_execute)
        
        # Command endpoint
        self.app.router.add_post(f"{prefix}/command", self._handle_command)
        
        # Info endpoint
        self.app.router.add_get(f"{prefix}/info", self._handle_info)
        
        # Root endpoint
        self.app.router.add_get("/", self._handle_root)
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          REQUEST HANDLERS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _handle_root(self, request: Request) -> Response:
        """Handle root endpoint."""
        return json_response({
            "name": "Autonomous Agent API",
            "version": "3.0.0",
            "api_version": self.api_version,
            "endpoints": {
                "message": f"/api/{self.api_version}/message",
                "status": f"/api/{self.api_version}/status",
                "health": f"/api/{self.api_version}/health",
                "memory": f"/api/{self.api_version}/memory",
                "tools": f"/api/{self.api_version}/tools",
                "command": f"/api/{self.api_version}/command",
                "info": f"/api/{self.api_version}/info",
            }
        })
    
    async def _handle_message(self, request: Request) -> Response:
        """
        Handle message endpoint.
        
        POST /api/v1/message
        Body: {"message": "your message here", "session_id": "optional"}
        """
        try:
            data = await request.json()
            message_text = data.get("message", "")
            session_id = data.get("session_id", request.remote or "api")
            
            if not message_text:
                return json_response(
                    {"error": "Message is required"},
                    status=400
                )
            
            # Create message
            message = InterfaceMessage.create(
                content=message_text,
                interface_type=InterfaceType.API,
                user_id=session_id
            )
            message.session_id = session_id
            
            # Process message
            response = await self.process_message(message)
            
            return json_response({
                "success": response.success,
                "response": response.content,
                "message_id": message.id,
                "response_id": response.id,
                "memory_tags": response.memory_tags,
                "thinking": response.thinking,
                "confidence": response.confidence,
                "processing_time_ms": response.processing_time_ms,
                "errors": response.errors,
                "warnings": response.warnings,
            })
            
        except json.JSONDecodeError:
            return json_response(
                {"error": "Invalid JSON"},
                status=400
            )
        except Exception as e:
            self.logger.error(f"Message handler error: {e}", exc_info=True)
            return json_response(
                {"error": str(e)},
                status=500
            )
    
    async def _handle_status(self, request: Request) -> Response:
        """
        Handle status endpoint.
        
        GET /api/v1/status
        """
        stats = self.get_stats()
        
        return json_response({
            "status": "online",
            "agent": {
                "name": "Axiom",  # Would come from config
                "version": "3.0.0",
            },
            "interface": {
                "type": self.interface_type.value,
                "state": self.state.value,
                "uptime_seconds": stats['uptime_seconds'],
            },
            "statistics": {
                "messages_received": stats['messages_received'],
                "messages_sent": stats['messages_sent'],
                "errors": stats['errors'],
                "avg_response_time_ms": stats['avg_response_time_ms'],
            }
        })
    
    async def _handle_health(self, request: Request) -> Response:
        """
        Handle health check endpoint.
        
        GET /api/v1/health
        """
        health = await self.health_check()
        
        status_code = 200 if health['healthy'] else 503
        
        return json_response({
            "healthy": health['healthy'],
            "checks": {
                "api": self.is_running(),
                "agent_loop": self._agent_loop is not None,
            },
            "timestamp": datetime.utcnow().isoformat()
        }, status=status_code)
    
    async def _handle_memory_get(self, request: Request) -> Response:
        """
        Handle memory get endpoint.
        
        GET /api/v1/memory?type=fact&query=search
        """
        memory_type = request.query.get("type")
        query = request.query.get("query")
        
        # Would call memory manager
        return json_response({
            "memory": {
                "type": memory_type,
                "query": query,
                "results": [],  # Would come from memory manager
                "total_entries": 0,
            }
        })
    
    async def _handle_memory_post(self, request: Request) -> Response:
        """
        Handle memory write endpoint.
        
        POST /api/v1/memory
        Body: {"key": "key", "value": "value", "type": "fact"}
        """
        try:
            data = await request.json()
            
            # Would call memory manager to store
            return json_response({
                "success": True,
                "message": "Memory stored",
                "key": data.get("key"),
                "type": data.get("type", "fact"),
            })
            
        except Exception as e:
            return json_response({"error": str(e)}, status=500)
    
    async def _handle_tools_list(self, request: Request) -> Response:
        """
        Handle tools list endpoint.
        
        GET /api/v1/tools?category=file_ops
        """
        category = request.query.get("category")
        
        # Would call tool registry
        return json_response({
            "tools": [],  # Would come from tool registry
            "total": 0,
            "category": category,
        })
    
    async def _handle_tool_execute(self, request: Request) -> Response:
        """
        Handle tool execution endpoint.
        
        POST /api/v1/tools/execute
        Body: {"tool": "file_read", "parameters": {"path": "/tmp/file.txt"}}
        """
        try:
            data = await request.json()
            tool_name = data.get("tool")
            parameters = data.get("parameters", {})
            
            if not tool_name:
                return json_response(
                    {"error": "Tool name is required"},
                    status=400
                )
            
            # Would call tool executor
            return json_response({
                "success": True,
                "tool": tool_name,
                "result": None,  # Would come from executor
                "execution_time_ms": 0,
            })
            
        except Exception as e:
            return json_response({"error": str(e)}, status=500)
    
    async def _handle_command(self, request: Request) -> Response:
        """
        Handle direct command endpoint.
        
        POST /api/v1/command
        Body: {"command": "status", "args": []}
        """
        try:
            data = await request.json()
            command = data.get("command")
            args = data.get("args", [])
            
            if not command:
                return json_response(
                    {"error": "Command is required"},
                    status=400
                )
            
            # Process as a command message
            message = InterfaceMessage.create(
                content=f"/{command} {' '.join(args)}".strip(),
                interface_type=InterfaceType.API
            )
            message.is_command = True
            message.command_name = command
            message.command_args = args
            
            response = await self.process_message(message)
            
            return json_response({
                "success": response.success,
                "result": response.content,
                "errors": response.errors,
            })
            
        except Exception as e:
            return json_response({"error": str(e)}, status=500)
    
    async def _handle_info(self, request: Request) -> Response:
        """
        Handle info endpoint.
        
        GET /api/v1/info
        """
        return json_response({
            "agent": {
                "name": "Axiom",
                "version": "3.0.0",
                "description": "Autonomous AI Agent",
            },
            "api": {
                "version": self.api_version,
                "host": self.api_config.host,
                "port": self.api_config.port,
            },
            "features": {
                "memory_system": True,
                "tool_execution": True,
                "learning": True,
                "research": True,
            },
            "timestamp": datetime.utcnow().isoformat()
        })
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          MIDDLEWARE
    # ═══════════════════════════════════════════════════════════════════════════
    
    @web.middleware
    async def _error_middleware(self, request: Request, handler) -> Response:
        """Error handling middleware."""
        try:
            return await handler(request)
        except web.HTTPException:
            raise
        except Exception as e:
            self.logger.error(f"Request error: {e}", exc_info=True)
            return json_response(
                {"error": "Internal server error", "detail": str(e)},
                status=500
            )
    
    @web.middleware
    async def _cors_middleware(self, request: Request, handler) -> Response:
        """CORS middleware."""
        if not self.api_config.cors_enabled:
            return await handler(request)
            
        # Handle preflight
        if request.method == "OPTIONS":
            response = web.Response()
        else:
            response = await handler(request)
        
        # Add CORS headers
        origin = request.headers.get("Origin", "*")
        if "*" in self.api_config.cors_origins or origin in self.api_config.cors_origins:
            response.headers["Access-Control-Allow-Origin"] = origin
            response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
            response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization, X-API-Key"
            
        return response
    
    @web.middleware
    async def _auth_middleware(self, request: Request, handler) -> Response:
        """Authentication middleware."""
        if not self.api_config.api_key_required:
            return await handler(request)
            
        # Skip auth for health check
        if request.path.endswith("/health"):
            return await handler(request)
            
        api_key = request.headers.get("X-API-Key")
        
        if not api_key or api_key != self.api_config.api_key:
            return json_response(
                {"error": "Invalid or missing API key"},
                status=401
            )
            
        return await handler(request)
    
    @web.middleware
    async def _rate_limit_middleware(self, request: Request, handler) -> Response:
        """Rate limiting middleware."""
        if not self.api_config.rate_limit_enabled:
            return await handler(request)
            
        client_id = request.remote or "unknown"
        now = datetime.utcnow()
        
        # Clean old entries
        if client_id in self.request_counts:
            self.request_counts[client_id] = [
                t for t in self.request_counts[client_id]
                if (now - t).total_seconds() < 60
            ]
        else:
            self.request_counts[client_id] = []
        
        # Check rate limit
        if len(self.request_counts[client_id]) >= self.api_config.rate_limit_per_minute:
            return json_response(
                {"error": "Rate limit exceeded. Try again later."},
                status=429
            )
        
        # Record request
        self.request_counts[client_id].append(now)
        
        return await handler(request)


# ═══════════════════════════════════════════════════════════════════════════════
#                          STANDALONE EXECUTION
# ═══════════════════════════════════════════════════════════════════════════════

async def main():
    """Run API interface standalone (for testing)."""
    api = APIInterface()
    
    if await api.initialize():
        try:
            await api.start()
        except KeyboardInterrupt:
            await api.stop()
    else:
        print("Failed to initialize API interface")


if __name__ == "__main__":
    asyncio.run(main())