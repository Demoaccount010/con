#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 BASE INTERFACE - Abstract base class for all interfaces
═══════════════════════════════════════════════════════════════════════════════

 All interfaces (CLI, API, Telegram, etc.) inherit from this base.
 
 INTERFACE RESPONSIBILITIES:
 ───────────────────────────
 • Receive user input
 • Send to agent loop for processing
 • Format and display output
 • Handle interface-specific features
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Optional, Dict, Any, List, Callable, Awaitable
from dataclasses import dataclass, field
from enum import Enum
from uuid import uuid4


class InterfaceType(Enum):
    """Types of interfaces."""
    CLI = "cli"
    API = "api"
    TELEGRAM = "telegram"
    WEBSOCKET = "websocket"
    DISCORD = "discord"
    REPL = "repl"


class InterfaceState(Enum):
    """Interface states."""
    INITIALIZING = "initializing"
    READY = "ready"
    RUNNING = "running"
    PAUSED = "paused"
    STOPPING = "stopping"
    STOPPED = "stopped"
    ERROR = "error"


@dataclass
class InterfaceMessage:
    """
    Standardized message format across all interfaces.
    """
    id: str
    content: str
    interface_type: InterfaceType
    timestamp: datetime
    
    # Source info
    user_id: Optional[str] = None
    user_name: Optional[str] = None
    session_id: Optional[str] = None
    
    # Message metadata
    is_command: bool = False
    command_name: Optional[str] = None
    command_args: List[str] = field(default_factory=list)
    
    # Attachments (files, images, etc.)
    attachments: List[Dict[str, Any]] = field(default_factory=list)
    
    # Reply context
    reply_to: Optional[str] = None
    
    # Raw data from interface
    raw_data: Optional[Dict[str, Any]] = None
    
    @classmethod
    def create(
        cls,
        content: str,
        interface_type: InterfaceType,
        user_id: Optional[str] = None,
        user_name: Optional[str] = None
    ) -> 'InterfaceMessage':
        """Create a new message."""
        return cls(
            id=str(uuid4())[:8],
            content=content,
            interface_type=interface_type,
            timestamp=datetime.utcnow(),
            user_id=user_id,
            user_name=user_name
        )


@dataclass
class InterfaceResponse:
    """
    Standardized response format for all interfaces.
    """
    id: str
    content: str
    success: bool
    timestamp: datetime
    
    # Response metadata
    response_to: Optional[str] = None  # Message ID this responds to
    
    # Memory tags (for display)
    memory_tags: List[str] = field(default_factory=list)
    
    # Thinking/reasoning (if enabled)
    thinking: Optional[str] = None
    
    # Confidence level
    confidence: float = 0.0
    
    # Errors and warnings
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    
    # Attachments (files to send)
    attachments: List[Dict[str, Any]] = field(default_factory=list)
    
    # Interactive elements (buttons, keyboards)
    interactive: Optional[Dict[str, Any]] = None
    
    # Performance
    processing_time_ms: int = 0
    
    @classmethod
    def create(
        cls,
        content: str,
        success: bool = True,
        response_to: Optional[str] = None
    ) -> 'InterfaceResponse':
        """Create a new response."""
        return cls(
            id=str(uuid4())[:8],
            content=content,
            success=success,
            timestamp=datetime.utcnow(),
            response_to=response_to
        )
    
    @classmethod
    def error(cls, error_message: str, response_to: Optional[str] = None) -> 'InterfaceResponse':
        """Create an error response."""
        return cls(
            id=str(uuid4())[:8],
            content=f"❌ Error: {error_message}",
            success=False,
            timestamp=datetime.utcnow(),
            response_to=response_to,
            errors=[error_message]
        )


@dataclass
class InterfaceConfig:
    """Configuration for an interface."""
    interface_type: InterfaceType
    enabled: bool = True
    
    # Display settings
    show_thinking: bool = True
    show_memory_tags: bool = True
    show_confidence: bool = False
    show_timing: bool = False
    colored_output: bool = True
    
    # Behavior settings
    auto_start: bool = True
    persistent_session: bool = True
    
    # Interface-specific config
    extra: Dict[str, Any] = field(default_factory=dict)


class BaseInterface(ABC):
    """
    ═══════════════════════════════════════════════════════════════════════════
    ABSTRACT BASE INTERFACE
    ═══════════════════════════════════════════════════════════════════════════
    
    All interfaces must inherit from this class and implement:
    - initialize()
    - start()
    - stop()
    - send_response()
    
    The base class provides:
    - Common message processing
    - Session management
    - Hook system for extensibility
    """
    
    def __init__(
        self,
        interface_type: InterfaceType,
        config: Optional[InterfaceConfig] = None
    ):
        """
        Initialize base interface.
        
        Args:
            interface_type: Type of this interface
            config: Interface configuration
        """
        self.interface_type = interface_type
        self.config = config or InterfaceConfig(interface_type=interface_type)
        self.logger = logging.getLogger(f"interface.{interface_type.value}")
        
        # State
        self.state = InterfaceState.INITIALIZING
        self.started_at: Optional[datetime] = None
        
        # Session management
        self.session_id = str(uuid4())[:8]
        self.sessions: Dict[str, Dict[str, Any]] = {}
        
        # Agent loop reference (set by agent)
        self._agent_loop = None
        self._output_manager = None
        
        # Message history
        self.message_history: List[InterfaceMessage] = []
        self.max_history = 100
        
        # Hooks
        self._pre_process_hooks: List[Callable] = []
        self._post_process_hooks: List[Callable] = []
        self._error_hooks: List[Callable] = []
        
        # Statistics
        self.stats = {
            'messages_received': 0,
            'messages_sent': 0,
            'errors': 0,
            'avg_response_time_ms': 0
        }
        
    def set_agent_loop(self, agent_loop) -> None:
        """Set the agent loop for processing messages."""
        self._agent_loop = agent_loop
        
    def set_output_manager(self, output_manager) -> None:
        """Set the output manager for formatting."""
        self._output_manager = output_manager
        
    # ═══════════════════════════════════════════════════════════════════════════
    #                          ABSTRACT METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    @abstractmethod
    async def initialize(self) -> bool:
        """
        Initialize the interface.
        
        Returns:
            True if initialization successful
        """
        pass
    
    @abstractmethod
    async def start(self) -> None:
        """Start the interface and begin accepting input."""
        pass
    
    @abstractmethod
    async def stop(self) -> None:
        """Stop the interface gracefully."""
        pass
    
    @abstractmethod
    async def send_response(self, response: InterfaceResponse) -> bool:
        """
        Send a response through this interface.
        
        Args:
            response: The response to send
            
        Returns:
            True if sent successfully
        """
        pass
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          MESSAGE PROCESSING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def process_message(self, message: InterfaceMessage) -> InterfaceResponse:
        """
        Process an incoming message through the agent loop.
        
        Args:
            message: The incoming message
            
        Returns:
            Response from the agent
        """
        import time
        start_time = time.perf_counter()
        
        self.stats['messages_received'] += 1
        self.message_history.append(message)
        
        # Trim history if needed
        if len(self.message_history) > self.max_history:
            self.message_history = self.message_history[-self.max_history:]
        
        try:
            # Run pre-process hooks
            for hook in self._pre_process_hooks:
                message = await self._run_hook(hook, message)
                
            # Check if agent loop is available
            if not self._agent_loop:
                return InterfaceResponse.error(
                    "Agent not initialized",
                    response_to=message.id
                )
            
            # Process through agent loop
            result = await self._agent_loop.process(message.content)
            
            # Create response
            response = InterfaceResponse(
                id=str(uuid4())[:8],
                content=result.response,
                success=result.success,
                timestamp=datetime.utcnow(),
                response_to=message.id,
                memory_tags=self._extract_memory_tags(result.memory_changes),
                thinking=result.thinking_summary if self.config.show_thinking else None,
                confidence=result.confidence,
                errors=result.errors,
                warnings=result.warnings,
                processing_time_ms=result.total_duration_ms
            )
            
            # Run post-process hooks
            for hook in self._post_process_hooks:
                response = await self._run_hook(hook, response)
                
            # Update stats
            duration = int((time.perf_counter() - start_time) * 1000)
            self._update_response_time(duration)
            self.stats['messages_sent'] += 1
            
            return response
            
        except Exception as e:
            self.logger.error(f"Error processing message: {e}", exc_info=True)
            self.stats['errors'] += 1
            
            # Run error hooks
            for hook in self._error_hooks:
                await self._run_hook(hook, e, message)
                
            return InterfaceResponse.error(str(e), response_to=message.id)
    
    def _extract_memory_tags(self, memory_changes: List[Dict]) -> List[str]:
        """Extract memory tags from changes for display."""
        tags = []
        tag_map = {
            'SAVED': '🏷️ [MEMORY SAVED]',
            'UPDATED': '🔄 [MEMORY UPDATED]',
            'OVERWRITTEN': '♻️ [MEMORY OVERWRITTEN]',
            'VERIFIED': '✅ [MEMORY VERIFIED]',
            'LEARNED': '📚 [MEMORY LEARNED]',
            'CONFLICT': '⚠️ [MEMORY CONFLICT]',
            'ARCHIVED': '🗑️ [MEMORY ARCHIVED]',
            'PERMANENT': '📍 [MEMORY PERMANENT]',
            'HINT': '💡 [MEMORY HINT]',
            'DELETED': '❌ [MEMORY DELETED]'
        }
        
        for change in memory_changes:
            change_type = change.get('type', 'SAVED')
            tag = tag_map.get(change_type, f'[MEMORY {change_type}]')
            key = change.get('key', '')
            if key:
                tags.append(f"{tag} {key}")
            else:
                tags.append(tag)
                
        return tags
    
    def _update_response_time(self, duration_ms: int) -> None:
        """Update average response time."""
        n = self.stats['messages_received']
        if n == 1:
            self.stats['avg_response_time_ms'] = duration_ms
        else:
            current_avg = self.stats['avg_response_time_ms']
            self.stats['avg_response_time_ms'] = (current_avg * (n - 1) + duration_ms) / n
    
    async def _run_hook(self, hook: Callable, *args) -> Any:
        """Run a hook function."""
        try:
            if asyncio.iscoroutinefunction(hook):
                return await hook(*args)
            else:
                return hook(*args)
        except Exception as e:
            self.logger.error(f"Hook error: {e}")
            return args[0] if args else None
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          HOOK MANAGEMENT
    # ═══════════════════════════════════════════════════════════════════════════
    
    def add_pre_process_hook(self, hook: Callable) -> None:
        """Add a pre-processing hook."""
        self._pre_process_hooks.append(hook)
        
    def add_post_process_hook(self, hook: Callable) -> None:
        """Add a post-processing hook."""
        self._post_process_hooks.append(hook)
        
    def add_error_hook(self, hook: Callable) -> None:
        """Add an error handling hook."""
        self._error_hooks.append(hook)
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          SESSION MANAGEMENT
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_session(self, session_id: str) -> Dict[str, Any]:
        """Get or create a session."""
        if session_id not in self.sessions:
            self.sessions[session_id] = {
                'id': session_id,
                'created_at': datetime.utcnow(),
                'last_activity': datetime.utcnow(),
                'message_count': 0,
                'data': {}
            }
        return self.sessions[session_id]
    
    def update_session(self, session_id: str, **kwargs) -> None:
        """Update session data."""
        session = self.get_session(session_id)
        session['last_activity'] = datetime.utcnow()
        session['data'].update(kwargs)
    
    def clear_session(self, session_id: str) -> None:
        """Clear a session."""
        if session_id in self.sessions:
            del self.sessions[session_id]
    
    # ═══════════════════════════════════════════════════════════════════════════
    #                          UTILITY METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_stats(self) -> Dict[str, Any]:
        """Get interface statistics."""
        return {
            **self.stats,
            'interface_type': self.interface_type.value,
            'state': self.state.value,
            'session_id': self.session_id,
            'active_sessions': len(self.sessions),
            'uptime_seconds': (datetime.utcnow() - self.started_at).total_seconds() if self.started_at else 0
        }
    
    def is_ready(self) -> bool:
        """Check if interface is ready."""
        return self.state in [InterfaceState.READY, InterfaceState.RUNNING]
    
    def is_running(self) -> bool:
        """Check if interface is running."""
        return self.state == InterfaceState.RUNNING
    
    async def health_check(self) -> Dict[str, Any]:
        """Perform health check."""
        return {
            'interface': self.interface_type.value,
            'healthy': self.is_ready(),
            'state': self.state.value,
            'stats': self.get_stats()
        }
    
    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} type={self.interface_type.value} state={self.state.value}>"