"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                        CURIOSITY CONTROLLER                                   ║
║              Central Controller for Agent's Question-Asking System            ║
╚══════════════════════════════════════════════════════════════════════════════╝

The Curiosity Controller manages:
- When to ask questions vs. when to act
- Tracking asked questions (never repeat for known info)
- Learning from user answers
- Confirmation for dangerous actions
- Knowledge gap detection
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Callable, Awaitable, Set, Tuple
from dataclasses import dataclass, field
from enum import Enum
import hashlib
import json

logger = logging.getLogger(__name__)


class QuestionType(Enum):
    """Types of questions the agent can ask"""
    CLARIFICATION = "clarification"      # "Did you mean X or Y?"
    CONFIRMATION = "confirmation"        # "Are you sure you want to delete?"
    INFORMATION = "information"          # "What is your timezone?"
    PREFERENCE = "preference"            # "Would you prefer verbose output?"
    LEARNING = "learning"                # "Can you teach me about X?"
    VERIFICATION = "verification"        # "I found X, is this correct?"
    PERMISSION = "permission"            # "Can I access this file?"
    FEEDBACK = "feedback"                # "Was this helpful?"


class QuestionPriority(Enum):
    """Priority of questions"""
    CRITICAL = 1      # Must ask before proceeding
    HIGH = 2          # Should ask, but can proceed with defaults
    NORMAL = 3        # Nice to ask
    LOW = 4           # Optional, can skip
    BACKGROUND = 5    # Ask when idle


class QuestionStatus(Enum):
    """Status of a question"""
    PENDING = "pending"
    ASKED = "asked"
    ANSWERED = "answered"
    SKIPPED = "skipped"
    EXPIRED = "expired"
    CANCELLED = "cancelled"


@dataclass
class Question:
    """A question to ask the user"""
    id: str
    type: QuestionType
    priority: QuestionPriority
    text: str
    context: str
    options: Optional[List[str]] = None
    default_answer: Optional[str] = None
    
    # Metadata
    category: str = "general"
    tags: List[str] = field(default_factory=list)
    
    # Status
    status: QuestionStatus = QuestionStatus.PENDING
    asked_at: Optional[datetime] = None
    answered_at: Optional[datetime] = None
    answer: Optional[str] = None
    
    # Behavior
    remember_answer: bool = True        # Save answer for future
    ask_only_once: bool = True          # Never ask again if answered
    expires_in_minutes: Optional[int] = None
    requires_confirmation: bool = False
    
    # Tracking
    created_at: datetime = field(default_factory=datetime.now)
    ask_count: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "type": self.type.value,
            "priority": self.priority.value,
            "text": self.text,
            "context": self.context,
            "options": self.options,
            "default_answer": self.default_answer,
            "status": self.status.value,
            "answer": self.answer
        }


@dataclass
class Answer:
    """An answer to a question"""
    question_id: str
    value: str
    raw_input: str
    confidence: float = 1.0
    is_default: bool = False
    answered_at: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class KnownFact:
    """A fact learned from user answers"""
    key: str
    value: Any
    source: str  # question_id or "user_provided"
    category: str
    learned_at: datetime = field(default_factory=datetime.now)
    last_verified: Optional[datetime] = None
    verification_count: int = 0
    is_permanent: bool = False


@dataclass
class CuriosityConfig:
    """Configuration for curiosity system"""
    enabled: bool = True
    
    # Question behavior
    max_questions_per_interaction: int = 3
    ask_delay_seconds: float = 0.5
    question_timeout_minutes: int = 30
    
    # Confirmation thresholds
    always_confirm_destructive: bool = True
    confirm_threshold_confidence: float = 0.7
    
    # Learning behavior
    learn_from_corrections: bool = True
    learn_from_feedback: bool = True
    
    # Memory integration
    save_answers_to_memory: bool = True
    use_memory_for_answers: bool = True
    
    # First run questions
    first_run_questions_enabled: bool = True


class KnowledgeStore:
    """Store for learned knowledge from questions"""
    
    def __init__(self):
        self._facts: Dict[str, KnownFact] = {}
        self._categories: Dict[str, Set[str]] = {}
        self._lock = asyncio.Lock()
    
    async def store(self, fact: KnownFact) -> None:
        """Store a fact"""
        async with self._lock:
            self._facts[fact.key] = fact
            
            if fact.category not in self._categories:
                self._categories[fact.category] = set()
            self._categories[fact.category].add(fact.key)
    
    async def get(self, key: str) -> Optional[KnownFact]:
        """Get a fact by key"""
        return self._facts.get(key)
    
    async def get_value(self, key: str) -> Optional[Any]:
        """Get just the value"""
        fact = self._facts.get(key)
        return fact.value if fact else None
    
    async def has(self, key: str) -> bool:
        """Check if fact exists"""
        return key in self._facts
    
    async def get_by_category(self, category: str) -> List[KnownFact]:
        """Get all facts in category"""
        keys = self._categories.get(category, set())
        return [self._facts[k] for k in keys if k in self._facts]
    
    async def remove(self, key: str) -> bool:
        """Remove a fact"""
        async with self._lock:
            if key in self._facts:
                fact = self._facts.pop(key)
                if fact.category in self._categories:
                    self._categories[fact.category].discard(key)
                return True
            return False
    
    async def update(self, key: str, value: Any) -> bool:
        """Update fact value"""
        async with self._lock:
            if key in self._facts:
                self._facts[key].value = value
                self._facts[key].last_verified = datetime.now()
                self._facts[key].verification_count += 1
                return True
            return False
    
    async def get_all(self) -> List[KnownFact]:
        """Get all facts"""
        return list(self._facts.values())
    
    def to_dict(self) -> Dict[str, Any]:
        """Export as dict"""
        return {
            key: {
                "value": fact.value,
                "category": fact.category,
                "source": fact.source,
                "is_permanent": fact.is_permanent
            }
            for key, fact in self._facts.items()
        }


class QuestionQueue:
    """Queue for pending questions"""
    
    def __init__(self):
        self._queue: List[Question] = []
        self._asked: Dict[str, Question] = {}
        self._answered: Dict[str, Question] = {}
        self._lock = asyncio.Lock()
    
    async def add(self, question: Question) -> None:
        """Add question to queue"""
        async with self._lock:
            # Check for duplicates
            for q in self._queue:
                if q.id == question.id:
                    return
            
            self._queue.append(question)
            # Sort by priority
            self._queue.sort(key=lambda q: q.priority.value)
    
    async def get_next(self) -> Optional[Question]:
        """Get next question to ask"""
        async with self._lock:
            now = datetime.now()
            
            for i, question in enumerate(self._queue):
                # Skip expired questions
                if question.expires_in_minutes:
                    age = (now - question.created_at).total_seconds() / 60
                    if age > question.expires_in_minutes:
                        question.status = QuestionStatus.EXPIRED
                        continue
                
                if question.status == QuestionStatus.PENDING:
                    question.status = QuestionStatus.ASKED
                    question.asked_at = now
                    question.ask_count += 1
                    self._asked[question.id] = self._queue.pop(i)
                    return question
            
            return None
    
    async def mark_answered(
        self,
        question_id: str,
        answer: str
    ) -> Optional[Question]:
        """Mark question as answered"""
        async with self._lock:
            if question_id in self._asked:
                question = self._asked.pop(question_id)
                question.status = QuestionStatus.ANSWERED
                question.answered_at = datetime.now()
                question.answer = answer
                self._answered[question_id] = question
                return question
            return None
    
    async def cancel(self, question_id: str) -> bool:
        """Cancel a question"""
        async with self._lock:
            for i, q in enumerate(self._queue):
                if q.id == question_id:
                    q.status = QuestionStatus.CANCELLED
                    self._queue.pop(i)
                    return True
            
            if question_id in self._asked:
                self._asked[question_id].status = QuestionStatus.CANCELLED
                return True
            
            return False
    
    async def get_pending_count(self) -> int:
        """Get count of pending questions"""
        return len([q for q in self._queue if q.status == QuestionStatus.PENDING])
    
    async def clear_expired(self) -> int:
        """Clear expired questions"""
        async with self._lock:
            now = datetime.now()
            expired = []
            
            for i, q in enumerate(self._queue):
                if q.expires_in_minutes:
                    age = (now - q.created_at).total_seconds() / 60
                    if age > q.expires_in_minutes:
                        expired.append(i)
            
            for i in reversed(expired):
                self._queue[i].status = QuestionStatus.EXPIRED
                self._queue.pop(i)
            
            return len(expired)


class CuriosityController:
    """
    Central controller for the agent's curiosity and question-asking
    
    Features:
    - Smart question generation
    - Answer tracking and learning
    - Never repeat known questions
    - Confirmation for dangerous actions
    - Knowledge gap detection
    - First-run question handling
    """
    
    def __init__(
        self,
        config: Optional[CuriosityConfig] = None,
        memory_manager: Optional[Any] = None,
        question_generator: Optional[Any] = None,
        answer_processor: Optional[Any] = None
    ):
        self.config = config or CuriosityConfig()
        self.memory_manager = memory_manager
        self.question_generator = question_generator
        self.answer_processor = answer_processor
        
        # Components
        self._queue = QuestionQueue()
        self._knowledge = KnowledgeStore()
        
        # Tracking
        self._asked_questions: Set[str] = set()  # Hash of questions asked
        self._never_ask_again: Set[str] = set()  # Questions to never repeat
        
        # Callbacks
        self._on_question_callbacks: List[Callable] = []
        self._on_answer_callbacks: List[Callable] = []
        self._on_learning_callbacks: List[Callable] = []
        
        # State
        self._first_run_completed = False
        self._questions_this_session = 0
        
        # Statistics
        self._stats = {
            "total_questions_asked": 0,
            "total_answers_received": 0,
            "facts_learned": 0,
            "confirmations_requested": 0,
            "clarifications_requested": 0
        }
        
        logger.info("CuriosityController initialized")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # QUESTION MANAGEMENT
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def should_ask(
        self,
        question_key: str,
        question_type: QuestionType = QuestionType.INFORMATION
    ) -> bool:
        """Check if we should ask this question"""
        if not self.config.enabled:
            return False
        
        # Check if already known
        if await self._knowledge.has(question_key):
            return False
        
        # Check never ask again list
        if question_key in self._never_ask_again:
            return False
        
        # Check session limit
        if self._questions_this_session >= self.config.max_questions_per_interaction:
            if question_type not in [QuestionType.CONFIRMATION, QuestionType.CLARIFICATION]:
                return False
        
        return True
    
    async def ask(
        self,
        text: str,
        question_type: QuestionType = QuestionType.INFORMATION,
        priority: QuestionPriority = QuestionPriority.NORMAL,
        context: str = "",
        options: Optional[List[str]] = None,
        default: Optional[str] = None,
        key: Optional[str] = None,
        remember: bool = True,
        ask_once: bool = True,
        category: str = "general",
        tags: Optional[List[str]] = None
    ) -> Question:
        """
        Create and queue a question
        
        Args:
            text: The question text
            question_type: Type of question
            priority: Priority level
            context: Why we're asking
            options: Possible answers (for multiple choice)
            default: Default answer if user doesn't respond
            key: Unique key for this question/fact
            remember: Whether to save the answer
            ask_once: Never ask again if answered
            category: Category for organization
            tags: Tags for the question
        
        Returns:
            The created Question object
        """
        # Generate unique ID
        question_id = self._generate_question_id(text, key)
        
        question = Question(
            id=question_id,
            type=question_type,
            priority=priority,
            text=text,
            context=context,
            options=options,
            default_answer=default,
            category=category,
            tags=tags or [],
            remember_answer=remember,
            ask_only_once=ask_once
        )
        
        await self._queue.add(question)
        
        # Trigger callbacks
        for callback in self._on_question_callbacks:
            try:
                await callback(question)
            except Exception as e:
                logger.error(f"Question callback error: {e}")
        
        return question
    
    async def ask_clarification(
        self,
        ambiguous_input: str,
        options: List[str],
        context: str = ""
    ) -> Question:
        """Ask for clarification on ambiguous input"""
        self._stats["clarifications_requested"] += 1
        
        text = f"I'm not sure what you mean by '{ambiguous_input}'. Did you mean:"
        
        return await self.ask(
            text=text,
            question_type=QuestionType.CLARIFICATION,
            priority=QuestionPriority.HIGH,
            context=context,
            options=options,
            ask_once=False  # Clarifications can be repeated
        )
    
    async def ask_confirmation(
        self,
        action: str,
        details: str = "",
        is_destructive: bool = False
    ) -> Question:
        """Ask for confirmation before an action"""
        self._stats["confirmations_requested"] += 1
        
        if is_destructive:
            text = f"⚠️ DESTRUCTIVE ACTION: {action}"
            if details:
                text += f"\n{details}"
            text += "\n\nAre you absolutely sure? This cannot be undone."
            priority = QuestionPriority.CRITICAL
        else:
            text = f"Should I proceed with: {action}?"
            if details:
                text += f"\n{details}"
            priority = QuestionPriority.HIGH
        
        return await self.ask(
            text=text,
            question_type=QuestionType.CONFIRMATION,
            priority=priority,
            options=["Yes", "No"],
            default="No" if is_destructive else None,
            remember=False,
            ask_once=False
        )
    
    async def ask_permission(
        self,
        action: str,
        resource: str,
        reason: str = ""
    ) -> Question:
        """Ask for permission to perform an action"""
        text = f"May I {action} {resource}?"
        if reason:
            text += f"\nReason: {reason}"
        
        return await self.ask(
            text=text,
            question_type=QuestionType.PERMISSION,
            priority=QuestionPriority.HIGH,
            options=["Yes", "No", "Ask me each time"],
            remember=True,
            key=f"permission:{action}:{resource}"
        )
    
    async def ask_preference(
        self,
        preference_key: str,
        question_text: str,
        options: List[str],
        default: Optional[str] = None
    ) -> Question:
        """Ask about user preference"""
        return await self.ask(
            text=question_text,
            question_type=QuestionType.PREFERENCE,
            priority=QuestionPriority.NORMAL,
            options=options,
            default=default,
            key=f"preference:{preference_key}",
            category="preferences",
            remember=True,
            ask_once=True
        )
    
    async def ask_for_information(
        self,
        info_key: str,
        question_text: str,
        context: str = "",
        is_permanent: bool = False
    ) -> Question:
        """Ask for specific information"""
        return await self.ask(
            text=question_text,
            question_type=QuestionType.INFORMATION,
            priority=QuestionPriority.NORMAL,
            context=context,
            key=info_key,
            category="permanent" if is_permanent else "general",
            remember=True,
            ask_once=True
        )
    
    async def verify(
        self,
        statement: str,
        source: str = ""
    ) -> Question:
        """Ask user to verify information"""
        text = f"I believe: {statement}\nIs this correct?"
        if source:
            text = f"According to {source}:\n{statement}\nIs this correct?"
        
        return await self.ask(
            text=text,
            question_type=QuestionType.VERIFICATION,
            priority=QuestionPriority.NORMAL,
            options=["Yes, that's correct", "No, let me correct it"],
            remember=False,
            ask_once=False
        )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # ANSWER PROCESSING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def process_answer(
        self,
        question_id: str,
        raw_answer: str
    ) -> Optional[Answer]:
        """Process an answer to a question"""
        # Get the question
        question = await self._queue.mark_answered(question_id, raw_answer)
        
        if not question:
            logger.warning(f"No question found for id: {question_id}")
            return None
        
        # Parse the answer
        parsed_value = await self._parse_answer(question, raw_answer)
        
        answer = Answer(
            question_id=question_id,
            value=parsed_value,
            raw_input=raw_answer,
            confidence=1.0
        )
        
        # Learn from answer
        if question.remember_answer:
            await self._learn_from_answer(question, answer)
        
        # Mark as never ask again
        if question.ask_only_once:
            self._never_ask_again.add(question.id)
        
        # Update stats
        self._stats["total_answers_received"] += 1
        self._questions_this_session += 1
        
        # Trigger callbacks
        for callback in self._on_answer_callbacks:
            try:
                await callback(question, answer)
            except Exception as e:
                logger.error(f"Answer callback error: {e}")
        
        return answer
    
    async def _parse_answer(self, question: Question, raw_answer: str) -> Any:
        """Parse raw answer into appropriate value"""
        raw_lower = raw_answer.lower().strip()
        
        # Boolean answers
        if question.type in [QuestionType.CONFIRMATION, QuestionType.VERIFICATION]:
            if raw_lower in ['yes', 'y', 'yeah', 'yep', 'sure', 'ok', 'okay', 'confirm', '1', 'true']:
                return True
            elif raw_lower in ['no', 'n', 'nope', 'nah', 'cancel', '0', 'false']:
                return False
        
        # Option selection
        if question.options:
            # Check for exact match
            for i, option in enumerate(question.options):
                if raw_lower == option.lower():
                    return option
                # Check for number selection
                if raw_lower == str(i + 1):
                    return option
                # Check for partial match
                if raw_lower in option.lower():
                    return option
        
        # Return raw value
        return raw_answer.strip()
    
    async def _learn_from_answer(self, question: Question, answer: Answer) -> None:
        """Learn and store information from answer"""
        # Create fact key
        fact_key = question.id
        if ":" in question.id:
            fact_key = question.id.split(":", 1)[1]
        
        fact = KnownFact(
            key=fact_key,
            value=answer.value,
            source=question.id,
            category=question.category,
            is_permanent=question.category == "permanent"
        )
        
        await self._knowledge.store(fact)
        self._stats["facts_learned"] += 1
        
        # Store in memory if configured
        if self.config.save_answers_to_memory and self.memory_manager:
            try:
                memory_type = "permanent" if fact.is_permanent else "preference"
                await self.memory_manager.store_memory(
                    content={
                        "question": question.text,
                        "answer": answer.value,
                        "key": fact_key,
                        "category": question.category
                    },
                    memory_type=memory_type,
                    tags=["learned", "user_answer"] + question.tags
                )
            except Exception as e:
                logger.error(f"Failed to store answer in memory: {e}")
        
        # Trigger learning callbacks
        for callback in self._on_learning_callbacks:
            try:
                await callback(fact)
            except Exception as e:
                logger.error(f"Learning callback error: {e}")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # KNOWLEDGE ACCESS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def get_known_value(self, key: str) -> Optional[Any]:
        """Get a known value by key"""
        # Check local knowledge
        value = await self._knowledge.get_value(key)
        if value is not None:
            return value
        
        # Check memory if configured
        if self.config.use_memory_for_answers and self.memory_manager:
            try:
                memories = await self.memory_manager.search_memories(
                    query=key,
                    memory_type="preference",
                    limit=1
                )
                if memories:
                    content = memories[0].get("content", {})
                    if isinstance(content, dict):
                        return content.get("answer")
            except Exception:
                pass
        
        return None
    
    async def knows(self, key: str) -> bool:
        """Check if we know a value"""
        return await self._knowledge.has(key)
    
    async def get_or_ask(
        self,
        key: str,
        question_text: str,
        **kwargs
    ) -> Tuple[Optional[Any], Optional[Question]]:
        """Get known value or ask for it"""
        # Check if we already know
        value = await self.get_known_value(key)
        if value is not None:
            return value, None
        
        # Ask for it
        question = await self.ask_for_information(
            info_key=key,
            question_text=question_text,
            **kwargs
        )
        
        return None, question
    
    async def forget(self, key: str) -> bool:
        """Forget a learned fact"""
        return await self._knowledge.remove(key)
    
    async def update_knowledge(self, key: str, new_value: Any) -> bool:
        """Update a known value"""
        return await self._knowledge.update(key, new_value)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # FIRST RUN QUESTIONS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def run_first_run_questions(self) -> List[Question]:
        """Run first-run questions if not completed"""
        if self._first_run_completed:
            return []
        
        if not self.config.first_run_questions_enabled:
            self._first_run_completed = True
            return []
        
        questions = []
        
        # Owner name
        if not await self.knows("owner_name"):
            q = await self.ask_for_information(
                info_key="owner_name",
                question_text="What should I call you?",
                context="I'd like to know how to address you",
                is_permanent=True
            )
            questions.append(q)
        
        # Communication style
        if not await self.knows("communication_style"):
            q = await self.ask_preference(
                preference_key="communication_style",
                question_text="How would you like me to communicate?",
                options=["Casual & friendly", "Professional & formal", "Balanced"],
                default="Balanced"
            )
            questions.append(q)
        
        # Show reasoning
        if not await self.knows("show_reasoning"):
            q = await self.ask_preference(
                preference_key="show_reasoning",
                question_text="Should I explain my reasoning when answering?",
                options=["Yes, always", "Only when asked", "No, keep it brief"],
                default="Only when asked"
            )
            questions.append(q)
        
        # Notify learnings
        if not await self.knows("notify_learnings"):
            q = await self.ask_preference(
                preference_key="notify_learnings",
                question_text="Should I notify you when I learn something new?",
                options=["Yes", "Only important discoveries", "No"],
                default="Only important discoveries"
            )
            questions.append(q)
        
        self._first_run_completed = True
        return questions
    
    async def mark_first_run_complete(self) -> None:
        """Mark first run as complete"""
        self._first_run_completed = True
        
        # Store flag
        if self.memory_manager:
            await self.memory_manager.store_memory(
                content={"first_run_completed": True, "completed_at": datetime.now().isoformat()},
                memory_type="permanent",
                tags=["system", "first_run"]
            )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # QUESTION RETRIEVAL
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def get_next_question(self) -> Optional[Question]:
        """Get the next question to ask"""
        question = await self._queue.get_next()
        
        if question:
            self._stats["total_questions_asked"] += 1
            self._asked_questions.add(question.id)
        
        return question
    
    async def get_pending_questions(self) -> int:
        """Get count of pending questions"""
        return await self._queue.get_pending_count()
    
    async def cancel_question(self, question_id: str) -> bool:
        """Cancel a pending question"""
        return await self._queue.cancel(question_id)
    
    async def use_default_answer(self, question_id: str) -> Optional[Answer]:
        """Use default answer for a question"""
        # Find question in asked queue
        if question_id in self._queue._asked:
            question = self._queue._asked[question_id]
            if question.default_answer:
                answer = Answer(
                    question_id=question_id,
                    value=question.default_answer,
                    raw_input=question.default_answer,
                    is_default=True
                )
                await self._queue.mark_answered(question_id, question.default_answer)
                return answer
        return None
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CALLBACKS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def on_question(self, callback: Callable[[Question], Awaitable[None]]) -> None:
        """Register callback for new questions"""
        self._on_question_callbacks.append(callback)
    
    def on_answer(self, callback: Callable[[Question, Answer], Awaitable[None]]) -> None:
        """Register callback for answers"""
        self._on_answer_callbacks.append(callback)
    
    def on_learning(self, callback: Callable[[KnownFact], Awaitable[None]]) -> None:
        """Register callback for learned facts"""
        self._on_learning_callbacks.append(callback)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # UTILITIES
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _generate_question_id(self, text: str, key: Optional[str] = None) -> str:
        """Generate unique question ID"""
        if key:
            return f"q:{key}"
        
        # Hash the question text
        text_hash = hashlib.md5(text.encode()).hexdigest()[:8]
        return f"q:{text_hash}"
    
    async def reset_session(self) -> None:
        """Reset session counters"""
        self._questions_this_session = 0
    
    def get_stats(self) -> Dict[str, Any]:
        """Get curiosity statistics"""
        return {
            **self._stats,
            "pending_questions": len(self._queue._queue),
            "known_facts": len(self._knowledge._facts),
            "never_ask_again_count": len(self._never_ask_again),
            "first_run_completed": self._first_run_completed,
            "questions_this_session": self._questions_this_session
        }
    
    def get_known_facts(self) -> Dict[str, Any]:
        """Get all known facts"""
        return self._knowledge.to_dict()
    
    async def export_knowledge(self) -> Dict[str, Any]:
        """Export all learned knowledge"""
        facts = await self._knowledge.get_all()
        return {
            "facts": [
                {
                    "key": f.key,
                    "value": f.value,
                    "category": f.category,
                    "source": f.source,
                    "learned_at": f.learned_at.isoformat(),
                    "is_permanent": f.is_permanent
                }
                for f in facts
            ],
            "never_ask_again": list(self._never_ask_again),
            "exported_at": datetime.now().isoformat()
        }


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

async def create_curiosity_controller(
    memory_manager: Optional[Any] = None,
    **kwargs
) -> CuriosityController:
    """Create configured curiosity controller"""
    config = CuriosityConfig(**kwargs)
    
    controller = CuriosityController(
        config=config,
        memory_manager=memory_manager
    )
    
    return controller