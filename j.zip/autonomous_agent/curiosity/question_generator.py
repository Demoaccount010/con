"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                        QUESTION GENERATOR                                     ║
║                Smart Question Generation for Learning                         ║
╚══════════════════════════════════════════════════════════════════════════════╝

The Question Generator creates intelligent questions:
- Clarification questions when input is ambiguous
- Learning questions to fill knowledge gaps
- Contextual questions based on conversation
- Follow-up questions for deeper understanding
"""

import asyncio
import logging
import re
from datetime import datetime
from typing import Optional, Dict, Any, List, Tuple, Set
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)


class AmbiguityType(Enum):
    """Types of ambiguity in user input"""
    PRONOUN = "pronoun"           # "it", "that", "this"
    INCOMPLETE = "incomplete"      # Missing crucial info
    MULTIPLE_MEANINGS = "multiple_meanings"
    VAGUE_ACTION = "vague_action"  # "do something"
    UNCLEAR_TARGET = "unclear_target"
    TIME_AMBIGUITY = "time_ambiguity"
    QUANTITY_AMBIGUITY = "quantity_ambiguity"


class KnowledgeGapType(Enum):
    """Types of knowledge gaps"""
    OWNER_INFO = "owner_info"
    SYSTEM_CONFIG = "system_config"
    PREFERENCE = "preference"
    CONTEXT = "context"
    DOMAIN = "domain"
    PROCESS = "process"


@dataclass
class AmbiguityDetection:
    """Result of ambiguity detection"""
    is_ambiguous: bool
    ambiguity_type: Optional[AmbiguityType]
    ambiguous_part: Optional[str]
    possible_meanings: List[str]
    confidence: float
    context_needed: str


@dataclass
class KnowledgeGap:
    """A detected knowledge gap"""
    gap_type: KnowledgeGapType
    topic: str
    importance: float  # 0-1
    question_text: str
    context: str
    related_to: Optional[str] = None


@dataclass
class GeneratedQuestion:
    """A generated question"""
    text: str
    type: str
    options: Optional[List[str]]
    context: str
    priority: int
    tags: List[str]
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class GeneratorConfig:
    """Configuration for question generator"""
    # Ambiguity detection
    detect_pronouns: bool = True
    detect_vague_terms: bool = True
    detect_incomplete_commands: bool = True
    
    # Question generation
    max_options: int = 5
    include_context: bool = True
    
    # Thresholds
    ambiguity_threshold: float = 0.6
    importance_threshold: float = 0.5
    
    # LLM usage
    use_llm_for_generation: bool = True


class AmbiguityDetector:
    """Detect ambiguity in user input"""
    
    # Ambiguous pronouns
    PRONOUNS = {'it', 'this', 'that', 'these', 'those', 'they', 'them', 'he', 'she'}
    
    # Vague terms
    VAGUE_TERMS = {
        'something', 'stuff', 'things', 'everything', 'anything',
        'somewhere', 'somehow', 'sometime', 'soon', 'later',
        'maybe', 'probably', 'might', 'could', 'some', 'few'
    }
    
    # Incomplete action patterns
    INCOMPLETE_PATTERNS = [
        r'^(run|start|stop|restart|do|make|create|delete|remove|show|get|set)\s*$',
        r'^(the|a|an|my|your)\s+\w+\s*$',
        r'^(it|this|that)\s*$'
    ]
    
    # Multiple meaning words (context-dependent)
    POLYSEMOUS_WORDS = {
        'run': ['execute', 'sprint', 'manage'],
        'kill': ['terminate process', 'stop'],
        'check': ['verify', 'examine', 'search'],
        'clean': ['delete', 'format', 'organize'],
        'log': ['record', 'file', 'history'],
        'table': ['data structure', 'database table', 'format'],
        'head': ['beginning', 'header', 'git head'],
        'master': ['git master', 'primary', 'expert'],
        'branch': ['git branch', 'divide', 'section']
    }
    
    def __init__(self, config: Optional[GeneratorConfig] = None):
        self.config = config or GeneratorConfig()
    
    def detect(
        self,
        text: str,
        context: Optional[Dict[str, Any]] = None
    ) -> AmbiguityDetection:
        """Detect ambiguity in text"""
        text_lower = text.lower().strip()
        words = text_lower.split()
        
        # Check for pronoun ambiguity
        if self.config.detect_pronouns:
            pronoun_result = self._check_pronouns(text_lower, words, context)
            if pronoun_result.is_ambiguous:
                return pronoun_result
        
        # Check for incomplete commands
        if self.config.detect_incomplete_commands:
            incomplete_result = self._check_incomplete(text_lower)
            if incomplete_result.is_ambiguous:
                return incomplete_result
        
        # Check for vague terms
        if self.config.detect_vague_terms:
            vague_result = self._check_vague_terms(text_lower, words)
            if vague_result.is_ambiguous:
                return vague_result
        
        # Check for multiple meanings
        polysemy_result = self._check_polysemy(words, context)
        if polysemy_result.is_ambiguous:
            return polysemy_result
        
        # No ambiguity detected
        return AmbiguityDetection(
            is_ambiguous=False,
            ambiguity_type=None,
            ambiguous_part=None,
            possible_meanings=[],
            confidence=1.0,
            context_needed=""
        )
    
    def _check_pronouns(
        self,
        text: str,
        words: List[str],
        context: Optional[Dict]
    ) -> AmbiguityDetection:
        """Check for ambiguous pronoun usage"""
        for word in words:
            if word in self.PRONOUNS:
                # Check if context provides referent
                if context and context.get("last_subject"):
                    continue  # Pronoun has clear referent
                
                return AmbiguityDetection(
                    is_ambiguous=True,
                    ambiguity_type=AmbiguityType.PRONOUN,
                    ambiguous_part=word,
                    possible_meanings=[],
                    confidence=0.8,
                    context_needed=f"What does '{word}' refer to?"
                )
        
        return AmbiguityDetection(
            is_ambiguous=False,
            ambiguity_type=None,
            ambiguous_part=None,
            possible_meanings=[],
            confidence=1.0,
            context_needed=""
        )
    
    def _check_incomplete(self, text: str) -> AmbiguityDetection:
        """Check for incomplete commands"""
        for pattern in self.INCOMPLETE_PATTERNS:
            if re.match(pattern, text, re.IGNORECASE):
                return AmbiguityDetection(
                    is_ambiguous=True,
                    ambiguity_type=AmbiguityType.INCOMPLETE,
                    ambiguous_part=text,
                    possible_meanings=[],
                    confidence=0.9,
                    context_needed="The command seems incomplete. What should I do specifically?"
                )
        
        return AmbiguityDetection(
            is_ambiguous=False,
            ambiguity_type=None,
            ambiguous_part=None,
            possible_meanings=[],
            confidence=1.0,
            context_needed=""
        )
    
    def _check_vague_terms(
        self,
        text: str,
        words: List[str]
    ) -> AmbiguityDetection:
        """Check for vague terms"""
        for word in words:
            if word in self.VAGUE_TERMS:
                return AmbiguityDetection(
                    is_ambiguous=True,
                    ambiguity_type=AmbiguityType.VAGUE_ACTION,
                    ambiguous_part=word,
                    possible_meanings=[],
                    confidence=0.7,
                    context_needed=f"'{word}' is vague. Can you be more specific?"
                )
        
        return AmbiguityDetection(
            is_ambiguous=False,
            ambiguity_type=None,
            ambiguous_part=None,
            possible_meanings=[],
            confidence=1.0,
            context_needed=""
        )
    
    def _check_polysemy(
        self,
        words: List[str],
        context: Optional[Dict]
    ) -> AmbiguityDetection:
        """Check for words with multiple meanings"""
        for word in words:
            if word in self.POLYSEMOUS_WORDS:
                meanings = self.POLYSEMOUS_WORDS[word]
                
                # Check if context disambiguates
                if context:
                    domain = context.get("domain", "")
                    if domain in ["git", "code"] and word in ["branch", "head", "master"]:
                        continue  # Context disambiguates
                
                if len(meanings) > 1:
                    return AmbiguityDetection(
                        is_ambiguous=True,
                        ambiguity_type=AmbiguityType.MULTIPLE_MEANINGS,
                        ambiguous_part=word,
                        possible_meanings=meanings,
                        confidence=0.6,
                        context_needed=f"'{word}' has multiple meanings. Which do you mean?"
                    )
        
        return AmbiguityDetection(
            is_ambiguous=False,
            ambiguity_type=None,
            ambiguous_part=None,
            possible_meanings=[],
            confidence=1.0,
            context_needed=""
        )


class KnowledgeGapDetector:
    """Detect knowledge gaps that need to be filled"""
    
    # Essential owner information
    OWNER_INFO_KEYS = [
        "owner_name", "owner_timezone", "owner_language",
        "owner_preferred_name", "owner_communication_style"
    ]
    
    # System configuration
    SYSTEM_CONFIG_KEYS = [
        "default_shell", "preferred_editor", "project_directory",
        "backup_location", "log_level"
    ]
    
    # Preferences
    PREFERENCE_KEYS = [
        "show_reasoning", "notify_on_complete", "confirm_destructive",
        "verbose_output", "auto_save"
    ]
    
    def __init__(
        self,
        knowledge_store: Optional[Any] = None,
        memory_manager: Optional[Any] = None
    ):
        self.knowledge_store = knowledge_store
        self.memory_manager = memory_manager
    
    async def detect_gaps(
        self,
        context: Optional[Dict] = None
    ) -> List[KnowledgeGap]:
        """Detect knowledge gaps"""
        gaps = []
        
        # Check owner info gaps
        for key in self.OWNER_INFO_KEYS:
            if not await self._is_known(key):
                gap = self._create_gap_for_key(key, KnowledgeGapType.OWNER_INFO)
                if gap:
                    gaps.append(gap)
        
        # Check preference gaps
        for key in self.PREFERENCE_KEYS:
            if not await self._is_known(key):
                gap = self._create_gap_for_key(key, KnowledgeGapType.PREFERENCE)
                if gap:
                    gaps.append(gap)
        
        # Sort by importance
        gaps.sort(key=lambda g: g.importance, reverse=True)
        
        return gaps
    
    async def _is_known(self, key: str) -> bool:
        """Check if information is known"""
        if self.knowledge_store:
            return await self.knowledge_store.has(key)
        return False
    
    def _create_gap_for_key(
        self,
        key: str,
        gap_type: KnowledgeGapType
    ) -> Optional[KnowledgeGap]:
        """Create a knowledge gap for a specific key"""
        gap_info = self._get_gap_info(key)
        
        if not gap_info:
            return None
        
        return KnowledgeGap(
            gap_type=gap_type,
            topic=key,
            importance=gap_info["importance"],
            question_text=gap_info["question"],
            context=gap_info.get("context", "")
        )
    
    def _get_gap_info(self, key: str) -> Optional[Dict]:
        """Get question info for a knowledge gap"""
        gap_questions = {
            "owner_name": {
                "question": "What should I call you?",
                "importance": 0.9,
                "context": "I'd like to address you properly"
            },
            "owner_timezone": {
                "question": "What timezone are you in?",
                "importance": 0.7,
                "context": "This helps me schedule tasks correctly"
            },
            "owner_language": {
                "question": "What language do you prefer?",
                "importance": 0.6,
                "context": "I can communicate in your preferred language"
            },
            "show_reasoning": {
                "question": "Should I explain my reasoning?",
                "importance": 0.5,
                "context": "I can show or hide my thought process"
            },
            "notify_on_complete": {
                "question": "Should I notify you when tasks complete?",
                "importance": 0.5,
                "context": "For long-running tasks"
            },
            "confirm_destructive": {
                "question": "Should I always confirm destructive actions?",
                "importance": 0.8,
                "context": "Like file deletion or system changes"
            },
            "default_shell": {
                "question": "What shell do you prefer? (bash/zsh/fish/etc)",
                "importance": 0.4,
                "context": "For executing commands"
            },
            "preferred_editor": {
                "question": "What text editor do you prefer?",
                "importance": 0.3,
                "context": "When I need to open files for editing"
            }
        }
        
        return gap_questions.get(key)
    
    async def find_contextual_gaps(
        self,
        user_input: str,
        task_type: str
    ) -> List[KnowledgeGap]:
        """Find knowledge gaps based on current context"""
        gaps = []
        input_lower = user_input.lower()
        
        # File-related gaps
        if any(word in input_lower for word in ['file', 'save', 'write', 'create']):
            if not await self._is_known("default_directory"):
                gaps.append(KnowledgeGap(
                    gap_type=KnowledgeGapType.CONTEXT,
                    topic="default_directory",
                    importance=0.7,
                    question_text="Where should I save files by default?",
                    context="You mentioned file operations",
                    related_to=user_input
                ))
        
        # Backup-related gaps
        if 'backup' in input_lower:
            if not await self._is_known("backup_location"):
                gaps.append(KnowledgeGap(
                    gap_type=KnowledgeGapType.CONTEXT,
                    topic="backup_location",
                    importance=0.8,
                    question_text="Where should I store backups?",
                    context="You mentioned backup",
                    related_to=user_input
                ))
        
        # Time-related gaps
        if any(word in input_lower for word in ['schedule', 'remind', 'later', 'tomorrow']):
            if not await self._is_known("owner_timezone"):
                gaps.append(KnowledgeGap(
                    gap_type=KnowledgeGapType.CONTEXT,
                    topic="owner_timezone",
                    importance=0.9,
                    question_text="What timezone are you in?",
                    context="For scheduling accurately",
                    related_to=user_input
                ))
        
        return gaps


class QuestionGenerator:
    """
    Generate intelligent questions for the agent
    
    Features:
    - Ambiguity resolution questions
    - Knowledge gap questions
    - Contextual follow-up questions
    - Learning opportunity questions
    """
    
    def __init__(
        self,
        config: Optional[GeneratorConfig] = None,
        brain_controller: Optional[Any] = None,
        knowledge_store: Optional[Any] = None,
        memory_manager: Optional[Any] = None
    ):
        self.config = config or GeneratorConfig()
        self.brain_controller = brain_controller
        self.knowledge_store = knowledge_store
        self.memory_manager = memory_manager
        
        # Components
        self._ambiguity_detector = AmbiguityDetector(config)
        self._gap_detector = KnowledgeGapDetector(knowledge_store, memory_manager)
        
        # Statistics
        self._stats = {
            "questions_generated": 0,
            "ambiguity_questions": 0,
            "gap_questions": 0,
            "followup_questions": 0
        }
        
        logger.info("QuestionGenerator initialized")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # QUESTION GENERATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def generate_clarification(
        self,
        user_input: str,
        context: Optional[Dict] = None
    ) -> Optional[GeneratedQuestion]:
        """Generate clarification question if input is ambiguous"""
        detection = self._ambiguity_detector.detect(user_input, context)
        
        if not detection.is_ambiguous:
            return None
        
        if detection.confidence < self.config.ambiguity_threshold:
            return None
        
        self._stats["ambiguity_questions"] += 1
        self._stats["questions_generated"] += 1
        
        # Build question based on ambiguity type
        if detection.ambiguity_type == AmbiguityType.MULTIPLE_MEANINGS:
            return GeneratedQuestion(
                text=f"'{detection.ambiguous_part}' can mean different things. Which do you mean?",
                type="clarification",
                options=detection.possible_meanings[:self.config.max_options],
                context=f"Original input: {user_input}",
                priority=2,
                tags=["clarification", "ambiguity"],
                metadata={
                    "ambiguity_type": detection.ambiguity_type.value,
                    "original_input": user_input
                }
            )
        
        elif detection.ambiguity_type == AmbiguityType.PRONOUN:
            return GeneratedQuestion(
                text=detection.context_needed,
                type="clarification",
                options=None,
                context=f"Original input: {user_input}",
                priority=2,
                tags=["clarification", "pronoun"],
                metadata={
                    "ambiguity_type": detection.ambiguity_type.value,
                    "ambiguous_pronoun": detection.ambiguous_part
                }
            )
        
        elif detection.ambiguity_type == AmbiguityType.INCOMPLETE:
            return GeneratedQuestion(
                text=detection.context_needed,
                type="clarification",
                options=None,
                context=f"Incomplete command: {user_input}",
                priority=1,
                tags=["clarification", "incomplete"],
                metadata={
                    "ambiguity_type": detection.ambiguity_type.value
                }
            )
        
        else:
            return GeneratedQuestion(
                text=detection.context_needed,
                type="clarification",
                options=None,
                context=f"Original input: {user_input}",
                priority=2,
                tags=["clarification"],
                metadata={
                    "ambiguity_type": detection.ambiguity_type.value if detection.ambiguity_type else "unknown"
                }
            )
    
    async def generate_knowledge_questions(
        self,
        context: Optional[Dict] = None,
        max_questions: int = 3
    ) -> List[GeneratedQuestion]:
        """Generate questions to fill knowledge gaps"""
        gaps = await self._gap_detector.detect_gaps(context)
        
        questions = []
        for gap in gaps[:max_questions]:
            if gap.importance >= self.config.importance_threshold:
                self._stats["gap_questions"] += 1
                self._stats["questions_generated"] += 1
                
                questions.append(GeneratedQuestion(
                    text=gap.question_text,
                    type="knowledge_gap",
                    options=None,
                    context=gap.context,
                    priority=int(10 - gap.importance * 10),  # Higher importance = lower priority number
                    tags=["learning", gap.gap_type.value, gap.topic],
                    metadata={
                        "gap_type": gap.gap_type.value,
                        "topic": gap.topic
                    }
                ))
        
        return questions
    
    async def generate_contextual_questions(
        self,
        user_input: str,
        task_type: str,
        max_questions: int = 2
    ) -> List[GeneratedQuestion]:
        """Generate questions based on current context"""
        gaps = await self._gap_detector.find_contextual_gaps(user_input, task_type)
        
        questions = []
        for gap in gaps[:max_questions]:
            self._stats["questions_generated"] += 1
            
            questions.append(GeneratedQuestion(
                text=gap.question_text,
                type="contextual",
                options=None,
                context=gap.context,
                priority=int(10 - gap.importance * 10),
                tags=["contextual", gap.topic],
                metadata={
                    "related_to": gap.related_to,
                    "topic": gap.topic
                }
            ))
        
        return questions
    
    async def generate_confirmation_question(
        self,
        action: str,
        target: str,
        is_destructive: bool = False,
        details: Optional[str] = None
    ) -> GeneratedQuestion:
        """Generate confirmation question"""
        self._stats["questions_generated"] += 1
        
        if is_destructive:
            text = f"⚠️ DESTRUCTIVE: {action} {target}"
            if details:
                text += f"\n{details}"
            text += "\n\nThis cannot be undone. Proceed?"
            priority = 1
        else:
            text = f"Should I {action} {target}?"
            if details:
                text += f"\n{details}"
            priority = 2
        
        return GeneratedQuestion(
            text=text,
            type="confirmation",
            options=["Yes, proceed", "No, cancel"],
            context=f"Action: {action} on {target}",
            priority=priority,
            tags=["confirmation", "destructive" if is_destructive else "safe"],
            metadata={
                "action": action,
                "target": target,
                "is_destructive": is_destructive
            }
        )
    
    async def generate_followup_questions(
        self,
        topic: str,
        previous_answer: str,
        depth: int = 1
    ) -> List[GeneratedQuestion]:
        """Generate follow-up questions for deeper understanding"""
        if not self.brain_controller or not self.config.use_llm_for_generation:
            return []
        
        questions = []
        
        try:
            result = await self.brain_controller.think(
                f"""Based on the topic "{topic}" and the user's response "{previous_answer}",
generate {depth} follow-up question(s) to better understand the user's needs.
Keep questions concise and relevant.

Return as JSON array: [{{"question": "...", "purpose": "..."}}]""",
                context={"mode": "question_generation"}
            )
            
            if result.get("success"):
                import json
                response = result.get("response", "")
                
                # Try to parse JSON
                match = re.search(r'\[.*\]', response, re.DOTALL)
                if match:
                    parsed = json.loads(match.group())
                    
                    for item in parsed:
                        self._stats["followup_questions"] += 1
                        self._stats["questions_generated"] += 1
                        
                        questions.append(GeneratedQuestion(
                            text=item.get("question", ""),
                            type="followup",
                            options=None,
                            context=f"Following up on: {topic}",
                            priority=3,
                            tags=["followup", "learning"],
                            metadata={
                                "purpose": item.get("purpose", ""),
                                "original_topic": topic
                            }
                        ))
        
        except Exception as e:
            logger.error(f"Follow-up generation error: {e}")
        
        return questions
    
    async def generate_learning_question(
        self,
        topic: str,
        what_to_learn: str
    ) -> GeneratedQuestion:
        """Generate question to learn from user"""
        self._stats["questions_generated"] += 1
        
        return GeneratedQuestion(
            text=f"Can you teach me about {what_to_learn}?",
            type="learning",
            options=None,
            context=f"Topic: {topic}",
            priority=4,
            tags=["learning", topic.lower().replace(" ", "_")],
            metadata={
                "topic": topic,
                "learning_target": what_to_learn
            }
        )
    
    async def generate_verification_question(
        self,
        statement: str,
        source: Optional[str] = None,
        confidence: float = 0.5
    ) -> GeneratedQuestion:
        """Generate question to verify information"""
        self._stats["questions_generated"] += 1
        
        if source:
            text = f"According to {source}: {statement}\n\nIs this correct?"
        else:
            text = f"I believe: {statement}\n\nIs this correct?"
        
        return GeneratedQuestion(
            text=text,
            type="verification",
            options=["Yes, correct", "No, let me clarify", "I'm not sure"],
            context=f"Confidence: {confidence:.0%}",
            priority=3,
            tags=["verification"],
            metadata={
                "statement": statement,
                "source": source,
                "confidence": confidence
            }
        )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # ANALYSIS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def analyze_input(
        self,
        user_input: str,
        context: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Analyze input for potential questions"""
        detection = self._ambiguity_detector.detect(user_input, context)
        
        return {
            "is_ambiguous": detection.is_ambiguous,
            "ambiguity_type": detection.ambiguity_type.value if detection.ambiguity_type else None,
            "ambiguous_part": detection.ambiguous_part,
            "possible_meanings": detection.possible_meanings,
            "confidence": detection.confidence,
            "needs_clarification": detection.is_ambiguous and detection.confidence >= self.config.ambiguity_threshold,
            "suggested_question": detection.context_needed if detection.is_ambiguous else None
        }
    
    def get_stats(self) -> Dict[str, Any]:
        """Get generator statistics"""
        return {
            **self._stats,
            "config": {
                "use_llm": self.config.use_llm_for_generation,
                "ambiguity_threshold": self.config.ambiguity_threshold,
                "importance_threshold": self.config.importance_threshold
            }
        }


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

async def create_question_generator(
    brain_controller: Optional[Any] = None,
    knowledge_store: Optional[Any] = None,
    memory_manager: Optional[Any] = None,
    **kwargs
) -> QuestionGenerator:
    """Create configured question generator"""
    config = GeneratorConfig(**kwargs)
    
    generator = QuestionGenerator(
        config=config,
        brain_controller=brain_controller,
        knowledge_store=knowledge_store,
        memory_manager=memory_manager
    )
    
    return generator