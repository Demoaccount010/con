"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                         ANSWER PROCESSOR                                      ║
║              Process and Learn from User Answers                              ║
╚══════════════════════════════════════════════════════════════════════════════╝

The Answer Processor handles:
- Parsing user responses
- Extracting structured information
- Learning and storing knowledge
- Handling corrections
- Feedback processing
"""

import asyncio
import logging
import re
from datetime import datetime
from typing import Optional, Dict, Any, List, Tuple, Union
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)


class AnswerType(Enum):
    """Types of answers"""
    AFFIRMATIVE = "affirmative"
    NEGATIVE = "negative"
    SELECTION = "selection"
    TEXT = "text"
    NUMBER = "number"
    LIST = "list"
    CORRECTION = "correction"
    CLARIFICATION = "clarification"
    UNKNOWN = "unknown"


class AnswerConfidence(Enum):
    """Confidence levels for parsed answers"""
    HIGH = "high"           # 90%+
    MEDIUM = "medium"       # 70-90%
    LOW = "low"             # 50-70%
    UNCERTAIN = "uncertain" # <50%


@dataclass
class ParsedAnswer:
    """Result of answer parsing"""
    raw_input: str
    answer_type: AnswerType
    value: Any
    confidence: float
    confidence_level: AnswerConfidence
    alternatives: List[Any] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    @property
    def is_affirmative(self) -> bool:
        return self.answer_type == AnswerType.AFFIRMATIVE
    
    @property
    def is_negative(self) -> bool:
        return self.answer_type == AnswerType.NEGATIVE
    
    @property
    def is_high_confidence(self) -> bool:
        return self.confidence_level == AnswerConfidence.HIGH


@dataclass
class ExtractedInfo:
    """Information extracted from answer"""
    key: str
    value: Any
    data_type: str
    source: str
    confidence: float
    needs_verification: bool = False


@dataclass
class LearningResult:
    """Result of learning from answer"""
    learned: bool
    key: str
    value: Any
    previous_value: Optional[Any] = None
    is_update: bool = False
    is_correction: bool = False
    stored_in_memory: bool = False


@dataclass
class ProcessorConfig:
    """Configuration for answer processor"""
    # Parsing
    fuzzy_matching: bool = True
    extract_entities: bool = True
    handle_corrections: bool = True
    
    # Learning
    learn_from_answers: bool = True
    verify_before_storing: bool = False
    store_in_memory: bool = True
    
    # Confidence thresholds
    high_confidence_threshold: float = 0.9
    medium_confidence_threshold: float = 0.7
    low_confidence_threshold: float = 0.5
    
    # Entity extraction
    extract_names: bool = True
    extract_numbers: bool = True
    extract_dates: bool = True
    extract_paths: bool = True


class AnswerParser:
    """Parse and interpret user answers"""
    
    # Affirmative patterns
    AFFIRMATIVE_PATTERNS = [
        r'^y(es|ep|eah|up)?$',
        r'^(ok|okay|sure|fine|alright|right)$',
        r'^(confirm|confirmed|proceed|go ahead|do it)$',
        r'^(correct|true|affirmative|absolutely|definitely)$',
        r'^(1|one|first)$',
        r'^(accept|agree|approved)$'
    ]
    
    # Negative patterns
    NEGATIVE_PATTERNS = [
        r'^n(o|ope|ah)?$',
        r'^(cancel|stop|abort|halt|quit)$',
        r'^(wrong|incorrect|false|negative)$',
        r'^(0|zero|none)$',
        r'^(decline|reject|refused?|deny)$',
        r'^(don\'?t|do not|never)$'
    ]
    
    # Number patterns
    NUMBER_PATTERNS = [
        r'^-?\d+\.?\d*$',  # Decimal
        r'^-?\d+$',         # Integer
        r'^\d+(?:,\d{3})*$' # With commas
    ]
    
    # Selection patterns (option number)
    SELECTION_PATTERNS = [
        r'^(\d+)\.?\s*$',           # Just number
        r'^option\s*(\d+)$',        # "option 1"
        r'^choice\s*(\d+)$',        # "choice 1"
        r'^#(\d+)$',                # "#1"
        r'^(\d+)(?:st|nd|rd|th)$'   # "1st", "2nd"
    ]
    
    def __init__(self, config: Optional[ProcessorConfig] = None):
        self.config = config or ProcessorConfig()
        
        # Compile patterns
        self._affirmative_re = [re.compile(p, re.IGNORECASE) for p in self.AFFIRMATIVE_PATTERNS]
        self._negative_re = [re.compile(p, re.IGNORECASE) for p in self.NEGATIVE_PATTERNS]
        self._number_re = [re.compile(p) for p in self.NUMBER_PATTERNS]
        self._selection_re = [re.compile(p, re.IGNORECASE) for p in self.SELECTION_PATTERNS]
    
    def parse(
        self,
        raw_input: str,
        expected_type: Optional[AnswerType] = None,
        options: Optional[List[str]] = None
    ) -> ParsedAnswer:
        """Parse user answer"""
        cleaned = raw_input.strip()
        cleaned_lower = cleaned.lower()
        
        # Check for empty
        if not cleaned:
            return ParsedAnswer(
                raw_input=raw_input,
                answer_type=AnswerType.UNKNOWN,
                value=None,
                confidence=0.0,
                confidence_level=AnswerConfidence.UNCERTAIN
            )
        
        # Check for affirmative
        if self._is_affirmative(cleaned_lower):
            return ParsedAnswer(
                raw_input=raw_input,
                answer_type=AnswerType.AFFIRMATIVE,
                value=True,
                confidence=0.95,
                confidence_level=AnswerConfidence.HIGH
            )
        
        # Check for negative
        if self._is_negative(cleaned_lower):
            return ParsedAnswer(
                raw_input=raw_input,
                answer_type=AnswerType.NEGATIVE,
                value=False,
                confidence=0.95,
                confidence_level=AnswerConfidence.HIGH
            )
        
        # Check for selection from options
        if options:
            selection = self._parse_selection(cleaned, options)
            if selection:
                return selection
        
        # Check for number
        number_result = self._parse_number(cleaned)
        if number_result:
            return number_result
        
        # Check for correction pattern
        if self._is_correction(cleaned_lower):
            correction = self._parse_correction(cleaned)
            return ParsedAnswer(
                raw_input=raw_input,
                answer_type=AnswerType.CORRECTION,
                value=correction,
                confidence=0.8,
                confidence_level=AnswerConfidence.HIGH,
                metadata={"is_correction": True}
            )
        
        # Check for list
        if self._is_list(cleaned):
            items = self._parse_list(cleaned)
            return ParsedAnswer(
                raw_input=raw_input,
                answer_type=AnswerType.LIST,
                value=items,
                confidence=0.8,
                confidence_level=AnswerConfidence.MEDIUM
            )
        
        # Default to text
        return ParsedAnswer(
            raw_input=raw_input,
            answer_type=AnswerType.TEXT,
            value=cleaned,
            confidence=0.7,
            confidence_level=AnswerConfidence.MEDIUM
        )
    
    def _is_affirmative(self, text: str) -> bool:
        """Check if text is affirmative"""
        return any(pattern.match(text) for pattern in self._affirmative_re)
    
    def _is_negative(self, text: str) -> bool:
        """Check if text is negative"""
        return any(pattern.match(text) for pattern in self._negative_re)
    
    def _parse_number(self, text: str) -> Optional[ParsedAnswer]:
        """Parse numeric answer"""
        for pattern in self._number_re:
            if pattern.match(text):
                # Remove commas
                clean_num = text.replace(',', '')
                try:
                    if '.' in clean_num:
                        value = float(clean_num)
                    else:
                        value = int(clean_num)
                    
                    return ParsedAnswer(
                        raw_input=text,
                        answer_type=AnswerType.NUMBER,
                        value=value,
                        confidence=0.95,
                        confidence_level=AnswerConfidence.HIGH
                    )
                except ValueError:
                    pass
        
        return None
    
    def _parse_selection(
        self,
        text: str,
        options: List[str]
    ) -> Optional[ParsedAnswer]:
        """Parse selection from options"""
        text_lower = text.lower().strip()
        
        # Direct match with option
        for i, option in enumerate(options):
            if text_lower == option.lower():
                return ParsedAnswer(
                    raw_input=text,
                    answer_type=AnswerType.SELECTION,
                    value=option,
                    confidence=0.95,
                    confidence_level=AnswerConfidence.HIGH,
                    metadata={"selected_index": i}
                )
        
        # Number selection
        for pattern in self._selection_re:
            match = pattern.match(text)
            if match:
                try:
                    index = int(match.group(1)) - 1  # 1-based to 0-based
                    if 0 <= index < len(options):
                        return ParsedAnswer(
                            raw_input=text,
                            answer_type=AnswerType.SELECTION,
                            value=options[index],
                            confidence=0.9,
                            confidence_level=AnswerConfidence.HIGH,
                            metadata={"selected_index": index}
                        )
                except (ValueError, IndexError):
                    pass
        
        # Fuzzy match
        if self.config.fuzzy_matching:
            best_match = None
            best_score = 0.0
            
            for i, option in enumerate(options):
                score = self._fuzzy_score(text_lower, option.lower())
                if score > best_score and score > 0.6:
                    best_score = score
                    best_match = (i, option)
            
            if best_match:
                return ParsedAnswer(
                    raw_input=text,
                    answer_type=AnswerType.SELECTION,
                    value=best_match[1],
                    confidence=best_score,
                    confidence_level=self._score_to_level(best_score),
                    metadata={"selected_index": best_match[0], "fuzzy_match": True}
                )
        
        return None
    
    def _fuzzy_score(self, s1: str, s2: str) -> float:
        """Calculate fuzzy match score"""
        # Simple Jaccard similarity on words
        words1 = set(s1.split())
        words2 = set(s2.split())
        
        if not words1 or not words2:
            return 0.0
        
        intersection = len(words1 & words2)
        union = len(words1 | words2)
        
        return intersection / union if union > 0 else 0.0
    
    def _is_correction(self, text: str) -> bool:
        """Check if answer is a correction"""
        correction_patterns = [
            r'^(no,?\s+)?it\'?s\s+',
            r'^(actually|instead|rather)\s+',
            r'^(i meant|what i meant)\s+',
            r'^(correct(ion)?:?\s+)',
            r'^(not\s+.+,?\s+but\s+)'
        ]
        
        return any(re.match(p, text, re.IGNORECASE) for p in correction_patterns)
    
    def _parse_correction(self, text: str) -> str:
        """Extract corrected value from correction"""
        # Remove correction prefixes
        patterns = [
            r'^(no,?\s+)?it\'?s\s+',
            r'^(actually|instead|rather)\s+',
            r'^(i meant|what i meant)\s+',
            r'^(correct(ion)?:?\s+)',
        ]
        
        result = text
        for pattern in patterns:
            result = re.sub(pattern, '', result, flags=re.IGNORECASE)
        
        return result.strip()
    
    def _is_list(self, text: str) -> bool:
        """Check if answer is a list"""
        # Multiple items separated by comma, semicolon, or newline
        separators = [',', ';', '\n', ' and ', ' or ']
        return any(sep in text for sep in separators)
    
    def _parse_list(self, text: str) -> List[str]:
        """Parse list from answer"""
        # Split by common separators
        items = re.split(r'[,;\n]|\s+and\s+|\s+or\s+', text)
        return [item.strip() for item in items if item.strip()]
    
    def _score_to_level(self, score: float) -> AnswerConfidence:
        """Convert score to confidence level"""
        if score >= self.config.high_confidence_threshold:
            return AnswerConfidence.HIGH
        elif score >= self.config.medium_confidence_threshold:
            return AnswerConfidence.MEDIUM
        elif score >= self.config.low_confidence_threshold:
            return AnswerConfidence.LOW
        else:
            return AnswerConfidence.UNCERTAIN


class EntityExtractor:
    """Extract entities from answers"""
    
    # Name patterns
    NAME_PATTERNS = [
        r'^my name is\s+(.+)$',
        r'^i\'?m\s+(.+)$',
        r'^call me\s+(.+)$',
        r'^(.+)\s+is my name$'
    ]
    
    # Path patterns
    PATH_PATTERNS = [
        r'([/~][\w/.-]+)',
        r'([A-Za-z]:\\[\w\\.-]+)',
        r'(\.\.?/[\w/.-]+)'
    ]
    
    # Time patterns
    TIME_PATTERNS = [
        r'(\d{1,2}:\d{2}(?::\d{2})?(?:\s*[ap]m)?)',
        r'(\d{1,2}\s*[ap]m)',
    ]
    
    # Date patterns
    DATE_PATTERNS = [
        r'(\d{4}-\d{2}-\d{2})',
        r'(\d{1,2}/\d{1,2}/\d{2,4})',
        r'(\d{1,2}-\d{1,2}-\d{2,4})'
    ]
    
    def __init__(self, config: Optional[ProcessorConfig] = None):
        self.config = config or ProcessorConfig()
    
    def extract(self, text: str) -> List[ExtractedInfo]:
        """Extract all entities from text"""
        entities = []
        
        if self.config.extract_names:
            entities.extend(self._extract_names(text))
        
        if self.config.extract_paths:
            entities.extend(self._extract_paths(text))
        
        if self.config.extract_numbers:
            entities.extend(self._extract_numbers(text))
        
        if self.config.extract_dates:
            entities.extend(self._extract_dates(text))
        
        return entities
    
    def _extract_names(self, text: str) -> List[ExtractedInfo]:
        """Extract names from text"""
        entities = []
        
        for pattern in self.NAME_PATTERNS:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                name = match.group(1).strip()
                # Clean up name
                name = re.sub(r'[.,!?]$', '', name)
                
                entities.append(ExtractedInfo(
                    key="name",
                    value=name,
                    data_type="string",
                    source="name_pattern",
                    confidence=0.85
                ))
        
        return entities
    
    def _extract_paths(self, text: str) -> List[ExtractedInfo]:
        """Extract file paths from text"""
        entities = []
        
        for pattern in self.PATH_PATTERNS:
            matches = re.findall(pattern, text)
            for match in matches:
                entities.append(ExtractedInfo(
                    key="path",
                    value=match,
                    data_type="path",
                    source="path_pattern",
                    confidence=0.9
                ))
        
        return entities
    
    def _extract_numbers(self, text: str) -> List[ExtractedInfo]:
        """Extract numbers from text"""
        entities = []
        
        # Find all numbers
        matches = re.findall(r'\b\d+(?:\.\d+)?\b', text)
        
        for match in matches:
            try:
                if '.' in match:
                    value = float(match)
                else:
                    value = int(match)
                
                entities.append(ExtractedInfo(
                    key="number",
                    value=value,
                    data_type="number",
                    source="number_pattern",
                    confidence=0.95
                ))
            except ValueError:
                pass
        
        return entities
    
    def _extract_dates(self, text: str) -> List[ExtractedInfo]:
        """Extract dates from text"""
        entities = []
        
        for pattern in self.DATE_PATTERNS:
            matches = re.findall(pattern, text)
            for match in matches:
                entities.append(ExtractedInfo(
                    key="date",
                    value=match,
                    data_type="date",
                    source="date_pattern",
                    confidence=0.85
                ))
        
        return entities


class AnswerProcessor:
    """
    Process user answers and learn from them
    
    Features:
    - Answer parsing
    - Entity extraction
    - Learning from answers
    - Correction handling
    - Knowledge storage
    """
    
    def __init__(
        self,
        config: Optional[ProcessorConfig] = None,
        memory_manager: Optional[Any] = None,
        knowledge_store: Optional[Any] = None
    ):
        self.config = config or ProcessorConfig()
        self.memory_manager = memory_manager
        self.knowledge_store = knowledge_store
        
        # Components
        self._parser = AnswerParser(config)
        self._extractor = EntityExtractor(config)
        
        # Statistics
        self._stats = {
            "answers_processed": 0,
            "high_confidence_answers": 0,
            "corrections_processed": 0,
            "facts_learned": 0,
            "facts_updated": 0
        }
        
        logger.info("AnswerProcessor initialized")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MAIN PROCESSING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def process(
        self,
        raw_answer: str,
        question_context: Optional[Dict] = None,
        expected_type: Optional[AnswerType] = None,
        options: Optional[List[str]] = None
    ) -> ParsedAnswer:
        """
        Process a user answer
        
        Args:
            raw_answer: The raw user input
            question_context: Context from the question
            expected_type: Expected answer type
            options: Available options for selection
        
        Returns:
            ParsedAnswer with interpretation
        """
        self._stats["answers_processed"] += 1
        
        # Parse the answer
        parsed = self._parser.parse(raw_answer, expected_type, options)
        
        # Extract entities if text answer
        if parsed.answer_type == AnswerType.TEXT and self.config.extract_entities:
            entities = self._extractor.extract(raw_answer)
            parsed.metadata["extracted_entities"] = [
                {"key": e.key, "value": e.value, "type": e.data_type}
                for e in entities
            ]
        
        # Track high confidence
        if parsed.is_high_confidence:
            self._stats["high_confidence_answers"] += 1
        
        # Handle corrections
        if parsed.answer_type == AnswerType.CORRECTION:
            self._stats["corrections_processed"] += 1
        
        return parsed
    
    async def process_and_learn(
        self,
        raw_answer: str,
        question_key: str,
        question_context: Optional[Dict] = None,
        **kwargs
    ) -> Tuple[ParsedAnswer, Optional[LearningResult]]:
        """Process answer and learn from it"""
        # Parse
        parsed = await self.process(raw_answer, question_context, **kwargs)
        
        # Learn if configured
        learning_result = None
        if self.config.learn_from_answers:
            learning_result = await self._learn(question_key, parsed, question_context)
        
        return parsed, learning_result
    
    # ═══════════════════════════════════════════════════════════════════════════
    # LEARNING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _learn(
        self,
        key: str,
        parsed: ParsedAnswer,
        context: Optional[Dict]
    ) -> Optional[LearningResult]:
        """Learn from parsed answer"""
        if not self.config.learn_from_answers:
            return None
        
        # Check if needs verification
        if self.config.verify_before_storing:
            if parsed.confidence_level in [AnswerConfidence.LOW, AnswerConfidence.UNCERTAIN]:
                return LearningResult(
                    learned=False,
                    key=key,
                    value=parsed.value,
                    is_update=False,
                    is_correction=False
                )
        
        # Check for existing value
        previous_value = None
        is_update = False
        
        if self.knowledge_store:
            previous_value = await self.knowledge_store.get_value(key)
            is_update = previous_value is not None
        
        # Store in knowledge store
        if self.knowledge_store:
            if is_update:
                await self.knowledge_store.update(key, parsed.value)
                self._stats["facts_updated"] += 1
            else:
                from curiosity.curiosity_controller import KnownFact
                fact = KnownFact(
                    key=key,
                    value=parsed.value,
                    source="user_answer",
                    category=context.get("category", "general") if context else "general"
                )
                await self.knowledge_store.store(fact)
                self._stats["facts_learned"] += 1
        
        # Store in memory
        stored_in_memory = False
        if self.config.store_in_memory and self.memory_manager:
            try:
                await self.memory_manager.store_memory(
                    content={
                        "key": key,
                        "value": parsed.value,
                        "answer_type": parsed.answer_type.value,
                        "confidence": parsed.confidence
                    },
                    memory_type="preference" if "preference" in key else "fact",
                    tags=["learned", "user_answer"]
                )
                stored_in_memory = True
            except Exception as e:
                logger.error(f"Failed to store in memory: {e}")
        
        return LearningResult(
            learned=True,
            key=key,
            value=parsed.value,
            previous_value=previous_value,
            is_update=is_update,
            is_correction=parsed.answer_type == AnswerType.CORRECTION,
            stored_in_memory=stored_in_memory
        )
    
    async def process_correction(
        self,
        original_key: str,
        correction: str
    ) -> LearningResult:
        """Process a user correction"""
        self._stats["corrections_processed"] += 1
        
        # Parse the correction
        parsed = self._parser.parse(correction)
        corrected_value = parsed.value
        
        # Get previous value
        previous_value = None
        if self.knowledge_store:
            previous_value = await self.knowledge_store.get_value(original_key)
            await self.knowledge_store.update(original_key, corrected_value)
        
        # Update memory
        if self.memory_manager:
            try:
                # Store correction with context
                await self.memory_manager.store_memory(
                    content={
                        "key": original_key,
                        "old_value": previous_value,
                        "new_value": corrected_value,
                        "correction_reason": "user_correction"
                    },
                    memory_type="fact",
                    tags=["correction", "user_provided"]
                )
            except Exception as e:
                logger.error(f"Failed to store correction: {e}")
        
        self._stats["facts_updated"] += 1
        
        return LearningResult(
            learned=True,
            key=original_key,
            value=corrected_value,
            previous_value=previous_value,
            is_update=True,
            is_correction=True,
            stored_in_memory=True
        )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # VALIDATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    def validate_answer(
        self,
        parsed: ParsedAnswer,
        expected_type: Optional[AnswerType] = None,
        required: bool = False,
        min_confidence: float = 0.5
    ) -> Tuple[bool, Optional[str]]:
        """
        Validate a parsed answer
        
        Returns:
            Tuple of (is_valid, error_message)
        """
        # Check if required and empty
        if required and parsed.value is None:
            return False, "Answer is required"
        
        # Check type match
        if expected_type and parsed.answer_type != expected_type:
            # Allow some flexibility
            if expected_type == AnswerType.AFFIRMATIVE:
                if parsed.answer_type not in [AnswerType.AFFIRMATIVE, AnswerType.NEGATIVE]:
                    return False, f"Expected yes/no answer, got {parsed.answer_type.value}"
        
        # Check confidence
        if parsed.confidence < min_confidence:
            return False, f"Answer confidence too low ({parsed.confidence:.0%})"
        
        return True, None
    
    # ═══════════════════════════════════════════════════════════════════════════
    # FEEDBACK PROCESSING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def process_feedback(
        self,
        feedback_type: str,
        feedback_value: str,
        context: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Process user feedback"""
        result = {
            "processed": True,
            "feedback_type": feedback_type,
            "action_taken": None
        }
        
        parsed = self._parser.parse(feedback_value)
        
        if feedback_type == "rating":
            # Process rating feedback
            if parsed.answer_type == AnswerType.NUMBER:
                result["rating"] = parsed.value
                result["action_taken"] = "stored_rating"
        
        elif feedback_type == "helpful":
            # Was response helpful?
            result["was_helpful"] = parsed.is_affirmative
            result["action_taken"] = "stored_helpfulness"
        
        elif feedback_type == "correction":
            # User is correcting something
            if context and "key" in context:
                correction_result = await self.process_correction(
                    context["key"],
                    feedback_value
                )
                result["correction"] = correction_result
                result["action_taken"] = "applied_correction"
        
        elif feedback_type == "suggestion":
            # User is suggesting something
            if self.memory_manager:
                await self.memory_manager.store_memory(
                    content={
                        "suggestion": feedback_value,
                        "context": context
                    },
                    memory_type="preference",
                    tags=["feedback", "suggestion"]
                )
                result["action_taken"] = "stored_suggestion"
        
        return result
    
    # ═══════════════════════════════════════════════════════════════════════════
    # UTILITIES
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_stats(self) -> Dict[str, Any]:
        """Get processor statistics"""
        return {
            **self._stats,
            "config": {
                "fuzzy_matching": self.config.fuzzy_matching,
                "learn_from_answers": self.config.learn_from_answers,
                "extract_entities": self.config.extract_entities
            }
        }
    
    def extract_entities(self, text: str) -> List[Dict[str, Any]]:
        """Extract entities from text"""
        entities = self._extractor.extract(text)
        return [
            {
                "key": e.key,
                "value": e.value,
                "type": e.data_type,
                "confidence": e.confidence
            }
            for e in entities
        ]


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

async def create_answer_processor(
    memory_manager: Optional[Any] = None,
    knowledge_store: Optional[Any] = None,
    **kwargs
) -> AnswerProcessor:
    """Create configured answer processor"""
    config = ProcessorConfig(**kwargs)
    
    processor = AnswerProcessor(
        config=config,
        memory_manager=memory_manager,
        knowledge_store=knowledge_store
    )
    
    return processor