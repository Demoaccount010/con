#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 TAG RENDERER - VISUAL RENDERING OF MEMORY TAGS
═══════════════════════════════════════════════════════════════════════════════

 Renders memory operation tags for display in:
 • Console output
 • Telegram messages
 • Log files
 • API responses
 
 TAG TYPES:
 ──────────
 🏷️ [MEMORY SAVED]       → New information stored
 🔄 [MEMORY UPDATED]     → Existing information changed  
 ♻️ [MEMORY OVERWRITTEN] → Agent decided to rewrite (with reason)
 ✅ [MEMORY VERIFIED]    → Information verified against reality
 📚 [MEMORY LEARNED]     → Learned from research
 ⚠️ [MEMORY CONFLICT]    → Conflict detected (reality wins)
 🗑️ [MEMORY ARCHIVED]    → Old version archived
 📍 [MEMORY PERMANENT]   → Stored in permanent memory
 💡 [MEMORY HINT]        → Using as hint, not fact
 ❌ [MEMORY DELETED]     → Memory removed
 
 CONNECTS TO:
 ────────────
 • OutputManager        - For formatted output
 • MemoryNotifications  - For memory change events
 • TelegramFormatter    - For Telegram-specific formatting
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import logging
from typing import Dict, Any, List, Optional, Union
from dataclasses import dataclass
from enum import Enum
from datetime import datetime


class TagType(Enum):
    """Types of memory tags."""
    SAVED = "SAVED"
    UPDATED = "UPDATED"
    OVERWRITTEN = "OVERWRITTEN"
    VERIFIED = "VERIFIED"
    LEARNED = "LEARNED"
    CONFLICT = "CONFLICT"
    ARCHIVED = "ARCHIVED"
    PERMANENT = "PERMANENT"
    HINT = "HINT"
    DELETED = "DELETED"


class RenderFormat(Enum):
    """Output format for rendering."""
    CONSOLE = "console"
    TELEGRAM = "telegram"
    PLAIN = "plain"
    HTML = "html"
    MARKDOWN = "markdown"
    JSON = "json"


@dataclass
class MemoryTag:
    """
    A memory tag for display.
    
    This is the main data structure for memory operation tags.
    Used throughout the system to show visible memory operations.
    """
    tag_type: TagType
    key: str
    message: str
    
    # Optional details
    old_value: Optional[str] = None
    new_value: Optional[str] = None
    reason: Optional[str] = None
    memory_type: Optional[str] = None
    version: Optional[int] = None
    
    # Timestamp
    timestamp: datetime = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.utcnow()
            
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'tag_type': self.tag_type.value,
            'key': self.key,
            'message': self.message,
            'old_value': self.old_value,
            'new_value': self.new_value,
            'reason': self.reason,
            'memory_type': self.memory_type,
            'version': self.version,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
        }


class TagRenderer:
    """
    ═══════════════════════════════════════════════════════════════════════════
    MEMORY TAG RENDERER
    ═══════════════════════════════════════════════════════════════════════════
    
    Renders memory tags in various formats for different output channels.
    Ensures consistent, beautiful display of memory operations.
    """
    
    # Icons for each tag type
    TAG_ICONS = {
        TagType.SAVED: "🏷️",
        TagType.UPDATED: "🔄",
        TagType.OVERWRITTEN: "♻️",
        TagType.VERIFIED: "✅",
        TagType.LEARNED: "📚",
        TagType.CONFLICT: "⚠️",
        TagType.ARCHIVED: "🗑️",
        TagType.PERMANENT: "📍",
        TagType.HINT: "💡",
        TagType.DELETED: "❌",
    }
    
    # Label text for each tag type
    TAG_LABELS = {
        TagType.SAVED: "MEMORY SAVED",
        TagType.UPDATED: "MEMORY UPDATED",
        TagType.OVERWRITTEN: "MEMORY OVERWRITTEN",
        TagType.VERIFIED: "MEMORY VERIFIED",
        TagType.LEARNED: "MEMORY LEARNED",
        TagType.CONFLICT: "MEMORY CONFLICT",
        TagType.ARCHIVED: "MEMORY ARCHIVED",
        TagType.PERMANENT: "MEMORY PERMANENT",
        TagType.HINT: "MEMORY HINT",
        TagType.DELETED: "MEMORY DELETED",
    }
    
    # Colors for console output (ANSI codes)
    TAG_COLORS = {
        TagType.SAVED: "\033[92m",      # Green
        TagType.UPDATED: "\033[94m",     # Blue
        TagType.OVERWRITTEN: "\033[93m", # Yellow
        TagType.VERIFIED: "\033[92m",    # Green
        TagType.LEARNED: "\033[95m",     # Magenta
        TagType.CONFLICT: "\033[91m",    # Red
        TagType.ARCHIVED: "\033[90m",    # Gray
        TagType.PERMANENT: "\033[96m",   # Cyan
        TagType.HINT: "\033[33m",        # Orange/Brown
        TagType.DELETED: "\033[91m",     # Red
    }
    
    RESET_COLOR = "\033[0m"
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize the tag renderer.
        
        Args:
            config: Configuration dictionary
        """
        self.logger = logging.getLogger("output.tag_renderer")
        self.config = config or {}
        
        # Settings
        self.show_icons = self.config.get('show_icons', True)
        self.show_timestamps = self.config.get('show_timestamps', False)
        self.colorize_console = self.config.get('colorize_console', True)
        self.compact_mode = self.config.get('compact_mode', False)
        self.max_value_length = self.config.get('max_value_length', 50)
        
    def render(
        self,
        tag: MemoryTag,
        format: RenderFormat = RenderFormat.CONSOLE
    ) -> str:
        """
        Render a memory tag.
        
        Args:
            tag: The memory tag to render
            format: Output format
            
        Returns:
            Formatted tag string
        """
        if format == RenderFormat.CONSOLE:
            return self._render_console(tag)
        elif format == RenderFormat.TELEGRAM:
            return self._render_telegram(tag)
        elif format == RenderFormat.MARKDOWN:
            return self._render_markdown(tag)
        elif format == RenderFormat.HTML:
            return self._render_html(tag)
        elif format == RenderFormat.PLAIN:
            return self._render_plain(tag)
        elif format == RenderFormat.JSON:
            return self._render_json(tag)
        else:
            return self._render_plain(tag)
            
    def render_multiple(
        self,
        tags: List[MemoryTag],
        format: RenderFormat = RenderFormat.CONSOLE,
        separator: str = "\n"
    ) -> str:
        """
        Render multiple tags.
        
        Args:
            tags: List of memory tags
            format: Output format
            separator: Separator between tags
            
        Returns:
            Formatted tags string
        """
        rendered = [self.render(tag, format) for tag in tags]
        return separator.join(rendered)
        
    def _render_console(self, tag: MemoryTag) -> str:
        """Render for console with colors."""
        parts = []
        
        # Color start
        color = ""
        if self.colorize_console:
            color = self.TAG_COLORS.get(tag.tag_type, "")
            
        # Icon
        icon = self.TAG_ICONS.get(tag.tag_type, "•") if self.show_icons else ""
        
        # Label
        label = self.TAG_LABELS.get(tag.tag_type, tag.tag_type.value)
        
        # Build tag
        if self.compact_mode:
            parts.append(f"{color}{icon} [{label}]{self.RESET_COLOR if color else ''}")
            parts.append(f" {tag.key}")
            if tag.message and tag.message != tag.key:
                parts.append(f": {self._truncate(tag.message)}")
        else:
            parts.append(f"{color}{icon} [{label}]{self.RESET_COLOR if color else ''}")
            parts.append(f"\n   Key: {tag.key}")
            
            if tag.memory_type:
                parts.append(f"\n   Type: {tag.memory_type}")
                
            if tag.message:
                parts.append(f"\n   {tag.message}")
                
            if tag.old_value and tag.new_value:
                parts.append(f"\n   Change: '{self._truncate(tag.old_value)}' → '{self._truncate(tag.new_value)}'")
            elif tag.new_value:
                parts.append(f"\n   Value: {self._truncate(tag.new_value)}")
                
            if tag.reason:
                parts.append(f"\n   Reason: {tag.reason}")
                
            if tag.version:
                parts.append(f"\n   Version: {tag.version}")
                
            if self.show_timestamps and tag.timestamp:
                parts.append(f"\n   Time: {tag.timestamp.strftime('%H:%M:%S')}")
                
        return "".join(parts)
        
    def _render_telegram(self, tag: MemoryTag) -> str:
        """Render for Telegram with markdown."""
        parts = []
        
        # Icon and label
        icon = self.TAG_ICONS.get(tag.tag_type, "•") if self.show_icons else ""
        label = self.TAG_LABELS.get(tag.tag_type, tag.tag_type.value)
        
        parts.append(f"{icon} **[{label}]**")
        
        if tag.key:
            parts.append(f" `{tag.key}`")
            
        if tag.message and tag.message != tag.key:
            parts.append(f"\n{tag.message}")
            
        if tag.old_value and tag.new_value:
            parts.append(f"\n_'{self._truncate(tag.old_value, 30)}' → '{self._truncate(tag.new_value, 30)}'_")
            
        if tag.reason:
            parts.append(f"\n📝 {tag.reason}")
            
        return "".join(parts)
        
    def _render_markdown(self, tag: MemoryTag) -> str:
        """Render as Markdown."""
        parts = []
        
        icon = self.TAG_ICONS.get(tag.tag_type, "•") if self.show_icons else ""
        label = self.TAG_LABELS.get(tag.tag_type, tag.tag_type.value)
        
        parts.append(f"{icon} **[{label}]** `{tag.key}`")
        
        if tag.message:
            parts.append(f"\n> {tag.message}")
            
        if tag.old_value and tag.new_value:
            parts.append(f"\n- Change: `{self._truncate(tag.old_value)}` → `{self._truncate(tag.new_value)}`")
            
        if tag.reason:
            parts.append(f"\n- Reason: *{tag.reason}*")
            
        return "".join(parts)
        
    def _render_html(self, tag: MemoryTag) -> str:
        """Render as HTML."""
        icon = self.TAG_ICONS.get(tag.tag_type, "•") if self.show_icons else ""
        label = self.TAG_LABELS.get(tag.tag_type, tag.tag_type.value)
        
        # Color mapping for HTML
        colors = {
            TagType.SAVED: "#28a745",
            TagType.UPDATED: "#007bff",
            TagType.OVERWRITTEN: "#ffc107",
            TagType.VERIFIED: "#28a745",
            TagType.LEARNED: "#6f42c1",
            TagType.CONFLICT: "#dc3545",
            TagType.PERMANENT: "#17a2b8",
            TagType.HINT: "#fd7e14",
            TagType.DELETED: "#dc3545",
        }
        
        color = colors.get(tag.tag_type, "#6c757d")
        
        html = f'''<div class="memory-tag" style="border-left: 3px solid {color}; padding-left: 10px; margin: 5px 0;">
    <span class="tag-icon">{icon}</span>
    <strong style="color: {color};">[{label}]</strong>
    <code>{tag.key}</code>'''
        
        if tag.message:
            html += f'\n    <p>{tag.message}</p>'
            
        if tag.reason:
            html += f'\n    <small>Reason: {tag.reason}</small>'
            
        html += '\n</div>'
        
        return html
        
    def _render_plain(self, tag: MemoryTag) -> str:
        """Render as plain text (no formatting)."""
        label = self.TAG_LABELS.get(tag.tag_type, tag.tag_type.value)
        text = f"[{label}] {tag.key}"
        
        if tag.message and tag.message != tag.key:
            text += f": {tag.message}"
            
        if tag.reason:
            text += f" (Reason: {tag.reason})"
            
        return text
        
    def _render_json(self, tag: MemoryTag) -> str:
        """Render as JSON."""
        import json
        return json.dumps(tag.to_dict(), indent=2)
        
    def _truncate(self, value: Any, max_len: int = None) -> str:
        """Truncate value for display."""
        if value is None:
            return "None"
            
        max_len = max_len or self.max_value_length
        text = str(value)
        
        if len(text) > max_len:
            return text[:max_len - 3] + "..."
        return text
        
    # ═══════════════════════════════════════════════════════════════════════════
    # FACTORY METHODS FOR CREATING TAGS
    # ═══════════════════════════════════════════════════════════════════════════
    
    @staticmethod
    def create_saved_tag(
        key: str,
        value: Any,
        memory_type: str = "fact"
    ) -> MemoryTag:
        """Create a SAVED tag."""
        return MemoryTag(
            tag_type=TagType.SAVED,
            key=key,
            message=f"Saved {memory_type}: {key}",
            new_value=str(value),
            memory_type=memory_type
        )
        
    @staticmethod
    def create_updated_tag(
        key: str,
        old_value: Any,
        new_value: Any,
        memory_type: str = "fact"
    ) -> MemoryTag:
        """Create an UPDATED tag."""
        return MemoryTag(
            tag_type=TagType.UPDATED,
            key=key,
            message=f"Updated {memory_type}",
            old_value=str(old_value),
            new_value=str(new_value),
            memory_type=memory_type
        )
        
    @staticmethod
    def create_overwritten_tag(
        key: str,
        old_value: Any,
        new_value: Any,
        reason: str
    ) -> MemoryTag:
        """Create an OVERWRITTEN tag."""
        return MemoryTag(
            tag_type=TagType.OVERWRITTEN,
            key=key,
            message=f"Agent rewrote memory",
            old_value=str(old_value),
            new_value=str(new_value),
            reason=reason
        )
        
    @staticmethod
    def create_conflict_tag(
        key: str,
        memory_value: Any,
        reality_value: Any
    ) -> MemoryTag:
        """Create a CONFLICT tag."""
        return MemoryTag(
            tag_type=TagType.CONFLICT,
            key=key,
            message=f"Memory conflicts with reality - Reality wins!",
            old_value=str(memory_value),
            new_value=str(reality_value),
            reason="Reality always wins over memory"
        )
        
    @staticmethod
    def create_verified_tag(key: str, value: Any) -> MemoryTag:
        """Create a VERIFIED tag."""
        return MemoryTag(
            tag_type=TagType.VERIFIED,
            key=key,
            message=f"Verified against reality",
            new_value=str(value)
        )
        
    @staticmethod
    def create_permanent_tag(
        key: str,
        value: Any,
        memory_type: str = "permanent"
    ) -> MemoryTag:
        """Create a PERMANENT tag."""
        return MemoryTag(
            tag_type=TagType.PERMANENT,
            key=key,
            message=f"Stored in permanent memory (never forgotten)",
            new_value=str(value),
            memory_type=memory_type
        )
        
    @staticmethod
    def create_learned_tag(
        topic: str,
        knowledge: Any,
        source: str = "research"
    ) -> MemoryTag:
        """Create a LEARNED tag."""
        return MemoryTag(
            tag_type=TagType.LEARNED,
            key=topic,
            message=f"Learned from {source}",
            new_value=str(knowledge),
            memory_type="research"
        )
        
    @staticmethod
    def create_hint_tag(key: str, hint_value: Any) -> MemoryTag:
        """Create a HINT tag."""
        return MemoryTag(
            tag_type=TagType.HINT,
            key=key,
            message=f"Using as HINT only - will verify, not trust blindly",
            new_value=str(hint_value),
            reason="Memory is hint, not answer"
        )
        
    @staticmethod
    def create_deleted_tag(key: str, old_value: Any = None) -> MemoryTag:
        """Create a DELETED tag."""
        return MemoryTag(
            tag_type=TagType.DELETED,
            key=key,
            message=f"Memory removed",
            old_value=str(old_value) if old_value else None
        )
        
    # ═══════════════════════════════════════════════════════════════════════════
    # BATCH RENDERING
    # ═══════════════════════════════════════════════════════════════════════════
    
    def render_tag_summary(
        self,
        tags: List[MemoryTag],
        format: RenderFormat = RenderFormat.CONSOLE
    ) -> str:
        """
        Render a summary of multiple tags.
        
        Args:
            tags: List of memory tags
            format: Output format
            
        Returns:
            Formatted summary string
        """
        if not tags:
            return ""
            
        # Count by type
        type_counts = {}
        for tag in tags:
            type_name = tag.tag_type.value
            type_counts[type_name] = type_counts.get(type_name, 0) + 1
            
        # Build summary
        parts = [f"📊 Memory Operations Summary ({len(tags)} total)"]
        
        for tag_type in TagType:
            count = type_counts.get(tag_type.value, 0)
            if count > 0:
                icon = self.TAG_ICONS.get(tag_type, "•")
                label = self.TAG_LABELS.get(tag_type, tag_type.value)
                parts.append(f"  {icon} {label}: {count}")
                
        return "\n".join(parts)
        
    def render_change_log(
        self,
        tags: List[MemoryTag],
        format: RenderFormat = RenderFormat.CONSOLE
    ) -> str:
        """
        Render tags as a change log.
        
        Args:
            tags: List of memory tags
            format: Output format
            
        Returns:
            Formatted change log
        """
        if not tags:
            return "No memory changes."
            
        parts = ["═══ Memory Change Log ═══"]
        
        for i, tag in enumerate(tags, 1):
            rendered = self.render(tag, format)
            parts.append(f"\n{i}. {rendered}")
            
        parts.append("\n" + "═" * 25)
        
        return "\n".join(parts)


# ═══════════════════════════════════════════════════════════════════════════════
# SINGLETON INSTANCE FOR EASY ACCESS
# ═══════════════════════════════════════════════════════════════════════════════

_default_renderer: Optional[TagRenderer] = None


def get_tag_renderer(config: Dict[str, Any] = None) -> TagRenderer:
    """
    Get the default tag renderer instance.
    
    Args:
        config: Configuration (only used if creating new instance)
        
    Returns:
        TagRenderer instance
    """
    global _default_renderer
    
    if _default_renderer is None:
        _default_renderer = TagRenderer(config)
        
    return _default_renderer


def render_tag(tag: MemoryTag, format: RenderFormat = RenderFormat.CONSOLE) -> str:
    """
    Quick function to render a tag.
    
    Args:
        tag: Memory tag to render
        format: Output format
        
    Returns:
        Rendered tag string
    """
    return get_tag_renderer().render(tag, format)