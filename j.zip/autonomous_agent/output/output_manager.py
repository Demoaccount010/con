#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 OUTPUT MANAGER - BEAUTIFUL OUTPUT WITH MEMORY TAGS
═══════════════════════════════════════════════════════════════════════════════

 Handles ALL output formatting for the agent.
 
 KEY FEATURES:
 ─────────────
 • Beautiful formatted output
 • Memory tags [MEMORY SAVED], [MEMORY UPDATED], etc.
 • Color support (terminal)
 • Tables, trees, progress bars
 • Telegram-compatible formatting
 • Consistent styling across all outputs
 
 MEMORY TAGS:
 ────────────
 🏷️ [MEMORY SAVED]      → New information stored
 🔄 [MEMORY UPDATED]    → Existing information changed  
 ✅ [MEMORY VERIFIED]   → Information verified against reality
 📚 [MEMORY LEARNED]    → Learned from research
 ⚠️ [MEMORY CONFLICT]   → Conflict detected
 🗑️ [MEMORY ARCHIVED]   → Old version archived
 📍 [MEMORY PERMANENT]  → Stored in permanent memory
 💡 [MEMORY HINT]       → Using as hint, not fact
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import os
import sys
import shutil
from datetime import datetime
from typing import Optional, List, Dict, Any, Union
from enum import Enum
from dataclasses import dataclass


class Color(Enum):
    """Terminal colors."""
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    ITALIC = "\033[3m"
    UNDERLINE = "\033[4m"
    
    # Foreground colors
    BLACK = "\033[30m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"
    
    # Bright foreground
    BRIGHT_BLACK = "\033[90m"
    BRIGHT_RED = "\033[91m"
    BRIGHT_GREEN = "\033[92m"
    BRIGHT_YELLOW = "\033[93m"
    BRIGHT_BLUE = "\033[94m"
    BRIGHT_MAGENTA = "\033[95m"
    BRIGHT_CYAN = "\033[96m"
    BRIGHT_WHITE = "\033[97m"
    
    # Background colors
    BG_BLACK = "\033[40m"
    BG_RED = "\033[41m"
    BG_GREEN = "\033[42m"
    BG_YELLOW = "\033[43m"
    BG_BLUE = "\033[44m"
    BG_MAGENTA = "\033[45m"
    BG_CYAN = "\033[46m"
    BG_WHITE = "\033[47m"


class MemoryTag(Enum):
    """Memory operation tags."""
    SAVED = ("🏷️", "[MEMORY SAVED]", Color.GREEN)
    UPDATED = ("🔄", "[MEMORY UPDATED]", Color.YELLOW)
    VERIFIED = ("✅", "[MEMORY VERIFIED]", Color.GREEN)
    LEARNED = ("📚", "[MEMORY LEARNED]", Color.CYAN)
    CONFLICT = ("⚠️", "[MEMORY CONFLICT]", Color.RED)
    ARCHIVED = ("🗑️", "[MEMORY ARCHIVED]", Color.DIM)
    PERMANENT = ("📍", "[MEMORY PERMANENT]", Color.MAGENTA)
    HINT = ("💡", "[MEMORY HINT]", Color.BLUE)
    DELETED = ("❌", "[MEMORY DELETED]", Color.RED)
    OVERWRITTEN = ("♻️", "[MEMORY OVERWRITTEN]", Color.YELLOW)


class StatusIcon(Enum):
    """Status icons for different states."""
    SUCCESS = "✅"
    ERROR = "❌"
    WARNING = "⚠️"
    INFO = "ℹ️"
    THINKING = "🧠"
    PLANNING = "📋"
    EXECUTING = "⚡"
    OBSERVING = "👁️"
    RETHINKING = "🔄"
    COMPLETE = "✨"
    BLOCKED = "🚫"
    QUESTION = "❓"
    LEARNING = "📚"
    RESEARCH = "🔬"
    NOTIFICATION = "🔔"
    TELEGRAM = "📱"
    SYSTEM = "💻"
    NETWORK = "🌐"
    DATABASE = "🗃️"
    FILE = "📁"
    SECURITY = "🔐"
    TIME = "⏰"
    ROCKET = "🚀"
    BRAIN = "🧠"
    HEART = "❤️"
    STAR = "⭐"


@dataclass
class MemoryChange:
    """Represents a memory change for display."""
    tag: MemoryTag
    key: str
    old_value: Optional[Any] = None
    new_value: Optional[Any] = None
    reason: str = ""
    category: str = ""
    timestamp: datetime = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.utcnow()


class OutputManager:
    """
    ═══════════════════════════════════════════════════════════════════════════
    CENTRAL OUTPUT MANAGER
    ═══════════════════════════════════════════════════════════════════════════
    
    Handles all output formatting with consistent styling.
    Supports both terminal and Telegram outputs.
    """
    
    def __init__(self, use_colors: bool = True, telegram_mode: bool = False):
        """
        Initialize output manager.
        
        Args:
            use_colors: Enable terminal colors
            telegram_mode: Format for Telegram instead of terminal
        """
        self.use_colors = use_colors and self._supports_color()
        self.telegram_mode = telegram_mode
        self.terminal_width = self._get_terminal_width()
        
        # Pending memory changes to display
        self.pending_memory_changes: List[MemoryChange] = []
        
    async def initialize(self) -> None:
        """Initialize output manager."""
        pass  # No async initialization needed
        
    def _supports_color(self) -> bool:
        """Check if terminal supports colors."""
        # Check common indicators
        if os.environ.get('NO_COLOR'):
            return False
        if os.environ.get('FORCE_COLOR'):
            return True
        if not hasattr(sys.stdout, 'isatty'):
            return False
        if not sys.stdout.isatty():
            return False
        if os.environ.get('TERM') == 'dumb':
            return False
        return True
        
    def _get_terminal_width(self) -> int:
        """Get terminal width."""
        try:
            return shutil.get_terminal_size().columns
        except:
            return 80
            
    def _colorize(self, text: str, color: Color) -> str:
        """Apply color to text if colors enabled."""
        if not self.use_colors or self.telegram_mode:
            return text
        return f"{color.value}{text}{Color.RESET.value}"
        
    def _bold(self, text: str) -> str:
        """Make text bold."""
        if self.telegram_mode:
            return f"*{text}*"
        if self.use_colors:
            return f"{Color.BOLD.value}{text}{Color.RESET.value}"
        return text
        
    def _italic(self, text: str) -> str:
        """Make text italic."""
        if self.telegram_mode:
            return f"_{text}_"
        if self.use_colors:
            return f"{Color.ITALIC.value}{text}{Color.RESET.value}"
        return text
        
    def _code(self, text: str) -> str:
        """Format as code."""
        if self.telegram_mode:
            return f"`{text}`"
        return text
        
    def _code_block(self, text: str, language: str = "") -> str:
        """Format as code block."""
        if self.telegram_mode:
            return f"```{language}\n{text}\n```"
        return f"\n{text}\n"
        
    # ═══════════════════════════════════════════════════════════════════════
    # BASIC OUTPUT METHODS
    # ═══════════════════════════════════════════════════════════════════════
    
    def print(self, message: str) -> None:
        """Print a simple message."""
        print(message)
        
    def print_line(self) -> None:
        """Print a horizontal line."""
        if self.telegram_mode:
            print("─" * 30)
        else:
            print("─" * min(60, self.terminal_width))
            
    def print_divider(self, char: str = "═") -> None:
        """Print a divider line."""
        if self.telegram_mode:
            print(char * 30)
        else:
            print(char * min(60, self.terminal_width))
            
    def print_blank(self, count: int = 1) -> None:
        """Print blank lines."""
        for _ in range(count):
            print()
            
    # ═══════════════════════════════════════════════════════════════════════
    # FORMATTED OUTPUT METHODS
    # ═══════════════════════════════════════════════════════════════════════
    
    def print_header(self, title: str, icon: str = "📌") -> None:
        """Print a section header."""
        if self.telegram_mode:
            print(f"\n{icon} *{title}*\n")
        else:
            print()
            print(self._colorize(f"  {icon} {title}", Color.BOLD))
            print(self._colorize("  " + "─" * (len(title) + 4), Color.DIM))
            print()
            
    def print_subheader(self, title: str) -> None:
        """Print a subsection header."""
        if self.telegram_mode:
            print(f"\n_{title}_")
        else:
            print(self._colorize(f"\n  {title}", Color.CYAN))
            print()
            
    def print_success(self, message: str) -> None:
        """Print a success message."""
        icon = StatusIcon.SUCCESS.value
        if self.telegram_mode:
            print(f"{icon} {message}")
        else:
            colored = self._colorize(f"  {icon} {message}", Color.GREEN)
            print(colored)
            
    def print_error(self, message: str) -> None:
        """Print an error message."""
        icon = StatusIcon.ERROR.value
        if self.telegram_mode:
            print(f"{icon} {message}")
        else:
            colored = self._colorize(f"  {icon} {message}", Color.RED)
            print(colored)
            
    def print_warning(self, message: str) -> None:
        """Print a warning message."""
        icon = StatusIcon.WARNING.value
        if self.telegram_mode:
            print(f"{icon} {message}")
        else:
            colored = self._colorize(f"  {icon} {message}", Color.YELLOW)
            print(colored)
            
    def print_info(self, message: str) -> None:
        """Print an info message."""
        icon = StatusIcon.INFO.value
        if self.telegram_mode:
            print(f"{icon} {message}")
        else:
            colored = self._colorize(f"  {icon} {message}", Color.CYAN)
            print(colored)
            
    def print_status(self, message: str) -> None:
        """Print a status message (for loading/processing)."""
        if self.telegram_mode:
            print(f"⏳ {message}")
        else:
            colored = self._colorize(f"  ⏳ {message}", Color.DIM)
            print(colored)
            
    def print_bullet(self, message: str, indent: int = 1, icon: str = "•") -> None:
        """Print a bullet point."""
        prefix = "  " * indent
        print(f"{prefix}{icon} {message}")
        
    def print_numbered(self, items: List[str], start: int = 1) -> None:
        """Print a numbered list."""
        for i, item in enumerate(items, start):
            print(f"  {i}. {item}")
            
    def print_prompt(self) -> None:
        """Print the input prompt."""
        if self.telegram_mode:
            return  # No prompt in Telegram
            
        prompt = self._colorize("\n🤖 ", Color.CYAN)
        prompt += self._colorize("Agent", Color.BOLD)
        prompt += self._colorize(" > ", Color.DIM)
        print(prompt, end="", flush=True)
        
    # ═══════════════════════════════════════════════════════════════════════
    # MEMORY TAG METHODS - CRITICAL FOR VISIBILITY
    # ═══════════════════════════════════════════════════════════════════════
    
    def add_memory_change(self, change: MemoryChange) -> None:
        """Queue a memory change for display."""
        self.pending_memory_changes.append(change)
        
    def print_memory_tag(self, tag: MemoryTag, key: str, details: str = "") -> None:
        """
        Print a memory tag immediately.
        
        Example outputs:
        🏷️ [MEMORY SAVED] user_preference.theme = "dark"
        🔄 [MEMORY UPDATED] owner.timezone: UTC → IST
        """
        icon, label, color = tag.value
        
        if self.telegram_mode:
            text = f"{icon} `{label}` {key}"
            if details:
                text += f"\n   {details}"
            print(text)
        else:
            tag_text = self._colorize(f"{icon} {label}", color)
            key_text = self._colorize(key, Color.BOLD)
            
            print(f"\n  {tag_text} {key_text}")
            if details:
                print(self._colorize(f"     {details}", Color.DIM))
                
    def print_memory_saved(self, key: str, value: Any, category: str = "") -> None:
        """Print [MEMORY SAVED] tag."""
        value_str = self._format_value(value)
        details = f"= {value_str}"
        if category:
            details += f" (category: {category})"
        self.print_memory_tag(MemoryTag.SAVED, key, details)
        
    def print_memory_updated(
        self,
        key: str,
        old_value: Any,
        new_value: Any,
        reason: str = ""
    ) -> None:
        """Print [MEMORY UPDATED] tag."""
        old_str = self._format_value(old_value)
        new_str = self._format_value(new_value)
        details = f"{old_str} → {new_str}"
        if reason:
            details += f"\n     Reason: {reason}"
        self.print_memory_tag(MemoryTag.UPDATED, key, details)
        
    def print_memory_overwritten(
        self,
        key: str,
        old_value: Any,
        new_value: Any,
        reason: str = ""
    ) -> None:
        """Print [MEMORY OVERWRITTEN] tag (agent decision to rewrite)."""
        old_str = self._format_value(old_value)
        new_str = self._format_value(new_value)
        details = f"{old_str} → {new_str}"
        if reason:
            details += f"\n     Agent decision: {reason}"
        self.print_memory_tag(MemoryTag.OVERWRITTEN, key, details)
        
    def print_memory_verified(self, key: str, value: Any) -> None:
        """Print [MEMORY VERIFIED] tag."""
        value_str = self._format_value(value)
        self.print_memory_tag(MemoryTag.VERIFIED, key, f"confirmed: {value_str}")
        
    def print_memory_learned(self, key: str, value: Any, source: str = "") -> None:
        """Print [MEMORY LEARNED] tag."""
        value_str = self._format_value(value)
        details = f"= {value_str}"
        if source:
            details += f"\n     Source: {source}"
        self.print_memory_tag(MemoryTag.LEARNED, key, details)
        
    def print_memory_conflict(
        self,
        key: str,
        memory_value: Any,
        reality_value: Any
    ) -> None:
        """Print [MEMORY CONFLICT] tag."""
        mem_str = self._format_value(memory_value)
        real_str = self._format_value(reality_value)
        details = f"Memory: {mem_str} | Reality: {real_str}"
        self.print_memory_tag(MemoryTag.CONFLICT, key, details)
        
    def print_memory_permanent(self, key: str, value: Any) -> None:
        """Print [MEMORY PERMANENT] tag."""
        value_str = self._format_value(value)
        self.print_memory_tag(MemoryTag.PERMANENT, key, f"= {value_str} (never expires)")
        
    def print_memory_hint(self, key: str, value: Any) -> None:
        """Print [MEMORY HINT] tag."""
        value_str = self._format_value(value)
        self.print_memory_tag(MemoryTag.HINT, key, f"using as hint: {value_str}")
        
    def flush_memory_changes(self) -> None:
        """Print all pending memory changes."""
        if not self.pending_memory_changes:
            return
            
        self.print_subheader("Memory Changes")
        
        for change in self.pending_memory_changes:
            if change.old_value is not None and change.new_value is not None:
                self.print_memory_updated(
                    change.key,
                    change.old_value,
                    change.new_value,
                    change.reason
                )
            else:
                details = ""
                if change.new_value is not None:
                    details = f"= {self._format_value(change.new_value)}"
                if change.reason:
                    details += f" ({change.reason})"
                self.print_memory_tag(change.tag, change.key, details)
                
        self.pending_memory_changes.clear()
        
    def _format_value(self, value: Any, max_length: int = 50) -> str:
        """Format a value for display."""
        if value is None:
            return "null"
        if isinstance(value, str):
            if len(value) > max_length:
                return f'"{value[:max_length]}..."'
            return f'"{value}"'
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, (int, float)):
            return str(value)
        if isinstance(value, dict):
            return f"{{...}} ({len(value)} keys)"
        if isinstance(value, list):
            return f"[...] ({len(value)} items)"
        return str(value)[:max_length]
        
    # ═══════════════════════════════════════════════════════════════════════
    # AGENT RESPONSE OUTPUT
    # ═══════════════════════════════════════════════════════════════════════
    
    def print_response(self, result: Dict[str, Any]) -> None:
        """
        Print the complete agent response with all tags.
        
        This is the main method called after agent loop completes.
        """
        print()
        self.print_line()
        
        # Check if there are memory changes
        memory_changes = result.get('memory_changes', [])
        if memory_changes:
            for change in memory_changes:
                if isinstance(change, dict):
                    self.add_memory_change(MemoryChange(
                        tag=MemoryTag[change.get('type', 'SAVED').upper()],
                        key=change.get('key', ''),
                        old_value=change.get('old_value'),
                        new_value=change.get('new_value'),
                        reason=change.get('reason', '')
                    ))
                    
        # Print main response
        response_text = result.get('response', 'No response generated.')
        
        if self.telegram_mode:
            print(response_text)
        else:
            # Format response nicely
            for line in response_text.split('\n'):
                if line.strip():
                    print(f"  {line}")
                else:
                    print()
                    
        # Print memory changes
        self.flush_memory_changes()
        
        # Print errors if any
        errors = result.get('errors', [])
        if errors:
            print()
            self.print_warning("Issues encountered:")
            for error in errors:
                self.print_bullet(error, icon="⚠️")
                
        # Print thinking summary if available
        thinking = result.get('thinking_summary')
        if thinking:
            print()
            self.print_info(f"Reasoning: {thinking}")
            
        self.print_line()
        print()
        
    # ═══════════════════════════════════════════════════════════════════════
    # PHASE INDICATORS
    # ═══════════════════════════════════════════════════════════════════════
    
    def print_phase(self, phase: str, description: str = "") -> None:
        """Print current processing phase."""
        icons = {
            'thinking': StatusIcon.THINKING.value,
            'planning': StatusIcon.PLANNING.value,
            'executing': StatusIcon.EXECUTING.value,
            'observing': StatusIcon.OBSERVING.value,
            'rethinking': StatusIcon.RETHINKING.value,
            'complete': StatusIcon.COMPLETE.value,
        }
        
        icon = icons.get(phase.lower(), "▶️")
        phase_text = phase.upper()
        
        if self.telegram_mode:
            print(f"{icon} *{phase_text}*: {description}")
        else:
            phase_colored = self._colorize(f"{icon} {phase_text}", Color.CYAN)
            print(f"\n  {phase_colored}")
            if description:
                print(self._colorize(f"     {description}", Color.DIM))
                
    # ═══════════════════════════════════════════════════════════════════════
    # TABLE OUTPUT
    # ═══════════════════════════════════════════════════════════════════════
    
    def print_table(
        self,
        headers: List[str],
        rows: List[List[str]],
        title: str = ""
    ) -> None:
        """Print a formatted table."""
        if self.telegram_mode:
            # Simple Telegram format
            if title:
                print(f"*{title}*\n")
            print("```")
            print(" | ".join(headers))
            print("-" * 40)
            for row in rows:
                print(" | ".join(str(cell) for cell in row))
            print("```")
            return
            
        # Calculate column widths
        widths = [len(h) for h in headers]
        for row in rows:
            for i, cell in enumerate(row):
                widths[i] = max(widths[i], len(str(cell)))
                
        # Print title
        if title:
            self.print_header(title, icon="📊")
            
        # Print header
        header_line = "  │ " + " │ ".join(
            h.ljust(widths[i]) for i, h in enumerate(headers)
        ) + " │"
        separator = "  ├─" + "─┼─".join("─" * w for w in widths) + "─┤"
        top_border = "  ┌─" + "─┬─".join("─" * w for w in widths) + "─┐"
        bottom_border = "  └─" + "─┴─".join("─" * w for w in widths) + "─┘"
        
        print(top_border)
        print(self._colorize(header_line, Color.BOLD))
        print(separator)
        
        # Print rows
        for row in rows:
            row_line = "  │ " + " │ ".join(
                str(cell).ljust(widths[i]) for i, cell in enumerate(row)
            ) + " │"
            print(row_line)
            
        print(bottom_border)
        
    # ═══════════════════════════════════════════════════════════════════════
    # PROGRESS INDICATORS
    # ═══════════════════════════════════════════════════════════════════════
    
    def print_progress(
        self,
        current: int,
        total: int,
        label: str = "",
        width: int = 30
    ) -> None:
        """Print a progress bar."""
        if self.telegram_mode:
            percent = int(current / total * 100)
            print(f"⏳ {label}: {percent}% ({current}/{total})")
            return
            
        percent = current / total
        filled = int(width * percent)
        bar = "█" * filled + "░" * (width - filled)
        percent_text = f"{int(percent * 100):3d}%"
        
        line = f"\r  {label}: [{bar}] {percent_text} ({current}/{total})"
        print(line, end="", flush=True)
        
        if current >= total:
            print()  # Newline when complete
            
    # ═══════════════════════════════════════════════════════════════════════
    # THINKING/REASONING DISPLAY
    # ═══════════════════════════════════════════════════════════════════════
    
    def print_thinking(self, thoughts: List[str]) -> None:
        """Print agent's reasoning steps."""
        if not thoughts:
            return
            
        self.print_header("My Reasoning", icon="🧠")
        
        for i, thought in enumerate(thoughts, 1):
            if self.telegram_mode:
                print(f"{i}. {thought}")
            else:
                print(self._colorize(f"  {i}. {thought}", Color.DIM))
                
        print()
        
    def print_decision(self, decision: str, reason: str = "") -> None:
        """Print a decision with reasoning."""
        if self.telegram_mode:
            print(f"💭 *Decision:* {decision}")
            if reason:
                print(f"   _Reason: {reason}_")
        else:
            print(self._colorize(f"\n  💭 Decision: ", Color.CYAN) + self._bold(decision))
            if reason:
                print(self._colorize(f"     Reason: {reason}", Color.DIM))
                
    # ═══════════════════════════════════════════════════════════════════════
    # TELEGRAM-SPECIFIC FORMATTING
    # ═══════════════════════════════════════════════════════════════════════
    
    def format_for_telegram(self, text: str) -> str:
        """Format text for Telegram markdown."""
        # Escape special characters
        special_chars = ['_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!']
        
        result = text
        for char in special_chars:
            result = result.replace(char, f'\\{char}')
            
        return result
        
    def format_telegram_message(self, result: Dict[str, Any]) -> str:
        """Format complete response for Telegram."""
        lines = []
        
        # Response
        response = result.get('response', '')
        if response:
            lines.append(response)
            
        # Memory changes
        memory_changes = result.get('memory_changes', [])
        if memory_changes:
            lines.append("")
            for change in memory_changes:
                tag_type = change.get('type', 'SAVED')
                key = change.get('key', '')
                icon = {
                    'SAVED': '🏷️',
                    'UPDATED': '🔄',
                    'LEARNED': '📚',
                    'PERMANENT': '📍',
                }.get(tag_type, '🏷️')
                lines.append(f"{icon} `[MEMORY {tag_type}]` {key}")
                
        # Errors
        errors = result.get('errors', [])
        if errors:
            lines.append("")
            for error in errors:
                lines.append(f"⚠️ {error}")
                
        return "\n".join(lines)