"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                          RESEARCH ENGINE                                      ║
║               Autonomous Research and Knowledge Acquisition                   ║
╚══════════════════════════════════════════════════════════════════════════════╝

The research engine enables the agent to:
- Research topics autonomously
- Gather information from multiple sources
- Synthesize findings
- Detect new discoveries
- Update knowledge base
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Set
from dataclasses import dataclass, field
from enum import Enum
import hashlib
import json
import re
from abc import ABC, abstractmethod

logger = logging.getLogger(__name__)


class ResearchDepth(Enum):
    """Depth of research"""
    SHALLOW = "shallow"      # Quick overview
    BASIC = "basic"          # Standard research
    DEEP = "deep"            # Comprehensive research
    EXHAUSTIVE = "exhaustive" # Maximum depth


class SourceType(Enum):
    """Types of research sources"""
    WEB_SEARCH = "web_search"
    WIKIPEDIA = "wikipedia"
    DOCUMENTATION = "documentation"
    ACADEMIC = "academic"
    NEWS = "news"
    GITHUB = "github"
    STACKOVERFLOW = "stackoverflow"
    CUSTOM = "custom"


class ResearchStatus(Enum):
    """Status of research task"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    CACHED = "cached"


@dataclass
class ResearchSource:
    """A source of information"""
    type: SourceType
    name: str
    url: Optional[str] = None
    content: Optional[str] = None
    title: Optional[str] = None
    relevance_score: float = 0.0
    fetched_at: Optional[datetime] = None
    error: Optional[str] = None


@dataclass
class ResearchFinding:
    """A finding from research"""
    topic: str
    summary: str
    key_points: List[str]
    sources: List[ResearchSource]
    confidence: float
    is_discovery: bool = False
    importance: float = 0.5
    tags: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)


@dataclass
class ResearchTask:
    """A research task"""
    id: str
    topic: str
    depth: ResearchDepth
    status: ResearchStatus
    sources_requested: List[SourceType]
    max_sources: int
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    findings: Optional[ResearchFinding] = None
    error: Optional[str] = None


@dataclass
class ResearchConfig:
    """Configuration for research engine"""
    enabled: bool = True
    
    # Source configuration
    enabled_sources: List[SourceType] = field(default_factory=lambda: [
        SourceType.WEB_SEARCH,
        SourceType.WIKIPEDIA,
        SourceType.DOCUMENTATION
    ])
    
    # Limits
    max_concurrent_research: int = 2
    max_sources_per_research: int = 5
    max_content_length: int = 10000
    
    # Caching
    cache_enabled: bool = True
    cache_ttl_hours: int = 24
    
    # Discovery detection
    discovery_threshold: float = 0.7
    novelty_check_enabled: bool = True
    
    # Rate limiting
    rate_limit_per_minute: int = 10
    
    # Content filtering
    blocked_domains: List[str] = field(default_factory=list)
    required_keywords: List[str] = field(default_factory=list)


class ResearchProvider(ABC):
    """Abstract base for research providers"""
    
    @property
    @abstractmethod
    def source_type(self) -> SourceType:
        """Get source type"""
        pass
    
    @abstractmethod
    async def search(
        self,
        query: str,
        max_results: int = 5
    ) -> List[ResearchSource]:
        """Search for information"""
        pass
    
    @abstractmethod
    async def fetch_content(
        self,
        source: ResearchSource
    ) -> ResearchSource:
        """Fetch full content"""
        pass


class WebSearchProvider(ResearchProvider):
    """Web search provider (DuckDuckGo)"""
    
    def __init__(self, internet_manager: Optional[Any] = None):
        self.internet_manager = internet_manager
    
    @property
    def source_type(self) -> SourceType:
        return SourceType.WEB_SEARCH
    
    async def search(
        self,
        query: str,
        max_results: int = 5
    ) -> List[ResearchSource]:
        """Search the web"""
        sources = []
        
        try:
            if self.internet_manager:
                results = await self.internet_manager.search(
                    query=query,
                    max_results=max_results
                )
                
                for result in results:
                    sources.append(ResearchSource(
                        type=SourceType.WEB_SEARCH,
                        name=result.get("title", ""),
                        url=result.get("url"),
                        title=result.get("title"),
                        content=result.get("snippet")
                    ))
        except Exception as e:
            logger.error(f"Web search error: {e}")
        
        return sources
    
    async def fetch_content(
        self,
        source: ResearchSource
    ) -> ResearchSource:
        """Fetch full page content"""
        if not source.url or not self.internet_manager:
            return source
        
        try:
            content = await self.internet_manager.fetch_page(source.url)
            source.content = content[:10000] if content else None
            source.fetched_at = datetime.now()
        except Exception as e:
            source.error = str(e)
        
        return source


class WikipediaProvider(ResearchProvider):
    """Wikipedia research provider"""
    
    def __init__(self, internet_manager: Optional[Any] = None):
        self.internet_manager = internet_manager
        self.base_url = "https://en.wikipedia.org/api/rest_v1"
    
    @property
    def source_type(self) -> SourceType:
        return SourceType.WIKIPEDIA
    
    async def search(
        self,
        query: str,
        max_results: int = 5
    ) -> List[ResearchSource]:
        """Search Wikipedia"""
        sources = []
        
        try:
            if self.internet_manager:
                # Use Wikipedia API
                search_url = f"{self.base_url}/page/related/{query.replace(' ', '_')}"
                response = await self.internet_manager.fetch_json(search_url)
                
                if response and "pages" in response:
                    for page in response["pages"][:max_results]:
                        sources.append(ResearchSource(
                            type=SourceType.WIKIPEDIA,
                            name=page.get("title", ""),
                            url=f"https://en.wikipedia.org/wiki/{page.get('title', '').replace(' ', '_')}",
                            title=page.get("title"),
                            content=page.get("extract")
                        ))
        except Exception as e:
            logger.error(f"Wikipedia search error: {e}")
            
            # Fallback: create direct search source
            sources.append(ResearchSource(
                type=SourceType.WIKIPEDIA,
                name=query,
                url=f"https://en.wikipedia.org/wiki/{query.replace(' ', '_')}",
                title=query
            ))
        
        return sources
    
    async def fetch_content(
        self,
        source: ResearchSource
    ) -> ResearchSource:
        """Fetch Wikipedia article content"""
        if not source.title or not self.internet_manager:
            return source
        
        try:
            summary_url = f"{self.base_url}/page/summary/{source.title.replace(' ', '_')}"
            response = await self.internet_manager.fetch_json(summary_url)
            
            if response:
                source.content = response.get("extract", "")
                source.fetched_at = datetime.now()
        except Exception as e:
            source.error = str(e)
        
        return source


class DocumentationProvider(ResearchProvider):
    """Technical documentation provider"""
    
    def __init__(self, internet_manager: Optional[Any] = None):
        self.internet_manager = internet_manager
        self.doc_sources = {
            "python": "https://docs.python.org/3/search.html?q=",
            "nodejs": "https://nodejs.org/api/",
            "docker": "https://docs.docker.com/search/?q=",
            "kubernetes": "https://kubernetes.io/docs/search/?q="
        }
    
    @property
    def source_type(self) -> SourceType:
        return SourceType.DOCUMENTATION
    
    async def search(
        self,
        query: str,
        max_results: int = 5
    ) -> List[ResearchSource]:
        """Search documentation"""
        sources = []
        
        # Detect technology
        query_lower = query.lower()
        for tech, base_url in self.doc_sources.items():
            if tech in query_lower:
                sources.append(ResearchSource(
                    type=SourceType.DOCUMENTATION,
                    name=f"{tech.title()} Documentation",
                    url=f"{base_url}{query}",
                    title=f"{tech.title()}: {query}"
                ))
        
        return sources
    
    async def fetch_content(
        self,
        source: ResearchSource
    ) -> ResearchSource:
        """Fetch documentation content"""
        if not source.url or not self.internet_manager:
            return source
        
        try:
            content = await self.internet_manager.fetch_page(source.url)
            source.content = content[:10000] if content else None
            source.fetched_at = datetime.now()
        except Exception as e:
            source.error = str(e)
        
        return source


class ResearchCache:
    """Cache for research results"""
    
    def __init__(self, ttl_hours: int = 24):
        self.ttl_hours = ttl_hours
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._lock = asyncio.Lock()
    
    def _make_key(self, topic: str, depth: ResearchDepth) -> str:
        """Create cache key"""
        key_str = f"{topic}:{depth.value}"
        return hashlib.md5(key_str.encode()).hexdigest()
    
    async def get(
        self,
        topic: str,
        depth: ResearchDepth
    ) -> Optional[ResearchFinding]:
        """Get cached finding"""
        async with self._lock:
            key = self._make_key(topic, depth)
            
            if key not in self._cache:
                return None
            
            entry = self._cache[key]
            
            # Check expiry
            if datetime.now() > entry["expires_at"]:
                del self._cache[key]
                return None
            
            return entry["finding"]
    
    async def set(
        self,
        topic: str,
        depth: ResearchDepth,
        finding: ResearchFinding
    ) -> None:
        """Cache a finding"""
        async with self._lock:
            key = self._make_key(topic, depth)
            
            self._cache[key] = {
                "finding": finding,
                "expires_at": datetime.now() + timedelta(hours=self.ttl_hours)
            }
    
    async def clear(self) -> None:
        """Clear cache"""
        async with self._lock:
            self._cache.clear()
    
    async def cleanup(self) -> int:
        """Remove expired entries"""
        async with self._lock:
            now = datetime.now()
            expired = [
                key for key, entry in self._cache.items()
                if now > entry["expires_at"]
            ]
            
            for key in expired:
                del self._cache[key]
            
            return len(expired)


class ResearchSynthesizer:
    """Synthesize research findings"""
    
    def __init__(self, brain_controller: Optional[Any] = None):
        self.brain_controller = brain_controller
    
    async def synthesize(
        self,
        topic: str,
        sources: List[ResearchSource],
        existing_knowledge: Optional[str] = None
    ) -> ResearchFinding:
        """Synthesize information from multiple sources"""
        # Combine content from sources
        combined_content = []
        for source in sources:
            if source.content:
                combined_content.append(f"[{source.name}]:\n{source.content}")
        
        all_content = "\n\n---\n\n".join(combined_content)
        
        # Use brain to synthesize
        if self.brain_controller and all_content:
            try:
                result = await self.brain_controller.think(
                    f"""Synthesize the following information about "{topic}":

{all_content[:8000]}

Provide:
1. A concise summary (2-3 sentences)
2. 3-5 key points
3. Any notable insights or discoveries
4. Confidence level (0-1)

Format as JSON with keys: summary, key_points, insights, confidence""",
                    context={"mode": "synthesis", "topic": topic}
                )
                
                if result.get("success"):
                    response = result.get("response", "")
                    # Try to parse JSON from response
                    try:
                        # Find JSON in response
                        json_match = re.search(r'\{.*\}', response, re.DOTALL)
                        if json_match:
                            data = json.loads(json_match.group())
                            
                            return ResearchFinding(
                                topic=topic,
                                summary=data.get("summary", ""),
                                key_points=data.get("key_points", []),
                                sources=sources,
                                confidence=data.get("confidence", 0.5),
                                is_discovery=bool(data.get("insights")),
                                importance=data.get("confidence", 0.5),
                                tags=[topic.lower().replace(" ", "_")]
                            )
                    except json.JSONDecodeError:
                        pass
            except Exception as e:
                logger.error(f"Synthesis error: {e}")
        
        # Fallback: simple synthesis
        summary = ""
        key_points = []
        
        for source in sources:
            if source.content:
                if not summary:
                    summary = source.content[:500]
                # Extract sentences as key points
                sentences = source.content.split('.')[:3]
                key_points.extend([s.strip() + '.' for s in sentences if s.strip()])
        
        return ResearchFinding(
            topic=topic,
            summary=summary,
            key_points=key_points[:5],
            sources=sources,
            confidence=0.5,
            is_discovery=False,
            importance=0.5,
            tags=[topic.lower().replace(" ", "_")]
        )
    
    async def detect_discovery(
        self,
        finding: ResearchFinding,
        known_facts: List[str]
    ) -> bool:
        """Detect if finding contains new discovery"""
        if not self.brain_controller:
            return False
        
        try:
            result = await self.brain_controller.think(
                f"""Is the following information a new discovery or insight?

Topic: {finding.topic}
Finding: {finding.summary}

Known facts:
{chr(10).join(known_facts[:10])}

Answer YES or NO with brief explanation.""",
                context={"mode": "discovery_detection"}
            )
            
            response = result.get("response", "").lower()
            return "yes" in response
            
        except Exception as e:
            logger.error(f"Discovery detection error: {e}")
            return False


class ResearchEngine:
    """
    Main research engine for autonomous knowledge acquisition
    
    Features:
    - Multi-source research
    - Intelligent synthesis
    - Discovery detection
    - Caching and rate limiting
    - Knowledge integration
    """
    
    def __init__(
        self,
        config: Optional[ResearchConfig] = None,
        memory_manager: Optional[Any] = None,
        brain_controller: Optional[Any] = None,
        internet_manager: Optional[Any] = None
    ):
        self.config = config or ResearchConfig()
        self.memory_manager = memory_manager
        self.brain_controller = brain_controller
        self.internet_manager = internet_manager
        
        # Components
        self._cache = ResearchCache(ttl_hours=self.config.cache_ttl_hours)
        self._synthesizer = ResearchSynthesizer(brain_controller)
        self._providers: Dict[SourceType, ResearchProvider] = {}
        
        # State
        self._running_tasks: Dict[str, ResearchTask] = {}
        self._completed_tasks: List[ResearchTask] = []
        self._rate_limit_tokens: List[datetime] = []
        
        # Statistics
        self._stats = {
            "total_research": 0,
            "successful_research": 0,
            "failed_research": 0,
            "cache_hits": 0,
            "discoveries": 0
        }
        
        # Initialize providers
        self._init_providers()
        
        logger.info("ResearchEngine initialized")
    
    def _init_providers(self) -> None:
        """Initialize research providers"""
        if SourceType.WEB_SEARCH in self.config.enabled_sources:
            self._providers[SourceType.WEB_SEARCH] = WebSearchProvider(
                self.internet_manager
            )
        
        if SourceType.WIKIPEDIA in self.config.enabled_sources:
            self._providers[SourceType.WIKIPEDIA] = WikipediaProvider(
                self.internet_manager
            )
        
        if SourceType.DOCUMENTATION in self.config.enabled_sources:
            self._providers[SourceType.DOCUMENTATION] = DocumentationProvider(
                self.internet_manager
            )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MAIN RESEARCH API
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def research(
        self,
        topic: str,
        depth: str = "basic",
        max_sources: int = 5,
        source_types: Optional[List[SourceType]] = None
    ) -> Dict[str, Any]:
        """
        Research a topic
        
        Args:
            topic: Topic to research
            depth: Research depth (shallow, basic, deep, exhaustive)
            max_sources: Maximum number of sources to use
            source_types: Specific source types to use
        
        Returns:
            Research results dict
        """
        if not self.config.enabled:
            return {"success": False, "error": "Research disabled"}
        
        # Parse depth
        try:
            research_depth = ResearchDepth(depth)
        except ValueError:
            research_depth = ResearchDepth.BASIC
        
        # Check rate limit
        if not self._check_rate_limit():
            return {"success": False, "error": "Rate limited"}
        
        # Check cache
        if self.config.cache_enabled:
            cached = await self._cache.get(topic, research_depth)
            if cached:
                self._stats["cache_hits"] += 1
                return {
                    "success": True,
                    "topic": topic,
                    "findings": cached.summary,
                    "key_points": cached.key_points,
                    "sources": len(cached.sources),
                    "cached": True,
                    "confidence": cached.confidence
                }
        
        # Create task
        task_id = f"research_{datetime.now().timestamp()}"
        task = ResearchTask(
            id=task_id,
            topic=topic,
            depth=research_depth,
            status=ResearchStatus.PENDING,
            sources_requested=source_types or list(self.config.enabled_sources),
            max_sources=min(max_sources, self.config.max_sources_per_research),
            started_at=datetime.now()
        )
        
        self._running_tasks[task_id] = task
        self._stats["total_research"] += 1
        
        try:
            # Execute research
            finding = await self._execute_research(task)
            
            task.status = ResearchStatus.COMPLETED
            task.completed_at = datetime.now()
            task.findings = finding
            
            # Cache result
            if self.config.cache_enabled:
                await self._cache.set(topic, research_depth, finding)
            
            # Store in memory
            if self.memory_manager:
                await self._store_research(finding)
            
            # Check for discovery
            if self.config.novelty_check_enabled:
                is_discovery = await self._check_discovery(finding)
                finding.is_discovery = is_discovery
                if is_discovery:
                    self._stats["discoveries"] += 1
            
            self._stats["successful_research"] += 1
            
            return {
                "success": True,
                "topic": topic,
                "summary": finding.summary,
                "key_points": finding.key_points,
                "sources": len(finding.sources),
                "confidence": finding.confidence,
                "is_discovery": finding.is_discovery,
                "importance": finding.importance,
                "findings": finding.summary
            }
            
        except Exception as e:
            logger.error(f"Research failed: {e}")
            task.status = ResearchStatus.FAILED
            task.error = str(e)
            self._stats["failed_research"] += 1
            
            return {
                "success": False,
                "topic": topic,
                "error": str(e)
            }
        
        finally:
            del self._running_tasks[task_id]
            self._completed_tasks.append(task)
            
            # Keep only last 100 completed tasks
            if len(self._completed_tasks) > 100:
                self._completed_tasks = self._completed_tasks[-100:]
    
    async def quick_lookup(self, query: str) -> Optional[str]:
        """Quick lookup without full research"""
        # Try Wikipedia first
        if SourceType.WIKIPEDIA in self._providers:
            provider = self._providers[SourceType.WIKIPEDIA]
            sources = await provider.search(query, max_results=1)
            
            if sources:
                source = await provider.fetch_content(sources[0])
                if source.content:
                    return source.content[:1000]
        
        # Fall back to web search
        if SourceType.WEB_SEARCH in self._providers:
            provider = self._providers[SourceType.WEB_SEARCH]
            sources = await provider.search(query, max_results=1)
            
            if sources and sources[0].content:
                return sources[0].content
        
        return None
    
    async def explore_related(self, topic: str) -> List[str]:
        """Find related topics for exploration"""
        related = []
        
        if self.brain_controller:
            try:
                result = await self.brain_controller.think(
                    f"What are 5 related topics to explore after learning about '{topic}'? "
                    f"Return as JSON array of strings.",
                    context={"mode": "exploration"}
                )
                
                response = result.get("response", "")
                # Try to parse JSON array
                match = re.search(r'\[.*\]', response, re.DOTALL)
                if match:
                    related = json.loads(match.group())
            except Exception as e:
                logger.error(f"Related topics error: {e}")
        
        return related[:5]
    
    # ═══════════════════════════════════════════════════════════════════════════
    # INTERNAL METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _execute_research(self, task: ResearchTask) -> ResearchFinding:
        """Execute the research task"""
        task.status = ResearchStatus.IN_PROGRESS
        
        all_sources: List[ResearchSource] = []
        
        # Gather sources from all providers
        for source_type in task.sources_requested:
            if source_type not in self._providers:
                continue
            
            provider = self._providers[source_type]
            
            try:
                sources = await provider.search(
                    query=task.topic,
                    max_results=task.max_sources // len(task.sources_requested) + 1
                )
                
                # Fetch content for each source
                for source in sources:
                    fetched = await provider.fetch_content(source)
                    if fetched.content:
                        all_sources.append(fetched)
                
            except Exception as e:
                logger.error(f"Provider {source_type} error: {e}")
        
        if not all_sources:
            raise Exception("No sources found")
        
        # Limit sources
        all_sources = all_sources[:task.max_sources]
        
        # Score relevance
        for source in all_sources:
            source.relevance_score = self._score_relevance(
                source.content or "",
                task.topic
            )
        
        # Sort by relevance
        all_sources.sort(key=lambda s: s.relevance_score, reverse=True)
        
        # Get existing knowledge
        existing_knowledge = None
        if self.memory_manager:
            existing = await self.memory_manager.search_memories(
                query=task.topic,
                memory_type="fact",
                limit=5
            )
            if existing:
                existing_knowledge = "\n".join([
                    m.get("content", "") for m in existing
                ])
        
        # Synthesize findings
        finding = await self._synthesizer.synthesize(
            topic=task.topic,
            sources=all_sources,
            existing_knowledge=existing_knowledge
        )
        
        return finding
    
    def _score_relevance(self, content: str, topic: str) -> float:
        """Score content relevance to topic"""
        if not content:
            return 0.0
        
        content_lower = content.lower()
        topic_lower = topic.lower()
        topic_words = topic_lower.split()
        
        # Count topic word occurrences
        score = 0.0
        for word in topic_words:
            if len(word) > 2:  # Skip short words
                count = content_lower.count(word)
                score += min(count / 10.0, 1.0)  # Cap at 1.0 per word
        
        # Normalize
        score = min(score / len(topic_words), 1.0) if topic_words else 0.0
        
        return score
    
    async def _check_discovery(self, finding: ResearchFinding) -> bool:
        """Check if finding is a new discovery"""
        if not self.memory_manager:
            return False
        
        # Get known facts about topic
        known = await self.memory_manager.search_memories(
            query=finding.topic,
            memory_type="fact",
            limit=10
        )
        
        known_facts = [m.get("content", "") for m in known]
        
        return await self._synthesizer.detect_discovery(finding, known_facts)
    
    async def _store_research(self, finding: ResearchFinding) -> None:
        """Store research finding in memory"""
        if not self.memory_manager:
            return
        
        await self.memory_manager.store_memory(
            content={
                "topic": finding.topic,
                "summary": finding.summary,
                "key_points": finding.key_points,
                "confidence": finding.confidence,
                "is_discovery": finding.is_discovery,
                "source_count": len(finding.sources)
            },
            memory_type="research",
            tags=["research", "autonomous"] + finding.tags,
            metadata={
                "created_at": finding.created_at.isoformat(),
                "importance": finding.importance
            }
        )
    
    def _check_rate_limit(self) -> bool:
        """Check if we're within rate limits"""
        now = datetime.now()
        
        # Remove old tokens
        self._rate_limit_tokens = [
            t for t in self._rate_limit_tokens
            if (now - t).total_seconds() < 60
        ]
        
        if len(self._rate_limit_tokens) >= self.config.rate_limit_per_minute:
            return False
        
        self._rate_limit_tokens.append(now)
        return True
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MANAGEMENT API
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def health_check(self) -> bool:
        """Check engine health"""
        try:
            # Check at least one provider works
            for provider in self._providers.values():
                try:
                    results = await provider.search("test", max_results=1)
                    return True
                except Exception:
                    continue
            return False
        except Exception:
            return False
    
    async def clear_cache(self) -> None:
        """Clear research cache"""
        await self._cache.clear()
    
    def get_stats(self) -> Dict[str, Any]:
        """Get engine statistics"""
        return {
            **self._stats,
            "running_tasks": len(self._running_tasks),
            "completed_tasks": len(self._completed_tasks),
            "providers": list(self._providers.keys()),
            "enabled": self.config.enabled
        }
    
    def get_running_tasks(self) -> List[Dict[str, Any]]:
        """Get running tasks"""
        return [
            {
                "id": t.id,
                "topic": t.topic,
                "depth": t.depth.value,
                "status": t.status.value,
                "started_at": t.started_at.isoformat() if t.started_at else None
            }
            for t in self._running_tasks.values()
        ]


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

async def create_research_engine(
    memory_manager: Optional[Any] = None,
    brain_controller: Optional[Any] = None,
    internet_manager: Optional[Any] = None,
    **kwargs
) -> ResearchEngine:
    """Create configured research engine"""
    config = ResearchConfig(**kwargs)
    
    engine = ResearchEngine(
        config=config,
        memory_manager=memory_manager,
        brain_controller=brain_controller,
        internet_manager=internet_manager
    )
    
    return engine