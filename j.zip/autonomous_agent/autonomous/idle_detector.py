"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                           IDLE DETECTOR                                       ║
║                   Detect User Idle State for Autonomous Operation             ║
╚══════════════════════════════════════════════════════════════════════════════╝

The idle detector tracks user activity and determines when the agent
should begin autonomous operations like research and learning.
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Callable, Awaitable
from dataclasses import dataclass, field
from enum import Enum
from collections import deque

logger = logging.getLogger(__name__)


class IdleState(Enum):
    """States of user activity"""
    ACTIVE = "active"           # User is actively interacting
    IDLE = "idle"               # User is idle (short-term)
    DEEP_IDLE = "deep_idle"     # User has been idle for extended period
    AWAY = "away"               # User is away (very long idle)
    UNKNOWN = "unknown"         # State unknown


class ActivityType(Enum):
    """Types of user activity"""
    MESSAGE = "message"
    COMMAND = "command"
    CALLBACK = "callback"
    TYPING = "typing"
    PRESENCE = "presence"
    INTERACTION = "interaction"


@dataclass
class ActivityEvent:
    """Record of user activity"""
    type: ActivityType
    timestamp: datetime
    user_id: Optional[int] = None
    chat_id: Optional[int] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class IdleConfig:
    """Configuration for idle detection"""
    # Thresholds (in minutes)
    idle_threshold: int = 5           # Time until considered idle
    deep_idle_threshold: int = 30     # Time until considered deep idle
    away_threshold: int = 120         # Time until considered away
    
    # Activity tracking
    track_messages: bool = True
    track_commands: bool = True
    track_callbacks: bool = True
    
    # Callbacks
    notify_on_idle: bool = True
    notify_on_return: bool = True
    
    # History
    max_history_size: int = 100
    
    # User-specific settings
    per_user_tracking: bool = True
    primary_user_id: Optional[int] = None


@dataclass
class IdleInfo:
    """Information about idle state"""
    state: IdleState
    idle_duration_seconds: float
    idle_duration_minutes: float
    last_activity: Optional[datetime]
    activity_count_last_hour: int
    is_idle: bool
    is_deep_idle: bool
    is_away: bool


class UserActivityTracker:
    """Track activity for a specific user"""
    
    def __init__(self, user_id: int, max_history: int = 100):
        self.user_id = user_id
        self.max_history = max_history
        
        self._activities: deque = deque(maxlen=max_history)
        self._last_activity: Optional[datetime] = None
        self._session_start: Optional[datetime] = None
        self._total_messages: int = 0
        self._total_commands: int = 0
    
    def record_activity(self, activity: ActivityEvent) -> None:
        """Record an activity"""
        self._activities.append(activity)
        self._last_activity = activity.timestamp
        
        if self._session_start is None:
            self._session_start = activity.timestamp
        
        if activity.type == ActivityType.MESSAGE:
            self._total_messages += 1
        elif activity.type == ActivityType.COMMAND:
            self._total_commands += 1
    
    def get_idle_seconds(self) -> float:
        """Get seconds since last activity"""
        if self._last_activity is None:
            return float('inf')
        
        return (datetime.now() - self._last_activity).total_seconds()
    
    def get_activities_in_window(self, minutes: int) -> List[ActivityEvent]:
        """Get activities in time window"""
        cutoff = datetime.now() - timedelta(minutes=minutes)
        return [a for a in self._activities if a.timestamp > cutoff]
    
    @property
    def last_activity(self) -> Optional[datetime]:
        return self._last_activity
    
    @property
    def session_duration(self) -> Optional[timedelta]:
        if self._session_start:
            return datetime.now() - self._session_start
        return None


class IdleDetector:
    """
    Detect when users are idle for autonomous operation
    
    Features:
    - Track multiple users
    - Multiple idle states (active, idle, deep_idle, away)
    - Activity history
    - Idle/return callbacks
    - Session tracking
    """
    
    def __init__(self, config: Optional[IdleConfig] = None):
        self.config = config or IdleConfig()
        
        # Trackers
        self._global_tracker = UserActivityTracker(user_id=0)
        self._user_trackers: Dict[int, UserActivityTracker] = {}
        
        # State
        self._current_state = IdleState.UNKNOWN
        self._last_state_change: Optional[datetime] = None
        
        # Callbacks
        self._on_idle_callbacks: List[Callable[[IdleState], Awaitable[None]]] = []
        self._on_return_callbacks: List[Callable[[IdleInfo], Awaitable[None]]] = []
        
        # Background task
        self._monitor_task: Optional[asyncio.Task] = None
        self._running = False
        
        # Statistics
        self._stats = {
            "total_activities": 0,
            "idle_events": 0,
            "return_events": 0,
            "total_idle_time_seconds": 0,
            "longest_idle_seconds": 0
        }
        
        logger.info("IdleDetector initialized")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # LIFECYCLE
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def start(self) -> None:
        """Start idle monitoring"""
        if self._running:
            return
        
        self._running = True
        self._monitor_task = asyncio.create_task(self._monitor_loop())
        logger.info("IdleDetector started")
    
    async def stop(self) -> None:
        """Stop idle monitoring"""
        self._running = False
        
        if self._monitor_task:
            self._monitor_task.cancel()
            try:
                await self._monitor_task
            except asyncio.CancelledError:
                pass
        
        logger.info("IdleDetector stopped")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # ACTIVITY RECORDING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def record_activity(
        self,
        activity_type: ActivityType,
        user_id: Optional[int] = None,
        chat_id: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """Record user activity"""
        event = ActivityEvent(
            type=activity_type,
            timestamp=datetime.now(),
            user_id=user_id,
            chat_id=chat_id,
            metadata=metadata or {}
        )
        
        # Record globally
        self._global_tracker.record_activity(event)
        self._stats["total_activities"] += 1
        
        # Record per-user if enabled
        if self.config.per_user_tracking and user_id:
            if user_id not in self._user_trackers:
                self._user_trackers[user_id] = UserActivityTracker(
                    user_id=user_id,
                    max_history=self.config.max_history_size
                )
            self._user_trackers[user_id].record_activity(event)
        
        # Check for return from idle
        old_state = self._current_state
        await self._update_state()
        
        if old_state in [IdleState.IDLE, IdleState.DEEP_IDLE, IdleState.AWAY]:
            if self._current_state == IdleState.ACTIVE:
                await self._handle_return(old_state)
    
    async def record_message(
        self,
        user_id: Optional[int] = None,
        chat_id: Optional[int] = None
    ) -> None:
        """Convenience method to record message activity"""
        if self.config.track_messages:
            await self.record_activity(
                ActivityType.MESSAGE,
                user_id=user_id,
                chat_id=chat_id
            )
    
    async def record_command(
        self,
        command: str,
        user_id: Optional[int] = None,
        chat_id: Optional[int] = None
    ) -> None:
        """Convenience method to record command activity"""
        if self.config.track_commands:
            await self.record_activity(
                ActivityType.COMMAND,
                user_id=user_id,
                chat_id=chat_id,
                metadata={"command": command}
            )
    
    async def record_callback(
        self,
        callback_data: str,
        user_id: Optional[int] = None,
        chat_id: Optional[int] = None
    ) -> None:
        """Convenience method to record callback activity"""
        if self.config.track_callbacks:
            await self.record_activity(
                ActivityType.CALLBACK,
                user_id=user_id,
                chat_id=chat_id,
                metadata={"callback": callback_data}
            )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # STATE DETECTION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def get_idle_info(
        self,
        user_id: Optional[int] = None
    ) -> Dict[str, Any]:
        """Get idle information"""
        tracker = self._get_tracker(user_id)
        
        idle_seconds = tracker.get_idle_seconds()
        idle_minutes = idle_seconds / 60.0
        
        # Determine state
        if idle_minutes < self.config.idle_threshold:
            state = IdleState.ACTIVE
        elif idle_minutes < self.config.deep_idle_threshold:
            state = IdleState.IDLE
        elif idle_minutes < self.config.away_threshold:
            state = IdleState.DEEP_IDLE
        else:
            state = IdleState.AWAY
        
        # Activity count in last hour
        activities_last_hour = len(tracker.get_activities_in_window(60))
        
        info = IdleInfo(
            state=state,
            idle_duration_seconds=idle_seconds,
            idle_duration_minutes=idle_minutes,
            last_activity=tracker.last_activity,
            activity_count_last_hour=activities_last_hour,
            is_idle=state != IdleState.ACTIVE,
            is_deep_idle=state in [IdleState.DEEP_IDLE, IdleState.AWAY],
            is_away=state == IdleState.AWAY
        )
        
        return {
            "state": info.state.value,
            "idle_duration_seconds": info.idle_duration_seconds,
            "idle_duration_minutes": info.idle_duration_minutes,
            "last_activity": info.last_activity.isoformat() if info.last_activity else None,
            "activity_count_last_hour": info.activity_count_last_hour,
            "is_idle": info.is_idle,
            "is_deep_idle": info.is_deep_idle,
            "is_away": info.is_away
        }
    
    async def is_idle(self, user_id: Optional[int] = None) -> bool:
        """Check if user is idle"""
        info = await self.get_idle_info(user_id)
        return info["is_idle"]
    
    async def is_deep_idle(self, user_id: Optional[int] = None) -> bool:
        """Check if user is in deep idle"""
        info = await self.get_idle_info(user_id)
        return info["is_deep_idle"]
    
    async def get_idle_duration(
        self,
        user_id: Optional[int] = None
    ) -> timedelta:
        """Get idle duration"""
        tracker = self._get_tracker(user_id)
        return timedelta(seconds=tracker.get_idle_seconds())
    
    async def get_state(self, user_id: Optional[int] = None) -> IdleState:
        """Get current idle state"""
        info = await self.get_idle_info(user_id)
        return IdleState(info["state"])
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CALLBACKS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def on_idle(
        self,
        callback: Callable[[IdleState], Awaitable[None]]
    ) -> None:
        """Register callback for when user becomes idle"""
        self._on_idle_callbacks.append(callback)
    
    def on_return(
        self,
        callback: Callable[[IdleInfo], Awaitable[None]]
    ) -> None:
        """Register callback for when user returns from idle"""
        self._on_return_callbacks.append(callback)
    
    async def _handle_idle(self, new_state: IdleState) -> None:
        """Handle transition to idle state"""
        self._stats["idle_events"] += 1
        logger.debug(f"User became {new_state.value}")
        
        if self.config.notify_on_idle:
            for callback in self._on_idle_callbacks:
                try:
                    await callback(new_state)
                except Exception as e:
                    logger.error(f"Idle callback error: {e}")
    
    async def _handle_return(self, from_state: IdleState) -> None:
        """Handle return from idle"""
        self._stats["return_events"] += 1
        
        info = await self.get_idle_info()
        idle_info = IdleInfo(
            state=IdleState.ACTIVE,
            idle_duration_seconds=info["idle_duration_seconds"],
            idle_duration_minutes=info["idle_duration_minutes"],
            last_activity=datetime.now(),
            activity_count_last_hour=info["activity_count_last_hour"],
            is_idle=False,
            is_deep_idle=False,
            is_away=False
        )
        
        # Update stats
        self._stats["total_idle_time_seconds"] += info["idle_duration_seconds"]
        if info["idle_duration_seconds"] > self._stats["longest_idle_seconds"]:
            self._stats["longest_idle_seconds"] = info["idle_duration_seconds"]
        
        logger.debug(f"User returned from {from_state.value}")
        
        if self.config.notify_on_return:
            for callback in self._on_return_callbacks:
                try:
                    await callback(idle_info)
                except Exception as e:
                    logger.error(f"Return callback error: {e}")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MONITORING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _monitor_loop(self) -> None:
        """Background monitoring loop"""
        logger.info("Idle monitor loop started")
        
        while self._running:
            try:
                old_state = self._current_state
                await self._update_state()
                
                # Check for idle transitions
                if old_state == IdleState.ACTIVE:
                    if self._current_state in [IdleState.IDLE, IdleState.DEEP_IDLE]:
                        await self._handle_idle(self._current_state)
                elif old_state == IdleState.IDLE:
                    if self._current_state == IdleState.DEEP_IDLE:
                        await self._handle_idle(self._current_state)
                
                await asyncio.sleep(30)  # Check every 30 seconds
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Monitor loop error: {e}")
                await asyncio.sleep(5)
        
        logger.info("Idle monitor loop stopped")
    
    async def _update_state(self) -> None:
        """Update current idle state"""
        info = await self.get_idle_info()
        new_state = IdleState(info["state"])
        
        if new_state != self._current_state:
            self._current_state = new_state
            self._last_state_change = datetime.now()
    
    def _get_tracker(self, user_id: Optional[int] = None) -> UserActivityTracker:
        """Get appropriate tracker"""
        if user_id and user_id in self._user_trackers:
            return self._user_trackers[user_id]
        
        if self.config.primary_user_id and self.config.primary_user_id in self._user_trackers:
            return self._user_trackers[self.config.primary_user_id]
        
        return self._global_tracker
    
    # ═══════════════════════════════════════════════════════════════════════════
    # STATISTICS AND INFO
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_stats(self) -> Dict[str, Any]:
        """Get detector statistics"""
        return {
            **self._stats,
            "current_state": self._current_state.value,
            "tracked_users": len(self._user_trackers),
            "last_state_change": (
                self._last_state_change.isoformat() 
                if self._last_state_change else None
            )
        }
    
    def get_activity_summary(
        self,
        user_id: Optional[int] = None,
        minutes: int = 60
    ) -> Dict[str, Any]:
        """Get activity summary for time window"""
        tracker = self._get_tracker(user_id)
        activities = tracker.get_activities_in_window(minutes)
        
        # Count by type
        by_type = {}
        for activity in activities:
            type_name = activity.type.value
            by_type[type_name] = by_type.get(type_name, 0) + 1
        
        return {
            "total": len(activities),
            "by_type": by_type,
            "window_minutes": minutes,
            "user_id": user_id
        }
    
    def get_all_users_status(self) -> List[Dict[str, Any]]:
        """Get status of all tracked users"""
        statuses = []
        
        for user_id, tracker in self._user_trackers.items():
            idle_seconds = tracker.get_idle_seconds()
            statuses.append({
                "user_id": user_id,
                "idle_seconds": idle_seconds,
                "idle_minutes": idle_seconds / 60.0,
                "last_activity": (
                    tracker.last_activity.isoformat()
                    if tracker.last_activity else None
                ),
                "session_duration": (
                    str(tracker.session_duration)
                    if tracker.session_duration else None
                )
            })
        
        return statuses


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

async def create_idle_detector(
    primary_user_id: Optional[int] = None,
    idle_threshold: int = 5,
    deep_idle_threshold: int = 30,
    **kwargs
) -> IdleDetector:
    """Create and start idle detector"""
    config = IdleConfig(
        primary_user_id=primary_user_id,
        idle_threshold=idle_threshold,
        deep_idle_threshold=deep_idle_threshold,
        **kwargs
    )
    
    detector = IdleDetector(config=config)
    await detector.start()
    
    return detector