"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                      AUTONOMOUS CONTROLLER                                    ║
║            Central Controller for Autonomous Agent Operations                 ║
╚══════════════════════════════════════════════════════════════════════════════╝

This controller manages the agent's autonomous behavior:
- Detects when user is idle
- Triggers research and learning
- Manages background tasks
- Notifies owner of discoveries
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Callable, Awaitable, Set
from dataclasses import dataclass, field
from enum import Enum
import random
from pathlib import Path

logger = logging.getLogger(__name__)


class AutonomousState(Enum):
    """States of autonomous operation"""
    DISABLED = "disabled"
    IDLE = "idle"
    ACTIVE = "active"
    RESEARCHING = "researching"
    LEARNING = "learning"
    PROCESSING = "processing"
    PAUSED = "paused"
    ERROR = "error"


class TaskPriority(Enum):
    """Priority levels for autonomous tasks"""
    CRITICAL = 1
    HIGH = 2
    NORMAL = 3
    LOW = 4
    BACKGROUND = 5


class TaskType(Enum):
    """Types of autonomous tasks"""
    RESEARCH = "research"
    LEARNING = "learning"
    MEMORY_MAINTENANCE = "memory_maintenance"
    KNOWLEDGE_UPDATE = "knowledge_update"
    SKILL_PRACTICE = "skill_practice"
    EXPLORATION = "exploration"
    CLEANUP = "cleanup"
    HEALTH_CHECK = "health_check"
    CUSTOM = "custom"


@dataclass
class AutonomousTask:
    """Definition of an autonomous task"""
    id: str
    name: str
    type: TaskType
    priority: TaskPriority
    handler: Callable[[], Awaitable[Any]]
    
    # Scheduling
    interval_minutes: Optional[int] = None  # Run every N minutes
    schedule_time: Optional[str] = None     # Run at specific time (HH:MM)
    run_when_idle: bool = True              # Run only when user is idle
    
    # Status
    enabled: bool = True
    last_run: Optional[datetime] = None
    next_run: Optional[datetime] = None
    run_count: int = 0
    error_count: int = 0
    last_error: Optional[str] = None
    
    # Limits
    max_duration_seconds: int = 300  # 5 minutes max
    max_errors: int = 3              # Disable after 3 consecutive errors
    cooldown_minutes: int = 5        # Wait between runs


@dataclass
class AutonomousConfig:
    """Configuration for autonomous operation"""
    enabled: bool = True
    
    # Idle detection
    idle_threshold_minutes: int = 5
    deep_idle_threshold_minutes: int = 30
    
    # Research settings
    research_enabled: bool = True
    research_interval_minutes: int = 60
    max_research_per_hour: int = 5
    
    # Learning settings
    learning_enabled: bool = True
    learning_interval_minutes: int = 120
    max_learning_per_day: int = 10
    
    # Notification settings
    notify_discoveries: bool = True
    notify_learnings: bool = True
    min_discovery_importance: float = 0.5
    
    # Resource limits
    max_concurrent_tasks: int = 2
    max_cpu_percent: float = 50.0
    max_memory_percent: float = 70.0
    
    # Topics of interest
    interest_topics: List[str] = field(default_factory=list)
    blocked_topics: List[str] = field(default_factory=list)
    
    # Active hours (None = always active)
    active_hours_start: Optional[int] = None  # 0-23
    active_hours_end: Optional[int] = None    # 0-23


@dataclass
class AutonomousStats:
    """Statistics for autonomous operation"""
    total_tasks_run: int = 0
    successful_tasks: int = 0
    failed_tasks: int = 0
    total_research: int = 0
    total_learnings: int = 0
    total_discoveries: int = 0
    total_notifications: int = 0
    total_idle_time_minutes: int = 0
    last_activity: Optional[datetime] = None
    started_at: Optional[datetime] = None


class AutonomousController:
    """
    Central controller for autonomous agent operations
    
    Features:
    - Idle detection and response
    - Scheduled task execution
    - Research and learning orchestration
    - Discovery notification
    - Resource management
    - Error handling and recovery
    """
    
    def __init__(
        self,
        config: Optional[AutonomousConfig] = None,
        memory_manager: Optional[Any] = None,
        brain_controller: Optional[Any] = None,
        notification_sender: Optional[Any] = None,
        research_engine: Optional[Any] = None,
        idle_detector: Optional[Any] = None
    ):
        self.config = config or AutonomousConfig()
        self.memory_manager = memory_manager
        self.brain_controller = brain_controller
        self.notification_sender = notification_sender
        self.research_engine = research_engine
        self.idle_detector = idle_detector
        
        # State
        self.state = AutonomousState.DISABLED
        self._running = False
        self._paused = False
        
        # Tasks
        self._tasks: Dict[str, AutonomousTask] = {}
        self._running_tasks: Set[str] = set()
        self._task_queue: asyncio.PriorityQueue = asyncio.PriorityQueue()
        
        # Workers
        self._scheduler_task: Optional[asyncio.Task] = None
        self._executor_task: Optional[asyncio.Task] = None
        self._monitor_task: Optional[asyncio.Task] = None
        
        # Statistics
        self.stats = AutonomousStats()
        
        # Event callbacks
        self._on_discovery_callbacks: List[Callable] = []
        self._on_learning_callbacks: List[Callable] = []
        self._on_state_change_callbacks: List[Callable] = []
        
        # Locks
        self._task_lock = asyncio.Lock()
        
        logger.info("AutonomousController initialized")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # LIFECYCLE MANAGEMENT
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def start(self) -> bool:
        """Start autonomous operation"""
        if self._running:
            logger.warning("AutonomousController already running")
            return True
        
        if not self.config.enabled:
            logger.info("Autonomous operation is disabled")
            self.state = AutonomousState.DISABLED
            return False
        
        logger.info("Starting autonomous controller...")
        
        try:
            self._running = True
            self.stats.started_at = datetime.now()
            
            # Register default tasks
            await self._register_default_tasks()
            
            # Start workers
            self._scheduler_task = asyncio.create_task(self._scheduler_loop())
            self._executor_task = asyncio.create_task(self._executor_loop())
            self._monitor_task = asyncio.create_task(self._monitor_loop())
            
            self.state = AutonomousState.IDLE
            await self._notify_state_change(AutonomousState.IDLE)
            
            logger.info("✅ Autonomous controller started")
            return True
            
        except Exception as e:
            logger.error(f"Failed to start autonomous controller: {e}")
            self.state = AutonomousState.ERROR
            self._running = False
            return False
    
    async def stop(self) -> None:
        """Stop autonomous operation"""
        if not self._running:
            return
        
        logger.info("Stopping autonomous controller...")
        self._running = False
        
        # Cancel workers
        for task in [self._scheduler_task, self._executor_task, self._monitor_task]:
            if task:
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
        
        # Wait for running tasks
        if self._running_tasks:
            logger.info(f"Waiting for {len(self._running_tasks)} running tasks...")
            await asyncio.sleep(2)  # Give tasks time to complete
        
        self.state = AutonomousState.DISABLED
        logger.info("Autonomous controller stopped")
    
    async def pause(self) -> None:
        """Pause autonomous operation"""
        self._paused = True
        self.state = AutonomousState.PAUSED
        await self._notify_state_change(AutonomousState.PAUSED)
        logger.info("Autonomous operation paused")
    
    async def resume(self) -> None:
        """Resume autonomous operation"""
        self._paused = False
        self.state = AutonomousState.IDLE
        await self._notify_state_change(AutonomousState.IDLE)
        logger.info("Autonomous operation resumed")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # TASK MANAGEMENT
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def register_task(self, task: AutonomousTask) -> None:
        """Register a new autonomous task"""
        async with self._task_lock:
            self._tasks[task.id] = task
            logger.debug(f"Registered task: {task.name}")
    
    async def unregister_task(self, task_id: str) -> bool:
        """Unregister a task"""
        async with self._task_lock:
            if task_id in self._tasks:
                del self._tasks[task_id]
                logger.debug(f"Unregistered task: {task_id}")
                return True
            return False
    
    async def enable_task(self, task_id: str) -> bool:
        """Enable a task"""
        if task_id in self._tasks:
            self._tasks[task_id].enabled = True
            return True
        return False
    
    async def disable_task(self, task_id: str) -> bool:
        """Disable a task"""
        if task_id in self._tasks:
            self._tasks[task_id].enabled = False
            return True
        return False
    
    async def trigger_task(self, task_id: str) -> bool:
        """Manually trigger a task"""
        if task_id not in self._tasks:
            return False
        
        task = self._tasks[task_id]
        await self._queue_task(task)
        return True
    
    async def _register_default_tasks(self) -> None:
        """Register default autonomous tasks"""
        
        # Research task
        if self.config.research_enabled and self.research_engine:
            await self.register_task(AutonomousTask(
                id="research_topics",
                name="Research Topics of Interest",
                type=TaskType.RESEARCH,
                priority=TaskPriority.NORMAL,
                handler=self._task_research_topics,
                interval_minutes=self.config.research_interval_minutes,
                run_when_idle=True
            ))
        
        # Learning task
        if self.config.learning_enabled:
            await self.register_task(AutonomousTask(
                id="continuous_learning",
                name="Continuous Learning",
                type=TaskType.LEARNING,
                priority=TaskPriority.LOW,
                handler=self._task_continuous_learning,
                interval_minutes=self.config.learning_interval_minutes,
                run_when_idle=True
            ))
        
        # Memory maintenance
        if self.memory_manager:
            await self.register_task(AutonomousTask(
                id="memory_maintenance",
                name="Memory Maintenance",
                type=TaskType.MEMORY_MAINTENANCE,
                priority=TaskPriority.LOW,
                handler=self._task_memory_maintenance,
                interval_minutes=360,  # Every 6 hours
                run_when_idle=True
            ))
        
        # Health check
        await self.register_task(AutonomousTask(
            id="health_check",
            name="System Health Check",
            type=TaskType.HEALTH_CHECK,
            priority=TaskPriority.HIGH,
            handler=self._task_health_check,
            interval_minutes=30,
            run_when_idle=False  # Run regardless of idle state
        ))
        
        # Knowledge exploration
        await self.register_task(AutonomousTask(
            id="knowledge_exploration",
            name="Knowledge Exploration",
            type=TaskType.EXPLORATION,
            priority=TaskPriority.BACKGROUND,
            handler=self._task_knowledge_exploration,
            interval_minutes=180,  # Every 3 hours
            run_when_idle=True
        ))
    
    # ═══════════════════════════════════════════════════════════════════════════
    # DEFAULT TASK IMPLEMENTATIONS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _task_research_topics(self) -> Dict[str, Any]:
        """Research topics of interest"""
        if not self.research_engine:
            return {"status": "skipped", "reason": "No research engine"}
        
        result = {
            "status": "completed",
            "topics_researched": 0,
            "discoveries": []
        }
        
        try:
            # Get topics to research
            topics = await self._get_research_topics()
            
            for topic in topics[:3]:  # Max 3 topics per run
                self.state = AutonomousState.RESEARCHING
                
                research_result = await self.research_engine.research(
                    topic=topic,
                    depth="basic",
                    max_sources=3
                )
                
                if research_result.get("success"):
                    result["topics_researched"] += 1
                    
                    # Store in memory
                    if self.memory_manager:
                        await self.memory_manager.store_memory(
                            content=research_result.get("findings", {}),
                            memory_type="research",
                            tags=["autonomous", "research", topic],
                            metadata={
                                "topic": topic,
                                "source": "autonomous_research",
                                "timestamp": datetime.now().isoformat()
                            }
                        )
                    
                    # Check for discoveries
                    if research_result.get("is_discovery"):
                        discovery = {
                            "topic": topic,
                            "finding": research_result.get("summary", ""),
                            "importance": research_result.get("importance", 0.5)
                        }
                        result["discoveries"].append(discovery)
                        await self._handle_discovery(discovery)
                
                await asyncio.sleep(2)  # Pause between topics
            
            self.stats.total_research += result["topics_researched"]
            
        except Exception as e:
            logger.error(f"Research task error: {e}")
            result["status"] = "error"
            result["error"] = str(e)
        
        return result
    
    async def _task_continuous_learning(self) -> Dict[str, Any]:
        """Continuous learning from various sources"""
        result = {
            "status": "completed",
            "items_learned": 0,
            "topics": []
        }
        
        try:
            self.state = AutonomousState.LEARNING
            
            # Get learning topics
            topics = await self._get_learning_topics()
            
            for topic in topics[:2]:  # Max 2 topics per run
                # Learn about topic
                if self.brain_controller:
                    learning_result = await self.brain_controller.think(
                        f"Learn and summarize key points about: {topic}",
                        context={"mode": "learning", "autonomous": True}
                    )
                    
                    if learning_result.get("success"):
                        result["items_learned"] += 1
                        result["topics"].append(topic)
                        
                        # Store learning
                        if self.memory_manager:
                            await self.memory_manager.store_memory(
                                content={
                                    "topic": topic,
                                    "summary": learning_result.get("response", ""),
                                    "learned_at": datetime.now().isoformat()
                                },
                                memory_type="skill",
                                tags=["autonomous", "learning", topic]
                            )
                        
                        # Notify
                        if self.config.notify_learnings:
                            await self._notify_learning(topic, learning_result.get("response", ""))
                
                await asyncio.sleep(1)
            
            self.stats.total_learnings += result["items_learned"]
            
        except Exception as e:
            logger.error(f"Learning task error: {e}")
            result["status"] = "error"
            result["error"] = str(e)
        
        return result
    
    async def _task_memory_maintenance(self) -> Dict[str, Any]:
        """Maintain and optimize memory"""
        result = {"status": "completed", "actions": []}
        
        try:
            if not self.memory_manager:
                return {"status": "skipped", "reason": "No memory manager"}
            
            # Consolidate memories
            consolidation = await self.memory_manager.consolidate_memories()
            if consolidation:
                result["actions"].append("consolidation")
            
            # Clean old working memory
            cleanup = await self.memory_manager.cleanup_old_memories(
                memory_type="working",
                older_than_days=7
            )
            if cleanup:
                result["actions"].append(f"cleaned_{cleanup}_old_memories")
            
            # Optimize database
            await self.memory_manager.optimize()
            result["actions"].append("optimization")
            
        except Exception as e:
            logger.error(f"Memory maintenance error: {e}")
            result["status"] = "error"
            result["error"] = str(e)
        
        return result
    
    async def _task_health_check(self) -> Dict[str, Any]:
        """Check system health"""
        result = {
            "status": "healthy",
            "checks": {},
            "issues": []
        }
        
        try:
            # Check memory
            if self.memory_manager:
                try:
                    stats = await self.memory_manager.get_statistics()
                    result["checks"]["memory"] = "ok"
                except Exception as e:
                    result["checks"]["memory"] = "error"
                    result["issues"].append(f"Memory: {e}")
            
            # Check brain
            if self.brain_controller:
                try:
                    health = await self.brain_controller.health_check()
                    result["checks"]["brain"] = "ok" if health else "degraded"
                except Exception as e:
                    result["checks"]["brain"] = "error"
                    result["issues"].append(f"Brain: {e}")
            
            # Check research engine
            if self.research_engine:
                try:
                    health = await self.research_engine.health_check()
                    result["checks"]["research"] = "ok" if health else "degraded"
                except Exception as e:
                    result["checks"]["research"] = "error"
                    result["issues"].append(f"Research: {e}")
            
            # Set overall status
            if result["issues"]:
                result["status"] = "degraded" if len(result["issues"]) < 2 else "unhealthy"
                
                # Notify if unhealthy
                if result["status"] == "unhealthy" and self.notification_sender:
                    await self.notification_sender.notify_error(
                        "System Health Issue",
                        f"Issues detected: {', '.join(result['issues'])}"
                    )
            
        except Exception as e:
            logger.error(f"Health check error: {e}")
            result["status"] = "error"
            result["error"] = str(e)
        
        return result
    
    async def _task_knowledge_exploration(self) -> Dict[str, Any]:
        """Explore and expand knowledge"""
        result = {"status": "completed", "explored": []}
        
        try:
            self.state = AutonomousState.PROCESSING
            
            # Get unexplored topics from memory
            if self.memory_manager:
                unexplored = await self.memory_manager.find_knowledge_gaps()
                
                for gap in unexplored[:2]:
                    # Research the gap
                    if self.research_engine:
                        res = await self.research_engine.research(
                            topic=gap,
                            depth="shallow"
                        )
                        if res.get("success"):
                            result["explored"].append(gap)
            
        except Exception as e:
            logger.error(f"Knowledge exploration error: {e}")
            result["status"] = "error"
            result["error"] = str(e)
        
        return result
    
    # ═══════════════════════════════════════════════════════════════════════════
    # WORKER LOOPS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _scheduler_loop(self) -> None:
        """Schedule tasks based on their configuration"""
        logger.info("Scheduler loop started")
        
        while self._running:
            try:
                if self._paused:
                    await asyncio.sleep(5)
                    continue
                
                now = datetime.now()
                
                async with self._task_lock:
                    for task in self._tasks.values():
                        if not task.enabled:
                            continue
                        
                        if task.id in self._running_tasks:
                            continue
                        
                        # Check if task should run
                        should_run = await self._should_run_task(task, now)
                        
                        if should_run:
                            await self._queue_task(task)
                
                await asyncio.sleep(10)  # Check every 10 seconds
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Scheduler error: {e}")
                await asyncio.sleep(5)
        
        logger.info("Scheduler loop stopped")
    
    async def _executor_loop(self) -> None:
        """Execute queued tasks"""
        logger.info("Executor loop started")
        
        while self._running:
            try:
                if self._paused:
                    await asyncio.sleep(5)
                    continue
                
                # Check resource limits
                if len(self._running_tasks) >= self.config.max_concurrent_tasks:
                    await asyncio.sleep(1)
                    continue
                
                # Get next task
                try:
                    priority, task_id = await asyncio.wait_for(
                        self._task_queue.get(),
                        timeout=5.0
                    )
                except asyncio.TimeoutError:
                    continue
                
                if task_id not in self._tasks:
                    continue
                
                task = self._tasks[task_id]
                
                # Execute task
                asyncio.create_task(self._execute_task(task))
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Executor error: {e}")
                await asyncio.sleep(1)
        
        logger.info("Executor loop stopped")
    
    async def _monitor_loop(self) -> None:
        """Monitor autonomous operation"""
        logger.info("Monitor loop started")
        
        while self._running:
            try:
                # Update idle state
                if self.idle_detector:
                    idle_info = await self.idle_detector.get_idle_info()
                    
                    if idle_info.get("is_idle"):
                        if self.state not in [
                            AutonomousState.RESEARCHING,
                            AutonomousState.LEARNING,
                            AutonomousState.PROCESSING,
                            AutonomousState.PAUSED
                        ]:
                            self.state = AutonomousState.IDLE
                            self.stats.total_idle_time_minutes += 1
                    else:
                        if self.state == AutonomousState.IDLE:
                            self.state = AutonomousState.ACTIVE
                
                # Update stats
                self.stats.last_activity = datetime.now()
                
                await asyncio.sleep(60)  # Check every minute
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Monitor error: {e}")
                await asyncio.sleep(5)
        
        logger.info("Monitor loop stopped")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # TASK EXECUTION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _should_run_task(self, task: AutonomousTask, now: datetime) -> bool:
        """Check if task should run"""
        # Check error limit
        if task.error_count >= task.max_errors:
            return False
        
        # Check cooldown
        if task.last_run:
            cooldown_end = task.last_run + timedelta(minutes=task.cooldown_minutes)
            if now < cooldown_end:
                return False
        
        # Check idle requirement
        if task.run_when_idle and self.idle_detector:
            idle_info = await self.idle_detector.get_idle_info()
            if not idle_info.get("is_idle"):
                return False
        
        # Check active hours
        if not self._is_active_hours(now):
            return False
        
        # Check interval
        if task.interval_minutes:
            if task.last_run is None:
                return True
            
            next_run = task.last_run + timedelta(minutes=task.interval_minutes)
            return now >= next_run
        
        # Check scheduled time
        if task.schedule_time:
            hour, minute = map(int, task.schedule_time.split(':'))
            scheduled = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            
            if task.last_run and task.last_run.date() == now.date():
                return False  # Already run today
            
            return now >= scheduled
        
        return False
    
    async def _queue_task(self, task: AutonomousTask) -> None:
        """Add task to execution queue"""
        await self._task_queue.put((task.priority.value, task.id))
        logger.debug(f"Queued task: {task.name}")
    
    async def _execute_task(self, task: AutonomousTask) -> None:
        """Execute a single task"""
        task_id = task.id
        self._running_tasks.add(task_id)
        
        logger.info(f"Executing task: {task.name}")
        start_time = datetime.now()
        
        try:
            # Execute with timeout
            result = await asyncio.wait_for(
                task.handler(),
                timeout=task.max_duration_seconds
            )
            
            # Update task status
            task.last_run = datetime.now()
            task.run_count += 1
            task.error_count = 0  # Reset on success
            
            self.stats.total_tasks_run += 1
            self.stats.successful_tasks += 1
            
            logger.info(f"Task completed: {task.name} - {result.get('status', 'ok')}")
            
        except asyncio.TimeoutError:
            logger.warning(f"Task timeout: {task.name}")
            task.error_count += 1
            task.last_error = "Timeout"
            self.stats.failed_tasks += 1
            
        except Exception as e:
            logger.error(f"Task error: {task.name} - {e}")
            task.error_count += 1
            task.last_error = str(e)
            self.stats.failed_tasks += 1
            
        finally:
            self._running_tasks.discard(task_id)
            
            # Reset state if no other tasks running
            if not self._running_tasks and self.state not in [
                AutonomousState.PAUSED,
                AutonomousState.DISABLED
            ]:
                self.state = AutonomousState.IDLE
    
    # ═══════════════════════════════════════════════════════════════════════════
    # HELPER METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _get_research_topics(self) -> List[str]:
        """Get topics to research"""
        topics = list(self.config.interest_topics)
        
        # Add topics from memory
        if self.memory_manager:
            try:
                recent_topics = await self.memory_manager.get_recent_topics(limit=5)
                topics.extend(recent_topics)
            except Exception:
                pass
        
        # Filter blocked topics
        topics = [t for t in topics if t not in self.config.blocked_topics]
        
        # Shuffle for variety
        random.shuffle(topics)
        
        return topics or ["technology trends", "programming best practices"]
    
    async def _get_learning_topics(self) -> List[str]:
        """Get topics for learning"""
        topics = []
        
        # Get from user preferences
        if self.memory_manager:
            try:
                preferences = await self.memory_manager.get_preferences()
                topics.extend(preferences.get("learning_topics", []))
            except Exception:
                pass
        
        # Add default topics
        default_topics = [
            "Python best practices",
            "System administration",
            "DevOps techniques",
            "AI and machine learning",
            "Software architecture"
        ]
        
        if not topics:
            topics = default_topics
        
        random.shuffle(topics)
        return topics
    
    async def _handle_discovery(self, discovery: Dict[str, Any]) -> None:
        """Handle a new discovery"""
        self.stats.total_discoveries += 1
        
        # Check importance threshold
        importance = discovery.get("importance", 0)
        if importance < self.config.min_discovery_importance:
            return
        
        # Notify owner
        if self.config.notify_discoveries and self.notification_sender:
            await self.notification_sender.notify_research(
                topic=discovery.get("topic", "Unknown"),
                finding=discovery.get("finding", "")
            )
            self.stats.total_notifications += 1
        
        # Trigger callbacks
        for callback in self._on_discovery_callbacks:
            try:
                await callback(discovery)
            except Exception as e:
                logger.error(f"Discovery callback error: {e}")
    
    async def _notify_learning(self, topic: str, summary: str) -> None:
        """Notify about learning completion"""
        if self.notification_sender:
            await self.notification_sender.notify_learning(
                topic=topic,
                summary=summary[:500]  # Limit length
            )
            self.stats.total_notifications += 1
        
        # Trigger callbacks
        for callback in self._on_learning_callbacks:
            try:
                await callback({"topic": topic, "summary": summary})
            except Exception as e:
                logger.error(f"Learning callback error: {e}")
    
    async def _notify_state_change(self, new_state: AutonomousState) -> None:
        """Notify about state change"""
        for callback in self._on_state_change_callbacks:
            try:
                await callback(new_state)
            except Exception as e:
                logger.error(f"State change callback error: {e}")
    
    def _is_active_hours(self, now: datetime) -> bool:
        """Check if current time is within active hours"""
        if self.config.active_hours_start is None:
            return True
        
        hour = now.hour
        start = self.config.active_hours_start
        end = self.config.active_hours_end or 23
        
        if start <= end:
            return start <= hour <= end
        else:
            return hour >= start or hour <= end
    
    # ═══════════════════════════════════════════════════════════════════════════
    # EVENT CALLBACKS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def on_discovery(self, callback: Callable[[Dict], Awaitable[None]]) -> None:
        """Register discovery callback"""
        self._on_discovery_callbacks.append(callback)
    
    def on_learning(self, callback: Callable[[Dict], Awaitable[None]]) -> None:
        """Register learning callback"""
        self._on_learning_callbacks.append(callback)
    
    def on_state_change(self, callback: Callable[[AutonomousState], Awaitable[None]]) -> None:
        """Register state change callback"""
        self._on_state_change_callbacks.append(callback)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PUBLIC API
    # ═══════════════════════════════════════════════════════════════════════════
    
    def add_interest_topic(self, topic: str) -> None:
        """Add topic of interest"""
        if topic not in self.config.interest_topics:
            self.config.interest_topics.append(topic)
    
    def remove_interest_topic(self, topic: str) -> None:
        """Remove topic of interest"""
        if topic in self.config.interest_topics:
            self.config.interest_topics.remove(topic)
    
    def block_topic(self, topic: str) -> None:
        """Block a topic from research"""
        if topic not in self.config.blocked_topics:
            self.config.blocked_topics.append(topic)
    
    def unblock_topic(self, topic: str) -> None:
        """Unblock a topic"""
        if topic in self.config.blocked_topics:
            self.config.blocked_topics.remove(topic)
    
    def get_status(self) -> Dict[str, Any]:
        """Get autonomous operation status"""
        return {
            "state": self.state.value,
            "enabled": self.config.enabled,
            "running": self._running,
            "paused": self._paused,
            "tasks_registered": len(self._tasks),
            "tasks_running": len(self._running_tasks),
            "tasks_queued": self._task_queue.qsize(),
            "stats": {
                "total_tasks_run": self.stats.total_tasks_run,
                "successful_tasks": self.stats.successful_tasks,
                "failed_tasks": self.stats.failed_tasks,
                "total_research": self.stats.total_research,
                "total_learnings": self.stats.total_learnings,
                "total_discoveries": self.stats.total_discoveries,
                "total_notifications": self.stats.total_notifications,
                "total_idle_time_minutes": self.stats.total_idle_time_minutes,
                "started_at": self.stats.started_at.isoformat() if self.stats.started_at else None
            },
            "interest_topics": self.config.interest_topics,
            "blocked_topics": self.config.blocked_topics
        }
    
    def get_tasks(self) -> List[Dict[str, Any]]:
        """Get all registered tasks"""
        return [
            {
                "id": t.id,
                "name": t.name,
                "type": t.type.value,
                "priority": t.priority.value,
                "enabled": t.enabled,
                "last_run": t.last_run.isoformat() if t.last_run else None,
                "run_count": t.run_count,
                "error_count": t.error_count
            }
            for t in self._tasks.values()
        ]


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

async def create_autonomous_controller(
    memory_manager: Optional[Any] = None,
    brain_controller: Optional[Any] = None,
    notification_sender: Optional[Any] = None,
    research_engine: Optional[Any] = None,
    idle_detector: Optional[Any] = None,
    interest_topics: Optional[List[str]] = None,
    **kwargs
) -> AutonomousController:
    """Create and configure autonomous controller"""
    config = AutonomousConfig(
        interest_topics=interest_topics or [],
        **kwargs
    )
    
    controller = AutonomousController(
        config=config,
        memory_manager=memory_manager,
        brain_controller=brain_controller,
        notification_sender=notification_sender,
        research_engine=research_engine,
        idle_detector=idle_detector
    )
    
    return controller