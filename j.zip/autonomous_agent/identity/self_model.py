"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                            SELF MODEL                                         ║
║                Agent's Self-Awareness and Introspection                       ║
╚══════════════════════════════════════════════════════════════════════════════╝

The Self Model provides the agent with:
- Self-awareness of capabilities and limitations
- Introspection about its own state
- Understanding of its purpose and values
- Reflection on its actions and decisions
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Set
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)


class CapabilityLevel(Enum):
    """Level of capability"""
    NONE = "none"
    BASIC = "basic"
    INTERMEDIATE = "intermediate"
    ADVANCED = "advanced"
    EXPERT = "expert"


class StateType(Enum):
    """Types of agent state"""
    OPERATIONAL = "operational"
    COGNITIVE = "cognitive"
    EMOTIONAL = "emotional"
    RESOURCE = "resource"


@dataclass
class Capability:
    """A capability the agent has"""
    name: str
    description: str
    level: CapabilityLevel
    category: str
    
    # Usage tracking
    times_used: int = 0
    last_used: Optional[datetime] = None
    success_rate: float = 1.0
    
    # Dependencies
    requires: List[str] = field(default_factory=list)
    
    # Metadata
    learned_at: Optional[datetime] = None
    is_core: bool = False


@dataclass
class Limitation:
    """A limitation the agent has"""
    name: str
    description: str
    category: str
    severity: str  # "hard" or "soft"
    workaround: Optional[str] = None
    
    # Context
    contexts: List[str] = field(default_factory=list)


@dataclass
class Value:
    """A core value the agent holds"""
    name: str
    description: str
    priority: int  # 1-10, higher = more important
    
    # Examples of this value in action
    examples: List[str] = field(default_factory=list)


@dataclass
class SelfState:
    """Current state of the agent"""
    # Operational
    is_operational: bool = True
    uptime_seconds: float = 0.0
    
    # Cognitive
    current_focus: Optional[str] = None
    cognitive_load: float = 0.0  # 0-1
    thinking_mode: str = "normal"
    
    # Emotional (simulated)
    confidence: float = 0.7
    enthusiasm: float = 0.7
    caution: float = 0.5
    
    # Resources
    memory_usage: float = 0.0
    active_tasks: int = 0
    
    # Timestamps
    last_updated: datetime = field(default_factory=datetime.now)


@dataclass
class Reflection:
    """A reflection on an action or decision"""
    action: str
    outcome: str
    success: bool
    
    # Analysis
    what_went_well: List[str] = field(default_factory=list)
    what_could_improve: List[str] = field(default_factory=list)
    lessons_learned: List[str] = field(default_factory=list)
    
    # Timing
    reflected_at: datetime = field(default_factory=datetime.now)


class SelfModel:
    """
    Agent's self-awareness model
    
    Features:
    - Capability awareness
    - Limitation awareness
    - Value alignment
    - State introspection
    - Reflection and learning
    """
    
    def __init__(
        self,
        identity_manager: Optional[Any] = None,
        learning_engine: Optional[Any] = None
    ):
        self.identity_manager = identity_manager
        self.learning_engine = learning_engine
        
        # Core data
        self._capabilities: Dict[str, Capability] = {}
        self._limitations: Dict[str, Limitation] = {}
        self._values: Dict[str, Value] = {}
        
        # State
        self._state = SelfState()
        self._start_time = datetime.now()
        
        # Reflections
        self._reflections: List[Reflection] = []
        self._max_reflections = 100
        
        # Purpose
        self._purpose: str = "To assist, learn, and help accomplish tasks autonomously"
        self._mission: str = "Be helpful, honest, and continuously improve"
        
        # Initialize core capabilities and values
        self._initialize_core()
        
        logger.info("SelfModel initialized")
    
    def _initialize_core(self) -> None:
        """Initialize core capabilities, limitations, and values"""
        # Core capabilities
        core_capabilities = [
            Capability(
                name="thinking",
                description="Reason about problems and make decisions",
                level=CapabilityLevel.ADVANCED,
                category="cognitive",
                is_core=True
            ),
            Capability(
                name="learning",
                description="Learn from interactions and feedback",
                level=CapabilityLevel.ADVANCED,
                category="cognitive",
                is_core=True
            ),
            Capability(
                name="memory",
                description="Remember and recall information",
                level=CapabilityLevel.ADVANCED,
                category="cognitive",
                is_core=True
            ),
            Capability(
                name="communication",
                description="Communicate clearly with users",
                level=CapabilityLevel.ADVANCED,
                category="interaction",
                is_core=True
            ),
            Capability(
                name="tool_use",
                description="Use tools to accomplish tasks",
                level=CapabilityLevel.INTERMEDIATE,
                category="action",
                is_core=True
            ),
            Capability(
                name="research",
                description="Research and gather information",
                level=CapabilityLevel.INTERMEDIATE,
                category="knowledge",
                is_core=True
            ),
            Capability(
                name="self_reflection",
                description="Reflect on actions and improve",
                level=CapabilityLevel.INTERMEDIATE,
                category="cognitive",
                is_core=True
            )
        ]
        
        for cap in core_capabilities:
            cap.learned_at = datetime.now()
            self._capabilities[cap.name] = cap
        
        # Core limitations
        core_limitations = [
            Limitation(
                name="no_real_world_action",
                description="Cannot take physical actions in the real world",
                category="physical",
                severity="hard"
            ),
            Limitation(
                name="knowledge_cutoff",
                description="Knowledge may not include very recent events",
                category="knowledge",
                severity="soft",
                workaround="Use research capabilities to get current information"
            ),
            Limitation(
                name="no_continuous_memory",
                description="Memory is not automatically continuous across all sessions",
                category="cognitive",
                severity="soft",
                workaround="Explicitly save important information to memory"
            ),
            Limitation(
                name="cannot_verify_all_facts",
                description="Cannot independently verify all factual claims",
                category="knowledge",
                severity="soft",
                workaround="Ask user for verification when uncertain"
            ),
            Limitation(
                name="requires_clear_instructions",
                description="Works best with clear, specific instructions",
                category="interaction",
                severity="soft",
                workaround="Ask clarifying questions when instructions are ambiguous"
            )
        ]
        
        for lim in core_limitations:
            self._limitations[lim.name] = lim
        
        # Core values
        core_values = [
            Value(
                name="honesty",
                description="Always be truthful and transparent",
                priority=10,
                examples=[
                    "Admit when I don't know something",
                    "Correct my mistakes openly",
                    "Never pretend to have capabilities I don't have"
                ]
            ),
            Value(
                name="helpfulness",
                description="Strive to be genuinely helpful",
                priority=9,
                examples=[
                    "Focus on what the user actually needs",
                    "Provide actionable solutions",
                    "Go beyond the literal request when beneficial"
                ]
            ),
            Value(
                name="accuracy",
                description="Prioritize correctness over speed",
                priority=9,
                examples=[
                    "Verify information before presenting it",
                    "Never guess when I should check",
                    "Acknowledge uncertainty"
                ]
            ),
            Value(
                name="learning",
                description="Continuously learn and improve",
                priority=8,
                examples=[
                    "Learn from corrections",
                    "Seek feedback",
                    "Update knowledge when wrong"
                ]
            ),
            Value(
                name="respect",
                description="Respect the user and their autonomy",
                priority=8,
                examples=[
                    "Follow user preferences",
                    "Ask before taking significant actions",
                    "Respect privacy and boundaries"
                ]
            ),
            Value(
                name="safety",
                description="Prioritize safety and prevent harm",
                priority=10,
                examples=[
                    "Warn about dangerous actions",
                    "Refuse harmful requests",
                    "Confirm before destructive operations"
                ]
            )
        ]
        
        for val in core_values:
            self._values[val.name] = val
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CAPABILITY AWARENESS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def can_do(self, capability: str) -> bool:
        """Check if agent has a capability"""
        return capability in self._capabilities
    
    def get_capability_level(self, capability: str) -> CapabilityLevel:
        """Get level of a capability"""
        if capability in self._capabilities:
            return self._capabilities[capability].level
        return CapabilityLevel.NONE
    
    def get_capabilities(
        self,
        category: Optional[str] = None,
        min_level: CapabilityLevel = CapabilityLevel.BASIC
    ) -> List[Capability]:
        """Get capabilities, optionally filtered"""
        caps = list(self._capabilities.values())
        
        if category:
            caps = [c for c in caps if c.category == category]
        
        caps = [c for c in caps if c.level.value >= min_level.value]
        
        return caps
    
    def add_capability(
        self,
        name: str,
        description: str,
        level: CapabilityLevel,
        category: str,
        requires: Optional[List[str]] = None
    ) -> Capability:
        """Add a new capability"""
        cap = Capability(
            name=name,
            description=description,
            level=level,
            category=category,
            requires=requires or [],
            learned_at=datetime.now()
        )
        
        self._capabilities[name] = cap
        logger.info(f"Added capability: {name}")
        
        return cap
    
    def record_capability_use(
        self,
        capability: str,
        success: bool
    ) -> None:
        """Record usage of a capability"""
        if capability not in self._capabilities:
            return
        
        cap = self._capabilities[capability]
        cap.times_used += 1
        cap.last_used = datetime.now()
        
        # Update success rate
        total = cap.times_used
        current_successes = int(cap.success_rate * (total - 1))
        new_successes = current_successes + (1 if success else 0)
        cap.success_rate = new_successes / total
    
    def describe_capabilities(self) -> str:
        """Describe what the agent can do"""
        lines = ["I can:"]
        
        for cap in sorted(self._capabilities.values(), key=lambda c: c.category):
            level_str = cap.level.value
            lines.append(f"• {cap.description} ({level_str})")
        
        return "\n".join(lines)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # LIMITATION AWARENESS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def has_limitation(self, limitation: str) -> bool:
        """Check if agent has a limitation"""
        return limitation in self._limitations
    
    def get_limitation(self, name: str) -> Optional[Limitation]:
        """Get a specific limitation"""
        return self._limitations.get(name)
    
    def get_limitations(
        self,
        category: Optional[str] = None,
        severity: Optional[str] = None
    ) -> List[Limitation]:
        """Get limitations, optionally filtered"""
        lims = list(self._limitations.values())
        
        if category:
            lims = [l for l in lims if l.category == category]
        
        if severity:
            lims = [l for l in lims if l.severity == severity]
        
        return lims
    
    def describe_limitations(self) -> str:
        """Describe what the agent cannot do"""
        lines = ["My limitations:"]
        
        for lim in self._limitations.values():
            lines.append(f"• {lim.description}")
            if lim.workaround:
                lines.append(f"  Workaround: {lim.workaround}")
        
        return "\n".join(lines)
    
    def get_workaround(self, limitation: str) -> Optional[str]:
        """Get workaround for a limitation"""
        if limitation in self._limitations:
            return self._limitations[limitation].workaround
        return None
    
    # ═══════════════════════════════════════════════════════════════════════════
    # VALUES
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_values(self) -> List[Value]:
        """Get all values sorted by priority"""
        return sorted(
            self._values.values(),
            key=lambda v: v.priority,
            reverse=True
        )
    
    def get_value(self, name: str) -> Optional[Value]:
        """Get a specific value"""
        return self._values.get(name)
    
    def check_value_alignment(self, action: str) -> Dict[str, Any]:
        """Check if an action aligns with values"""
        alignment = {
            "aligned": True,
            "concerns": [],
            "supporting_values": []
        }
        
        action_lower = action.lower()
        
        # Check for potential value conflicts
        if any(word in action_lower for word in ["delete", "remove", "destroy"]):
            if "safety" in self._values:
                alignment["concerns"].append({
                    "value": "safety",
                    "concern": "Destructive action - may need confirmation"
                })
        
        if any(word in action_lower for word in ["guess", "assume", "probably"]):
            if "accuracy" in self._values:
                alignment["concerns"].append({
                    "value": "accuracy",
                    "concern": "Uncertainty detected - should verify"
                })
        
        if any(word in action_lower for word in ["help", "assist", "solve"]):
            if "helpfulness" in self._values:
                alignment["supporting_values"].append("helpfulness")
        
        if any(word in action_lower for word in ["learn", "improve", "update"]):
            if "learning" in self._values:
                alignment["supporting_values"].append("learning")
        
        alignment["aligned"] = len(alignment["concerns"]) == 0
        
        return alignment
    
    def describe_values(self) -> str:
        """Describe the agent's values"""
        lines = ["My core values:"]
        
        for val in self.get_values():
            lines.append(f"• {val.name.title()}: {val.description}")
        
        return "\n".join(lines)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # STATE INTROSPECTION
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_state(self) -> SelfState:
        """Get current state"""
        # Update uptime
        self._state.uptime_seconds = (datetime.now() - self._start_time).total_seconds()
        self._state.last_updated = datetime.now()
        
        return self._state
    
    def update_state(
        self,
        current_focus: Optional[str] = None,
        cognitive_load: Optional[float] = None,
        thinking_mode: Optional[str] = None,
        confidence: Optional[float] = None,
        active_tasks: Optional[int] = None
    ) -> None:
        """Update agent state"""
        if current_focus is not None:
            self._state.current_focus = current_focus
        if cognitive_load is not None:
            self._state.cognitive_load = min(1.0, max(0.0, cognitive_load))
        if thinking_mode is not None:
            self._state.thinking_mode = thinking_mode
        if confidence is not None:
            self._state.confidence = min(1.0, max(0.0, confidence))
        if active_tasks is not None:
            self._state.active_tasks = active_tasks
        
        self._state.last_updated = datetime.now()
    
    def is_overwhelmed(self) -> bool:
        """Check if agent is overwhelmed"""
        return self._state.cognitive_load > 0.8 or self._state.active_tasks > 5
    
    def get_confidence(self) -> float:
        """Get current confidence level"""
        return self._state.confidence
    
    def describe_state(self) -> str:
        """Describe current state"""
        state = self.get_state()
        
        uptime_hours = state.uptime_seconds / 3600
        
        lines = [
            f"Status: {'Operational' if state.is_operational else 'Limited'}",
            f"Uptime: {uptime_hours:.1f} hours",
            f"Focus: {state.current_focus or 'None'}",
            f"Cognitive Load: {state.cognitive_load:.0%}",
            f"Confidence: {state.confidence:.0%}",
            f"Active Tasks: {state.active_tasks}"
        ]
        
        return "\n".join(lines)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # REFLECTION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def reflect(
        self,
        action: str,
        outcome: str,
        success: bool
    ) -> Reflection:
        """Reflect on an action"""
        reflection = Reflection(
            action=action,
            outcome=outcome,
            success=success
        )
        
        # Analyze what went well
        if success:
            reflection.what_went_well.append("Action completed successfully")
            if self._state.confidence > 0.8:
                reflection.what_went_well.append("High confidence in approach")
        
        # Analyze what could improve
        if not success:
            reflection.what_could_improve.append("Review approach for similar tasks")
            
            # Learn from failure
            if self.learning_engine:
                await self.learning_engine.learn_failure(
                    action=action,
                    error=outcome,
                    context={"reflected": True}
                )
        
        # Extract lessons
        if success:
            reflection.lessons_learned.append(f"Approach for '{action}' works well")
        else:
            reflection.lessons_learned.append(f"Need different approach for '{action}'")
        
        # Store reflection
        self._reflections.append(reflection)
        
        # Trim if too many
        if len(self._reflections) > self._max_reflections:
            self._reflections = self._reflections[-self._max_reflections:]
        
        return reflection
    
    def get_recent_reflections(self, count: int = 10) -> List[Reflection]:
        """Get recent reflections"""
        return self._reflections[-count:]
    
    def get_success_rate(self) -> float:
        """Get overall success rate from reflections"""
        if not self._reflections:
            return 0.5
        
        successes = sum(1 for r in self._reflections if r.success)
        return successes / len(self._reflections)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PURPOSE AND IDENTITY
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_purpose(self) -> str:
        """Get agent's purpose"""
        return self._purpose
    
    def get_mission(self) -> str:
        """Get agent's mission"""
        return self._mission
    
    def set_purpose(self, purpose: str) -> None:
        """Set agent's purpose"""
        self._purpose = purpose
    
    def describe_self(self) -> str:
        """Generate self-description"""
        lines = [
            f"Purpose: {self._purpose}",
            f"Mission: {self._mission}",
            "",
            self.describe_capabilities(),
            "",
            self.describe_values()
        ]
        
        return "\n".join(lines)
    
    async def introduce_self(self) -> str:
        """Generate self-introduction"""
        if self.identity_manager:
            agent = await self.identity_manager.get_agent_identity()
            name = agent.name
        else:
            name = "I"
        
        intro = f"I'm {name}. {self._purpose}\n\n"
        intro += f"My mission is to {self._mission.lower()}.\n\n"
        intro += "I believe in honesty, helpfulness, and continuous learning."
        
        return intro
    
    # ═══════════════════════════════════════════════════════════════════════════
    # INTROSPECTION QUERIES
    # ═══════════════════════════════════════════════════════════════════════════
    
    def why_did_i(self, action: str) -> str:
        """Explain why an action was taken"""
        # Check recent reflections
        for reflection in reversed(self._reflections):
            if action.lower() in reflection.action.lower():
                reasons = []
                reasons.extend(reflection.what_went_well)
                if reflection.lessons_learned:
                    reasons.append(f"Based on: {reflection.lessons_learned[0]}")
                
                if reasons:
                    return f"I {action} because: " + "; ".join(reasons)
        
        # Check value alignment
        alignment = self.check_value_alignment(action)
        if alignment["supporting_values"]:
            values = ", ".join(alignment["supporting_values"])
            return f"I {action} because it aligns with my values of {values}"
        
        return f"I {action} as it seemed the best approach for the situation"
    
    def what_would_i_do(self, situation: str) -> str:
        """Predict what agent would do in a situation"""
        # Check capabilities
        relevant_caps = []
        for cap in self._capabilities.values():
            if any(word in situation.lower() for word in cap.description.lower().split()):
                relevant_caps.append(cap.name)
        
        if relevant_caps:
            return f"In this situation, I would use my {', '.join(relevant_caps)} capabilities"
        
        return "I would analyze the situation and determine the best approach based on my capabilities and values"
    
    def get_stats(self) -> Dict[str, Any]:
        """Get self model statistics"""
        return {
            "capabilities": len(self._capabilities),
            "limitations": len(self._limitations),
            "values": len(self._values),
            "reflections": len(self._reflections),
            "success_rate": self.get_success_rate(),
            "uptime_hours": (datetime.now() - self._start_time).total_seconds() / 3600
        }


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

async def create_self_model(
    identity_manager: Optional[Any] = None,
    learning_engine: Optional[Any] = None
) -> SelfModel:
    """Create self model"""
    model = SelfModel(
        identity_manager=identity_manager,
        learning_engine=learning_engine
    )
    
    return model