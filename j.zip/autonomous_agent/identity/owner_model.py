"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                           OWNER MODEL                                         ║
║              Model of the Owner for Personalized Interaction                  ║
╚══════════════════════════════════════════════════════════════════════════════╝

The Owner Model maintains:
- Understanding of owner's preferences
- Communication style adaptation
- Historical patterns
- Relationship dynamics
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Set
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict

logger = logging.getLogger(__name__)


class CommunicationStyle(Enum):
    """Owner's communication style"""
    CASUAL = "casual"
    BALANCED = "balanced"
    FORMAL = "formal"


class ExpertiseLevel(Enum):
    """Owner's expertise level in a domain"""
    BEGINNER = "beginner"
    INTERMEDIATE = "intermediate"
    ADVANCED = "advanced"
    EXPERT = "expert"


class MoodIndicator(Enum):
    """Detected mood indicators"""
    HAPPY = "happy"
    NEUTRAL = "neutral"
    FRUSTRATED = "frustrated"
    BUSY = "busy"
    CURIOUS = "curious"
    UNCERTAIN = "uncertain"


@dataclass
class Preference:
    """An owner preference"""
    key: str
    value: Any
    category: str
    
    # Tracking
    set_explicitly: bool = False
    inferred: bool = False
    confidence: float = 1.0
    
    # History
    set_at: datetime = field(default_factory=datetime.now)
    times_used: int = 0
    last_used: Optional[datetime] = None


@dataclass
class InteractionPattern:
    """A pattern in owner's interactions"""
    pattern_type: str
    description: str
    frequency: int
    examples: List[str] = field(default_factory=list)
    first_observed: datetime = field(default_factory=datetime.now)
    last_observed: datetime = field(default_factory=datetime.now)


@dataclass
class TopicInterest:
    """Owner's interest in a topic"""
    topic: str
    interest_level: float  # 0-1
    expertise: ExpertiseLevel
    
    # Tracking
    mentions: int = 0
    questions_asked: int = 0
    teachings_given: int = 0
    
    last_discussed: Optional[datetime] = None


@dataclass
class OwnerContext:
    """Current context about the owner"""
    # Current session
    current_mood: MoodIndicator = MoodIndicator.NEUTRAL
    is_busy: bool = False
    is_in_hurry: bool = False
    
    # Current focus
    current_topic: Optional[str] = None
    current_task: Optional[str] = None
    
    # Session stats
    session_start: datetime = field(default_factory=datetime.now)
    messages_this_session: int = 0
    
    # Inferred context
    likely_goal: Optional[str] = None
    frustration_level: float = 0.0


class OwnerModel:
    """
    Model of the owner for personalized interaction
    
    Features:
    - Preference tracking
    - Communication style adaptation
    - Interest and expertise modeling
    - Pattern recognition
    - Context awareness
    """
    
    def __init__(
        self,
        identity_manager: Optional[Any] = None,
        memory_manager: Optional[Any] = None
    ):
        self.identity_manager = identity_manager
        self.memory_manager = memory_manager
        
        # Preferences
        self._preferences: Dict[str, Preference] = {}
        
        # Interests
        self._interests: Dict[str, TopicInterest] = {}
        
        # Patterns
        self._patterns: List[InteractionPattern] = []
        
        # Context
        self._context = OwnerContext()
        
        # Communication
        self._comm_style = CommunicationStyle.BALANCED
        self._verbosity = "normal"  # brief, normal, verbose
        
        # History
        self._interaction_times: List[datetime] = []
        self._common_requests: Dict[str, int] = defaultdict(int)
        self._feedback_history: List[Dict] = []
        
        # Initialize default preferences
        self._initialize_defaults()
        
        logger.info("OwnerModel initialized")
    
    def _initialize_defaults(self) -> None:
        """Initialize default preferences"""
        defaults = [
            Preference(
                key="confirm_destructive",
                value=True,
                category="safety",
                set_explicitly=False,
                inferred=False
            ),
            Preference(
                key="show_progress",
                value=True,
                category="feedback",
                set_explicitly=False,
                inferred=False
            ),
            Preference(
                key="auto_save",
                value=True,
                category="behavior",
                set_explicitly=False,
                inferred=False
            )
        ]
        
        for pref in defaults:
            self._preferences[pref.key] = pref
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PREFERENCES
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def set_preference(
        self,
        key: str,
        value: Any,
        category: str = "general",
        explicit: bool = True
    ) -> None:
        """Set a preference"""
        self._preferences[key] = Preference(
            key=key,
            value=value,
            category=category,
            set_explicitly=explicit,
            inferred=not explicit,
            confidence=1.0 if explicit else 0.7
        )
        
        # Store in memory
        if self.memory_manager and explicit:
            await self.memory_manager.store_memory(
                content={"preference": key, "value": value},
                memory_type="preference",
                tags=["owner_preference", category]
            )
        
        logger.debug(f"Set preference: {key} = {value}")
    
    async def get_preference(
        self,
        key: str,
        default: Any = None
    ) -> Any:
        """Get a preference value"""
        if key in self._preferences:
            pref = self._preferences[key]
            pref.times_used += 1
            pref.last_used = datetime.now()
            return pref.value
        
        return default
    
    async def infer_preference(
        self,
        key: str,
        value: Any,
        confidence: float = 0.5
    ) -> None:
        """Infer a preference from behavior"""
        if key in self._preferences:
            existing = self._preferences[key]
            # Only update if explicitly set or lower confidence
            if existing.set_explicitly:
                return
            if existing.confidence > confidence:
                return
        
        self._preferences[key] = Preference(
            key=key,
            value=value,
            category="inferred",
            set_explicitly=False,
            inferred=True,
            confidence=confidence
        )
        
        logger.debug(f"Inferred preference: {key} = {value} (confidence: {confidence})")
    
    async def get_preferences_by_category(
        self,
        category: str
    ) -> Dict[str, Any]:
        """Get all preferences in a category"""
        return {
            key: pref.value
            for key, pref in self._preferences.items()
            if pref.category == category
        }
    
    async def clear_inferred_preferences(self) -> int:
        """Clear inferred preferences"""
        to_remove = [
            key for key, pref in self._preferences.items()
            if pref.inferred and not pref.set_explicitly
        ]
        
        for key in to_remove:
            del self._preferences[key]
        
        return len(to_remove)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # COMMUNICATION STYLE
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def set_communication_style(
        self,
        style: CommunicationStyle
    ) -> None:
        """Set preferred communication style"""
        self._comm_style = style
        await self.set_preference(
            "communication_style",
            style.value,
            category="communication"
        )
    
    def get_communication_style(self) -> CommunicationStyle:
        """Get current communication style"""
        return self._comm_style
    
    async def set_verbosity(self, level: str) -> None:
        """Set verbosity preference"""
        if level in ["brief", "normal", "verbose"]:
            self._verbosity = level
            await self.set_preference(
                "verbosity",
                level,
                category="communication"
            )
    
    def get_verbosity(self) -> str:
        """Get verbosity level"""
        return self._verbosity
    
    def should_be_brief(self) -> bool:
        """Check if responses should be brief"""
        return (
            self._verbosity == "brief" or
            self._context.is_busy or
            self._context.is_in_hurry
        )
    
    def should_be_detailed(self) -> bool:
        """Check if responses should be detailed"""
        return (
            self._verbosity == "verbose" or
            self._context.current_mood == MoodIndicator.CURIOUS
        )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # INTERESTS AND EXPERTISE
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def record_topic_interest(
        self,
        topic: str,
        interaction_type: str = "mention"
    ) -> None:
        """Record interest in a topic"""
        if topic not in self._interests:
            self._interests[topic] = TopicInterest(
                topic=topic,
                interest_level=0.5,
                expertise=ExpertiseLevel.BEGINNER
            )
        
        interest = self._interests[topic]
        interest.last_discussed = datetime.now()
        
        if interaction_type == "mention":
            interest.mentions += 1
            interest.interest_level = min(1.0, interest.interest_level + 0.05)
        elif interaction_type == "question":
            interest.questions_asked += 1
            interest.interest_level = min(1.0, interest.interest_level + 0.1)
        elif interaction_type == "teaching":
            interest.teachings_given += 1
            interest.interest_level = min(1.0, interest.interest_level + 0.1)
            # Teaching indicates expertise
            if interest.expertise.value < ExpertiseLevel.ADVANCED.value:
                interest.expertise = ExpertiseLevel(
                    min(interest.expertise.value + 1, ExpertiseLevel.EXPERT.value)
                )
    
    async def get_top_interests(self, limit: int = 5) -> List[TopicInterest]:
        """Get top interests by level"""
        sorted_interests = sorted(
            self._interests.values(),
            key=lambda x: x.interest_level,
            reverse=True
        )
        return sorted_interests[:limit]
    
    async def get_expertise_level(self, topic: str) -> ExpertiseLevel:
        """Get owner's expertise in a topic"""
        if topic in self._interests:
            return self._interests[topic].expertise
        return ExpertiseLevel.BEGINNER
    
    def should_explain_details(self, topic: str) -> bool:
        """Check if detailed explanations are needed for topic"""
        if topic in self._interests:
            expertise = self._interests[topic].expertise
            return expertise in [ExpertiseLevel.BEGINNER, ExpertiseLevel.INTERMEDIATE]
        return True  # Default to explaining
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CONTEXT
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_context(self) -> OwnerContext:
        """Get current context"""
        return self._context
    
    async def update_context(
        self,
        mood: Optional[MoodIndicator] = None,
        is_busy: Optional[bool] = None,
        is_in_hurry: Optional[bool] = None,
        current_topic: Optional[str] = None,
        current_task: Optional[str] = None
    ) -> None:
        """Update owner context"""
        if mood is not None:
            self._context.current_mood = mood
        if is_busy is not None:
            self._context.is_busy = is_busy
        if is_in_hurry is not None:
            self._context.is_in_hurry = is_in_hurry
        if current_topic is not None:
            self._context.current_topic = current_topic
        if current_task is not None:
            self._context.current_task = current_task
    
    async def detect_mood_from_message(self, message: str) -> MoodIndicator:
        """Detect mood from message content"""
        message_lower = message.lower()
        
        # Frustration indicators
        frustration_words = ["frustrated", "annoyed", "angry", "hate", "stupid", "why won't", "not working"]
        if any(word in message_lower for word in frustration_words):
            self._context.frustration_level = min(1.0, self._context.frustration_level + 0.2)
            return MoodIndicator.FRUSTRATED
        
        # Happy indicators
        happy_words = ["thanks", "great", "awesome", "perfect", "love", "amazing", "excellent"]
        if any(word in message_lower for word in happy_words):
            self._context.frustration_level = max(0.0, self._context.frustration_level - 0.1)
            return MoodIndicator.HAPPY
        
        # Busy/hurry indicators
        hurry_words = ["quick", "fast", "asap", "urgent", "hurry", "immediately"]
        if any(word in message_lower for word in hurry_words):
            self._context.is_in_hurry = True
            return MoodIndicator.BUSY
        
        # Curious indicators
        curious_words = ["how", "why", "what if", "explain", "curious", "wonder"]
        if any(word in message_lower for word in curious_words):
            return MoodIndicator.CURIOUS
        
        # Uncertain indicators
        uncertain_words = ["not sure", "maybe", "perhaps", "might", "confused", "don't know"]
        if any(word in message_lower for word in uncertain_words):
            return MoodIndicator.UNCERTAIN
        
        return MoodIndicator.NEUTRAL
    
    async def record_interaction(self, message: str) -> None:
        """Record an interaction"""
        now = datetime.now()
        self._interaction_times.append(now)
        self._context.messages_this_session += 1
        
        # Detect mood
        mood = await self.detect_mood_from_message(message)
        self._context.current_mood = mood
        
        # Track common requests
        words = message.lower().split()
        if words:
            first_word = words[0]
            if first_word in ["run", "show", "list", "create", "delete", "find", "help"]:
                self._common_requests[first_word] += 1
        
        # Trim history
        if len(self._interaction_times) > 1000:
            self._interaction_times = self._interaction_times[-1000:]
    
    def start_new_session(self) -> None:
        """Start a new session"""
        self._context = OwnerContext()
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PATTERNS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def detect_patterns(self) -> List[InteractionPattern]:
        """Detect patterns in owner's behavior"""
        patterns = []
        
        # Time-based patterns
        if len(self._interaction_times) >= 10:
            hours = [t.hour for t in self._interaction_times[-100:]]
            
            # Morning person
            morning_count = sum(1 for h in hours if 6 <= h < 12)
            if morning_count > len(hours) * 0.5:
                patterns.append(InteractionPattern(
                    pattern_type="time",
                    description="Most active in the morning",
                    frequency=morning_count
                ))
            
            # Night owl
            night_count = sum(1 for h in hours if h >= 22 or h < 6)
            if night_count > len(hours) * 0.3:
                patterns.append(InteractionPattern(
                    pattern_type="time",
                    description="Often active at night",
                    frequency=night_count
                ))
        
        # Request patterns
        for request, count in self._common_requests.items():
            if count >= 5:
                patterns.append(InteractionPattern(
                    pattern_type="request",
                    description=f"Frequently uses '{request}' commands",
                    frequency=count
                ))
        
        self._patterns = patterns
        return patterns
    
    def get_patterns(self) -> List[InteractionPattern]:
        """Get detected patterns"""
        return self._patterns
    
    # ═══════════════════════════════════════════════════════════════════════════
    # FEEDBACK
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def record_feedback(
        self,
        feedback_type: str,
        positive: bool,
        context: Optional[str] = None
    ) -> None:
        """Record feedback from owner"""
        self._feedback_history.append({
            "type": feedback_type,
            "positive": positive,
            "context": context,
            "timestamp": datetime.now().isoformat()
        })
        
        # Update frustration level
        if positive:
            self._context.frustration_level = max(0.0, self._context.frustration_level - 0.1)
        else:
            self._context.frustration_level = min(1.0, self._context.frustration_level + 0.15)
        
        # Trim history
        if len(self._feedback_history) > 100:
            self._feedback_history = self._feedback_history[-100:]
    
    def get_satisfaction_score(self) -> float:
        """Calculate overall satisfaction score"""
        if not self._feedback_history:
            return 0.7  # Neutral default
        
        recent = self._feedback_history[-20:]
        positive_count = sum(1 for f in recent if f["positive"])
        
        return positive_count / len(recent)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # ADAPTATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_response_guidelines(self) -> Dict[str, Any]:
        """Get guidelines for generating responses"""
        guidelines = {
            "tone": self._comm_style.value,
            "verbosity": self._verbosity,
            "be_brief": self.should_be_brief(),
            "be_detailed": self.should_be_detailed(),
            "show_empathy": self._context.frustration_level > 0.5,
            "be_encouraging": self._context.current_mood == MoodIndicator.UNCERTAIN,
            "acknowledge_expertise": {},
            "current_topic": self._context.current_topic
        }
        
        # Add expertise acknowledgment
        for topic, interest in self._interests.items():
            if interest.expertise in [ExpertiseLevel.ADVANCED, ExpertiseLevel.EXPERT]:
                guidelines["acknowledge_expertise"][topic] = interest.expertise.value
        
        return guidelines
    
    def adapt_response(self, response: str) -> str:
        """Adapt a response based on owner model"""
        # Apply verbosity
        if self.should_be_brief() and len(response) > 200:
            # Try to truncate to key points
            sentences = response.split('. ')
            if len(sentences) > 3:
                response = '. '.join(sentences[:3]) + '.'
        
        # Add empathy if frustrated
        if self._context.frustration_level > 0.5:
            empathy_phrases = [
                "I understand this might be frustrating. ",
                "Let me help resolve this. ",
                "I see the issue. "
            ]
            import random
            response = random.choice(empathy_phrases) + response
        
        return response
    
    # ═══════════════════════════════════════════════════════════════════════════
    # UTILITIES
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def get_owner_summary(self) -> Dict[str, Any]:
        """Get summary of owner model"""
        return {
            "communication_style": self._comm_style.value,
            "verbosity": self._verbosity,
            "current_mood": self._context.current_mood.value,
            "frustration_level": self._context.frustration_level,
            "satisfaction_score": self.get_satisfaction_score(),
            "preferences_count": len(self._preferences),
            "interests_count": len(self._interests),
            "patterns_count": len(self._patterns),
            "total_interactions": len(self._interaction_times)
        }
    
    def get_stats(self) -> Dict[str, Any]:
        """Get model statistics"""
        return {
            "preferences": len(self._preferences),
            "explicit_preferences": sum(1 for p in self._preferences.values() if p.set_explicitly),
            "inferred_preferences": sum(1 for p in self._preferences.values() if p.inferred),
            "interests": len(self._interests),
            "patterns": len(self._patterns),
            "feedback_count": len(self._feedback_history),
            "satisfaction": self.get_satisfaction_score()
        }


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

async def create_owner_model(
    identity_manager: Optional[Any] = None,
    memory_manager: Optional[Any] = None
) -> OwnerModel:
    """Create owner model"""
    model = OwnerModel(
        identity_manager=identity_manager,
        memory_manager=memory_manager
    )
    
    return model