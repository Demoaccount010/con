#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 CODE ANALYZER - Safety and Quality Analysis
═══════════════════════════════════════════════════════════════════════════════

 Analyzes generated code for safety, quality, and potential issues.
 
 Author: System Engineer
 Version: 1.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import ast
import logging
from typing import Dict, Any, List, Optional
import re

logger = logging.getLogger(__name__)


class CodeAnalyzer:
    """
    Analyzes code for safety and quality.
    
    Checks for:
    - Dangerous operations (file deletion, system calls, etc.)
    - Syntax errors
    - Security issues
    - Code quality
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize code analyzer."""
        self.logger = logging.getLogger("code_analyzer")
        self.config = config or {}
        
        # Dangerous patterns
        self.dangerous_imports = {
            'os.system', 'subprocess', 'eval', 'exec', '__import__',
            'compile', 'shutil.rmtree'
        }
        
        self.dangerous_functions = {
            'eval', 'exec', 'compile', '__import__', 'system',
            'rmtree', 'remove', 'unlink'
        }
        
        self.logger.info("Code analyzer initialized")
    
    async def analyze_code(
        self,
        generated_code: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Analyze generated code for safety and quality.
        
        Args:
            generated_code: Dictionary with 'files' containing code
            
        Returns:
            Analysis result with safety status
        """
        try:
            result = {
                "safe": True,
                "warnings": [],
                "errors": [],
                "severity": "low",
                "details": {}
            }
            
            files = generated_code.get("files", {})
            
            for filename, code in files.items():
                file_analysis = await self._analyze_file(filename, code)
                
                result["details"][filename] = file_analysis
                
                # Aggregate results
                if file_analysis["errors"]:
                    result["errors"].extend(file_analysis["errors"])
                    result["safe"] = False
                    result["severity"] = "high"
                
                if file_analysis["warnings"]:
                    result["warnings"].extend(file_analysis["warnings"])
                    if result["severity"] == "low":
                        result["severity"] = "medium"
                
                if file_analysis.get("dangerous_operations"):
                    result["safe"] = False
                    result["severity"] = "critical"
                    result["reason"] = "Dangerous operations detected"
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error analyzing code: {e}")
            return {
                "safe": False,
                "reason": f"Analysis failed: {str(e)}",
                "warnings": [],
                "errors": [str(e)]
            }
    
    async def _analyze_file(
        self,
        filename: str,
        code: str
    ) -> Dict[str, Any]:
        """Analyze a single file."""
        analysis = {
            "filename": filename,
            "syntax_valid": False,
            "dangerous_operations": [],
            "warnings": [],
            "errors": [],
            "metrics": {}
        }
        
        try:
            # Check syntax
            try:
                tree = ast.parse(code)
                analysis["syntax_valid"] = True
            except SyntaxError as e:
                analysis["errors"].append(f"Syntax error: {e}")
                return analysis
            
            # Check for dangerous operations
            dangerous = self._check_dangerous_operations(code, tree)
            if dangerous:
                analysis["dangerous_operations"] = dangerous
            
            # Check imports
            dangerous_imports = self._check_dangerous_imports(tree)
            if dangerous_imports:
                analysis["warnings"].append(f"Potentially dangerous imports: {dangerous_imports}")
            
            # Basic metrics
            analysis["metrics"] = self._calculate_metrics(code, tree)
            
        except Exception as e:
            analysis["errors"].append(f"Analysis error: {e}")
        
        return analysis
    
    def _check_dangerous_operations(
        self,
        code: str,
        tree: ast.AST
    ) -> List[str]:
        """Check for dangerous operations in code."""
        dangerous = []
        
        # Check for dangerous function calls
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                func_name = self._get_function_name(node)
                if func_name in self.dangerous_functions:
                    dangerous.append(f"Dangerous function: {func_name}")
        
        # Check for file deletion patterns
        if re.search(r'\b(remove|unlink|rmtree)\s*\(', code):
            dangerous.append("File deletion operations detected")
        
        # Check for system calls
        if re.search(r'\b(system|popen|spawn)\s*\(', code):
            dangerous.append("System command execution detected")
        
        return dangerous
    
    def _check_dangerous_imports(self, tree: ast.AST) -> List[str]:
        """Check for dangerous imports."""
        dangerous = []
        
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if any(d in alias.name for d in ['subprocess', 'os']):
                        dangerous.append(alias.name)
            
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    full_name = f"{node.module}.{node.names[0].name if node.names else ''}"
                    if any(d in full_name for d in self.dangerous_imports):
                        dangerous.append(full_name)
        
        return dangerous
    
    def _get_function_name(self, node: ast.Call) -> str:
        """Extract function name from call node."""
        if isinstance(node.func, ast.Name):
            return node.func.id
        elif isinstance(node.func, ast.Attribute):
            return node.func.attr
        return ""
    
    def _calculate_metrics(
        self,
        code: str,
        tree: ast.AST
    ) -> Dict[str, Any]:
        """Calculate code metrics."""
        lines = code.split('\n')
        
        return {
            "lines_of_code": len(lines),
            "non_empty_lines": len([l for l in lines if l.strip()]),
            "functions": len([n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)]),
            "classes": len([n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)])
        }


def create_code_analyzer(config: Optional[Dict[str, Any]] = None) -> CodeAnalyzer:
    """Create code analyzer instance."""
    return CodeAnalyzer(config=config)
