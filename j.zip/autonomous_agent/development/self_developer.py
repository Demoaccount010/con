#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 SELF DEVELOPER - Main Self-Development Controller
═══════════════════════════════════════════════════════════════════════════════

 Enables the agent to develop new features and modify its own code
 based on owner requests with proper safety checks and approval workflow.
 
 Author: System Engineer
 Version: 1.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
from datetime import datetime
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from uuid import uuid4

logger = logging.getLogger(__name__)


class DevelopmentPhase(Enum):
    """Phases of feature development."""
    UNDERSTANDING = "understanding"
    PLANNING = "planning"
    APPROVAL_PLAN = "approval_plan"
    GENERATING = "generating"
    REVIEWING = "reviewing"
    APPROVAL_CODE = "approval_code"
    TESTING = "testing"
    DEPLOYING = "deploying"
    MONITORING = "monitoring"
    COMPLETE = "complete"
    FAILED = "failed"
    ROLLED_BACK = "rolled_back"


class FeatureType(Enum):
    """Types of features that can be developed."""
    PLUGIN = "plugin"
    TOOL = "tool"
    ENHANCEMENT = "enhancement"
    INTEGRATION = "integration"
    AUTOMATION = "automation"


@dataclass
class FeatureRequest:
    """User request for a new feature."""
    id: str = field(default_factory=lambda: str(uuid4()))
    description: str = ""
    requested_by: str = ""
    requested_at: datetime = field(default_factory=datetime.now)
    
    # Classification
    feature_type: Optional[FeatureType] = None
    priority: str = "medium"
    
    # Context
    context: Dict[str, Any] = field(default_factory=dict)
    examples: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "description": self.description,
            "requested_by": self.requested_by,
            "feature_type": self.feature_type.value if self.feature_type else None,
            "priority": self.priority
        }


@dataclass
class DevelopmentPlan:
    """Plan for developing a feature."""
    id: str = field(default_factory=lambda: str(uuid4()))
    request_id: str = ""
    
    # Plan details
    title: str = ""
    description: str = ""
    feature_type: FeatureType = FeatureType.PLUGIN
    
    # Implementation
    steps: List[Dict[str, Any]] = field(default_factory=list)
    files_to_create: List[str] = field(default_factory=list)
    files_to_modify: List[str] = field(default_factory=list)
    
    # Requirements
    dependencies: List[str] = field(default_factory=list)
    permissions_needed: List[str] = field(default_factory=list)
    
    # Safety
    safety_concerns: List[str] = field(default_factory=list)
    rollback_plan: str = ""
    
    # Approval
    approved: bool = False
    approved_by: Optional[str] = None
    approved_at: Optional[datetime] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "feature_type": self.feature_type.value,
            "steps": self.steps,
            "files_to_create": self.files_to_create,
            "files_to_modify": self.files_to_modify,
            "dependencies": self.dependencies,
            "safety_concerns": self.safety_concerns,
            "approved": self.approved
        }


@dataclass
class DevelopmentResult:
    """Result of development process."""
    success: bool = False
    feature_id: Optional[str] = None
    phase: DevelopmentPhase = DevelopmentPhase.UNDERSTANDING
    
    # Generated artifacts
    generated_files: List[str] = field(default_factory=list)
    modified_files: List[str] = field(default_factory=list)
    
    # Testing
    tests_passed: bool = False
    test_results: Dict[str, Any] = field(default_factory=dict)
    
    # Deployment
    deployed: bool = False
    deployment_path: Optional[str] = None
    
    # Errors
    error: Optional[str] = None
    warnings: List[str] = field(default_factory=list)


class SelfDeveloper:
    """
    Main self-development controller.
    
    This system allows the agent to develop new features based on
    owner requests with proper safety checks and approval workflow.
    """
    
    def __init__(
        self,
        llm_client: Optional[Any] = None,
        owner_verification: Optional[Any] = None,
        code_generator: Optional[Any] = None,
        code_analyzer: Optional[Any] = None,
        test_runner: Optional[Any] = None,
        deployment_manager: Optional[Any] = None,
        learning_engine: Optional[Any] = None,
        config: Optional[Dict[str, Any]] = None
    ):
        """Initialize self developer."""
        self.logger = logging.getLogger("self_developer")
        
        # Dependencies
        self.llm_client = llm_client
        self.owner_verification = owner_verification
        self.code_generator = code_generator
        self.code_analyzer = code_analyzer
        self.test_runner = test_runner
        self.deployment_manager = deployment_manager
        self.learning_engine = learning_engine
        
        # Configuration
        self.config = config or {}
        self.enabled = self.config.get("enabled", True)
        self.require_approval = self.config.get("require_owner_approval", True)
        self.max_features_per_hour = self.config.get("max_features_per_hour", 5)
        self.sandbox_enabled = self.config.get("sandbox_enabled", True)
        
        # State
        self.active_developments: Dict[str, Dict[str, Any]] = {}
        self.completed_features: List[str] = []
        self.feature_count_hour = 0
        self.last_reset_time = datetime.now()
        
        self.logger.info("Self developer initialized")
    
    async def develop_feature(
        self,
        request: FeatureRequest,
        owner_id: str
    ) -> DevelopmentResult:
        """
        Main entry point for feature development.
        
        Args:
            request: Feature request from owner
            owner_id: ID of owner requesting feature
            
        Returns:
            DevelopmentResult with outcome
        """
        result = DevelopmentResult()
        
        try:
            # Check if enabled
            if not self.enabled:
                result.error = "Self-development is disabled"
                result.phase = DevelopmentPhase.FAILED
                return result
            
            # Check rate limit
            if not await self._check_rate_limit():
                result.error = "Rate limit exceeded. Please try again later."
                result.phase = DevelopmentPhase.FAILED
                return result
            
            # Verify owner
            if self.owner_verification:
                is_owner = await self.owner_verification.verify_owner_identity(owner_id)
                if not is_owner:
                    result.error = "Only owner can request feature development"
                    result.phase = DevelopmentPhase.FAILED
                    return result
            
            self.logger.info(f"Starting feature development: {request.id}")
            
            # Phase 1: Understand requirement
            result.phase = DevelopmentPhase.UNDERSTANDING
            requirement = await self._understand_requirement(request)
            if not requirement:
                result.error = "Failed to understand requirement"
                result.phase = DevelopmentPhase.FAILED
                return result
            
            # Phase 2: Create development plan
            result.phase = DevelopmentPhase.PLANNING
            plan = await self._create_development_plan(requirement, request)
            if not plan:
                result.error = "Failed to create development plan"
                result.phase = DevelopmentPhase.FAILED
                return result
            
            # Phase 3: Get owner approval for plan
            if self.require_approval:
                result.phase = DevelopmentPhase.APPROVAL_PLAN
                approved = await self._get_owner_approval_plan(plan, owner_id)
                if not approved:
                    result.error = "Plan not approved by owner"
                    result.phase = DevelopmentPhase.FAILED
                    return result
            
            # Phase 4: Generate code
            result.phase = DevelopmentPhase.GENERATING
            generated_code = await self._generate_code(plan)
            if not generated_code:
                result.error = "Failed to generate code"
                result.phase = DevelopmentPhase.FAILED
                return result
            
            # Phase 5: Review code safety
            result.phase = DevelopmentPhase.REVIEWING
            safety_result = await self._review_code_safety(generated_code)
            if not safety_result["safe"]:
                result.error = f"Code safety check failed: {safety_result.get('reason')}"
                result.warnings = safety_result.get("warnings", [])
                result.phase = DevelopmentPhase.FAILED
                return result
            
            # Phase 6: Get owner approval for code
            if self.require_approval:
                result.phase = DevelopmentPhase.APPROVAL_CODE
                approved = await self._get_owner_approval_code(
                    generated_code, plan, owner_id
                )
                if not approved:
                    result.error = "Code not approved by owner"
                    result.phase = DevelopmentPhase.FAILED
                    return result
            
            # Phase 7: Test code
            result.phase = DevelopmentPhase.TESTING
            test_results = await self._test_code(generated_code, plan)
            result.test_results = test_results
            result.tests_passed = test_results.get("passed", False)
            
            if not result.tests_passed:
                result.error = "Tests failed"
                result.warnings.append("Some tests did not pass")
                # Continue anyway if owner approved
            
            # Phase 8: Deploy
            result.phase = DevelopmentPhase.DEPLOYING
            deployment = await self._deploy_feature(generated_code, plan)
            if not deployment["success"]:
                result.error = f"Deployment failed: {deployment.get('error')}"
                result.phase = DevelopmentPhase.FAILED
                return result
            
            result.deployed = True
            result.deployment_path = deployment.get("path")
            result.generated_files = deployment.get("files", [])
            
            # Phase 9: Monitor
            result.phase = DevelopmentPhase.MONITORING
            await self._monitor_feature(deployment["feature_id"])
            
            # Success!
            result.phase = DevelopmentPhase.COMPLETE
            result.success = True
            result.feature_id = deployment["feature_id"]
            
            # Learn from success
            if self.learning_engine:
                await self._learn_from_success(request, plan, result)
            
            self.completed_features.append(result.feature_id)
            self.feature_count_hour += 1
            
            self.logger.info(f"Feature development complete: {result.feature_id}")
            
        except Exception as e:
            self.logger.error(f"Feature development failed: {e}", exc_info=True)
            result.error = str(e)
            result.phase = DevelopmentPhase.FAILED
        
        return result
    
    async def _understand_requirement(
        self,
        request: FeatureRequest
    ) -> Optional[Dict[str, Any]]:
        """Understand and clarify the requirement."""
        try:
            if not self.llm_client:
                return {
                    "description": request.description,
                    "type": "plugin",
                    "scope": "unknown"
                }
            
            # Use LLM to understand requirement
            prompt = f"""Analyze this feature request and provide structured understanding:

Request: {request.description}

Provide:
1. Clear description of what user wants
2. Feature type (plugin, tool, enhancement, integration, automation)
3. Key requirements
4. Scope and complexity
5. Potential challenges

Format as JSON."""
            
            response = await self.llm_client.generate(
                prompt=prompt,
                temperature=0.3
            )
            
            # Parse response (simplified)
            requirement = {
                "description": request.description,
                "type": request.feature_type or "plugin",
                "scope": "medium",
                "llm_analysis": response
            }
            
            self.logger.info("Requirement understood")
            return requirement
            
        except Exception as e:
            self.logger.error(f"Error understanding requirement: {e}")
            return None
    
    async def _create_development_plan(
        self,
        requirement: Dict[str, Any],
        request: FeatureRequest
    ) -> Optional[DevelopmentPlan]:
        """Create detailed development plan."""
        try:
            plan = DevelopmentPlan(
                request_id=request.id,
                title=f"Develop: {requirement['description'][:50]}",
                description=requirement['description'],
                feature_type=FeatureType.PLUGIN
            )
            
            # Determine what needs to be created
            if requirement['type'] == 'plugin':
                plan.files_to_create = [
                    f"plugins/installed/{request.id}/plugin.py",
                    f"plugins/installed/{request.id}/plugin.yaml"
                ]
            
            # Add implementation steps
            plan.steps = [
                {"step": 1, "action": "Create plugin structure"},
                {"step": 2, "action": "Generate plugin code"},
                {"step": 3, "action": "Create plugin metadata"},
                {"step": 4, "action": "Generate tests"},
                {"step": 5, "action": "Deploy plugin"}
            ]
            
            # Safety concerns
            plan.safety_concerns = [
                "Generated code will be reviewed",
                "Code will run in sandbox first",
                "Owner approval required"
            ]
            
            # Rollback plan
            plan.rollback_plan = "Plugin can be disabled and removed immediately"
            
            self.logger.info(f"Development plan created: {plan.id}")
            return plan
            
        except Exception as e:
            self.logger.error(f"Error creating plan: {e}")
            return None
    
    async def _get_owner_approval_plan(
        self,
        plan: DevelopmentPlan,
        owner_id: str
    ) -> bool:
        """Get owner approval for development plan."""
        try:
            if not self.owner_verification:
                return True
            
            # Create approval request
            approval_request = await self.owner_verification.require_approval(
                action="develop_feature_plan",
                level=self.owner_verification.VerificationLevel.HIGH,
                details=plan.to_dict(),
                description=f"Approve development plan: {plan.title}"
            )
            
            # Wait for approval
            status = await self.owner_verification.wait_for_approval(
                approval_request.id
            )
            
            approved = status == self.owner_verification.ApprovalStatus.APPROVED
            
            if approved:
                plan.approved = True
                plan.approved_by = owner_id
                plan.approved_at = datetime.now()
            
            return approved
            
        except Exception as e:
            self.logger.error(f"Error getting plan approval: {e}")
            return False
    
    async def _generate_code(
        self,
        plan: DevelopmentPlan
    ) -> Optional[Dict[str, Any]]:
        """Generate code for the feature."""
        try:
            if not self.code_generator:
                return {"files": {}, "success": False}
            
            # Generate code using code generator
            generated = await self.code_generator.generate_from_plan(plan)
            
            return generated
            
        except Exception as e:
            self.logger.error(f"Error generating code: {e}")
            return None
    
    async def _review_code_safety(
        self,
        generated_code: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Review generated code for safety."""
        try:
            if not self.code_analyzer:
                return {"safe": True, "warnings": []}
            
            # Analyze code
            analysis = await self.code_analyzer.analyze_code(generated_code)
            
            return analysis
            
        except Exception as e:
            self.logger.error(f"Error reviewing code: {e}")
            return {"safe": False, "reason": str(e)}
    
    async def _get_owner_approval_code(
        self,
        generated_code: Dict[str, Any],
        plan: DevelopmentPlan,
        owner_id: str
    ) -> bool:
        """Get owner approval for generated code."""
        try:
            if not self.owner_verification:
                return True
            
            # Create approval request with code preview
            approval_request = await self.owner_verification.require_approval(
                action="deploy_generated_code",
                level=self.owner_verification.VerificationLevel.CRITICAL,
                details={
                    "plan_id": plan.id,
                    "files": list(generated_code.get("files", {}).keys()),
                    "code_preview": self._create_code_preview(generated_code)
                },
                description=f"Approve generated code for: {plan.title}"
            )
            
            # Wait for approval
            status = await self.owner_verification.wait_for_approval(
                approval_request.id
            )
            
            return status == self.owner_verification.ApprovalStatus.APPROVED
            
        except Exception as e:
            self.logger.error(f"Error getting code approval: {e}")
            return False
    
    async def _test_code(
        self,
        generated_code: Dict[str, Any],
        plan: DevelopmentPlan
    ) -> Dict[str, Any]:
        """Test generated code."""
        try:
            if not self.test_runner:
                return {"passed": True, "tests": []}
            
            # Run tests
            results = await self.test_runner.run_tests(generated_code)
            
            return results
            
        except Exception as e:
            self.logger.error(f"Error testing code: {e}")
            return {"passed": False, "error": str(e)}
    
    async def _deploy_feature(
        self,
        generated_code: Dict[str, Any],
        plan: DevelopmentPlan
    ) -> Dict[str, Any]:
        """Deploy the feature."""
        try:
            if not self.deployment_manager:
                return {"success": False, "error": "No deployment manager"}
            
            # Deploy
            result = await self.deployment_manager.deploy(generated_code, plan)
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error deploying feature: {e}")
            return {"success": False, "error": str(e)}
    
    async def _monitor_feature(self, feature_id: str) -> None:
        """Monitor deployed feature."""
        try:
            # Monitor for 5 minutes
            self.logger.info(f"Monitoring feature: {feature_id}")
            await asyncio.sleep(5)  # Simplified monitoring
            
        except Exception as e:
            self.logger.error(f"Error monitoring feature: {e}")
    
    async def _learn_from_success(
        self,
        request: FeatureRequest,
        plan: DevelopmentPlan,
        result: DevelopmentResult
    ) -> None:
        """Learn from successful feature development."""
        try:
            if not self.learning_engine:
                return
            
            # Record learning
            await self.learning_engine.learn_from_success(
                action="feature_development",
                context={
                    "request": request.to_dict(),
                    "plan": plan.to_dict(),
                    "result": "success"
                }
            )
            
        except Exception as e:
            self.logger.error(f"Error learning from success: {e}")
    
    async def _check_rate_limit(self) -> bool:
        """Check if rate limit exceeded."""
        # Reset counter if hour passed
        if (datetime.now() - self.last_reset_time).total_seconds() > 3600:
            self.feature_count_hour = 0
            self.last_reset_time = datetime.now()
        
        return self.feature_count_hour < self.max_features_per_hour
    
    def _create_code_preview(self, generated_code: Dict[str, Any]) -> str:
        """Create preview of generated code for approval."""
        preview = "Generated Files:\n\n"
        
        files = generated_code.get("files", {})
        for filename, content in files.items():
            preview += f"File: {filename}\n"
            preview += f"{'='*50}\n"
            
            # Show first 20 lines
            lines = content.split('\n')[:20]
            preview += '\n'.join(lines)
            
            total_lines = len(content.split('\n'))
            if total_lines > 20:
                remaining = total_lines - 20
                preview += f"\n... ({remaining} more lines)"
            
            preview += "\n\n"
        
        return preview


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

async def create_self_developer(
    llm_client: Optional[Any] = None,
    owner_verification: Optional[Any] = None,
    config: Optional[Dict[str, Any]] = None
) -> SelfDeveloper:
    """Create self developer instance."""
    developer = SelfDeveloper(
        llm_client=llm_client,
        owner_verification=owner_verification,
        config=config
    )
    return developer
