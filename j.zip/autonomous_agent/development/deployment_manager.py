#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 DEPLOYMENT MANAGER - Safe Feature Deployment
═══════════════════════════════════════════════════════════════════════════════

 Manages safe deployment of generated features with rollback capability.
 
 Author: System Engineer
 Version: 1.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
import shutil
from typing import Dict, Any, List, Optional
from pathlib import Path
from datetime import datetime
from uuid import uuid4
import json

logger = logging.getLogger(__name__)


class DeploymentManager:
    """
    Manages deployment of generated features.
    
    Features:
    - Safe deployment with backups
    - Rollback capability
    - Deployment tracking
    """
    
    def __init__(
        self,
        base_dir: Optional[Path] = None,
        config: Optional[Dict[str, Any]] = None
    ):
        """Initialize deployment manager."""
        self.logger = logging.getLogger("deployment_manager")
        
        self.base_dir = base_dir or Path(".")
        self.plugins_dir = self.base_dir / "plugins" / "installed"
        self.tools_dir = self.base_dir / "tools" / "custom"
        self.backups_dir = self.base_dir / "data" / "backups"
        
        # Create directories
        self.plugins_dir.mkdir(parents=True, exist_ok=True)
        self.tools_dir.mkdir(parents=True, exist_ok=True)
        self.backups_dir.mkdir(parents=True, exist_ok=True)
        
        # Configuration
        self.config = config or {}
        self.backup_enabled = self.config.get("backup_before_deploy", True)
        
        # Deployment tracking
        self.deployments: Dict[str, Dict[str, Any]] = {}
        self.deployment_log = self.base_dir / "data" / "deployments.json"
        
        self.logger.info("Deployment manager initialized")
    
    async def deploy(
        self,
        generated_code: Dict[str, Any],
        plan: Any
    ) -> Dict[str, Any]:
        """
        Deploy generated code.
        
        Args:
            generated_code: Generated files
            plan: Development plan
            
        Returns:
            Deployment result
        """
        try:
            feature_id = str(uuid4())
            
            result = {
                "success": False,
                "feature_id": feature_id,
                "path": None,
                "files": [],
                "backup_id": None
            }
            
            # Create backup if enabled
            if self.backup_enabled:
                backup_id = await self._create_backup()
                result["backup_id"] = backup_id
            
            # Determine deployment type
            if plan.feature_type.value == "plugin":
                deploy_result = await self._deploy_plugin(
                    generated_code, plan, feature_id
                )
            elif plan.feature_type.value == "tool":
                deploy_result = await self._deploy_tool(
                    generated_code, plan, feature_id
                )
            else:
                return {
                    "success": False,
                    "error": f"Unsupported feature type: {plan.feature_type}"
                }
            
            if deploy_result["success"]:
                result.update(deploy_result)
                
                # Track deployment
                await self._track_deployment(feature_id, plan, result)
                
                self.logger.info(f"Feature deployed: {feature_id}")
            
            return result
            
        except Exception as e:
            self.logger.error(f"Deployment failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    async def _deploy_plugin(
        self,
        generated_code: Dict[str, Any],
        plan: Any,
        feature_id: str
    ) -> Dict[str, Any]:
        """Deploy a plugin."""
        try:
            # Create plugin directory
            plugin_dir = self.plugins_dir / feature_id
            plugin_dir.mkdir(parents=True, exist_ok=True)
            
            files_created = []
            
            # Write files
            files = generated_code.get("files", {})
            for filename, content in files.items():
                file_path = plugin_dir / filename
                file_path.write_text(content, encoding='utf-8')
                files_created.append(str(file_path))
            
            return {
                "success": True,
                "path": str(plugin_dir),
                "files": files_created
            }
            
        except Exception as e:
            self.logger.error(f"Plugin deployment failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    async def _deploy_tool(
        self,
        generated_code: Dict[str, Any],
        plan: Any,
        feature_id: str
    ) -> Dict[str, Any]:
        """Deploy a tool."""
        try:
            # Create tool directory if needed
            self.tools_dir.mkdir(parents=True, exist_ok=True)
            
            files_created = []
            
            # Write files
            files = generated_code.get("files", {})
            for filename, content in files.items():
                file_path = self.tools_dir / filename
                file_path.write_text(content, encoding='utf-8')
                files_created.append(str(file_path))
            
            return {
                "success": True,
                "path": str(self.tools_dir),
                "files": files_created
            }
            
        except Exception as e:
            self.logger.error(f"Tool deployment failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    async def _create_backup(self) -> str:
        """Create backup before deployment."""
        try:
            backup_id = f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            backup_path = self.backups_dir / backup_id
            backup_path.mkdir(parents=True, exist_ok=True)
            
            # Backup plugins directory
            if self.plugins_dir.exists():
                shutil.copytree(
                    self.plugins_dir,
                    backup_path / "plugins",
                    dirs_exist_ok=True
                )
            
            self.logger.info(f"Backup created: {backup_id}")
            return backup_id
            
        except Exception as e:
            self.logger.error(f"Backup creation failed: {e}")
            return ""
    
    async def rollback(self, feature_id: str) -> bool:
        """Rollback a deployment."""
        try:
            deployment = self.deployments.get(feature_id)
            if not deployment:
                self.logger.error(f"Deployment not found: {feature_id}")
                return False
            
            # Remove deployed files
            path = Path(deployment.get("path", ""))
            if path.exists():
                if path.is_dir():
                    shutil.rmtree(path)
                else:
                    path.unlink()
            
            # Restore from backup if available
            backup_id = deployment.get("backup_id")
            if backup_id:
                await self._restore_backup(backup_id)
            
            self.logger.info(f"Rolled back deployment: {feature_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"Rollback failed: {e}")
            return False
    
    async def _restore_backup(self, backup_id: str) -> bool:
        """Restore from backup."""
        try:
            backup_path = self.backups_dir / backup_id
            if not backup_path.exists():
                return False
            
            # Restore plugins
            backup_plugins = backup_path / "plugins"
            if backup_plugins.exists():
                shutil.copytree(
                    backup_plugins,
                    self.plugins_dir,
                    dirs_exist_ok=True
                )
            
            return True
            
        except Exception as e:
            self.logger.error(f"Backup restore failed: {e}")
            return False
    
    async def _track_deployment(
        self,
        feature_id: str,
        plan: Any,
        result: Dict[str, Any]
    ) -> None:
        """Track deployment for future reference."""
        try:
            self.deployments[feature_id] = {
                "id": feature_id,
                "plan_id": plan.id,
                "title": plan.title,
                "deployed_at": datetime.now().isoformat(),
                "path": result.get("path"),
                "files": result.get("files", []),
                "backup_id": result.get("backup_id")
            }
            
            # Save to file
            await self._save_deployment_log()
            
        except Exception as e:
            self.logger.error(f"Failed to track deployment: {e}")
    
    async def _save_deployment_log(self) -> None:
        """Save deployment log to file."""
        try:
            self.deployment_log.parent.mkdir(parents=True, exist_ok=True)
            with open(self.deployment_log, 'w') as f:
                json.dump(self.deployments, f, indent=2)
        except Exception as e:
            self.logger.error(f"Failed to save deployment log: {e}")


def create_deployment_manager(
    base_dir: Optional[Path] = None,
    config: Optional[Dict[str, Any]] = None
) -> DeploymentManager:
    """Create deployment manager instance."""
    return DeploymentManager(base_dir=base_dir, config=config)
