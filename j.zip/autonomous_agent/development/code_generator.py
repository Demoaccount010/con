#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 CODE GENERATOR - LLM-based Code Generation
═══════════════════════════════════════════════════════════════════════════════

 Generates Python code using LLM (Ollama) based on specifications.
 
 Author: System Engineer
 Version: 1.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
from typing import Optional, Dict, Any, List
from pathlib import Path
import re

logger = logging.getLogger(__name__)


class CodeGenerator:
    """
    Generates code using LLM.
    
    Supports generating:
    - Plugins
    - Tools
    - Tests
    - Configuration files
    """
    
    def __init__(
        self,
        llm_client: Optional[Any] = None,
        config: Optional[Dict[str, Any]] = None
    ):
        """Initialize code generator."""
        self.logger = logging.getLogger("code_generator")
        
        # LLM client
        self.llm_client = llm_client
        
        # Configuration
        self.config = config or {}
        self.model = self.config.get("model", "qwen2.5-coder:32b")
        self.temperature = self.config.get("temperature", 0.2)
        self.max_tokens = self.config.get("max_tokens", 4000)
        
        self.logger.info("Code generator initialized")
    
    async def generate_from_plan(
        self,
        plan: Any
    ) -> Dict[str, Any]:
        """
        Generate code from development plan.
        
        Args:
            plan: DevelopmentPlan object
            
        Returns:
            Dictionary with generated files and metadata
        """
        try:
            result = {
                "success": False,
                "files": {},
                "errors": []
            }
            
            # Generate based on feature type
            if plan.feature_type.value == "plugin":
                files = await self._generate_plugin(plan)
                result["files"] = files
                result["success"] = len(files) > 0
            
            elif plan.feature_type.value == "tool":
                files = await self._generate_tool(plan)
                result["files"] = files
                result["success"] = len(files) > 0
            
            else:
                result["errors"].append(f"Unsupported feature type: {plan.feature_type}")
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error generating code from plan: {e}")
            return {"success": False, "files": {}, "errors": [str(e)]}
    
    async def generate_from_description(
        self,
        description: str,
        context: Optional[Dict[str, Any]] = None
    ) -> Optional[str]:
        """
        Generate code from natural language description.
        
        Args:
            description: What the code should do
            context: Additional context
            
        Returns:
            Generated code as string
        """
        try:
            if not self.llm_client:
                self.logger.error("No LLM client available")
                return None
            
            # Create prompt
            prompt = self._create_code_prompt(description, context)
            
            # Generate code
            response = await self.llm_client.generate(
                prompt=prompt,
                model=self.model,
                temperature=self.temperature,
                max_tokens=self.max_tokens
            )
            
            # Extract code from response
            code = self._extract_code(response)
            
            return code
            
        except Exception as e:
            self.logger.error(f"Error generating code: {e}")
            return None
    
    async def _generate_plugin(
        self,
        plan: Any
    ) -> Dict[str, str]:
        """Generate plugin files."""
        try:
            files = {}
            
            # Generate plugin.py
            plugin_code = await self._generate_plugin_code(plan)
            if plugin_code:
                files["plugin.py"] = plugin_code
            
            # Generate plugin.yaml
            plugin_yaml = self._generate_plugin_yaml(plan)
            files["plugin.yaml"] = plugin_yaml
            
            # Generate README.md
            readme = self._generate_plugin_readme(plan)
            files["README.md"] = readme
            
            return files
            
        except Exception as e:
            self.logger.error(f"Error generating plugin: {e}")
            return {}
    
    async def _generate_plugin_code(
        self,
        plan: Any
    ) -> Optional[str]:
        """Generate plugin Python code."""
        try:
            prompt = f"""Generate a Python plugin class for an autonomous agent.

Requirements:
- Plugin name: {plan.title}
- Description: {plan.description}
- Must inherit from PluginBase
- Implement required methods: on_enable, on_disable
- Add any custom functionality needed

Generate ONLY the Python code, no explanations.

Example structure:
```python
from plugins.plugin_base import PluginBase, PluginMetadata, PluginCapability
import logging

class MyPlugin(PluginBase):
    def __init__(self):
        metadata = PluginMetadata(
            id="my_plugin",
            name="My Plugin",
            version="1.0.0",
            description="Plugin description",
            capabilities=[PluginCapability.CUSTOM]
        )
        super().__init__(metadata)
    
    async def on_enable(self):
        await super().on_enable()
        # Initialize plugin
    
    async def on_disable(self):
        # Cleanup
        await super().on_disable()
```

Now generate the plugin for: {plan.description}
"""
            
            if not self.llm_client:
                # Return template if no LLM
                return self._get_plugin_template(plan)
            
            response = await self.llm_client.generate(
                prompt=prompt,
                model=self.model,
                temperature=self.temperature
            )
            
            code = self._extract_code(response)
            
            return code or self._get_plugin_template(plan)
            
        except Exception as e:
            self.logger.error(f"Error generating plugin code: {e}")
            return self._get_plugin_template(plan)
    
    def _generate_plugin_yaml(self, plan: Any) -> str:
        """Generate plugin.yaml metadata file."""
        # Sanitize title for ID
        plugin_id = re.sub(r'[^a-z0-9_]', '_', plan.title.lower())
        
        yaml_content = f"""# Plugin Metadata
id: {plugin_id}
name: {plan.title}
version: 1.0.0
description: {plan.description}

author: Autonomous Agent
author_email: agent@autonomous.local

capabilities:
  - custom

dependencies: []

min_agent_version: "3.0.0"

permissions: []

priority: 100

tags:
  - auto-generated
  - custom

license: MIT
"""
        return yaml_content
    
    def _generate_plugin_readme(self, plan: Any) -> str:
        """Generate README.md for plugin."""
        readme = f"""# {plan.title}

## Description
{plan.description}

## Features
- Auto-generated plugin
- Based on owner request

## Installation
This plugin is automatically installed and managed by the autonomous agent.

## Usage
The plugin will be automatically loaded when the agent starts.

## Version
1.0.0

## Generated
This plugin was automatically generated by the agent's self-development system.
"""
        return readme
    
    def _get_plugin_template(self, plan: Any) -> str:
        """Get basic plugin template."""
        plugin_id = re.sub(r'[^a-z0-9_]', '_', plan.title.lower())
        class_name = ''.join(word.capitalize() for word in plugin_id.split('_'))
        
        template = f'''#!/usr/bin/env python3
"""
{plan.title}

{plan.description}

Auto-generated by autonomous agent.
"""

import logging
from plugins.plugin_base import PluginBase, PluginMetadata, PluginCapability

logger = logging.getLogger(__name__)


class {class_name}Plugin(PluginBase):
    """
    {plan.title} Plugin
    
    {plan.description}
    """
    
    def __init__(self):
        """Initialize plugin."""
        metadata = PluginMetadata(
            id="{plugin_id}",
            name="{plan.title}",
            version="1.0.0",
            description="{plan.description}",
            author="Autonomous Agent",
            capabilities=[PluginCapability.CUSTOM]
        )
        super().__init__(metadata)
        
        self.logger = logging.getLogger(f"plugin.{{metadata.id}}")
    
    async def on_enable(self) -> None:
        """Called when plugin is enabled."""
        await super().on_enable()
        
        self.logger.info(f"{{self.metadata.name}} enabled")
        
        # TODO: Add initialization logic here
    
    async def on_disable(self) -> None:
        """Called when plugin is disabled."""
        
        self.logger.info(f"{{self.metadata.name}} disabled")
        
        # TODO: Add cleanup logic here
        
        await super().on_disable()
    
    async def execute(self, *args, **kwargs):
        """
        Main execution method.
        
        Override this method to add custom functionality.
        """
        self.logger.info("Plugin executed")
        
        # TODO: Add custom logic here
        
        return {{"success": True, "message": "Plugin executed successfully"}}


# Plugin entry point
def get_plugin():
    """Return plugin instance."""
    return {class_name}Plugin()
'''
        return template
    
    async def _generate_tool(
        self,
        plan: Any
    ) -> Dict[str, str]:
        """Generate tool files."""
        try:
            files = {}
            
            # Generate tool code
            tool_code = await self._generate_tool_code(plan)
            if tool_code:
                tool_id = re.sub(r'[^a-z0-9_]', '_', plan.title.lower())
                files[f"{tool_id}.py"] = tool_code
            
            return files
            
        except Exception as e:
            self.logger.error(f"Error generating tool: {e}")
            return {}
    
    async def _generate_tool_code(
        self,
        plan: Any
    ) -> Optional[str]:
        """Generate tool Python code."""
        try:
            tool_id = re.sub(r'[^a-z0-9_]', '_', plan.title.lower())
            class_name = ''.join(word.capitalize() for word in tool_id.split('_'))
            
            template = f'''#!/usr/bin/env python3
"""
{plan.title}

{plan.description}

Auto-generated tool.
"""

import logging
from typing import Dict, Any
from tools.base_tool import BaseTool

logger = logging.getLogger(__name__)


class {class_name}Tool(BaseTool):
    """
    {plan.title}
    
    {plan.description}
    """
    
    def __init__(self):
        """Initialize tool."""
        super().__init__(
            name="{tool_id}",
            description="{plan.description}",
            parameters={{}}
        )
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """
        Execute the tool.
        
        Returns:
            Result dictionary
        """
        try:
            self.logger.info("Executing {plan.title}")
            
            # TODO: Implement tool logic here
            
            return {{
                "success": True,
                "message": "Tool executed successfully"
            }}
            
        except Exception as e:
            self.logger.error(f"Tool execution failed: {{e}}")
            return {{
                "success": False,
                "error": str(e)
            }}


# Tool registration
def register_tool():
    """Register tool with the system."""
    return {class_name}Tool()
'''
            return template
            
        except Exception as e:
            self.logger.error(f"Error generating tool code: {e}")
            return None
    
    async def generate_tests(
        self,
        code: str,
        description: str
    ) -> Optional[str]:
        """Generate test code for given code."""
        try:
            test_template = f'''#!/usr/bin/env python3
"""
Tests for auto-generated code.
"""

import pytest
import asyncio


@pytest.mark.asyncio
async def test_basic_functionality():
    """Test basic functionality."""
    # TODO: Add actual tests
    assert True


@pytest.mark.asyncio  
async def test_error_handling():
    """Test error handling."""
    # TODO: Add error handling tests
    assert True


if __name__ == "__main__":
    pytest.main([__file__])
'''
            return test_template
            
        except Exception as e:
            self.logger.error(f"Error generating tests: {e}")
            return None
    
    def _create_code_prompt(
        self,
        description: str,
        context: Optional[Dict[str, Any]] = None
    ) -> str:
        """Create prompt for code generation."""
        prompt = f"""Generate Python code for the following requirement:

{description}

Requirements:
- Use async/await where appropriate
- Include proper error handling
- Add logging
- Follow PEP 8 style guidelines
- Add docstrings

Generate ONLY the code, no explanations.
"""
        
        if context:
            prompt += f"\n\nAdditional context:\n{context}"
        
        return prompt
    
    def _extract_code(self, response: str) -> Optional[str]:
        """Extract code from LLM response."""
        try:
            # Try to find code blocks
            code_block_pattern = r'```python\n(.*?)\n```'
            matches = re.findall(code_block_pattern, response, re.DOTALL)
            
            if matches:
                return matches[0].strip()
            
            # Try generic code blocks
            code_block_pattern = r'```\n(.*?)\n```'
            matches = re.findall(code_block_pattern, response, re.DOTALL)
            
            if matches:
                return matches[0].strip()
            
            # Return as-is if no code blocks found
            return response.strip()
            
        except Exception as e:
            self.logger.error(f"Error extracting code: {e}")
            return response


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

def create_code_generator(
    llm_client: Optional[Any] = None,
    config: Optional[Dict[str, Any]] = None
) -> CodeGenerator:
    """Create code generator instance."""
    return CodeGenerator(llm_client=llm_client, config=config)
