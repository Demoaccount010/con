"""
═══════════════════════════════════════════════════════════════════════════════════════
VERIFICATION CHAIN - VERIFY EVERYTHING, ASSUME NOTHING
═══════════════════════════════════════════════════════════════════════════════════════
Multi-stage verification system that validates all claims, checks assumptions,
and ensures the agent NEVER guesses. Reality always wins over memory.
"""

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Callable, Tuple
from abc import ABC, abstractmethod
import hashlib
import json

logger = logging.getLogger(__name__)


class VerificationType(Enum):
    """Types of verification that can be performed."""
    FACT_CHECK = auto()          # Verify factual claims
    ASSUMPTION_CHECK = auto()     # Check for hidden assumptions
    MEMORY_VERIFY = auto()        # Verify against memory
    REALITY_CHECK = auto()        # Verify against current reality
    LOGIC_CHECK = auto()          # Verify logical consistency
    PERMISSION_CHECK = auto()     # Verify permissions exist
    CAPABILITY_CHECK = auto()     # Verify capability exists
    CONTEXT_CHECK = auto()        # Verify context is complete
    SAFETY_CHECK = auto()         # Verify action is safe
    DEPENDENCY_CHECK = auto()     # Verify dependencies exist


class VerificationStatus(Enum):
    """Status of a verification."""
    PENDING = "pending"
    VERIFIED = "verified"
    FAILED = "failed"
    UNCERTAIN = "uncertain"
    NEEDS_MORE_INFO = "needs_more_info"
    CONFLICT_DETECTED = "conflict_detected"
    SKIPPED = "skipped"


class ConflictResolution(Enum):
    """How to resolve conflicts between memory and reality."""
    REALITY_WINS = "reality_wins"     # Reality takes precedence
    MEMORY_WINS = "memory_wins"       # Memory takes precedence (rare)
    ASK_USER = "ask_user"             # Ask user to resolve
    MARK_UNCERTAIN = "uncertain"      # Mark as uncertain


@dataclass
class VerificationResult:
    """Result of a single verification step."""
    verification_type: VerificationType
    status: VerificationStatus
    confidence: float  # 0.0 to 1.0
    claim: str
    evidence: List[str] = field(default_factory=list)
    issues: List[str] = field(default_factory=list)
    suggestions: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
    duration_ms: float = 0.0
    
    @property
    def passed(self) -> bool:
        """Check if verification passed."""
        return self.status == VerificationStatus.VERIFIED
    
    @property
    def needs_action(self) -> bool:
        """Check if verification requires action."""
        return self.status in [
            VerificationStatus.FAILED,
            VerificationStatus.NEEDS_MORE_INFO,
            VerificationStatus.CONFLICT_DETECTED
        ]


@dataclass
class VerificationChainResult:
    """Result of the complete verification chain."""
    passed: bool
    overall_confidence: float
    results: List[VerificationResult] = field(default_factory=list)
    blocking_issues: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    questions_needed: List[str] = field(default_factory=list)
    conflicts: List[Dict[str, Any]] = field(default_factory=list)
    total_duration_ms: float = 0.0
    verification_count: int = 0
    
    def add_result(self, result: VerificationResult) -> None:
        """Add a verification result."""
        self.results.append(result)
        self.verification_count += 1
        self.total_duration_ms += result.duration_ms
        
        if result.status == VerificationStatus.FAILED:
            self.blocking_issues.extend(result.issues)
        elif result.status == VerificationStatus.NEEDS_MORE_INFO:
            self.questions_needed.extend(result.suggestions)
        elif result.status == VerificationStatus.CONFLICT_DETECTED:
            self.conflicts.append({
                "type": result.verification_type.name,
                "claim": result.claim,
                "issues": result.issues
            })
    
    def calculate_overall(self) -> None:
        """Calculate overall pass/fail and confidence."""
        if not self.results:
            self.passed = False
            self.overall_confidence = 0.0
            return
        
        # Any failed verification = chain fails
        failed = any(r.status == VerificationStatus.FAILED for r in self.results)
        
        # Calculate weighted confidence
        total_confidence = sum(r.confidence for r in self.results)
        self.overall_confidence = total_confidence / len(self.results)
        
        # Must pass all checks and have reasonable confidence
        self.passed = not failed and self.overall_confidence >= 0.6


class Verifier(ABC):
    """Abstract base class for verifiers."""
    
    @property
    @abstractmethod
    def verification_type(self) -> VerificationType:
        """Return the type of verification this performs."""
        pass
    
    @abstractmethod
    async def verify(
        self,
        claim: str,
        context: Dict[str, Any],
        evidence: Optional[Dict[str, Any]] = None
    ) -> VerificationResult:
        """Perform verification."""
        pass


class FactVerifier(Verifier):
    """Verifies factual claims against known facts."""
    
    def __init__(self, memory_manager=None, llm_client=None):
        self.memory_manager = memory_manager
        self.llm_client = llm_client
    
    @property
    def verification_type(self) -> VerificationType:
        return VerificationType.FACT_CHECK
    
    async def verify(
        self,
        claim: str,
        context: Dict[str, Any],
        evidence: Optional[Dict[str, Any]] = None
    ) -> VerificationResult:
        """Verify a factual claim."""
        start_time = datetime.now()
        
        issues = []
        found_evidence = []
        confidence = 0.5  # Start neutral
        
        try:
            # Check if claim contains verifiable facts
            if self.llm_client:
                verification_prompt = f"""
                Analyze this claim for factual accuracy:
                Claim: {claim}
                Context: {json.dumps(context, default=str)}
                
                Determine:
                1. Is this a verifiable factual claim?
                2. What evidence would verify/refute it?
                3. Are there any red flags or inconsistencies?
                
                Respond with JSON:
                {{
                    "is_factual_claim": true/false,
                    "can_verify": true/false,
                    "confidence": 0.0-1.0,
                    "evidence_needed": ["..."],
                    "red_flags": ["..."]
                }}
                """
                
                response = await self.llm_client.generate(
                    verification_prompt,
                    temperature=0.1  # Low temp for precise analysis
                )
                
                try:
                    analysis = json.loads(response)
                    confidence = analysis.get("confidence", 0.5)
                    
                    if analysis.get("red_flags"):
                        issues.extend(analysis["red_flags"])
                    
                    if analysis.get("evidence_needed"):
                        found_evidence.extend(
                            f"Needs: {e}" for e in analysis["evidence_needed"]
                        )
                except json.JSONDecodeError:
                    issues.append("Could not parse verification response")
            
            # Check memory for supporting/contradicting info
            if self.memory_manager:
                memory_check = await self._check_memory(claim, context)
                if memory_check["supports"]:
                    found_evidence.extend(memory_check["supports"])
                    confidence = min(1.0, confidence + 0.2)
                if memory_check["contradicts"]:
                    issues.extend(memory_check["contradicts"])
                    confidence = max(0.0, confidence - 0.3)
            
            # Determine status
            if issues and confidence < 0.4:
                status = VerificationStatus.FAILED
            elif not found_evidence and confidence < 0.6:
                status = VerificationStatus.NEEDS_MORE_INFO
            elif issues:
                status = VerificationStatus.UNCERTAIN
            else:
                status = VerificationStatus.VERIFIED
            
            duration = (datetime.now() - start_time).total_seconds() * 1000
            
            return VerificationResult(
                verification_type=self.verification_type,
                status=status,
                confidence=confidence,
                claim=claim,
                evidence=found_evidence,
                issues=issues,
                suggestions=[
                    "Verify against authoritative source"
                ] if status == VerificationStatus.UNCERTAIN else [],
                duration_ms=duration
            )
            
        except Exception as e:
            logger.error(f"Fact verification failed: {e}")
            duration = (datetime.now() - start_time).total_seconds() * 1000
            return VerificationResult(
                verification_type=self.verification_type,
                status=VerificationStatus.FAILED,
                confidence=0.0,
                claim=claim,
                issues=[f"Verification error: {str(e)}"],
                duration_ms=duration
            )
    
    async def _check_memory(
        self,
        claim: str,
        context: Dict[str, Any]
    ) -> Dict[str, List[str]]:
        """Check memory for supporting/contradicting information."""
        result = {"supports": [], "contradicts": []}
        
        try:
            # Search memory for related information
            memories = await self.memory_manager.search(
                query=claim,
                limit=5,
                memory_types=["fact", "permanent"]
            )
            
            for memory in memories:
                # Simplified relevance check
                if memory.get("relevance", 0) > 0.7:
                    result["supports"].append(
                        f"Memory supports: {memory.get('content', '')[:100]}"
                    )
                elif memory.get("contradicts", False):
                    result["contradicts"].append(
                        f"Memory contradicts: {memory.get('content', '')[:100]}"
                    )
        except Exception as e:
            logger.warning(f"Memory check failed: {e}")
        
        return result


class AssumptionVerifier(Verifier):
    """Detects and verifies hidden assumptions."""
    
    def __init__(self, llm_client=None):
        self.llm_client = llm_client
        self._common_assumptions = [
            "file exists",
            "service is running",
            "permission granted",
            "path is valid",
            "connection available",
            "user meant this",
            "default value used"
        ]
    
    @property
    def verification_type(self) -> VerificationType:
        return VerificationType.ASSUMPTION_CHECK
    
    async def verify(
        self,
        claim: str,
        context: Dict[str, Any],
        evidence: Optional[Dict[str, Any]] = None
    ) -> VerificationResult:
        """Detect and verify assumptions in a claim or plan."""
        start_time = datetime.now()
        
        assumptions_found = []
        issues = []
        suggestions = []
        confidence = 0.8  # Start optimistic
        
        try:
            # Use LLM to detect assumptions
            if self.llm_client:
                detection_prompt = f"""
                Analyze this statement/plan for HIDDEN ASSUMPTIONS:
                Statement: {claim}
                Context: {json.dumps(context, default=str)}
                
                An assumption is something taken for granted without verification.
                
                List ALL assumptions found, including:
                - What file/path/service exists
                - What permissions are available
                - What the user meant
                - What state the system is in
                - What values are used
                
                Respond with JSON:
                {{
                    "assumptions": [
                        {{"assumption": "...", "risk": "low/medium/high", "verify_how": "..."}}
                    ],
                    "confidence_without_verification": 0.0-1.0
                }}
                """
                
                response = await self.llm_client.generate(
                    detection_prompt,
                    temperature=0.2
                )
                
                try:
                    analysis = json.loads(response)
                    
                    for assumption in analysis.get("assumptions", []):
                        assumptions_found.append(assumption["assumption"])
                        
                        if assumption.get("risk") == "high":
                            issues.append(
                                f"HIGH RISK assumption: {assumption['assumption']}"
                            )
                            confidence -= 0.2
                        elif assumption.get("risk") == "medium":
                            issues.append(
                                f"Unverified assumption: {assumption['assumption']}"
                            )
                            confidence -= 0.1
                        
                        if assumption.get("verify_how"):
                            suggestions.append(
                                f"Verify: {assumption['verify_how']}"
                            )
                    
                    # Cap confidence based on LLM analysis
                    llm_confidence = analysis.get(
                        "confidence_without_verification", 0.5
                    )
                    confidence = min(confidence, llm_confidence + 0.2)
                    
                except json.JSONDecodeError:
                    issues.append("Could not parse assumption analysis")
            
            # Pattern-based assumption detection
            claim_lower = claim.lower()
            for pattern in self._common_assumptions:
                if pattern in claim_lower or self._implies_assumption(
                    claim_lower, pattern
                ):
                    if pattern not in assumptions_found:
                        assumptions_found.append(f"Implicit: {pattern}")
                        issues.append(f"Possible assumption: {pattern}")
            
            # Determine status
            confidence = max(0.0, min(1.0, confidence))
            
            if any("HIGH RISK" in issue for issue in issues):
                status = VerificationStatus.FAILED
            elif assumptions_found and confidence < 0.5:
                status = VerificationStatus.NEEDS_MORE_INFO
            elif assumptions_found:
                status = VerificationStatus.UNCERTAIN
            else:
                status = VerificationStatus.VERIFIED
            
            duration = (datetime.now() - start_time).total_seconds() * 1000
            
            return VerificationResult(
                verification_type=self.verification_type,
                status=status,
                confidence=confidence,
                claim=claim,
                evidence=[f"Found {len(assumptions_found)} assumptions"],
                issues=issues,
                suggestions=suggestions,
                metadata={"assumptions": assumptions_found},
                duration_ms=duration
            )
            
        except Exception as e:
            logger.error(f"Assumption verification failed: {e}")
            duration = (datetime.now() - start_time).total_seconds() * 1000
            return VerificationResult(
                verification_type=self.verification_type,
                status=VerificationStatus.FAILED,
                confidence=0.0,
                claim=claim,
                issues=[f"Verification error: {str(e)}"],
                duration_ms=duration
            )
    
    def _implies_assumption(self, text: str, pattern: str) -> bool:
        """Check if text implies a certain assumption pattern."""
        implication_map = {
            "file exists": ["read file", "open file", "edit file", "delete file"],
            "service is running": ["restart", "stop service", "check status"],
            "permission granted": ["sudo", "admin", "root", "delete", "modify"],
            "path is valid": ["in directory", "at path", "from folder"],
            "connection available": ["connect to", "fetch from", "download"],
        }
        
        triggers = implication_map.get(pattern, [])
        return any(trigger in text for trigger in triggers)


class RealityVerifier(Verifier):
    """Verifies claims against current system reality."""
    
    def __init__(self, tool_executor=None):
        self.tool_executor = tool_executor
        self._verification_tools = {
            "file_exists": self._verify_file_exists,
            "service_running": self._verify_service_running,
            "path_valid": self._verify_path_valid,
            "command_available": self._verify_command_available,
            "network_reachable": self._verify_network_reachable,
        }
    
    @property
    def verification_type(self) -> VerificationType:
        return VerificationType.REALITY_CHECK
    
    async def verify(
        self,
        claim: str,
        context: Dict[str, Any],
        evidence: Optional[Dict[str, Any]] = None
    ) -> VerificationResult:
        """Verify claim against current system reality."""
        start_time = datetime.now()
        
        verifications_done = []
        issues = []
        confidence = 0.5
        
        try:
            # Determine what reality checks are needed
            needed_checks = self._determine_needed_checks(claim, context)
            
            if not needed_checks:
                # No specific reality checks needed
                duration = (datetime.now() - start_time).total_seconds() * 1000
                return VerificationResult(
                    verification_type=self.verification_type,
                    status=VerificationStatus.SKIPPED,
                    confidence=0.7,
                    claim=claim,
                    evidence=["No specific reality check required"],
                    duration_ms=duration
                )
            
            # Perform each needed check
            passed_checks = 0
            for check_type, check_params in needed_checks:
                check_func = self._verification_tools.get(check_type)
                if check_func:
                    check_result = await check_func(check_params)
                    
                    if check_result["passed"]:
                        verifications_done.append(
                            f"✓ {check_type}: {check_params}"
                        )
                        passed_checks += 1
                    else:
                        issues.append(
                            f"Reality check failed - {check_type}: "
                            f"{check_result.get('reason', 'unknown')}"
                        )
            
            # Calculate confidence based on checks passed
            if needed_checks:
                confidence = passed_checks / len(needed_checks)
            
            # Determine status
            if issues and confidence < 0.5:
                status = VerificationStatus.CONFLICT_DETECTED
            elif issues:
                status = VerificationStatus.UNCERTAIN
            else:
                status = VerificationStatus.VERIFIED
            
            duration = (datetime.now() - start_time).total_seconds() * 1000
            
            return VerificationResult(
                verification_type=self.verification_type,
                status=status,
                confidence=confidence,
                claim=claim,
                evidence=verifications_done,
                issues=issues,
                metadata={
                    "checks_performed": len(needed_checks),
                    "checks_passed": passed_checks
                },
                duration_ms=duration
            )
            
        except Exception as e:
            logger.error(f"Reality verification failed: {e}")
            duration = (datetime.now() - start_time).total_seconds() * 1000
            return VerificationResult(
                verification_type=self.verification_type,
                status=VerificationStatus.FAILED,
                confidence=0.0,
                claim=claim,
                issues=[f"Verification error: {str(e)}"],
                duration_ms=duration
            )
    
    def _determine_needed_checks(
        self,
        claim: str,
        context: Dict[str, Any]
    ) -> List[Tuple[str, str]]:
        """Determine what reality checks are needed."""
        checks = []
        claim_lower = claim.lower()
        
        # Check for file references
        if any(word in claim_lower for word in ["file", "read", "write", "edit"]):
            path = context.get("file_path") or context.get("path")
            if path:
                checks.append(("file_exists", path))
        
        # Check for service references
        if any(word in claim_lower for word in ["service", "restart", "stop", "start"]):
            service = context.get("service_name") or context.get("service")
            if service:
                checks.append(("service_running", service))
        
        # Check for command references
        if any(word in claim_lower for word in ["run", "execute", "command"]):
            command = context.get("command")
            if command:
                cmd_name = command.split()[0] if command else None
                if cmd_name:
                    checks.append(("command_available", cmd_name))
        
        # Check for network references
        if any(word in claim_lower for word in ["connect", "fetch", "download", "url"]):
            url = context.get("url") or context.get("host")
            if url:
                checks.append(("network_reachable", url))
        
        return checks
    
    async def _verify_file_exists(self, path: str) -> Dict[str, Any]:
        """Verify a file exists."""
        import os
        try:
            exists = os.path.exists(path)
            return {
                "passed": exists,
                "reason": None if exists else f"File not found: {path}"
            }
        except Exception as e:
            return {"passed": False, "reason": str(e)}
    
    async def _verify_service_running(self, service: str) -> Dict[str, Any]:
        """Verify a service is running."""
        import subprocess
        try:
            result = subprocess.run(
                ["systemctl", "is-active", service],
                capture_output=True,
                text=True,
                timeout=5
            )
            is_active = result.returncode == 0
            return {
                "passed": is_active,
                "reason": None if is_active else f"Service not active: {service}"
            }
        except Exception as e:
            return {"passed": False, "reason": str(e)}
    
    async def _verify_path_valid(self, path: str) -> Dict[str, Any]:
        """Verify a path is valid."""
        import os
        try:
            # Check if parent directory exists
            parent = os.path.dirname(path) or "."
            valid = os.path.isdir(parent)
            return {
                "passed": valid,
                "reason": None if valid else f"Invalid path: {path}"
            }
        except Exception as e:
            return {"passed": False, "reason": str(e)}
    
    async def _verify_command_available(self, command: str) -> Dict[str, Any]:
        """Verify a command is available."""
        import shutil
        try:
            available = shutil.which(command) is not None
            return {
                "passed": available,
                "reason": None if available else f"Command not found: {command}"
            }
        except Exception as e:
            return {"passed": False, "reason": str(e)}
    
    async def _verify_network_reachable(self, target: str) -> Dict[str, Any]:
        """Verify network target is reachable."""
        import socket
        try:
            # Extract host from URL if needed
            host = target
            if "://" in target:
                from urllib.parse import urlparse
                parsed = urlparse(target)
                host = parsed.hostname or target
            
            socket.setdefaulttimeout(5)
            socket.gethostbyname(host)
            return {"passed": True, "reason": None}
        except socket.gaierror:
            return {"passed": False, "reason": f"Cannot resolve: {host}"}
        except Exception as e:
            return {"passed": False, "reason": str(e)}


class MemoryVerifier(Verifier):
    """Verifies claims against memory, detecting conflicts."""
    
    def __init__(self, memory_manager=None):
        self.memory_manager = memory_manager
    
    @property
    def verification_type(self) -> VerificationType:
        return VerificationType.MEMORY_VERIFY
    
    async def verify(
        self,
        claim: str,
        context: Dict[str, Any],
        evidence: Optional[Dict[str, Any]] = None
    ) -> VerificationResult:
        """Verify claim against stored memory."""
        start_time = datetime.now()
        
        supporting = []
        conflicting = []
        confidence = 0.5
        
        try:
            if not self.memory_manager:
                duration = (datetime.now() - start_time).total_seconds() * 1000
                return VerificationResult(
                    verification_type=self.verification_type,
                    status=VerificationStatus.SKIPPED,
                    confidence=0.5,
                    claim=claim,
                    evidence=["No memory manager available"],
                    duration_ms=duration
                )
            
            # Search for related memories
            memories = await self.memory_manager.search(
                query=claim,
                limit=10,
                memory_types=["fact", "permanent", "skill", "failure"]
            )
            
            for memory in memories:
                content = memory.get("content", "")
                relevance = memory.get("relevance", 0)
                memory_type = memory.get("type", "unknown")
                
                if relevance > 0.8:
                    # Highly relevant memory
                    if self._memories_align(claim, content):
                        supporting.append(f"[{memory_type}] {content[:100]}")
                        confidence += 0.1
                    else:
                        conflicting.append(f"[{memory_type}] {content[:100]}")
                        confidence -= 0.15
                elif relevance > 0.5:
                    # Moderately relevant
                    if self._memories_align(claim, content):
                        supporting.append(f"[{memory_type}] {content[:100]}")
                        confidence += 0.05
            
            # Normalize confidence
            confidence = max(0.0, min(1.0, confidence))
            
            # Determine status
            if conflicting and len(conflicting) > len(supporting):
                status = VerificationStatus.CONFLICT_DETECTED
            elif conflicting:
                status = VerificationStatus.UNCERTAIN
            elif supporting:
                status = VerificationStatus.VERIFIED
            else:
                status = VerificationStatus.NEEDS_MORE_INFO
            
            duration = (datetime.now() - start_time).total_seconds() * 1000
            
            issues = []
            if conflicting:
                issues.append(
                    f"⚠️ MEMORY CONFLICT: {len(conflicting)} conflicting memories found"
                )
                for conflict in conflicting[:3]:
                    issues.append(f"  - {conflict}")
            
            return VerificationResult(
                verification_type=self.verification_type,
                status=status,
                confidence=confidence,
                claim=claim,
                evidence=supporting,
                issues=issues,
                metadata={
                    "supporting_count": len(supporting),
                    "conflicting_count": len(conflicting)
                },
                duration_ms=duration
            )
            
        except Exception as e:
            logger.error(f"Memory verification failed: {e}")
            duration = (datetime.now() - start_time).total_seconds() * 1000
            return VerificationResult(
                verification_type=self.verification_type,
                status=VerificationStatus.FAILED,
                confidence=0.0,
                claim=claim,
                issues=[f"Verification error: {str(e)}"],
                duration_ms=duration
            )
    
    def _memories_align(self, claim: str, memory_content: str) -> bool:
        """Check if a claim aligns with memory content."""
        # Simple word overlap check (can be enhanced with semantic similarity)
        claim_words = set(claim.lower().split())
        memory_words = set(memory_content.lower().split())
        
        overlap = len(claim_words & memory_words)
        total = len(claim_words | memory_words)
        
        if total == 0:
            return False
        
        similarity = overlap / total
        return similarity > 0.3


class SafetyVerifier(Verifier):
    """Verifies that actions are safe to perform."""
    
    def __init__(self, security_manager=None):
        self.security_manager = security_manager
        self._dangerous_patterns = [
            "rm -rf",
            "delete all",
            "drop database",
            "format disk",
            "shutdown",
            "reboot",
            "kill -9",
            "> /dev/",
            "chmod 777",
            "sudo rm",
        ]
        self._requires_confirmation = [
            "delete",
            "remove",
            "drop",
            "truncate",
            "overwrite",
            "format",
            "reset",
            "destroy"
        ]
    
    @property
    def verification_type(self) -> VerificationType:
        return VerificationType.SAFETY_CHECK
    
    async def verify(
        self,
        claim: str,
        context: Dict[str, Any],
        evidence: Optional[Dict[str, Any]] = None
    ) -> VerificationResult:
        """Verify an action is safe to perform."""
        start_time = datetime.now()
        
        issues = []
        warnings = []
        confidence = 1.0
        
        claim_lower = claim.lower()
        command = context.get("command", "").lower()
        
        # Check for dangerous patterns
        for pattern in self._dangerous_patterns:
            if pattern in claim_lower or pattern in command:
                issues.append(f"🚨 DANGEROUS: Contains '{pattern}'")
                confidence = 0.0
        
        # Check for actions requiring confirmation
        for word in self._requires_confirmation:
            if word in claim_lower or word in command:
                warnings.append(f"⚠️ Action '{word}' requires confirmation")
                confidence = min(confidence, 0.5)
        
        # Check with security manager if available
        if self.security_manager and command:
            try:
                security_check = await self.security_manager.check_command(command)
                if not security_check.get("allowed", False):
                    issues.append(
                        f"Security block: {security_check.get('reason', 'Not allowed')}"
                    )
                    confidence = 0.0
            except Exception as e:
                warnings.append(f"Could not check security: {e}")
        
        # Determine status
        if issues:
            status = VerificationStatus.FAILED
        elif warnings:
            status = VerificationStatus.NEEDS_MORE_INFO
        else:
            status = VerificationStatus.VERIFIED
        
        duration = (datetime.now() - start_time).total_seconds() * 1000
        
        return VerificationResult(
            verification_type=self.verification_type,
            status=status,
            confidence=confidence,
            claim=claim,
            evidence=["Safety check completed"],
            issues=issues,
            suggestions=warnings,
            metadata={
                "dangerous_patterns_found": len(issues),
                "confirmations_needed": len(warnings)
            },
            duration_ms=duration
        )


class VerificationChain:
    """
    Main verification chain orchestrator.
    Runs multiple verification steps in sequence or parallel.
    """
    
    def __init__(
        self,
        memory_manager=None,
        llm_client=None,
        tool_executor=None,
        security_manager=None,
        memory=None,
        llm=None,
        strict=False,
        **kwargs
    ):
        # Backward + forward compatibility
        self.memory_manager = memory_manager or memory
        self.llm_client = llm_client or llm
        self.tool_executor = tool_executor
        self.security_manager = security_manager
        self.strict = strict

        # Initialize verifiers
        self._verifiers: Dict[VerificationType, Verifier] = {}
        self._setup_verifiers()

        # Configuration
        self.parallel_verification = True
        self.fail_fast = False
        self.min_confidence_threshold = 0.5

        logger.info("VerificationChain initialized")
    
    def _setup_verifiers(self) -> None:
        """Initialize all verifiers."""
        self._verifiers[VerificationType.FACT_CHECK] = FactVerifier(
            memory_manager=self.memory_manager,
            llm_client=self.llm_client
        )
        self._verifiers[VerificationType.ASSUMPTION_CHECK] = AssumptionVerifier(
            llm_client=self.llm_client
        )
        self._verifiers[VerificationType.REALITY_CHECK] = RealityVerifier(
            tool_executor=self.tool_executor
        )
        self._verifiers[VerificationType.MEMORY_VERIFY] = MemoryVerifier(
            memory_manager=self.memory_manager
        )
        self._verifiers[VerificationType.SAFETY_CHECK] = SafetyVerifier(
            security_manager=self.security_manager
        )
    
    async def verify_claim(
        self,
        claim: str,
        context: Optional[Dict[str, Any]] = None,
        verification_types: Optional[List[VerificationType]] = None,
        require_all_pass: bool = True
    ) -> VerificationChainResult:
        """
        Run verification chain on a claim.
        
        Args:
            claim: The statement/action to verify
            context: Additional context
            verification_types: Specific verifications to run (None = all)
            require_all_pass: If True, all checks must pass
        
        Returns:
            VerificationChainResult with all results
        """
        start_time = datetime.now()
        context = context or {}
        
        # Determine which verifications to run
        if verification_types is None:
            verification_types = [
                VerificationType.ASSUMPTION_CHECK,
                VerificationType.FACT_CHECK,
                VerificationType.SAFETY_CHECK,
                VerificationType.REALITY_CHECK,
                VerificationType.MEMORY_VERIFY,
            ]
        
        result = VerificationChainResult()
        
        try:
            if self.parallel_verification:
                # Run verifications in parallel
                tasks = []
                for v_type in verification_types:
                    verifier = self._verifiers.get(v_type)
                    if verifier:
                        tasks.append(
                            verifier.verify(claim, context)
                        )
                
                if tasks:
                    verification_results = await asyncio.gather(
                        *tasks,
                        return_exceptions=True
                    )
                    
                    for v_result in verification_results:
                        if isinstance(v_result, Exception):
                            result.add_result(VerificationResult(
                                verification_type=VerificationType.FACT_CHECK,
                                status=VerificationStatus.FAILED,
                                confidence=0.0,
                                claim=claim,
                                issues=[str(v_result)]
                            ))
                        else:
                            result.add_result(v_result)
            else:
                # Run verifications sequentially
                for v_type in verification_types:
                    verifier = self._verifiers.get(v_type)
                    if verifier:
                        v_result = await verifier.verify(claim, context)
                        result.add_result(v_result)
                        
                        # Fail fast if configured
                        if self.fail_fast and v_result.status == VerificationStatus.FAILED:
                            break
            
            # Calculate overall result
            result.calculate_overall()
            
            # Add timing
            result.total_duration_ms = (
                datetime.now() - start_time
            ).total_seconds() * 1000
            
            logger.info(
                f"Verification chain completed: "
                f"passed={result.passed}, "
                f"confidence={result.overall_confidence:.2f}, "
                f"checks={result.verification_count}"
            )
            
        except Exception as e:
            logger.error(f"Verification chain failed: {e}")
            result.blocking_issues.append(str(e))
            result.passed = False
            result.overall_confidence = 0.0
        
        return result
    
    async def quick_verify(
        self,
        claim: str,
        context: Optional[Dict[str, Any]] = None
    ) -> Tuple[bool, float, List[str]]:
        """
        Quick verification returning simple pass/fail.
        
        Returns:
            Tuple of (passed, confidence, issues)
        """
        result = await self.verify_claim(
            claim=claim,
            context=context,
            verification_types=[
                VerificationType.ASSUMPTION_CHECK,
                VerificationType.SAFETY_CHECK
            ]
        )
        
        return (
            result.passed,
            result.overall_confidence,
            result.blocking_issues + result.warnings
        )
    
    async def verify_before_action(
        self,
        action: str,
        context: Dict[str, Any]
    ) -> VerificationChainResult:
        """
        Verify an action before execution.
        Focuses on safety and reality checks.
        """
        return await self.verify_claim(
            claim=action,
            context=context,
            verification_types=[
                VerificationType.SAFETY_CHECK,
                VerificationType.REALITY_CHECK,
                VerificationType.PERMISSION_CHECK
            ],
            require_all_pass=True
        )
    
    async def verify_memory_vs_reality(
        self,
        memory_claim: str,
        context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Check if memory matches current reality.
        Returns which one should be trusted.
        """
        memory_result = await self._verifiers[
            VerificationType.MEMORY_VERIFY
        ].verify(memory_claim, context)
        
        reality_result = await self._verifiers[
            VerificationType.REALITY_CHECK
        ].verify(memory_claim, context)
        
        # Reality wins by default
        trust_reality = True
        reason = "Reality check performed"
        
        if reality_result.status == VerificationStatus.SKIPPED:
            # Can't check reality, trust memory with caution
            trust_reality = False
            reason = "Could not verify reality, using memory as hint"
        elif (memory_result.status == VerificationStatus.VERIFIED and
              reality_result.status == VerificationStatus.VERIFIED):
            # Both agree
            trust_reality = True
            reason = "Memory and reality agree"
        elif reality_result.status == VerificationStatus.VERIFIED:
            # Reality confirmed, trust it
            trust_reality = True
            reason = "Reality verified"
        
        return {
            "trust_reality": trust_reality,
            "reason": reason,
            "memory_confidence": memory_result.confidence,
            "reality_confidence": reality_result.confidence,
            "conflict": memory_result.status == VerificationStatus.CONFLICT_DETECTED,
            "update_memory_recommended": (
                trust_reality and 
                memory_result.status != VerificationStatus.VERIFIED
            )
        }
    
    def get_verification_stats(self) -> Dict[str, Any]:
        """Get statistics about verifications performed."""
        return {
            "verifiers_available": list(self._verifiers.keys()),
            "parallel_mode": self.parallel_verification,
            "fail_fast": self.fail_fast,
            "min_confidence": self.min_confidence_threshold
        }


# Factory function
def create_verification_chain(
    memory_manager=None,
    llm_client=None,
    tool_executor=None,
    security_manager=None
) -> VerificationChain:
    """Create a configured verification chain."""
    return VerificationChain(
        memory_manager=memory_manager,
        llm_client=llm_client,
        tool_executor=tool_executor,
        security_manager=security_manager
    )