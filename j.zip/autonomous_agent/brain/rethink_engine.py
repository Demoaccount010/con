"""
═══════════════════════════════════════════════════════════════════════════════════════
RETHINK ENGINE - MULTI-STAGE RE-EVALUATION SYSTEM
═══════════════════════════════════════════════════════════════════════════════════════
Re-evaluates decisions with new information. Can CHANGE decisions when evidence
warrants. Implements the "RETHINK" step of the core loop.
"""

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Callable, Tuple
import json
import hashlib

logger = logging.getLogger(__name__)


class RethinkTrigger(Enum):
    """What triggered the rethink."""
    NEW_INFORMATION = auto()      # New info received
    VERIFICATION_FAILED = auto()  # Verification found issues
    EXECUTION_FAILED = auto()     # Action failed
    PARTIAL_SUCCESS = auto()      # Action partially succeeded
    USER_CORRECTION = auto()      # User corrected us
    MEMORY_CONFLICT = auto()      # Memory conflicts with reality
    CONFIDENCE_LOW = auto()       # Confidence dropped below threshold
    TIME_PASSED = auto()          # Time-based re-evaluation
    DEPENDENCY_CHANGED = auto()   # Something we depend on changed
    CONTEXT_SHIFTED = auto()      # Context has shifted


class RethinkDecision(Enum):
    """Decision after rethinking."""
    PROCEED = "proceed"                   # Continue as planned
    MODIFY_PLAN = "modify_plan"           # Adjust the plan
    ABORT = "abort"                       # Stop completely
    ASK_USER = "ask_user"                 # Need user input
    RETRY = "retry"                       # Try again
    ALTERNATIVE = "alternative"           # Use alternative approach
    WAIT = "wait"                         # Wait for conditions
    ESCALATE = "escalate"                 # Escalate to higher authority


class RethinkDepth(Enum):
    """How deep to rethink."""
    SHALLOW = 1      # Quick sanity check
    MODERATE = 2     # Standard re-evaluation
    DEEP = 3         # Full re-analysis
    EXHAUSTIVE = 4   # Complete restart of thinking


@dataclass
class RethinkContext:
    """Context for a rethink session."""
    original_task: str
    original_plan: List[Dict[str, Any]]
    current_step: int
    execution_results: List[Dict[str, Any]] = field(default_factory=list)
    new_information: Dict[str, Any] = field(default_factory=dict)
    trigger: RethinkTrigger = RethinkTrigger.NEW_INFORMATION
    memory_hints: List[str] = field(default_factory=list)
    confidence_history: List[float] = field(default_factory=list)
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class RethinkResult:
    """Result of a rethink session."""
    decision: RethinkDecision
    confidence: float
    reasoning: str
    modified_plan: Optional[List[Dict[str, Any]]] = None
    questions_for_user: List[str] = field(default_factory=list)
    lessons_learned: List[str] = field(default_factory=list)
    memory_updates: List[Dict[str, Any]] = field(default_factory=list)
    next_action: Optional[str] = None
    abort_reason: Optional[str] = None
    retry_count: int = 0
    max_retries: int = 3
    duration_ms: float = 0.0
    
    @property
    def should_continue(self) -> bool:
        """Check if execution should continue."""
        return self.decision in [
            RethinkDecision.PROCEED,
            RethinkDecision.MODIFY_PLAN,
            RethinkDecision.RETRY
        ]
    
    @property
    def needs_user_input(self) -> bool:
        """Check if user input is needed."""
        return self.decision == RethinkDecision.ASK_USER


@dataclass
class RethinkStage:
    """A stage in the rethink process."""
    name: str
    depth: RethinkDepth
    analysis: str
    findings: List[str] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)
    confidence_delta: float = 0.0


class RethinkEngine:
    """
    Multi-stage re-evaluation engine.
    
    Implements iterative rethinking with:
    - Shallow → Deep escalation
    - Evidence-based decision changing
    - Learning from failures
    - Memory updates when beliefs change
    """
    
    def __init__(
        self,
        llm_client=None,
        memory_manager=None,
        verification_chain=None
    ):
        self.llm_client = llm_client
        self.memory_manager = memory_manager
        self.verification_chain = verification_chain
        
        # Configuration
        self.max_rethink_iterations = 3
        self.confidence_threshold = 0.6
        self.auto_escalate_on_failure = True
        
        # State
        self._rethink_history: List[RethinkResult] = []
        self._decision_changes: List[Dict[str, Any]] = []
        
        logger.info("RethinkEngine initialized")
    
    async def rethink(
        self,
        context: RethinkContext,
        depth: RethinkDepth = RethinkDepth.MODERATE
    ) -> RethinkResult:
        """
        Perform rethinking based on context and trigger.
        
        Args:
            context: The rethink context with all relevant information
            depth: How deeply to rethink
        
        Returns:
            RethinkResult with decision and reasoning
        """
        start_time = datetime.now()
        
        logger.info(
            f"Rethinking: trigger={context.trigger.name}, depth={depth.name}"
        )
        
        stages_completed: List[RethinkStage] = []
        current_confidence = context.confidence_history[-1] if context.confidence_history else 0.5
        
        try:
            # Stage 1: Quick Assessment
            stage1 = await self._quick_assessment(context)
            stages_completed.append(stage1)
            current_confidence += stage1.confidence_delta
            
            # Check if we need deeper analysis
            if depth.value >= RethinkDepth.MODERATE.value or stage1.confidence_delta < -0.2:
                # Stage 2: Analyze New Information
                stage2 = await self._analyze_new_information(context)
                stages_completed.append(stage2)
                current_confidence += stage2.confidence_delta
            
            if depth.value >= RethinkDepth.DEEP.value or current_confidence < 0.5:
                # Stage 3: Re-evaluate Plan
                stage3 = await self._reevaluate_plan(context)
                stages_completed.append(stage3)
                current_confidence += stage3.confidence_delta
            
            if depth.value >= RethinkDepth.EXHAUSTIVE.value or current_confidence < 0.3:
                # Stage 4: Generate Alternatives
                stage4 = await self._generate_alternatives(context)
                stages_completed.append(stage4)
                current_confidence += stage4.confidence_delta
            
            # Make final decision
            result = await self._make_decision(
                context=context,
                stages=stages_completed,
                final_confidence=max(0.0, min(1.0, current_confidence))
            )
            
            # Calculate duration
            result.duration_ms = (datetime.now() - start_time).total_seconds() * 1000
            
            # Record in history
            self._rethink_history.append(result)
            
            # Log decision changes
            if result.decision != RethinkDecision.PROCEED:
                self._decision_changes.append({
                    "timestamp": datetime.now().isoformat(),
                    "trigger": context.trigger.name,
                    "original_step": context.current_step,
                    "decision": result.decision.value,
                    "confidence": result.confidence,
                    "reasoning": result.reasoning[:200]
                })
            
            logger.info(
                f"Rethink complete: decision={result.decision.value}, "
                f"confidence={result.confidence:.2f}"
            )
            
            return result
            
        except Exception as e:
            logger.error(f"Rethink failed: {e}")
            duration = (datetime.now() - start_time).total_seconds() * 1000
            return RethinkResult(
                decision=RethinkDecision.ABORT,
                confidence=0.0,
                reasoning=f"Rethink failed: {str(e)}",
                abort_reason=str(e),
                duration_ms=duration
            )
    
    async def _quick_assessment(self, context: RethinkContext) -> RethinkStage:
        """Stage 1: Quick assessment of the situation."""
        findings = []
        recommendations = []
        confidence_delta = 0.0
        
        # Check trigger type
        if context.trigger == RethinkTrigger.EXECUTION_FAILED:
            findings.append("Previous action failed")
            confidence_delta -= 0.2
            recommendations.append("Analyze failure reason")
        
        elif context.trigger == RethinkTrigger.VERIFICATION_FAILED:
            findings.append("Verification found issues")
            confidence_delta -= 0.15
            recommendations.append("Address verification issues before proceeding")
        
        elif context.trigger == RethinkTrigger.USER_CORRECTION:
            findings.append("User provided correction")
            confidence_delta -= 0.1
            recommendations.append("Update understanding based on correction")
        
        elif context.trigger == RethinkTrigger.NEW_INFORMATION:
            findings.append("New information available")
            # New info might increase or decrease confidence
            if context.new_information.get("supports_plan"):
                confidence_delta += 0.1
            elif context.new_information.get("contradicts_plan"):
                confidence_delta -= 0.15
        
        # Check execution results
        if context.execution_results:
            last_result = context.execution_results[-1]
            if last_result.get("success"):
                findings.append("Last action succeeded")
                confidence_delta += 0.05
            elif last_result.get("partial"):
                findings.append("Last action partially succeeded")
                recommendations.append("Complete remaining parts")
            else:
                findings.append("Last action failed")
                confidence_delta -= 0.1
        
        return RethinkStage(
            name="Quick Assessment",
            depth=RethinkDepth.SHALLOW,
            analysis="Rapid evaluation of trigger and recent results",
            findings=findings,
            recommendations=recommendations,
            confidence_delta=confidence_delta
        )
    
    async def _analyze_new_information(self, context: RethinkContext) -> RethinkStage:
        """Stage 2: Analyze new information in detail."""
        findings = []
        recommendations = []
        confidence_delta = 0.0
        
        new_info = context.new_information
        
        if self.llm_client and new_info:
            try:
                analysis_prompt = f"""
                Analyze this new information in context of the current task:
                
                ORIGINAL TASK: {context.original_task}
                
                CURRENT PLAN STEP: {context.current_step + 1} of {len(context.original_plan)}
                CURRENT ACTION: {context.original_plan[context.current_step] if context.current_step < len(context.original_plan) else 'Complete'}
                
                NEW INFORMATION:
                {json.dumps(new_info, default=str, indent=2)}
                
                PREVIOUS RESULTS:
                {json.dumps(context.execution_results[-3:], default=str, indent=2)}
                
                Analyze:
                1. Does this new information change what we should do?
                2. Does it reveal any risks we didn't consider?
                3. Does it suggest a better approach?
                4. Should we continue, modify, or stop?
                
                Respond with JSON:
                {{
                    "changes_needed": true/false,
                    "risks_identified": ["..."],
                    "better_approach": "..." or null,
                    "recommendation": "continue/modify/stop/ask",
                    "confidence_impact": -0.3 to 0.3,
                    "reasoning": "..."
                }}
                """
                
                response = await self.llm_client.generate(
                    analysis_prompt,
                    temperature=0.2
                )
                
                try:
                    analysis = json.loads(response)
                    
                    if analysis.get("changes_needed"):
                        findings.append("Changes needed based on new information")
                    
                    for risk in analysis.get("risks_identified", []):
                        findings.append(f"Risk: {risk}")
                    
                    if analysis.get("better_approach"):
                        recommendations.append(
                            f"Consider: {analysis['better_approach']}"
                        )
                    
                    if analysis.get("recommendation"):
                        recommendations.append(
                            f"Recommended action: {analysis['recommendation']}"
                        )
                    
                    confidence_delta = analysis.get("confidence_impact", 0.0)
                    
                except json.JSONDecodeError:
                    findings.append("Could not fully analyze new information")
                    confidence_delta = -0.1
                    
            except Exception as e:
                logger.warning(f"LLM analysis failed: {e}")
                findings.append("Analysis limited due to LLM unavailability")
        
        # Check memory hints
        for hint in context.memory_hints:
            if "warning" in hint.lower() or "caution" in hint.lower():
                findings.append(f"Memory hint: {hint}")
                confidence_delta -= 0.05
            elif "success" in hint.lower() or "worked" in hint.lower():
                findings.append(f"Memory hint: {hint}")
                confidence_delta += 0.05
        
        return RethinkStage(
            name="Information Analysis",
            depth=RethinkDepth.MODERATE,
            analysis="Detailed analysis of new information impact",
            findings=findings,
            recommendations=recommendations,
            confidence_delta=confidence_delta
        )
    
    async def _reevaluate_plan(self, context: RethinkContext) -> RethinkStage:
        """Stage 3: Re-evaluate the entire plan."""
        findings = []
        recommendations = []
        confidence_delta = 0.0
        
        # Analyze plan progress
        total_steps = len(context.original_plan)
        completed_steps = context.current_step
        success_rate = 0.0
        
        if context.execution_results:
            successes = sum(
                1 for r in context.execution_results if r.get("success")
            )
            success_rate = successes / len(context.execution_results)
        
        findings.append(
            f"Progress: {completed_steps}/{total_steps} steps "
            f"({success_rate*100:.0f}% success rate)"
        )
        
        # Check if plan is still viable
        if success_rate < 0.5 and completed_steps > 2:
            findings.append("Low success rate indicates plan problems")
            recommendations.append("Consider alternative approach")
            confidence_delta -= 0.2
        
        # Analyze remaining steps
        remaining_steps = context.original_plan[context.current_step:]
        
        if self.verification_chain and remaining_steps:
            # Quick verify next step
            next_step = remaining_steps[0]
            try:
                verification = await self.verification_chain.quick_verify(
                    claim=str(next_step),
                    context=context.new_information
                )
                passed, conf, issues = verification
                
                if not passed:
                    findings.append(f"Next step has issues: {issues[:2]}")
                    recommendations.append("Address issues before continuing")
                    confidence_delta -= 0.15
                else:
                    findings.append("Next step looks viable")
                    confidence_delta += 0.05
                    
            except Exception as e:
                logger.warning(f"Verification failed: {e}")
        
        # Check for patterns in failures
        if context.execution_results:
            failure_reasons = [
                r.get("error", "")
                for r in context.execution_results
                if not r.get("success")
            ]
            
            if failure_reasons:
                common_issues = self._find_common_patterns(failure_reasons)
                if common_issues:
                    findings.append(f"Recurring issues: {common_issues[:2]}")
                    recommendations.append("Address root cause of recurring failures")
        
        return RethinkStage(
            name="Plan Re-evaluation",
            depth=RethinkDepth.DEEP,
            analysis="Full re-evaluation of plan viability",
            findings=findings,
            recommendations=recommendations,
            confidence_delta=confidence_delta
        )
    
    async def _generate_alternatives(self, context: RethinkContext) -> RethinkStage:
        """Stage 4: Generate alternative approaches."""
        findings = []
        recommendations = []
        confidence_delta = 0.0
        
        if self.llm_client:
            try:
                alternatives_prompt = f"""
                The current plan is not working well. Generate alternatives.
                
                ORIGINAL TASK: {context.original_task}
                
                CURRENT PLAN:
                {json.dumps(context.original_plan, default=str, indent=2)}
                
                PROBLEMS ENCOUNTERED:
                {json.dumps([r for r in context.execution_results if not r.get("success")], default=str, indent=2)}
                
                Generate 2-3 alternative approaches that:
                1. Avoid the problems encountered
                2. Still achieve the original goal
                3. Are simpler if possible
                
                Respond with JSON:
                {{
                    "alternatives": [
                        {{
                            "approach": "...",
                            "steps": ["..."],
                            "advantages": ["..."],
                            "risks": ["..."],
                            "confidence": 0.0-1.0
                        }}
                    ],
                    "best_alternative": 0,
                    "should_switch": true/false,
                    "reasoning": "..."
                }}
                """
                
                response = await self.llm_client.generate(
                    alternatives_prompt,
                    temperature=0.5  # Higher temp for creative alternatives
                )
                
                try:
                    analysis = json.loads(response)
                    
                    alternatives = analysis.get("alternatives", [])
                    for i, alt in enumerate(alternatives):
                        findings.append(f"Alternative {i+1}: {alt.get('approach', '')[:100]}")
                    
                    if analysis.get("should_switch"):
                        best_idx = analysis.get("best_alternative", 0)
                        if alternatives and best_idx < len(alternatives):
                            best = alternatives[best_idx]
                            recommendations.append(
                                f"Switch to: {best.get('approach', 'alternative approach')}"
                            )
                            confidence_delta = best.get("confidence", 0.5) - 0.5
                    else:
                        recommendations.append("Continue with current plan with adjustments")
                        
                except json.JSONDecodeError:
                    findings.append("Could not generate structured alternatives")
                    
            except Exception as e:
                logger.warning(f"Alternative generation failed: {e}")
                findings.append("Could not generate alternatives")
        
        # Fallback simple alternatives
        if not findings:
            findings.append("Consider: Retry with different parameters")
            findings.append("Consider: Break into smaller steps")
            findings.append("Consider: Ask user for guidance")
            recommendations.append("Simplify approach")
        
        return RethinkStage(
            name="Alternative Generation",
            depth=RethinkDepth.EXHAUSTIVE,
            analysis="Generation of alternative approaches",
            findings=findings,
            recommendations=recommendations,
            confidence_delta=confidence_delta
        )
    
    async def _make_decision(
        self,
        context: RethinkContext,
        stages: List[RethinkStage],
        final_confidence: float
    ) -> RethinkResult:
        """Make final decision based on all stages."""
        
        # Collect all findings and recommendations
        all_findings = []
        all_recommendations = []
        
        for stage in stages:
            all_findings.extend(stage.findings)
            all_recommendations.extend(stage.recommendations)
        
        # Decision logic
        decision = RethinkDecision.PROCEED
        reasoning = ""
        modified_plan = None
        questions = []
        lessons = []
        memory_updates = []
        abort_reason = None
        
        # Check for abort conditions
        if final_confidence < 0.2:
            decision = RethinkDecision.ABORT
            reasoning = "Confidence too low to continue safely"
            abort_reason = "Critical confidence threshold breached"
            
        elif any("dangerous" in f.lower() for f in all_findings):
            decision = RethinkDecision.ABORT
            reasoning = "Safety concern detected"
            abort_reason = "Safety check triggered abort"
            
        elif final_confidence < 0.4:
            # Low confidence - ask user
            decision = RethinkDecision.ASK_USER
            reasoning = "Need user guidance due to low confidence"
            questions = self._generate_questions(context, all_findings)
            
        elif any("switch to" in r.lower() for r in all_recommendations):
            # Alternative recommended
            decision = RethinkDecision.ALTERNATIVE
            reasoning = "Better alternative approach identified"
            # Extract modified plan from recommendations
            modified_plan = self._extract_alternative_plan(
                context, all_recommendations
            )
            
        elif any("retry" in r.lower() or "try again" in r.lower() for r in all_recommendations):
            # Retry recommended
            decision = RethinkDecision.RETRY
            reasoning = "Retry recommended with adjustments"
            
        elif any("adjust" in r.lower() or "modify" in r.lower() for r in all_recommendations):
            # Modification recommended
            decision = RethinkDecision.MODIFY_PLAN
            reasoning = "Plan modification recommended"
            modified_plan = self._create_modified_plan(
                context, all_recommendations
            )
            
        elif final_confidence >= self.confidence_threshold:
            # Good to go
            decision = RethinkDecision.PROCEED
            reasoning = "Confidence sufficient to continue"
        else:
            # Uncertain - wait or ask
            decision = RethinkDecision.ASK_USER
            reasoning = "Moderate uncertainty, seeking user input"
            questions = self._generate_questions(context, all_findings)
        
        # Extract lessons learned
        if context.trigger == RethinkTrigger.EXECUTION_FAILED:
            lessons.append(f"Task '{context.original_task[:50]}' failed at step {context.current_step}")
            for finding in all_findings:
                if "fail" in finding.lower() or "error" in finding.lower():
                    lessons.append(finding)
        
        # Determine memory updates
        if lessons:
            memory_updates.append({
                "type": "failure",
                "content": "; ".join(lessons),
                "context": context.original_task[:100]
            })
        
        return RethinkResult(
            decision=decision,
            confidence=final_confidence,
            reasoning=reasoning,
            modified_plan=modified_plan,
            questions_for_user=questions,
            lessons_learned=lessons,
            memory_updates=memory_updates,
            abort_reason=abort_reason
        )
    
    def _find_common_patterns(self, failures: List[str]) -> List[str]:
        """Find common patterns in failure messages."""
        patterns = []
        
        # Simple word frequency
        word_count: Dict[str, int] = {}
        for failure in failures:
            words = failure.lower().split()
            for word in words:
                if len(word) > 4:  # Skip short words
                    word_count[word] = word_count.get(word, 0) + 1
        
        # Get frequently occurring words
        for word, count in word_count.items():
            if count > len(failures) / 2:  # Appears in more than half
                patterns.append(word)
        
        return patterns[:3]
    
    def _generate_questions(
        self,
        context: RethinkContext,
        findings: List[str]
    ) -> List[str]:
        """Generate questions for user based on findings."""
        questions = []
        
        # Add context-specific questions
        if context.trigger == RethinkTrigger.EXECUTION_FAILED:
            questions.append(
                "The previous action failed. Should I try a different approach?"
            )
        
        if context.trigger == RethinkTrigger.MEMORY_CONFLICT:
            questions.append(
                "I found conflicting information. Can you clarify what's correct?"
            )
        
        # Add finding-based questions
        for finding in findings[:2]:
            if "risk" in finding.lower():
                questions.append(f"I noticed a potential risk: {finding}. Should I proceed?")
        
        # Default question
        if not questions:
            questions.append(
                f"I'm uncertain about how to proceed with: {context.original_task[:100]}. "
                "Can you provide guidance?"
            )
        
        return questions[:3]
    
    def _extract_alternative_plan(
        self,
        context: RethinkContext,
        recommendations: List[str]
    ) -> List[Dict[str, Any]]:
        """Extract alternative plan from recommendations."""
        # Simplified - in practice would parse more carefully
        alternative_plan = []
        
        for rec in recommendations:
            if "switch to" in rec.lower() or "alternative" in rec.lower():
                alternative_plan.append({
                    "action": rec,
                    "description": "Alternative approach from rethink",
                    "source": "rethink_engine"
                })
        
        return alternative_plan if alternative_plan else context.original_plan
    
    def _create_modified_plan(
        self,
        context: RethinkContext,
        recommendations: List[str]
    ) -> List[Dict[str, Any]]:
        """Create modified plan based on recommendations."""
        # Start with remaining steps
        modified = list(context.original_plan[context.current_step:])
        
        # Add modification markers
        for i, step in enumerate(modified):
            if isinstance(step, dict):
                step["modified"] = True
                step["modification_reason"] = "Rethink adjustment"
        
        return modified
    
    async def rethink_on_failure(
        self,
        task: str,
        plan: List[Dict[str, Any]],
        step: int,
        error: str,
        execution_results: List[Dict[str, Any]]
    ) -> RethinkResult:
        """Convenience method for rethinking after a failure."""
        context = RethinkContext(
            original_task=task,
            original_plan=plan,
            current_step=step,
            execution_results=execution_results,
            new_information={"error": error},
            trigger=RethinkTrigger.EXECUTION_FAILED
        )
        
        return await self.rethink(context, depth=RethinkDepth.DEEP)
    
    async def rethink_with_new_info(
        self,
        task: str,
        plan: List[Dict[str, Any]],
        step: int,
        new_info: Dict[str, Any]
    ) -> RethinkResult:
        """Convenience method for rethinking with new information."""
        context = RethinkContext(
            original_task=task,
            original_plan=plan,
            current_step=step,
            new_information=new_info,
            trigger=RethinkTrigger.NEW_INFORMATION
        )
        
        return await self.rethink(context, depth=RethinkDepth.MODERATE)
    
    def get_decision_history(self) -> List[Dict[str, Any]]:
        """Get history of decision changes."""
        return self._decision_changes.copy()
    
    def get_stats(self) -> Dict[str, Any]:
        """Get rethink statistics."""
        total = len(self._rethink_history)
        if not total:
            return {"total_rethinks": 0}
        
        decisions = [r.decision.value for r in self._rethink_history]
        
        return {
            "total_rethinks": total,
            "decision_breakdown": {
                d: decisions.count(d) for d in set(decisions)
            },
            "avg_confidence": sum(r.confidence for r in self._rethink_history) / total,
            "decision_changes": len(self._decision_changes),
            "aborts": decisions.count("abort")
        }


# Factory function
def create_rethink_engine(
    llm_client=None,
    memory_manager=None,
    verification_chain=None
) -> RethinkEngine:
    """Create a configured rethink engine."""
    return RethinkEngine(
        llm_client=llm_client,
        memory_manager=memory_manager,
        verification_chain=verification_chain
    )