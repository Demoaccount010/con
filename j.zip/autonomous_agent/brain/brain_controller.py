#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 BRAIN CONTROLLER - MASTER ORCHESTRATOR
═══════════════════════════════════════════════════════════════════════════════

 The central brain that coordinates all thinking, reasoning, and decision-making.
 
 CORE RESPONSIBILITIES:
 ──────────────────────
 • Orchestrate THINK → PLAN → ACT → OBSERVE → RETHINK loop
 • Coordinate between thinking engine, memory, and tools
 • Ensure NO GUESSING - everything verified
 • Maintain reasoning chains
 • Track confidence levels
 • Handle rethinking and corrections
 
 THINKING MODES:
 ───────────────
 • ANALYTICAL   - Precise, logical reasoning
 • CREATIVE     - Creative problem solving
 • FAST         - Quick responses for simple queries
 • VERIFICATION - Double-checking and validation
 
 CRITICAL RULES:
 ───────────────
 1. NEVER skip thinking phases
 2. NEVER guess - always verify
 3. ALWAYS maintain reasoning chain
 4. ALWAYS check confidence before output
 5. ALWAYS allow rethink to change decisions
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
import time
from datetime import datetime
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass, field
from enum import Enum
from uuid import uuid4

from llm.ollama_client import OllamaClient
from llm.model_manager import ModelManager, ModelProfile
from memory.memory_manager import MemoryManager
from brain.thinking_engine import ThinkingEngine, ThoughtResult
from brain.no_guess_enforcer import NoGuessEnforcer, VerificationResult
from brain.verification_chain import VerificationChain
from brain.rethink_engine import RethinkEngine, RethinkDecision
from brain.confidence_calculator import ConfidenceCalculator


class ThinkingMode(Enum):
    """Mode of thinking."""
    ANALYTICAL = "analytical"      # Precise, logical
    CREATIVE = "creative"          # Creative solutions
    FAST = "fast"                  # Quick responses
    VERIFICATION = "verification"  # Double-checking
    CONVERSATIONAL = "conversational"  # Natural dialogue


class BrainPhase(Enum):
    """Current phase of brain processing."""
    IDLE = "idle"
    UNDERSTANDING = "understanding"
    THINKING = "thinking"
    PLANNING = "planning"
    VERIFYING = "verifying"
    DECIDING = "deciding"
    RETHINKING = "rethinking"
    RESPONDING = "responding"
    COMPLETE = "complete"
    ERROR = "error"


@dataclass
class BrainInput:
    """Input to the brain for processing."""
    text: str
    context: Dict[str, Any] = field(default_factory=dict)
    require_verification: bool = True
    allow_rethink: bool = True
    max_thinking_time: float = 30.0
    thinking_mode: ThinkingMode = ThinkingMode.ANALYTICAL


@dataclass
class ReasoningStep:
    """A single step in the reasoning chain."""
    step_id: str
    step_number: int
    thought: str
    evidence: List[str]
    confidence: float
    timestamp: datetime
    duration_ms: int


@dataclass
class BrainOutput:
    """Output from brain processing."""
    output_id: str
    input_text: str
    
    # Result
    response: str
    success: bool
    
    # Reasoning
    reasoning_chain: List[ReasoningStep]
    thinking_summary: str
    
    # Verification
    verified: bool
    confidence: float
    assumptions: List[str]
    
    # Metadata
    phase: BrainPhase
    thinking_mode: ThinkingMode
    rethink_count: int
    total_duration_ms: int
    
    # Memory changes
    memory_changes: List[Dict[str, Any]] = field(default_factory=list)
    
    # Errors
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


@dataclass
class BrainState:
    """Current state of brain processing."""
    session_id: str
    phase: BrainPhase
    current_input: Optional[BrainInput]
    reasoning_chain: List[ReasoningStep]
    thoughts: List[ThoughtResult]
    verification_result: Optional[VerificationResult]
    rethink_count: int
    start_time: datetime
    confidence: float
    errors: List[str]


class BrainController:
    """
    ═══════════════════════════════════════════════════════════════════════════
    MASTER BRAIN CONTROLLER
    ═══════════════════════════════════════════════════════════════════════════
    
    Coordinates all thinking, reasoning, and decision-making processes.
    Ensures quality, verification, and no guessing.
    """
    
    # Configuration
    DEFAULT_CONFIDENCE_THRESHOLD = 0.75
    MAX_RETHINK_ITERATIONS = 3
    MAX_REASONING_STEPS = 10
    
    def __init__(
        self,
        ollama: OllamaClient,
        model_manager: ModelManager,
        memory: MemoryManager,
        config: Dict[str, Any] = None
    ):
        """
        Initialize brain controller.
        
        Args:
            ollama: Ollama client for LLM access
            model_manager: Model management
            memory: Memory manager
            config: Brain configuration
        """
        self.logger = logging.getLogger("brain.controller")
        self.ollama = ollama
        self.model_manager = model_manager
        self.memory = memory
        self.config = config or {}
        
        # Configuration
        self.confidence_threshold = self.config.get(
            'confidence_threshold',
            self.DEFAULT_CONFIDENCE_THRESHOLD
        )
        self.max_rethink = self.config.get(
            'max_rethink_iterations',
            self.MAX_RETHINK_ITERATIONS
        )
        
        # Sub-components (initialized in initialize())
        self.thinking_engine: Optional[ThinkingEngine] = None
        self.no_guess_enforcer: Optional[NoGuessEnforcer] = None
        self.verification_chain: Optional[VerificationChain] = None
        self.rethink_engine: Optional[RethinkEngine] = None
        self.confidence_calculator: Optional[ConfidenceCalculator] = None
        
        # State
        self.current_state: Optional[BrainState] = None
        self.processing_lock = asyncio.Lock()
        
        # Statistics
        self.stats = {
            'total_processed': 0,
            'successful': 0,
            'failed': 0,
            'rethinks': 0,
            'verifications_failed': 0,
            'avg_confidence': 0.0,
            'avg_duration_ms': 0,
        }
        
    async def initialize(self) -> None:
        """Initialize brain and all sub-components."""
        self.logger.info("Initializing brain controller...")
        
        # Initialize thinking engine
        self.thinking_engine = ThinkingEngine(
            ollama=self.ollama,
            model_manager=self.model_manager,
            memory=self.memory,
            config=self.config.get('thinking', {})
        )
        await self.thinking_engine.initialize()
        
        # Initialize no-guess enforcer
        self.no_guess_enforcer = NoGuessEnforcer(
            memory=self.memory,
            config=self.config.get('verification', {})
        )
        await self.no_guess_enforcer.initialize()
        
        # Initialize verification chain
        self.verification_chain = VerificationChain(
            memory=self.memory,
            config=self.config.get('verification', {})
        )
        await self.verification_chain.initialize()
        
        # Initialize rethink engine
        self.rethink_engine = RethinkEngine(
            thinking_engine=self.thinking_engine,
            config=self.config.get('rethink', {})
        )
        await self.rethink_engine.initialize()
        
        # Initialize confidence calculator
        self.confidence_calculator = ConfidenceCalculator(
            config=self.config.get('confidence', {})
        )
        await self.confidence_calculator.initialize()
        
        self.logger.info("Brain controller initialized (all sub-components ready)")
        
    async def process(self, brain_input: BrainInput) -> BrainOutput:
        """
        Process input through the complete brain pipeline.
        
        PIPELINE:
        1. UNDERSTAND - Parse and classify input
        2. THINK - Generate thoughts and reasoning
        3. VERIFY - Check for guessing, validate
        4. DECIDE - Form conclusion with confidence
        5. RETHINK - Re-evaluate if needed
        6. RESPOND - Generate final output
        
        Args:
            brain_input: Input to process
            
        Returns:
            BrainOutput with response and metadata
        """
        async with self.processing_lock:
            return await self._process_internal(brain_input)
            
    async def _process_internal(self, brain_input: BrainInput) -> BrainOutput:
        """Internal processing implementation."""
        session_id = str(uuid4())[:8]
        start_time = datetime.utcnow()
        start_perf = time.perf_counter()
        
        self.logger.info(f"[{session_id}] Processing: {brain_input.text[:50]}...")
        
        # Initialize state
        self.current_state = BrainState(
            session_id=session_id,
            phase=BrainPhase.UNDERSTANDING,
            current_input=brain_input,
            reasoning_chain=[],
            thoughts=[],
            verification_result=None,
            rethink_count=0,
            start_time=start_time,
            confidence=0.0,
            errors=[]
        )
        
        try:
            # ═══════════════════════════════════════════════════════════════
            # PHASE 1: UNDERSTAND
            # ═══════════════════════════════════════════════════════════════
            self.logger.debug(f"[{session_id}] Phase 1: UNDERSTAND")
            self.current_state.phase = BrainPhase.UNDERSTANDING
            
            understanding = await self._understand(brain_input)
            
            self._add_reasoning_step(
                thought=f"Understood input as: {understanding['intent']}",
                evidence=[f"Input type: {understanding['type']}"],
                confidence=understanding['confidence']
            )
            
            # ═══════════════════════════════════════════════════════════════
            # PHASE 2: THINK
            # ═══════════════════════════════════════════════════════════════
            self.logger.debug(f"[{session_id}] Phase 2: THINK")
            self.current_state.phase = BrainPhase.THINKING
            
            # Get relevant memory as HINTS (not answers!)
            memory_hints = await self._get_memory_hints(brain_input.text, understanding)
            
            # Think with appropriate mode
            thinking_result = await self.thinking_engine.think(
                input_text=brain_input.text,
                context={
                    **brain_input.context,
                    'understanding': understanding,
                    'memory_hints': memory_hints,
                },
                mode=brain_input.thinking_mode
            )
            
            self.current_state.thoughts.append(thinking_result)
            
            for i, thought in enumerate(thinking_result.thought_chain):
                self._add_reasoning_step(
                    thought=thought,
                    evidence=thinking_result.evidence[:3] if thinking_result.evidence else [],
                    confidence=thinking_result.confidence
                )
                
            # ═══════════════════════════════════════════════════════════════
            # PHASE 3: VERIFY (No Guessing!)
            # ═══════════════════════════════════════════════════════════════
            if brain_input.require_verification:
                self.logger.debug(f"[{session_id}] Phase 3: VERIFY")
                self.current_state.phase = BrainPhase.VERIFYING
                
                verification = await self.no_guess_enforcer.verify(
                    thought_result=thinking_result,
                    memory_hints=memory_hints,
                    context=brain_input.context
                )
                
                self.current_state.verification_result = verification
                
                if not verification.passed:
                    self.logger.warning(f"[{session_id}] Verification failed: {verification.reason}")
                    self.stats['verifications_failed'] += 1
                    
                    # If verification failed, we need to rethink or ask for clarification
                    if verification.needs_clarification:
                        return self._create_clarification_output(
                            session_id, brain_input, verification, start_perf
                        )
                        
            # ═══════════════════════════════════════════════════════════════
            # PHASE 4: DECIDE
            # ═══════════════════════════════════════════════════════════════
            self.logger.debug(f"[{session_id}] Phase 4: DECIDE")
            self.current_state.phase = BrainPhase.DECIDING
            
            # Calculate confidence
            confidence = await self.confidence_calculator.calculate(
                thinking_result=thinking_result,
                verification_result=self.current_state.verification_result,
                reasoning_chain=self.current_state.reasoning_chain
            )
            
            self.current_state.confidence = confidence.score
            
            # ═══════════════════════════════════════════════════════════════
            # PHASE 5: RETHINK (if needed)
            # ═══════════════════════════════════════════════════════════════
            if brain_input.allow_rethink:
                self.logger.debug(f"[{session_id}] Phase 5: RETHINK CHECK")
                self.current_state.phase = BrainPhase.RETHINKING
                
                rethink_result = await self._rethink_loop(
                    thinking_result=thinking_result,
                    confidence=confidence
                )
                
                if rethink_result.changed:
                    thinking_result = rethink_result.new_thought
                    self.current_state.thoughts.append(thinking_result)
                    self.current_state.confidence = rethink_result.new_confidence
                    
            # ═══════════════════════════════════════════════════════════════
            # PHASE 6: RESPOND
            # ═══════════════════════════════════════════════════════════════
            self.logger.debug(f"[{session_id}] Phase 6: RESPOND")
            self.current_state.phase = BrainPhase.RESPONDING
            
            response = await self._generate_response(
                thinking_result=thinking_result,
                understanding=understanding
            )
            
            # ═══════════════════════════════════════════════════════════════
            # COMPLETE
            # ═══════════════════════════════════════════════════════════════
            self.current_state.phase = BrainPhase.COMPLETE
            
            duration_ms = int((time.perf_counter() - start_perf) * 1000)
            
            # Update stats
            self.stats['total_processed'] += 1
            self.stats['successful'] += 1
            self._update_avg_stats(self.current_state.confidence, duration_ms)
            
            # Get memory changes
            memory_changes = await self._collect_memory_changes()
            
            self.logger.info(
                f"[{session_id}] Complete in {duration_ms}ms, "
                f"confidence: {self.current_state.confidence:.2f}"
            )
            
            return BrainOutput(
                output_id=session_id,
                input_text=brain_input.text,
                response=response,
                success=True,
                reasoning_chain=self.current_state.reasoning_chain,
                thinking_summary=self._summarize_thinking(),
                verified=self.current_state.verification_result.passed if self.current_state.verification_result else True,
                confidence=self.current_state.confidence,
                assumptions=thinking_result.assumptions if thinking_result else [],
                phase=BrainPhase.COMPLETE,
                thinking_mode=brain_input.thinking_mode,
                rethink_count=self.current_state.rethink_count,
                total_duration_ms=duration_ms,
                memory_changes=memory_changes,
                errors=self.current_state.errors,
                warnings=[]
            )
            
        except asyncio.TimeoutError:
            self.logger.error(f"[{session_id}] Timeout after {brain_input.max_thinking_time}s")
            self.stats['failed'] += 1
            return self._create_error_output(
                session_id, brain_input, "Thinking timeout", start_perf
            )
            
        except Exception as e:
            self.logger.error(f"[{session_id}] Error: {e}", exc_info=True)
            self.stats['failed'] += 1
            return self._create_error_output(
                session_id, brain_input, str(e), start_perf
            )
            
    async def _understand(self, brain_input: BrainInput) -> Dict[str, Any]:
        """
        Understand and classify the input.
        
        Returns:
            Dictionary with intent, type, and confidence
        """
        text = brain_input.text.lower()
        
        # Quick classification based on patterns
        input_types = {
            'question': ['what', 'how', 'why', 'when', 'where', 'who', 'which', '?'],
            'command': ['do', 'run', 'execute', 'start', 'stop', 'restart', 'create', 'delete', 'show', 'list'],
            'statement': ['i want', 'i need', 'please', 'can you'],
            'greeting': ['hello', 'hi', 'hey', 'good morning', 'good evening'],
            'feedback': ['thanks', 'thank you', 'great', 'good', 'bad', 'wrong'],
        }
        
        detected_type = 'unknown'
        confidence = 0.5
        
        for itype, patterns in input_types.items():
            for pattern in patterns:
                if pattern in text:
                    detected_type = itype
                    confidence = 0.8
                    break
            if detected_type != 'unknown':
                break
                
        # Determine intent
        intent = brain_input.text  # Default to raw input
        
        if detected_type == 'question':
            intent = f"Answer question: {brain_input.text}"
        elif detected_type == 'command':
            intent = f"Execute command: {brain_input.text}"
        elif detected_type == 'greeting':
            intent = "Respond to greeting"
            
        return {
            'intent': intent,
            'type': detected_type,
            'confidence': confidence,
            'original': brain_input.text,
        }
        
    async def _get_memory_hints(
        self,
        text: str,
        understanding: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Get relevant memories as HINTS (not answers).
        
        CRITICAL: These are HINTS to guide thinking, NOT direct answers.
        The brain must still think fresh!
        """
        hints = {
            'relevant_facts': [],
            'relevant_skills': [],
            'past_failures': [],
            'preferences': [],
            '_note': 'USE AS HINTS ONLY - VERIFY AND THINK FRESH'
        }
        
        try:
            # Get relevant facts
            facts = await self.memory.search_facts(text, limit=5)
            hints['relevant_facts'] = [
                {
                    'key': f.key,
                    'value': f.value,
                    'confidence': f.confidence,
                    'age_days': f.age_days,
                    'is_hint': True  # Mark as hint!
                }
                for f in facts
            ]
            
            # Get relevant skills
            skills = await self.memory.search_skills(understanding.get('type', ''), limit=3)
            hints['relevant_skills'] = [
                {
                    'name': s.name,
                    'procedure': s.procedure,
                    'success_rate': s.success_rate,
                    'is_hint': True
                }
                for s in skills
            ]
            
            # Get past failures to avoid
            failures = await self.memory.get_recent_failures(limit=3)
            hints['past_failures'] = [
                {
                    'action': f.action,
                    'reason': f.reason,
                    'avoid': True
                }
                for f in failures
            ]
            
            # Get user preferences
            preferences = await self.memory.get_preferences()
            hints['preferences'] = preferences
            
        except Exception as e:
            self.logger.warning(f"Error getting memory hints: {e}")
            
        return hints
        
    async def _rethink_loop(
        self,
        thinking_result: ThoughtResult,
        confidence: 'ConfidenceResult'
    ) -> RethinkDecision:
        """
        Rethink loop - re-evaluate and potentially change decision.
        
        Returns:
            RethinkDecision indicating if/how to change
        """
        # Check if rethinking is needed
        if confidence.score >= self.confidence_threshold:
            # High confidence - no rethink needed
            return RethinkDecision(
                changed=False,
                reason="Confidence sufficient",
                new_thought=None,
                new_confidence=confidence.score
            )
            
        # Need to rethink
        self.current_state.rethink_count += 1
        self.stats['rethinks'] += 1
        
        if self.current_state.rethink_count > self.max_rethink:
            # Too many rethinks - proceed with best effort
            return RethinkDecision(
                changed=False,
                reason=f"Max rethink iterations ({self.max_rethink}) reached",
                new_thought=None,
                new_confidence=confidence.score
            )
            
        self.logger.info(
            f"Rethinking (attempt {self.current_state.rethink_count}): "
            f"confidence {confidence.score:.2f} < {self.confidence_threshold}"
        )
        
        # Perform rethink
        rethink_result = await self.rethink_engine.rethink(
            original_thought=thinking_result,
            confidence=confidence,
            issues=confidence.issues
        )
        
        self._add_reasoning_step(
            thought=f"Rethought: {rethink_result.reason}",
            evidence=["Low confidence triggered rethink"],
            confidence=rethink_result.new_confidence
        )
        
        return rethink_result
        
    async def _generate_response(
        self,
        thinking_result: ThoughtResult,
        understanding: Dict[str, Any]
    ) -> str:
        """Generate final response from thinking result."""
        if not thinking_result:
            return "I was unable to process this request properly."
            
        # Get response from thinking result
        response = thinking_result.conclusion
        
        if not response:
            response = thinking_result.response if hasattr(thinking_result, 'response') else ""
            
        if not response:
            # Generate from thought chain
            if thinking_result.thought_chain:
                response = thinking_result.thought_chain[-1]
            else:
                response = "I processed your request but couldn't formulate a clear response."
                
        return response
        
    async def _collect_memory_changes(self) -> List[Dict[str, Any]]:
        """Collect any memory changes made during processing."""
        # This will be populated by the memory manager's change tracking
        return self.memory.get_pending_changes() if hasattr(self.memory, 'get_pending_changes') else []
        
    def _add_reasoning_step(
        self,
        thought: str,
        evidence: List[str],
        confidence: float
    ) -> None:
        """Add a step to the reasoning chain."""
        step_number = len(self.current_state.reasoning_chain) + 1
        
        if step_number > self.MAX_REASONING_STEPS:
            return  # Prevent too long chains
            
        step = ReasoningStep(
            step_id=f"step_{step_number}",
            step_number=step_number,
            thought=thought,
            evidence=evidence,
            confidence=confidence,
            timestamp=datetime.utcnow(),
            duration_ms=0  # Could track per-step timing
        )
        
        self.current_state.reasoning_chain.append(step)
        
    def _summarize_thinking(self) -> str:
        """Create a summary of the thinking process."""
        if not self.current_state.reasoning_chain:
            return "No reasoning chain recorded."
            
        steps = self.current_state.reasoning_chain
        
        if len(steps) == 1:
            return steps[0].thought
            
        summary_parts = []
        for step in steps[:5]:  # Max 5 steps in summary
            summary_parts.append(f"{step.step_number}. {step.thought}")
            
        if len(steps) > 5:
            summary_parts.append(f"... and {len(steps) - 5} more steps")
            
        return "\n".join(summary_parts)
        
    def _create_error_output(
        self,
        session_id: str,
        brain_input: BrainInput,
        error: str,
        start_perf: float
    ) -> BrainOutput:
        """Create error output."""
        duration_ms = int((time.perf_counter() - start_perf) * 1000)
        
        return BrainOutput(
            output_id=session_id,
            input_text=brain_input.text,
            response=f"I encountered an error: {error}",
            success=False,
            reasoning_chain=self.current_state.reasoning_chain if self.current_state else [],
            thinking_summary="Error during processing",
            verified=False,
            confidence=0.0,
            assumptions=[],
            phase=BrainPhase.ERROR,
            thinking_mode=brain_input.thinking_mode,
            rethink_count=self.current_state.rethink_count if self.current_state else 0,
            total_duration_ms=duration_ms,
            memory_changes=[],
            errors=[error],
            warnings=[]
        )
        
    def _create_clarification_output(
        self,
        session_id: str,
        brain_input: BrainInput,
        verification: VerificationResult,
        start_perf: float
    ) -> BrainOutput:
        """Create output requesting clarification."""
        duration_ms = int((time.perf_counter() - start_perf) * 1000)
        
        clarification_msg = "I need clarification before proceeding:\n"
        for q in verification.clarification_questions:
            clarification_msg += f"• {q}\n"
            
        return BrainOutput(
            output_id=session_id,
            input_text=brain_input.text,
            response=clarification_msg,
            success=True,  # Not a failure, just needs input
            reasoning_chain=self.current_state.reasoning_chain,
            thinking_summary="Needs clarification before proceeding",
            verified=False,
            confidence=verification.confidence,
            assumptions=verification.assumptions,
            phase=BrainPhase.COMPLETE,
            thinking_mode=brain_input.thinking_mode,
            rethink_count=0,
            total_duration_ms=duration_ms,
            memory_changes=[],
            errors=[],
            warnings=["Clarification needed"]
        )
        
    def _update_avg_stats(self, confidence: float, duration_ms: int) -> None:
        """Update average statistics."""
        n = self.stats['successful']
        
        if n == 1:
            self.stats['avg_confidence'] = confidence
            self.stats['avg_duration_ms'] = duration_ms
        else:
            # Running average
            self.stats['avg_confidence'] = (
                (self.stats['avg_confidence'] * (n - 1) + confidence) / n
            )
            self.stats['avg_duration_ms'] = (
                (self.stats['avg_duration_ms'] * (n - 1) + duration_ms) / n
            )
            
    def get_stats(self) -> Dict[str, Any]:
        """Get brain statistics."""
        return {
            **self.stats,
            'current_phase': self.current_state.phase.value if self.current_state else 'idle',
        }
        
    async def think_simple(self, text: str) -> str:
        """
        Simple thinking - quick response without full pipeline.
        
        Use for simple queries that don't need full verification.
        """
        result = await self.thinking_engine.think_fast(text)
        return result.conclusion if result else ""