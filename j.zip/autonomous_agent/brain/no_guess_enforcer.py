#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 NO-GUESS ENFORCER - NEVER GUESS, ALWAYS VERIFY
═══════════════════════════════════════════════════════════════════════════════

 CRITICAL COMPONENT: Prevents the agent from guessing.
 
 PHILOSOPHY:
 ───────────
 The agent must NEVER guess. Every piece of information must be:
 1. Verified against facts
 2. Based on tool output
 3. Explicitly stated by user
 4. Marked as assumption if uncertain
 
 WHAT CONSTITUTES GUESSING:
 ──────────────────────────
 • Making up file paths that weren't verified
 • Assuming system state without checking
 • Inventing data that wasn't provided
 • Claiming certainty without evidence
 • Filling in gaps with imagination
 
 WHAT IS ALLOWED:
 ────────────────
 • Stating facts that were verified
 • Reporting tool outputs
 • Explicitly marking assumptions
 • Asking for clarification
 • Saying "I don't know"
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
import re
from datetime import datetime
from typing import Optional, Dict, Any, List, Set
from dataclasses import dataclass, field
from enum import Enum

from memory.memory_manager import MemoryManager
from brain.thinking_engine import ThoughtResult


class VerificationStatus(Enum):
    """Status of verification check."""
    PASSED = "passed"
    FAILED = "failed"
    NEEDS_CLARIFICATION = "needs_clarification"
    UNCERTAIN = "uncertain"


@dataclass
class VerificationResult:
    """Result of verification check."""
    passed: bool
    status: VerificationStatus
    confidence: float
    
    # Issues found
    guessing_detected: bool
    assumptions: List[str]
    unverified_claims: List[str]
    
    # What to do
    needs_clarification: bool
    clarification_questions: List[str]
    
    # Details
    reason: str
    checks_performed: List[str]
    timestamp: datetime = field(default_factory=datetime.utcnow)


class NoGuessEnforcer:
    """
    ═══════════════════════════════════════════════════════════════════════════
    NO-GUESS ENFORCEMENT SYSTEM
    ═══════════════════════════════════════════════════════════════════════════
    
    Analyzes thoughts and outputs to detect and prevent guessing.
    """
    
    # Patterns that indicate guessing
    GUESSING_PATTERNS = [
        r"probably\s+is",
        r"might\s+be",
        r"could\s+be",
        r"should\s+be\s+at",
        r"i\s+think\s+it('s|s|\s+is)",
        r"i\s+assume",
        r"i\s+guess",
        r"likely\s+(is|at|in)",
        r"presumably",
        r"i\s+believe\s+(it|the|this)",
        r"most\s+likely",
        r"if\s+i\s+had\s+to\s+guess",
        r"my\s+guess\s+is",
        r"i\s+would\s+say",
    ]
    
    # Patterns that indicate proper uncertainty
    UNCERTAINTY_PATTERNS = [
        r"i\s+don't\s+know",
        r"i'm\s+not\s+sure",
        r"i\s+cannot\s+determine",
        r"i\s+need\s+to\s+check",
        r"let\s+me\s+verify",
        r"i\s+should\s+confirm",
        r"uncertain",
        r"unable\s+to\s+confirm",
        r"need\s+more\s+information",
        r"please\s+clarify",
        r"could\s+you\s+specify",
    ]
    
    # Patterns for unverified claims
    UNVERIFIED_CLAIM_PATTERNS = [
        r"the\s+file\s+is\s+(at|in|located)",
        r"the\s+path\s+is",
        r"it('s|s|\s+is)\s+running\s+(on|at)",
        r"the\s+service\s+is\s+(running|stopped)",
        r"the\s+value\s+is",
        r"there\s+are\s+\d+",
        r"the\s+size\s+is",
        r"it\s+was\s+created",
        r"the\s+version\s+is",
        r"the\s+status\s+is",
    ]
    
    def __init__(self, memory: MemoryManager, config: Dict[str, Any] = None):
        """
        Initialize no-guess enforcer.
        
        Args:
            memory: Memory manager for fact verification
            config: Configuration
        """
        self.logger = logging.getLogger("brain.no_guess")
        self.memory = memory
        self.config = config or {}
        
        # Configuration
        self.strict_mode = self.config.get('strict_mode', True)
        self.confidence_threshold = self.config.get('confidence_threshold', 0.75)
        self.max_assumptions = self.config.get('max_assumptions', 3)
        
        # Compile patterns
        self._guessing_patterns = [
            re.compile(p, re.IGNORECASE) for p in self.GUESSING_PATTERNS
        ]
        self._uncertainty_patterns = [
            re.compile(p, re.IGNORECASE) for p in self.UNCERTAINTY_PATTERNS
        ]
        self._claim_patterns = [
            re.compile(p, re.IGNORECASE) for p in self.UNVERIFIED_CLAIM_PATTERNS
        ]
        
        # Track verified facts for session
        self._verified_facts: Set[str] = set()
        
        # Statistics
        self.stats = {
            'checks_performed': 0,
            'guessing_detected': 0,
            'clarifications_requested': 0,
        }
        
    async def initialize(self) -> None:
        """Initialize enforcer."""
        self.logger.info("No-guess enforcer initialized (strict mode: %s)", self.strict_mode)
        
    async def verify(
        self,
        thought_result: ThoughtResult,
        memory_hints: Dict[str, Any] = None,
        context: Dict[str, Any] = None
    ) -> VerificationResult:
        """
        Verify that a thought result doesn't contain guessing.
        
        Args:
            thought_result: The thought to verify
            memory_hints: Available memory hints
            context: Additional context
            
        Returns:
            VerificationResult indicating if thoughts are valid
        """
        self.stats['checks_performed'] += 1
        
        checks_performed = []
        unverified_claims = []
        assumptions = thought_result.assumptions.copy()
        clarification_questions = []
        guessing_detected = False
        
        # Combine all text to check
        all_text = " ".join([
            thought_result.conclusion,
            *thought_result.thought_chain,
            thought_result.response
        ])
        
        # ═══════════════════════════════════════════════════════════════════
        # CHECK 1: Detect guessing patterns
        # ═══════════════════════════════════════════════════════════════════
        checks_performed.append("guessing_pattern_check")
        
        guessing_matches = self._detect_guessing(all_text)
        if guessing_matches:
            guessing_detected = True
            self.stats['guessing_detected'] += 1
            self.logger.warning(f"Guessing detected: {guessing_matches}")
            
            # Check if uncertainty is properly expressed
            has_proper_uncertainty = self._has_proper_uncertainty(all_text)
            if not has_proper_uncertainty:
                clarification_questions.append(
                    "I detected uncertain language. Could you confirm the specific details?"
                )
                
        # ═══════════════════════════════════════════════════════════════════
        # CHECK 2: Detect unverified claims
        # ═══════════════════════════════════════════════════════════════════
        checks_performed.append("unverified_claims_check")
        
        claims = self._detect_claims(all_text)
        for claim in claims:
            if not await self._verify_claim(claim, memory_hints, context):
                unverified_claims.append(claim)
                
        if unverified_claims:
            self.logger.warning(f"Unverified claims: {unverified_claims}")
            for claim in unverified_claims[:2]:
                clarification_questions.append(
                    f"I need to verify: {claim}. Can you confirm or should I check?"
                )
                
        # ═══════════════════════════════════════════════════════════════════
        # CHECK 3: Check assumptions count
        # ═══════════════════════════════════════════════════════════════════
        checks_performed.append("assumptions_check")
        
        # Detect implicit assumptions
        implicit_assumptions = self._detect_implicit_assumptions(all_text)
        assumptions.extend(implicit_assumptions)
        
        if len(assumptions) > self.max_assumptions:
            self.logger.warning(f"Too many assumptions: {len(assumptions)}")
            clarification_questions.append(
                f"I'm making {len(assumptions)} assumptions. Should I proceed or clarify first?"
            )
            
        # ═══════════════════════════════════════════════════════════════════
        # CHECK 4: Confidence validation
        # ═══════════════════════════════════════════════════════════════════
        checks_performed.append("confidence_check")
        
        confidence = thought_result.confidence
        
        # Reduce confidence if issues found
        if guessing_detected:
            confidence *= 0.7
        if unverified_claims:
            confidence *= 0.8
        if len(assumptions) > 2:
            confidence *= 0.9
            
        # ═══════════════════════════════════════════════════════════════════
        # CHECK 5: Evidence validation
        # ═══════════════════════════════════════════════════════════════════
        checks_performed.append("evidence_check")
        
        has_evidence = len(thought_result.evidence) > 0
        if not has_evidence and thought_result.confidence > 0.8:
            # High confidence without evidence is suspicious
            self.logger.warning("High confidence without evidence")
            confidence *= 0.8
            
        # ═══════════════════════════════════════════════════════════════════
        # DETERMINE RESULT
        # ═══════════════════════════════════════════════════════════════════
        
        # Strict mode fails on any guessing
        if self.strict_mode and guessing_detected and not self._has_proper_uncertainty(all_text):
            return VerificationResult(
                passed=False,
                status=VerificationStatus.FAILED,
                confidence=confidence,
                guessing_detected=True,
                assumptions=assumptions,
                unverified_claims=unverified_claims,
                needs_clarification=True,
                clarification_questions=clarification_questions or [
                    "I detected guessing in my response. Let me rephrase with verified facts only."
                ],
                reason="Guessing detected in strict mode",
                checks_performed=checks_performed
            )
            
        # Need clarification if too many unknowns
        needs_clarification = (
            len(clarification_questions) > 0 or
            confidence < 0.5 or
            len(unverified_claims) > 2
        )
        
        if needs_clarification:
            self.stats['clarifications_requested'] += 1
            return VerificationResult(
                passed=False,
                status=VerificationStatus.NEEDS_CLARIFICATION,
                confidence=confidence,
                guessing_detected=guessing_detected,
                assumptions=assumptions,
                unverified_claims=unverified_claims,
                needs_clarification=True,
                clarification_questions=clarification_questions,
                reason="Need clarification before proceeding",
                checks_performed=checks_performed
            )
            
        # Passed if confidence is acceptable
        passed = confidence >= self.confidence_threshold
        
        return VerificationResult(
            passed=passed,
            status=VerificationStatus.PASSED if passed else VerificationStatus.UNCERTAIN,
            confidence=confidence,
            guessing_detected=guessing_detected,
            assumptions=assumptions,
            unverified_claims=unverified_claims,
            needs_clarification=False,
            clarification_questions=[],
            reason="Verification passed" if passed else "Low confidence",
            checks_performed=checks_performed
        )
        
    def _detect_guessing(self, text: str) -> List[str]:
        """Detect guessing patterns in text."""
        matches = []
        for pattern in self._guessing_patterns:
            found = pattern.findall(text)
            matches.extend(found)
        return matches
        
    def _has_proper_uncertainty(self, text: str) -> bool:
        """Check if uncertainty is properly expressed."""
        for pattern in self._uncertainty_patterns:
            if pattern.search(text):
                return True
        return False
        
    def _detect_claims(self, text: str) -> List[str]:
        """Detect claims that need verification."""
        claims = []
        for pattern in self._claim_patterns:
            matches = pattern.findall(text)
            for match in matches:
                # Get surrounding context
                start = text.lower().find(match.lower())
                if start >= 0:
                    # Extract the full claim (sentence or phrase)
                    end = text.find('.', start)
                    if end == -1:
                        end = min(start + 100, len(text))
                    claim = text[max(0, start-10):end].strip()
                    if claim and len(claim) > 10:
                        claims.append(claim)
        return claims[:5]  # Limit
        
    async def _verify_claim(
        self,
        claim: str,
        memory_hints: Dict[str, Any],
        context: Dict[str, Any]
    ) -> bool:
        """Check if a claim can be verified."""
        claim_lower = claim.lower()
        
        # Check if it's in verified facts
        if claim_lower in self._verified_facts:
            return True
            
        # Check against memory hints
        if memory_hints:
            facts = memory_hints.get('relevant_facts', [])
            for fact in facts:
                fact_value = str(fact.get('value', '')).lower()
                if fact_value in claim_lower or claim_lower in fact_value:
                    # Mark as verified
                    self._verified_facts.add(claim_lower)
                    return True
                    
        # Check context
        if context:
            context_str = str(context).lower()
            if any(word in context_str for word in claim_lower.split()[:3]):
                return True
                
        return False
        
    def _detect_implicit_assumptions(self, text: str) -> List[str]:
        """Detect assumptions that aren't explicitly stated."""
        assumptions = []
        
        # Common implicit assumptions
        implicit_patterns = [
            (r"the\s+default\s+", "Assuming default settings"),
            (r"as\s+usual", "Assuming usual behavior"),
            (r"like\s+before", "Assuming same as before"),
            (r"normally", "Assuming normal conditions"),
            (r"typically", "Assuming typical case"),
            (r"by\s+default", "Assuming default configuration"),
        ]
        
        text_lower = text.lower()
        for pattern, assumption in implicit_patterns:
            if re.search(pattern, text_lower):
                assumptions.append(assumption)
                
        return assumptions
        
    def add_verified_fact(self, fact: str) -> None:
        """Add a fact that has been verified (e.g., from tool output)."""
        self._verified_facts.add(fact.lower())
        
    def clear_session(self) -> None:
        """Clear session-specific verified facts."""
        self._verified_facts.clear()
        
    async def create_safe_response(
        self,
        original_response: str,
        verification: VerificationResult
    ) -> str:
        """
        Create a safe response that doesn't guess.
        
        If guessing was detected, reformulate to be honest about uncertainty.
        """
        if verification.passed:
            return original_response
            
        safe_parts = []
        
        # Acknowledge uncertainty
        safe_parts.append("Based on what I can verify:")
        
        # Add verified content only
        # (In a full implementation, would extract verified parts)
        safe_parts.append(original_response)
        
        # Add disclaimers
        if verification.assumptions:
            safe_parts.append("\n\n**Note:** I'm making these assumptions:")
            for assumption in verification.assumptions[:3]:
                safe_parts.append(f"• {assumption}")
                
        if verification.unverified_claims:
            safe_parts.append("\n\n**To verify:**")
            for claim in verification.unverified_claims[:3]:
                safe_parts.append(f"• {claim}")
                
        if verification.clarification_questions:
            safe_parts.append("\n\n**I need to confirm:**")
            for q in verification.clarification_questions[:3]:
                safe_parts.append(f"• {q}")
                
        return "\n".join(safe_parts)
        
    def get_stats(self) -> Dict[str, Any]:
        """Get enforcer statistics."""
        return {
            **self.stats,
            'verified_facts_count': len(self._verified_facts),
            'strict_mode': self.strict_mode,
        }