#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 THINKING ENGINE - ULTRA-FAST PARALLEL THINKING
═══════════════════════════════════════════════════════════════════════════════

 Core thinking capabilities with parallel processing for speed.
 
 THINKING CAPABILITIES:
 ──────────────────────
 • Chain-of-thought reasoning
 • Parallel thought generation
 • Evidence-based conclusions
 • Assumption tracking
 • Confidence estimation
 
 OPTIMIZATION TECHNIQUES:
 ────────────────────────
 • Async parallel processing
 • Thought caching
 • Early termination on high confidence
 • Lazy loading of context
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
import hashlib
import time
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass, field
from enum import Enum

from llm.ollama_client import OllamaClient, GenerateResponse
from llm.model_manager import ModelManager, ModelProfile
from memory.memory_manager import MemoryManager


@dataclass
class ThoughtResult:
    """Result of thinking process."""
    thought_id: str
    input_text: str
    
    # Thinking output
    thought_chain: List[str]
    conclusion: str
    evidence: List[str]
    assumptions: List[str]
    
    # Quality metrics
    confidence: float
    reasoning_quality: float
    
    # Metadata
    thinking_mode: str
    model_used: str
    duration_ms: int
    cached: bool = False
    
    # Response for direct output
    response: str = ""


class ThinkingMode(Enum):
    """Mode of thinking."""
    ANALYTICAL = "analytical"
    CREATIVE = "creative"
    FAST = "fast"
    VERIFICATION = "verification"
    CONVERSATIONAL = "conversational"


class ThinkingEngine:
    """
    ═══════════════════════════════════════════════════════════════════════════
    ULTRA-FAST THINKING ENGINE
    ═══════════════════════════════════════════════════════════════════════════
    
    Generates thoughts, reasoning chains, and conclusions.
    Optimized for speed with caching and parallel processing.
    """
    
    # Prompts for different thinking modes
    THINKING_PROMPTS = {
        ThinkingMode.ANALYTICAL: """You are an analytical reasoning engine. Think step by step.

INPUT: {input_text}

CONTEXT:
{context}

MEMORY HINTS (use as reference, verify before trusting):
{memory_hints}

Provide your analysis in this format:
THOUGHT 1: [First observation or analysis]
THOUGHT 2: [Second step of reasoning]
THOUGHT 3: [Further analysis]
EVIDENCE: [What facts support your reasoning]
ASSUMPTIONS: [What you're assuming - BE EXPLICIT]
CONFIDENCE: [0.0 to 1.0 - how confident are you]
CONCLUSION: [Your final answer]

Remember: NEVER guess. If unsure, say so. Verify everything.""",

        ThinkingMode.FAST: """Quick analysis needed.

INPUT: {input_text}

Respond concisely:
THOUGHT: [Brief analysis]
ANSWER: [Direct answer]
CONFIDENCE: [0.0 to 1.0]""",

        ThinkingMode.CREATIVE: """Creative problem solving mode.

INPUT: {input_text}

CONTEXT:
{context}

Think creatively and explore multiple approaches:
APPROACH 1: [First idea]
APPROACH 2: [Alternative idea]
BEST APPROACH: [Which is best and why]
SOLUTION: [Your creative solution]
CONFIDENCE: [0.0 to 1.0]""",

        ThinkingMode.VERIFICATION: """Verification mode - double check everything.

CLAIM TO VERIFY: {input_text}

EVIDENCE AVAILABLE:
{context}

Verify step by step:
CHECK 1: [First verification step]
CHECK 2: [Second verification step]
VERIFIED: [true/false]
ISSUES: [Any problems found]
CONFIDENCE: [0.0 to 1.0]""",

        ThinkingMode.CONVERSATIONAL: """Natural conversation mode.

USER: {input_text}

CONTEXT:
{context}

Respond naturally and helpfully. Be clear and concise.
If you need more information, ask.
If you're unsure, say so honestly.

RESPONSE:"""
    }
    
    def __init__(
        self,
        ollama: OllamaClient,
        model_manager: ModelManager,
        memory: MemoryManager,
        config: Dict[str, Any] = None
    ):
        """
        Initialize thinking engine.
        
        Args:
            ollama: Ollama client
            model_manager: Model manager
            memory: Memory manager
            config: Configuration
        """
        self.logger = logging.getLogger("brain.thinking")
        self.ollama = ollama
        self.model_manager = model_manager
        self.memory = memory
        self.config = config or {}
        
        # Configuration
        self.max_thoughts = self.config.get('max_thoughts', 5)
        self.cache_enabled = self.config.get('cache_enabled', True)
        self.cache_ttl = self.config.get('cache_ttl_seconds', 300)
        
        # Thought cache
        self._cache: Dict[str, Tuple[ThoughtResult, datetime]] = {}
        
        # Statistics
        self.stats = {
            'thoughts_generated': 0,
            'cache_hits': 0,
            'avg_duration_ms': 0,
        }
        
    async def initialize(self) -> None:
        """Initialize thinking engine."""
        self.logger.info("Thinking engine initialized")
        
    async def think(
        self,
        input_text: str,
        context: Dict[str, Any] = None,
        mode: 'ThinkingMode' = None,
        use_cache: bool = True
    ) -> ThoughtResult:
        """
        Main thinking function.
        
        Args:
            input_text: Text to think about
            context: Additional context
            mode: Thinking mode
            use_cache: Whether to use cache
            
        Returns:
            ThoughtResult with thoughts and conclusion
        """
        start_time = time.perf_counter()
        
        # Determine mode
        if mode is None:
            mode = self._detect_best_mode(input_text)
        elif isinstance(mode, str):
            mode = ThinkingMode(mode)
            
        # Check cache
        cache_key = self._make_cache_key(input_text, mode, context)
        if use_cache and self.cache_enabled:
            cached = self._get_cached(cache_key)
            if cached:
                self.stats['cache_hits'] += 1
                return cached
                
        self.logger.debug(f"Thinking about: {input_text[:50]}... (mode: {mode.value})")
        
        # Build prompt
        prompt = self._build_prompt(input_text, context, mode)
        
        # Get model settings for mode
        model_settings = await self.model_manager.use_profile(
            self._mode_to_profile(mode)
        )
        
        # Generate thoughts via LLM
        response = await self.ollama.generate(
            prompt=prompt,
            model=model_settings.get('model'),
            temperature=model_settings.get('temperature', 0.7),
            max_tokens=model_settings.get('max_tokens', 2048),
        )
        
        if response.error:
            self.logger.error(f"LLM error: {response.error}")
            return self._create_error_result(input_text, response.error, mode)
            
        # Parse response
        thought_result = self._parse_thinking_response(
            input_text=input_text,
            response_text=response.text,
            mode=mode,
            model_used=model_settings.get('model', 'unknown')
        )
        
        # Calculate duration
        duration_ms = int((time.perf_counter() - start_time) * 1000)
        thought_result.duration_ms = duration_ms
        
        # Cache result
        if self.cache_enabled:
            self._set_cached(cache_key, thought_result)
            
        # Update stats
        self.stats['thoughts_generated'] += 1
        self._update_avg_duration(duration_ms)
        
        self.logger.debug(
            f"Thinking complete in {duration_ms}ms, "
            f"confidence: {thought_result.confidence:.2f}"
        )
        
        return thought_result
        
    async def think_fast(self, input_text: str) -> ThoughtResult:
        """Quick thinking for simple queries."""
        return await self.think(
            input_text=input_text,
            mode=ThinkingMode.FAST,
            use_cache=True
        )
        
    async def think_parallel(
        self,
        input_text: str,
        approaches: List[str],
        context: Dict[str, Any] = None
    ) -> List[ThoughtResult]:
        """
        Think about something from multiple approaches in parallel.
        
        Args:
            input_text: Text to think about
            approaches: Different approaches to consider
            context: Additional context
            
        Returns:
            List of thought results, one per approach
        """
        tasks = []
        
        for approach in approaches:
            modified_context = {
                **(context or {}),
                'approach': approach,
                'instruction': f"Consider this from the perspective of: {approach}"
            }
            
            task = asyncio.create_task(
                self.think(
                    input_text=input_text,
                    context=modified_context,
                    mode=ThinkingMode.ANALYTICAL
                )
            )
            tasks.append(task)
            
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Filter out exceptions
        valid_results = []
        for result in results:
            if isinstance(result, ThoughtResult):
                valid_results.append(result)
            elif isinstance(result, Exception):
                self.logger.warning(f"Parallel thinking error: {result}")
                
        return valid_results
        
    async def think_and_verify(
        self,
        input_text: str,
        context: Dict[str, Any] = None
    ) -> Tuple[ThoughtResult, ThoughtResult]:
        """
        Think and then verify the thinking.
        
        Returns:
            Tuple of (original thought, verification result)
        """
        # First, think
        thought = await self.think(
            input_text=input_text,
            context=context,
            mode=ThinkingMode.ANALYTICAL
        )
        
        # Then verify
        verification_context = {
            **(context or {}),
            'original_thought': thought.conclusion,
            'original_reasoning': thought.thought_chain,
            'original_confidence': thought.confidence,
        }
        
        verification = await self.think(
            input_text=f"Verify this conclusion: {thought.conclusion}",
            context=verification_context,
            mode=ThinkingMode.VERIFICATION
        )
        
        return thought, verification
        
    def _detect_best_mode(self, input_text: str) -> ThinkingMode:
        """Detect the best thinking mode for input."""
        text_lower = input_text.lower()
        
        # Check for verification needs
        if any(word in text_lower for word in ['verify', 'check', 'confirm', 'validate']):
            return ThinkingMode.VERIFICATION
            
        # Check for creative needs
        if any(word in text_lower for word in ['create', 'design', 'imagine', 'suggest', 'idea']):
            return ThinkingMode.CREATIVE
            
        # Check for conversational
        if any(word in text_lower for word in ['hello', 'hi', 'thanks', 'how are you']):
            return ThinkingMode.CONVERSATIONAL
            
        # Check for simple queries (use fast mode)
        if len(input_text.split()) < 5:
            return ThinkingMode.FAST
            
        # Default to analytical
        return ThinkingMode.ANALYTICAL
        
    def _mode_to_profile(self, mode: ThinkingMode) -> ModelProfile:
        """Convert thinking mode to model profile."""
        mapping = {
            ThinkingMode.ANALYTICAL: ModelProfile.THINKING,
            ThinkingMode.CREATIVE: ModelProfile.CREATIVE,
            ThinkingMode.FAST: ModelProfile.FAST,
            ThinkingMode.VERIFICATION: ModelProfile.THINKING,
            ThinkingMode.CONVERSATIONAL: ModelProfile.CONVERSATION,
        }
        return mapping.get(mode, ModelProfile.THINKING)
        
    def _build_prompt(
        self,
        input_text: str,
        context: Dict[str, Any],
        mode: ThinkingMode
    ) -> str:
        """Build the thinking prompt."""
        template = self.THINKING_PROMPTS.get(mode, self.THINKING_PROMPTS[ThinkingMode.ANALYTICAL])
        
        # Format context
        context_str = ""
        if context:
            for key, value in context.items():
                if key not in ['memory_hints', 'understanding']:
                    context_str += f"- {key}: {value}\n"
                    
        # Format memory hints
        memory_hints_str = ""
        memory_hints = context.get('memory_hints', {}) if context else {}
        if memory_hints:
            facts = memory_hints.get('relevant_facts', [])
            for fact in facts[:3]:
                memory_hints_str += f"- [HINT] {fact.get('key', '')}: {fact.get('value', '')}\n"
                
        return template.format(
            input_text=input_text,
            context=context_str or "No additional context",
            memory_hints=memory_hints_str or "No memory hints"
        )
        
    def _parse_thinking_response(
        self,
        input_text: str,
        response_text: str,
        mode: ThinkingMode,
        model_used: str
    ) -> ThoughtResult:
        """Parse LLM response into ThoughtResult."""
        thought_chain = []
        conclusion = ""
        evidence = []
        assumptions = []
        confidence = 0.5  # Default
        response = ""
        
        lines = response_text.strip().split('\n')
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
                
            line_upper = line.upper()
            
            if line_upper.startswith('THOUGHT'):
                # Extract thought
                thought = line.split(':', 1)[-1].strip()
                thought_chain.append(thought)
                
            elif line_upper.startswith('CONCLUSION') or line_upper.startswith('ANSWER'):
                conclusion = line.split(':', 1)[-1].strip()
                
            elif line_upper.startswith('EVIDENCE'):
                evidence.append(line.split(':', 1)[-1].strip())
                
            elif line_upper.startswith('ASSUMPTION'):
                assumptions.append(line.split(':', 1)[-1].strip())
                
            elif line_upper.startswith('CONFIDENCE'):
                try:
                    conf_str = line.split(':', 1)[-1].strip()
                    # Extract number
                    conf_str = ''.join(c for c in conf_str if c.isdigit() or c == '.')
                    if conf_str:
                        confidence = float(conf_str)
                        if confidence > 1:
                            confidence = confidence / 100  # Handle percentage
                except ValueError:
                    pass
                    
            elif line_upper.startswith('RESPONSE'):
                response = line.split(':', 1)[-1].strip()
                
            elif line_upper.startswith('SOLUTION') or line_upper.startswith('BEST APPROACH'):
                conclusion = line.split(':', 1)[-1].strip()
                
        # If no structured output, use the whole response
        if not conclusion and not thought_chain:
            conclusion = response_text.strip()
            thought_chain = [response_text.strip()[:200]]
            
        # Set response
        if not response:
            response = conclusion
            
        # Calculate reasoning quality
        reasoning_quality = self._calculate_reasoning_quality(
            thought_chain, evidence, assumptions, confidence
        )
        
        return ThoughtResult(
            thought_id=hashlib.md5(input_text.encode()).hexdigest()[:8],
            input_text=input_text,
            thought_chain=thought_chain,
            conclusion=conclusion,
            evidence=evidence,
            assumptions=assumptions,
            confidence=min(1.0, max(0.0, confidence)),
            reasoning_quality=reasoning_quality,
            thinking_mode=mode.value,
            model_used=model_used,
            duration_ms=0,
            response=response
        )
        
    def _calculate_reasoning_quality(
        self,
        thought_chain: List[str],
        evidence: List[str],
        assumptions: List[str],
        confidence: float
    ) -> float:
        """Calculate quality score for reasoning."""
        quality = 0.0
        
        # More thoughts = better reasoning (up to a point)
        thought_score = min(len(thought_chain) / 3, 1.0) * 0.3
        quality += thought_score
        
        # Evidence increases quality
        evidence_score = min(len(evidence) / 2, 1.0) * 0.3
        quality += evidence_score
        
        # Explicit assumptions are good (shows awareness)
        assumption_score = min(len(assumptions) / 2, 1.0) * 0.2
        quality += assumption_score
        
        # Confidence affects quality
        quality += confidence * 0.2
        
        return min(1.0, quality)
        
    def _create_error_result(
        self,
        input_text: str,
        error: str,
        mode: ThinkingMode
    ) -> ThoughtResult:
        """Create error result."""
        return ThoughtResult(
            thought_id="error",
            input_text=input_text,
            thought_chain=[f"Error: {error}"],
            conclusion=f"Unable to think: {error}",
            evidence=[],
            assumptions=[],
            confidence=0.0,
            reasoning_quality=0.0,
            thinking_mode=mode.value,
            model_used="none",
            duration_ms=0,
            response=f"Error during thinking: {error}"
        )
        
    def _make_cache_key(
        self,
        input_text: str,
        mode: ThinkingMode,
        context: Dict[str, Any]
    ) -> str:
        """Create cache key."""
        content = f"{mode.value}|{input_text}"
        if context:
            # Only include stable context items
            stable_context = {k: v for k, v in context.items() 
                           if k not in ['memory_hints', 'timestamp']}
            content += f"|{str(stable_context)}"
        return hashlib.sha256(content.encode()).hexdigest()[:16]
        
    def _get_cached(self, key: str) -> Optional[ThoughtResult]:
        """Get cached thought result."""
        if key not in self._cache:
            return None
            
        result, timestamp = self._cache[key]
        
        if datetime.utcnow() - timestamp > timedelta(seconds=self.cache_ttl):
            del self._cache[key]
            return None
            
        result.cached = True
        return result
        
    def _set_cached(self, key: str, result: ThoughtResult) -> None:
        """Cache thought result."""
        # Limit cache size
        if len(self._cache) > 500:
            # Remove oldest
            oldest_keys = sorted(
                self._cache.keys(),
                key=lambda k: self._cache[k][1]
            )[:50]
            for old_key in oldest_keys:
                del self._cache[old_key]
                
        self._cache[key] = (result, datetime.utcnow())
        
    def _update_avg_duration(self, duration_ms: int) -> None:
        """Update average duration stat."""
        n = self.stats['thoughts_generated']
        if n == 1:
            self.stats['avg_duration_ms'] = duration_ms
        else:
            self.stats['avg_duration_ms'] = (
                (self.stats['avg_duration_ms'] * (n - 1) + duration_ms) / n
            )
            
    def clear_cache(self) -> None:
        """Clear thought cache."""
        self._cache.clear()
        
    def get_stats(self) -> Dict[str, Any]:
        """Get engine statistics."""
        return {
            **self.stats,
            'cache_size': len(self._cache),
        }