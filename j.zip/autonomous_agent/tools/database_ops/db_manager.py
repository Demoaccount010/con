"""
Database Manager - Multi-database connection management.
Manage connections to multiple database types.
"""

import asyncio
from pathlib import Path
from typing import Optional, Dict, Any, List, Type
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from abc import ABC, abstractmethod
import logging

import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from tools.base_tool import (
    BaseTool, ToolResult, ToolContext, ResultStatus,
    ToolCategory, ToolRisk
)
from tools.registry import get_registry

logger = logging.getLogger(__name__)


class DatabaseType(Enum):
    """Supported database types."""
    SQLITE = "sqlite"
    POSTGRESQL = "postgresql"
    MYSQL = "mysql"
    REDIS = "redis"
    MONGODB = "mongodb"


@dataclass
class ConnectionConfig:
    """Database connection configuration."""
    db_type: DatabaseType
    name: str
    
    # Connection params
    host: Optional[str] = None
    port: Optional[int] = None
    database: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None
    
    # SQLite specific
    path: Optional[str] = None
    
    # Connection pool
    min_connections: int = 1
    max_connections: int = 10
    
    # Timeouts
    connect_timeout: float = 10.0
    query_timeout: float = 60.0
    
    # Options
    ssl: bool = False
    options: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'db_type': self.db_type.value,
            'name': self.name,
            'host': self.host,
            'port': self.port,
            'database': self.database,
            'username': self.username,
            'path': self.path,
            'min_connections': self.min_connections,
            'max_connections': self.max_connections,
            'ssl': self.ssl
        }


@dataclass
class ConnectionStatus:
    """Status of a database connection."""
    name: str
    db_type: DatabaseType
    connected: bool
    active_connections: int = 0
    last_used: Optional[datetime] = None
    last_error: Optional[str] = None
    latency_ms: Optional[float] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'db_type': self.db_type.value,
            'connected': self.connected,
            'active_connections': self.active_connections,
            'last_used': self.last_used.isoformat() if self.last_used else None,
            'last_error': self.last_error,
            'latency_ms': self.latency_ms
        }


class DatabaseAdapter(ABC):
    """Abstract base class for database adapters."""
    
    def __init__(self, config: ConnectionConfig):
        self.config = config
        self._connected = False
    
    @property
    def is_connected(self) -> bool:
        return self._connected
    
    @abstractmethod
    async def connect(self) -> bool:
        """Establish connection."""
        pass
    
    @abstractmethod
    async def disconnect(self) -> None:
        """Close connection."""
        pass
    
    @abstractmethod
    async def ping(self) -> float:
        """Ping database, return latency in ms."""
        pass
    
    @abstractmethod
    async def execute(
        self,
        query: str,
        params: Optional[tuple] = None
    ) -> Dict[str, Any]:
        """Execute query."""
        pass


class SqliteAdapter(DatabaseAdapter):
    """SQLite adapter."""
    
    def __init__(self, config: ConnectionConfig):
        super().__init__(config)
        self._connection = None
    
    async def connect(self) -> bool:
        try:
            import aiosqlite
            
            db_path = self.config.path or self.config.database
            if not db_path:
                return False
            
            self._connection = await aiosqlite.connect(db_path)
            self._connection.row_factory = aiosqlite.Row
            self._connected = True
            return True
        except Exception as e:
            logger.error(f"SQLite connect error: {e}")
            return False
    
    async def disconnect(self) -> None:
        if self._connection:
            await self._connection.close()
            self._connection = None
        self._connected = False
    
    async def ping(self) -> float:
        if not self._connection:
            return -1
        
        start = datetime.now()
        try:
            await self._connection.execute("SELECT 1")
            return (datetime.now() - start).total_seconds() * 1000
        except:
            return -1
    
    async def execute(
        self,
        query: str,
        params: Optional[tuple] = None
    ) -> Dict[str, Any]:
        if not self._connection:
            return {'success': False, 'error': 'Not connected'}
        
        try:
            cursor = await self._connection.execute(query, params or ())
            
            rows = []
            if cursor.description:
                columns = [col[0] for col in cursor.description]
                raw_rows = await cursor.fetchall()
                rows = [dict(row) for row in raw_rows]
            
            await self._connection.commit()
            
            return {
                'success': True,
                'rows': rows,
                'row_count': len(rows),
                'last_row_id': cursor.lastrowid,
                'rows_affected': cursor.rowcount
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}


class PostgresAdapter(DatabaseAdapter):
    """PostgreSQL adapter."""
    
    def __init__(self, config: ConnectionConfig):
        super().__init__(config)
        self._pool = None
    
    async def connect(self) -> bool:
        try:
            import asyncpg
            
            self._pool = await asyncpg.create_pool(
                host=self.config.host or 'localhost',
                port=self.config.port or 5432,
                database=self.config.database,
                user=self.config.username,
                password=self.config.password,
                min_size=self.config.min_connections,
                max_size=self.config.max_connections,
                timeout=self.config.connect_timeout,
                ssl=self.config.ssl
            )
            self._connected = True
            return True
        except ImportError:
            logger.error("asyncpg not installed")
            return False
        except Exception as e:
            logger.error(f"PostgreSQL connect error: {e}")
            return False
    
    async def disconnect(self) -> None:
        if self._pool:
            await self._pool.close()
            self._pool = None
        self._connected = False
    
    async def ping(self) -> float:
        if not self._pool:
            return -1
        
        start = datetime.now()
        try:
            async with self._pool.acquire() as conn:
                await conn.execute("SELECT 1")
            return (datetime.now() - start).total_seconds() * 1000
        except:
            return -1
    
    async def execute(
        self,
        query: str,
        params: Optional[tuple] = None
    ) -> Dict[str, Any]:
        if not self._pool:
            return {'success': False, 'error': 'Not connected'}
        
        try:
            async with self._pool.acquire() as conn:
                if query.strip().upper().startswith('SELECT'):
                    rows = await conn.fetch(query, *(params or ()))
                    return {
                        'success': True,
                        'rows': [dict(row) for row in rows],
                        'row_count': len(rows)
                    }
                else:
                    result = await conn.execute(query, *(params or ()))
                    return {
                        'success': True,
                        'result': result
                    }
        except Exception as e:
            return {'success': False, 'error': str(e)}


class MysqlAdapter(DatabaseAdapter):
    """MySQL adapter."""
    
    def __init__(self, config: ConnectionConfig):
        super().__init__(config)
        self._pool = None
    
    async def connect(self) -> bool:
        try:
            import aiomysql
            
            self._pool = await aiomysql.create_pool(
                host=self.config.host or 'localhost',
                port=self.config.port or 3306,
                db=self.config.database,
                user=self.config.username,
                password=self.config.password,
                minsize=self.config.min_connections,
                maxsize=self.config.max_connections,
                connect_timeout=self.config.connect_timeout
            )
            self._connected = True
            return True
        except ImportError:
            logger.error("aiomysql not installed")
            return False
        except Exception as e:
            logger.error(f"MySQL connect error: {e}")
            return False
    
    async def disconnect(self) -> None:
        if self._pool:
            self._pool.close()
            await self._pool.wait_closed()
            self._pool = None
        self._connected = False
    
    async def ping(self) -> float:
        if not self._pool:
            return -1
        
        start = datetime.now()
        try:
            async with self._pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute("SELECT 1")
            return (datetime.now() - start).total_seconds() * 1000
        except:
            return -1
    
    async def execute(
        self,
        query: str,
        params: Optional[tuple] = None
    ) -> Dict[str, Any]:
        if not self._pool:
            return {'success': False, 'error': 'Not connected'}
        
        try:
            async with self._pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(query, params)
                    
                    if cur.description:
                        columns = [col[0] for col in cur.description]
                        rows = await cur.fetchall()
                        rows = [dict(zip(columns, row)) for row in rows]
                        return {
                            'success': True,
                            'rows': rows,
                            'row_count': len(rows)
                        }
                    else:
                        await conn.commit()
                        return {
                            'success': True,
                            'rows_affected': cur.rowcount,
                            'last_row_id': cur.lastrowid
                        }
        except Exception as e:
            return {'success': False, 'error': str(e)}


class DatabaseManager(BaseTool):
    """
    Multi-database connection manager.
    
    Features:
    - Manage multiple database connections
    - Support SQLite, PostgreSQL, MySQL
    - Connection pooling
    - Health checks
    - Connection status monitoring
    """
    
    ADAPTERS: Dict[DatabaseType, Type[DatabaseAdapter]] = {
        DatabaseType.SQLITE: SqliteAdapter,
        DatabaseType.POSTGRESQL: PostgresAdapter,
        DatabaseType.MYSQL: MysqlAdapter,
    }
    
    def __init__(self):
        super().__init__(
            name="db_manager",
            description="Multi-database connection management",
            category=ToolCategory.DATABASE,
            risk=ToolRisk.MEDIUM,
            requires_confirmation=False,
            timeout=120.0,
            version="1.0.0"
        )
        
        self._connections: Dict[str, DatabaseAdapter] = {}
        self._configs: Dict[str, ConnectionConfig] = {}
    
    async def add_connection(
        self,
        config: ConnectionConfig
    ) -> bool:
        """
        Add a new database connection.
        
        Args:
            config: Connection configuration
            
        Returns:
            True if connected successfully
        """
        if config.name in self._connections:
            await self.remove_connection(config.name)
        
        adapter_class = self.ADAPTERS.get(config.db_type)
        if not adapter_class:
            logger.error(f"Unsupported database type: {config.db_type}")
            return False
        
        adapter = adapter_class(config)
        success = await adapter.connect()
        
        if success:
            self._connections[config.name] = adapter
            self._configs[config.name] = config
            logger.info(f"Connected to {config.name} ({config.db_type.value})")
        
        return success
    
    async def remove_connection(self, name: str) -> bool:
        """Remove and close a connection."""
        if name in self._connections:
            await self._connections[name].disconnect()
            del self._connections[name]
            del self._configs[name]
            logger.info(f"Disconnected from {name}")
            return True
        return False
    
    async def get_connection(self, name: str) -> Optional[DatabaseAdapter]:
        """Get a connection by name."""
        return self._connections.get(name)
    
    async def execute(
        self,
        connection_name: str,
        query: str,
        params: Optional[tuple] = None
    ) -> Dict[str, Any]:
        """Execute query on named connection."""
        adapter = self._connections.get(connection_name)
        if not adapter:
            return {'success': False, 'error': f'Connection not found: {connection_name}'}
        
        return await adapter.execute(query, params)
    
    async def get_status(self, name: Optional[str] = None) -> List[ConnectionStatus]:
        """Get connection status."""
        statuses = []
        
        connections = {name: self._connections[name]} if name else self._connections
        
        for conn_name, adapter in connections.items():
            config = self._configs[conn_name]
            
            latency = await adapter.ping() if adapter.is_connected else -1
            
            statuses.append(ConnectionStatus(
                name=conn_name,
                db_type=config.db_type,
                connected=adapter.is_connected and latency >= 0,
                latency_ms=latency if latency >= 0 else None
            ))
        
        return statuses
    
    async def health_check(self) -> Dict[str, Any]:
        """Check health of all connections."""
        results = {}
        
        for name, adapter in self._connections.items():
            latency = await adapter.ping()
            results[name] = {
                'healthy': latency >= 0,
                'latency_ms': latency if latency >= 0 else None
            }
        
        all_healthy = all(r['healthy'] for r in results.values())
        
        return {
            'all_healthy': all_healthy,
            'connections': results
        }
    
    def list_connections(self) -> List[Dict[str, Any]]:
        """List all connections."""
        return [config.to_dict() for config in self._configs.values()]
    
    async def run(self, context: ToolContext, **kwargs) -> ToolResult:
        """
        Execute database manager operation.
        
        Supported operations:
        - connect: Add new connection
        - disconnect: Remove connection
        - execute: Execute query
        - status: Get connection status
        - health: Health check
        - list: List connections
        """
        operation = kwargs.get('operation', 'list')
        
        try:
            if operation == 'connect':
                db_type_str = kwargs.get('db_type', 'sqlite')
                try:
                    db_type = DatabaseType(db_type_str)
                except ValueError:
                    return ToolResult.fail(error=f"Invalid db_type: {db_type_str}")
                
                config = ConnectionConfig(
                    db_type=db_type,
                    name=kwargs.get('name', 'default'),
                    host=kwargs.get('host'),
                    port=kwargs.get('port'),
                    database=kwargs.get('database'),
                    username=kwargs.get('username'),
                    password=kwargs.get('password'),
                    path=kwargs.get('path'),
                    ssl=kwargs.get('ssl', False)
                )
                
                success = await self.add_connection(config)
                
                if success:
                    return ToolResult.ok(message=f"Connected to {config.name}")
                else:
                    return ToolResult.fail(error=f"Failed to connect to {config.name}")
            
            elif operation == 'disconnect':
                name = kwargs.get('name')
                if not name:
                    return ToolResult.fail(error="name is required")
                
                success = await self.remove_connection(name)
                
                if success:
                    return ToolResult.ok(message=f"Disconnected from {name}")
                else:
                    return ToolResult.fail(error=f"Connection not found: {name}")
            
            elif operation == 'execute':
                name = kwargs.get('name') or kwargs.get('connection')
                query = kwargs.get('query') or kwargs.get('sql')
                
                if not name or not query:
                    return ToolResult.fail(error="name and query are required")
                
                result = await self.execute(
                    name, query,
                    params=kwargs.get('params')
                )
                
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('error'))
            
            elif operation == 'status':
                statuses = await self.get_status(kwargs.get('name'))
                
                return ToolResult.ok(
                    data={'connections': [s.to_dict() for s in statuses]}
                )
            
            elif operation == 'health':
                health = await self.health_check()
                
                return ToolResult.ok(data=health)
            
            elif operation == 'list':
                connections = self.list_connections()
                
                return ToolResult.ok(
                    data={'connections': connections, 'count': len(connections)}
                )
            
            else:
                return ToolResult.fail(error=f"Unknown operation: {operation}")
            
        except Exception as e:
            logger.error(f"DatabaseManager error: {e}")
            return ToolResult.error(error=str(e))
    
    async def cleanup(self) -> None:
        """Close all connections."""
        for name in list(self._connections.keys()):
            await self.remove_connection(name)


# Create singleton
db_manager = DatabaseManager()


def register():
    """Register database manager."""
    registry = get_registry()
    registry.register_tool(db_manager)