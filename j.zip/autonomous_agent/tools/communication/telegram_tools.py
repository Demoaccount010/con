"""
Telegram Tools - Telegram Bot API integration.
Send messages, notifications, files, and manage bot interactions.
"""

import asyncio
import aiohttp
import json
from pathlib import Path
from typing import Optional, Dict, Any, List, Union
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import logging
import os

import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from tools.base_tool import (
    BaseTool, ToolResult, ToolContext, ResultStatus,
    ToolCategory, ToolRisk
)
from tools.registry import get_registry

logger = logging.getLogger(__name__)


class ParseMode(Enum):
    """Telegram message parse modes."""
    TEXT = None
    MARKDOWN = "Markdown"
    MARKDOWN_V2 = "MarkdownV2"
    HTML = "HTML"


class ChatAction(Enum):
    """Telegram chat actions (typing indicators)."""
    TYPING = "typing"
    UPLOAD_PHOTO = "upload_photo"
    UPLOAD_VIDEO = "upload_video"
    UPLOAD_AUDIO = "upload_audio"
    UPLOAD_DOCUMENT = "upload_document"
    FIND_LOCATION = "find_location"
    RECORD_VIDEO = "record_video"
    RECORD_AUDIO = "record_audio"


@dataclass
class TelegramMessage:
    """Telegram message data."""
    message_id: int
    chat_id: int
    text: Optional[str]
    date: datetime
    from_user: Optional[Dict[str, Any]]
    reply_to_message: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'message_id': self.message_id,
            'chat_id': self.chat_id,
            'text': self.text,
            'date': self.date.isoformat(),
            'from_user': self.from_user,
            'reply_to_message': self.reply_to_message
        }


@dataclass
class TelegramResponse:
    """Response from Telegram API."""
    success: bool
    result: Optional[Any] = None
    error_code: Optional[int] = None
    description: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'success': self.success,
            'result': self.result,
            'error_code': self.error_code,
            'description': self.description
        }


@dataclass
class InlineKeyboardButton:
    """Inline keyboard button."""
    text: str
    callback_data: Optional[str] = None
    url: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        result = {'text': self.text}
        if self.callback_data:
            result['callback_data'] = self.callback_data
        if self.url:
            result['url'] = self.url
        return result


class TelegramTools(BaseTool):
    """
    Telegram Bot API tool.
    
    Features:
    - Send text messages with formatting
    - Send photos, documents, videos
    - Inline keyboards
    - Reply to messages
    - Edit/delete messages
    - Get updates
    - Chat actions (typing indicators)
    - Bot info
    """
    
    API_BASE = "https://api.telegram.org/bot"
    
    def __init__(self, token: Optional[str] = None):
        super().__init__(
            name="telegram_tools",
            description="Telegram Bot API integration",
            category=ToolCategory.COMMUNICATION,
            risk=ToolRisk.LOW,
            requires_confirmation=False,
            timeout=60.0,
            version="1.0.0"
        )
        
        self._token = token or os.environ.get('TELEGRAM_BOT_TOKEN')
        self._session: Optional[aiohttp.ClientSession] = None
        self._bot_info: Optional[Dict[str, Any]] = None
        self._default_chat_id: Optional[int] = None
    
    @property
    def is_configured(self) -> bool:
        """Check if bot token is configured."""
        return bool(self._token)
    
    def set_token(self, token: str) -> None:
        """Set bot token."""
        self._token = token
        self._bot_info = None
    
    def set_default_chat(self, chat_id: int) -> None:
        """Set default chat ID for messages."""
        self._default_chat_id = chat_id
    
    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create HTTP session."""
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession()
        return self._session
    
    async def _api_request(
        self,
        method: str,
        data: Optional[Dict[str, Any]] = None,
        files: Optional[Dict[str, Any]] = None
    ) -> TelegramResponse:
        """
        Make Telegram API request.
        
        Args:
            method: API method name
            data: Request data
            files: Files to upload
            
        Returns:
            TelegramResponse
        """
        if not self._token:
            return TelegramResponse(
                success=False,
                description="Bot token not configured"
            )
        
        url = f"{self.API_BASE}{self._token}/{method}"
        session = await self._get_session()
        
        try:
            if files:
                # Multipart form data for file uploads
                form = aiohttp.FormData()
                for key, value in (data or {}).items():
                    if value is not None:
                        if isinstance(value, (dict, list)):
                            form.add_field(key, json.dumps(value))
                        else:
                            form.add_field(key, str(value))
                
                for key, file_data in files.items():
                    if isinstance(file_data, str):
                        # File path
                        path = Path(file_data)
                        form.add_field(
                            key,
                            open(path, 'rb'),
                            filename=path.name
                        )
                    else:
                        # File-like object or bytes
                        form.add_field(key, file_data)
                
                async with session.post(url, data=form) as response:
                    result = await response.json()
            else:
                # JSON request
                async with session.post(url, json=data or {}) as response:
                    result = await response.json()
            
            if result.get('ok'):
                return TelegramResponse(
                    success=True,
                    result=result.get('result')
                )
            else:
                return TelegramResponse(
                    success=False,
                    error_code=result.get('error_code'),
                    description=result.get('description')
                )
                
        except aiohttp.ClientError as e:
            return TelegramResponse(
                success=False,
                description=f"Network error: {e}"
            )
        except Exception as e:
            logger.error(f"Telegram API error: {e}")
            return TelegramResponse(
                success=False,
                description=str(e)
            )
    
    async def get_me(self) -> TelegramResponse:
        """Get bot information."""
        response = await self._api_request('getMe')
        if response.success:
            self._bot_info = response.result
        return response
    
    async def send_message(
        self,
        chat_id: Optional[int] = None,
        text: str = "",
        parse_mode: ParseMode = ParseMode.TEXT,
        disable_notification: bool = False,
        reply_to_message_id: Optional[int] = None,
        reply_markup: Optional[Dict[str, Any]] = None,
        disable_web_page_preview: bool = False
    ) -> TelegramResponse:
        """
        Send text message.
        
        Args:
            chat_id: Target chat ID
            text: Message text
            parse_mode: Text parsing mode
            disable_notification: Send silently
            reply_to_message_id: Message to reply to
            reply_markup: Inline keyboard or reply markup
            disable_web_page_preview: Disable link previews
            
        Returns:
            TelegramResponse with sent message
        """
        chat_id = chat_id or self._default_chat_id
        if not chat_id:
            return TelegramResponse(
                success=False,
                description="chat_id is required"
            )
        
        data = {
            'chat_id': chat_id,
            'text': text,
            'disable_notification': disable_notification,
            'disable_web_page_preview': disable_web_page_preview
        }
        
        if parse_mode.value:
            data['parse_mode'] = parse_mode.value
        
        if reply_to_message_id:
            data['reply_to_message_id'] = reply_to_message_id
        
        if reply_markup:
            data['reply_markup'] = reply_markup
        
        return await self._api_request('sendMessage', data)
    
    async def send_photo(
        self,
        chat_id: Optional[int] = None,
        photo: Union[str, bytes] = None,
        caption: Optional[str] = None,
        parse_mode: ParseMode = ParseMode.TEXT,
        reply_to_message_id: Optional[int] = None,
        reply_markup: Optional[Dict[str, Any]] = None
    ) -> TelegramResponse:
        """
        Send photo.
        
        Args:
            chat_id: Target chat ID
            photo: Photo file path, URL, or bytes
            caption: Photo caption
            parse_mode: Caption parsing mode
            reply_to_message_id: Message to reply to
            reply_markup: Inline keyboard
            
        Returns:
            TelegramResponse with sent message
        """
        chat_id = chat_id or self._default_chat_id
        if not chat_id:
            return TelegramResponse(
                success=False,
                description="chat_id is required"
            )
        
        data = {'chat_id': chat_id}
        files = {}
        
        if caption:
            data['caption'] = caption
        if parse_mode.value:
            data['parse_mode'] = parse_mode.value
        if reply_to_message_id:
            data['reply_to_message_id'] = reply_to_message_id
        if reply_markup:
            data['reply_markup'] = reply_markup
        
        # Check if URL or file
        if isinstance(photo, str):
            if photo.startswith('http://') or photo.startswith('https://'):
                data['photo'] = photo
            else:
                files['photo'] = photo
        else:
            files['photo'] = photo
        
        return await self._api_request('sendPhoto', data, files if files else None)
    
    async def send_document(
        self,
        chat_id: Optional[int] = None,
        document: Union[str, bytes] = None,
        caption: Optional[str] = None,
        filename: Optional[str] = None,
        parse_mode: ParseMode = ParseMode.TEXT,
        reply_to_message_id: Optional[int] = None
    ) -> TelegramResponse:
        """
        Send document/file.
        
        Args:
            chat_id: Target chat ID
            document: Document file path or bytes
            caption: Document caption
            filename: Override filename
            parse_mode: Caption parsing mode
            reply_to_message_id: Message to reply to
            
        Returns:
            TelegramResponse with sent message
        """
        chat_id = chat_id or self._default_chat_id
        if not chat_id:
            return TelegramResponse(
                success=False,
                description="chat_id is required"
            )
        
        data = {'chat_id': chat_id}
        files = {}
        
        if caption:
            data['caption'] = caption
        if parse_mode.value:
            data['parse_mode'] = parse_mode.value
        if reply_to_message_id:
            data['reply_to_message_id'] = reply_to_message_id
        
        if isinstance(document, str):
            if document.startswith('http://') or document.startswith('https://'):
                data['document'] = document
            else:
                files['document'] = document
        else:
            files['document'] = document
        
        return await self._api_request('sendDocument', data, files if files else None)
    
    async def send_video(
        self,
        chat_id: Optional[int] = None,
        video: Union[str, bytes] = None,
        caption: Optional[str] = None,
        duration: Optional[int] = None,
        width: Optional[int] = None,
        height: Optional[int] = None,
        parse_mode: ParseMode = ParseMode.TEXT
    ) -> TelegramResponse:
        """Send video."""
        chat_id = chat_id or self._default_chat_id
        if not chat_id:
            return TelegramResponse(success=False, description="chat_id is required")
        
        data = {'chat_id': chat_id}
        files = {}
        
        if caption:
            data['caption'] = caption
        if parse_mode.value:
            data['parse_mode'] = parse_mode.value
        if duration:
            data['duration'] = duration
        if width:
            data['width'] = width
        if height:
            data['height'] = height
        
        if isinstance(video, str) and not video.startswith('http'):
            files['video'] = video
        else:
            data['video'] = video
        
        return await self._api_request('sendVideo', data, files if files else None)
    
    async def send_audio(
        self,
        chat_id: Optional[int] = None,
        audio: Union[str, bytes] = None,
        caption: Optional[str] = None,
        duration: Optional[int] = None,
        performer: Optional[str] = None,
        title: Optional[str] = None,
        parse_mode: ParseMode = ParseMode.TEXT
    ) -> TelegramResponse:
        """Send audio file."""
        chat_id = chat_id or self._default_chat_id
        if not chat_id:
            return TelegramResponse(success=False, description="chat_id is required")
        
        data = {'chat_id': chat_id}
        files = {}
        
        if caption:
            data['caption'] = caption
        if parse_mode.value:
            data['parse_mode'] = parse_mode.value
        if duration:
            data['duration'] = duration
        if performer:
            data['performer'] = performer
        if title:
            data['title'] = title
        
        if isinstance(audio, str) and not audio.startswith('http'):
            files['audio'] = audio
        else:
            data['audio'] = audio
        
        return await self._api_request('sendAudio', data, files if files else None)
    
    async def send_location(
        self,
        chat_id: Optional[int] = None,
        latitude: float = 0,
        longitude: float = 0,
        reply_to_message_id: Optional[int] = None
    ) -> TelegramResponse:
        """Send location."""
        chat_id = chat_id or self._default_chat_id
        if not chat_id:
            return TelegramResponse(success=False, description="chat_id is required")
        
        data = {
            'chat_id': chat_id,
            'latitude': latitude,
            'longitude': longitude
        }
        
        if reply_to_message_id:
            data['reply_to_message_id'] = reply_to_message_id
        
        return await self._api_request('sendLocation', data)
    
    async def send_contact(
        self,
        chat_id: Optional[int] = None,
        phone_number: str = "",
        first_name: str = "",
        last_name: Optional[str] = None
    ) -> TelegramResponse:
        """Send contact."""
        chat_id = chat_id or self._default_chat_id
        if not chat_id:
            return TelegramResponse(success=False, description="chat_id is required")
        
        data = {
            'chat_id': chat_id,
            'phone_number': phone_number,
            'first_name': first_name
        }
        
        if last_name:
            data['last_name'] = last_name
        
        return await self._api_request('sendContact', data)
    
    async def forward_message(
        self,
        chat_id: int,
        from_chat_id: int,
        message_id: int,
        disable_notification: bool = False
    ) -> TelegramResponse:
        """Forward a message."""
        data = {
            'chat_id': chat_id,
            'from_chat_id': from_chat_id,
            'message_id': message_id,
            'disable_notification': disable_notification
        }
        
        return await self._api_request('forwardMessage', data)
    
    async def edit_message_text(
        self,
        chat_id: int,
        message_id: int,
        text: str,
        parse_mode: ParseMode = ParseMode.TEXT,
        reply_markup: Optional[Dict[str, Any]] = None
    ) -> TelegramResponse:
        """Edit message text."""
        data = {
            'chat_id': chat_id,
            'message_id': message_id,
            'text': text
        }
        
        if parse_mode.value:
            data['parse_mode'] = parse_mode.value
        if reply_markup:
            data['reply_markup'] = reply_markup
        
        return await self._api_request('editMessageText', data)
    
    async def delete_message(
        self,
        chat_id: int,
        message_id: int
    ) -> TelegramResponse:
        """Delete a message."""
        data = {
            'chat_id': chat_id,
            'message_id': message_id
        }
        
        return await self._api_request('deleteMessage', data)
    
    async def send_chat_action(
        self,
        chat_id: Optional[int] = None,
        action: ChatAction = ChatAction.TYPING
    ) -> TelegramResponse:
        """Send chat action (typing indicator)."""
        chat_id = chat_id or self._default_chat_id
        if not chat_id:
            return TelegramResponse(success=False, description="chat_id is required")
        
        data = {
            'chat_id': chat_id,
            'action': action.value
        }
        
        return await self._api_request('sendChatAction', data)
    
    async def get_updates(
        self,
        offset: Optional[int] = None,
        limit: int = 100,
        timeout: int = 0,
        allowed_updates: Optional[List[str]] = None
    ) -> TelegramResponse:
        """Get bot updates (messages, callbacks, etc.)."""
        data = {
            'limit': limit,
            'timeout': timeout
        }
        
        if offset is not None:
            data['offset'] = offset
        if allowed_updates:
            data['allowed_updates'] = allowed_updates
        
        return await self._api_request('getUpdates', data)
    
    async def get_chat(self, chat_id: int) -> TelegramResponse:
        """Get chat information."""
        return await self._api_request('getChat', {'chat_id': chat_id})
    
    async def get_chat_member(
        self,
        chat_id: int,
        user_id: int
    ) -> TelegramResponse:
        """Get chat member information."""
        data = {
            'chat_id': chat_id,
            'user_id': user_id
        }
        return await self._api_request('getChatMember', data)
    
    async def get_chat_member_count(self, chat_id: int) -> TelegramResponse:
        """Get chat member count."""
        return await self._api_request('getChatMemberCount', {'chat_id': chat_id})
    
    async def answer_callback_query(
        self,
        callback_query_id: str,
        text: Optional[str] = None,
        show_alert: bool = False,
        url: Optional[str] = None
    ) -> TelegramResponse:
        """Answer callback query from inline keyboard."""
        data = {
            'callback_query_id': callback_query_id,
            'show_alert': show_alert
        }
        
        if text:
            data['text'] = text
        if url:
            data['url'] = url
        
        return await self._api_request('answerCallbackQuery', data)
    
    async def set_webhook(
        self,
        url: str,
        certificate: Optional[str] = None,
        max_connections: int = 40,
        allowed_updates: Optional[List[str]] = None
    ) -> TelegramResponse:
        """Set webhook URL."""
        data = {
            'url': url,
            'max_connections': max_connections
        }
        
        if allowed_updates:
            data['allowed_updates'] = allowed_updates
        
        files = {}
        if certificate:
            files['certificate'] = certificate
        
        return await self._api_request('setWebhook', data, files if files else None)
    
    async def delete_webhook(self) -> TelegramResponse:
        """Delete webhook."""
        return await self._api_request('deleteWebhook')
    
    async def get_webhook_info(self) -> TelegramResponse:
        """Get webhook info."""
        return await self._api_request('getWebhookInfo')
    
    def create_inline_keyboard(
        self,
        buttons: List[List[Dict[str, str]]]
    ) -> Dict[str, Any]:
        """
        Create inline keyboard markup.
        
        Args:
            buttons: 2D list of button dicts with 'text' and 'callback_data' or 'url'
            
        Returns:
            Inline keyboard markup dict
        """
        keyboard = []
        for row in buttons:
            keyboard_row = []
            for btn in row:
                button = InlineKeyboardButton(
                    text=btn.get('text', ''),
                    callback_data=btn.get('callback_data'),
                    url=btn.get('url')
                )
                keyboard_row.append(button.to_dict())
            keyboard.append(keyboard_row)
        
        return {'inline_keyboard': keyboard}
    
    def create_reply_keyboard(
        self,
        buttons: List[List[str]],
        resize_keyboard: bool = True,
        one_time_keyboard: bool = False
    ) -> Dict[str, Any]:
        """
        Create reply keyboard markup.
        
        Args:
            buttons: 2D list of button texts
            resize_keyboard: Resize keyboard to fit buttons
            one_time_keyboard: Hide after use
            
        Returns:
            Reply keyboard markup dict
        """
        keyboard = [[{'text': btn} for btn in row] for row in buttons]
        
        return {
            'keyboard': keyboard,
            'resize_keyboard': resize_keyboard,
            'one_time_keyboard': one_time_keyboard
        }
    
    async def run(self, context: ToolContext, **kwargs) -> ToolResult:
        """
        Execute Telegram operation.
        
        Supported operations:
        - get_me: Get bot info
        - send_message: Send text message
        - send_photo: Send photo
        - send_document: Send document
        - send_video: Send video
        - send_audio: Send audio
        - send_location: Send location
        - send_contact: Send contact
        - forward: Forward message
        - edit: Edit message
        - delete: Delete message
        - typing: Send typing indicator
        - get_updates: Get updates
        - get_chat: Get chat info
        - webhook: Set/delete/get webhook
        """
        operation = kwargs.get('operation', 'send_message')
        
        if not self.is_configured:
            return ToolResult.fail(
                error="Telegram bot token not configured. Set TELEGRAM_BOT_TOKEN environment variable."
            )
        
        try:
            if operation == 'get_me':
                response = await self.get_me()
                
            elif operation == 'send_message':
                text = kwargs.get('text') or kwargs.get('message')
                if not text:
                    return ToolResult.fail(error="text is required")
                
                parse_mode_str = kwargs.get('parse_mode', 'text').upper()
                try:
                    parse_mode = ParseMode[parse_mode_str]
                except KeyError:
                    parse_mode = ParseMode.TEXT
                
                # Build inline keyboard if provided
                reply_markup = None
                if kwargs.get('buttons'):
                    reply_markup = self.create_inline_keyboard(kwargs['buttons'])
                elif kwargs.get('reply_keyboard'):
                    reply_markup = self.create_reply_keyboard(kwargs['reply_keyboard'])
                
                response = await self.send_message(
                    chat_id=kwargs.get('chat_id'),
                    text=text,
                    parse_mode=parse_mode,
                    disable_notification=kwargs.get('silent', False),
                    reply_to_message_id=kwargs.get('reply_to'),
                    reply_markup=reply_markup,
                    disable_web_page_preview=kwargs.get('no_preview', False)
                )
                
            elif operation == 'send_photo':
                photo = kwargs.get('photo')
                if not photo:
                    return ToolResult.fail(error="photo is required")
                
                response = await self.send_photo(
                    chat_id=kwargs.get('chat_id'),
                    photo=photo,
                    caption=kwargs.get('caption'),
                    reply_to_message_id=kwargs.get('reply_to')
                )
                
            elif operation == 'send_document':
                document = kwargs.get('document') or kwargs.get('file')
                if not document:
                    return ToolResult.fail(error="document is required")
                
                response = await self.send_document(
                    chat_id=kwargs.get('chat_id'),
                    document=document,
                    caption=kwargs.get('caption'),
                    filename=kwargs.get('filename')
                )
                
            elif operation == 'send_video':
                video = kwargs.get('video')
                if not video:
                    return ToolResult.fail(error="video is required")
                
                response = await self.send_video(
                    chat_id=kwargs.get('chat_id'),
                    video=video,
                    caption=kwargs.get('caption'),
                    duration=kwargs.get('duration')
                )
                
            elif operation == 'send_audio':
                audio = kwargs.get('audio')
                if not audio:
                    return ToolResult.fail(error="audio is required")
                
                response = await self.send_audio(
                    chat_id=kwargs.get('chat_id'),
                    audio=audio,
                    caption=kwargs.get('caption'),
                    title=kwargs.get('title'),
                    performer=kwargs.get('performer')
                )
                
            elif operation == 'send_location':
                lat = kwargs.get('latitude') or kwargs.get('lat')
                lon = kwargs.get('longitude') or kwargs.get('lon')
                
                if lat is None or lon is None:
                    return ToolResult.fail(error="latitude and longitude are required")
                
                response = await self.send_location(
                    chat_id=kwargs.get('chat_id'),
                    latitude=float(lat),
                    longitude=float(lon)
                )
                
            elif operation == 'send_contact':
                phone = kwargs.get('phone_number') or kwargs.get('phone')
                first_name = kwargs.get('first_name')
                
                if not phone or not first_name:
                    return ToolResult.fail(error="phone_number and first_name are required")
                
                response = await self.send_contact(
                    chat_id=kwargs.get('chat_id'),
                    phone_number=phone,
                    first_name=first_name,
                    last_name=kwargs.get('last_name')
                )
                
            elif operation == 'forward':
                chat_id = kwargs.get('chat_id')
                from_chat_id = kwargs.get('from_chat_id')
                message_id = kwargs.get('message_id')
                
                if not all([chat_id, from_chat_id, message_id]):
                    return ToolResult.fail(error="chat_id, from_chat_id, and message_id are required")
                
                response = await self.forward_message(
                    chat_id=chat_id,
                    from_chat_id=from_chat_id,
                    message_id=message_id
                )
                
            elif operation == 'edit':
                chat_id = kwargs.get('chat_id')
                message_id = kwargs.get('message_id')
                text = kwargs.get('text')
                
                if not all([chat_id, message_id, text]):
                    return ToolResult.fail(error="chat_id, message_id, and text are required")
                
                response = await self.edit_message_text(
                    chat_id=chat_id,
                    message_id=message_id,
                    text=text
                )
                
            elif operation == 'delete':
                chat_id = kwargs.get('chat_id')
                message_id = kwargs.get('message_id')
                
                if not chat_id or not message_id:
                    return ToolResult.fail(error="chat_id and message_id are required")
                
                response = await self.delete_message(chat_id, message_id)
                
            elif operation == 'typing':
                action_str = kwargs.get('action', 'typing').upper()
                try:
                    action = ChatAction[action_str]
                except KeyError:
                    action = ChatAction.TYPING
                
                response = await self.send_chat_action(
                    chat_id=kwargs.get('chat_id'),
                    action=action
                )
                
            elif operation == 'get_updates':
                response = await self.get_updates(
                    offset=kwargs.get('offset'),
                    limit=kwargs.get('limit', 100),
                    timeout=kwargs.get('timeout', 0)
                )
                
            elif operation == 'get_chat':
                chat_id = kwargs.get('chat_id')
                if not chat_id:
                    return ToolResult.fail(error="chat_id is required")
                
                response = await self.get_chat(chat_id)
                
            elif operation == 'set_webhook':
                url = kwargs.get('url')
                if not url:
                    return ToolResult.fail(error="url is required")
                
                response = await self.set_webhook(
                    url=url,
                    max_connections=kwargs.get('max_connections', 40)
                )
                
            elif operation == 'delete_webhook':
                response = await self.delete_webhook()
                
            elif operation == 'get_webhook':
                response = await self.get_webhook_info()
                
            else:
                return ToolResult.fail(error=f"Unknown operation: {operation}")
            
            if response.success:
                return ToolResult.ok(
                    data=response.to_dict(),
                    message="Operation successful"
                )
            else:
                return ToolResult.fail(
                    error=response.description or "Operation failed",
                    data=response.to_dict()
                )
                
        except Exception as e:
            logger.error(f"TelegramTools error: {e}")
            return ToolResult.error(error=str(e))
    
    async def cleanup(self) -> None:
        """Close HTTP session."""
        if self._session and not self._session.closed:
            await self._session.close()


# Create singleton
telegram_tools = TelegramTools()


def register():
    """Register Telegram tools."""
    registry = get_registry()
    registry.register_tool(telegram_tools)