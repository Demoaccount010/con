"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                          TOOL EXECUTOR                                        ║
║                    Execute Tools Safely and Reliably                          ║
╚══════════════════════════════════════════════════════════════════════════════╝

The Tool Executor handles:
- Safe tool execution
- Permission checking
- Confirmation handling
- Rate limiting
- Execution tracking
- Error handling
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Callable, Awaitable
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict

from tools.registry import ToolRegistry, ToolRisk, get_registry
from tools.base_tool import ToolResult, ToolContext, ResultStatus, BaseTool

logger = logging.getLogger(__name__)


class ExecutionMode(Enum):
    """Execution modes"""
    NORMAL = "normal"
    DRY_RUN = "dry_run"
    SAFE = "safe"           # Extra safety checks
    UNRESTRICTED = "unrestricted"  # Skip safety checks


@dataclass
class ExecutionRequest:
    """A request to execute a tool"""
    tool_name: str
    parameters: Dict[str, Any]
    context: Optional[ToolContext] = None
    
    # Options
    mode: ExecutionMode = ExecutionMode.NORMAL
    timeout_seconds: Optional[float] = None
    retry_on_failure: bool = False
    max_retries: int = 3
    
    # Tracking
    request_id: str = ""
    requested_at: datetime = field(default_factory=datetime.now)


@dataclass
class ExecutionRecord:
    """Record of tool execution"""
    request_id: str
    tool_name: str
    started_at: datetime
    completed_at: Optional[datetime] = None
    
    # Result
    success: bool = False
    status: ResultStatus = ResultStatus.ERROR
    result: Optional[ToolResult] = None
    error: Optional[str] = None
    
    # Metrics
    execution_time_ms: float = 0.0
    retries: int = 0


@dataclass
class ExecutorConfig:
    """Configuration for tool executor"""
    # Timeouts
    default_timeout_seconds: float = 60.0
    max_timeout_seconds: float = 300.0
    
    # Retries
    allow_retries: bool = True
    default_max_retries: int = 3
    retry_delay_seconds: float = 1.0
    
    # Safety
    require_confirmation_for_destructive: bool = True
    block_critical_risk: bool = True
    safe_mode: bool = False
    
    # Rate limiting
    rate_limit_enabled: bool = True
    max_executions_per_minute: int = 60
    max_executions_per_tool_per_minute: int = 20
    
    # History
    keep_history: bool = True
    max_history_size: int = 1000
    
    # Callbacks
    on_before_execute: Optional[Callable] = None
    on_after_execute: Optional[Callable] = None


class RateLimiter:
    """Rate limiter for tool execution"""
    
    def __init__(
        self,
        global_limit: int = 60,
        per_tool_limit: int = 20,
        window_seconds: int = 60
    ):
        self.global_limit = global_limit
        self.per_tool_limit = per_tool_limit
        self.window_seconds = window_seconds
        
        self._global_executions: List[datetime] = []
        self._tool_executions: Dict[str, List[datetime]] = defaultdict(list)
        self._lock = asyncio.Lock()
    
    async def check(self, tool_name: str) -> tuple[bool, Optional[str]]:
        """Check if execution is allowed"""
        async with self._lock:
            now = datetime.now()
            window_start = now - timedelta(seconds=self.window_seconds)
            
            # Clean old entries
            self._global_executions = [
                t for t in self._global_executions if t > window_start
            ]
            self._tool_executions[tool_name] = [
                t for t in self._tool_executions[tool_name] if t > window_start
            ]
            
            # Check global limit
            if len(self._global_executions) >= self.global_limit:
                return False, "Global rate limit exceeded"
            
            # Check per-tool limit
            if len(self._tool_executions[tool_name]) >= self.per_tool_limit:
                return False, f"Rate limit exceeded for tool: {tool_name}"
            
            return True, None
    
    async def record(self, tool_name: str) -> None:
        """Record an execution"""
        async with self._lock:
            now = datetime.now()
            self._global_executions.append(now)
            self._tool_executions[tool_name].append(now)


class ConfirmationHandler:
    """Handle confirmation requests"""
    
    def __init__(self):
        self._pending: Dict[str, Dict[str, Any]] = {}
        self._confirmed: Dict[str, bool] = {}
    
    async def request_confirmation(
        self,
        request_id: str,
        tool_name: str,
        description: str
    ) -> None:
        """Request confirmation for an action"""
        self._pending[request_id] = {
            "tool_name": tool_name,
            "description": description,
            "requested_at": datetime.now()
        }
    
    async def confirm(self, request_id: str) -> bool:
        """Confirm a pending request"""
        if request_id in self._pending:
            del self._pending[request_id]
            self._confirmed[request_id] = True
            return True
        return False
    
    async def deny(self, request_id: str) -> bool:
        """Deny a pending request"""
        if request_id in self._pending:
            del self._pending[request_id]
            self._confirmed[request_id] = False
            return True
        return False
    
    def is_confirmed(self, request_id: str) -> Optional[bool]:
        """Check if request is confirmed"""
        return self._confirmed.get(request_id)
    
    def is_pending(self, request_id: str) -> bool:
        """Check if request is pending"""
        return request_id in self._pending
    
    def get_pending(self) -> List[Dict[str, Any]]:
        """Get all pending confirmations"""
        return [
            {"request_id": rid, **info}
            for rid, info in self._pending.items()
        ]


class ToolExecutor:
    """
    Execute tools safely and reliably
    
    Features:
    - Safe execution with error handling
    - Permission and confirmation checking
    - Rate limiting
    - Retry logic
    - Execution history
    """
    
    def __init__(
        self,
        config: Optional[ExecutorConfig] = None,
        registry: Optional[ToolRegistry] = None
    ):
        self.config = config or ExecutorConfig()
        self.registry = registry or get_registry()
        
        # Components
        self._rate_limiter = RateLimiter(
            global_limit=self.config.max_executions_per_minute,
            per_tool_limit=self.config.max_executions_per_tool_per_minute
        )
        self._confirmation_handler = ConfirmationHandler()
        
        # State
        self._history: List[ExecutionRecord] = []
        self._running: Dict[str, ExecutionRequest] = {}
        
        # Callbacks
        self._before_callbacks: List[Callable] = []
        self._after_callbacks: List[Callable] = []
        
        # Statistics
        self._stats = {
            "total_executions": 0,
            "successful_executions": 0,
            "failed_executions": 0,
            "rate_limited": 0,
            "confirmations_required": 0
        }
        
        logger.info("ToolExecutor initialized")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # EXECUTION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def execute(
        self,
        tool_name: str,
        parameters: Optional[Dict[str, Any]] = None,
        context: Optional[ToolContext] = None,
        mode: ExecutionMode = ExecutionMode.NORMAL,
        timeout: Optional[float] = None
    ) -> ToolResult:
        """
        Execute a tool
        
        Args:
            tool_name: Name of tool to execute
            parameters: Tool parameters
            context: Execution context
            mode: Execution mode
            timeout: Timeout in seconds
        
        Returns:
            ToolResult
        """
        parameters = parameters or {}
        context = context or ToolContext()
        
        # Generate request ID
        request_id = f"exec_{datetime.now().timestamp()}"
        
        request = ExecutionRequest(
            tool_name=tool_name,
            parameters=parameters,
            context=context,
            mode=mode,
            timeout_seconds=timeout or self.config.default_timeout_seconds,
            request_id=request_id
        )
        
        return await self._execute_request(request)
    
    async def _execute_request(self, request: ExecutionRequest) -> ToolResult:
        """Execute a request"""
        start_time = datetime.now()
        record = ExecutionRecord(
            request_id=request.request_id,
            tool_name=request.tool_name,
            started_at=start_time
        )
        
        self._running[request.request_id] = request
        self._stats["total_executions"] += 1
        
        try:
            # Pre-execution checks
            result = await self._pre_execution_checks(request)
            if result:
                return result
            
            # Get tool
            tool = self.registry.get(request.tool_name)
            if not tool:
                return ToolResult.fail(
                    error=f"Tool not found: {request.tool_name}",
                    message="Tool not found"
                )
            
            # Check confirmation
            if tool.metadata.requires_confirmation:
                if not request.context.confirmed:
                    self._stats["confirmations_required"] += 1
                    
                    await self._confirmation_handler.request_confirmation(
                        request.request_id,
                        request.tool_name,
                        f"Execute {request.tool_name} with {request.parameters}"
                    )
                    
                    return ToolResult(
                        success=False,
                        status=ResultStatus.CANCELLED,
                        message="Confirmation required",
                        error="Please confirm this action",
                        metadata={"request_id": request.request_id}
                    )
            
            # Execute before callbacks
            for callback in self._before_callbacks:
                try:
                    await callback(request)
                except Exception as e:
                    logger.warning(f"Before callback error: {e}")
            
            # Execute tool
            result = await self._execute_tool(tool, request)
            
            # Update record
            record.success = result.success
            record.status = result.status
            record.result = result
            
            # Update stats
            if result.success:
                self._stats["successful_executions"] += 1
            else:
                self._stats["failed_executions"] += 1
            
            # Record usage
            self.registry.record_usage(
                request.tool_name,
                result.success,
                result.execution_time_ms
            )
            
            # Execute after callbacks
            for callback in self._after_callbacks:
                try:
                    await callback(request, result)
                except Exception as e:
                    logger.warning(f"After callback error: {e}")
            
            return result
            
        except Exception as e:
            logger.error(f"Execution error: {e}")
            record.error = str(e)
            self._stats["failed_executions"] += 1
            
            return ToolResult.error(
                error=str(e),
                message=f"Error executing {request.tool_name}"
            )
            
        finally:
            # Complete record
            record.completed_at = datetime.now()
            record.execution_time_ms = (
                record.completed_at - record.started_at
            ).total_seconds() * 1000
            
            # Add to history
            if self.config.keep_history:
                self._history.append(record)
                if len(self._history) > self.config.max_history_size:
                    self._history = self._history[-self.config.max_history_size:]
            
            # Remove from running
            if request.request_id in self._running:
                del self._running[request.request_id]
    
    async def _pre_execution_checks(
        self,
        request: ExecutionRequest
    ) -> Optional[ToolResult]:
        """Run pre-execution checks"""
        # Check rate limit
        if self.config.rate_limit_enabled:
            allowed, reason = await self._rate_limiter.check(request.tool_name)
            if not allowed:
                self._stats["rate_limited"] += 1
                return ToolResult.fail(
                    error=reason or "Rate limited",
                    message="Rate limit exceeded"
                )
            await self._rate_limiter.record(request.tool_name)
        
        # Check permissions
        can_use, reason = self.registry.can_use_tool(request.tool_name)
        if not can_use:
            return ToolResult.fail(
                error=reason or "Permission denied",
                message="Cannot use this tool"
            )
        
        # Check safe mode
        if self.config.safe_mode or request.mode == ExecutionMode.SAFE:
            tool = self.registry.get(request.tool_name)
            if tool and tool.metadata.risk in [ToolRisk.HIGH, ToolRisk.CRITICAL]:
                return ToolResult.fail(
                    error="Safe mode blocks high-risk tools",
                    message="Tool blocked by safe mode"
                )
        
        # Check critical risk
        if self.config.block_critical_risk:
            tool = self.registry.get(request.tool_name)
            if tool and tool.metadata.risk == ToolRisk.CRITICAL:
                return ToolResult.fail(
                    error="Critical risk tools are blocked",
                    message="Tool blocked"
                )
        
        return None
    
    async def _execute_tool(
        self,
        tool,
        request: ExecutionRequest
    ) -> ToolResult:
        """Execute a specific tool"""
        # Handle dry run
        if request.mode == ExecutionMode.DRY_RUN:
            request.context.dry_run = True
        
        # Set timeout
        timeout = min(
            request.timeout_seconds or self.config.default_timeout_seconds,
            self.config.max_timeout_seconds
        )
        request.context.timeout_seconds = timeout
        
        # Execute with retry
        last_error = None
        retries = 0
        max_retries = request.max_retries if request.retry_on_failure else 1
        
        while retries < max_retries:
            try:
                # Execute
                if hasattr(tool, 'instance') and tool.instance:
                    # Use cached instance
                    result = await asyncio.wait_for(
                        tool.instance.run(request.context, **request.parameters),
                        timeout=timeout
                    )
                else:
                    # Use handler
                    result = await asyncio.wait_for(
                        tool.handler(**request.parameters),
                        timeout=timeout
                    )
                
                # Convert if needed
                if not isinstance(result, ToolResult):
                    result = ToolResult.ok(data=result)
                
                result.tool_name = request.tool_name
                
                if result.success:
                    return result
                
                # Don't retry on certain failures
                if result.status in [ResultStatus.CANCELLED, ResultStatus.TIMEOUT]:
                    return result
                
                last_error = result.error
                
            except asyncio.TimeoutError:
                last_error = f"Timeout after {timeout}s"
                return ToolResult(
                    success=False,
                    status=ResultStatus.TIMEOUT,
                    error=last_error,
                    tool_name=request.tool_name
                )
                
            except Exception as e:
                last_error = str(e)
                logger.warning(f"Execution attempt {retries + 1} failed: {e}")
            
            retries += 1
            
            if retries < max_retries:
                await asyncio.sleep(self.config.retry_delay_seconds * retries)
        
        return ToolResult.fail(
            error=last_error or "Max retries exceeded",
            message=f"Failed after {retries} attempts"
        )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CONFIRMATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def confirm_execution(self, request_id: str) -> Optional[ToolResult]:
        """Confirm and execute a pending request"""
        # Check if there's a pending confirmation
        if not self._confirmation_handler.is_pending(request_id):
            return None
        
        await self._confirmation_handler.confirm(request_id)
        
        # Re-execute with confirmation
        # Note: In practice, you'd need to store the original request
        # This is simplified
        return ToolResult.ok(message="Confirmation accepted")
    
    async def deny_execution(self, request_id: str) -> bool:
        """Deny a pending execution"""
        return await self._confirmation_handler.deny(request_id)
    
    def get_pending_confirmations(self) -> List[Dict[str, Any]]:
        """Get pending confirmations"""
        return self._confirmation_handler.get_pending()
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CALLBACKS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def on_before_execute(
        self,
        callback: Callable[[ExecutionRequest], Awaitable[None]]
    ) -> None:
        """Register before-execution callback"""
        self._before_callbacks.append(callback)
    
    def on_after_execute(
        self,
        callback: Callable[[ExecutionRequest, ToolResult], Awaitable[None]]
    ) -> None:
        """Register after-execution callback"""
        self._after_callbacks.append(callback)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # HISTORY AND STATS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_history(
        self,
        tool_name: Optional[str] = None,
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        """Get execution history"""
        history = self._history
        
        if tool_name:
            history = [h for h in history if h.tool_name == tool_name]
        
        history = history[-limit:]
        
        return [
            {
                "request_id": h.request_id,
                "tool_name": h.tool_name,
                "success": h.success,
                "status": h.status.value,
                "execution_time_ms": h.execution_time_ms,
                "started_at": h.started_at.isoformat(),
                "error": h.error
            }
            for h in history
        ]
    
    def get_running(self) -> List[Dict[str, Any]]:
        """Get currently running executions"""
        return [
            {
                "request_id": r.request_id,
                "tool_name": r.tool_name,
                "started_at": r.requested_at.isoformat()
            }
            for r in self._running.values()
        ]
    
    def get_stats(self) -> Dict[str, Any]:
        """Get executor statistics"""
        return {
            **self._stats,
            "running": len(self._running),
            "history_size": len(self._history),
            "pending_confirmations": len(self._confirmation_handler.get_pending())
        }
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MODE MANAGEMENT
    # ═══════════════════════════════════════════════════════════════════════════
    
    def enable_safe_mode(self) -> None:
        """Enable safe mode"""
        self.config.safe_mode = True
        logger.info("Safe mode enabled")
    
    def disable_safe_mode(self) -> None:
        """Disable safe mode"""
        self.config.safe_mode = False
        logger.info("Safe mode disabled")
    
    def is_safe_mode(self) -> bool:
        """Check if safe mode is enabled"""
        return self.config.safe_mode


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

async def create_executor(
    registry: Optional[ToolRegistry] = None,
    safe_mode: bool = False,
    **kwargs
) -> ToolExecutor:
    """Create configured tool executor"""
    config = ExecutorConfig(
        safe_mode=safe_mode,
        **kwargs
    )
    
    executor = ToolExecutor(
        config=config,
        registry=registry
    )
    
    return executor