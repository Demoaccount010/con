"""
═══════════════════════════════════════════════════════════════════════════════════════
DATETIME TOOLS - DATE AND TIME UTILITIES
═══════════════════════════════════════════════════════════════════════════════════════
Comprehensive date/time manipulation:
- Timezone handling
- Date parsing and formatting
- Duration calculations
- Relative time (ago, until)
- Cron expression parsing
- Calendar utilities
- Unix timestamp conversion
- ISO 8601 support
"""

import asyncio
import logging
import re
import calendar
from dataclasses import dataclass, field
from datetime import datetime, date, time, timedelta, timezone
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Union, Tuple, Generator
import time as time_module

logger = logging.getLogger(__name__)

# Try to import optional libraries
try:
    import pytz
    PYTZ_AVAILABLE = True
except ImportError:
    PYTZ_AVAILABLE = False

try:
    from dateutil import parser as dateutil_parser
    from dateutil.relativedelta import relativedelta
    from dateutil.rrule import rrule, YEARLY, MONTHLY, WEEKLY, DAILY, HOURLY, MINUTELY
    DATEUTIL_AVAILABLE = True
except ImportError:
    DATEUTIL_AVAILABLE = False


class TimeUnit(Enum):
    """Time units for calculations."""
    NANOSECOND = "nanosecond"
    MICROSECOND = "microsecond"
    MILLISECOND = "millisecond"
    SECOND = "second"
    MINUTE = "minute"
    HOUR = "hour"
    DAY = "day"
    WEEK = "week"
    MONTH = "month"
    YEAR = "year"


class DateFormat(Enum):
    """Common date formats."""
    ISO = "%Y-%m-%dT%H:%M:%S"
    ISO_DATE = "%Y-%m-%d"
    ISO_TIME = "%H:%M:%S"
    ISO_FULL = "%Y-%m-%dT%H:%M:%S.%f%z"
    US = "%m/%d/%Y"
    EU = "%d/%m/%Y"
    HUMAN = "%B %d, %Y"
    HUMAN_TIME = "%B %d, %Y at %I:%M %p"
    LOG = "%Y-%m-%d %H:%M:%S"
    COMPACT = "%Y%m%d%H%M%S"
    RFC2822 = "%a, %d %b %Y %H:%M:%S %z"
    UNIX = "unix"


@dataclass
class DateTimeInfo:
    """Detailed information about a datetime."""
    datetime: datetime
    date: date
    time: time
    year: int
    month: int
    day: int
    hour: int
    minute: int
    second: int
    microsecond: int
    weekday: int
    weekday_name: str
    month_name: str
    iso_week: int
    day_of_year: int
    is_weekend: bool
    is_leap_year: bool
    quarter: int
    timezone: Optional[str] = None
    utc_offset: Optional[str] = None
    unix_timestamp: float = 0.0
    iso_format: str = ""


@dataclass
class Duration:
    """Represents a time duration."""
    total_seconds: float
    days: int = 0
    hours: int = 0
    minutes: int = 0
    seconds: int = 0
    milliseconds: int = 0
    
    def __post_init__(self):
        if self.total_seconds and not any([self.days, self.hours, self.minutes]):
            self._decompose()
    
    def _decompose(self):
        """Decompose total seconds into components."""
        remaining = abs(self.total_seconds)
        
        self.days = int(remaining // 86400)
        remaining %= 86400
        
        self.hours = int(remaining // 3600)
        remaining %= 3600
        
        self.minutes = int(remaining // 60)
        remaining %= 60
        
        self.seconds = int(remaining)
        self.milliseconds = int((remaining - self.seconds) * 1000)
    
    def human_readable(self, max_units: int = 2) -> str:
        """Format as human-readable string."""
        parts = []
        
        if self.days:
            parts.append(f"{self.days} day{'s' if self.days != 1 else ''}")
        if self.hours:
            parts.append(f"{self.hours} hour{'s' if self.hours != 1 else ''}")
        if self.minutes:
            parts.append(f"{self.minutes} minute{'s' if self.minutes != 1 else ''}")
        if self.seconds and len(parts) < max_units:
            parts.append(f"{self.seconds} second{'s' if self.seconds != 1 else ''}")
        
        if not parts:
            return "0 seconds"
        
        return ", ".join(parts[:max_units])
    
    def to_timedelta(self) -> timedelta:
        """Convert to timedelta."""
        return timedelta(seconds=self.total_seconds)


@dataclass
class RelativeTime:
    """Relative time description."""
    text: str
    direction: str  # 'past' or 'future'
    duration: Duration
    reference: datetime


class DateTimeTools:
    """
    Comprehensive date and time toolkit.
    
    Provides:
    - Date/time parsing and formatting
    - Timezone conversions
    - Duration calculations
    - Relative time formatting
    - Calendar utilities
    """
    
    def __init__(self, default_timezone: str = "UTC"):
        self.default_timezone = default_timezone
        
        # Common format patterns for parsing
        self._parse_formats = [
            "%Y-%m-%dT%H:%M:%S.%f%z",
            "%Y-%m-%dT%H:%M:%S%z",
            "%Y-%m-%dT%H:%M:%S.%f",
            "%Y-%m-%dT%H:%M:%S",
            "%Y-%m-%d %H:%M:%S.%f",
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%d",
            "%d/%m/%Y %H:%M:%S",
            "%d/%m/%Y",
            "%m/%d/%Y %H:%M:%S",
            "%m/%d/%Y",
            "%d-%m-%Y",
            "%B %d, %Y",
            "%b %d, %Y",
            "%Y%m%d%H%M%S",
            "%Y%m%d",
        ]
        
        # Relative time thresholds
        self._relative_thresholds = [
            (60, "second"),
            (3600, "minute"),
            (86400, "hour"),
            (604800, "day"),
            (2592000, "week"),
            (31536000, "month"),
            (float('inf'), "year"),
        ]
        
        logger.info("DateTimeTools initialized")
    
    # ─────────────────────────────────────────────────────────────────────
    # CURRENT TIME
    # ─────────────────────────────────────────────────────────────────────
    
    async def now(self, tz: Optional[str] = None) -> datetime:
        """Get current datetime."""
        if tz:
            return datetime.now(self._get_timezone(tz))
        return datetime.now(timezone.utc)
    
    async def today(self, tz: Optional[str] = None) -> date:
        """Get current date."""
        now = await self.now(tz)
        return now.date()
    
    async def utc_now(self) -> datetime:
        """Get current UTC datetime."""
        return datetime.now(timezone.utc)
    
    async def timestamp(self) -> float:
        """Get current Unix timestamp."""
        return time_module.time()
    
    async def timestamp_ms(self) -> int:
        """Get current Unix timestamp in milliseconds."""
        return int(time_module.time() * 1000)
    
    # ─────────────────────────────────────────────────────────────────────
    # PARSING
    # ─────────────────────────────────────────────────────────────────────
    
    async def parse(
        self,
        date_string: str,
        format: Optional[str] = None,
        timezone: Optional[str] = None
    ) -> datetime:
        """
        Parse a date string into datetime.
        
        Args:
            date_string: String to parse
            format: Optional strptime format
            timezone: Timezone to assume if not in string
        
        Returns:
            Parsed datetime
        """
        date_string = date_string.strip()
        
        # Handle Unix timestamp
        if date_string.isdigit() or (date_string.startswith('-') and date_string[1:].isdigit()):
            ts = int(date_string)
            # Detect milliseconds vs seconds
            if ts > 1e12:
                ts = ts / 1000
            return datetime.fromtimestamp(ts, tz=timezone.utc)
        
        # Try specific format first
        if format:
            try:
                dt = datetime.strptime(date_string, format)
                if timezone and dt.tzinfo is None:
                    dt = dt.replace(tzinfo=self._get_timezone(timezone))
                return dt
            except ValueError:
                pass
        
        # Try dateutil if available (most flexible)
        if DATEUTIL_AVAILABLE:
            try:
                dt = dateutil_parser.parse(date_string)
                if timezone and dt.tzinfo is None:
                    dt = dt.replace(tzinfo=self._get_timezone(timezone))
                return dt
            except Exception:
                pass
        
        # Try common formats
        for fmt in self._parse_formats:
            try:
                dt = datetime.strptime(date_string, fmt)
                if timezone and dt.tzinfo is None:
                    dt = dt.replace(tzinfo=self._get_timezone(timezone))
                return dt
            except ValueError:
                continue
        
        raise ValueError(f"Unable to parse date: {date_string}")
    
    async def parse_relative(self, text: str, reference: datetime = None) -> datetime:
        """
        Parse relative time expressions.
        
        Examples:
        - "5 minutes ago"
        - "in 2 hours"
        - "next week"
        - "yesterday"
        - "tomorrow at 3pm"
        """
        reference = reference or datetime.now(timezone.utc)
        text = text.lower().strip()
        
        # Simple patterns
        if text == "now":
            return reference
        if text == "today":
            return reference.replace(hour=0, minute=0, second=0, microsecond=0)
        if text == "yesterday":
            return reference - timedelta(days=1)
        if text == "tomorrow":
            return reference + timedelta(days=1)
        
        # "X units ago" or "in X units"
        ago_pattern = r'(\d+)\s*(second|minute|hour|day|week|month|year)s?\s*ago'
        in_pattern = r'in\s*(\d+)\s*(second|minute|hour|day|week|month|year)s?'
        
        ago_match = re.match(ago_pattern, text)
        if ago_match:
            amount = int(ago_match.group(1))
            unit = ago_match.group(2)
            return self._adjust_by_unit(reference, -amount, unit)
        
        in_match = re.match(in_pattern, text)
        if in_match:
            amount = int(in_match.group(1))
            unit = in_match.group(2)
            return self._adjust_by_unit(reference, amount, unit)
        
        # "next/last X"
        next_match = re.match(r'next\s*(monday|tuesday|wednesday|thursday|friday|saturday|sunday|week|month|year)', text)
        if next_match:
            return self._get_next(reference, next_match.group(1))
        
        last_match = re.match(r'last\s*(monday|tuesday|wednesday|thursday|friday|saturday|sunday|week|month|year)', text)
        if last_match:
            return self._get_last(reference, last_match.group(1))
        
        raise ValueError(f"Unable to parse relative time: {text}")
    
    def _adjust_by_unit(self, dt: datetime, amount: int, unit: str) -> datetime:
        """Adjust datetime by amount of unit."""
        if DATEUTIL_AVAILABLE:
            if unit == "year":
                return dt + relativedelta(years=amount)
            elif unit == "month":
                return dt + relativedelta(months=amount)
        
        unit_seconds = {
            "second": 1,
            "minute": 60,
            "hour": 3600,
            "day": 86400,
            "week": 604800,
        }
        
        if unit in unit_seconds:
            return dt + timedelta(seconds=amount * unit_seconds[unit])
        elif unit == "month":
            # Approximate
            return dt + timedelta(days=amount * 30)
        elif unit == "year":
            # Approximate
            return dt + timedelta(days=amount * 365)
        
        return dt
    
    def _get_next(self, dt: datetime, target: str) -> datetime:
        """Get next occurrence of target."""
        weekdays = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
        
        if target in weekdays:
            target_weekday = weekdays.index(target)
            days_ahead = target_weekday - dt.weekday()
            if days_ahead <= 0:
                days_ahead += 7
            return dt + timedelta(days=days_ahead)
        elif target == "week":
            return dt + timedelta(weeks=1)
        elif target == "month":
            if DATEUTIL_AVAILABLE:
                return dt + relativedelta(months=1)
            return dt + timedelta(days=30)
        elif target == "year":
            if DATEUTIL_AVAILABLE:
                return dt + relativedelta(years=1)
            return dt + timedelta(days=365)
        
        return dt
    
    def _get_last(self, dt: datetime, target: str) -> datetime:
        """Get last occurrence of target."""
        weekdays = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
        
        if target in weekdays:
            target_weekday = weekdays.index(target)
            days_behind = dt.weekday() - target_weekday
            if days_behind <= 0:
                days_behind += 7
            return dt - timedelta(days=days_behind)
        elif target == "week":
            return dt - timedelta(weeks=1)
        elif target == "month":
            if DATEUTIL_AVAILABLE:
                return dt - relativedelta(months=1)
            return dt - timedelta(days=30)
        elif target == "year":
            if DATEUTIL_AVAILABLE:
                return dt - relativedelta(years=1)
            return dt - timedelta(days=365)
        
        return dt
    
    # ─────────────────────────────────────────────────────────────────────
    # FORMATTING
    # ─────────────────────────────────────────────────────────────────────
    
    async def format(
        self,
        dt: Union[datetime, date, str],
        format: Union[DateFormat, str] = DateFormat.ISO
    ) -> str:
        """
        Format datetime as string.
        
        Args:
            dt: Datetime to format
            format: Output format
        
        Returns:
            Formatted string
        """
        # Parse if string
        if isinstance(dt, str):
            dt = await self.parse(dt)
        
        # Get format string
        if isinstance(format, DateFormat):
            if format == DateFormat.UNIX:
                return str(int(dt.timestamp()))
            format_str = format.value
        else:
            format_str = format
        
        return dt.strftime(format_str)
    
    async def format_iso(self, dt: datetime) -> str:
        """Format as ISO 8601."""
        return dt.isoformat()
    
    async def format_relative(
        self,
        dt: Union[datetime, str],
        reference: datetime = None,
        granularity: int = 1
    ) -> RelativeTime:
        """
        Format as relative time.
        
        Args:
            dt: Target datetime
            reference: Reference point (default: now)
            granularity: Number of units to show
        
        Returns:
            RelativeTime with human-readable text
        """
        if isinstance(dt, str):
            dt = await self.parse(dt)
        
        reference = reference or datetime.now(timezone.utc)
        
        # Make both timezone-aware or naive
        if dt.tzinfo is None and reference.tzinfo is not None:
            dt = dt.replace(tzinfo=timezone.utc)
        elif dt.tzinfo is not None and reference.tzinfo is None:
            reference = reference.replace(tzinfo=timezone.utc)
        
        diff = dt - reference
        total_seconds = diff.total_seconds()
        direction = "future" if total_seconds > 0 else "past"
        abs_seconds = abs(total_seconds)
        
        # Determine appropriate unit
        for threshold, unit in self._relative_thresholds:
            if abs_seconds < threshold:
                if unit == "second":
                    amount = int(abs_seconds)
                elif unit == "minute":
                    amount = int(abs_seconds / 60)
                elif unit == "hour":
                    amount = int(abs_seconds / 3600)
                elif unit == "day":
                    amount = int(abs_seconds / 86400)
                elif unit == "week":
                    amount = int(abs_seconds / 604800)
                elif unit == "month":
                    amount = int(abs_seconds / 2592000)
                else:  # year
                    amount = int(abs_seconds / 31536000)
                
                if amount == 0:
                    text = "just now"
                elif direction == "past":
                    text = f"{amount} {unit}{'s' if amount != 1 else ''} ago"
                else:
                    text = f"in {amount} {unit}{'s' if amount != 1 else ''}"
                
                break
        
        return RelativeTime(
            text=text,
            direction=direction,
            duration=Duration(total_seconds=abs_seconds),
            reference=reference
        )
    
    # ─────────────────────────────────────────────────────────────────────
    # TIMEZONE OPERATIONS
    # ─────────────────────────────────────────────────────────────────────
    
    async def convert_timezone(
        self,
        dt: Union[datetime, str],
        target_tz: str,
        source_tz: Optional[str] = None
    ) -> datetime:
        """Convert datetime to different timezone."""
        if isinstance(dt, str):
            dt = await self.parse(dt)
        
        # Ensure source timezone
        if dt.tzinfo is None:
            source = self._get_timezone(source_tz or self.default_timezone)
            dt = dt.replace(tzinfo=source)
        
        # Convert to target
        target = self._get_timezone(target_tz)
        return dt.astimezone(target)
    
    async def to_utc(self, dt: Union[datetime, str]) -> datetime:
        """Convert to UTC."""
        return await self.convert_timezone(dt, "UTC")
    
    async def to_local(self, dt: Union[datetime, str]) -> datetime:
        """Convert to local timezone."""
        if isinstance(dt, str):
            dt = await self.parse(dt)
        return dt.astimezone()
    
    def _get_timezone(self, tz_name: str):
        """Get timezone object from name."""
        if tz_name.upper() == "UTC":
            return timezone.utc
        
        if PYTZ_AVAILABLE:
            try:
                return pytz.timezone(tz_name)
            except Exception:
                pass
        
        # Try to parse as offset
        offset_match = re.match(r'([+-])(\d{2}):?(\d{2})?', tz_name)
        if offset_match:
            sign = 1 if offset_match.group(1) == '+' else -1
            hours = int(offset_match.group(2))
            minutes = int(offset_match.group(3) or 0)
            return timezone(timedelta(hours=sign * hours, minutes=sign * minutes))
        
        return timezone.utc
    
    async def list_timezones(self, filter: Optional[str] = None) -> List[str]:
        """List available timezones."""
        if PYTZ_AVAILABLE:
            zones = list(pytz.all_timezones)
            if filter:
                filter_lower = filter.lower()
                zones = [z for z in zones if filter_lower in z.lower()]
            return sorted(zones)
        
        return ["UTC"]
    
    # ─────────────────────────────────────────────────────────────────────
    # DURATION CALCULATIONS
    # ─────────────────────────────────────────────────────────────────────
    
    async def diff(
        self,
        dt1: Union[datetime, str],
        dt2: Union[datetime, str]
    ) -> Duration:
        """Calculate duration between two datetimes."""
        if isinstance(dt1, str):
            dt1 = await self.parse(dt1)
        if isinstance(dt2, str):
            dt2 = await self.parse(dt2)
        
        delta = dt2 - dt1
        return Duration(total_seconds=delta.total_seconds())
    
    async def add(
        self,
        dt: Union[datetime, str],
        amount: int,
        unit: TimeUnit
    ) -> datetime:
        """Add time to datetime."""
        if isinstance(dt, str):
            dt = await self.parse(dt)
        
        return self._adjust_by_unit(dt, amount, unit.value)
    
    async def subtract(
        self,
        dt: Union[datetime, str],
        amount: int,
        unit: TimeUnit
    ) -> datetime:
        """Subtract time from datetime."""
        return await self.add(dt, -amount, unit)
    
    # ─────────────────────────────────────────────────────────────────────
    # DATE INFO
    # ─────────────────────────────────────────────────────────────────────
    
    async def info(self, dt: Union[datetime, str] = None) -> DateTimeInfo:
        """Get detailed information about a datetime."""
        if dt is None:
            dt = datetime.now(timezone.utc)
        elif isinstance(dt, str):
            dt = await self.parse(dt)
        
        weekday_names = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        month_names = ['', 'January', 'February', 'March', 'April', 'May', 'June',
                      'July', 'August', 'September', 'October', 'November', 'December']
        
        return DateTimeInfo(
            datetime=dt,
            date=dt.date(),
            time=dt.time(),
            year=dt.year,
            month=dt.month,
            day=dt.day,
            hour=dt.hour,
            minute=dt.minute,
            second=dt.second,
            microsecond=dt.microsecond,
            weekday=dt.weekday(),
            weekday_name=weekday_names[dt.weekday()],
            month_name=month_names[dt.month],
            iso_week=dt.isocalendar()[1],
            day_of_year=dt.timetuple().tm_yday,
            is_weekend=dt.weekday() >= 5,
            is_leap_year=calendar.isleap(dt.year),
            quarter=(dt.month - 1) // 3 + 1,
            timezone=str(dt.tzinfo) if dt.tzinfo else None,
            utc_offset=dt.strftime('%z') if dt.tzinfo else None,
            unix_timestamp=dt.timestamp() if dt.tzinfo else 0,
            iso_format=dt.isoformat()
        )
    
    # ─────────────────────────────────────────────────────────────────────
    # CALENDAR UTILITIES
    # ─────────────────────────────────────────────────────────────────────
    
    async def days_in_month(self, year: int, month: int) -> int:
        """Get number of days in a month."""
        return calendar.monthrange(year, month)[1]
    
    async def is_leap_year(self, year: int) -> bool:
        """Check if year is a leap year."""
        return calendar.isleap(year)
    
    async def start_of(
        self,
        dt: Union[datetime, str],
        unit: TimeUnit
    ) -> datetime:
        """Get start of a time unit."""
        if isinstance(dt, str):
            dt = await self.parse(dt)
        
        if unit == TimeUnit.DAY:
            return dt.replace(hour=0, minute=0, second=0, microsecond=0)
        elif unit == TimeUnit.WEEK:
            days_since_monday = dt.weekday()
            start = dt - timedelta(days=days_since_monday)
            return start.replace(hour=0, minute=0, second=0, microsecond=0)
        elif unit == TimeUnit.MONTH:
            return dt.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        elif unit == TimeUnit.YEAR:
            return dt.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0)
        elif unit == TimeUnit.HOUR:
            return dt.replace(minute=0, second=0, microsecond=0)
        elif unit == TimeUnit.MINUTE:
            return dt.replace(second=0, microsecond=0)
        
        return dt
    
    async def end_of(
        self,
        dt: Union[datetime, str],
        unit: TimeUnit
    ) -> datetime:
        """Get end of a time unit."""
        if isinstance(dt, str):
            dt = await self.parse(dt)
        
        if unit == TimeUnit.DAY:
            return dt.replace(hour=23, minute=59, second=59, microsecond=999999)
        elif unit == TimeUnit.WEEK:
            days_until_sunday = 6 - dt.weekday()
            end = dt + timedelta(days=days_until_sunday)
            return end.replace(hour=23, minute=59, second=59, microsecond=999999)
        elif unit == TimeUnit.MONTH:
            last_day = calendar.monthrange(dt.year, dt.month)[1]
            return dt.replace(day=last_day, hour=23, minute=59, second=59, microsecond=999999)
        elif unit == TimeUnit.YEAR:
            return dt.replace(month=12, day=31, hour=23, minute=59, second=59, microsecond=999999)
        elif unit == TimeUnit.HOUR:
            return dt.replace(minute=59, second=59, microsecond=999999)
        elif unit == TimeUnit.MINUTE:
            return dt.replace(second=59, microsecond=999999)
        
        return dt
    
    async def range(
        self,
        start: Union[datetime, str],
        end: Union[datetime, str],
        step: TimeUnit = TimeUnit.DAY
    ) -> List[datetime]:
        """Generate datetime range."""
        if isinstance(start, str):
            start = await self.parse(start)
        if isinstance(end, str):
            end = await self.parse(end)
        
        result = []
        current = start
        
        step_delta = {
            TimeUnit.SECOND: timedelta(seconds=1),
            TimeUnit.MINUTE: timedelta(minutes=1),
            TimeUnit.HOUR: timedelta(hours=1),
            TimeUnit.DAY: timedelta(days=1),
            TimeUnit.WEEK: timedelta(weeks=1),
        }
        
        delta = step_delta.get(step, timedelta(days=1))
        
        while current <= end:
            result.append(current)
            current = current + delta
        
        return result


# Singleton instance
_datetime_tools: Optional[DateTimeTools] = None


def get_datetime_tools() -> DateTimeTools:
    """Get or create datetime tools singleton."""
    global _datetime_tools
    if _datetime_tools is None:
        _datetime_tools = DateTimeTools()
    return _datetime_tools


# Convenience functions
async def now() -> datetime:
    """Get current UTC datetime."""
    tools = get_datetime_tools()
    return await tools.utc_now()


async def parse_date(date_string: str) -> datetime:
    """Parse date string."""
    tools = get_datetime_tools()
    return await tools.parse(date_string)


async def format_date(dt: datetime, format: str = "%Y-%m-%d %H:%M:%S") -> str:
    """Format datetime."""
    tools = get_datetime_tools()
    return await tools.format(dt, format)


async def time_ago(dt: datetime) -> str:
    """Get relative time string."""
    tools = get_datetime_tools()
    result = await tools.format_relative(dt)
    return result.text


async def timestamp() -> float:
    """Get current Unix timestamp."""
    tools = get_datetime_tools()
    return await tools.timestamp()