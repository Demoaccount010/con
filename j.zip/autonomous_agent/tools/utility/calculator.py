"""
═══════════════════════════════════════════════════════════════════════════════════════
CALCULATOR - MATHEMATICAL COMPUTATION ENGINE
═══════════════════════════════════════════════════════════════════════════════════════
Comprehensive calculation capabilities:
- Basic arithmetic
- Scientific functions
- Unit conversions
- Financial calculations
- Statistical functions
- Expression evaluation
- Equation solving
- Safe math evaluation
"""

import asyncio
import logging
import math
import cmath
import re
import ast
import operator
from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Union, Tuple, Callable
from fractions import Fraction
import statistics

logger = logging.getLogger(__name__)

# Try to import optional libraries
try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False


class AngleUnit(Enum):
    """Angle measurement units."""
    RADIAN = "radian"
    DEGREE = "degree"
    GRADIAN = "gradian"


class NumberFormat(Enum):
    """Number display formats."""
    DECIMAL = "decimal"
    SCIENTIFIC = "scientific"
    ENGINEERING = "engineering"
    FRACTION = "fraction"
    PERCENTAGE = "percentage"
    BINARY = "binary"
    OCTAL = "octal"
    HEXADECIMAL = "hexadecimal"


@dataclass
class CalculationResult:
    """Result of a calculation."""
    expression: str
    result: Any
    result_type: str
    formatted: str
    steps: List[str] = field(default_factory=list)
    precision: int = 10
    timestamp: datetime = field(default_factory=datetime.now)
    error: Optional[str] = None
    
    @property
    def success(self) -> bool:
        return self.error is None


@dataclass
class ConversionResult:
    """Result of unit conversion."""
    value: float
    from_unit: str
    to_unit: str
    result: float
    formula: str


class SafeEvaluator:
    """
    Safe mathematical expression evaluator.
    
    Only allows safe operations, no code execution.
    """
    
    # Allowed operators
    OPERATORS = {
        ast.Add: operator.add,
        ast.Sub: operator.sub,
        ast.Mult: operator.mul,
        ast.Div: operator.truediv,
        ast.FloorDiv: operator.floordiv,
        ast.Mod: operator.mod,
        ast.Pow: operator.pow,
        ast.USub: operator.neg,
        ast.UAdd: operator.pos,
        ast.BitXor: operator.xor,  # For power (^)
    }
    
    # Allowed functions
    FUNCTIONS = {
        # Basic
        'abs': abs,
        'round': round,
        'min': min,
        'max': max,
        'sum': sum,
        'int': int,
        'float': float,
        
        # Math functions
        'sqrt': math.sqrt,
        'cbrt': lambda x: x ** (1/3),
        'pow': pow,
        'exp': math.exp,
        'log': math.log,
        'log10': math.log10,
        'log2': math.log2,
        'ln': math.log,
        
        # Trigonometric
        'sin': math.sin,
        'cos': math.cos,
        'tan': math.tan,
        'asin': math.asin,
        'acos': math.acos,
        'atan': math.atan,
        'atan2': math.atan2,
        'sinh': math.sinh,
        'cosh': math.cosh,
        'tanh': math.tanh,
        
        # Angular
        'radians': math.radians,
        'degrees': math.degrees,
        
        # Other
        'factorial': math.factorial,
        'gcd': math.gcd,
        'lcm': lambda a, b: abs(a * b) // math.gcd(a, b),
        'ceil': math.ceil,
        'floor': math.floor,
        'trunc': math.trunc,
        'fabs': math.fabs,
        
        # Statistical
        'mean': statistics.mean,
        'median': statistics.median,
        'stdev': statistics.stdev,
        'variance': statistics.variance,
    }
    
    # Constants
    CONSTANTS = {
        'pi': math.pi,
        'e': math.e,
        'tau': math.tau,
        'inf': float('inf'),
        'nan': float('nan'),
        'phi': (1 + math.sqrt(5)) / 2,  # Golden ratio
    }
    
    def __init__(self):
        self._angle_unit = AngleUnit.RADIAN
    
    def evaluate(self, expression: str) -> Tuple[Any, List[str]]:
        """
        Safely evaluate a mathematical expression.
        
        Returns:
            Tuple of (result, steps)
        """
        steps = []
        
        # Preprocess expression
        expr = self._preprocess(expression)
        steps.append(f"Preprocessed: {expr}")
        
        try:
            # Parse to AST
            tree = ast.parse(expr, mode='eval')
            
            # Evaluate
            result = self._eval_node(tree.body)
            
            return result, steps
            
        except Exception as e:
            raise ValueError(f"Evaluation error: {e}")
    
    def _preprocess(self, expr: str) -> str:
        """Preprocess expression for parsing."""
        # Replace ^ with ** for power
        expr = expr.replace('^', '**')
        
        # Replace × and ÷ with * and /
        expr = expr.replace('×', '*').replace('÷', '/')
        
        # Handle implicit multiplication: 2(3) -> 2*(3), 2pi -> 2*pi
        expr = re.sub(r'(\d)([a-zA-Z(])', r'\1*\2', expr)
        expr = re.sub(r'(\))(\d)', r'\1*\2', expr)
        expr = re.sub(r'(\))([a-zA-Z(])', r'\1*\2', expr)
        
        # Replace constant names
        for name, value in self.CONSTANTS.items():
            expr = re.sub(rf'\b{name}\b', str(value), expr, flags=re.IGNORECASE)
        
        return expr
    
    def _eval_node(self, node):
        """Recursively evaluate AST node."""
        if isinstance(node, ast.Constant):
            return node.value
        
        elif isinstance(node, ast.Num):  # Python 3.7 compatibility
            return node.n
        
        elif isinstance(node, ast.Name):
            name = node.id.lower()
            if name in self.CONSTANTS:
                return self.CONSTANTS[name]
            raise ValueError(f"Unknown variable: {node.id}")
        
        elif isinstance(node, ast.BinOp):
            left = self._eval_node(node.left)
            right = self._eval_node(node.right)
            op = self.OPERATORS.get(type(node.op))
            if op is None:
                raise ValueError(f"Unsupported operator: {type(node.op).__name__}")
            return op(left, right)
        
        elif isinstance(node, ast.UnaryOp):
            operand = self._eval_node(node.operand)
            op = self.OPERATORS.get(type(node.op))
            if op is None:
                raise ValueError(f"Unsupported unary operator: {type(node.op).__name__}")
            return op(operand)
        
        elif isinstance(node, ast.Call):
            func_name = node.func.id if isinstance(node.func, ast.Name) else None
            if func_name is None or func_name.lower() not in self.FUNCTIONS:
                raise ValueError(f"Unknown function: {func_name}")
            
            func = self.FUNCTIONS[func_name.lower()]
            args = [self._eval_node(arg) for arg in node.args]
            
            return func(*args)
        
        elif isinstance(node, ast.List):
            return [self._eval_node(elem) for elem in node.elts]
        
        elif isinstance(node, ast.Tuple):
            return tuple(self._eval_node(elem) for elem in node.elts)
        
        else:
            raise ValueError(f"Unsupported expression type: {type(node).__name__}")
    
    def set_angle_unit(self, unit: AngleUnit):
        """Set angle unit for trig functions."""
        self._angle_unit = unit


class UnitConverter:
    """Unit conversion engine."""
    
    # Conversion factors to base unit
    CONVERSIONS = {
        # Length (base: meter)
        'length': {
            'm': 1.0,
            'meter': 1.0,
            'km': 1000.0,
            'kilometer': 1000.0,
            'cm': 0.01,
            'centimeter': 0.01,
            'mm': 0.001,
            'millimeter': 0.001,
            'mi': 1609.344,
            'mile': 1609.344,
            'yd': 0.9144,
            'yard': 0.9144,
            'ft': 0.3048,
            'foot': 0.3048,
            'feet': 0.3048,
            'in': 0.0254,
            'inch': 0.0254,
            'nm': 1852.0,
            'nautical_mile': 1852.0,
            'um': 1e-6,
            'micrometer': 1e-6,
            'nm_nano': 1e-9,
            'nanometer': 1e-9,
            'ly': 9.461e15,
            'light_year': 9.461e15,
        },
        
        # Mass (base: kilogram)
        'mass': {
            'kg': 1.0,
            'kilogram': 1.0,
            'g': 0.001,
            'gram': 0.001,
            'mg': 1e-6,
            'milligram': 1e-6,
            'lb': 0.453592,
            'pound': 0.453592,
            'oz': 0.0283495,
            'ounce': 0.0283495,
            'ton': 1000.0,
            'tonne': 1000.0,
            'st': 6.35029,
            'stone': 6.35029,
        },
        
        # Temperature (special handling)
        'temperature': {
            'c': 'celsius',
            'celsius': 'celsius',
            'f': 'fahrenheit',
            'fahrenheit': 'fahrenheit',
            'k': 'kelvin',
            'kelvin': 'kelvin',
        },
        
        # Time (base: second)
        'time': {
            's': 1.0,
            'second': 1.0,
            'ms': 0.001,
            'millisecond': 0.001,
            'us': 1e-6,
            'microsecond': 1e-6,
            'ns': 1e-9,
            'nanosecond': 1e-9,
            'min': 60.0,
            'minute': 60.0,
            'h': 3600.0,
            'hour': 3600.0,
            'day': 86400.0,
            'week': 604800.0,
            'month': 2592000.0,  # 30 days
            'year': 31536000.0,  # 365 days
        },
        
        # Data (base: byte)
        'data': {
            'b': 1.0,
            'byte': 1.0,
            'kb': 1024.0,
            'kilobyte': 1024.0,
            'mb': 1048576.0,
            'megabyte': 1048576.0,
            'gb': 1073741824.0,
            'gigabyte': 1073741824.0,
            'tb': 1099511627776.0,
            'terabyte': 1099511627776.0,
            'pb': 1125899906842624.0,
            'petabyte': 1125899906842624.0,
            'bit': 0.125,
            'kbit': 128.0,
            'mbit': 131072.0,
            'gbit': 134217728.0,
        },
        
        # Speed (base: m/s)
        'speed': {
            'm/s': 1.0,
            'mps': 1.0,
            'km/h': 0.277778,
            'kph': 0.277778,
            'mph': 0.44704,
            'ft/s': 0.3048,
            'knot': 0.514444,
            'c': 299792458.0,  # speed of light
            'mach': 343.0,
        },
        
        # Area (base: square meter)
        'area': {
            'm2': 1.0,
            'sqm': 1.0,
            'km2': 1e6,
            'cm2': 1e-4,
            'mm2': 1e-6,
            'ha': 10000.0,
            'hectare': 10000.0,
            'acre': 4046.86,
            'sqft': 0.092903,
            'sqmi': 2.59e6,
            'sqyd': 0.836127,
        },
        
        # Volume (base: liter)
        'volume': {
            'l': 1.0,
            'liter': 1.0,
            'ml': 0.001,
            'milliliter': 0.001,
            'cl': 0.01,
            'centiliter': 0.01,
            'gal': 3.78541,
            'gallon': 3.78541,
            'qt': 0.946353,
            'quart': 0.946353,
            'pt': 0.473176,
            'pint': 0.473176,
            'cup': 0.236588,
            'floz': 0.0295735,
            'm3': 1000.0,
            'cm3': 0.001,
            'mm3': 1e-6,
        },
        
        # Angle (base: radian)
        'angle': {
            'rad': 1.0,
            'radian': 1.0,
            'deg': math.pi / 180,
            'degree': math.pi / 180,
            'grad': math.pi / 200,
            'gradian': math.pi / 200,
            'turn': 2 * math.pi,
            'arcmin': math.pi / 10800,
            'arcsec': math.pi / 648000,
        },
        
        # Pressure (base: pascal)
        'pressure': {
            'pa': 1.0,
            'pascal': 1.0,
            'kpa': 1000.0,
            'bar': 100000.0,
            'atm': 101325.0,
            'psi': 6894.76,
            'mmhg': 133.322,
            'torr': 133.322,
        },
        
        # Energy (base: joule)
        'energy': {
            'j': 1.0,
            'joule': 1.0,
            'kj': 1000.0,
            'cal': 4.184,
            'calorie': 4.184,
            'kcal': 4184.0,
            'kilocalorie': 4184.0,
            'wh': 3600.0,
            'kwh': 3600000.0,
            'ev': 1.602e-19,
            'btu': 1055.06,
        },
    }
    
    def convert(
        self,
        value: float,
        from_unit: str,
        to_unit: str
    ) -> ConversionResult:
        """Convert between units."""
        from_unit = from_unit.lower().strip()
        to_unit = to_unit.lower().strip()
        
        # Find category
        category = None
        for cat, units in self.CONVERSIONS.items():
            if from_unit in units and to_unit in units:
                category = cat
                break
        
        if category is None:
            raise ValueError(f"Cannot convert between {from_unit} and {to_unit}")
        
        # Special handling for temperature
        if category == 'temperature':
            result = self._convert_temperature(value, from_unit, to_unit)
            formula = f"{value} {from_unit} = {result} {to_unit}"
        else:
            # Standard conversion through base unit
            units = self.CONVERSIONS[category]
            base_value = value * units[from_unit]
            result = base_value / units[to_unit]
            formula = f"{value} × {units[from_unit]} ÷ {units[to_unit]} = {result}"
        
        return ConversionResult(
            value=value,
            from_unit=from_unit,
            to_unit=to_unit,
            result=result,
            formula=formula
        )
    
    def _convert_temperature(
        self,
        value: float,
        from_unit: str,
        to_unit: str
    ) -> float:
        """Convert temperature."""
        # Normalize unit names
        units = self.CONVERSIONS['temperature']
        from_type = units.get(from_unit, from_unit)
        to_type = units.get(to_unit, to_unit)
        
        # Convert to Celsius first
        if from_type == 'celsius':
            celsius = value
        elif from_type == 'fahrenheit':
            celsius = (value - 32) * 5/9
        elif from_type == 'kelvin':
            celsius = value - 273.15
        else:
            raise ValueError(f"Unknown temperature unit: {from_unit}")
        
        # Convert from Celsius to target
        if to_type == 'celsius':
            return celsius
        elif to_type == 'fahrenheit':
            return celsius * 9/5 + 32
        elif to_type == 'kelvin':
            return celsius + 273.15
        else:
            raise ValueError(f"Unknown temperature unit: {to_unit}")
    
    def list_units(self, category: Optional[str] = None) -> Dict[str, List[str]]:
        """List available units."""
        if category:
            return {category: list(self.CONVERSIONS.get(category, {}).keys())}
        return {cat: list(units.keys()) for cat, units in self.CONVERSIONS.items()}


class Calculator:
    """
    Full-featured calculator.
    
    Provides:
    - Safe expression evaluation
    - Unit conversions
    - Financial calculations
    - Statistical functions
    - Precision control
    """
    
    def __init__(self, precision: int = 10):
        self.precision = precision
        self.evaluator = SafeEvaluator()
        self.converter = UnitConverter()
        
        # History
        self._history: List[CalculationResult] = []
        self._max_history = 100
        
        # Memory
        self._memory: Dict[str, Any] = {}
        
        logger.info("Calculator initialized")
    
    # ─────────────────────────────────────────────────────────────────────
    # BASIC CALCULATIONS
    # ─────────────────────────────────────────────────────────────────────
    
    async def calculate(
        self,
        expression: str,
        precision: Optional[int] = None
    ) -> CalculationResult:
        """
        Evaluate a mathematical expression.
        
        Args:
            expression: Mathematical expression
            precision: Decimal precision
        
        Returns:
            CalculationResult
        """
        precision = precision or self.precision
        
        try:
            result, steps = self.evaluator.evaluate(expression)
            
            # Format result
            if isinstance(result, float):
                if result.is_integer():
                    formatted = str(int(result))
                else:
                    formatted = f"{result:.{precision}g}"
                result_type = "float"
            elif isinstance(result, complex):
                formatted = f"{result.real:.{precision}g} + {result.imag:.{precision}g}i"
                result_type = "complex"
            elif isinstance(result, (list, tuple)):
                formatted = str(result)
                result_type = "array"
            else:
                formatted = str(result)
                result_type = type(result).__name__
            
            calc_result = CalculationResult(
                expression=expression,
                result=result,
                result_type=result_type,
                formatted=formatted,
                steps=steps,
                precision=precision
            )
            
            self._add_to_history(calc_result)
            return calc_result
            
        except Exception as e:
            return CalculationResult(
                expression=expression,
                result=None,
                result_type="error",
                formatted="Error",
                error=str(e)
            )
    
    async def evaluate(self, expression: str) -> float:
        """Quick evaluation returning just the number."""
        result = await self.calculate(expression)
        if result.error:
            raise ValueError(result.error)
        return result.result
    
    # ─────────────────────────────────────────────────────────────────────
    # UNIT CONVERSION
    # ─────────────────────────────────────────────────────────────────────
    
    async def convert(
        self,
        value: float,
        from_unit: str,
        to_unit: str
    ) -> ConversionResult:
        """Convert between units."""
        return self.converter.convert(value, from_unit, to_unit)
    
    async def convert_expression(self, expression: str) -> ConversionResult:
        """
        Parse and convert expression like "100 km to mi".
        """
        # Pattern: value from_unit to to_unit
        patterns = [
            r'([\d.]+)\s*(\w+)\s+(?:to|in|as)\s+(\w+)',
            r'([\d.]+)\s*(\w+)\s*=\s*\?\s*(\w+)',
            r'convert\s+([\d.]+)\s*(\w+)\s+to\s+(\w+)',
        ]
        
        for pattern in patterns:
            match = re.match(pattern, expression, re.IGNORECASE)
            if match:
                value = float(match.group(1))
                from_unit = match.group(2)
                to_unit = match.group(3)
                return await self.convert(value, from_unit, to_unit)
        
        raise ValueError(f"Cannot parse conversion: {expression}")
    
    # ─────────────────────────────────────────────────────────────────────
    # FINANCIAL CALCULATIONS
    # ─────────────────────────────────────────────────────────────────────
    
    async def compound_interest(
        self,
        principal: float,
        rate: float,
        time_years: float,
        n: int = 12  # Compounding frequency
    ) -> Dict[str, float]:
        """Calculate compound interest."""
        amount = principal * (1 + rate/n) ** (n * time_years)
        interest = amount - principal
        
        return {
            "principal": principal,
            "rate": rate,
            "time_years": time_years,
            "compound_frequency": n,
            "final_amount": round(amount, 2),
            "interest_earned": round(interest, 2),
            "effective_rate": round((amount/principal - 1) * 100, 2)
        }
    
    async def loan_payment(
        self,
        principal: float,
        annual_rate: float,
        years: int
    ) -> Dict[str, float]:
        """Calculate monthly loan payment."""
        monthly_rate = annual_rate / 12
        num_payments = years * 12
        
        if monthly_rate == 0:
            payment = principal / num_payments
        else:
            payment = principal * (
                monthly_rate * (1 + monthly_rate)**num_payments
            ) / (
                (1 + monthly_rate)**num_payments - 1
            )
        
        total_paid = payment * num_payments
        total_interest = total_paid - principal
        
        return {
            "principal": principal,
            "annual_rate": annual_rate,
            "years": years,
            "monthly_payment": round(payment, 2),
            "total_paid": round(total_paid, 2),
            "total_interest": round(total_interest, 2)
        }
    
    async def percentage(
        self,
        operation: str,
        value: float,
        percent: float
    ) -> float:
        """
        Percentage calculations.
        
        Operations:
        - 'of': what is X% of Y
        - 'add': add X% to Y
        - 'subtract': subtract X% from Y
        - 'change': percent change from X to Y
        """
        if operation == 'of':
            return value * (percent / 100)
        elif operation == 'add':
            return value * (1 + percent / 100)
        elif operation == 'subtract':
            return value * (1 - percent / 100)
        elif operation == 'change':
            return ((percent - value) / value) * 100
        else:
            raise ValueError(f"Unknown operation: {operation}")
    
    # ─────────────────────────────────────────────────────────────────────
    # STATISTICS
    # ─────────────────────────────────────────────────────────────────────
    
    async def statistics(self, values: List[float]) -> Dict[str, float]:
        """Calculate statistics for a list of values."""
        if not values:
            raise ValueError("Empty list")
        
        n = len(values)
        sorted_values = sorted(values)
        
        result = {
            "count": n,
            "sum": sum(values),
            "mean": statistics.mean(values),
            "median": statistics.median(values),
            "min": min(values),
            "max": max(values),
            "range": max(values) - min(values),
        }
        
        if n >= 2:
            result["stdev"] = statistics.stdev(values)
            result["variance"] = statistics.variance(values)
        
        # Mode (most common)
        try:
            result["mode"] = statistics.mode(values)
        except statistics.StatisticsError:
            result["mode"] = None
        
        # Quartiles
        if n >= 4:
            q1_idx = n // 4
            q3_idx = 3 * n // 4
            result["q1"] = sorted_values[q1_idx]
            result["q3"] = sorted_values[q3_idx]
            result["iqr"] = result["q3"] - result["q1"]
        
        return result
    
    # ─────────────────────────────────────────────────────────────────────
    # NUMBER FORMATTING
    # ─────────────────────────────────────────────────────────────────────
    
    async def format_number(
        self,
        value: float,
        format: NumberFormat = NumberFormat.DECIMAL,
        precision: int = None
    ) -> str:
        """Format number in different representations."""
        precision = precision or self.precision
        
        if format == NumberFormat.DECIMAL:
            return f"{value:.{precision}g}"
        elif format == NumberFormat.SCIENTIFIC:
            return f"{value:.{precision}e}"
        elif format == NumberFormat.ENGINEERING:
            exp = int(math.floor(math.log10(abs(value)) / 3) * 3) if value != 0 else 0
            mantissa = value / (10 ** exp)
            return f"{mantissa:.{precision}g}e{exp:+d}"
        elif format == NumberFormat.FRACTION:
            frac = Fraction(value).limit_denominator(1000)
            return str(frac)
        elif format == NumberFormat.PERCENTAGE:
            return f"{value * 100:.{precision}g}%"
        elif format == NumberFormat.BINARY:
            return bin(int(value))
        elif format == NumberFormat.OCTAL:
            return oct(int(value))
        elif format == NumberFormat.HEXADECIMAL:
            return hex(int(value))
        else:
            return str(value)
    
    # ─────────────────────────────────────────────────────────────────────
    # MEMORY
    # ─────────────────────────────────────────────────────────────────────
    
    async def store(self, name: str, value: Any) -> None:
        """Store value in memory."""
        self._memory[name] = value
    
    async def recall(self, name: str) -> Any:
        """Recall value from memory."""
        return self._memory.get(name)
    
    async def clear_memory(self) -> None:
        """Clear all memory."""
        self._memory.clear()
    
    # ─────────────────────────────────────────────────────────────────────
    # HISTORY
    # ─────────────────────────────────────────────────────────────────────
    
    def _add_to_history(self, result: CalculationResult) -> None:
        """Add result to history."""
        self._history.append(result)
        if len(self._history) > self._max_history:
            self._history = self._history[-self._max_history:]
    
    async def get_history(self, limit: int = 10) -> List[CalculationResult]:
        """Get calculation history."""
        return list(reversed(self._history[-limit:]))
    
    async def clear_history(self) -> None:
        """Clear history."""
        self._history.clear()
    
    # ─────────────────────────────────────────────────────────────────────
    # UTILITIES
    # ─────────────────────────────────────────────────────────────────────
    
    async def gcd(self, a: int, b: int) -> int:
        """Greatest common divisor."""
        return math.gcd(a, b)
    
    async def lcm(self, a: int, b: int) -> int:
        """Least common multiple."""
        return abs(a * b) // math.gcd(a, b)
    
    async def factorial(self, n: int) -> int:
        """Calculate factorial."""
        return math.factorial(n)
    
    async def is_prime(self, n: int) -> bool:
        """Check if number is prime."""
        if n < 2:
            return False
        if n == 2:
            return True
        if n % 2 == 0:
            return False
        for i in range(3, int(math.sqrt(n)) + 1, 2):
            if n % i == 0:
                return False
        return True
    
    async def factors(self, n: int) -> List[int]:
        """Get all factors of a number."""
        result = []
        for i in range(1, int(math.sqrt(n)) + 1):
            if n % i == 0:
                result.append(i)
                if i != n // i:
                    result.append(n // i)
        return sorted(result)
    
    async def prime_factors(self, n: int) -> List[int]:
        """Get prime factorization."""
        factors = []
        d = 2
        while d * d <= n:
            while n % d == 0:
                factors.append(d)
                n //= d
            d += 1
        if n > 1:
            factors.append(n)
        return factors


# Singleton instance
_calculator: Optional[Calculator] = None


def get_calculator() -> Calculator:
    """Get or create calculator singleton."""
    global _calculator
    if _calculator is None:
        _calculator = Calculator()
    return _calculator


# Convenience functions
async def calc(expression: str) -> float:
    """Quick calculation."""
    calculator = get_calculator()
    result = await calculator.calculate(expression)
    if result.error:
        raise ValueError(result.error)
    return result.result


async def convert(value: float, from_unit: str, to_unit: str) -> float:
    """Quick unit conversion."""
    calculator = get_calculator()
    result = await calculator.convert(value, from_unit, to_unit)
    return result.result


async def stats(values: List[float]) -> Dict[str, float]:
    """Quick statistics."""
    calculator = get_calculator()
    return await calculator.statistics(values)