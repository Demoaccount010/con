"""
Scheduler Tools - Task scheduling and management.
Schedule one-time and recurring tasks.
"""

import asyncio
import uuid
from pathlib import Path
from typing import Optional, Dict, Any, List, Callable, Awaitable, Union
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
import logging
import heapq

import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from tools.base_tool import (
    BaseTool, ToolResult, ToolContext, ResultStatus,
    ToolCategory, ToolRisk
)
from tools.registry import get_registry

logger = logging.getLogger(__name__)

# Check for croniter
try:
    from croniter import croniter
    HAS_CRONITER = True
except ImportError:
    HAS_CRONITER = False
    logger.info("croniter not available, cron scheduling limited")


class TaskStatus(Enum):
    """Task status."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    PAUSED = "paused"


class ScheduleType(Enum):
    """Schedule type."""
    ONCE = "once"
    INTERVAL = "interval"
    CRON = "cron"
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"


@dataclass
class ScheduledTask:
    """A scheduled task."""
    id: str
    name: str
    schedule_type: ScheduleType
    next_run: datetime
    callback: Optional[Callable] = None
    callback_name: Optional[str] = None
    args: tuple = field(default_factory=tuple)
    kwargs: Dict[str, Any] = field(default_factory=dict)
    
    # Schedule config
    interval_seconds: Optional[float] = None
    cron_expression: Optional[str] = None
    
    # State
    status: TaskStatus = TaskStatus.PENDING
    last_run: Optional[datetime] = None
    run_count: int = 0
    max_runs: Optional[int] = None
    error_count: int = 0
    last_error: Optional[str] = None
    last_result: Optional[Any] = None
    
    # Options
    catch_up: bool = False
    enabled: bool = True
    
    created_at: datetime = field(default_factory=datetime.now)
    
    def __lt__(self, other: 'ScheduledTask') -> bool:
        """For heap comparison."""
        return self.next_run < other.next_run
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'name': self.name,
            'schedule_type': self.schedule_type.value,
            'next_run': self.next_run.isoformat() if self.next_run else None,
            'callback_name': self.callback_name,
            'interval_seconds': self.interval_seconds,
            'cron_expression': self.cron_expression,
            'status': self.status.value,
            'last_run': self.last_run.isoformat() if self.last_run else None,
            'run_count': self.run_count,
            'max_runs': self.max_runs,
            'error_count': self.error_count,
            'last_error': self.last_error,
            'enabled': self.enabled,
            'created_at': self.created_at.isoformat()
        }


@dataclass
class TaskResult:
    """Result of task execution."""
    task_id: str
    task_name: str
    success: bool
    result: Optional[Any] = None
    error: Optional[str] = None
    execution_time_ms: float = 0
    timestamp: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'task_id': self.task_id,
            'task_name': self.task_name,
            'success': self.success,
            'result': str(self.result)[:500] if self.result else None,
            'error': self.error,
            'execution_time_ms': self.execution_time_ms,
            'timestamp': self.timestamp.isoformat()
        }


class SchedulerTools(BaseTool):
    """
    Task scheduling tool.
    
    Features:
    - One-time task scheduling
    - Interval-based recurring tasks
    - Cron expression support
    - Daily, weekly, monthly schedules
    - Task pause/resume
    - Execution history
    - Callback registration
    """
    
    def __init__(self):
        super().__init__(
            name="scheduler_tools",
            description="Task scheduling and management",
            category=ToolCategory.UTILITY,
            risk=ToolRisk.LOW,
            requires_confirmation=False,
            timeout=60.0,
            version="1.0.0"
        )
        
        self._tasks: Dict[str, ScheduledTask] = {}
        self._task_heap: List[ScheduledTask] = []
        self._callbacks: Dict[str, Callable] = {}
        self._execution_history: List[TaskResult] = []
        self._max_history = 500
        
        self._running = False
        self._scheduler_task: Optional[asyncio.Task] = None
        self._lock = asyncio.Lock()
    
    # =========================================================================
    # Callback Registration
    # =========================================================================
    
    def register_callback(
        self,
        name: str,
        callback: Callable[..., Awaitable[Any]]
    ) -> None:
        """
        Register a callback function for tasks.
        
        Args:
            name: Callback name
            callback: Async callable
        """
        self._callbacks[name] = callback
        logger.info(f"Registered callback: {name}")
    
    def unregister_callback(self, name: str) -> bool:
        """Unregister a callback."""
        if name in self._callbacks:
            del self._callbacks[name]
            return True
        return False
    
    def list_callbacks(self) -> List[str]:
        """List registered callbacks."""
        return list(self._callbacks.keys())
    
    # =========================================================================
    # Task Scheduling
    # =========================================================================
    
    async def schedule_once(
        self,
        name: str,
        run_at: datetime,
        callback_name: str,
        args: tuple = (),
        kwargs: Optional[Dict[str, Any]] = None
    ) -> ScheduledTask:
        """
        Schedule a one-time task.
        
        Args:
            name: Task name
            run_at: When to run
            callback_name: Name of registered callback
            args: Callback arguments
            kwargs: Callback keyword arguments
            
        Returns:
            ScheduledTask
        """
        task = ScheduledTask(
            id=str(uuid.uuid4()),
            name=name,
            schedule_type=ScheduleType.ONCE,
            next_run=run_at,
            callback_name=callback_name,
            callback=self._callbacks.get(callback_name),
            args=args,
            kwargs=kwargs or {},
            max_runs=1
        )
        
        await self._add_task(task)
        return task
    
    async def schedule_interval(
        self,
        name: str,
        interval_seconds: float,
        callback_name: str,
        args: tuple = (),
        kwargs: Optional[Dict[str, Any]] = None,
        start_immediately: bool = True,
        max_runs: Optional[int] = None
    ) -> ScheduledTask:
        """
        Schedule a recurring task with fixed interval.
        
        Args:
            name: Task name
            interval_seconds: Interval between runs
            callback_name: Name of registered callback
            args: Callback arguments
            kwargs: Callback keyword arguments
            start_immediately: Run immediately on start
            max_runs: Maximum number of runs
            
        Returns:
            ScheduledTask
        """
        if start_immediately:
            next_run = datetime.now()
        else:
            next_run = datetime.now() + timedelta(seconds=interval_seconds)
        
        task = ScheduledTask(
            id=str(uuid.uuid4()),
            name=name,
            schedule_type=ScheduleType.INTERVAL,
            next_run=next_run,
            callback_name=callback_name,
            callback=self._callbacks.get(callback_name),
            args=args,
            kwargs=kwargs or {},
            interval_seconds=interval_seconds,
            max_runs=max_runs
        )
        
        await self._add_task(task)
        return task
    
    async def schedule_cron(
        self,
        name: str,
        cron_expression: str,
        callback_name: str,
        args: tuple = (),
        kwargs: Optional[Dict[str, Any]] = None,
        max_runs: Optional[int] = None
    ) -> ScheduledTask:
        """
        Schedule a task with cron expression.
        
        Args:
            name: Task name
            cron_expression: Cron expression (e.g., "0 * * * *" for hourly)
            callback_name: Name of registered callback
            args: Callback arguments
            kwargs: Callback keyword arguments
            max_runs: Maximum number of runs
            
        Returns:
            ScheduledTask
        """
        if not HAS_CRONITER:
            raise RuntimeError("croniter not installed. Install with: pip install croniter")
        
        try:
            cron = croniter(cron_expression, datetime.now())
            next_run = cron.get_next(datetime)
        except Exception as e:
            raise ValueError(f"Invalid cron expression: {e}")
        
        task = ScheduledTask(
            id=str(uuid.uuid4()),
            name=name,
            schedule_type=ScheduleType.CRON,
            next_run=next_run,
            callback_name=callback_name,
            callback=self._callbacks.get(callback_name),
            args=args,
            kwargs=kwargs or {},
            cron_expression=cron_expression,
            max_runs=max_runs
        )
        
        await self._add_task(task)
        return task
    
    async def schedule_daily(
        self,
        name: str,
        hour: int,
        minute: int,
        callback_name: str,
        args: tuple = (),
        kwargs: Optional[Dict[str, Any]] = None
    ) -> ScheduledTask:
        """
        Schedule a daily task.
        
        Args:
            name: Task name
            hour: Hour (0-23)
            minute: Minute (0-59)
            callback_name: Callback name
            args: Callback arguments
            kwargs: Callback keyword arguments
            
        Returns:
            ScheduledTask
        """
        # Calculate next run time
        now = datetime.now()
        next_run = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
        
        if next_run <= now:
            next_run += timedelta(days=1)
        
        task = ScheduledTask(
            id=str(uuid.uuid4()),
            name=name,
            schedule_type=ScheduleType.DAILY,
            next_run=next_run,
            callback_name=callback_name,
            callback=self._callbacks.get(callback_name),
            args=args,
            kwargs=kwargs or {},
            interval_seconds=86400  # 24 hours
        )
        
        await self._add_task(task)
        return task
    
    async def schedule_weekly(
        self,
        name: str,
        day_of_week: int,
        hour: int,
        minute: int,
        callback_name: str,
        args: tuple = (),
        kwargs: Optional[Dict[str, Any]] = None
    ) -> ScheduledTask:
        """
        Schedule a weekly task.
        
        Args:
            name: Task name
            day_of_week: Day (0=Monday, 6=Sunday)
            hour: Hour (0-23)
            minute: Minute (0-59)
            callback_name: Callback name
            args: Callback arguments
            kwargs: Callback keyword arguments
            
        Returns:
            ScheduledTask
        """
        now = datetime.now()
        days_ahead = day_of_week - now.weekday()
        
        if days_ahead < 0:
            days_ahead += 7
        elif days_ahead == 0:
            # Same day, check time
            target_time = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            if now >= target_time:
                days_ahead = 7
        
        next_run = now + timedelta(days=days_ahead)
        next_run = next_run.replace(hour=hour, minute=minute, second=0, microsecond=0)
        
        task = ScheduledTask(
            id=str(uuid.uuid4()),
            name=name,
            schedule_type=ScheduleType.WEEKLY,
            next_run=next_run,
            callback_name=callback_name,
            callback=self._callbacks.get(callback_name),
            args=args,
            kwargs=kwargs or {},
            interval_seconds=604800  # 7 days
        )
        
        await self._add_task(task)
        return task
    
    async def schedule_delay(
        self,
        name: str,
        delay_seconds: float,
        callback_name: str,
        args: tuple = (),
        kwargs: Optional[Dict[str, Any]] = None
    ) -> ScheduledTask:
        """
        Schedule a task to run after a delay.
        
        Args:
            name: Task name
            delay_seconds: Delay in seconds
            callback_name: Callback name
            args: Callback arguments
            kwargs: Callback keyword arguments
            
        Returns:
            ScheduledTask
        """
        run_at = datetime.now() + timedelta(seconds=delay_seconds)
        return await self.schedule_once(name, run_at, callback_name, args, kwargs)
    
    async def _add_task(self, task: ScheduledTask) -> None:
        """Add task to scheduler."""
        async with self._lock:
            self._tasks[task.id] = task
            heapq.heappush(self._task_heap, task)
            logger.info(f"Scheduled task: {task.name} ({task.id}) - next run: {task.next_run}")
    
    # =========================================================================
    # Task Management
    # =========================================================================
    
    async def cancel_task(self, task_id: str) -> bool:
        """Cancel a scheduled task."""
        async with self._lock:
            if task_id in self._tasks:
                self._tasks[task_id].status = TaskStatus.CANCELLED
                self._tasks[task_id].enabled = False
                logger.info(f"Cancelled task: {task_id}")
                return True
            return False
    
    async def pause_task(self, task_id: str) -> bool:
        """Pause a scheduled task."""
        async with self._lock:
            if task_id in self._tasks:
                self._tasks[task_id].status = TaskStatus.PAUSED
                self._tasks[task_id].enabled = False
                logger.info(f"Paused task: {task_id}")
                return True
            return False
    
    async def resume_task(self, task_id: str) -> bool:
        """Resume a paused task."""
        async with self._lock:
            if task_id in self._tasks:
                task = self._tasks[task_id]
                if task.status == TaskStatus.PAUSED:
                    task.status = TaskStatus.PENDING
                    task.enabled = True
                    
                    # Recalculate next run
                    task.next_run = await self._calculate_next_run(task) or datetime.now()
                    heapq.heappush(self._task_heap, task)
                    logger.info(f"Resumed task: {task_id}")
                    return True
            return False
    
    async def remove_task(self, task_id: str) -> bool:
        """Remove a task completely."""
        async with self._lock:
            if task_id in self._tasks:
                del self._tasks[task_id]
                logger.info(f"Removed task: {task_id}")
                return True
            return False
    
    def get_task(self, task_id: str) -> Optional[ScheduledTask]:
        """Get task by ID."""
        return self._tasks.get(task_id)
    
    def get_task_by_name(self, name: str) -> Optional[ScheduledTask]:
        """Get task by name."""
        for task in self._tasks.values():
            if task.name == name:
                return task
        return None
    
    def list_tasks(
        self,
        status: Optional[TaskStatus] = None,
        enabled_only: bool = False
    ) -> List[Dict[str, Any]]:
        """List all scheduled tasks."""
        tasks = list(self._tasks.values())
        
        if status:
            tasks = [t for t in tasks if t.status == status]
        if enabled_only:
            tasks = [t for t in tasks if t.enabled]
        
        return [t.to_dict() for t in sorted(tasks, key=lambda x: x.next_run or datetime.max)]
    
    def get_next_tasks(self, count: int = 5) -> List[Dict[str, Any]]:
        """Get next tasks to run."""
        pending = [t for t in self._tasks.values() 
                   if t.enabled and t.status == TaskStatus.PENDING]
        pending.sort(key=lambda x: x.next_run)
        return [t.to_dict() for t in pending[:count]]
    
    # =========================================================================
    # Task Execution
    # =========================================================================
    
    async def _execute_task(self, task: ScheduledTask) -> TaskResult:
        """Execute a scheduled task."""
        start_time = datetime.now()
        
        try:
            task.status = TaskStatus.RUNNING
            
            # Get callback
            callback = task.callback or self._callbacks.get(task.callback_name)
            
            if not callback:
                raise ValueError(f"Callback not found: {task.callback_name}")
            
            # Execute
            if asyncio.iscoroutinefunction(callback):
                result = await callback(*task.args, **task.kwargs)
            else:
                result = callback(*task.args, **task.kwargs)
            
            execution_time = (datetime.now() - start_time).total_seconds() * 1000
            
            task.last_result = result
            task.run_count += 1
            task.last_run = datetime.now()
            
            # Check if max runs reached
            if task.max_runs and task.run_count >= task.max_runs:
                task.status = TaskStatus.COMPLETED
            else:
                task.status = TaskStatus.PENDING
            
            logger.info(f"Task {task.name} completed successfully in {execution_time:.2f}ms")
            
            return TaskResult(
                task_id=task.id,
                task_name=task.name,
                success=True,
                result=result,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            execution_time = (datetime.now() - start_time).total_seconds() * 1000
            
            task.error_count += 1
            task.last_error = str(e)
            task.status = TaskStatus.FAILED
            task.run_count += 1
            task.last_run = datetime.now()
            
            logger.error(f"Task {task.name} failed: {e}")
            
            return TaskResult(
                task_id=task.id,
                task_name=task.name,
                success=False,
                error=str(e),
                execution_time_ms=execution_time
            )
    
    async def _calculate_next_run(self, task: ScheduledTask) -> Optional[datetime]:
        """Calculate next run time for task."""
        if task.max_runs and task.run_count >= task.max_runs:
            return None
        
        if task.schedule_type == ScheduleType.ONCE:
            return None
        
        if task.schedule_type == ScheduleType.INTERVAL and task.interval_seconds:
            return datetime.now() + timedelta(seconds=task.interval_seconds)
        
        if task.schedule_type == ScheduleType.CRON and task.cron_expression and HAS_CRONITER:
            try:
                cron = croniter(task.cron_expression, datetime.now())
                return cron.get_next(datetime)
            except Exception:
                return None
        
        if task.schedule_type == ScheduleType.DAILY and task.interval_seconds:
            return datetime.now() + timedelta(seconds=task.interval_seconds)
        
        if task.schedule_type == ScheduleType.WEEKLY and task.interval_seconds:
            return datetime.now() + timedelta(seconds=task.interval_seconds)
        
        return None
    
    async def run_task_now(self, task_id: str) -> Optional[TaskResult]:
        """Run a task immediately (out of schedule)."""
        task = self._tasks.get(task_id)
        if not task:
            return None
        
        result = await self._execute_task(task)
        
        # Record in history
        self._add_to_history(result)
        
        # Reschedule if recurring and not cancelled
        if task.status not in [TaskStatus.CANCELLED, TaskStatus.COMPLETED]:
            next_run = await self._calculate_next_run(task)
            if next_run:
                task.next_run = next_run
                task.status = TaskStatus.PENDING
                async with self._lock:
                    heapq.heappush(self._task_heap, task)
        
        return result
    
    def _add_to_history(self, result: TaskResult) -> None:
        """Add result to execution history."""
        self._execution_history.append(result)
        if len(self._execution_history) > self._max_history:
            self._execution_history = self._execution_history[-self._max_history:]
    
    def get_execution_history(
        self,
        task_id: Optional[str] = None,
        task_name: Optional[str] = None,
        success_only: bool = False,
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        """Get task execution history."""
        history = self._execution_history
        
        if task_id:
            history = [h for h in history if h.task_id == task_id]
        if task_name:
            history = [h for h in history if h.task_name == task_name]
        if success_only:
            history = [h for h in history if h.success]
        
        return [h.to_dict() for h in history[-limit:]]
    
    # =========================================================================
    # Scheduler Loop
    # =========================================================================
    
    async def start(self) -> None:
        """Start the scheduler loop."""
        if self._running:
            logger.warning("Scheduler already running")
            return
        
        self._running = True
        self._scheduler_task = asyncio.create_task(self._scheduler_loop())
        logger.info("Scheduler started")
    
    async def stop(self) -> None:
        """Stop the scheduler loop."""
        self._running = False
        
        if self._scheduler_task:
            self._scheduler_task.cancel()
            try:
                await self._scheduler_task
            except asyncio.CancelledError:
                pass
            self._scheduler_task = None
        
        logger.info("Scheduler stopped")
    
    def is_running(self) -> bool:
        """Check if scheduler is running."""
        return self._running
    
    async def _scheduler_loop(self) -> None:
        """Main scheduler loop."""
        logger.info("Scheduler loop started")
        
        while self._running:
            try:
                await self._process_due_tasks()
                await asyncio.sleep(1)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Scheduler error: {e}")
                await asyncio.sleep(5)
        
        logger.info("Scheduler loop ended")
    
    async def _process_due_tasks(self) -> None:
        """Process all due tasks."""
        now = datetime.now()
        
        while self._task_heap:
            async with self._lock:
                if not self._task_heap:
                    break
                
                task = self._task_heap[0]
                
                # Check if task is due
                if task.next_run > now:
                    break
                
                # Pop task from heap
                heapq.heappop(self._task_heap)
                
                # Skip if disabled or cancelled
                if not task.enabled or task.status in [TaskStatus.CANCELLED, TaskStatus.PAUSED]:
                    continue
                
                # Skip if removed
                if task.id not in self._tasks:
                    continue
            
            # Execute task (outside lock)
            result = await self._execute_task(task)
            self._add_to_history(result)
            
            # Reschedule if recurring
            if task.status not in [TaskStatus.CANCELLED, TaskStatus.COMPLETED]:
                next_run = await self._calculate_next_run(task)
                if next_run:
                    task.next_run = next_run
                    task.status = TaskStatus.PENDING
                    async with self._lock:
                        heapq.heappush(self._task_heap, task)
    
    # =========================================================================
    # Statistics
    # =========================================================================
    
    def get_stats(self) -> Dict[str, Any]:
        """Get scheduler statistics."""
        tasks = list(self._tasks.values())
        
        return {
            'running': self._running,
            'total_tasks': len(tasks),
            'pending_tasks': sum(1 for t in tasks if t.status == TaskStatus.PENDING),
            'paused_tasks': sum(1 for t in tasks if t.status == TaskStatus.PAUSED),
            'completed_tasks': sum(1 for t in tasks if t.status == TaskStatus.COMPLETED),
            'failed_tasks': sum(1 for t in tasks if t.status == TaskStatus.FAILED),
            'cancelled_tasks': sum(1 for t in tasks if t.status == TaskStatus.CANCELLED),
            'total_executions': len(self._execution_history),
            'successful_executions': sum(1 for h in self._execution_history if h.success),
            'failed_executions': sum(1 for h in self._execution_history if not h.success),
            'registered_callbacks': len(self._callbacks)
        }
    
    # =========================================================================
    # Main Run Method
    # =========================================================================
    
    async def run(self, context: ToolContext, **kwargs) -> ToolResult:
        """
        Execute scheduler operation.
        
        Supported operations:
        - schedule_once: Schedule one-time task
        - schedule_interval: Schedule recurring task
        - schedule_cron: Schedule with cron expression
        - schedule_daily: Schedule daily task
        - schedule_weekly: Schedule weekly task
        - schedule_delay: Schedule after delay
        - cancel: Cancel task
        - pause: Pause task
        - resume: Resume task
        - remove: Remove task
        - run_now: Run task immediately
        - list: List tasks
        - get: Get task details
        - history: Get execution history
        - stats: Get scheduler stats
        - start: Start scheduler
        - stop: Stop scheduler
        - register_callback: Register callback
        - list_callbacks: List callbacks
        """
        operation = kwargs.get('operation', 'list')
        
        try:
            if operation == 'schedule_once':
                name = kwargs.get('name')
                callback_name = kwargs.get('callback_name') or kwargs.get('callback')
                run_at = kwargs.get('run_at')
                
                if not name or not callback_name:
                    return ToolResult.fail(error="name and callback_name are required")
                
                if isinstance(run_at, str):
                    run_at = datetime.fromisoformat(run_at)
                elif not run_at:
                    return ToolResult.fail(error="run_at is required")
                
                task = await self.schedule_once(
                    name=name,
                    run_at=run_at,
                    callback_name=callback_name,
                    args=tuple(kwargs.get('args', [])),
                    kwargs=kwargs.get('task_kwargs', {})
                )
                
                return ToolResult.ok(
                    data=task.to_dict(),
                    message=f"Scheduled task '{name}' for {run_at}"
                )
            
            elif operation == 'schedule_interval':
                name = kwargs.get('name')
                callback_name = kwargs.get('callback_name') or kwargs.get('callback')
                interval = kwargs.get('interval_seconds') or kwargs.get('interval')
                
                if not name or not callback_name or not interval:
                    return ToolResult.fail(error="name, callback_name, and interval_seconds are required")
                
                task = await self.schedule_interval(
                    name=name,
                    interval_seconds=float(interval),
                    callback_name=callback_name,
                    args=tuple(kwargs.get('args', [])),
                    kwargs=kwargs.get('task_kwargs', {}),
                    start_immediately=kwargs.get('start_immediately', True),
                    max_runs=kwargs.get('max_runs')
                )
                
                return ToolResult.ok(
                    data=task.to_dict(),
                    message=f"Scheduled task '{name}' every {interval}s"
                )
            
            elif operation == 'schedule_cron':
                name = kwargs.get('name')
                callback_name = kwargs.get('callback_name') or kwargs.get('callback')
                cron_expr = kwargs.get('cron_expression') or kwargs.get('cron')
                
                if not name or not callback_name or not cron_expr:
                    return ToolResult.fail(error="name, callback_name, and cron_expression are required")
                
                task = await self.schedule_cron(
                    name=name,
                    cron_expression=cron_expr,
                    callback_name=callback_name,
                    args=tuple(kwargs.get('args', [])),
                    kwargs=kwargs.get('task_kwargs', {}),
                    max_runs=kwargs.get('max_runs')
                )
                
                return ToolResult.ok(
                    data=task.to_dict(),
                    message=f"Scheduled task '{name}' with cron: {cron_expr}"
                )
            
            elif operation == 'schedule_daily':
                name = kwargs.get('name')
                callback_name = kwargs.get('callback_name') or kwargs.get('callback')
                hour = kwargs.get('hour', 0)
                minute = kwargs.get('minute', 0)
                
                if not name or not callback_name:
                    return ToolResult.fail(error="name and callback_name are required")
                
                task = await self.schedule_daily(
                    name=name,
                    hour=int(hour),
                    minute=int(minute),
                    callback_name=callback_name,
                    args=tuple(kwargs.get('args', [])),
                    kwargs=kwargs.get('task_kwargs', {})
                )
                
                return ToolResult.ok(
                    data=task.to_dict(),
                    message=f"Scheduled task '{name}' daily at {hour:02d}:{minute:02d}"
                )
            
            elif operation == 'schedule_weekly':
                name = kwargs.get('name')
                callback_name = kwargs.get('callback_name') or kwargs.get('callback')
                day = kwargs.get('day_of_week', 0)
                hour = kwargs.get('hour', 0)
                minute = kwargs.get('minute', 0)
                
                if not name or not callback_name:
                    return ToolResult.fail(error="name and callback_name are required")
                
                task = await self.schedule_weekly(
                    name=name,
                    day_of_week=int(day),
                    hour=int(hour),
                    minute=int(minute),
                    callback_name=callback_name,
                    args=tuple(kwargs.get('args', [])),
                    kwargs=kwargs.get('task_kwargs', {})
                )
                
                days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
                return ToolResult.ok(
                    data=task.to_dict(),
                    message=f"Scheduled task '{name}' every {days[day]} at {hour:02d}:{minute:02d}"
                )
            
            elif operation == 'schedule_delay':
                name = kwargs.get('name')
                callback_name = kwargs.get('callback_name') or kwargs.get('callback')
                delay = kwargs.get('delay_seconds') or kwargs.get('delay')
                
                if not name or not callback_name or not delay:
                    return ToolResult.fail(error="name, callback_name, and delay_seconds are required")
                
                task = await self.schedule_delay(
                    name=name,
                    delay_seconds=float(delay),
                    callback_name=callback_name,
                    args=tuple(kwargs.get('args', [])),
                    kwargs=kwargs.get('task_kwargs', {})
                )
                
                return ToolResult.ok(
                    data=task.to_dict(),
                    message=f"Scheduled task '{name}' to run in {delay}s"
                )
            
            elif operation == 'cancel':
                task_id = kwargs.get('task_id') or kwargs.get('id')
                if not task_id:
                    return ToolResult.fail(error="task_id is required")
                
                if await self.cancel_task(task_id):
                    return ToolResult.ok(message=f"Task {task_id} cancelled")
                else:
                    return ToolResult.fail(error=f"Task {task_id} not found")
            
            elif operation == 'pause':
                task_id = kwargs.get('task_id') or kwargs.get('id')
                if not task_id:
                    return ToolResult.fail(error="task_id is required")
                
                if await self.pause_task(task_id):
                    return ToolResult.ok(message=f"Task {task_id} paused")
                else:
                    return ToolResult.fail(error=f"Task {task_id} not found")
            
            elif operation == 'resume':
                task_id = kwargs.get('task_id') or kwargs.get('id')
                if not task_id:
                    return ToolResult.fail(error="task_id is required")
                
                if await self.resume_task(task_id):
                    return ToolResult.ok(message=f"Task {task_id} resumed")
                else:
                    return ToolResult.fail(error=f"Task {task_id} not found or not paused")
            
            elif operation == 'remove':
                task_id = kwargs.get('task_id') or kwargs.get('id')
                if not task_id:
                    return ToolResult.fail(error="task_id is required")
                
                if await self.remove_task(task_id):
                    return ToolResult.ok(message=f"Task {task_id} removed")
                else:
                    return ToolResult.fail(error=f"Task {task_id} not found")
            
            elif operation == 'run_now':
                task_id = kwargs.get('task_id') or kwargs.get('id')
                if not task_id:
                    return ToolResult.fail(error="task_id is required")
                
                result = await self.run_task_now(task_id)
                
                if result:
                    if result.success:
                        return ToolResult.ok(data=result.to_dict())
                    else:
                        return ToolResult.fail(error=result.error, data=result.to_dict())
                else:
                    return ToolResult.fail(error=f"Task {task_id} not found")
            
            elif operation == 'list':
                status_str = kwargs.get('status')
                status = TaskStatus(status_str) if status_str else None
                
                tasks = self.list_tasks(
                    status=status,
                    enabled_only=kwargs.get('enabled_only', False)
                )
                
                return ToolResult.ok(
                    data={
                        'tasks': tasks,
                        'count': len(tasks)
                    }
                )
            
            elif operation == 'get':
                task_id = kwargs.get('task_id') or kwargs.get('id')
                task_name = kwargs.get('name')
                
                if task_id:
                    task = self.get_task(task_id)
                elif task_name:
                    task = self.get_task_by_name(task_name)
                else:
                    return ToolResult.fail(error="task_id or name is required")
                
                if task:
                    return ToolResult.ok(data=task.to_dict())
                else:
                    return ToolResult.fail(error="Task not found")
            
            elif operation == 'next':
                count = kwargs.get('count', 5)
                tasks = self.get_next_tasks(count)
                
                return ToolResult.ok(
                    data={
                        'tasks': tasks,
                        'count': len(tasks)
                    }
                )
            
            elif operation == 'history':
                history = self.get_execution_history(
                    task_id=kwargs.get('task_id'),
                    task_name=kwargs.get('task_name'),
                    success_only=kwargs.get('success_only', False),
                    limit=kwargs.get('limit', 50)
                )
                
                return ToolResult.ok(
                    data={
                        'history': history,
                        'count': len(history)
                    }
                )
            
            elif operation == 'stats':
                stats = self.get_stats()
                return ToolResult.ok(data=stats)
            
            elif operation == 'start':
                await self.start()
                return ToolResult.ok(message="Scheduler started")
            
            elif operation == 'stop':
                await self.stop()
                return ToolResult.ok(message="Scheduler stopped")
            
            elif operation == 'status':
                return ToolResult.ok(
                    data={
                        'running': self.is_running(),
                        'stats': self.get_stats()
                    }
                )
            
            elif operation == 'register_callback':
                # Note: Can't register actual callbacks via this interface
                # This is mainly for documentation
                return ToolResult.fail(
                    error="Callbacks must be registered programmatically using register_callback()"
                )
            
            elif operation == 'list_callbacks':
                callbacks = self.list_callbacks()
                
                return ToolResult.ok(
                    data={
                        'callbacks': callbacks,
                        'count': len(callbacks)
                    }
                )
            
            else:
                return ToolResult.fail(error=f"Unknown operation: {operation}")
            
        except Exception as e:
            logger.error(f"SchedulerTools error: {e}")
            return ToolResult.error(error=str(e))
    
    async def cleanup(self) -> None:
        """Stop scheduler on cleanup."""
        await self.stop()


# Create singleton
scheduler_tools = SchedulerTools()


def register():
    """Register scheduler tools."""
    registry = get_registry()
    registry.register_tool(scheduler_tools)