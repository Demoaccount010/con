"""
DNS Tools - DNS resolution and lookup utilities.
Comprehensive DNS operations with caching.
"""

import asyncio
import socket
from pathlib import Path
from typing import Optional, Dict, Any, List, Set
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from collections import OrderedDict
import logging

import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from tools.base_tool import (
    BaseTool, ToolResult, ToolContext, ResultStatus,
    ToolCategory, ToolRisk
)
from tools.registry import get_registry

logger = logging.getLogger(__name__)


class RecordType:
    """DNS record types."""
    A = 'A'
    AAAA = 'AAAA'
    CNAME = 'CNAME'
    MX = 'MX'
    NS = 'NS'
    TXT = 'TXT'
    SOA = 'SOA'
    PTR = 'PTR'
    SRV = 'SRV'
    CAA = 'CAA'


@dataclass
class DnsRecord:
    """A DNS record."""
    name: str
    type: str
    value: str
    ttl: Optional[int] = None
    priority: Optional[int] = None  # For MX records
    
    def to_dict(self) -> Dict[str, Any]:
        result = {
            'name': self.name,
            'type': self.type,
            'value': self.value
        }
        if self.ttl is not None:
            result['ttl'] = self.ttl
        if self.priority is not None:
            result['priority'] = self.priority
        return result


@dataclass
class DnsLookupResult:
    """Result of DNS lookup."""
    success: bool
    domain: str
    record_type: str
    records: List[DnsRecord]
    query_time_ms: float
    from_cache: bool = False
    error: Optional[str] = None
    authoritative: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'success': self.success,
            'domain': self.domain,
            'record_type': self.record_type,
            'records': [r.to_dict() for r in self.records],
            'record_count': len(self.records),
            'query_time_ms': self.query_time_ms,
            'from_cache': self.from_cache,
            'error': self.error,
            'authoritative': self.authoritative
        }


@dataclass
class WhoisResult:
    """Result of WHOIS lookup."""
    success: bool
    domain: str
    registrar: Optional[str]
    creation_date: Optional[str]
    expiration_date: Optional[str]
    name_servers: List[str]
    status: List[str]
    raw: Optional[str] = None
    error: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'success': self.success,
            'domain': self.domain,
            'registrar': self.registrar,
            'creation_date': self.creation_date,
            'expiration_date': self.expiration_date,
            'name_servers': self.name_servers,
            'status': self.status,
            'error': self.error
        }


class DnsCache:
    """Simple DNS cache with TTL."""
    
    def __init__(self, max_size: int = 1000, default_ttl: int = 300):
        self.max_size = max_size
        self.default_ttl = default_ttl
        self._cache: OrderedDict[str, tuple] = OrderedDict()
        self._lock = asyncio.Lock()
    
    def _key(self, domain: str, record_type: str) -> str:
        return f"{domain}:{record_type}"
    
    async def get(self, domain: str, record_type: str) -> Optional[DnsLookupResult]:
        """Get cached result."""
        async with self._lock:
            key = self._key(domain, record_type)
            
            if key not in self._cache:
                return None
            
            result, expires_at = self._cache[key]
            
            if datetime.now() > expires_at:
                del self._cache[key]
                return None
            
            # Mark as recently used
            self._cache.move_to_end(key)
            
            # Return cached result
            cached = DnsLookupResult(
                success=result.success,
                domain=result.domain,
                record_type=result.record_type,
                records=result.records,
                query_time_ms=0,
                from_cache=True,
                error=result.error
            )
            return cached
    
    async def set(
        self,
        domain: str,
        record_type: str,
        result: DnsLookupResult,
        ttl: Optional[int] = None
    ) -> None:
        """Cache a result."""
        async with self._lock:
            key = self._key(domain, record_type)
            ttl = ttl or self.default_ttl
            expires_at = datetime.now() + timedelta(seconds=ttl)
            
            # Evict if full
            while len(self._cache) >= self.max_size:
                self._cache.popitem(last=False)
            
            self._cache[key] = (result, expires_at)
    
    async def clear(self) -> None:
        """Clear cache."""
        async with self._lock:
            self._cache.clear()
    
    def size(self) -> int:
        """Get cache size."""
        return len(self._cache)


class DnsTools(BaseTool):
    """
    DNS lookup and resolution tool.
    
    Features:
    - Multiple record type lookups (A, AAAA, MX, NS, TXT, etc.)
    - Reverse DNS lookup
    - WHOIS queries
    - DNS propagation check
    - Result caching
    - Batch lookups
    """
    
    def __init__(self):
        super().__init__(
            name="dns_tools",
            description="DNS lookup and resolution",
            category=ToolCategory.NETWORK,
            risk=ToolRisk.NONE,
            requires_confirmation=False,
            timeout=60.0,
            version="1.0.0"
        )
        
        self._cache = DnsCache()
        
        # Check for dnspython
        self._has_dnspython = False
        try:
            import dns.resolver
            self._has_dnspython = True
        except ImportError:
            logger.info("dnspython not available, using fallback methods")
    
    async def lookup(
        self,
        domain: str,
        record_type: str = RecordType.A,
        use_cache: bool = True,
        nameserver: Optional[str] = None
    ) -> DnsLookupResult:
        """
        Lookup DNS records.
        
        Args:
            domain: Domain name
            record_type: Type of record to lookup
            use_cache: Use cached results
            nameserver: Specific nameserver to use
            
        Returns:
            DnsLookupResult with records
        """
        start_time = datetime.now()
        
        # Check cache
        if use_cache:
            cached = await self._cache.get(domain, record_type)
            if cached:
                return cached
        
        try:
            if self._has_dnspython:
                result = await self._lookup_dnspython(domain, record_type, nameserver)
            else:
                result = await self._lookup_fallback(domain, record_type)
            
            result.query_time_ms = (datetime.now() - start_time).total_seconds() * 1000
            
            # Cache successful results
            if result.success and use_cache:
                await self._cache.set(domain, record_type, result)
            
            return result
            
        except Exception as e:
            logger.error(f"DNS lookup error: {e}")
            return DnsLookupResult(
                success=False,
                domain=domain,
                record_type=record_type,
                records=[],
                query_time_ms=(datetime.now() - start_time).total_seconds() * 1000,
                error=str(e)
            )
    
    async def _lookup_dnspython(
        self,
        domain: str,
        record_type: str,
        nameserver: Optional[str]
    ) -> DnsLookupResult:
        """Lookup using dnspython."""
        import dns.resolver
        import dns.exception
        
        try:
            resolver = dns.resolver.Resolver()
            
            if nameserver:
                resolver.nameservers = [nameserver]
            
            # Run in executor to avoid blocking
            loop = asyncio.get_event_loop()
            answers = await loop.run_in_executor(
                None,
                lambda: resolver.resolve(domain, record_type)
            )
            
            records = []
            for rdata in answers:
                value = str(rdata)
                
                # Handle MX records
                priority = None
                if record_type == RecordType.MX:
                    priority = rdata.preference
                    value = str(rdata.exchange).rstrip('.')
                
                records.append(DnsRecord(
                    name=domain,
                    type=record_type,
                    value=value,
                    ttl=answers.ttl,
                    priority=priority
                ))
            
            return DnsLookupResult(
                success=True,
                domain=domain,
                record_type=record_type,
                records=records,
                query_time_ms=0
            )
            
        except dns.resolver.NXDOMAIN:
            return DnsLookupResult(
                success=False,
                domain=domain,
                record_type=record_type,
                records=[],
                query_time_ms=0,
                error="Domain does not exist (NXDOMAIN)"
            )
        except dns.resolver.NoAnswer:
            return DnsLookupResult(
                success=True,
                domain=domain,
                record_type=record_type,
                records=[],
                query_time_ms=0
            )
        except dns.exception.Timeout:
            return DnsLookupResult(
                success=False,
                domain=domain,
                record_type=record_type,
                records=[],
                query_time_ms=0,
                error="DNS query timed out"
            )
    
    async def _lookup_fallback(
        self,
        domain: str,
        record_type: str
    ) -> DnsLookupResult:
        """Fallback lookup using dig command."""
        try:
            cmd = f"dig +short {domain} {record_type}"
            
            process = await asyncio.create_subprocess_shell(
                cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await asyncio.wait_for(
                process.communicate(),
                timeout=10.0
            )
            
            output = stdout.decode('utf-8', errors='replace').strip()
            
            if not output:
                # Try socket for A records
                if record_type == RecordType.A:
                    try:
                        ip = socket.gethostbyname(domain)
                        return DnsLookupResult(
                            success=True,
                            domain=domain,
                            record_type=record_type,
                            records=[DnsRecord(name=domain, type='A', value=ip)],
                            query_time_ms=0
                        )
                    except socket.gaierror:
                        pass
                
                return DnsLookupResult(
                    success=True,
                    domain=domain,
                    record_type=record_type,
                    records=[],
                    query_time_ms=0
                )
            
            records = []
            for line in output.split('\n'):
                line = line.strip()
                if line:
                    records.append(DnsRecord(
                        name=domain,
                        type=record_type,
                        value=line
                    ))
            
            return DnsLookupResult(
                success=True,
                domain=domain,
                record_type=record_type,
                records=records,
                query_time_ms=0
            )
            
        except Exception as e:
            return DnsLookupResult(
                success=False,
                domain=domain,
                record_type=record_type,
                records=[],
                query_time_ms=0,
                error=str(e)
            )
    
    async def reverse_lookup(self, ip: str) -> DnsLookupResult:
        """
        Reverse DNS lookup (IP to hostname).
        
        Args:
            ip: IP address
            
        Returns:
            DnsLookupResult with PTR records
        """
        start_time = datetime.now()
        
        try:
            # Use socket for reverse lookup
            loop = asyncio.get_event_loop()
            hostname, _, _ = await loop.run_in_executor(
                None,
                lambda: socket.gethostbyaddr(ip)
            )
            
            return DnsLookupResult(
                success=True,
                domain=ip,
                record_type=RecordType.PTR,
                records=[DnsRecord(name=ip, type='PTR', value=hostname)],
                query_time_ms=(datetime.now() - start_time).total_seconds() * 1000
            )
            
        except socket.herror as e:
            return DnsLookupResult(
                success=False,
                domain=ip,
                record_type=RecordType.PTR,
                records=[],
                query_time_ms=(datetime.now() - start_time).total_seconds() * 1000,
                error=str(e)
            )
    
    async def lookup_all(self, domain: str) -> Dict[str, DnsLookupResult]:
        """
        Lookup all common record types for a domain.
        
        Args:
            domain: Domain name
            
        Returns:
            Dict mapping record type to result
        """
        record_types = [
            RecordType.A,
            RecordType.AAAA,
            RecordType.MX,
            RecordType.NS,
            RecordType.TXT,
            RecordType.CNAME
        ]
        
        results = {}
        
        tasks = [self.lookup(domain, rt) for rt in record_types]
        lookup_results = await asyncio.gather(*tasks, return_exceptions=True)
        
        for rt, result in zip(record_types, lookup_results):
            if isinstance(result, Exception):
                results[rt] = DnsLookupResult(
                    success=False,
                    domain=domain,
                    record_type=rt,
                    records=[],
                    query_time_ms=0,
                    error=str(result)
                )
            else:
                results[rt] = result
        
        return results
    
    async def check_propagation(
        self,
        domain: str,
        record_type: str = RecordType.A,
        expected_value: Optional[str] = None,
        nameservers: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Check DNS propagation across multiple nameservers.
        
        Args:
            domain: Domain to check
            record_type: Record type
            expected_value: Expected value to match
            nameservers: List of nameservers to check
            
        Returns:
            Propagation status
        """
        if nameservers is None:
            nameservers = [
                '8.8.8.8',      # Google
                '8.8.4.4',      # Google
                '1.1.1.1',      # Cloudflare
                '1.0.0.1',      # Cloudflare
                '208.67.222.222',  # OpenDNS
                '208.67.220.220',  # OpenDNS
                '9.9.9.9',      # Quad9
            ]
        
        results = []
        propagated = 0
        
        for ns in nameservers:
            result = await self.lookup(domain, record_type, use_cache=False, nameserver=ns)
            
            values = [r.value for r in result.records]
            matches = expected_value is None or expected_value in values
            
            if matches and result.success:
                propagated += 1
            
            results.append({
                'nameserver': ns,
                'success': result.success,
                'values': values,
                'matches': matches,
                'query_time_ms': result.query_time_ms
            })
        
        return {
            'domain': domain,
            'record_type': record_type,
            'expected_value': expected_value,
            'propagation_percent': (propagated / len(nameservers)) * 100,
            'propagated': propagated,
            'total_checked': len(nameservers),
            'fully_propagated': propagated == len(nameservers),
            'results': results
        }
    
    async def get_nameservers(self, domain: str) -> List[str]:
        """Get nameservers for a domain."""
        result = await self.lookup(domain, RecordType.NS)
        return [r.value.rstrip('.') for r in result.records]
    
    async def get_mx_records(self, domain: str) -> List[Dict[str, Any]]:
        """Get MX records sorted by priority."""
        result = await self.lookup(domain, RecordType.MX)
        
        mx_records = [
            {'priority': r.priority or 0, 'server': r.value}
            for r in result.records
        ]
        
        return sorted(mx_records, key=lambda x: x['priority'])
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        return {
            'size': self._cache.size(),
            'max_size': self._cache.max_size,
            'default_ttl': self._cache.default_ttl
        }
    
    async def clear_cache(self) -> None:
        """Clear DNS cache."""
        await self._cache.clear()
    
    async def run(self, context: ToolContext, **kwargs) -> ToolResult:
        """
        Execute DNS operation.
        
        Supported operations:
        - lookup: Lookup DNS records
        - reverse: Reverse lookup
        - all: Lookup all record types
        - propagation: Check propagation
        - mx: Get MX records
        - ns: Get nameservers
        - cache_stats: Get cache stats
        - clear_cache: Clear cache
        """
        operation = kwargs.get('operation', 'lookup')
        
        try:
            if operation == 'lookup':
                domain = kwargs.get('domain') or kwargs.get('host')
                if not domain:
                    return ToolResult.fail(error="domain is required")
                
                result = await self.lookup(
                    domain,
                    record_type=kwargs.get('type', RecordType.A),
                    use_cache=kwargs.get('cache', True),
                    nameserver=kwargs.get('nameserver')
                )
                
                if result.success:
                    return ToolResult.ok(
                        data=result.to_dict(),
                        message=f"Found {len(result.records)} {result.record_type} records"
                    )
                else:
                    return ToolResult.fail(error=result.error)
                    
            elif operation == 'reverse':
                ip = kwargs.get('ip')
                if not ip:
                    return ToolResult.fail(error="ip is required")
                
                result = await self.reverse_lookup(ip)
                
                if result.success:
                    return ToolResult.ok(data=result.to_dict())
                else:
                    return ToolResult.fail(error=result.error)
                    
            elif operation == 'all':
                domain = kwargs.get('domain')
                if not domain:
                    return ToolResult.fail(error="domain is required")
                
                results = await self.lookup_all(domain)
                
                return ToolResult.ok(
                    data={
                        'domain': domain,
                        'records': {k: v.to_dict() for k, v in results.items()}
                    }
                )
                
            elif operation == 'propagation':
                domain = kwargs.get('domain')
                if not domain:
                    return ToolResult.fail(error="domain is required")
                
                result = await self.check_propagation(
                    domain,
                    record_type=kwargs.get('type', RecordType.A),
                    expected_value=kwargs.get('expected'),
                    nameservers=kwargs.get('nameservers')
                )
                
                return ToolResult.ok(
                    data=result,
                    message=f"Propagation: {result['propagation_percent']:.0f}%"
                )
                
            elif operation == 'mx':
                domain = kwargs.get('domain')
                if not domain:
                    return ToolResult.fail(error="domain is required")
                
                records = await self.get_mx_records(domain)
                
                return ToolResult.ok(
                    data={'domain': domain, 'mx_records': records}
                )
                
            elif operation == 'ns':
                domain = kwargs.get('domain')
                if not domain:
                    return ToolResult.fail(error="domain is required")
                
                nameservers = await self.get_nameservers(domain)
                
                return ToolResult.ok(
                    data={'domain': domain, 'nameservers': nameservers}
                )
                
            elif operation == 'cache_stats':
                return ToolResult.ok(data=self.get_cache_stats())
                
            elif operation == 'clear_cache':
                await self.clear_cache()
                return ToolResult.ok(message="Cache cleared")
                
            else:
                return ToolResult.fail(error=f"Unknown operation: {operation}")
                
        except Exception as e:
            logger.error(f"DnsTools error: {e}")
            return ToolResult.error(error=str(e))


# Create singleton
dns_tools = DnsTools()


def register():
    """Register DNS tools."""
    registry = get_registry()
    registry.register_tool(dns_tools)