"""
HTTP Client Tool - Make HTTP requests safely.
Supports GET, POST, PUT, DELETE, PATCH with full configuration.
"""

import asyncio
import aiohttp
import ssl
import json
from pathlib import Path
from typing import Optional, Dict, Any, List, Union
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
from urllib.parse import urljoin, urlparse
import logging

# Import from our tool system (matching existing structure)
import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from tools.base_tool import (
    BaseTool, ToolResult, ToolContext, ResultStatus,
    ToolCategory, ToolRisk
)
from tools.registry import get_registry

logger = logging.getLogger(__name__)


class HttpMethod(Enum):
    """HTTP methods."""
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    DELETE = "DELETE"
    PATCH = "PATCH"
    HEAD = "HEAD"
    OPTIONS = "OPTIONS"


class ContentType(Enum):
    """Content types."""
    JSON = "application/json"
    FORM = "application/x-www-form-urlencoded"
    MULTIPART = "multipart/form-data"
    TEXT = "text/plain"
    HTML = "text/html"
    XML = "application/xml"


@dataclass
class HttpResponse:
    """HTTP response data."""
    status_code: int
    headers: Dict[str, str]
    body: Optional[str]
    json_data: Optional[Any]
    url: str
    method: str
    elapsed_ms: float
    success: bool
    error: Optional[str] = None
    content_type: Optional[str] = None
    content_length: Optional[int] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'status_code': self.status_code,
            'headers': self.headers,
            'body': self.body[:1000] if self.body and len(self.body) > 1000 else self.body,
            'body_truncated': len(self.body) > 1000 if self.body else False,
            'json_data': self.json_data,
            'url': self.url,
            'method': self.method,
            'elapsed_ms': self.elapsed_ms,
            'success': self.success,
            'error': self.error,
            'content_type': self.content_type,
            'content_length': self.content_length
        }


@dataclass
class HttpClientConfig:
    """Configuration for HTTP client."""
    # Timeouts
    connect_timeout: float = 10.0
    read_timeout: float = 30.0
    total_timeout: float = 60.0
    
    # Limits
    max_response_size: int = 50 * 1024 * 1024  # 50MB
    max_redirects: int = 10
    
    # SSL
    verify_ssl: bool = True
    ssl_cert_path: Optional[str] = None
    
    # Retry
    retry_count: int = 3
    retry_delay: float = 1.0
    retry_on_status: List[int] = field(default_factory=lambda: [502, 503, 504])
    
    # Headers
    default_headers: Dict[str, str] = field(default_factory=lambda: {
        'User-Agent': 'AutonomousAgent/1.0'
    })
    
    # Blocked domains (security)
    blocked_domains: List[str] = field(default_factory=lambda: [
        'localhost',
        '127.0.0.1',
        '0.0.0.0',
        '169.254.169.254',  # AWS metadata
        'metadata.google.internal',  # GCP metadata
    ])
    
    # Allowed schemes
    allowed_schemes: List[str] = field(default_factory=lambda: ['http', 'https'])


class HttpClientTool(BaseTool):
    """
    HTTP client tool for making web requests.
    
    Features:
    - All HTTP methods (GET, POST, PUT, DELETE, PATCH, HEAD, OPTIONS)
    - JSON and form data support
    - File uploads
    - Custom headers and authentication
    - SSL/TLS configuration
    - Retry logic
    - Response caching
    - Request/response logging
    """
    
    def __init__(self, config: Optional[HttpClientConfig] = None):
        super().__init__(
            name="http_client",
            description="Make HTTP requests (GET, POST, PUT, DELETE, etc.)",
            category=ToolCategory.NETWORK,
            risk=ToolRisk.MEDIUM,
            requires_confirmation=False,
            timeout=120.0,
            version="1.0.0"
        )
        self.config = config or HttpClientConfig()
        self._session: Optional[aiohttp.ClientSession] = None
    
    async def initialize(self) -> bool:
        """Initialize HTTP session."""
        if self._session is None or self._session.closed:
            timeout = aiohttp.ClientTimeout(
                connect=self.config.connect_timeout,
                sock_read=self.config.read_timeout,
                total=self.config.total_timeout
            )
            
            # SSL context
            ssl_context = None
            if not self.config.verify_ssl:
                ssl_context = ssl.create_default_context()
                ssl_context.check_hostname = False
                ssl_context.verify_mode = ssl.CERT_NONE
            
            connector = aiohttp.TCPConnector(
                ssl=ssl_context,
                limit=100,
                limit_per_host=10
            )
            
            self._session = aiohttp.ClientSession(
                timeout=timeout,
                connector=connector,
                headers=self.config.default_headers
            )
        
        self._initialized = True
        return True
    
    async def cleanup(self) -> None:
        """Close HTTP session."""
        if self._session and not self._session.closed:
            await self._session.close()
            self._session = None
    
    def _validate_url(self, url: str) -> tuple[bool, Optional[str]]:
        """Validate URL for security."""
        try:
            parsed = urlparse(url)
            
            # Check scheme
            if parsed.scheme not in self.config.allowed_schemes:
                return False, f"Scheme not allowed: {parsed.scheme}"
            
            # Check domain
            hostname = parsed.hostname or ''
            for blocked in self.config.blocked_domains:
                if hostname == blocked or hostname.endswith('.' + blocked):
                    return False, f"Domain blocked: {hostname}"
            
            # Check for IP addresses in blocked ranges
            if hostname.startswith('10.') or hostname.startswith('192.168.'):
                return False, f"Private IP range blocked: {hostname}"
            
            return True, None
            
        except Exception as e:
            return False, f"Invalid URL: {e}"
    
    async def request(
        self,
        url: str,
        method: HttpMethod = HttpMethod.GET,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, str]] = None,
        data: Optional[Union[Dict, str, bytes]] = None,
        json_data: Optional[Dict] = None,
        auth: Optional[tuple] = None,  # (username, password)
        bearer_token: Optional[str] = None,
        timeout: Optional[float] = None,
        follow_redirects: bool = True,
        verify_ssl: Optional[bool] = None
    ) -> HttpResponse:
        """
        Make an HTTP request.
        
        Args:
            url: Target URL
            method: HTTP method
            headers: Custom headers
            params: Query parameters
            data: Request body (form data or raw)
            json_data: JSON body
            auth: Basic auth credentials
            bearer_token: Bearer token for auth
            timeout: Request timeout
            follow_redirects: Follow redirects
            verify_ssl: Verify SSL certificates
            
        Returns:
            HttpResponse with result
        """
        start_time = datetime.now()
        
        # Validate URL
        is_valid, error = self._validate_url(url)
        if not is_valid:
            return HttpResponse(
                status_code=0,
                headers={},
                body=None,
                json_data=None,
                url=url,
                method=method.value,
                elapsed_ms=0,
                success=False,
                error=error
            )
        
        # Ensure session
        await self.initialize()
        
        # Build headers
        request_headers = dict(headers or {})
        
        if bearer_token:
            request_headers['Authorization'] = f'Bearer {bearer_token}'
        
        if json_data and 'Content-Type' not in request_headers:
            request_headers['Content-Type'] = ContentType.JSON.value
        
        # Build auth
        basic_auth = None
        if auth:
            basic_auth = aiohttp.BasicAuth(auth[0], auth[1])
        
        # SSL settings
        ssl_setting = self.config.verify_ssl if verify_ssl is None else verify_ssl
        
        # Timeout
        request_timeout = timeout or self.config.total_timeout
        
        try:
            async with self._session.request(
                method=method.value,
                url=url,
                headers=request_headers,
                params=params,
                data=data,
                json=json_data,
                auth=basic_auth,
                allow_redirects=follow_redirects,
                max_redirects=self.config.max_redirects,
                ssl=ssl_setting,
                timeout=aiohttp.ClientTimeout(total=request_timeout)
            ) as response:
                # Read response
                content_type = response.headers.get('Content-Type', '')
                content_length = response.headers.get('Content-Length')
                
                # Check size limit
                if content_length and int(content_length) > self.config.max_response_size:
                    return HttpResponse(
                        status_code=response.status,
                        headers=dict(response.headers),
                        body=None,
                        json_data=None,
                        url=str(response.url),
                        method=method.value,
                        elapsed_ms=(datetime.now() - start_time).total_seconds() * 1000,
                        success=False,
                        error=f"Response too large: {content_length} bytes",
                        content_type=content_type
                    )
                
                # Read body
                body = await response.text()
                
                # Parse JSON if applicable
                json_body = None
                if 'application/json' in content_type:
                    try:
                        json_body = await response.json()
                    except:
                        pass
                
                elapsed = (datetime.now() - start_time).total_seconds() * 1000
                
                return HttpResponse(
                    status_code=response.status,
                    headers=dict(response.headers),
                    body=body,
                    json_data=json_body,
                    url=str(response.url),
                    method=method.value,
                    elapsed_ms=elapsed,
                    success=200 <= response.status < 300,
                    content_type=content_type,
                    content_length=int(content_length) if content_length else len(body)
                )
                
        except aiohttp.ClientSSLError as e:
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            return HttpResponse(
                status_code=0,
                headers={},
                body=None,
                json_data=None,
                url=url,
                method=method.value,
                elapsed_ms=elapsed,
                success=False,
                error=f"SSL error: {e}"
            )
            
        except asyncio.TimeoutError:
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            return HttpResponse(
                status_code=0,
                headers={},
                body=None,
                json_data=None,
                url=url,
                method=method.value,
                elapsed_ms=elapsed,
                success=False,
                error=f"Request timed out after {request_timeout}s"
            )
            
        except aiohttp.ClientError as e:
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            return HttpResponse(
                status_code=0,
                headers={},
                body=None,
                json_data=None,
                url=url,
                method=method.value,
                elapsed_ms=elapsed,
                success=False,
                error=str(e)
            )
            
        except Exception as e:
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            logger.error(f"HTTP request error: {e}")
            return HttpResponse(
                status_code=0,
                headers={},
                body=None,
                json_data=None,
                url=url,
                method=method.value,
                elapsed_ms=elapsed,
                success=False,
                error=str(e)
            )
    
    async def get(self, url: str, **kwargs) -> HttpResponse:
        """Make GET request."""
        return await self.request(url, method=HttpMethod.GET, **kwargs)
    
    async def post(self, url: str, **kwargs) -> HttpResponse:
        """Make POST request."""
        return await self.request(url, method=HttpMethod.POST, **kwargs)
    
    async def put(self, url: str, **kwargs) -> HttpResponse:
        """Make PUT request."""
        return await self.request(url, method=HttpMethod.PUT, **kwargs)
    
    async def delete(self, url: str, **kwargs) -> HttpResponse:
        """Make DELETE request."""
        return await self.request(url, method=HttpMethod.DELETE, **kwargs)
    
    async def patch(self, url: str, **kwargs) -> HttpResponse:
        """Make PATCH request."""
        return await self.request(url, method=HttpMethod.PATCH, **kwargs)
    
    async def head(self, url: str, **kwargs) -> HttpResponse:
        """Make HEAD request."""
        return await self.request(url, method=HttpMethod.HEAD, **kwargs)
    
    async def download(
        self,
        url: str,
        destination: str,
        chunk_size: int = 8192,
        headers: Optional[Dict[str, str]] = None
    ) -> Dict[str, Any]:
        """
        Download file from URL.
        
        Args:
            url: File URL
            destination: Local path to save
            chunk_size: Download chunk size
            headers: Custom headers
            
        Returns:
            Download result
        """
        start_time = datetime.now()
        
        # Validate URL
        is_valid, error = self._validate_url(url)
        if not is_valid:
            return {'success': False, 'error': error}
        
        await self.initialize()
        
        try:
            dest_path = Path(destination)
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            
            async with self._session.get(url, headers=headers) as response:
                if response.status != 200:
                    return {
                        'success': False,
                        'error': f"HTTP {response.status}",
                        'status_code': response.status
                    }
                
                total_size = int(response.headers.get('Content-Length', 0))
                downloaded = 0
                
                async with aiofiles.open(dest_path, 'wb') as f:
                    async for chunk in response.content.iter_chunked(chunk_size):
                        await f.write(chunk)
                        downloaded += len(chunk)
                
                elapsed = (datetime.now() - start_time).total_seconds()
                
                return {
                    'success': True,
                    'path': str(dest_path),
                    'size': downloaded,
                    'elapsed_seconds': elapsed,
                    'speed_mbps': (downloaded / 1024 / 1024) / elapsed if elapsed > 0 else 0
                }
                
        except Exception as e:
            logger.error(f"Download error: {e}")
            return {'success': False, 'error': str(e)}
    
    async def run(self, context: ToolContext, **kwargs) -> ToolResult:
        """
        Execute HTTP operation.
        
        Supported operations via 'operation' parameter:
        - request: Make HTTP request
        - get/post/put/delete/patch: Shorthand methods
        - download: Download file
        """
        operation = kwargs.get('operation', 'request')
        url = kwargs.get('url')
        
        if not url:
            return ToolResult.fail(
                error="url is required",
                message="Missing URL parameter"
            )
        
        start_time = datetime.now()
        
        try:
            if operation == 'download':
                destination = kwargs.get('destination')
                if not destination:
                    return ToolResult.fail(error="destination is required for download")
                
                result = await self.download(
                    url,
                    destination,
                    chunk_size=kwargs.get('chunk_size', 8192),
                    headers=kwargs.get('headers')
                )
                
                if result['success']:
                    return ToolResult.ok(data=result, message="Download complete")
                else:
                    return ToolResult.fail(error=result.get('error', 'Download failed'))
            
            # Determine method
            method_map = {
                'get': HttpMethod.GET,
                'post': HttpMethod.POST,
                'put': HttpMethod.PUT,
                'delete': HttpMethod.DELETE,
                'patch': HttpMethod.PATCH,
                'head': HttpMethod.HEAD,
                'options': HttpMethod.OPTIONS,
                'request': HttpMethod.GET
            }
            
            method_str = kwargs.get('method', operation).lower()
            method = method_map.get(method_str, HttpMethod.GET)
            
            # Make request
            response = await self.request(
                url=url,
                method=method,
                headers=kwargs.get('headers'),
                params=kwargs.get('params'),
                data=kwargs.get('data'),
                json_data=kwargs.get('json') or kwargs.get('json_data'),
                auth=kwargs.get('auth'),
                bearer_token=kwargs.get('bearer_token') or kwargs.get('token'),
                timeout=kwargs.get('timeout'),
                follow_redirects=kwargs.get('follow_redirects', True),
                verify_ssl=kwargs.get('verify_ssl')
            )
            
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            
            result = ToolResult(
                success=response.success,
                status=ResultStatus.SUCCESS if response.success else ResultStatus.ERROR,
                data=response.to_dict(),
                error=response.error,
                message=f"{method.value} {url} -> {response.status_code}",
                execution_time_ms=elapsed
            )
            result.tool_name = self.name
            return result
            
        except Exception as e:
            logger.error(f"HttpClientTool error: {e}")
            return ToolResult.error(error=str(e), message="HTTP request failed")


# Create singleton instance
http_client = HttpClientTool()


# Register the tool
def register():
    """Register HTTP client tool."""
    registry = get_registry()
    registry.register_tool(http_client)


# Need aiofiles for download
try:
    import aiofiles
except ImportError:
    logger.warning("aiofiles not installed, download feature may not work")