"""
Network Tools - Network diagnostics and utilities.
Ping, port scanning, interface info, and more.
"""

import asyncio
import socket
import struct
from pathlib import Path
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import logging
import re

import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from tools.base_tool import (
    BaseTool, ToolResult, ToolContext, ResultStatus,
    ToolCategory, ToolRisk
)
from tools.registry import get_registry

logger = logging.getLogger(__name__)


@dataclass
class PingResult:
    """Result of ping operation."""
    host: str
    ip: Optional[str]
    packets_sent: int
    packets_received: int
    packet_loss_percent: float
    min_ms: float
    avg_ms: float
    max_ms: float
    success: bool
    error: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'host': self.host,
            'ip': self.ip,
            'packets_sent': self.packets_sent,
            'packets_received': self.packets_received,
            'packet_loss_percent': self.packet_loss_percent,
            'min_ms': self.min_ms,
            'avg_ms': self.avg_ms,
            'max_ms': self.max_ms,
            'success': self.success,
            'error': self.error
        }


@dataclass
class PortScanResult:
    """Result of port scan."""
    host: str
    ports_scanned: int
    open_ports: List[Dict[str, Any]]
    closed_ports: int
    filtered_ports: int
    scan_time_ms: float
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'host': self.host,
            'ports_scanned': self.ports_scanned,
            'open_ports': self.open_ports,
            'open_count': len(self.open_ports),
            'closed_ports': self.closed_ports,
            'filtered_ports': self.filtered_ports,
            'scan_time_ms': self.scan_time_ms
        }


@dataclass
class NetworkInterface:
    """Network interface information."""
    name: str
    ip_address: Optional[str]
    netmask: Optional[str]
    broadcast: Optional[str]
    mac_address: Optional[str]
    is_up: bool
    is_loopback: bool
    mtu: Optional[int]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'ip_address': self.ip_address,
            'netmask': self.netmask,
            'broadcast': self.broadcast,
            'mac_address': self.mac_address,
            'is_up': self.is_up,
            'is_loopback': self.is_loopback,
            'mtu': self.mtu
        }


# Common ports and their services
COMMON_PORTS = {
    21: 'ftp',
    22: 'ssh',
    23: 'telnet',
    25: 'smtp',
    53: 'dns',
    80: 'http',
    110: 'pop3',
    143: 'imap',
    443: 'https',
    445: 'smb',
    993: 'imaps',
    995: 'pop3s',
    3306: 'mysql',
    3389: 'rdp',
    5432: 'postgresql',
    5900: 'vnc',
    6379: 'redis',
    8080: 'http-alt',
    8443: 'https-alt',
    27017: 'mongodb'
}


class NetworkTools(BaseTool):
    """
    Network diagnostics and utilities tool.
    
    Features:
    - Ping hosts
    - Port scanning
    - Network interface info
    - DNS resolution
    - Connectivity checks
    - Traceroute
    """
    
    def __init__(self):
        super().__init__(
            name="network_tools",
            description="Network diagnostics (ping, port scan, interfaces)",
            category=ToolCategory.NETWORK,
            risk=ToolRisk.LOW,
            requires_confirmation=False,
            timeout=120.0,
            version="1.0.0"
        )
        
        # Check for psutil
        self._has_psutil = False
        try:
            import psutil
            self._has_psutil = True
        except ImportError:
            logger.info("psutil not available for network info")
    
    async def ping(
        self,
        host: str,
        count: int = 4,
        timeout: float = 5.0
    ) -> PingResult:
        """
        Ping a host.
        
        Args:
            host: Hostname or IP
            count: Number of pings
            timeout: Timeout per ping
            
        Returns:
            PingResult with statistics
        """
        # Resolve hostname
        try:
            ip = socket.gethostbyname(host)
        except socket.gaierror as e:
            return PingResult(
                host=host,
                ip=None,
                packets_sent=0,
                packets_received=0,
                packet_loss_percent=100,
                min_ms=0,
                avg_ms=0,
                max_ms=0,
                success=False,
                error=f"DNS resolution failed: {e}"
            )
        
        # Use system ping command
        cmd = f"ping -c {count} -W {int(timeout)} {host}"
        
        try:
            process = await asyncio.create_subprocess_shell(
                cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await asyncio.wait_for(
                process.communicate(),
                timeout=timeout * count + 5
            )
            
            output = stdout.decode('utf-8', errors='replace')
            
            # Parse output
            times = []
            for line in output.split('\n'):
                # Look for time=X.X ms
                match = re.search(r'time[=<](\d+\.?\d*)\s*ms', line)
                if match:
                    times.append(float(match.group(1)))
            
            # Parse summary
            packets_sent = count
            packets_received = len(times)
            
            # Look for packet loss
            loss_match = re.search(r'(\d+\.?\d*)%\s*packet loss', output)
            if loss_match:
                packet_loss = float(loss_match.group(1))
            else:
                packet_loss = ((packets_sent - packets_received) / packets_sent) * 100 if packets_sent > 0 else 100
            
            return PingResult(
                host=host,
                ip=ip,
                packets_sent=packets_sent,
                packets_received=packets_received,
                packet_loss_percent=packet_loss,
                min_ms=min(times) if times else 0,
                avg_ms=sum(times) / len(times) if times else 0,
                max_ms=max(times) if times else 0,
                success=packets_received > 0
            )
            
        except asyncio.TimeoutError:
            return PingResult(
                host=host,
                ip=ip,
                packets_sent=count,
                packets_received=0,
                packet_loss_percent=100,
                min_ms=0,
                avg_ms=0,
                max_ms=0,
                success=False,
                error="Ping timed out"
            )
        except Exception as e:
            return PingResult(
                host=host,
                ip=ip,
                packets_sent=count,
                packets_received=0,
                packet_loss_percent=100,
                min_ms=0,
                avg_ms=0,
                max_ms=0,
                success=False,
                error=str(e)
            )
    
    async def check_port(
        self,
        host: str,
        port: int,
        timeout: float = 3.0
    ) -> Tuple[bool, Optional[str]]:
        """
        Check if a port is open.
        
        Returns:
            Tuple of (is_open, banner/error)
        """
        try:
            # Resolve hostname
            ip = socket.gethostbyname(host)
            
            # Try to connect
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(ip, port),
                timeout=timeout
            )
            
            # Try to grab banner
            banner = None
            try:
                writer.write(b'\r\n')
                await writer.drain()
                data = await asyncio.wait_for(reader.read(1024), timeout=2.0)
                if data:
                    banner = data.decode('utf-8', errors='replace').strip()[:100]
            except:
                pass
            
            writer.close()
            await writer.wait_closed()
            
            return True, banner
            
        except asyncio.TimeoutError:
            return False, "timeout"
        except ConnectionRefusedError:
            return False, "refused"
        except Exception as e:
            return False, str(e)
    
    async def scan_ports(
        self,
        host: str,
        ports: Optional[List[int]] = None,
        port_range: Optional[Tuple[int, int]] = None,
        timeout: float = 2.0,
        concurrency: int = 50
    ) -> PortScanResult:
        """
        Scan ports on a host.
        
        Args:
            host: Target host
            ports: List of specific ports
            port_range: Tuple of (start, end) range
            timeout: Timeout per port
            concurrency: Max concurrent scans
            
        Returns:
            PortScanResult with findings
        """
        start_time = datetime.now()
        
        # Determine ports to scan
        if ports:
            ports_to_scan = ports
        elif port_range:
            ports_to_scan = list(range(port_range[0], port_range[1] + 1))
        else:
            # Default: common ports
            ports_to_scan = list(COMMON_PORTS.keys())
        
        open_ports = []
        closed_count = 0
        filtered_count = 0
        
        # Semaphore for concurrency control
        semaphore = asyncio.Semaphore(concurrency)
        
        async def scan_single(port: int):
            nonlocal closed_count, filtered_count
            
            async with semaphore:
                is_open, result = await self.check_port(host, port, timeout)
                
                if is_open:
                    service = COMMON_PORTS.get(port, 'unknown')
                    open_ports.append({
                        'port': port,
                        'service': service,
                        'banner': result
                    })
                elif result == 'refused':
                    closed_count += 1
                else:
                    filtered_count += 1
        
        # Scan all ports
        tasks = [scan_single(port) for port in ports_to_scan]
        await asyncio.gather(*tasks, return_exceptions=True)
        
        elapsed = (datetime.now() - start_time).total_seconds() * 1000
        
        # Sort open ports
        open_ports.sort(key=lambda x: x['port'])
        
        return PortScanResult(
            host=host,
            ports_scanned=len(ports_to_scan),
            open_ports=open_ports,
            closed_ports=closed_count,
            filtered_ports=filtered_count,
            scan_time_ms=elapsed
        )
    
    async def get_interfaces(self) -> List[NetworkInterface]:
        """Get network interface information."""
        interfaces = []
        
        if self._has_psutil:
            import psutil
            
            addrs = psutil.net_if_addrs()
            stats = psutil.net_if_stats()
            
            for name, addr_list in addrs.items():
                ip_address = None
                netmask = None
                broadcast = None
                mac_address = None
                
                for addr in addr_list:
                    if addr.family == socket.AF_INET:
                        ip_address = addr.address
                        netmask = addr.netmask
                        broadcast = addr.broadcast
                    elif addr.family == socket.AF_PACKET if hasattr(socket, 'AF_PACKET') else -1:
                        mac_address = addr.address
                
                stat = stats.get(name)
                
                interfaces.append(NetworkInterface(
                    name=name,
                    ip_address=ip_address,
                    netmask=netmask,
                    broadcast=broadcast,
                    mac_address=mac_address,
                    is_up=stat.isup if stat else False,
                    is_loopback=name.startswith('lo'),
                    mtu=stat.mtu if stat else None
                ))
        else:
            # Fallback using ip command
            try:
                process = await asyncio.create_subprocess_shell(
                    "ip -o addr show",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout, _ = await process.communicate()
                output = stdout.decode('utf-8', errors='replace')
                
                for line in output.split('\n'):
                    if not line.strip():
                        continue
                    
                    parts = line.split()
                    if len(parts) >= 4:
                        name = parts[1].rstrip(':')
                        
                        # Find inet address
                        ip_address = None
                        for i, part in enumerate(parts):
                            if part == 'inet':
                                ip_address = parts[i + 1].split('/')[0]
                                break
                        
                        interfaces.append(NetworkInterface(
                            name=name,
                            ip_address=ip_address,
                            netmask=None,
                            broadcast=None,
                            mac_address=None,
                            is_up=True,
                            is_loopback=name.startswith('lo'),
                            mtu=None
                        ))
                        
            except Exception as e:
                logger.warning(f"Failed to get interfaces: {e}")
        
        return interfaces
    
    async def resolve_dns(
        self,
        hostname: str,
        record_type: str = 'A'
    ) -> Dict[str, Any]:
        """
        Resolve DNS for a hostname.
        
        Args:
            hostname: Hostname to resolve
            record_type: DNS record type (A, AAAA, MX, etc.)
            
        Returns:
            DNS resolution result
        """
        try:
            if record_type == 'A':
                ip = socket.gethostbyname(hostname)
                return {
                    'success': True,
                    'hostname': hostname,
                    'type': 'A',
                    'addresses': [ip]
                }
            elif record_type == 'AAAA':
                # Get IPv6
                infos = socket.getaddrinfo(hostname, None, socket.AF_INET6)
                addresses = list(set(info[4][0] for info in infos))
                return {
                    'success': True,
                    'hostname': hostname,
                    'type': 'AAAA',
                    'addresses': addresses
                }
            else:
                # Use dig for other record types
                process = await asyncio.create_subprocess_shell(
                    f"dig +short {hostname} {record_type}",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout, _ = await process.communicate()
                records = stdout.decode().strip().split('\n')
                
                return {
                    'success': True,
                    'hostname': hostname,
                    'type': record_type,
                    'records': [r for r in records if r]
                }
                
        except socket.gaierror as e:
            return {
                'success': False,
                'hostname': hostname,
                'error': str(e)
            }
        except Exception as e:
            return {
                'success': False,
                'hostname': hostname,
                'error': str(e)
            }
    
    async def check_connectivity(
        self,
        hosts: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Check internet connectivity.
        
        Args:
            hosts: Hosts to check (default: common DNS servers)
            
        Returns:
            Connectivity status
        """
        if hosts is None:
            hosts = [
                '8.8.8.8',      # Google DNS
                '1.1.1.1',      # Cloudflare DNS
                '208.67.222.222'  # OpenDNS
            ]
        
        results = []
        has_connectivity = False
        
        for host in hosts:
            is_open, _ = await self.check_port(host, 53, timeout=3.0)
            results.append({
                'host': host,
                'reachable': is_open
            })
            if is_open:
                has_connectivity = True
        
        return {
            'connected': has_connectivity,
            'checks': results
        }
    
    async def get_public_ip(self) -> Dict[str, Any]:
        """Get public IP address."""
        try:
            # Import http client
            from tools.network_ops.http_client import http_client
            
            await http_client.initialize()
            
            response = await http_client.get(
                'https://api.ipify.org?format=json',
                timeout=10.0
            )
            
            if response.success and response.json_data:
                return {
                    'success': True,
                    'ip': response.json_data.get('ip'),
                    'source': 'ipify.org'
                }
            
            return {
                'success': False,
                'error': response.error or 'Failed to get IP'
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    async def run(self, context: ToolContext, **kwargs) -> ToolResult:
        """
        Execute network operation.
        
        Supported operations:
        - ping: Ping a host
        - scan: Scan ports
        - check_port: Check single port
        - interfaces: Get network interfaces
        - dns: DNS resolution
        - connectivity: Check connectivity
        - public_ip: Get public IP
        """
        operation = kwargs.get('operation', 'ping')
        
        start_time = datetime.now()
        
        try:
            if operation == 'ping':
                host = kwargs.get('host')
                if not host:
                    return ToolResult.fail(error="host is required")
                
                result = await self.ping(
                    host,
                    count=kwargs.get('count', 4),
                    timeout=kwargs.get('timeout', 5.0)
                )
                
                return ToolResult(
                    success=result.success,
                    status=ResultStatus.SUCCESS if result.success else ResultStatus.ERROR,
                    data=result.to_dict(),
                    message=f"Ping {host}: {result.avg_ms:.1f}ms avg" if result.success else result.error
                )
                
            elif operation == 'scan':
                host = kwargs.get('host')
                if not host:
                    return ToolResult.fail(error="host is required")
                
                result = await self.scan_ports(
                    host,
                    ports=kwargs.get('ports'),
                    port_range=kwargs.get('port_range'),
                    timeout=kwargs.get('timeout', 2.0),
                    concurrency=kwargs.get('concurrency', 50)
                )
                
                return ToolResult.ok(
                    data=result.to_dict(),
                    message=f"Found {len(result.open_ports)} open ports on {host}"
                )
                
            elif operation == 'check_port':
                host = kwargs.get('host')
                port = kwargs.get('port')
                
                if not host or not port:
                    return ToolResult.fail(error="host and port are required")
                
                is_open, banner = await self.check_port(
                    host,
                    int(port),
                    timeout=kwargs.get('timeout', 3.0)
                )
                
                return ToolResult.ok(
                    data={
                        'host': host,
                        'port': port,
                        'open': is_open,
                        'banner': banner
                    },
                    message=f"Port {port} is {'open' if is_open else 'closed'}"
                )
                
            elif operation == 'interfaces':
                interfaces = await self.get_interfaces()
                
                return ToolResult.ok(
                    data={
                        'count': len(interfaces),
                        'interfaces': [i.to_dict() for i in interfaces]
                    }
                )
                
            elif operation == 'dns':
                hostname = kwargs.get('hostname') or kwargs.get('host')
                if not hostname:
                    return ToolResult.fail(error="hostname is required")
                
                result = await self.resolve_dns(
                    hostname,
                    record_type=kwargs.get('type', 'A')
                )
                
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('error', 'DNS resolution failed'))
                    
            elif operation == 'connectivity':
                result = await self.check_connectivity(
                    hosts=kwargs.get('hosts')
                )
                
                return ToolResult.ok(
                    data=result,
                    message="Connected" if result['connected'] else "No connectivity"
                )
                
            elif operation == 'public_ip':
                result = await self.get_public_ip()
                
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('error'))
                    
            else:
                return ToolResult.fail(error=f"Unknown operation: {operation}")
                
        except Exception as e:
            logger.error(f"NetworkTools error: {e}")
            return ToolResult.error(error=str(e))


# Create singleton
network_tools = NetworkTools()


def register():
    """Register network tools."""
    registry = get_registry()
    registry.register_tool(network_tools)