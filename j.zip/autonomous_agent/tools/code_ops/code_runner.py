"""
═══════════════════════════════════════════════════════════════════════════════════════
CODE RUNNER - SAFE CODE EXECUTION ENGINE
═══════════════════════════════════════════════════════════════════════════════════════
Executes code in multiple languages safely:
- Python (with sandbox)
- JavaScript/Node.js
- Shell/Bash
- SQL queries
- Support for custom interpreters
- Timeout enforcement
- Output capture
- Resource limiting
"""

import asyncio
import logging
import tempfile
import shutil
import os
import sys
import signal
import subprocess
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Union, Callable
from pathlib import Path
import json
import re

logger = logging.getLogger(__name__)


class Language(Enum):
    """Supported programming languages."""
    PYTHON = "python"
    PYTHON3 = "python3"
    JAVASCRIPT = "javascript"
    NODEJS = "nodejs"
    BASH = "bash"
    SH = "sh"
    ZSH = "zsh"
    RUBY = "ruby"
    PERL = "perl"
    PHP = "php"
    LUA = "lua"
    SQL = "sql"
    SQLITE = "sqlite"
    
    @classmethod
    def from_string(cls, name: str) -> "Language":
        """Get language from string."""
        name_lower = name.lower().strip()
        
        # Handle aliases
        aliases = {
            "py": cls.PYTHON,
            "py3": cls.PYTHON3,
            "node": cls.NODEJS,
            "js": cls.JAVASCRIPT,
            "shell": cls.BASH,
        }
        
        if name_lower in aliases:
            return aliases[name_lower]
        
        for lang in cls:
            if lang.value == name_lower:
                return lang
        
        raise ValueError(f"Unsupported language: {name}")
    
    @classmethod
    def from_extension(cls, ext: str) -> "Language":
        """Get language from file extension."""
        ext = ext.lower().lstrip('.')
        
        mapping = {
            "py": cls.PYTHON,
            "js": cls.JAVASCRIPT,
            "sh": cls.BASH,
            "bash": cls.BASH,
            "rb": cls.RUBY,
            "pl": cls.PERL,
            "php": cls.PHP,
            "lua": cls.LUA,
            "sql": cls.SQL,
        }
        
        if ext in mapping:
            return mapping[ext]
        
        raise ValueError(f"Unknown extension: {ext}")


class ExecutionStatus(Enum):
    """Status of code execution."""
    SUCCESS = "success"
    FAILED = "failed"
    TIMEOUT = "timeout"
    ERROR = "error"
    KILLED = "killed"
    SANDBOX_VIOLATION = "sandbox_violation"


@dataclass
class ExecutionConfig:
    """Configuration for code execution."""
    timeout_seconds: int = 30
    max_memory_mb: int = 256
    max_output_bytes: int = 1024 * 1024  # 1MB
    allow_network: bool = False
    allow_filesystem: bool = True
    working_directory: Optional[Path] = None
    environment: Dict[str, str] = field(default_factory=dict)
    stdin_data: Optional[str] = None
    capture_stderr: bool = True


@dataclass
class ExecutionResult:
    """Result of code execution."""
    status: ExecutionStatus
    exit_code: int
    stdout: str
    stderr: str
    execution_time_ms: float
    language: str
    code_hash: str = ""
    memory_used_mb: float = 0.0
    truncated: bool = False
    error_message: Optional[str] = None
    line_of_error: Optional[int] = None
    
    @property
    def success(self) -> bool:
        return self.status == ExecutionStatus.SUCCESS and self.exit_code == 0
    
    @property
    def output(self) -> str:
        """Combined output."""
        if self.stderr and self.stderr.strip():
            return f"{self.stdout}\n--- STDERR ---\n{self.stderr}"
        return self.stdout
    
    def format_error(self) -> str:
        """Format error for display."""
        if not self.error_message:
            return self.stderr or "Unknown error"
        
        msg = self.error_message
        if self.line_of_error:
            msg = f"Line {self.line_of_error}: {msg}"
        return msg


class LanguageRunner:
    """Base class for language-specific runners."""
    
    def __init__(self, language: Language):
        self.language = language
        self.interpreter_path: Optional[str] = None
        self.file_extension: str = ""
        self._detect_interpreter()
    
    def _detect_interpreter(self) -> None:
        """Detect interpreter path."""
        raise NotImplementedError
    
    @property
    def available(self) -> bool:
        return self.interpreter_path is not None
    
    async def run(
        self,
        code: str,
        config: ExecutionConfig
    ) -> ExecutionResult:
        """Run code and return result."""
        raise NotImplementedError
    
    def _create_temp_file(self, code: str, suffix: str) -> Path:
        """Create temporary file with code."""
        fd, path = tempfile.mkstemp(suffix=suffix)
        os.write(fd, code.encode('utf-8'))
        os.close(fd)
        return Path(path)
    
    def _parse_error(self, stderr: str) -> tuple[Optional[str], Optional[int]]:
        """Parse error message and line number from stderr."""
        return None, None


class PythonRunner(LanguageRunner):
    """Python code runner with sandbox support."""
    
    def __init__(self):
        super().__init__(Language.PYTHON)
        self.file_extension = ".py"
        
        # Restricted modules
        self._blocked_modules = {
            'os', 'subprocess', 'shutil', 'sys', 'socket',
            'urllib', 'requests', 'http', 'ftplib', 'smtplib',
            'ctypes', 'multiprocessing', '__builtins__'
        }
    
    def _detect_interpreter(self) -> None:
        """Detect Python interpreter."""
        for cmd in ['python3', 'python']:
            path = shutil.which(cmd)
            if path:
                self.interpreter_path = path
                break
    
    async def run(
        self,
        code: str,
        config: ExecutionConfig
    ) -> ExecutionResult:
        """Run Python code."""
        start_time = datetime.now()
        
        if not self.available:
            return ExecutionResult(
                status=ExecutionStatus.ERROR,
                exit_code=-1,
                stdout="",
                stderr="Python interpreter not found",
                execution_time_ms=0,
                language=self.language.value
            )
        
        # Create temp file
        temp_file = self._create_temp_file(code, self.file_extension)
        
        try:
            # Build command
            cmd = [self.interpreter_path, '-u', str(temp_file)]
            
            # Setup environment
            env = os.environ.copy()
            env.update(config.environment)
            
            # Disable Python optimizations for better error messages
            env['PYTHONDONTWRITEBYTECODE'] = '1'
            
            # Run process
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                stdin=asyncio.subprocess.PIPE if config.stdin_data else None,
                cwd=str(config.working_directory) if config.working_directory else None,
                env=env
            )
            
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(
                        input=config.stdin_data.encode() if config.stdin_data else None
                    ),
                    timeout=config.timeout_seconds
                )
                
                status = ExecutionStatus.SUCCESS if process.returncode == 0 else ExecutionStatus.FAILED
                
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()
                
                return ExecutionResult(
                    status=ExecutionStatus.TIMEOUT,
                    exit_code=-1,
                    stdout="",
                    stderr=f"Execution timed out after {config.timeout_seconds}s",
                    execution_time_ms=config.timeout_seconds * 1000,
                    language=self.language.value
                )
            
            # Decode output
            stdout_str = stdout.decode('utf-8', errors='replace')
            stderr_str = stderr.decode('utf-8', errors='replace')
            
            # Truncate if needed
            truncated = False
            if len(stdout_str) > config.max_output_bytes:
                stdout_str = stdout_str[:config.max_output_bytes] + "\n[OUTPUT TRUNCATED]"
                truncated = True
            
            # Parse error
            error_msg, error_line = self._parse_error(stderr_str)
            
            duration = (datetime.now() - start_time).total_seconds() * 1000
            
            return ExecutionResult(
                status=status,
                exit_code=process.returncode,
                stdout=stdout_str,
                stderr=stderr_str,
                execution_time_ms=duration,
                language=self.language.value,
                truncated=truncated,
                error_message=error_msg,
                line_of_error=error_line
            )
            
        finally:
            # Cleanup temp file
            try:
                temp_file.unlink()
            except Exception:
                pass
    
    def _parse_error(self, stderr: str) -> tuple[Optional[str], Optional[int]]:
        """Parse Python error message."""
        # Look for standard Python traceback format
        line_match = re.search(r'line (\d+)', stderr, re.IGNORECASE)
        line_num = int(line_match.group(1)) if line_match else None
        
        # Get the actual error message (last line usually)
        lines = stderr.strip().split('\n')
        error_msg = None
        for line in reversed(lines):
            if line and not line.startswith(' ') and ':' in line:
                error_msg = line
                break
        
        return error_msg, line_num
    
    async def run_sandboxed(
        self,
        code: str,
        config: ExecutionConfig,
        allowed_builtins: Optional[Dict[str, Any]] = None
    ) -> ExecutionResult:
        """Run Python code in a restricted sandbox."""
        # Wrap code in sandbox
        sandbox_code = self._create_sandbox_wrapper(code, allowed_builtins)
        return await self.run(sandbox_code, config)
    
    def _create_sandbox_wrapper(
        self,
        code: str,
        allowed_builtins: Optional[Dict[str, Any]] = None
    ) -> str:
        """Create sandboxed wrapper for Python code."""
        # Default safe builtins
        safe_builtins = """
safe_builtins = {
    'abs': abs, 'all': all, 'any': any, 'ascii': ascii,
    'bin': bin, 'bool': bool, 'bytearray': bytearray, 'bytes': bytes,
    'callable': callable, 'chr': chr, 'dict': dict, 'dir': dir,
    'divmod': divmod, 'enumerate': enumerate, 'filter': filter,
    'float': float, 'format': format, 'frozenset': frozenset,
    'hash': hash, 'hex': hex, 'int': int, 'isinstance': isinstance,
    'issubclass': issubclass, 'iter': iter, 'len': len, 'list': list,
    'map': map, 'max': max, 'min': min, 'next': next, 'oct': oct,
    'ord': ord, 'pow': pow, 'print': print, 'range': range,
    'repr': repr, 'reversed': reversed, 'round': round, 'set': set,
    'slice': slice, 'sorted': sorted, 'str': str, 'sum': sum,
    'tuple': tuple, 'type': type, 'zip': zip,
    'True': True, 'False': False, 'None': None,
}
"""
        
        # Escape the user code
        escaped_code = code.replace('\\', '\\\\').replace("'''", "\\'\\'\\'")
        
        wrapper = f'''
{safe_builtins}

# Execute user code with restricted globals
user_code = \'\'\'
{escaped_code}
\'\'\'

exec(compile(user_code, '<sandbox>', 'exec'), {{"__builtins__": safe_builtins}})
'''
        return wrapper


class JavaScriptRunner(LanguageRunner):
    """JavaScript/Node.js code runner."""
    
    def __init__(self):
        super().__init__(Language.JAVASCRIPT)
        self.file_extension = ".js"
    
    def _detect_interpreter(self) -> None:
        """Detect Node.js interpreter."""
        for cmd in ['node', 'nodejs']:
            path = shutil.which(cmd)
            if path:
                self.interpreter_path = path
                break
    
    async def run(
        self,
        code: str,
        config: ExecutionConfig
    ) -> ExecutionResult:
        """Run JavaScript code with Node.js."""
        start_time = datetime.now()
        
        if not self.available:
            return ExecutionResult(
                status=ExecutionStatus.ERROR,
                exit_code=-1,
                stdout="",
                stderr="Node.js interpreter not found",
                execution_time_ms=0,
                language=self.language.value
            )
        
        temp_file = self._create_temp_file(code, self.file_extension)
        
        try:
            cmd = [self.interpreter_path, str(temp_file)]
            
            env = os.environ.copy()
            env.update(config.environment)
            
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                stdin=asyncio.subprocess.PIPE if config.stdin_data else None,
                cwd=str(config.working_directory) if config.working_directory else None,
                env=env
            )
            
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(
                        input=config.stdin_data.encode() if config.stdin_data else None
                    ),
                    timeout=config.timeout_seconds
                )
                
                status = ExecutionStatus.SUCCESS if process.returncode == 0 else ExecutionStatus.FAILED
                
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()
                
                return ExecutionResult(
                    status=ExecutionStatus.TIMEOUT,
                    exit_code=-1,
                    stdout="",
                    stderr=f"Execution timed out after {config.timeout_seconds}s",
                    execution_time_ms=config.timeout_seconds * 1000,
                    language=self.language.value
                )
            
            duration = (datetime.now() - start_time).total_seconds() * 1000
            
            return ExecutionResult(
                status=status,
                exit_code=process.returncode,
                stdout=stdout.decode('utf-8', errors='replace'),
                stderr=stderr.decode('utf-8', errors='replace'),
                execution_time_ms=duration,
                language=self.language.value
            )
            
        finally:
            try:
                temp_file.unlink()
            except Exception:
                pass


class BashRunner(LanguageRunner):
    """Bash/Shell code runner."""
    
    def __init__(self, shell: str = "bash"):
        self._shell = shell
        super().__init__(Language.BASH)
        self.file_extension = ".sh"
    
    def _detect_interpreter(self) -> None:
        """Detect shell interpreter."""
        path = shutil.which(self._shell)
        if path:
            self.interpreter_path = path
        else:
            # Fallback to sh
            self.interpreter_path = shutil.which('sh')
    
    async def run(
        self,
        code: str,
        config: ExecutionConfig
    ) -> ExecutionResult:
        """Run shell code."""
        start_time = datetime.now()
        
        if not self.available:
            return ExecutionResult(
                status=ExecutionStatus.ERROR,
                exit_code=-1,
                stdout="",
                stderr="Shell interpreter not found",
                execution_time_ms=0,
                language=self.language.value
            )
        
        temp_file = self._create_temp_file(code, self.file_extension)
        
        try:
            # Make executable
            os.chmod(temp_file, 0o755)
            
            cmd = [self.interpreter_path, str(temp_file)]
            
            env = os.environ.copy()
            env.update(config.environment)
            
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                stdin=asyncio.subprocess.PIPE if config.stdin_data else None,
                cwd=str(config.working_directory) if config.working_directory else None,
                env=env
            )
            
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(
                        input=config.stdin_data.encode() if config.stdin_data else None
                    ),
                    timeout=config.timeout_seconds
                )
                
                status = ExecutionStatus.SUCCESS if process.returncode == 0 else ExecutionStatus.FAILED
                
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()
                
                return ExecutionResult(
                    status=ExecutionStatus.TIMEOUT,
                    exit_code=-1,
                    stdout="",
                    stderr=f"Execution timed out after {config.timeout_seconds}s",
                    execution_time_ms=config.timeout_seconds * 1000,
                    language=self.language.value
                )
            
            duration = (datetime.now() - start_time).total_seconds() * 1000
            
            return ExecutionResult(
                status=status,
                exit_code=process.returncode,
                stdout=stdout.decode('utf-8', errors='replace'),
                stderr=stderr.decode('utf-8', errors='replace'),
                execution_time_ms=duration,
                language=self.language.value
            )
            
        finally:
            try:
                temp_file.unlink()
            except Exception:
                pass


class SQLRunner(LanguageRunner):
    """SQL code runner (SQLite)."""
    
    def __init__(self):
        super().__init__(Language.SQL)
        self.file_extension = ".sql"
    
    def _detect_interpreter(self) -> None:
        """Detect SQLite."""
        path = shutil.which('sqlite3')
        self.interpreter_path = path
    
    async def run(
        self,
        code: str,
        config: ExecutionConfig,
        database: Optional[str] = ":memory:"
    ) -> ExecutionResult:
        """Run SQL code with SQLite."""
        start_time = datetime.now()
        
        # Use Python's sqlite3 for safety
        import sqlite3
        
        try:
            conn = sqlite3.connect(database)
            cursor = conn.cursor()
            
            # Split into statements
            statements = [s.strip() for s in code.split(';') if s.strip()]
            
            results = []
            for stmt in statements:
                try:
                    cursor.execute(stmt)
                    
                    if cursor.description:
                        # SELECT query
                        columns = [d[0] for d in cursor.description]
                        rows = cursor.fetchall()
                        
                        # Format as table
                        result_lines = [' | '.join(columns)]
                        result_lines.append('-' * len(result_lines[0]))
                        for row in rows:
                            result_lines.append(' | '.join(str(v) for v in row))
                        
                        results.append('\n'.join(result_lines))
                    else:
                        results.append(f"Affected rows: {cursor.rowcount}")
                        
                except sqlite3.Error as e:
                    results.append(f"SQL Error: {e}")
            
            conn.commit()
            conn.close()
            
            duration = (datetime.now() - start_time).total_seconds() * 1000
            
            return ExecutionResult(
                status=ExecutionStatus.SUCCESS,
                exit_code=0,
                stdout='\n\n'.join(results),
                stderr="",
                execution_time_ms=duration,
                language=self.language.value
            )
            
        except Exception as e:
            duration = (datetime.now() - start_time).total_seconds() * 1000
            
            return ExecutionResult(
                status=ExecutionStatus.FAILED,
                exit_code=1,
                stdout="",
                stderr=str(e),
                execution_time_ms=duration,
                language=self.language.value,
                error_message=str(e)
            )


class CodeRunner:
    """
    Main code runner that delegates to language-specific runners.
    
    Supports multiple languages with consistent interface.
    """
    
    def __init__(self):
        self._runners: Dict[Language, LanguageRunner] = {}
        self._setup_runners()
        
        # Default configuration
        self.default_config = ExecutionConfig()
        
        logger.info("CodeRunner initialized")
    
    def _setup_runners(self) -> None:
        """Initialize language runners."""
        self._runners[Language.PYTHON] = PythonRunner()
        self._runners[Language.PYTHON3] = PythonRunner()
        self._runners[Language.JAVASCRIPT] = JavaScriptRunner()
        self._runners[Language.NODEJS] = JavaScriptRunner()
        self._runners[Language.BASH] = BashRunner("bash")
        self._runners[Language.SH] = BashRunner("sh")
        self._runners[Language.ZSH] = BashRunner("zsh")
        self._runners[Language.SQL] = SQLRunner()
        self._runners[Language.SQLITE] = SQLRunner()
    
    async def run(
        self,
        code: str,
        language: Union[Language, str],
        config: Optional[ExecutionConfig] = None,
        **kwargs
    ) -> ExecutionResult:
        """
        Run code in specified language.
        
        Args:
            code: Source code to execute
            language: Programming language
            config: Execution configuration
            **kwargs: Additional language-specific options
        
        Returns:
            ExecutionResult with output and status
        """
        if isinstance(language, str):
            language = Language.from_string(language)
        
        config = config or self.default_config
        
        runner = self._runners.get(language)
        if not runner:
            return ExecutionResult(
                status=ExecutionStatus.ERROR,
                exit_code=-1,
                stdout="",
                stderr=f"No runner for language: {language.value}",
                execution_time_ms=0,
                language=language.value
            )
        
        if not runner.available:
            return ExecutionResult(
                status=ExecutionStatus.ERROR,
                exit_code=-1,
                stdout="",
                stderr=f"Interpreter for {language.value} not found",
                execution_time_ms=0,
                language=language.value
            )
        
        logger.info(f"Running {language.value} code ({len(code)} bytes)")
        
        return await runner.run(code, config)
    
    async def run_file(
        self,
        file_path: Union[str, Path],
        language: Optional[Union[Language, str]] = None,
        config: Optional[ExecutionConfig] = None
    ) -> ExecutionResult:
        """Run code from a file."""
        file_path = Path(file_path)
        
        if not file_path.exists():
            return ExecutionResult(
                status=ExecutionStatus.ERROR,
                exit_code=-1,
                stdout="",
                stderr=f"File not found: {file_path}",
                execution_time_ms=0,
                language=""
            )
        
        # Detect language from extension if not specified
        if language is None:
            try:
                language = Language.from_extension(file_path.suffix)
            except ValueError:
                return ExecutionResult(
                    status=ExecutionStatus.ERROR,
                    exit_code=-1,
                    stdout="",
                    stderr=f"Cannot detect language from extension: {file_path.suffix}",
                    execution_time_ms=0,
                    language=""
                )
        
        code = file_path.read_text()
        return await self.run(code, language, config)
    
    async def run_python(
        self,
        code: str,
        sandbox: bool = False,
        config: Optional[ExecutionConfig] = None
    ) -> ExecutionResult:
        """Convenience method for Python execution."""
        runner = self._runners[Language.PYTHON]
        config = config or self.default_config
        
        if sandbox and isinstance(runner, PythonRunner):
            return await runner.run_sandboxed(code, config)
        
        return await self.run(code, Language.PYTHON, config)
    
    async def run_shell(
        self,
        code: str,
        shell: str = "bash",
        config: Optional[ExecutionConfig] = None
    ) -> ExecutionResult:
        """Convenience method for shell execution."""
        lang = Language.from_string(shell)
        return await self.run(code, lang, config)
    
    async def run_sql(
        self,
        query: str,
        database: str = ":memory:",
        config: Optional[ExecutionConfig] = None
    ) -> ExecutionResult:
        """Convenience method for SQL execution."""
        runner = self._runners[Language.SQL]
        config = config or self.default_config
        
        if isinstance(runner, SQLRunner):
            return await runner.run(query, config, database)
        
        return await self.run(query, Language.SQL, config)
    
    def get_available_languages(self) -> List[str]:
        """Get list of available languages."""
        return [
            lang.value for lang, runner in self._runners.items()
            if runner.available
        ]
    
    def is_language_available(self, language: Union[Language, str]) -> bool:
        """Check if a language is available."""
        if isinstance(language, str):
            try:
                language = Language.from_string(language)
            except ValueError:
                return False
        
        runner = self._runners.get(language)
        return runner is not None and runner.available
    
    def get_interpreter_path(self, language: Union[Language, str]) -> Optional[str]:
        """Get interpreter path for a language."""
        if isinstance(language, str):
            language = Language.from_string(language)
        
        runner = self._runners.get(language)
        return runner.interpreter_path if runner else None


# Singleton instance
_code_runner: Optional[CodeRunner] = None


def get_code_runner() -> CodeRunner:
    """Get or create code runner singleton."""
    global _code_runner
    if _code_runner is None:
        _code_runner = CodeRunner()
    return _code_runner


# Convenience functions
async def run_python(code: str, timeout: int = 30) -> ExecutionResult:
    """Quick Python execution."""
    runner = get_code_runner()
    config = ExecutionConfig(timeout_seconds=timeout)
    return await runner.run_python(code, sandbox=False, config=config)


async def run_python_safe(code: str, timeout: int = 30) -> ExecutionResult:
    """Sandboxed Python execution."""
    runner = get_code_runner()
    config = ExecutionConfig(timeout_seconds=timeout)
    return await runner.run_python(code, sandbox=True, config=config)


async def run_shell(command: str, timeout: int = 30) -> ExecutionResult:
    """Quick shell execution."""
    runner = get_code_runner()
    config = ExecutionConfig(timeout_seconds=timeout)
    return await runner.run_shell(command, "bash", config)


async def run_sql(query: str, database: str = ":memory:") -> ExecutionResult:
    """Quick SQL execution."""
    runner = get_code_runner()
    return await runner.run_sql(query, database)


async def run_code(
    code: str,
    language: str,
    timeout: int = 30
) -> ExecutionResult:
    """Generic code execution."""
    runner = get_code_runner()
    config = ExecutionConfig(timeout_seconds=timeout)
    return await runner.run(code, language, config)