"""
═══════════════════════════════════════════════════════════════════════════════════════
HASH TOOLS - CRYPTOGRAPHIC HASHING UTILITIES
═══════════════════════════════════════════════════════════════════════════════════════
Provides secure hashing capabilities:
- Multiple algorithms (MD5, SHA1, SHA256, SHA512, BLAKE2, etc.)
- File hashing with progress
- String/data hashing
- Hash verification
- HMAC generation
- Password hashing (bcrypt, argon2, scrypt)
- Checksum generation and verification
"""

import asyncio
import hashlib
import hmac
import secrets
import logging
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Union, BinaryIO, Callable
from pathlib import Path
import base64
import os

logger = logging.getLogger(__name__)

# Try to import optional password hashing libraries
try:
    import bcrypt
    BCRYPT_AVAILABLE = True
except ImportError:
    BCRYPT_AVAILABLE = False

try:
    from argon2 import PasswordHasher
    from argon2.exceptions import VerifyMismatchError
    ARGON2_AVAILABLE = True
except ImportError:
    ARGON2_AVAILABLE = False


class HashAlgorithm(Enum):
    """Supported hash algorithms."""
    MD5 = "md5"
    SHA1 = "sha1"
    SHA224 = "sha224"
    SHA256 = "sha256"
    SHA384 = "sha384"
    SHA512 = "sha512"
    SHA3_224 = "sha3_224"
    SHA3_256 = "sha3_256"
    SHA3_384 = "sha3_384"
    SHA3_512 = "sha3_512"
    BLAKE2B = "blake2b"
    BLAKE2S = "blake2s"
    
    @classmethod
    def from_string(cls, name: str) -> "HashAlgorithm":
        """Get algorithm from string name."""
        name_upper = name.upper().replace("-", "_")
        for algo in cls:
            if algo.name == name_upper or algo.value == name.lower():
                return algo
        raise ValueError(f"Unknown hash algorithm: {name}")
    
    @property
    def is_secure(self) -> bool:
        """Check if algorithm is considered secure."""
        return self not in [HashAlgorithm.MD5, HashAlgorithm.SHA1]


class PasswordHashAlgorithm(Enum):
    """Password hashing algorithms."""
    BCRYPT = "bcrypt"
    ARGON2 = "argon2"
    SCRYPT = "scrypt"
    PBKDF2_SHA256 = "pbkdf2_sha256"
    PBKDF2_SHA512 = "pbkdf2_sha512"


@dataclass
class HashResult:
    """Result of a hashing operation."""
    algorithm: str
    hash_hex: str
    hash_bytes: bytes
    hash_base64: str
    input_size: int
    timestamp: datetime = field(default_factory=datetime.now)
    duration_ms: float = 0.0
    
    def __str__(self) -> str:
        return self.hash_hex
    
    def verify(self, expected: str) -> bool:
        """Verify hash against expected value."""
        expected_clean = expected.lower().strip()
        return (
            self.hash_hex.lower() == expected_clean or
            self.hash_base64 == expected.strip()
        )


@dataclass
class PasswordHashResult:
    """Result of password hashing."""
    algorithm: str
    hash_string: str
    salt: Optional[str] = None
    iterations: Optional[int] = None
    timestamp: datetime = field(default_factory=datetime.now)
    
    def __str__(self) -> str:
        return self.hash_string


@dataclass
class FileHashResult(HashResult):
    """Result of file hashing."""
    file_path: str = ""
    file_size: int = 0
    
    def format_checksum(self) -> str:
        """Format as standard checksum line."""
        return f"{self.hash_hex}  {self.file_path}"


class HashTools:
    """
    Comprehensive hashing toolkit.
    
    Provides secure hashing for:
    - Strings and binary data
    - Files (with streaming for large files)
    - Passwords (with salt and iterations)
    - HMAC generation
    """
    
    def __init__(self):
        self.default_algorithm = HashAlgorithm.SHA256
        self.default_password_algorithm = PasswordHashAlgorithm.PBKDF2_SHA256
        
        # PBKDF2 iterations (NIST recommends at least 10,000)
        self.pbkdf2_iterations = 100000
        
        # Chunk size for file hashing (64KB)
        self.chunk_size = 65536
        
        # Argon2 hasher if available
        self._argon2_hasher = PasswordHasher() if ARGON2_AVAILABLE else None
        
        logger.info("HashTools initialized")
    
    # ─────────────────────────────────────────────────────────────────────
    # STRING/DATA HASHING
    # ─────────────────────────────────────────────────────────────────────
    
    async def hash_string(
        self,
        data: str,
        algorithm: Union[HashAlgorithm, str] = None,
        encoding: str = "utf-8"
    ) -> HashResult:
        """
        Hash a string.
        
        Args:
            data: String to hash
            algorithm: Hash algorithm to use
            encoding: String encoding
        
        Returns:
            HashResult with hash in multiple formats
        """
        if algorithm is None:
            algorithm = self.default_algorithm
        elif isinstance(algorithm, str):
            algorithm = HashAlgorithm.from_string(algorithm)
        
        start_time = datetime.now()
        
        # Convert to bytes
        data_bytes = data.encode(encoding)
        
        # Create hash
        hasher = hashlib.new(algorithm.value)
        hasher.update(data_bytes)
        hash_bytes = hasher.digest()
        
        duration = (datetime.now() - start_time).total_seconds() * 1000
        
        return HashResult(
            algorithm=algorithm.value,
            hash_hex=hash_bytes.hex(),
            hash_bytes=hash_bytes,
            hash_base64=base64.b64encode(hash_bytes).decode(),
            input_size=len(data_bytes),
            duration_ms=duration
        )
    
    async def hash_bytes(
        self,
        data: bytes,
        algorithm: Union[HashAlgorithm, str] = None
    ) -> HashResult:
        """Hash binary data."""
        if algorithm is None:
            algorithm = self.default_algorithm
        elif isinstance(algorithm, str):
            algorithm = HashAlgorithm.from_string(algorithm)
        
        start_time = datetime.now()
        
        hasher = hashlib.new(algorithm.value)
        hasher.update(data)
        hash_bytes = hasher.digest()
        
        duration = (datetime.now() - start_time).total_seconds() * 1000
        
        return HashResult(
            algorithm=algorithm.value,
            hash_hex=hash_bytes.hex(),
            hash_bytes=hash_bytes,
            hash_base64=base64.b64encode(hash_bytes).decode(),
            input_size=len(data),
            duration_ms=duration
        )
    
    async def hash_multiple(
        self,
        data: Union[str, bytes],
        algorithms: List[Union[HashAlgorithm, str]]
    ) -> Dict[str, HashResult]:
        """Hash data with multiple algorithms."""
        results = {}
        
        if isinstance(data, str):
            data_bytes = data.encode('utf-8')
        else:
            data_bytes = data
        
        for algo in algorithms:
            if isinstance(algo, str):
                algo = HashAlgorithm.from_string(algo)
            
            result = await self.hash_bytes(data_bytes, algo)
            results[algo.value] = result
        
        return results
    
    # ─────────────────────────────────────────────────────────────────────
    # FILE HASHING
    # ─────────────────────────────────────────────────────────────────────
    
    async def hash_file(
        self,
        file_path: Union[str, Path],
        algorithm: Union[HashAlgorithm, str] = None,
        progress_callback: Optional[Callable[[int, int], None]] = None
    ) -> FileHashResult:
        """
        Hash a file using streaming.
        
        Args:
            file_path: Path to file
            algorithm: Hash algorithm
            progress_callback: Called with (bytes_processed, total_bytes)
        
        Returns:
            FileHashResult with file info
        """
        if algorithm is None:
            algorithm = self.default_algorithm
        elif isinstance(algorithm, str):
            algorithm = HashAlgorithm.from_string(algorithm)
        
        file_path = Path(file_path)
        
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        file_size = file_path.stat().st_size
        start_time = datetime.now()
        
        hasher = hashlib.new(algorithm.value)
        bytes_processed = 0
        
        # Use async file reading
        loop = asyncio.get_event_loop()
        
        def read_and_hash():
            nonlocal bytes_processed
            with open(file_path, 'rb') as f:
                while True:
                    chunk = f.read(self.chunk_size)
                    if not chunk:
                        break
                    hasher.update(chunk)
                    bytes_processed += len(chunk)
                    
                    if progress_callback:
                        progress_callback(bytes_processed, file_size)
        
        await loop.run_in_executor(None, read_and_hash)
        
        hash_bytes = hasher.digest()
        duration = (datetime.now() - start_time).total_seconds() * 1000
        
        return FileHashResult(
            algorithm=algorithm.value,
            hash_hex=hash_bytes.hex(),
            hash_bytes=hash_bytes,
            hash_base64=base64.b64encode(hash_bytes).decode(),
            input_size=file_size,
            file_path=str(file_path),
            file_size=file_size,
            duration_ms=duration
        )
    
    async def hash_files(
        self,
        file_paths: List[Union[str, Path]],
        algorithm: Union[HashAlgorithm, str] = None
    ) -> Dict[str, FileHashResult]:
        """Hash multiple files."""
        results = {}
        
        for path in file_paths:
            try:
                result = await self.hash_file(path, algorithm)
                results[str(path)] = result
            except Exception as e:
                logger.error(f"Failed to hash {path}: {e}")
                results[str(path)] = None
        
        return results
    
    async def verify_file_hash(
        self,
        file_path: Union[str, Path],
        expected_hash: str,
        algorithm: Union[HashAlgorithm, str] = None
    ) -> bool:
        """Verify a file's hash against expected value."""
        result = await self.hash_file(file_path, algorithm)
        return result.verify(expected_hash)
    
    async def generate_checksum_file(
        self,
        directory: Union[str, Path],
        output_file: Union[str, Path],
        algorithm: Union[HashAlgorithm, str] = None,
        recursive: bool = True,
        pattern: str = "*"
    ) -> int:
        """
        Generate checksum file for directory.
        
        Returns:
            Number of files hashed
        """
        directory = Path(directory)
        output_file = Path(output_file)
        
        if recursive:
            files = list(directory.rglob(pattern))
        else:
            files = list(directory.glob(pattern))
        
        # Filter to only files
        files = [f for f in files if f.is_file()]
        
        lines = []
        for file_path in sorted(files):
            try:
                result = await self.hash_file(file_path, algorithm)
                rel_path = file_path.relative_to(directory)
                lines.append(f"{result.hash_hex}  {rel_path}")
            except Exception as e:
                logger.warning(f"Skipping {file_path}: {e}")
        
        output_file.write_text('\n'.join(lines) + '\n')
        
        logger.info(f"Generated checksum file with {len(lines)} entries")
        return len(lines)
    
    async def verify_checksum_file(
        self,
        checksum_file: Union[str, Path],
        base_directory: Union[str, Path] = None,
        algorithm: Union[HashAlgorithm, str] = None
    ) -> Dict[str, bool]:
        """
        Verify files against a checksum file.
        
        Returns:
            Dict mapping file paths to verification results
        """
        checksum_file = Path(checksum_file)
        base_directory = Path(base_directory) if base_directory else checksum_file.parent
        
        results = {}
        
        for line in checksum_file.read_text().strip().split('\n'):
            if not line or line.startswith('#'):
                continue
            
            # Parse checksum line (format: "hash  filename" or "hash *filename")
            parts = line.split(None, 1)
            if len(parts) != 2:
                continue
            
            expected_hash = parts[0]
            filename = parts[1].lstrip('* ')
            file_path = base_directory / filename
            
            try:
                verified = await self.verify_file_hash(
                    file_path, expected_hash, algorithm
                )
                results[filename] = verified
            except FileNotFoundError:
                results[filename] = False
            except Exception as e:
                logger.error(f"Error verifying {filename}: {e}")
                results[filename] = False
        
        return results
    
    # ─────────────────────────────────────────────────────────────────────
    # HMAC
    # ─────────────────────────────────────────────────────────────────────
    
    async def hmac(
        self,
        data: Union[str, bytes],
        key: Union[str, bytes],
        algorithm: Union[HashAlgorithm, str] = None
    ) -> HashResult:
        """
        Generate HMAC.
        
        Args:
            data: Data to authenticate
            key: Secret key
            algorithm: Hash algorithm
        
        Returns:
            HashResult with HMAC
        """
        if algorithm is None:
            algorithm = self.default_algorithm
        elif isinstance(algorithm, str):
            algorithm = HashAlgorithm.from_string(algorithm)
        
        # Convert to bytes
        if isinstance(data, str):
            data = data.encode('utf-8')
        if isinstance(key, str):
            key = key.encode('utf-8')
        
        start_time = datetime.now()
        
        h = hmac.new(key, data, algorithm.value)
        hash_bytes = h.digest()
        
        duration = (datetime.now() - start_time).total_seconds() * 1000
        
        return HashResult(
            algorithm=f"hmac-{algorithm.value}",
            hash_hex=hash_bytes.hex(),
            hash_bytes=hash_bytes,
            hash_base64=base64.b64encode(hash_bytes).decode(),
            input_size=len(data),
            duration_ms=duration
        )
    
    async def verify_hmac(
        self,
        data: Union[str, bytes],
        key: Union[str, bytes],
        expected_hmac: str,
        algorithm: Union[HashAlgorithm, str] = None
    ) -> bool:
        """Verify HMAC using constant-time comparison."""
        result = await self.hmac(data, key, algorithm)
        
        # Use constant-time comparison to prevent timing attacks
        expected_bytes = bytes.fromhex(expected_hmac.lower())
        return hmac.compare_digest(result.hash_bytes, expected_bytes)
    
    # ─────────────────────────────────────────────────────────────────────
    # PASSWORD HASHING
    # ─────────────────────────────────────────────────────────────────────
    
    async def hash_password(
        self,
        password: str,
        algorithm: PasswordHashAlgorithm = None
    ) -> PasswordHashResult:
        """
        Hash a password securely.
        
        Args:
            password: Password to hash
            algorithm: Password hashing algorithm
        
        Returns:
            PasswordHashResult with hash
        """
        if algorithm is None:
            algorithm = self.default_password_algorithm
        
        loop = asyncio.get_event_loop()
        
        if algorithm == PasswordHashAlgorithm.BCRYPT:
            if not BCRYPT_AVAILABLE:
                raise RuntimeError("bcrypt not installed. Run: pip install bcrypt")
            
            def hash_bcrypt():
                salt = bcrypt.gensalt()
                hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
                return hashed.decode('utf-8'), salt.decode('utf-8')
            
            hash_str, salt = await loop.run_in_executor(None, hash_bcrypt)
            
            return PasswordHashResult(
                algorithm=algorithm.value,
                hash_string=hash_str,
                salt=salt
            )
        
        elif algorithm == PasswordHashAlgorithm.ARGON2:
            if not ARGON2_AVAILABLE:
                raise RuntimeError("argon2-cffi not installed. Run: pip install argon2-cffi")
            
            def hash_argon2():
                return self._argon2_hasher.hash(password)
            
            hash_str = await loop.run_in_executor(None, hash_argon2)
            
            return PasswordHashResult(
                algorithm=algorithm.value,
                hash_string=hash_str
            )
        
        elif algorithm == PasswordHashAlgorithm.SCRYPT:
            def hash_scrypt():
                salt = secrets.token_bytes(16)
                hashed = hashlib.scrypt(
                    password.encode('utf-8'),
                    salt=salt,
                    n=16384,  # CPU/memory cost
                    r=8,      # Block size
                    p=1,      # Parallelization
                    dklen=32
                )
                return base64.b64encode(salt + hashed).decode(), base64.b64encode(salt).decode()
            
            hash_str, salt = await loop.run_in_executor(None, hash_scrypt)
            
            return PasswordHashResult(
                algorithm=algorithm.value,
                hash_string=hash_str,
                salt=salt
            )
        
        elif algorithm in [PasswordHashAlgorithm.PBKDF2_SHA256, PasswordHashAlgorithm.PBKDF2_SHA512]:
            hash_name = "sha256" if algorithm == PasswordHashAlgorithm.PBKDF2_SHA256 else "sha512"
            
            def hash_pbkdf2():
                salt = secrets.token_bytes(16)
                hashed = hashlib.pbkdf2_hmac(
                    hash_name,
                    password.encode('utf-8'),
                    salt,
                    self.pbkdf2_iterations
                )
                # Format: algorithm$iterations$salt$hash
                return (
                    f"{hash_name}${self.pbkdf2_iterations}$"
                    f"{base64.b64encode(salt).decode()}$"
                    f"{base64.b64encode(hashed).decode()}"
                ), base64.b64encode(salt).decode()
            
            hash_str, salt = await loop.run_in_executor(None, hash_pbkdf2)
            
            return PasswordHashResult(
                algorithm=algorithm.value,
                hash_string=hash_str,
                salt=salt,
                iterations=self.pbkdf2_iterations
            )
        
        else:
            raise ValueError(f"Unsupported algorithm: {algorithm}")
    
    async def verify_password(
        self,
        password: str,
        hash_string: str,
        algorithm: PasswordHashAlgorithm = None
    ) -> bool:
        """
        Verify a password against a hash.
        
        Args:
            password: Password to verify
            hash_string: Hash to verify against
            algorithm: Algorithm (auto-detected if possible)
        
        Returns:
            True if password matches
        """
        loop = asyncio.get_event_loop()
        
        # Auto-detect algorithm
        if algorithm is None:
            if hash_string.startswith('$2'):
                algorithm = PasswordHashAlgorithm.BCRYPT
            elif hash_string.startswith('$argon2'):
                algorithm = PasswordHashAlgorithm.ARGON2
            elif '$' in hash_string:
                parts = hash_string.split('$')
                if parts[0] in ['sha256', 'sha512']:
                    algorithm = (
                        PasswordHashAlgorithm.PBKDF2_SHA256 
                        if parts[0] == 'sha256' 
                        else PasswordHashAlgorithm.PBKDF2_SHA512
                    )
            else:
                algorithm = PasswordHashAlgorithm.SCRYPT
        
        try:
            if algorithm == PasswordHashAlgorithm.BCRYPT:
                if not BCRYPT_AVAILABLE:
                    raise RuntimeError("bcrypt not installed")
                
                def verify_bcrypt():
                    return bcrypt.checkpw(
                        password.encode('utf-8'),
                        hash_string.encode('utf-8')
                    )
                
                return await loop.run_in_executor(None, verify_bcrypt)
            
            elif algorithm == PasswordHashAlgorithm.ARGON2:
                if not ARGON2_AVAILABLE:
                    raise RuntimeError("argon2-cffi not installed")
                
                def verify_argon2():
                    try:
                        self._argon2_hasher.verify(hash_string, password)
                        return True
                    except VerifyMismatchError:
                        return False
                
                return await loop.run_in_executor(None, verify_argon2)
            
            elif algorithm == PasswordHashAlgorithm.SCRYPT:
                def verify_scrypt():
                    decoded = base64.b64decode(hash_string)
                    salt = decoded[:16]
                    expected_hash = decoded[16:]
                    
                    computed = hashlib.scrypt(
                        password.encode('utf-8'),
                        salt=salt,
                        n=16384, r=8, p=1,
                        dklen=32
                    )
                    return hmac.compare_digest(computed, expected_hash)
                
                return await loop.run_in_executor(None, verify_scrypt)
            
            elif algorithm in [PasswordHashAlgorithm.PBKDF2_SHA256, PasswordHashAlgorithm.PBKDF2_SHA512]:
                def verify_pbkdf2():
                    parts = hash_string.split('$')
                    hash_name = parts[0]
                    iterations = int(parts[1])
                    salt = base64.b64decode(parts[2])
                    expected_hash = base64.b64decode(parts[3])
                    
                    computed = hashlib.pbkdf2_hmac(
                        hash_name,
                        password.encode('utf-8'),
                        salt,
                        iterations
                    )
                    return hmac.compare_digest(computed, expected_hash)
                
                return await loop.run_in_executor(None, verify_pbkdf2)
            
            else:
                raise ValueError(f"Unsupported algorithm: {algorithm}")
                
        except Exception as e:
            logger.error(f"Password verification failed: {e}")
            return False
    
    # ─────────────────────────────────────────────────────────────────────
    # UTILITY METHODS
    # ─────────────────────────────────────────────────────────────────────
    
    def generate_salt(self, length: int = 32) -> str:
        """Generate a random salt."""
        return secrets.token_hex(length)
    
    def generate_token(self, length: int = 32) -> str:
        """Generate a secure random token."""
        return secrets.token_urlsafe(length)
    
    def constant_time_compare(self, a: str, b: str) -> bool:
        """Constant-time string comparison."""
        return hmac.compare_digest(a.encode(), b.encode())
    
    def get_available_algorithms(self) -> List[str]:
        """Get list of available hash algorithms."""
        return [algo.value for algo in HashAlgorithm]
    
    def get_available_password_algorithms(self) -> List[str]:
        """Get list of available password hash algorithms."""
        available = [
            PasswordHashAlgorithm.PBKDF2_SHA256.value,
            PasswordHashAlgorithm.PBKDF2_SHA512.value,
            PasswordHashAlgorithm.SCRYPT.value,
        ]
        
        if BCRYPT_AVAILABLE:
            available.append(PasswordHashAlgorithm.BCRYPT.value)
        if ARGON2_AVAILABLE:
            available.append(PasswordHashAlgorithm.ARGON2.value)
        
        return available


# Singleton instance
_hash_tools: Optional[HashTools] = None


def get_hash_tools() -> HashTools:
    """Get or create hash tools singleton."""
    global _hash_tools
    if _hash_tools is None:
        _hash_tools = HashTools()
    return _hash_tools


# Convenience functions
async def quick_hash(data: Union[str, bytes], algorithm: str = "sha256") -> str:
    """Quick hash function returning hex string."""
    tools = get_hash_tools()
    if isinstance(data, str):
        result = await tools.hash_string(data, algorithm)
    else:
        result = await tools.hash_bytes(data, algorithm)
    return result.hash_hex


async def quick_file_hash(path: Union[str, Path], algorithm: str = "sha256") -> str:
    """Quick file hash function."""
    tools = get_hash_tools()
    result = await tools.hash_file(path, algorithm)
    return result.hash_hex


async def quick_password_hash(password: str) -> str:
    """Quick password hash with default algorithm."""
    tools = get_hash_tools()
    result = await tools.hash_password(password)
    return result.hash_string


async def quick_password_verify(password: str, hash_string: str) -> bool:
    """Quick password verification."""
    tools = get_hash_tools()
    return await tools.verify_password(password, hash_string)