"""
Git Tools - Git repository operations.
Clone, commit, push, pull, branch management, and more.
"""

import asyncio
import os
from pathlib import Path
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import logging
import re

import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from tools.base_tool import (
    BaseTool, ToolResult, ToolContext, ResultStatus,
    ToolCategory, ToolRisk
)
from tools.registry import get_registry
from tools.system_ops.shell_executor import shell_executor

logger = logging.getLogger(__name__)


@dataclass
class GitStatus:
    """Git repository status."""
    branch: str
    clean: bool
    ahead: int
    behind: int
    staged: List[str]
    modified: List[str]
    untracked: List[str]
    deleted: List[str]
    conflicts: List[str]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'branch': self.branch,
            'clean': self.clean,
            'ahead': self.ahead,
            'behind': self.behind,
            'staged': self.staged,
            'staged_count': len(self.staged),
            'modified': self.modified,
            'modified_count': len(self.modified),
            'untracked': self.untracked,
            'untracked_count': len(self.untracked),
            'deleted': self.deleted,
            'deleted_count': len(self.deleted),
            'conflicts': self.conflicts,
            'has_conflicts': len(self.conflicts) > 0
        }


@dataclass
class GitCommit:
    """Git commit information."""
    hash: str
    short_hash: str
    author: str
    author_email: str
    date: str
    message: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'hash': self.hash,
            'short_hash': self.short_hash,
            'author': self.author,
            'author_email': self.author_email,
            'date': self.date,
            'message': self.message
        }


@dataclass
class GitBranch:
    """Git branch information."""
    name: str
    is_current: bool
    is_remote: bool
    tracking: Optional[str]
    last_commit: Optional[str]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'is_current': self.is_current,
            'is_remote': self.is_remote,
            'tracking': self.tracking,
            'last_commit': self.last_commit
        }


class GitTools(BaseTool):
    """
    Git repository operations tool.
    
    Features:
    - Repository status
    - Clone, init repositories
    - Commit, push, pull
    - Branch management
    - Stash operations
    - Log and history
    - Diff viewing
    - Remote management
    """
    
    def __init__(self):
        super().__init__(
            name="git_tools",
            description="Git repository operations",
            category=ToolCategory.GIT,
            risk=ToolRisk.MEDIUM,
            requires_confirmation=False,
            timeout=300.0,
            version="1.0.0"
        )
    
    async def _run_git(
        self,
        command: str,
        cwd: Optional[str] = None,
        timeout: float = 60.0
    ) -> Tuple[bool, str, str]:
        """Run git command and return (success, stdout, stderr)."""
        result = await shell_executor.execute_command(
            f"git {command}",
            cwd=cwd,
            timeout=timeout
        )
        return result.success, result.stdout, result.stderr
    
    async def is_repo(self, path: str) -> bool:
        """Check if path is a git repository."""
        success, _, _ = await self._run_git("rev-parse --git-dir", cwd=path)
        return success
    
    async def init(
        self,
        path: str,
        bare: bool = False
    ) -> Dict[str, Any]:
        """
        Initialize a git repository.
        
        Args:
            path: Repository path
            bare: Create bare repository
            
        Returns:
            Result dict
        """
        Path(path).mkdir(parents=True, exist_ok=True)
        
        cmd = "init --bare" if bare else "init"
        success, stdout, stderr = await self._run_git(cmd, cwd=path)
        
        return {
            'success': success,
            'path': path,
            'bare': bare,
            'message': stdout.strip() if success else stderr
        }
    
    async def clone(
        self,
        url: str,
        path: Optional[str] = None,
        branch: Optional[str] = None,
        depth: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Clone a git repository.
        
        Args:
            url: Repository URL
            path: Destination path
            branch: Branch to clone
            depth: Clone depth (shallow clone)
            
        Returns:
            Result dict
        """
        cmd = "clone"
        
        if branch:
            cmd += f" --branch {branch}"
        if depth:
            cmd += f" --depth {depth}"
        
        cmd += f" {url}"
        
        if path:
            cmd += f" {path}"
        
        success, stdout, stderr = await self._run_git(cmd, timeout=300.0)
        
        return {
            'success': success,
            'url': url,
            'path': path or url.split('/')[-1].replace('.git', ''),
            'branch': branch,
            'message': stdout.strip() if success else stderr
        }
    
    async def status(self, path: str) -> Optional[GitStatus]:
        """
        Get repository status.
        
        Args:
            path: Repository path
            
        Returns:
            GitStatus or None
        """
        if not await self.is_repo(path):
            return None
        
        # Get branch info
        success, branch_output, _ = await self._run_git(
            "branch --show-current", cwd=path
        )
        branch = branch_output.strip() if success else "HEAD"
        
        # Get ahead/behind
        ahead, behind = 0, 0
        success, ab_output, _ = await self._run_git(
            "rev-list --left-right --count HEAD...@{u}", cwd=path
        )
        if success and ab_output.strip():
            parts = ab_output.strip().split()
            if len(parts) == 2:
                ahead, behind = int(parts[0]), int(parts[1])
        
        # Get status
        success, status_output, _ = await self._run_git(
            "status --porcelain", cwd=path
        )
        
        staged = []
        modified = []
        untracked = []
        deleted = []
        conflicts = []
        
        if success:
            for line in status_output.strip().split('\n'):
                if not line:
                    continue
                
                status_code = line[:2]
                filename = line[3:]
                
                # Staged
                if status_code[0] in 'MADRCU':
                    staged.append(filename)
                
                # Modified
                if status_code[1] == 'M':
                    modified.append(filename)
                
                # Deleted
                if status_code[1] == 'D':
                    deleted.append(filename)
                
                # Untracked
                if status_code == '??':
                    untracked.append(filename)
                
                # Conflicts
                if status_code in ['DD', 'AU', 'UD', 'UA', 'DU', 'AA', 'UU']:
                    conflicts.append(filename)
        
        clean = not (staged or modified or untracked or deleted or conflicts)
        
        return GitStatus(
            branch=branch,
            clean=clean,
            ahead=ahead,
            behind=behind,
            staged=staged,
            modified=modified,
            untracked=untracked,
            deleted=deleted,
            conflicts=conflicts
        )
    
    async def add(
        self,
        path: str,
        files: Optional[List[str]] = None,
        all_files: bool = False
    ) -> Dict[str, Any]:
        """
        Stage files for commit.
        
        Args:
            path: Repository path
            files: Files to add
            all_files: Add all files
            
        Returns:
            Result dict
        """
        if all_files:
            cmd = "add -A"
        elif files:
            cmd = f"add {' '.join(files)}"
        else:
            cmd = "add ."
        
        success, stdout, stderr = await self._run_git(cmd, cwd=path)
        
        return {
            'success': success,
            'files': files or ['all'] if all_files else ['.'],
            'message': stdout.strip() if success else stderr
        }
    
    async def commit(
        self,
        path: str,
        message: str,
        author: Optional[str] = None,
        amend: bool = False,
        allow_empty: bool = False
    ) -> Dict[str, Any]:
        """
        Create a commit.
        
        Args:
            path: Repository path
            message: Commit message
            author: Author string
            amend: Amend last commit
            allow_empty: Allow empty commit
            
        Returns:
            Result dict
        """
        # Escape message for shell
        escaped_message = message.replace('"', '\\"')
        cmd = f'commit -m "{escaped_message}"'
        
        if author:
            cmd += f' --author="{author}"'
        if amend:
            cmd += " --amend"
        if allow_empty:
            cmd += " --allow-empty"
        
        success, stdout, stderr = await self._run_git(cmd, cwd=path)
        
        # Extract commit hash
        commit_hash = None
        if success:
            match = re.search(r'\[[\w-]+ ([a-f0-9]+)\]', stdout)
            if match:
                commit_hash = match.group(1)
        
        return {
            'success': success,
            'commit_hash': commit_hash,
            'message': stdout.strip() if success else stderr
        }
    
    async def push(
        self,
        path: str,
        remote: str = "origin",
        branch: Optional[str] = None,
        force: bool = False,
        set_upstream: bool = False
    ) -> Dict[str, Any]:
        """
        Push changes to remote.
        
        Args:
            path: Repository path
            remote: Remote name
            branch: Branch to push
            force: Force push
            set_upstream: Set upstream
            
        Returns:
            Result dict
        """
        cmd = f"push {remote}"
        
        if branch:
            cmd += f" {branch}"
        if force:
            cmd += " --force"
        if set_upstream:
            cmd += " --set-upstream"
        
        success, stdout, stderr = await self._run_git(cmd, cwd=path, timeout=120.0)
        
        return {
            'success': success,
            'remote': remote,
            'branch': branch,
            'message': stdout.strip() or stderr.strip()
        }
    
    async def pull(
        self,
        path: str,
        remote: str = "origin",
        branch: Optional[str] = None,
        rebase: bool = False
    ) -> Dict[str, Any]:
        """
        Pull changes from remote.
        
        Args:
            path: Repository path
            remote: Remote name
            branch: Branch to pull
            rebase: Use rebase
            
        Returns:
            Result dict
        """
        cmd = f"pull {remote}"
        
        if branch:
            cmd += f" {branch}"
        if rebase:
            cmd += " --rebase"
        
        success, stdout, stderr = await self._run_git(cmd, cwd=path, timeout=120.0)
        
        return {
            'success': success,
            'remote': remote,
            'branch': branch,
            'message': stdout.strip() or stderr.strip()
        }
    
    async def fetch(
        self,
        path: str,
        remote: str = "origin",
        prune: bool = False
    ) -> Dict[str, Any]:
        """Fetch from remote."""
        cmd = f"fetch {remote}"
        if prune:
            cmd += " --prune"
        
        success, stdout, stderr = await self._run_git(cmd, cwd=path, timeout=120.0)
        
        return {
            'success': success,
            'remote': remote,
            'message': stdout.strip() or stderr.strip()
        }
    
    async def branches(
        self,
        path: str,
        all_branches: bool = False
    ) -> List[GitBranch]:
        """
        List branches.
        
        Args:
            path: Repository path
            all_branches: Include remote branches
            
        Returns:
            List of GitBranch
        """
        cmd = "branch -vv"
        if all_branches:
            cmd += " -a"
        
        success, stdout, _ = await self._run_git(cmd, cwd=path)
        
        branches = []
        if success:
            for line in stdout.strip().split('\n'):
                if not line.strip():
                    continue
                
                is_current = line.startswith('*')
                line = line.lstrip('* ')
                
                parts = line.split()
                if not parts:
                    continue
                
                name = parts[0]
                is_remote = name.startswith('remotes/')
                
                # Extract tracking info
                tracking = None
                tracking_match = re.search(r'\[([^\]]+)\]', line)
                if tracking_match:
                    tracking = tracking_match.group(1).split(':')[0]
                
                # Last commit
                last_commit = parts[1] if len(parts) > 1 else None
                
                branches.append(GitBranch(
                    name=name,
                    is_current=is_current,
                    is_remote=is_remote,
                    tracking=tracking,
                    last_commit=last_commit
                ))
        
        return branches
    
    async def checkout(
        self,
        path: str,
        branch: str,
        create: bool = False
    ) -> Dict[str, Any]:
        """
        Checkout a branch.
        
        Args:
            path: Repository path
            branch: Branch name
            create: Create new branch
            
        Returns:
            Result dict
        """
        cmd = f"checkout {'-b ' if create else ''}{branch}"
        success, stdout, stderr = await self._run_git(cmd, cwd=path)
        
        return {
            'success': success,
            'branch': branch,
            'created': create,
            'message': stdout.strip() or stderr.strip()
        }
    
    async def merge(
        self,
        path: str,
        branch: str,
        no_ff: bool = False
    ) -> Dict[str, Any]:
        """Merge a branch."""
        cmd = f"merge {branch}"
        if no_ff:
            cmd += " --no-ff"
        
        success, stdout, stderr = await self._run_git(cmd, cwd=path)
        
        return {
            'success': success,
            'branch': branch,
            'message': stdout.strip() or stderr.strip()
        }
    
    async def log(
        self,
        path: str,
        count: int = 10,
        oneline: bool = False
    ) -> List[GitCommit]:
        """
        Get commit log.
        
        Args:
            path: Repository path
            count: Number of commits
            oneline: One line format
            
        Returns:
            List of GitCommit
        """
        format_str = "%H|%h|%an|%ae|%ai|%s"
        cmd = f'log -{count} --format="{format_str}"'
        
        success, stdout, _ = await self._run_git(cmd, cwd=path)
        
        commits = []
        if success:
            for line in stdout.strip().split('\n'):
                if not line:
                    continue
                
                parts = line.split('|', 5)
                if len(parts) >= 6:
                    commits.append(GitCommit(
                        hash=parts[0],
                        short_hash=parts[1],
                        author=parts[2],
                        author_email=parts[3],
                        date=parts[4],
                        message=parts[5]
                    ))
        
        return commits
    
    async def diff(
        self,
        path: str,
        staged: bool = False,
        file: Optional[str] = None
    ) -> str:
        """Get diff output."""
        cmd = "diff"
        if staged:
            cmd += " --staged"
        if file:
            cmd += f" -- {file}"
        
        success, stdout, _ = await self._run_git(cmd, cwd=path)
        return stdout if success else ""
    
    async def stash(
        self,
        path: str,
        operation: str = "push",
        message: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Stash operations.
        
        Args:
            path: Repository path
            operation: push, pop, list, drop, apply
            message: Stash message
            
        Returns:
            Result dict
        """
        cmd = f"stash {operation}"
        if message and operation == "push":
            cmd += f' -m "{message}"'
        
        success, stdout, stderr = await self._run_git(cmd, cwd=path)
        
        return {
            'success': success,
            'operation': operation,
            'message': stdout.strip() or stderr.strip()
        }
    
    async def run(self, context: ToolContext, **kwargs) -> ToolResult:
        """
        Execute git operation.
        
        Supported operations:
        - status: Get repository status
        - init: Initialize repository
        - clone: Clone repository
        - add: Stage files
        - commit: Create commit
        - push: Push to remote
        - pull: Pull from remote
        - fetch: Fetch from remote
        - branches: List branches
        - checkout: Checkout branch
        - merge: Merge branch
        - log: Get commit log
        - diff: Get diff
        - stash: Stash operations
        """
        operation = kwargs.get('operation', 'status')
        path = kwargs.get('path') or kwargs.get('repo') or '.'
        
        try:
            if operation == 'status':
                status = await self.status(path)
                
                if status:
                    return ToolResult.ok(data=status.to_dict())
                else:
                    return ToolResult.fail(error="Not a git repository")
            
            elif operation == 'init':
                result = await self.init(path, bare=kwargs.get('bare', False))
                
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            elif operation == 'clone':
                url = kwargs.get('url')
                if not url:
                    return ToolResult.fail(error="url is required")
                
                result = await self.clone(
                    url, path=kwargs.get('dest'),
                    branch=kwargs.get('branch'),
                    depth=kwargs.get('depth')
                )
                
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            elif operation == 'add':
                result = await self.add(
                    path,
                    files=kwargs.get('files'),
                    all_files=kwargs.get('all', False)
                )
                
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            elif operation == 'commit':
                message = kwargs.get('message')
                if not message:
                    return ToolResult.fail(error="message is required")
                
                result = await self.commit(
                    path, message,
                    author=kwargs.get('author'),
                    amend=kwargs.get('amend', False)
                )
                
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            elif operation == 'push':
                result = await self.push(
                    path,
                    remote=kwargs.get('remote', 'origin'),
                    branch=kwargs.get('branch'),
                    force=kwargs.get('force', False),
                    set_upstream=kwargs.get('set_upstream', False)
                )
                
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            elif operation == 'pull':
                result = await self.pull(
                    path,
                    remote=kwargs.get('remote', 'origin'),
                    branch=kwargs.get('branch'),
                    rebase=kwargs.get('rebase', False)
                )
                
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            elif operation == 'fetch':
                result = await self.fetch(
                    path,
                    remote=kwargs.get('remote', 'origin'),
                    prune=kwargs.get('prune', False)
                )
                
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            elif operation == 'branches':
                branches = await self.branches(
                    path,
                    all_branches=kwargs.get('all', False)
                )
                
                return ToolResult.ok(
                    data={
                        'branches': [b.to_dict() for b in branches],
                        'count': len(branches)
                    }
                )
            
            elif operation == 'checkout':
                branch = kwargs.get('branch')
                if not branch:
                    return ToolResult.fail(error="branch is required")
                
                result = await self.checkout(
                    path, branch,
                    create=kwargs.get('create', False)
                )
                
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            elif operation == 'merge':
                branch = kwargs.get('branch')
                if not branch:
                    return ToolResult.fail(error="branch is required")
                
                result = await self.merge(path, branch)
                
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            elif operation == 'log':
                commits = await self.log(
                    path,
                    count=kwargs.get('count', 10)
                )
                
                return ToolResult.ok(
                    data={
                        'commits': [c.to_dict() for c in commits],
                        'count': len(commits)
                    }
                )
            
            elif operation == 'diff':
                diff_output = await self.diff(
                    path,
                    staged=kwargs.get('staged', False),
                    file=kwargs.get('file')
                )
                
                return ToolResult.ok(data={'diff': diff_output})
            
            elif operation == 'stash':
                stash_op = kwargs.get('stash_operation', 'push')
                result = await self.stash(
                    path, stash_op,
                    message=kwargs.get('message')
                )
                
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            else:
                return ToolResult.fail(error=f"Unknown operation: {operation}")
            
        except Exception as e:
            logger.error(f"GitTools error: {e}")
            return ToolResult.error(error=str(e))


# Create singleton
git_tools = GitTools()


def register():
    """Register git tools."""
    registry = get_registry()
    registry.register_tool(git_tools)