"""
Service Tools - System service management.
Control systemd, init.d, and other service managers.
"""

import asyncio
from pathlib import Path
from typing import Optional, List, Dict, Any, Set
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import logging
import re

# Import from our tool system
import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from tools.base_tool import (
    BaseTool, ToolResult, ToolStatus, ToolCategory,
    RiskLevel, tool_registry
)
from tools.system_ops.shell_executor import shell_executor, CommandResult

logger = logging.getLogger(__name__)


class ServiceManager(Enum):
    """Supported service managers."""
    SYSTEMD = "systemd"
    INITD = "init.d"
    UPSTART = "upstart"
    OPENRC = "openrc"
    LAUNCHD = "launchd"  # macOS
    UNKNOWN = "unknown"


class ServiceState(Enum):
    """Service states."""
    RUNNING = "running"
    STOPPED = "stopped"
    FAILED = "failed"
    INACTIVE = "inactive"
    ACTIVATING = "activating"
    DEACTIVATING = "deactivating"
    UNKNOWN = "unknown"


@dataclass
class ServiceInfo:
    """Information about a service."""
    name: str
    state: ServiceState
    enabled: bool
    description: Optional[str]
    pid: Optional[int]
    memory: Optional[str]
    cpu: Optional[str]
    uptime: Optional[str]
    manager: ServiceManager
    unit_file: Optional[str] = None
    load_state: Optional[str] = None
    sub_state: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'name': self.name,
            'state': self.state.value,
            'enabled': self.enabled,
            'description': self.description,
            'pid': self.pid,
            'memory': self.memory,
            'cpu': self.cpu,
            'uptime': self.uptime,
            'manager': self.manager.value,
            'unit_file': self.unit_file,
            'load_state': self.load_state,
            'sub_state': self.sub_state
        }


@dataclass
class ServiceOperation:
    """Result of a service operation."""
    success: bool
    service: str
    operation: str
    message: Optional[str] = None
    error: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'success': self.success,
            'service': self.service,
            'operation': self.operation,
            'message': self.message,
            'error': self.error
        }


class ServiceTools(BaseTool):
    """
    System service management tool.
    
    Features:
    - Auto-detect service manager
    - List all services
    - Start/stop/restart services
    - Enable/disable services
    - Get service status
    - View service logs
    - Reload configurations
    """
    
    def __init__(self):
        super().__init__(
            name="service_tools",
            description="System service management (systemd, init.d)",
            category=ToolCategory.SYSTEM,
            risk_level=RiskLevel.HIGH,
            requires_confirmation=True,
            timeout=60.0,
            version="1.0.0"
        )
        
        self._manager: Optional[ServiceManager] = None
        self._detected = False
    
    async def _detect_manager(self) -> ServiceManager:
        """Detect the system's service manager."""
        if self._detected:
            return self._manager
        
        # Check for systemd
        result = await shell_executor.execute_command(
            "systemctl --version",
            timeout=5.0
        )
        if result.success:
            self._manager = ServiceManager.SYSTEMD
            self._detected = True
            return self._manager
        
        # Check for launchd (macOS)
        result = await shell_executor.execute_command(
            "launchctl version",
            timeout=5.0
        )
        if result.success:
            self._manager = ServiceManager.LAUNCHD
            self._detected = True
            return self._manager
        
        # Check for OpenRC
        result = await shell_executor.execute_command(
            "rc-status --version",
            timeout=5.0
        )
        if result.success:
            self._manager = ServiceManager.OPENRC
            self._detected = True
            return self._manager
        
        # Check for init.d
        if Path('/etc/init.d').exists():
            self._manager = ServiceManager.INITD
            self._detected = True
            return self._manager
        
        self._manager = ServiceManager.UNKNOWN
        self._detected = True
        return self._manager
    
    async def _run_systemctl(self, *args) -> CommandResult:
        """Run systemctl command."""
        cmd = f"systemctl {' '.join(args)}"
        return await shell_executor.execute_command(cmd, timeout=30.0)
    
    async def _parse_systemd_status(self, output: str) -> Dict[str, Any]:
        """Parse systemctl status output."""
        info = {
            'state': ServiceState.UNKNOWN,
            'enabled': False,
            'pid': None,
            'memory': None,
            'cpu': None,
            'description': None,
            'uptime': None,
            'load_state': None,
            'sub_state': None
        }
        
        for line in output.split('\n'):
            line = line.strip()
            
            # Active state
            if line.startswith('Active:'):
                if 'running' in line.lower():
                    info['state'] = ServiceState.RUNNING
                elif 'inactive' in line.lower():
                    info['state'] = ServiceState.INACTIVE
                elif 'failed' in line.lower():
                    info['state'] = ServiceState.FAILED
                elif 'activating' in line.lower():
                    info['state'] = ServiceState.ACTIVATING
                elif 'deactivating' in line.lower():
                    info['state'] = ServiceState.DEACTIVATING
                
                # Extract uptime
                match = re.search(r'since (.+?)(?:;|$)', line)
                if match:
                    info['uptime'] = match.group(1).strip()
            
            # Loaded state and enabled
            if line.startswith('Loaded:'):
                if 'enabled' in line.lower():
                    info['enabled'] = True
                match = re.search(r'\((.+?)\)', line)
                if match:
                    info['load_state'] = match.group(1)
            
            # Main PID
            if 'Main PID:' in line:
                match = re.search(r'Main PID:\s*(\d+)', line)
                if match:
                    info['pid'] = int(match.group(1))
            
            # Memory
            if 'Memory:' in line:
                match = re.search(r'Memory:\s*(.+)', line)
                if match:
                    info['memory'] = match.group(1).strip()
            
            # CPU
            if 'CPU:' in line:
                match = re.search(r'CPU:\s*(.+)', line)
                if match:
                    info['cpu'] = match.group(1).strip()
            
            # Description (first line usually)
            if line.startswith('●') or line.startswith('○'):
                match = re.search(r'[●○]\s+\S+\s+-\s+(.+)', line)
                if match:
                    info['description'] = match.group(1)
        
        return info
    
    async def get_status(self, service_name: str) -> Optional[ServiceInfo]:
        """
        Get status of a service.
        
        Args:
            service_name: Name of the service
            
        Returns:
            ServiceInfo or None if not found
        """
        manager = await self._detect_manager()
        
        if manager == ServiceManager.SYSTEMD:
            result = await self._run_systemctl('status', service_name, '--no-pager')
            
            if result.exit_code not in [0, 3]:  # 3 = inactive but valid
                if 'could not be found' in result.stderr.lower():
                    return None
            
            parsed = await self._parse_systemd_status(result.stdout)
            
            return ServiceInfo(
                name=service_name,
                state=parsed['state'],
                enabled=parsed['enabled'],
                description=parsed['description'],
                pid=parsed['pid'],
                memory=parsed['memory'],
                cpu=parsed['cpu'],
                uptime=parsed['uptime'],
                manager=manager,
                load_state=parsed['load_state']
            )
            
        elif manager == ServiceManager.INITD:
            script_path = Path(f'/etc/init.d/{service_name}')
            if not script_path.exists():
                return None
            
            result = await shell_executor.execute_command(
                f"/etc/init.d/{service_name} status",
                timeout=10.0
            )
            
            state = ServiceState.STOPPED
            if result.success:
                if 'running' in result.stdout.lower():
                    state = ServiceState.RUNNING
            
            return ServiceInfo(
                name=service_name,
                state=state,
                enabled=False,  # Hard to determine with init.d
                description=None,
                pid=None,
                memory=None,
                cpu=None,
                uptime=None,
                manager=manager
            )
            
        elif manager == ServiceManager.LAUNCHD:
            result = await shell_executor.execute_command(
                f"launchctl list | grep {service_name}",
                timeout=10.0
            )
            
            if result.success and result.stdout.strip():
                parts = result.stdout.strip().split()
                pid = int(parts[0]) if parts[0] != '-' else None
                state = ServiceState.RUNNING if pid else ServiceState.STOPPED
                
                return ServiceInfo(
                    name=service_name,
                    state=state,
                    enabled=True,
                    description=None,
                    pid=pid,
                    memory=None,
                    cpu=None,
                    uptime=None,
                    manager=manager
                )
            return None
        
        return None
    
    async def list_services(
        self,
        running_only: bool = False,
        enabled_only: bool = False,
        pattern: Optional[str] = None
    ) -> List[ServiceInfo]:
        """
        List system services.
        
        Args:
            running_only: Only show running services
            enabled_only: Only show enabled services
            pattern: Filter by name pattern
            
        Returns:
            List of ServiceInfo objects
        """
        manager = await self._detect_manager()
        services = []
        
        if manager == ServiceManager.SYSTEMD:
            # List all services
            args = ['list-units', '--type=service', '--all', '--no-pager', '--no-legend']
            if running_only:
                args = ['list-units', '--type=service', '--state=running', '--no-pager', '--no-legend']
            
            result = await self._run_systemctl(*args)
            
            if result.success:
                for line in result.stdout.strip().split('\n'):
                    if not line.strip():
                        continue
                    
                    parts = line.split()
                    if len(parts) < 4:
                        continue
                    
                    name = parts[0]
                    if name.endswith('.service'):
                        name = name[:-8]
                    
                    # Filter by pattern
                    if pattern and not re.search(pattern, name, re.IGNORECASE):
                        continue
                    
                    load_state = parts[1] if len(parts) > 1 else None
                    active_state = parts[2] if len(parts) > 2 else None
                    sub_state = parts[3] if len(parts) > 3 else None
                    description = ' '.join(parts[4:]) if len(parts) > 4 else None
                    
                    # Map state
                    state = ServiceState.UNKNOWN
                    if active_state == 'active':
                        state = ServiceState.RUNNING
                    elif active_state == 'inactive':
                        state = ServiceState.INACTIVE
                    elif active_state == 'failed':
                        state = ServiceState.FAILED
                    
                    # Check if enabled
                    enabled = False
                    if not running_only:
                        enabled_result = await self._run_systemctl('is-enabled', name)
                        enabled = enabled_result.stdout.strip() == 'enabled'
                    
                    # Filter by enabled
                    if enabled_only and not enabled:
                        continue
                    
                    services.append(ServiceInfo(
                        name=name,
                        state=state,
                        enabled=enabled,
                        description=description,
                        pid=None,
                        memory=None,
                        cpu=None,
                        uptime=None,
                        manager=manager,
                        load_state=load_state,
                        sub_state=sub_state
                    ))
                    
        elif manager == ServiceManager.INITD:
            init_dir = Path('/etc/init.d')
            if init_dir.exists():
                for script in init_dir.iterdir():
                    if script.is_file() and script.name not in ['.', '..', 'README']:
                        name = script.name
                        
                        if pattern and not re.search(pattern, name, re.IGNORECASE):
                            continue
                        
                        info = await self.get_status(name)
                        if info:
                            if running_only and info.state != ServiceState.RUNNING:
                                continue
                            services.append(info)
        
        return services
    
    async def start(self, service_name: str) -> ServiceOperation:
        """Start a service."""
        manager = await self._detect_manager()
        
        if manager == ServiceManager.SYSTEMD:
            result = await self._run_systemctl('start', service_name)
            
            if result.success:
                return ServiceOperation(
                    success=True,
                    service=service_name,
                    operation='start',
                    message=f"Service {service_name} started successfully"
                )
            else:
                return ServiceOperation(
                    success=False,
                    service=service_name,
                    operation='start',
                    error=result.stderr or result.stdout
                )
                
        elif manager == ServiceManager.INITD:
            result = await shell_executor.execute_command(
                f"/etc/init.d/{service_name} start",
                timeout=30.0
            )
            
            return ServiceOperation(
                success=result.success,
                service=service_name,
                operation='start',
                message=result.stdout if result.success else None,
                error=result.stderr if not result.success else None
            )
        
        return ServiceOperation(
            success=False,
            service=service_name,
            operation='start',
            error=f"Unsupported service manager: {manager.value}"
        )
    
    async def stop(self, service_name: str) -> ServiceOperation:
        """Stop a service."""
        manager = await self._detect_manager()
        
        if manager == ServiceManager.SYSTEMD:
            result = await self._run_systemctl('stop', service_name)
            
            return ServiceOperation(
                success=result.success,
                service=service_name,
                operation='stop',
                message=f"Service {service_name} stopped" if result.success else None,
                error=result.stderr if not result.success else None
            )
            
        elif manager == ServiceManager.INITD:
            result = await shell_executor.execute_command(
                f"/etc/init.d/{service_name} stop",
                timeout=30.0
            )
            
            return ServiceOperation(
                success=result.success,
                service=service_name,
                operation='stop',
                message=result.stdout if result.success else None,
                error=result.stderr if not result.success else None
            )
        
        return ServiceOperation(
            success=False,
            service=service_name,
            operation='stop',
            error=f"Unsupported service manager: {manager.value}"
        )
    
    async def restart(self, service_name: str) -> ServiceOperation:
        """Restart a service."""
        manager = await self._detect_manager()
        
        if manager == ServiceManager.SYSTEMD:
            result = await self._run_systemctl('restart', service_name)
            
            return ServiceOperation(
                success=result.success,
                service=service_name,
                operation='restart',
                message=f"Service {service_name} restarted" if result.success else None,
                error=result.stderr if not result.success else None
            )
            
        elif manager == ServiceManager.INITD:
            result = await shell_executor.execute_command(
                f"/etc/init.d/{service_name} restart",
                timeout=60.0
            )
            
            return ServiceOperation(
                success=result.success,
                service=service_name,
                operation='restart',
                message=result.stdout if result.success else None,
                error=result.stderr if not result.success else None
            )
        
        return ServiceOperation(
            success=False,
            service=service_name,
            operation='restart',
            error=f"Unsupported service manager: {manager.value}"
        )
    
    async def reload(self, service_name: str) -> ServiceOperation:
        """Reload service configuration."""
        manager = await self._detect_manager()
        
        if manager == ServiceManager.SYSTEMD:
            result = await self._run_systemctl('reload', service_name)
            
            return ServiceOperation(
                success=result.success,
                service=service_name,
                operation='reload',
                message=f"Service {service_name} reloaded" if result.success else None,
                error=result.stderr if not result.success else None
            )
        
        return ServiceOperation(
            success=False,
            service=service_name,
            operation='reload',
            error=f"Reload not supported for {manager.value}"
        )
    
    async def enable(self, service_name: str) -> ServiceOperation:
        """Enable service to start at boot."""
        manager = await self._detect_manager()
        
        if manager == ServiceManager.SYSTEMD:
            result = await self._run_systemctl('enable', service_name)
            
            return ServiceOperation(
                success=result.success,
                service=service_name,
                operation='enable',
                message=f"Service {service_name} enabled" if result.success else None,
                error=result.stderr if not result.success else None
            )
        
        return ServiceOperation(
            success=False,
            service=service_name,
            operation='enable',
            error=f"Enable not supported for {manager.value}"
        )
    
    async def disable(self, service_name: str) -> ServiceOperation:
        """Disable service from starting at boot."""
        manager = await self._detect_manager()
        
        if manager == ServiceManager.SYSTEMD:
            result = await self._run_systemctl('disable', service_name)
            
            return ServiceOperation(
                success=result.success,
                service=service_name,
                operation='disable',
                message=f"Service {service_name} disabled" if result.success else None,
                error=result.stderr if not result.success else None
            )
        
        return ServiceOperation(
            success=False,
            service=service_name,
            operation='disable',
            error=f"Disable not supported for {manager.value}"
        )
    
    async def get_logs(
        self,
        service_name: str,
        lines: int = 100,
        follow: bool = False
    ) -> str:
        """
        Get service logs.
        
        Args:
            service_name: Service name
            lines: Number of lines
            follow: Follow log (streaming)
            
        Returns:
            Log content
        """
        manager = await self._detect_manager()
        
        if manager == ServiceManager.SYSTEMD:
            args = ['journalctl', '-u', service_name, '-n', str(lines), '--no-pager']
            if follow:
                args.append('-f')
            
            result = await shell_executor.execute_command(
                ' '.join(args),
                timeout=30.0 if not follow else 5.0
            )
            
            return result.stdout if result.success else result.stderr
        
        return f"Logs not available for {manager.value}"
    
    async def daemon_reload(self) -> ServiceOperation:
        """Reload systemd daemon configuration."""
        manager = await self._detect_manager()
        
        if manager == ServiceManager.SYSTEMD:
            result = await self._run_systemctl('daemon-reload')
            
            return ServiceOperation(
                success=result.success,
                service='daemon',
                operation='reload',
                message="Daemon reloaded" if result.success else None,
                error=result.stderr if not result.success else None
            )
        
        return ServiceOperation(
            success=False,
            service='daemon',
            operation='reload',
            error=f"Daemon reload not supported for {manager.value}"
        )
    
    async def execute(self, **kwargs) -> ToolResult:
        """
        Execute service operation.
        
        Supported operations:
        - list: List services
        - status: Get service status
        - start: Start service
        - stop: Stop service
        - restart: Restart service
        - reload: Reload service config
        - enable: Enable at boot
        - disable: Disable at boot
        - logs: Get service logs
        - daemon_reload: Reload systemd daemon
        """
        operation = kwargs.get('operation', 'list')
        service = kwargs.get('service') or kwargs.get('name')
        
        start_time = datetime.now()
        
        try:
            if operation == 'list':
                services = await self.list_services(
                    running_only=kwargs.get('running_only', False),
                    enabled_only=kwargs.get('enabled_only', False),
                    pattern=kwargs.get('pattern')
                )
                
                return ToolResult(
                    status=ToolStatus.SUCCESS,
                    data={
                        'count': len(services),
                        'manager': (await self._detect_manager()).value,
                        'services': [s.to_dict() for s in services]
                    }
                )
                
            elif operation == 'status':
                if not service:
                    return ToolResult(
                        status=ToolStatus.FAILURE,
                        error="service name is required"
                    )
                
                info = await self.get_status(service)
                
                if info:
                    return ToolResult(
                        status=ToolStatus.SUCCESS,
                        data=info.to_dict()
                    )
                else:
                    return ToolResult(
                        status=ToolStatus.FAILURE,
                        error=f"Service not found: {service}"
                    )
                    
            elif operation in ['start', 'stop', 'restart', 'reload', 'enable', 'disable']:
                if not service:
                    return ToolResult(
                        status=ToolStatus.FAILURE,
                        error="service name is required"
                    )
                
                op_map = {
                    'start': self.start,
                    'stop': self.stop,
                    'restart': self.restart,
                    'reload': self.reload,
                    'enable': self.enable,
                    'disable': self.disable
                }
                
                result = await op_map[operation](service)
                
                return ToolResult(
                    status=ToolStatus.SUCCESS if result.success else ToolStatus.FAILURE,
                    data=result.to_dict(),
                    error=result.error
                )
                
            elif operation == 'logs':
                if not service:
                    return ToolResult(
                        status=ToolStatus.FAILURE,
                        error="service name is required"
                    )
                
                logs = await self.get_logs(
                    service,
                    lines=kwargs.get('lines', 100)
                )
                
                return ToolResult(
                    status=ToolStatus.SUCCESS,
                    data={'service': service, 'logs': logs}
                )
                
            elif operation == 'daemon_reload':
                result = await self.daemon_reload()
                
                return ToolResult(
                    status=ToolStatus.SUCCESS if result.success else ToolStatus.FAILURE,
                    data=result.to_dict(),
                    error=result.error
                )
                
            else:
                return ToolResult(
                    status=ToolStatus.FAILURE,
                    error=f"Unknown operation: {operation}"
                )
                
        except Exception as e:
            logger.error(f"ServiceTools error: {e}")
            return ToolResult(
                status=ToolStatus.FAILURE,
                error=str(e)
            )


# Create singleton instance
service_tools = ServiceTools()


# Register the tool
def register():
    """Register service tools with the registry."""
    tool_registry.register(service_tools)


# Auto-register on import
try:
    register()
except Exception as e:
    logger.warning(f"Could not auto-register service_tools: {e}")