"""
Shell Executor Tool - Safe shell command execution.
Provides controlled access to system shell with security measures.
"""

import asyncio
import os
import shlex
import signal
import subprocess
from pathlib import Path
from typing import Optional, List, Dict, Any, Tuple, Set
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import logging
import re

# Import from our tool system
import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from tools.base_tool import (
    BaseTool, ToolResult, ToolStatus, ToolCategory,
    RiskLevel, tool_registry
)
from output.output_manager import OutputManager

logger = logging.getLogger(__name__)


class ShellType(Enum):
    """Supported shell types."""
    BASH = "bash"
    SH = "sh"
    ZSH = "zsh"
    FISH = "fish"
    POWERSHELL = "powershell"
    CMD = "cmd"


class ExecutionMode(Enum):
    """Command execution modes."""
    SYNC = "sync"           # Wait for completion
    ASYNC = "async"         # Run in background
    STREAM = "stream"       # Stream output
    INTERACTIVE = "interactive"  # Interactive mode


@dataclass
class CommandResult:
    """Result of a shell command execution."""
    success: bool
    command: str
    exit_code: int
    stdout: str
    stderr: str
    execution_time_ms: float
    killed: bool = False
    timed_out: bool = False
    pid: Optional[int] = None
    error: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'success': self.success,
            'command': self.command,
            'exit_code': self.exit_code,
            'stdout': self.stdout,
            'stderr': self.stderr,
            'execution_time_ms': self.execution_time_ms,
            'killed': self.killed,
            'timed_out': self.timed_out,
            'pid': self.pid,
            'error': self.error
        }


@dataclass 
class ShellSecurityConfig:
    """Security configuration for shell execution."""
    
    # Whitelisted commands (empty = all allowed minus blacklist)
    whitelist: Set[str] = field(default_factory=set)
    
    # Blacklisted commands (always blocked)
    blacklist: Set[str] = field(default_factory=lambda: {
        'rm -rf /',
        'rm -rf /*',
        'mkfs',
        'dd if=/dev/zero',
        'dd if=/dev/random',
        ':(){ :|:& };:',  # Fork bomb
        'chmod -R 777 /',
        'chown -R',
        '> /dev/sda',
        'mv /* /dev/null',
        'wget | sh',
        'curl | sh',
        'wget | bash',
        'curl | bash',
    })
    
    # Blocked command patterns (regex)
    blocked_patterns: List[str] = field(default_factory=lambda: [
        r'rm\s+(-[rf]+\s+)?/',  # rm with root path
        r'>\s*/dev/[sh]d[a-z]',  # Write to disk device
        r'mkfs\.',  # Format filesystem
        r'dd\s+if=/dev/(zero|random|urandom)',  # DD dangerous
        r'chmod\s+(-R\s+)?777\s+/',  # Chmod 777 on root
        r'\|\s*(ba)?sh',  # Pipe to shell
        r'eval\s+.*\$',  # Eval with variables
    ])
    
    # Require confirmation for these commands
    confirm_commands: Set[str] = field(default_factory=lambda: {
        'rm', 'rmdir', 'mv', 'dd', 'mkfs', 'fdisk', 
        'shutdown', 'reboot', 'halt', 'poweroff',
        'kill', 'killall', 'pkill',
        'chmod', 'chown', 'chgrp',
        'iptables', 'ufw', 'firewall-cmd',
        'systemctl stop', 'systemctl disable',
        'apt remove', 'apt purge', 'apt autoremove',
        'yum remove', 'dnf remove',
        'pip uninstall', 'npm uninstall',
    })
    
    # Maximum output size (bytes)
    max_output_size: int = 10 * 1024 * 1024  # 10MB
    
    # Maximum execution time (seconds)
    max_execution_time: float = 300.0  # 5 minutes
    
    # Allow sudo
    allow_sudo: bool = False
    
    # Allow background processes
    allow_background: bool = True
    
    # Allowed environment variables to pass
    allowed_env_vars: Set[str] = field(default_factory=lambda: {
        'PATH', 'HOME', 'USER', 'LANG', 'LC_ALL', 'TERM',
        'SHELL', 'PWD', 'HOSTNAME', 'TZ'
    })


class ShellExecutor(BaseTool):
    """
    Safe shell command executor.
    
    Features:
    - Command whitelisting/blacklisting
    - Pattern-based blocking
    - Timeout enforcement
    - Output size limits
    - Environment sanitization
    - Async execution
    - Output streaming
    - Process management
    """
    
    def __init__(self, config: Optional[ShellSecurityConfig] = None):
        super().__init__(
            name="shell_executor",
            description="Execute shell commands with security controls",
            category=ToolCategory.SYSTEM,
            risk_level=RiskLevel.CRITICAL,
            requires_confirmation=True,
            timeout=300.0,
            version="1.0.0"
        )
        self.config = config or ShellSecurityConfig()
        self.output = OutputManager()
        
        # Track running processes
        self._running_processes: Dict[int, asyncio.subprocess.Process] = {}
        
        # Compiled regex patterns
        self._blocked_patterns = [
            re.compile(p, re.IGNORECASE) 
            for p in self.config.blocked_patterns
        ]
        
        # Detect available shell
        self._default_shell = self._detect_shell()
    
    def _detect_shell(self) -> str:
        """Detect the default shell."""
        shell = os.environ.get('SHELL', '/bin/sh')
        
        # Check if bash is available
        if os.path.exists('/bin/bash'):
            return '/bin/bash'
        elif os.path.exists('/usr/bin/bash'):
            return '/usr/bin/bash'
        elif os.path.exists(shell):
            return shell
        else:
            return '/bin/sh'
    
    def _sanitize_environment(self) -> Dict[str, str]:
        """Create sanitized environment for command execution."""
        env = {}
        for key in self.config.allowed_env_vars:
            if key in os.environ:
                env[key] = os.environ[key]
        
        # Ensure PATH is set
        if 'PATH' not in env:
            env['PATH'] = '/usr/local/bin:/usr/bin:/bin'
        
        return env
    
    def _is_command_blocked(self, command: str) -> Tuple[bool, str]:
        """
        Check if command is blocked.
        
        Returns:
            Tuple of (is_blocked, reason)
        """
        # Normalize command
        cmd_lower = command.lower().strip()
        
        # Check direct blacklist
        for blocked in self.config.blacklist:
            if blocked.lower() in cmd_lower:
                return True, f"Command contains blocked pattern: {blocked}"
        
        # Check regex patterns
        for pattern in self._blocked_patterns:
            if pattern.search(command):
                return True, f"Command matches blocked pattern"
        
        # Check sudo if not allowed
        if not self.config.allow_sudo:
            if cmd_lower.startswith('sudo ') or ' sudo ' in cmd_lower:
                return True, "sudo is not allowed"
        
        # Check whitelist if specified
        if self.config.whitelist:
            cmd_base = cmd_lower.split()[0] if cmd_lower else ''
            if cmd_base not in self.config.whitelist:
                return True, f"Command '{cmd_base}' not in whitelist"
        
        return False, ""
    
    def _needs_confirmation(self, command: str) -> bool:
        """Check if command needs user confirmation."""
        cmd_lower = command.lower().strip()
        
        for confirm_cmd in self.config.confirm_commands:
            if cmd_lower.startswith(confirm_cmd.lower()):
                return True
            if f' {confirm_cmd.lower()}' in cmd_lower:
                return True
        
        return False
    
    async def execute_command(
        self,
        command: str,
        shell: Optional[str] = None,
        cwd: Optional[str] = None,
        env: Optional[Dict[str, str]] = None,
        timeout: Optional[float] = None,
        capture_output: bool = True,
        stdin_input: Optional[str] = None,
        combine_stderr: bool = False
    ) -> CommandResult:
        """
        Execute a shell command.
        
        Args:
            command: Command to execute
            shell: Shell to use (default: auto-detect)
            cwd: Working directory
            env: Additional environment variables
            timeout: Execution timeout in seconds
            capture_output: Capture stdout/stderr
            stdin_input: Input to send to stdin
            combine_stderr: Combine stderr with stdout
            
        Returns:
            CommandResult with execution details
        """
        start_time = datetime.now()
        timeout = timeout or self.config.max_execution_time
        
        # Security check
        is_blocked, reason = self._is_command_blocked(command)
        if is_blocked:
            logger.warning(f"Blocked command: {command} - {reason}")
            return CommandResult(
                success=False,
                command=command,
                exit_code=-1,
                stdout="",
                stderr="",
                execution_time_ms=0,
                error=f"Command blocked: {reason}"
            )
        
        try:
            # Prepare shell
            shell_path = shell or self._default_shell
            
            # Prepare environment
            execution_env = self._sanitize_environment()
            if env:
                execution_env.update(env)
            
            # Prepare working directory
            if cwd:
                cwd_path = Path(cwd).resolve()
                if not cwd_path.exists():
                    return CommandResult(
                        success=False,
                        command=command,
                        exit_code=-1,
                        stdout="",
                        stderr="",
                        execution_time_ms=0,
                        error=f"Working directory not found: {cwd}"
                    )
                cwd = str(cwd_path)
            
            # Prepare stderr handling
            stderr_dest = asyncio.subprocess.STDOUT if combine_stderr else asyncio.subprocess.PIPE
            
            # Create process
            process = await asyncio.create_subprocess_shell(
                command,
                stdin=asyncio.subprocess.PIPE if stdin_input else None,
                stdout=asyncio.subprocess.PIPE if capture_output else None,
                stderr=stderr_dest if capture_output else None,
                cwd=cwd,
                env=execution_env,
                executable=shell_path
            )
            
            # Track process
            if process.pid:
                self._running_processes[process.pid] = process
            
            # Execute with timeout
            try:
                stdin_bytes = stdin_input.encode() if stdin_input else None
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    process.communicate(input=stdin_bytes),
                    timeout=timeout
                )
                
                timed_out = False
                killed = False
                
            except asyncio.TimeoutError:
                # Kill process on timeout
                try:
                    process.kill()
                    await process.wait()
                except:
                    pass
                
                stdout_bytes = b""
                stderr_bytes = b""
                timed_out = True
                killed = True
            
            # Remove from tracking
            if process.pid and process.pid in self._running_processes:
                del self._running_processes[process.pid]
            
            # Process output
            stdout = ""
            stderr = ""
            
            if capture_output:
                if stdout_bytes:
                    # Limit output size
                    if len(stdout_bytes) > self.config.max_output_size:
                        stdout_bytes = stdout_bytes[:self.config.max_output_size]
                        stdout = stdout_bytes.decode('utf-8', errors='replace')
                        stdout += "\n... (output truncated)"
                    else:
                        stdout = stdout_bytes.decode('utf-8', errors='replace')
                
                if stderr_bytes:
                    if len(stderr_bytes) > self.config.max_output_size:
                        stderr_bytes = stderr_bytes[:self.config.max_output_size]
                        stderr = stderr_bytes.decode('utf-8', errors='replace')
                        stderr += "\n... (output truncated)"
                    else:
                        stderr = stderr_bytes.decode('utf-8', errors='replace')
            
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            
            return CommandResult(
                success=process.returncode == 0 and not timed_out,
                command=command,
                exit_code=process.returncode or -1,
                stdout=stdout,
                stderr=stderr,
                execution_time_ms=elapsed,
                killed=killed,
                timed_out=timed_out,
                pid=process.pid
            )
            
        except Exception as e:
            logger.error(f"Command execution error: {e}")
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            return CommandResult(
                success=False,
                command=command,
                exit_code=-1,
                stdout="",
                stderr="",
                execution_time_ms=elapsed,
                error=str(e)
            )
    
    async def execute_script(
        self,
        script: str,
        shell: Optional[str] = None,
        cwd: Optional[str] = None,
        env: Optional[Dict[str, str]] = None,
        timeout: Optional[float] = None
    ) -> CommandResult:
        """
        Execute a multi-line script.
        
        Args:
            script: Script content
            shell: Shell to use
            cwd: Working directory
            env: Environment variables
            timeout: Execution timeout
            
        Returns:
            CommandResult with execution details
        """
        import tempfile
        
        start_time = datetime.now()
        shell_path = shell or self._default_shell
        
        # Security check each line
        for line in script.split('\n'):
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            is_blocked, reason = self._is_command_blocked(line)
            if is_blocked:
                return CommandResult(
                    success=False,
                    command=script[:100] + "...",
                    exit_code=-1,
                    stdout="",
                    stderr="",
                    execution_time_ms=0,
                    error=f"Script contains blocked command: {reason}"
                )
        
        try:
            # Create temporary script file
            with tempfile.NamedTemporaryFile(
                mode='w',
                suffix='.sh',
                delete=False
            ) as f:
                f.write(script)
                script_path = f.name
            
            try:
                # Make executable
                os.chmod(script_path, 0o700)
                
                # Execute script
                result = await self.execute_command(
                    script_path,
                    shell=shell_path,
                    cwd=cwd,
                    env=env,
                    timeout=timeout
                )
                
                # Update command in result to show it was a script
                result.command = f"[script: {len(script)} chars]"
                
                return result
                
            finally:
                # Clean up script file
                try:
                    os.unlink(script_path)
                except:
                    pass
                    
        except Exception as e:
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            return CommandResult(
                success=False,
                command="[script]",
                exit_code=-1,
                stdout="",
                stderr="",
                execution_time_ms=elapsed,
                error=str(e)
            )
    
    async def run_background(
        self,
        command: str,
        log_file: Optional[str] = None
    ) -> CommandResult:
        """
        Run command in background.
        
        Args:
            command: Command to run
            log_file: File to log output (optional)
            
        Returns:
            CommandResult with PID
        """
        if not self.config.allow_background:
            return CommandResult(
                success=False,
                command=command,
                exit_code=-1,
                stdout="",
                stderr="",
                execution_time_ms=0,
                error="Background execution not allowed"
            )
        
        # Security check
        is_blocked, reason = self._is_command_blocked(command)
        if is_blocked:
            return CommandResult(
                success=False,
                command=command,
                exit_code=-1,
                stdout="",
                stderr="",
                execution_time_ms=0,
                error=f"Command blocked: {reason}"
            )
        
        start_time = datetime.now()
        
        try:
            # Build command with optional logging
            if log_file:
                full_command = f"nohup {command} > {log_file} 2>&1 &"
            else:
                full_command = f"nohup {command} > /dev/null 2>&1 &"
            
            process = await asyncio.create_subprocess_shell(
                full_command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=self._sanitize_environment()
            )
            
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            
            return CommandResult(
                success=True,
                command=command,
                exit_code=0,
                stdout=f"Started in background",
                stderr="",
                execution_time_ms=elapsed,
                pid=process.pid
            )
            
        except Exception as e:
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            return CommandResult(
                success=False,
                command=command,
                exit_code=-1,
                stdout="",
                stderr="",
                execution_time_ms=elapsed,
                error=str(e)
            )
    
    async def kill_process(self, pid: int, signal_type: int = signal.SIGTERM) -> bool:
        """
        Kill a running process.
        
        Args:
            pid: Process ID
            signal_type: Signal to send (default: SIGTERM)
            
        Returns:
            True if successful
        """
        try:
            os.kill(pid, signal_type)
            
            # Remove from tracking if present
            if pid in self._running_processes:
                del self._running_processes[pid]
            
            return True
        except ProcessLookupError:
            return False
        except PermissionError:
            logger.warning(f"Permission denied killing PID {pid}")
            return False
        except Exception as e:
            logger.error(f"Error killing PID {pid}: {e}")
            return False
    
    async def get_running_processes(self) -> List[int]:
        """Get list of tracked running processes."""
        # Clean up finished processes
        finished = []
        for pid, proc in self._running_processes.items():
            if proc.returncode is not None:
                finished.append(pid)
        
        for pid in finished:
            del self._running_processes[pid]
        
        return list(self._running_processes.keys())
    
    async def which(self, command: str) -> Optional[str]:
        """
        Find path to command executable.
        
        Args:
            command: Command name
            
        Returns:
            Path to executable or None
        """
        result = await self.execute_command(
            f"which {shlex.quote(command)}",
            timeout=5.0
        )
        
        if result.success and result.stdout.strip():
            return result.stdout.strip()
        return None
    
    async def execute(self, **kwargs) -> ToolResult:
        """
        Execute shell operation.
        
        Supported operations:
        - command: Execute single command
        - script: Execute multi-line script
        - background: Run in background
        - kill: Kill process
        - which: Find command path
        """
        operation = kwargs.get('operation', 'command')
        
        start_time = datetime.now()
        
        try:
            if operation == 'command':
                command = kwargs.get('command') or kwargs.get('cmd')
                if not command:
                    return ToolResult(
                        status=ToolStatus.FAILURE,
                        error="command is required"
                    )
                
                result = await self.execute_command(
                    command,
                    shell=kwargs.get('shell'),
                    cwd=kwargs.get('cwd'),
                    env=kwargs.get('env'),
                    timeout=kwargs.get('timeout'),
                    capture_output=kwargs.get('capture_output', True),
                    stdin_input=kwargs.get('stdin'),
                    combine_stderr=kwargs.get('combine_stderr', False)
                )
                
            elif operation == 'script':
                script = kwargs.get('script')
                if not script:
                    return ToolResult(
                        status=ToolStatus.FAILURE,
                        error="script is required"
                    )
                
                result = await self.execute_script(
                    script,
                    shell=kwargs.get('shell'),
                    cwd=kwargs.get('cwd'),
                    env=kwargs.get('env'),
                    timeout=kwargs.get('timeout')
                )
                
            elif operation == 'background':
                command = kwargs.get('command') or kwargs.get('cmd')
                if not command:
                    return ToolResult(
                        status=ToolStatus.FAILURE,
                        error="command is required"
                    )
                
                result = await self.run_background(
                    command,
                    log_file=kwargs.get('log_file')
                )
                
            elif operation == 'kill':
                pid = kwargs.get('pid')
                if not pid:
                    return ToolResult(
                        status=ToolStatus.FAILURE,
                        error="pid is required"
                    )
                
                success = await self.kill_process(
                    int(pid),
                    kwargs.get('signal', signal.SIGTERM)
                )
                
                return ToolResult(
                    status=ToolStatus.SUCCESS if success else ToolStatus.FAILURE,
                    data={'pid': pid, 'killed': success}
                )
                
            elif operation == 'which':
                command = kwargs.get('command') or kwargs.get('cmd')
                if not command:
                    return ToolResult(
                        status=ToolStatus.FAILURE,
                        error="command is required"
                    )
                
                path = await self.which(command)
                
                return ToolResult(
                    status=ToolStatus.SUCCESS if path else ToolStatus.FAILURE,
                    data={'command': command, 'path': path}
                )
                
            else:
                return ToolResult(
                    status=ToolStatus.FAILURE,
                    error=f"Unknown operation: {operation}"
                )
            
            elapsed = (datetime.now() - start_time).total_seconds()
            
            if result.success:
                return ToolResult(
                    status=ToolStatus.SUCCESS,
                    data=result.to_dict(),
                    execution_time=elapsed
                )
            else:
                return ToolResult(
                    status=ToolStatus.FAILURE,
                    data=result.to_dict(),
                    error=result.error or result.stderr,
                    execution_time=elapsed
                )
                
        except Exception as e:
            logger.error(f"ShellExecutor error: {e}")
            return ToolResult(
                status=ToolStatus.FAILURE,
                error=str(e)
            )


# Create singleton instance
shell_executor = ShellExecutor()


# Register the tool
def register():
    """Register shell executor with the registry."""
    tool_registry.register(shell_executor)


# Auto-register on import
try:
    register()
except Exception as e:
    logger.warning(f"Could not auto-register shell_executor: {e}")


# Convenience function
async def run(command: str, **kwargs) -> CommandResult:
    """Execute a shell command."""
    return await shell_executor.execute_command(command, **kwargs)