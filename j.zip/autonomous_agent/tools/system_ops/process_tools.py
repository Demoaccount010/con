"""
Process Tools - Process management and monitoring.
List, inspect, and manage system processes.
"""

import asyncio
import os
import signal
from pathlib import Path
from typing import Optional, List, Dict, Any, Set
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import logging
import re

# Import from our tool system
import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from tools.base_tool import (
    BaseTool, ToolResult, ToolStatus, ToolCategory,
    RiskLevel, tool_registry
)
from tools.system_ops.shell_executor import shell_executor

logger = logging.getLogger(__name__)


@dataclass
class ProcessInfo:
    """Information about a process."""
    pid: int
    ppid: int
    name: str
    status: str
    user: str
    cpu_percent: float
    memory_percent: float
    memory_rss: int  # Resident Set Size in bytes
    memory_vms: int  # Virtual Memory Size in bytes
    threads: int
    created: Optional[datetime]
    command: str
    cwd: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'pid': self.pid,
            'ppid': self.ppid,
            'name': self.name,
            'status': self.status,
            'user': self.user,
            'cpu_percent': self.cpu_percent,
            'memory_percent': self.memory_percent,
            'memory_rss': self.memory_rss,
            'memory_rss_human': self._human_size(self.memory_rss),
            'memory_vms': self.memory_vms,
            'memory_vms_human': self._human_size(self.memory_vms),
            'threads': self.threads,
            'created': self.created.isoformat() if self.created else None,
            'command': self.command,
            'cwd': self.cwd
        }
    
    @staticmethod
    def _human_size(size: int) -> str:
        """Convert bytes to human readable."""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024:
                return f"{size:.1f} {unit}"
            size /= 1024
        return f"{size:.1f} TB"


@dataclass
class ProcessTreeNode:
    """Node in process tree."""
    process: ProcessInfo
    children: List['ProcessTreeNode'] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'process': self.process.to_dict(),
            'children': [c.to_dict() for c in self.children]
        }


class ProcessSignal(Enum):
    """Process signals."""
    SIGTERM = signal.SIGTERM
    SIGKILL = signal.SIGKILL
    SIGHUP = signal.SIGHUP
    SIGINT = signal.SIGINT
    SIGSTOP = signal.SIGSTOP
    SIGCONT = signal.SIGCONT


class ProcessTools(BaseTool):
    """
    Process management tool.
    
    Features:
    - List all processes
    - Get process details
    - Process tree visualization
    - Kill processes
    - Find processes by name/pattern
    - Monitor process resource usage
    - Wait for process completion
    """
    
    def __init__(self):
        super().__init__(
            name="process_tools",
            description="Process management and monitoring",
            category=ToolCategory.SYSTEM,
            risk_level=RiskLevel.HIGH,
            requires_confirmation=False,  # Kill operations will require confirmation
            timeout=60.0,
            version="1.0.0"
        )
        
        # Try to import psutil for better process info
        self._has_psutil = False
        try:
            import psutil
            self._has_psutil = True
        except ImportError:
            logger.info("psutil not available, using fallback methods")
    
    async def _get_process_info_psutil(self, pid: int) -> Optional[ProcessInfo]:
        """Get process info using psutil."""
        try:
            import psutil
            
            proc = psutil.Process(pid)
            
            with proc.oneshot():
                return ProcessInfo(
                    pid=proc.pid,
                    ppid=proc.ppid(),
                    name=proc.name(),
                    status=proc.status(),
                    user=proc.username(),
                    cpu_percent=proc.cpu_percent(),
                    memory_percent=proc.memory_percent(),
                    memory_rss=proc.memory_info().rss,
                    memory_vms=proc.memory_info().vms,
                    threads=proc.num_threads(),
                    created=datetime.fromtimestamp(proc.create_time()),
                    command=' '.join(proc.cmdline()),
                    cwd=proc.cwd() if proc.is_running() else None
                )
        except Exception as e:
            logger.debug(f"Could not get process info for PID {pid}: {e}")
            return None
    
    async def _get_process_info_fallback(self, pid: int) -> Optional[ProcessInfo]:
        """Get process info using /proc filesystem."""
        try:
            proc_path = Path(f'/proc/{pid}')
            
            if not proc_path.exists():
                return None
            
            # Read stat file
            stat_file = proc_path / 'stat'
            with open(stat_file, 'r') as f:
                stat_content = f.read()
            
            # Parse stat (format: pid (name) state ppid ...)
            match = re.match(r'(\d+) \((.+)\) (\w) (\d+)', stat_content)
            if not match:
                return None
            
            pid_parsed, name, status, ppid = match.groups()
            
            # Read status file for memory
            status_file = proc_path / 'status'
            status_dict = {}
            with open(status_file, 'r') as f:
                for line in f:
                    if ':' in line:
                        key, value = line.split(':', 1)
                        status_dict[key.strip()] = value.strip()
            
            # Parse memory values
            rss = 0
            vms = 0
            if 'VmRSS' in status_dict:
                rss = int(status_dict['VmRSS'].split()[0]) * 1024
            if 'VmSize' in status_dict:
                vms = int(status_dict['VmSize'].split()[0]) * 1024
            
            # Get user
            uid = int(status_dict.get('Uid', '0').split()[0])
            try:
                import pwd
                user = pwd.getpwuid(uid).pw_name
            except:
                user = str(uid)
            
            # Get command
            cmdline_file = proc_path / 'cmdline'
            with open(cmdline_file, 'rb') as f:
                cmdline = f.read().decode('utf-8', errors='replace')
                command = cmdline.replace('\x00', ' ').strip()
            
            # Get threads
            threads = len(list((proc_path / 'task').iterdir())) if (proc_path / 'task').exists() else 1
            
            # Status mapping
            status_map = {
                'R': 'running',
                'S': 'sleeping',
                'D': 'disk-sleep',
                'Z': 'zombie',
                'T': 'stopped',
                'I': 'idle'
            }
            
            return ProcessInfo(
                pid=int(pid_parsed),
                ppid=int(ppid),
                name=name,
                status=status_map.get(status, status),
                user=user,
                cpu_percent=0.0,  # Can't easily get without psutil
                memory_percent=0.0,
                memory_rss=rss,
                memory_vms=vms,
                threads=threads,
                created=None,  # Would need to parse from stat
                command=command or name
            )
            
        except Exception as e:
            logger.debug(f"Could not get process info for PID {pid}: {e}")
            return None
    
    async def get_process(self, pid: int) -> Optional[ProcessInfo]:
        """
        Get information about a specific process.
        
        Args:
            pid: Process ID
            
        Returns:
            ProcessInfo or None if not found
        """
        if self._has_psutil:
            return await self._get_process_info_psutil(pid)
        else:
            return await self._get_process_info_fallback(pid)
    
    async def list_processes(
        self,
        user: Optional[str] = None,
        name_pattern: Optional[str] = None,
        sort_by: str = 'cpu',
        limit: Optional[int] = None,
        include_threads: bool = False
    ) -> List[ProcessInfo]:
        """
        List system processes.
        
        Args:
            user: Filter by user
            name_pattern: Filter by name pattern (regex)
            sort_by: Sort by 'cpu', 'memory', 'pid', 'name'
            limit: Maximum number of processes
            include_threads: Include thread info
            
        Returns:
            List of ProcessInfo objects
        """
        processes = []
        
        if self._has_psutil:
            import psutil
            
            for proc in psutil.process_iter(['pid', 'name', 'username']):
                try:
                    # Filter by user
                    if user and proc.info['username'] != user:
                        continue
                    
                    # Filter by name pattern
                    if name_pattern:
                        if not re.search(name_pattern, proc.info['name'], re.IGNORECASE):
                            continue
                    
                    info = await self._get_process_info_psutil(proc.info['pid'])
                    if info:
                        processes.append(info)
                        
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        else:
            # Fallback: read from /proc
            proc_dir = Path('/proc')
            for pid_dir in proc_dir.iterdir():
                if not pid_dir.name.isdigit():
                    continue
                
                pid = int(pid_dir.name)
                info = await self._get_process_info_fallback(pid)
                
                if info:
                    # Filter by user
                    if user and info.user != user:
                        continue
                    
                    # Filter by name pattern
                    if name_pattern:
                        if not re.search(name_pattern, info.name, re.IGNORECASE):
                            continue
                    
                    processes.append(info)
        
        # Sort
        sort_keys = {
            'cpu': lambda p: p.cpu_percent,
            'memory': lambda p: p.memory_percent,
            'pid': lambda p: p.pid,
            'name': lambda p: p.name.lower()
        }
        
        key_func = sort_keys.get(sort_by, sort_keys['cpu'])
        processes.sort(key=key_func, reverse=(sort_by in ['cpu', 'memory']))
        
        # Limit
        if limit:
            processes = processes[:limit]
        
        return processes
    
    async def find_by_name(self, name: str, exact: bool = False) -> List[ProcessInfo]:
        """
        Find processes by name.
        
        Args:
            name: Process name to find
            exact: Exact match only
            
        Returns:
            List of matching processes
        """
        if exact:
            pattern = f"^{re.escape(name)}$"
        else:
            pattern = re.escape(name)
        
        return await self.list_processes(name_pattern=pattern)
    
    async def find_by_port(self, port: int) -> List[ProcessInfo]:
        """
        Find processes using a specific port.
        
        Args:
            port: Port number
            
        Returns:
            List of processes using the port
        """
        pids = set()
        
        if self._has_psutil:
            import psutil
            
            for conn in psutil.net_connections():
                if conn.laddr and conn.laddr.port == port:
                    if conn.pid:
                        pids.add(conn.pid)
                if conn.raddr and conn.raddr.port == port:
                    if conn.pid:
                        pids.add(conn.pid)
        else:
            # Use lsof as fallback
            result = await shell_executor.execute_command(
                f"lsof -i :{port} -t 2>/dev/null",
                timeout=10.0
            )
            if result.success and result.stdout:
                for line in result.stdout.strip().split('\n'):
                    if line.isdigit():
                        pids.add(int(line))
        
        processes = []
        for pid in pids:
            info = await self.get_process(pid)
            if info:
                processes.append(info)
        
        return processes
    
    async def get_process_tree(self, root_pid: Optional[int] = None) -> List[ProcessTreeNode]:
        """
        Get process tree.
        
        Args:
            root_pid: Root PID (None for all root processes)
            
        Returns:
            List of ProcessTreeNode objects
        """
        all_processes = await self.list_processes()
        
        # Build pid -> process mapping
        pid_map: Dict[int, ProcessInfo] = {p.pid: p for p in all_processes}
        
        # Build pid -> children mapping
        children_map: Dict[int, List[int]] = {}
        for proc in all_processes:
            if proc.ppid not in children_map:
                children_map[proc.ppid] = []
            children_map[proc.ppid].append(proc.pid)
        
        def build_tree(pid: int) -> Optional[ProcessTreeNode]:
            if pid not in pid_map:
                return None
            
            proc = pid_map[pid]
            node = ProcessTreeNode(process=proc)
            
            if pid in children_map:
                for child_pid in children_map[pid]:
                    child_node = build_tree(child_pid)
                    if child_node:
                        node.children.append(child_node)
            
            return node
        
        if root_pid:
            root_node = build_tree(root_pid)
            return [root_node] if root_node else []
        else:
            # Find root processes (ppid = 0 or 1, or ppid not in pid_map)
            roots = []
            for proc in all_processes:
                if proc.ppid == 0 or proc.ppid == 1 or proc.ppid not in pid_map:
                    node = build_tree(proc.pid)
                    if node:
                        roots.append(node)
            return roots
    
    async def kill(
        self,
        pid: int,
        sig: ProcessSignal = ProcessSignal.SIGTERM,
        wait: bool = False,
        timeout: float = 10.0
    ) -> bool:
        """
        Kill a process.
        
        Args:
            pid: Process ID
            sig: Signal to send
            wait: Wait for process to terminate
            timeout: Wait timeout in seconds
            
        Returns:
            True if successful
        """
        try:
            os.kill(pid, sig.value)
            
            if wait:
                start = datetime.now()
                while (datetime.now() - start).total_seconds() < timeout:
                    try:
                        os.kill(pid, 0)  # Check if still running
                        await asyncio.sleep(0.1)
                    except ProcessLookupError:
                        return True
                
                # Process didn't terminate, force kill
                if sig != ProcessSignal.SIGKILL:
                    os.kill(pid, signal.SIGKILL)
                    await asyncio.sleep(0.5)
            
            return True
            
        except ProcessLookupError:
            return True  # Already dead
        except PermissionError:
            logger.warning(f"Permission denied killing PID {pid}")
            return False
        except Exception as e:
            logger.error(f"Error killing PID {pid}: {e}")
            return False
    
    async def kill_by_name(
        self,
        name: str,
        sig: ProcessSignal = ProcessSignal.SIGTERM,
        exact: bool = False
    ) -> Dict[int, bool]:
        """
        Kill processes by name.
        
        Args:
            name: Process name
            sig: Signal to send
            exact: Exact name match
            
        Returns:
            Dict mapping PID to success status
        """
        processes = await self.find_by_name(name, exact=exact)
        results = {}
        
        for proc in processes:
            results[proc.pid] = await self.kill(proc.pid, sig)
        
        return results
    
    async def wait_for_exit(
        self,
        pid: int,
        timeout: float = 60.0
    ) -> bool:
        """
        Wait for a process to exit.
        
        Args:
            pid: Process ID
            timeout: Maximum wait time
            
        Returns:
            True if process exited, False if timeout
        """
        start = datetime.now()
        
        while (datetime.now() - start).total_seconds() < timeout:
            try:
                os.kill(pid, 0)  # Check if running
                await asyncio.sleep(0.5)
            except ProcessLookupError:
                return True
            except PermissionError:
                # Can't check, assume still running
                await asyncio.sleep(0.5)
        
        return False
    
    async def get_resource_usage(self) -> Dict[str, Any]:
        """
        Get system-wide resource usage.
        
        Returns:
            Dict with CPU, memory, and process counts
        """
        if self._has_psutil:
            import psutil
            
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            
            return {
                'cpu_percent': cpu_percent,
                'cpu_count': psutil.cpu_count(),
                'memory_total': memory.total,
                'memory_available': memory.available,
                'memory_percent': memory.percent,
                'process_count': len(psutil.pids()),
                'boot_time': datetime.fromtimestamp(psutil.boot_time()).isoformat()
            }
        else:
            # Fallback using shell commands
            result = await shell_executor.execute_command(
                "cat /proc/loadavg && cat /proc/meminfo | head -3",
                timeout=5.0
            )
            
            return {
                'raw_output': result.stdout if result.success else 'unavailable'
            }
    
    async def execute(self, **kwargs) -> ToolResult:
        """
        Execute process operation.
        
        Supported operations:
        - list: List processes
        - get: Get process info
        - find: Find by name
        - find_port: Find by port
        - tree: Get process tree
        - kill: Kill process
        - kill_name: Kill by name
        - wait: Wait for exit
        - usage: Get resource usage
        """
        operation = kwargs.get('operation', 'list')
        
        start_time = datetime.now()
        
        try:
            if operation == 'list':
                processes = await self.list_processes(
                    user=kwargs.get('user'),
                    name_pattern=kwargs.get('pattern'),
                    sort_by=kwargs.get('sort_by', 'cpu'),
                    limit=kwargs.get('limit')
                )
                
                return ToolResult(
                    status=ToolStatus.SUCCESS,
                    data={
                        'count': len(processes),
                        'processes': [p.to_dict() for p in processes]
                    }
                )
                
            elif operation == 'get':
                pid = kwargs.get('pid')
                if not pid:
                    return ToolResult(
                        status=ToolStatus.FAILURE,
                        error="pid is required"
                    )
                
                info = await self.get_process(int(pid))
                
                if info:
                    return ToolResult(
                        status=ToolStatus.SUCCESS,
                        data=info.to_dict()
                    )
                else:
                    return ToolResult(
                        status=ToolStatus.FAILURE,
                        error=f"Process {pid} not found"
                    )
                    
            elif operation == 'find':
                name = kwargs.get('name')
                if not name:
                    return ToolResult(
                        status=ToolStatus.FAILURE,
                        error="name is required"
                    )
                
                processes = await self.find_by_name(
                    name,
                    exact=kwargs.get('exact', False)
                )
                
                return ToolResult(
                    status=ToolStatus.SUCCESS,
                    data={
                        'count': len(processes),
                        'processes': [p.to_dict() for p in processes]
                    }
                )
                
            elif operation == 'find_port':
                port = kwargs.get('port')
                if not port:
                    return ToolResult(
                        status=ToolStatus.FAILURE,
                        error="port is required"
                    )
                
                processes = await self.find_by_port(int(port))
                
                return ToolResult(
                    status=ToolStatus.SUCCESS,
                    data={
                        'port': port,
                        'count': len(processes),
                        'processes': [p.to_dict() for p in processes]
                    }
                )
                
            elif operation == 'tree':
                tree = await self.get_process_tree(
                    root_pid=kwargs.get('pid')
                )
                
                return ToolResult(
                    status=ToolStatus.SUCCESS,
                    data={
                        'tree': [n.to_dict() for n in tree]
                    }
                )
                
            elif operation == 'kill':
                pid = kwargs.get('pid')
                if not pid:
                    return ToolResult(
                        status=ToolStatus.FAILURE,
                        error="pid is required"
                    )
                
                sig_name = kwargs.get('signal', 'SIGTERM')
                try:
                    sig = ProcessSignal[sig_name]
                except KeyError:
                    sig = ProcessSignal.SIGTERM
                
                success = await self.kill(
                    int(pid),
                    sig=sig,
                    wait=kwargs.get('wait', False),
                    timeout=kwargs.get('timeout', 10.0)
                )
                
                return ToolResult(
                    status=ToolStatus.SUCCESS if success else ToolStatus.FAILURE,
                    data={'pid': pid, 'killed': success, 'signal': sig_name}
                )
                
            elif operation == 'kill_name':
                name = kwargs.get('name')
                if not name:
                    return ToolResult(
                        status=ToolStatus.FAILURE,
                        error="name is required"
                    )
                
                sig_name = kwargs.get('signal', 'SIGTERM')
                try:
                    sig = ProcessSignal[sig_name]
                except KeyError:
                    sig = ProcessSignal.SIGTERM
                
                results = await self.kill_by_name(
                    name,
                    sig=sig,
                    exact=kwargs.get('exact', False)
                )
                
                return ToolResult(
                    status=ToolStatus.SUCCESS,
                    data={
                        'name': name,
                        'results': results,
                        'killed_count': sum(1 for v in results.values() if v)
                    }
                )
                
            elif operation == 'wait':
                pid = kwargs.get('pid')
                if not pid:
                    return ToolResult(
                        status=ToolStatus.FAILURE,
                        error="pid is required"
                    )
                
                exited = await self.wait_for_exit(
                    int(pid),
                    timeout=kwargs.get('timeout', 60.0)
                )
                
                return ToolResult(
                    status=ToolStatus.SUCCESS,
                    data={'pid': pid, 'exited': exited}
                )
                
            elif operation == 'usage':
                usage = await self.get_resource_usage()
                
                return ToolResult(
                    status=ToolStatus.SUCCESS,
                    data=usage
                )
                
            else:
                return ToolResult(
                    status=ToolStatus.FAILURE,
                    error=f"Unknown operation: {operation}"
                )
                
        except Exception as e:
            logger.error(f"ProcessTools error: {e}")
            return ToolResult(
                status=ToolStatus.FAILURE,
                error=str(e)
            )


# Create singleton instance
process_tools = ProcessTools()


# Register the tool
def register():
    """Register process tools with the registry."""
    tool_registry.register(process_tools)


# Auto-register on import
try:
    register()
except Exception as e:
    logger.warning(f"Could not auto-register process_tools: {e}")