"""
Health Tools - System and application health monitoring.
Monitor system resources, services, and application health.
"""

import asyncio
import os
import platform
import socket
from pathlib import Path
from typing import Optional, Dict, Any, List, Tuple, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
import logging
import json

import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from tools.base_tool import (
    BaseTool, ToolResult, ToolContext, ResultStatus,
    ToolCategory, ToolRisk
)
from tools.registry import get_registry
from tools.system_ops.shell_executor import shell_executor

logger = logging.getLogger(__name__)


class HealthStatus(Enum):
    """Health status levels."""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


class ResourceStatus(Enum):
    """Resource usage status."""
    OK = "ok"
    WARNING = "warning"
    CRITICAL = "critical"


@dataclass
class HealthCheck:
    """Result of a health check."""
    name: str
    status: HealthStatus
    message: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)
    latency_ms: Optional[float] = None
    timestamp: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'status': self.status.value,
            'message': self.message,
            'details': self.details,
            'latency_ms': self.latency_ms,
            'timestamp': self.timestamp.isoformat()
        }


@dataclass
class ResourceMetrics:
    """System resource metrics."""
    cpu_percent: float
    cpu_count: int
    memory_total: int
    memory_used: int
    memory_percent: float
    disk_total: int
    disk_used: int
    disk_percent: float
    load_average: Tuple[float, float, float]
    uptime_seconds: float
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'cpu': {
                'percent': self.cpu_percent,
                'count': self.cpu_count,
                'status': self._get_status(self.cpu_percent, 70, 90).value
            },
            'memory': {
                'total': self.memory_total,
                'total_human': self._human_size(self.memory_total),
                'used': self.memory_used,
                'used_human': self._human_size(self.memory_used),
                'percent': self.memory_percent,
                'status': self._get_status(self.memory_percent, 70, 90).value
            },
            'disk': {
                'total': self.disk_total,
                'total_human': self._human_size(self.disk_total),
                'used': self.disk_used,
                'used_human': self._human_size(self.disk_used),
                'percent': self.disk_percent,
                'status': self._get_status(self.disk_percent, 80, 95).value
            },
            'load_average': {
                '1min': self.load_average[0],
                '5min': self.load_average[1],
                '15min': self.load_average[2]
            },
            'uptime_seconds': self.uptime_seconds,
            'uptime_human': self._human_uptime(self.uptime_seconds)
        }
    
    @staticmethod
    def _get_status(value: float, warning_threshold: float, critical_threshold: float) -> ResourceStatus:
        if value >= critical_threshold:
            return ResourceStatus.CRITICAL
        elif value >= warning_threshold:
            return ResourceStatus.WARNING
        return ResourceStatus.OK
    
    @staticmethod
    def _human_size(size: int) -> str:
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size < 1024:
                return f"{size:.1f} {unit}"
            size /= 1024
        return f"{size:.1f} PB"
    
    @staticmethod
    def _human_uptime(seconds: float) -> str:
        days = int(seconds // 86400)
        hours = int((seconds % 86400) // 3600)
        minutes = int((seconds % 3600) // 60)
        
        parts = []
        if days > 0:
            parts.append(f"{days}d")
        if hours > 0:
            parts.append(f"{hours}h")
        if minutes > 0:
            parts.append(f"{minutes}m")
        
        return ' '.join(parts) if parts else "< 1m"


@dataclass
class ServiceHealth:
    """Health of a monitored service."""
    name: str
    status: HealthStatus
    host: Optional[str] = None
    port: Optional[int] = None
    response_time_ms: Optional[float] = None
    last_check: datetime = field(default_factory=datetime.now)
    error: Optional[str] = None
    consecutive_failures: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'status': self.status.value,
            'host': self.host,
            'port': self.port,
            'response_time_ms': self.response_time_ms,
            'last_check': self.last_check.isoformat(),
            'error': self.error,
            'consecutive_failures': self.consecutive_failures
        }


@dataclass
class HealthReport:
    """Complete health report."""
    overall_status: HealthStatus
    checks: List[HealthCheck]
    resources: Optional[ResourceMetrics]
    services: List[ServiceHealth]
    timestamp: datetime = field(default_factory=datetime.now)
    duration_ms: float = 0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'overall_status': self.overall_status.value,
            'checks': [c.to_dict() for c in self.checks],
            'resources': self.resources.to_dict() if self.resources else None,
            'services': [s.to_dict() for s in self.services],
            'timestamp': self.timestamp.isoformat(),
            'duration_ms': self.duration_ms,
            'summary': {
                'total_checks': len(self.checks),
                'healthy': sum(1 for c in self.checks if c.status == HealthStatus.HEALTHY),
                'degraded': sum(1 for c in self.checks if c.status == HealthStatus.DEGRADED),
                'unhealthy': sum(1 for c in self.checks if c.status == HealthStatus.UNHEALTHY)
            }
        }


class HealthTools(BaseTool):
    """
    System and application health monitoring tool.
    
    Features:
    - System resource monitoring (CPU, memory, disk)
    - Service health checks (TCP, HTTP)
    - Process monitoring
    - Custom health checks
    - Health history tracking
    - Alerting thresholds
    - Comprehensive health reports
    """
    
    def __init__(self):
        super().__init__(
            name="health_tools",
            description="System and application health monitoring",
            category=ToolCategory.MONITORING,
            risk=ToolRisk.NONE,
            requires_confirmation=False,
            timeout=60.0,
            version="1.0.0"
        )
        
        # Check for psutil
        self._has_psutil = False
        try:
            import psutil
            self._has_psutil = True
        except ImportError:
            logger.info("psutil not available, using fallback methods")
        
        # Health check registry
        self._custom_checks: Dict[str, Callable] = {}
        
        # Service monitoring
        self._monitored_services: Dict[str, Dict[str, Any]] = {}
        
        # Health history
        self._health_history: List[HealthReport] = []
        self._max_history = 100
        
        # Thresholds
        self._thresholds = {
            'cpu_warning': 70,
            'cpu_critical': 90,
            'memory_warning': 70,
            'memory_critical': 90,
            'disk_warning': 80,
            'disk_critical': 95
        }
    
    # =========================================================================
    # Resource Monitoring
    # =========================================================================
    
    async def get_resource_metrics(self) -> ResourceMetrics:
        """
        Get current system resource metrics.
        
        Returns:
            ResourceMetrics with current usage
        """
        if self._has_psutil:
            return await self._get_metrics_psutil()
        else:
            return await self._get_metrics_fallback()
    
    async def _get_metrics_psutil(self) -> ResourceMetrics:
        """Get metrics using psutil."""
        import psutil
        
        # CPU
        cpu_percent = psutil.cpu_percent(interval=1)
        cpu_count = psutil.cpu_count()
        
        # Memory
        memory = psutil.virtual_memory()
        
        # Disk
        disk = psutil.disk_usage('/')
        
        # Load average
        try:
            load_avg = os.getloadavg()
        except (OSError, AttributeError):
            load_avg = (0.0, 0.0, 0.0)
        
        # Uptime
        boot_time = psutil.boot_time()
        uptime = datetime.now().timestamp() - boot_time
        
        return ResourceMetrics(
            cpu_percent=cpu_percent,
            cpu_count=cpu_count,
            memory_total=memory.total,
            memory_used=memory.used,
            memory_percent=memory.percent,
            disk_total=disk.total,
            disk_used=disk.used,
            disk_percent=disk.percent,
            load_average=load_avg,
            uptime_seconds=uptime
        )
    
    async def _get_metrics_fallback(self) -> ResourceMetrics:
        """Get metrics using shell commands (fallback)."""
        # CPU from /proc/stat
        cpu_percent = 0.0
        cpu_count = os.cpu_count() or 1
        
        try:
            result = await shell_executor.execute_command(
                "top -bn1 | grep 'Cpu(s)' | awk '{print $2}'",
                timeout=5.0
            )
            if result.success and result.stdout.strip():
                cpu_percent = float(result.stdout.strip().replace(',', '.'))
        except:
            pass
        
        # Memory from /proc/meminfo
        memory_total = 0
        memory_used = 0
        memory_percent = 0.0
        
        try:
            result = await shell_executor.execute_command(
                "free -b | grep Mem",
                timeout=5.0
            )
            if result.success and result.stdout.strip():
                parts = result.stdout.strip().split()
                if len(parts) >= 3:
                    memory_total = int(parts[1])
                    memory_used = int(parts[2])
                    memory_percent = (memory_used / memory_total) * 100 if memory_total > 0 else 0
        except:
            pass
        
        # Disk from df
        disk_total = 0
        disk_used = 0
        disk_percent = 0.0
        
        try:
            result = await shell_executor.execute_command(
                "df -B1 / | tail -1",
                timeout=5.0
            )
            if result.success and result.stdout.strip():
                parts = result.stdout.strip().split()
                if len(parts) >= 5:
                    disk_total = int(parts[1])
                    disk_used = int(parts[2])
                    disk_percent = float(parts[4].replace('%', ''))
        except:
            pass
        
        # Load average
        try:
            load_avg = os.getloadavg()
        except (OSError, AttributeError):
            load_avg = (0.0, 0.0, 0.0)
        
        # Uptime
        uptime = 0.0
        try:
            result = await shell_executor.execute_command(
                "cat /proc/uptime | awk '{print $1}'",
                timeout=5.0
            )
            if result.success and result.stdout.strip():
                uptime = float(result.stdout.strip())
        except:
            pass
        
        return ResourceMetrics(
            cpu_percent=cpu_percent,
            cpu_count=cpu_count,
            memory_total=memory_total,
            memory_used=memory_used,
            memory_percent=memory_percent,
            disk_total=disk_total,
            disk_used=disk_used,
            disk_percent=disk_percent,
            load_average=load_avg,
            uptime_seconds=uptime
        )
    
    async def check_cpu(self) -> HealthCheck:
        """Check CPU health."""
        start = datetime.now()
        
        try:
            metrics = await self.get_resource_metrics()
            latency = (datetime.now() - start).total_seconds() * 1000
            
            if metrics.cpu_percent >= self._thresholds['cpu_critical']:
                status = HealthStatus.UNHEALTHY
                message = f"CPU usage critical: {metrics.cpu_percent:.1f}%"
            elif metrics.cpu_percent >= self._thresholds['cpu_warning']:
                status = HealthStatus.DEGRADED
                message = f"CPU usage high: {metrics.cpu_percent:.1f}%"
            else:
                status = HealthStatus.HEALTHY
                message = f"CPU usage normal: {metrics.cpu_percent:.1f}%"
            
            return HealthCheck(
                name="cpu",
                status=status,
                message=message,
                details={
                    'percent': metrics.cpu_percent,
                    'count': metrics.cpu_count,
                    'load_average': list(metrics.load_average)
                },
                latency_ms=latency
            )
        except Exception as e:
            return HealthCheck(
                name="cpu",
                status=HealthStatus.UNKNOWN,
                message=f"Failed to check CPU: {e}"
            )
    
    async def check_memory(self) -> HealthCheck:
        """Check memory health."""
        start = datetime.now()
        
        try:
            metrics = await self.get_resource_metrics()
            latency = (datetime.now() - start).total_seconds() * 1000
            
            if metrics.memory_percent >= self._thresholds['memory_critical']:
                status = HealthStatus.UNHEALTHY
                message = f"Memory usage critical: {metrics.memory_percent:.1f}%"
            elif metrics.memory_percent >= self._thresholds['memory_warning']:
                status = HealthStatus.DEGRADED
                message = f"Memory usage high: {metrics.memory_percent:.1f}%"
            else:
                status = HealthStatus.HEALTHY
                message = f"Memory usage normal: {metrics.memory_percent:.1f}%"
            
            return HealthCheck(
                name="memory",
                status=status,
                message=message,
                details={
                    'total': metrics.memory_total,
                    'used': metrics.memory_used,
                    'percent': metrics.memory_percent
                },
                latency_ms=latency
            )
        except Exception as e:
            return HealthCheck(
                name="memory",
                status=HealthStatus.UNKNOWN,
                message=f"Failed to check memory: {e}"
            )
    
    async def check_disk(self, path: str = "/") -> HealthCheck:
        """Check disk health."""
        start = datetime.now()
        
        try:
            if self._has_psutil:
                import psutil
                disk = psutil.disk_usage(path)
                disk_percent = disk.percent
                disk_total = disk.total
                disk_used = disk.used
            else:
                result = await shell_executor.execute_command(
                    f"df -B1 {path} | tail -1",
                    timeout=5.0
                )
                if result.success:
                    parts = result.stdout.strip().split()
                    disk_total = int(parts[1])
                    disk_used = int(parts[2])
                    disk_percent = float(parts[4].replace('%', ''))
                else:
                    raise Exception("Failed to get disk info")
            
            latency = (datetime.now() - start).total_seconds() * 1000
            
            if disk_percent >= self._thresholds['disk_critical']:
                status = HealthStatus.UNHEALTHY
                message = f"Disk usage critical: {disk_percent:.1f}%"
            elif disk_percent >= self._thresholds['disk_warning']:
                status = HealthStatus.DEGRADED
                message = f"Disk usage high: {disk_percent:.1f}%"
            else:
                status = HealthStatus.HEALTHY
                message = f"Disk usage normal: {disk_percent:.1f}%"
            
            return HealthCheck(
                name=f"disk:{path}",
                status=status,
                message=message,
                details={
                    'path': path,
                    'total': disk_total,
                    'used': disk_used,
                    'percent': disk_percent
                },
                latency_ms=latency
            )
        except Exception as e:
            return HealthCheck(
                name=f"disk:{path}",
                status=HealthStatus.UNKNOWN,
                message=f"Failed to check disk: {e}"
            )
    
    # =========================================================================
    # Service Health Checks
    # =========================================================================
    
    async def check_tcp(
        self,
        host: str,
        port: int,
        timeout: float = 5.0,
        name: Optional[str] = None
    ) -> ServiceHealth:
        """
        Check if a TCP port is reachable.
        
        Args:
            host: Host to check
            port: Port number
            timeout: Connection timeout
            name: Service name
            
        Returns:
            ServiceHealth result
        """
        service_name = name or f"tcp:{host}:{port}"
        start = datetime.now()
        
        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(host, port),
                timeout=timeout
            )
            
            latency = (datetime.now() - start).total_seconds() * 1000
            
            writer.close()
            await writer.wait_closed()
            
            return ServiceHealth(
                name=service_name,
                status=HealthStatus.HEALTHY,
                host=host,
                port=port,
                response_time_ms=latency
            )
            
        except asyncio.TimeoutError:
            return ServiceHealth(
                name=service_name,
                status=HealthStatus.UNHEALTHY,
                host=host,
                port=port,
                error="Connection timed out"
            )
        except ConnectionRefusedError:
            return ServiceHealth(
                name=service_name,
                status=HealthStatus.UNHEALTHY,
                host=host,
                port=port,
                error="Connection refused"
            )
        except Exception as e:
            return ServiceHealth(
                name=service_name,
                status=HealthStatus.UNHEALTHY,
                host=host,
                port=port,
                error=str(e)
            )
    
    async def check_http(
        self,
        url: str,
        method: str = "GET",
        expected_status: int = 200,
        timeout: float = 10.0,
        name: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None
    ) -> ServiceHealth:
        """
        Check HTTP endpoint health.
        
        Args:
            url: URL to check
            method: HTTP method
            expected_status: Expected status code
            timeout: Request timeout
            name: Service name
            headers: Request headers
            
        Returns:
            ServiceHealth result
        """
        service_name = name or f"http:{url}"
        start = datetime.now()
        
        try:
            import aiohttp
            
            async with aiohttp.ClientSession() as session:
                async with session.request(
                    method,
                    url,
                    timeout=aiohttp.ClientTimeout(total=timeout),
                    headers=headers
                ) as response:
                    latency = (datetime.now() - start).total_seconds() * 1000
                    
                    if response.status == expected_status:
                        return ServiceHealth(
                            name=service_name,
                            status=HealthStatus.HEALTHY,
                            host=url,
                            response_time_ms=latency
                        )
                    else:
                        return ServiceHealth(
                            name=service_name,
                            status=HealthStatus.UNHEALTHY,
                            host=url,
                            response_time_ms=latency,
                            error=f"Expected {expected_status}, got {response.status}"
                        )
                        
        except asyncio.TimeoutError:
            return ServiceHealth(
                name=service_name,
                status=HealthStatus.UNHEALTHY,
                host=url,
                error="Request timed out"
            )
        except ImportError:
            # Fallback to curl
            result = await shell_executor.execute_command(
                f'curl -s -o /dev/null -w "%{{http_code}}" -m {int(timeout)} "{url}"',
                timeout=timeout + 2
            )
            
            latency = (datetime.now() - start).total_seconds() * 1000
            
            if result.success:
                status_code = int(result.stdout.strip())
                if status_code == expected_status:
                    return ServiceHealth(
                        name=service_name,
                        status=HealthStatus.HEALTHY,
                        host=url,
                        response_time_ms=latency
                    )
                else:
                    return ServiceHealth(
                        name=service_name,
                        status=HealthStatus.UNHEALTHY,
                        host=url,
                        response_time_ms=latency,
                        error=f"Expected {expected_status}, got {status_code}"
                    )
            else:
                return ServiceHealth(
                    name=service_name,
                    status=HealthStatus.UNHEALTHY,
                    host=url,
                    error=result.stderr or "Request failed"
                )
        except Exception as e:
            return ServiceHealth(
                name=service_name,
                status=HealthStatus.UNHEALTHY,
                host=url,
                error=str(e)
            )
    
    async def check_process(
        self,
        process_name: str,
        name: Optional[str] = None
    ) -> ServiceHealth:
        """
        Check if a process is running.
        
        Args:
            process_name: Process name to find
            name: Service name
            
        Returns:
            ServiceHealth result
        """
        service_name = name or f"process:{process_name}"
        start = datetime.now()
        
        try:
            if self._has_psutil:
                import psutil
                
                found = False
                for proc in psutil.process_iter(['name', 'cmdline']):
                    try:
                        if process_name.lower() in proc.info['name'].lower():
                            found = True
                            break
                        if proc.info['cmdline']:
                            cmdline = ' '.join(proc.info['cmdline'])
                            if process_name.lower() in cmdline.lower():
                                found = True
                                break
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        continue
            else:
                result = await shell_executor.execute_command(
                    f"pgrep -f '{process_name}'",
                    timeout=5.0
                )
                found = result.success and bool(result.stdout.strip())
            
            latency = (datetime.now() - start).total_seconds() * 1000
            
            if found:
                return ServiceHealth(
                    name=service_name,
                    status=HealthStatus.HEALTHY,
                    response_time_ms=latency
                )
            else:
                return ServiceHealth(
                    name=service_name,
                    status=HealthStatus.UNHEALTHY,
                    error=f"Process '{process_name}' not found"
                )
                
        except Exception as e:
            return ServiceHealth(
                name=service_name,
                status=HealthStatus.UNHEALTHY,
                error=str(e)
            )
    
    async def check_dns(
        self,
        hostname: str,
        name: Optional[str] = None
    ) -> ServiceHealth:
        """
        Check DNS resolution.
        
        Args:
            hostname: Hostname to resolve
            name: Service name
            
        Returns:
            ServiceHealth result
        """
        service_name = name or f"dns:{hostname}"
        start = datetime.now()
        
        try:
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, socket.gethostbyname, hostname)
            
            latency = (datetime.now() - start).total_seconds() * 1000
            
            return ServiceHealth(
                name=service_name,
                status=HealthStatus.HEALTHY,
                host=hostname,
                response_time_ms=latency
            )
            
        except socket.gaierror as e:
            return ServiceHealth(
                name=service_name,
                status=HealthStatus.UNHEALTHY,
                host=hostname,
                error=f"DNS resolution failed: {e}"
            )
        except Exception as e:
            return ServiceHealth(
                name=service_name,
                status=HealthStatus.UNHEALTHY,
                host=hostname,
                error=str(e)
            )
    
    # =========================================================================
    # Service Registration
    # =========================================================================
    
    def register_service(
        self,
        name: str,
        check_type: str,
        **kwargs
    ) -> None:
        """
        Register a service for monitoring.
        
        Args:
            name: Service name
            check_type: Type of check (tcp, http, process, dns)
            **kwargs: Check-specific parameters
        """
        self._monitored_services[name] = {
            'type': check_type,
            'params': kwargs,
            'last_status': None,
            'consecutive_failures': 0
        }
        logger.info(f"Registered service for monitoring: {name}")
    
    def unregister_service(self, name: str) -> bool:
        """Unregister a monitored service."""
        if name in self._monitored_services:
            del self._monitored_services[name]
            return True
        return False
    
    async def check_registered_services(self) -> List[ServiceHealth]:
        """Check all registered services."""
        results = []
        
        for name, config in self._monitored_services.items():
            check_type = config['type']
            params = config['params']
            
            if check_type == 'tcp':
                result = await self.check_tcp(name=name, **params)
            elif check_type == 'http':
                result = await self.check_http(name=name, **params)
            elif check_type == 'process':
                result = await self.check_process(name=name, **params)
            elif check_type == 'dns':
                result = await self.check_dns(name=name, **params)
            else:
                result = ServiceHealth(
                    name=name,
                    status=HealthStatus.UNKNOWN,
                    error=f"Unknown check type: {check_type}"
                )
            
            # Update consecutive failures
            if result.status == HealthStatus.UNHEALTHY:
                config['consecutive_failures'] += 1
                result.consecutive_failures = config['consecutive_failures']
            else:
                config['consecutive_failures'] = 0
            
            config['last_status'] = result.status
            results.append(result)
        
        return results
    
    # =========================================================================
    # Custom Health Checks
    # =========================================================================
    
    def register_check(
        self,
        name: str,
        check_func: Callable[[], HealthCheck]
    ) -> None:
        """
        Register a custom health check.
        
        Args:
            name: Check name
            check_func: Async function returning HealthCheck
        """
        self._custom_checks[name] = check_func
    
    def unregister_check(self, name: str) -> bool:
        """Unregister a custom health check."""
        if name in self._custom_checks:
            del self._custom_checks[name]
            return True
        return False
    
    async def run_custom_checks(self) -> List[HealthCheck]:
        """Run all custom health checks."""
        results = []
        
        for name, check_func in self._custom_checks.items():
            try:
                if asyncio.iscoroutinefunction(check_func):
                    result = await check_func()
                else:
                    result = check_func()
                results.append(result)
            except Exception as e:
                results.append(HealthCheck(
                    name=name,
                    status=HealthStatus.UNKNOWN,
                    message=f"Check failed: {e}"
                ))
        
        return results
    
    # =========================================================================
    # Health Reports
    # =========================================================================
    
    async def get_health_report(
        self,
        include_resources: bool = True,
        include_services: bool = True,
        include_custom: bool = True
    ) -> HealthReport:
        """
        Generate comprehensive health report.
        
        Args:
            include_resources: Include resource metrics
            include_services: Include service checks
            include_custom: Include custom checks
            
        Returns:
            HealthReport with all results
        """
        start = datetime.now()
        checks = []
        services = []
        resources = None
        
        # Resource checks
        if include_resources:
            resources = await self.get_resource_metrics()
            
            cpu_check = await self.check_cpu()
            memory_check = await self.check_memory()
            disk_check = await self.check_disk()
            
            checks.extend([cpu_check, memory_check, disk_check])
        
        # Service checks
        if include_services and self._monitored_services:
            services = await self.check_registered_services()
            
            # Convert to health checks for overall status
            for svc in services:
                checks.append(HealthCheck(
                    name=svc.name,
                    status=svc.status,
                    message=svc.error,
                    latency_ms=svc.response_time_ms
                ))
        
        # Custom checks
        if include_custom and self._custom_checks:
            custom_results = await self.run_custom_checks()
            checks.extend(custom_results)
        
        # Calculate overall status
        if any(c.status == HealthStatus.UNHEALTHY for c in checks):
            overall = HealthStatus.UNHEALTHY
        elif any(c.status == HealthStatus.DEGRADED for c in checks):
            overall = HealthStatus.DEGRADED
        elif any(c.status == HealthStatus.UNKNOWN for c in checks):
            overall = HealthStatus.DEGRADED
        else:
            overall = HealthStatus.HEALTHY
        
        duration = (datetime.now() - start).total_seconds() * 1000
        
        report = HealthReport(
            overall_status=overall,
            checks=checks,
            resources=resources,
            services=services,
            duration_ms=duration
        )
        
        # Store in history
        self._health_history.append(report)
        if len(self._health_history) > self._max_history:
            self._health_history = self._health_history[-self._max_history:]
        
        return report
    
    def get_health_history(
        self,
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        """Get health check history."""
        return [
            report.to_dict()
            for report in self._health_history[-limit:]
        ]
    
    # =========================================================================
    # System Info
    # =========================================================================
    
    async def get_system_info(self) -> Dict[str, Any]:
        """Get detailed system information."""
        info = {
            'platform': platform.platform(),
            'system': platform.system(),
            'release': platform.release(),
            'version': platform.version(),
            'machine': platform.machine(),
            'processor': platform.processor(),
            'hostname': socket.gethostname(),
            'python_version': platform.python_version()
        }
        
        # Network interfaces
        try:
            info['ip_address'] = socket.gethostbyname(socket.gethostname())
        except:
            info['ip_address'] = 'unknown'
        
        # Additional info with psutil
        if self._has_psutil:
            import psutil
            
            info['cpu_count_physical'] = psutil.cpu_count(logical=False)
            info['cpu_count_logical'] = psutil.cpu_count(logical=True)
            info['boot_time'] = datetime.fromtimestamp(psutil.boot_time()).isoformat()
        
        return info
    
    # =========================================================================
    # Threshold Configuration
    # =========================================================================
    
    def set_thresholds(
        self,
        cpu_warning: Optional[float] = None,
        cpu_critical: Optional[float] = None,
        memory_warning: Optional[float] = None,
        memory_critical: Optional[float] = None,
        disk_warning: Optional[float] = None,
        disk_critical: Optional[float] = None
    ) -> Dict[str, float]:
        """
        Set health check thresholds.
        
        Args:
            cpu_warning: CPU warning threshold (%)
            cpu_critical: CPU critical threshold (%)
            memory_warning: Memory warning threshold (%)
            memory_critical: Memory critical threshold (%)
            disk_warning: Disk warning threshold (%)
            disk_critical: Disk critical threshold (%)
            
        Returns:
            Updated thresholds
        """
        if cpu_warning is not None:
            self._thresholds['cpu_warning'] = cpu_warning
        if cpu_critical is not None:
            self._thresholds['cpu_critical'] = cpu_critical
        if memory_warning is not None:
            self._thresholds['memory_warning'] = memory_warning
        if memory_critical is not None:
            self._thresholds['memory_critical'] = memory_critical
        if disk_warning is not None:
            self._thresholds['disk_warning'] = disk_warning
        if disk_critical is not None:
            self._thresholds['disk_critical'] = disk_critical
        
        return self._thresholds.copy()
    
    def get_thresholds(self) -> Dict[str, float]:
        """Get current thresholds."""
        return self._thresholds.copy()
    
    # =========================================================================
    # Main Run Method
    # =========================================================================
    
    async def run(self, context: ToolContext, **kwargs) -> ToolResult:
        """
        Execute health monitoring operation.
        
        Supported operations:
        - report: Get comprehensive health report
        - resources: Get resource metrics
        - check_cpu: Check CPU health
        - check_memory: Check memory health
        - check_disk: Check disk health
        - check_tcp: Check TCP port
        - check_http: Check HTTP endpoint
        - check_process: Check if process is running
        - check_dns: Check DNS resolution
        - register_service: Register service for monitoring
        - unregister_service: Unregister service
        - services: List registered services
        - history: Get health history
        - system_info: Get system info
        - thresholds: Get/set thresholds
        """
        operation = kwargs.get('operation', 'report')
        
        try:
            if operation == 'report':
                report = await self.get_health_report(
                    include_resources=kwargs.get('include_resources', True),
                    include_services=kwargs.get('include_services', True),
                    include_custom=kwargs.get('include_custom', True)
                )
                
                return ToolResult.ok(
                    data=report.to_dict(),
                    message=f"Health: {report.overall_status.value}"
                )
            
            elif operation == 'resources':
                metrics = await self.get_resource_metrics()
                return ToolResult.ok(data=metrics.to_dict())
            
            elif operation == 'check_cpu':
                result = await self.check_cpu()
                return ToolResult.ok(data=result.to_dict())
            
            elif operation == 'check_memory':
                result = await self.check_memory()
                return ToolResult.ok(data=result.to_dict())
            
            elif operation == 'check_disk':
                path = kwargs.get('path', '/')
                result = await self.check_disk(path)
                return ToolResult.ok(data=result.to_dict())
            
            elif operation == 'check_tcp':
                host = kwargs.get('host')
                port = kwargs.get('port')
                
                if not host or not port:
                    return ToolResult.fail(error="host and port are required")
                
                result = await self.check_tcp(
                    host, int(port),
                    timeout=kwargs.get('timeout', 5.0),
                    name=kwargs.get('name')
                )
                return ToolResult.ok(data=result.to_dict())
            
            elif operation == 'check_http':
                url = kwargs.get('url')
                if not url:
                    return ToolResult.fail(error="url is required")
                
                result = await self.check_http(
                    url,
                    method=kwargs.get('method', 'GET'),
                    expected_status=kwargs.get('expected_status', 200),
                    timeout=kwargs.get('timeout', 10.0),
                    name=kwargs.get('name'),
                    headers=kwargs.get('headers')
                )
                return ToolResult.ok(data=result.to_dict())
            
            elif operation == 'check_process':
                process_name = kwargs.get('process_name') or kwargs.get('process')
                if not process_name:
                    return ToolResult.fail(error="process_name is required")
                
                result = await self.check_process(
                    process_name,
                    name=kwargs.get('name')
                )
                return ToolResult.ok(data=result.to_dict())
            
            elif operation == 'check_dns':
                hostname = kwargs.get('hostname') or kwargs.get('host')
                if not hostname:
                    return ToolResult.fail(error="hostname is required")
                
                result = await self.check_dns(
                    hostname,
                    name=kwargs.get('name')
                )
                return ToolResult.ok(data=result.to_dict())
            
            elif operation == 'register_service':
                name = kwargs.get('name')
                check_type = kwargs.get('check_type') or kwargs.get('type')
                
                if not name or not check_type:
                    return ToolResult.fail(error="name and check_type are required")
                
                # Remove name and check_type from kwargs for params
                params = {k: v for k, v in kwargs.items() 
                         if k not in ['operation', 'name', 'check_type', 'type']}
                
                self.register_service(name, check_type, **params)
                
                return ToolResult.ok(
                    message=f"Service '{name}' registered for monitoring"
                )
            
            elif operation == 'unregister_service':
                name = kwargs.get('name')
                if not name:
                    return ToolResult.fail(error="name is required")
                
                if self.unregister_service(name):
                    return ToolResult.ok(message=f"Service '{name}' unregistered")
                else:
                    return ToolResult.fail(error=f"Service '{name}' not found")
            
            elif operation == 'services':
                services = {
                    name: {
                        'type': config['type'],
                        'params': config['params'],
                        'last_status': config['last_status'].value if config['last_status'] else None,
                        'consecutive_failures': config['consecutive_failures']
                    }
                    for name, config in self._monitored_services.items()
                }
                
                return ToolResult.ok(
                    data={
                        'services': services,
                        'count': len(services)
                    }
                )
            
            elif operation == 'history':
                limit = kwargs.get('limit', 50)
                history = self.get_health_history(limit)
                
                return ToolResult.ok(
                    data={
                        'history': history,
                        'count': len(history)
                    }
                )
            
            elif operation == 'system_info':
                info = await self.get_system_info()
                return ToolResult.ok(data=info)
            
            elif operation == 'thresholds':
                if any(k in kwargs for k in ['cpu_warning', 'cpu_critical', 
                                              'memory_warning', 'memory_critical',
                                              'disk_warning', 'disk_critical']):
                    thresholds = self.set_thresholds(
                        cpu_warning=kwargs.get('cpu_warning'),
                        cpu_critical=kwargs.get('cpu_critical'),
                        memory_warning=kwargs.get('memory_warning'),
                        memory_critical=kwargs.get('memory_critical'),
                        disk_warning=kwargs.get('disk_warning'),
                        disk_critical=kwargs.get('disk_critical')
                    )
                    return ToolResult.ok(
                        data=thresholds,
                        message="Thresholds updated"
                    )
                else:
                    return ToolResult.ok(data=self.get_thresholds())
            
            else:
                return ToolResult.fail(error=f"Unknown operation: {operation}")
            
        except Exception as e:
            logger.error(f"HealthTools error: {e}")
            return ToolResult.error(error=str(e))


# Create singleton
health_tools = HealthTools()


def register():
    """Register health tools."""
    registry = get_registry()
    registry.register_tool(health_tools)