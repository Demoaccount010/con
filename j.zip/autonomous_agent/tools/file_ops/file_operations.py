"""
File Operations Tool - General file management operations.
Supports copy, move, delete, info, search, permissions, and more.
"""

import asyncio
import aiofiles
import aiofiles.os
import os
import shutil
import fnmatch
import stat
import hashlib
from pathlib import Path
from typing import Optional, List, Dict, Any, Set, AsyncIterator
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import logging
import re

# Import from our tool system
import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from tools.base_tool import (
    BaseTool, ToolResult, ToolStatus, ToolCategory,
    RiskLevel, tool_registry
)
from security.path_validator import PathValidator
from output.output_manager import OutputManager

logger = logging.getLogger(__name__)


class ConflictResolution(Enum):
    """How to handle file conflicts."""
    FAIL = "fail"           # Fail if target exists
    OVERWRITE = "overwrite" # Overwrite target
    SKIP = "skip"           # Skip if target exists
    RENAME = "rename"       # Rename with suffix
    BACKUP = "backup"       # Backup target first


@dataclass
class FileInfo:
    """Comprehensive file information."""
    path: str
    name: str
    extension: str
    size: int
    size_human: str
    type: str  # file, directory, symlink
    mime_type: Optional[str]
    permissions: str
    permissions_octal: str
    owner: Optional[str]
    group: Optional[str]
    created: datetime
    modified: datetime
    accessed: datetime
    is_hidden: bool
    is_readable: bool
    is_writable: bool
    is_executable: bool
    is_symlink: bool
    symlink_target: Optional[str]
    checksum_md5: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'path': self.path,
            'name': self.name,
            'extension': self.extension,
            'size': self.size,
            'size_human': self.size_human,
            'type': self.type,
            'mime_type': self.mime_type,
            'permissions': self.permissions,
            'permissions_octal': self.permissions_octal,
            'owner': self.owner,
            'group': self.group,
            'created': self.created.isoformat(),
            'modified': self.modified.isoformat(),
            'accessed': self.accessed.isoformat(),
            'is_hidden': self.is_hidden,
            'is_readable': self.is_readable,
            'is_writable': self.is_writable,
            'is_executable': self.is_executable,
            'is_symlink': self.is_symlink,
            'symlink_target': self.symlink_target,
            'checksum_md5': self.checksum_md5
        }


@dataclass
class OperationResult:
    """Result of a file operation."""
    success: bool
    operation: str
    source: Optional[str] = None
    destination: Optional[str] = None
    items_processed: int = 0
    items_failed: int = 0
    bytes_processed: int = 0
    error: Optional[str] = None
    details: Optional[Dict[str, Any]] = None
    execution_time_ms: float = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'success': self.success,
            'operation': self.operation,
            'source': self.source,
            'destination': self.destination,
            'items_processed': self.items_processed,
            'items_failed': self.items_failed,
            'bytes_processed': self.bytes_processed,
            'error': self.error,
            'details': self.details,
            'execution_time_ms': self.execution_time_ms
        }


@dataclass
class SearchResult:
    """Result of a file search."""
    success: bool
    query: str
    total_found: int
    files: List[Dict[str, Any]] = field(default_factory=list)
    search_time_ms: float = 0
    error: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'success': self.success,
            'query': self.query,
            'total_found': self.total_found,
            'files': self.files,
            'search_time_ms': self.search_time_ms,
            'error': self.error
        }


class FileOperationsTool(BaseTool):
    """
    General file operations tool.
    
    Capabilities:
    - Copy files and directories
    - Move/rename files and directories
    - Delete files and directories
    - Get detailed file info
    - Search for files
    - Change permissions
    - Create symlinks
    - Compare files
    - Calculate checksums
    - Get file tree
    """
    
    def __init__(self, path_validator: Optional[PathValidator] = None):
        super().__init__(
            name="file_operations",
            description="General file operations (copy, move, delete, search, permissions)",
            category=ToolCategory.FILE,
            risk_level=RiskLevel.HIGH,  # Includes destructive operations
            requires_confirmation=True,
            timeout=300.0,
            version="1.0.0"
        )
        self.path_validator = path_validator or PathValidator()
        self.output = OutputManager()
        
        # Maximum items for recursive operations
        self.max_recursive_items = 10000
    
    def _human_readable_size(self, size: int) -> str:
        """Convert bytes to human readable format."""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size < 1024:
                return f"{size:.2f} {unit}"
            size /= 1024
        return f"{size:.2f} PB"
    
    def _get_permission_string(self, mode: int) -> str:
        """Convert mode to rwx permission string."""
        perms = []
        for who in [(mode >> 6) & 7, (mode >> 3) & 7, mode & 7]:
            perms.append(
                ('r' if who & 4 else '-') +
                ('w' if who & 2 else '-') +
                ('x' if who & 1 else '-')
            )
        return ''.join(perms)
    
    async def get_info(
        self,
        path: str,
        calculate_checksum: bool = False
    ) -> Optional[FileInfo]:
        """Get detailed information about a file or directory."""
        import mimetypes
        
        p = Path(path).resolve()
        
        if not p.exists():
            return None
        
        try:
            stat_info = p.stat()
            lstat_info = p.lstat()
            
            # Determine type
            if p.is_symlink():
                file_type = "symlink"
            elif p.is_dir():
                file_type = "directory"
            elif p.is_file():
                file_type = "file"
            else:
                file_type = "other"
            
            # Get MIME type
            mime_type = None
            if file_type == "file":
                mime_type, _ = mimetypes.guess_type(str(p))
            
            # Get owner/group (Unix)
            owner, group = None, None
            try:
                import pwd
                import grp
                owner = pwd.getpwuid(stat_info.st_uid).pw_name
                group = grp.getgrgid(stat_info.st_gid).gr_name
            except (ImportError, KeyError):
                pass
            
            # Get symlink target
            symlink_target = None
            if p.is_symlink():
                symlink_target = str(os.readlink(p))
            
            # Calculate checksum if requested
            checksum = None
            if calculate_checksum and file_type == "file":
                md5 = hashlib.md5()
                async with aiofiles.open(p, 'rb') as f:
                    while chunk := await f.read(8192):
                        md5.update(chunk)
                checksum = md5.hexdigest()
            
            return FileInfo(
                path=str(p),
                name=p.name,
                extension=p.suffix.lower() if p.suffix else "",
                size=stat_info.st_size if file_type != "directory" else 0,
                size_human=self._human_readable_size(stat_info.st_size),
                type=file_type,
                mime_type=mime_type,
                permissions=self._get_permission_string(stat_info.st_mode),
                permissions_octal=oct(stat_info.st_mode)[-3:],
                owner=owner,
                group=group,
                created=datetime.fromtimestamp(stat_info.st_ctime),
                modified=datetime.fromtimestamp(stat_info.st_mtime),
                accessed=datetime.fromtimestamp(stat_info.st_atime),
                is_hidden=p.name.startswith('.'),
                is_readable=os.access(p, os.R_OK),
                is_writable=os.access(p, os.W_OK),
                is_executable=os.access(p, os.X_OK),
                is_symlink=p.is_symlink(),
                symlink_target=symlink_target,
                checksum_md5=checksum
            )
            
        except Exception as e:
            logger.error(f"Error getting file info for {path}: {e}")
            return None
    
    async def copy(
        self,
        source: str,
        destination: str,
        recursive: bool = True,
        preserve_metadata: bool = True,
        conflict: ConflictResolution = ConflictResolution.FAIL,
        follow_symlinks: bool = True
    ) -> OperationResult:
        """
        Copy file or directory.
        
        Args:
            source: Source path
            destination: Destination path
            recursive: Copy directories recursively
            preserve_metadata: Preserve file metadata
            conflict: How to handle conflicts
            follow_symlinks: Follow symbolic links
            
        Returns:
            OperationResult with details
        """
        start_time = datetime.now()
        src = Path(source).resolve()
        dst = Path(destination).resolve()
        
        try:
            # Validate paths
            if not await self.path_validator.validate(src, 'read'):
                return OperationResult(
                    success=False,
                    operation='copy',
                    source=str(src),
                    error=f"Source path validation failed: {src}"
                )
            
            if not await self.path_validator.validate(dst, 'write'):
                return OperationResult(
                    success=False,
                    operation='copy',
                    destination=str(dst),
                    error=f"Destination path validation failed: {dst}"
                )
            
            if not src.exists():
                return OperationResult(
                    success=False,
                    operation='copy',
                    source=str(src),
                    error=f"Source not found: {src}"
                )
            
            # Handle conflict
            if dst.exists():
                if conflict == ConflictResolution.FAIL:
                    return OperationResult(
                        success=False,
                        operation='copy',
                        error=f"Destination exists: {dst}"
                    )
                elif conflict == ConflictResolution.SKIP:
                    return OperationResult(
                        success=True,
                        operation='copy',
                        source=str(src),
                        destination=str(dst),
                        details={'skipped': True, 'reason': 'destination exists'}
                    )
                elif conflict == ConflictResolution.RENAME:
                    i = 1
                    while dst.exists():
                        new_name = f"{dst.stem}_{i}{dst.suffix}"
                        dst = dst.parent / new_name
                        i += 1
                elif conflict == ConflictResolution.BACKUP:
                    backup = dst.with_suffix(dst.suffix + '.bak')
                    shutil.move(str(dst), str(backup))
            
            # Ensure parent directory exists
            dst.parent.mkdir(parents=True, exist_ok=True)
            
            # Perform copy
            items_processed = 0
            bytes_processed = 0
            
            if src.is_file():
                if preserve_metadata:
                    shutil.copy2(str(src), str(dst))
                else:
                    shutil.copy(str(src), str(dst))
                items_processed = 1
                bytes_processed = src.stat().st_size
            elif src.is_dir():
                if not recursive:
                    return OperationResult(
                        success=False,
                        operation='copy',
                        error="Source is directory but recursive=False"
                    )
                
                # Use copytree for directories
                if preserve_metadata:
                    shutil.copytree(
                        str(src), str(dst),
                        symlinks=not follow_symlinks,
                        copy_function=shutil.copy2
                    )
                else:
                    shutil.copytree(
                        str(src), str(dst),
                        symlinks=not follow_symlinks
                    )
                
                # Count items
                for item in dst.rglob('*'):
                    items_processed += 1
                    if item.is_file():
                        bytes_processed += item.stat().st_size
            
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            
            return OperationResult(
                success=True,
                operation='copy',
                source=str(src),
                destination=str(dst),
                items_processed=items_processed,
                bytes_processed=bytes_processed,
                execution_time_ms=elapsed
            )
            
        except Exception as e:
            logger.error(f"Error copying {source} to {destination}: {e}")
            return OperationResult(
                success=False,
                operation='copy',
                source=str(src),
                destination=str(dst),
                error=str(e)
            )
    
    async def move(
        self,
        source: str,
        destination: str,
        conflict: ConflictResolution = ConflictResolution.FAIL
    ) -> OperationResult:
        """
        Move or rename file/directory.
        
        Args:
            source: Source path
            destination: Destination path
            conflict: How to handle conflicts
            
        Returns:
            OperationResult with details
        """
        start_time = datetime.now()
        src = Path(source).resolve()
        dst = Path(destination).resolve()
        
        try:
            if not await self.path_validator.validate(src, 'write'):
                return OperationResult(
                    success=False,
                    operation='move',
                    error=f"Source path validation failed: {src}"
                )
            
            if not await self.path_validator.validate(dst, 'write'):
                return OperationResult(
                    success=False,
                    operation='move',
                    error=f"Destination path validation failed: {dst}"
                )
            
            if not src.exists():
                return OperationResult(
                    success=False,
                    operation='move',
                    error=f"Source not found: {src}"
                )
            
            # Handle conflict
            if dst.exists():
                if conflict == ConflictResolution.FAIL:
                    return OperationResult(
                        success=False,
                        operation='move',
                        error=f"Destination exists: {dst}"
                    )
                elif conflict == ConflictResolution.SKIP:
                    return OperationResult(
                        success=True,
                        operation='move',
                        source=str(src),
                        details={'skipped': True}
                    )
                elif conflict == ConflictResolution.OVERWRITE:
                    if dst.is_dir():
                        shutil.rmtree(str(dst))
                    else:
                        dst.unlink()
                elif conflict == ConflictResolution.RENAME:
                    i = 1
                    while dst.exists():
                        new_name = f"{dst.stem}_{i}{dst.suffix}"
                        dst = dst.parent / new_name
                        i += 1
            
            # Ensure parent directory exists
            dst.parent.mkdir(parents=True, exist_ok=True)
            
            # Get size before move
            bytes_processed = 0
            if src.is_file():
                bytes_processed = src.stat().st_size
            elif src.is_dir():
                for item in src.rglob('*'):
                    if item.is_file():
                        bytes_processed += item.stat().st_size
            
            # Perform move
            shutil.move(str(src), str(dst))
            
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            
            return OperationResult(
                success=True,
                operation='move',
                source=str(src),
                destination=str(dst),
                items_processed=1,
                bytes_processed=bytes_processed,
                execution_time_ms=elapsed
            )
            
        except Exception as e:
            logger.error(f"Error moving {source} to {destination}: {e}")
            return OperationResult(
                success=False,
                operation='move',
                source=str(src),
                error=str(e)
            )
    
    async def delete(
        self,
        path: str,
        recursive: bool = False,
        force: bool = False,
        secure: bool = False
    ) -> OperationResult:
        """
        Delete file or directory.
        
        Args:
            path: Path to delete
            recursive: Delete directories recursively
            force: Force deletion (ignore errors)
            secure: Overwrite file before deletion
            
        Returns:
            OperationResult with details
        """
        start_time = datetime.now()
        p = Path(path).resolve()
        
        try:
            if not await self.path_validator.validate(p, 'delete'):
                return OperationResult(
                    success=False,
                    operation='delete',
                    error=f"Path validation failed: {p}"
                )
            
            if not p.exists():
                return OperationResult(
                    success=True,
                    operation='delete',
                    source=str(p),
                    details={'already_deleted': True}
                )
            
            items_processed = 0
            bytes_processed = 0
            
            if p.is_file() or p.is_symlink():
                bytes_processed = p.stat().st_size if p.is_file() else 0
                
                # Secure delete: overwrite with random data
                if secure and p.is_file():
                    size = p.stat().st_size
                    async with aiofiles.open(p, 'wb') as f:
                        await f.write(os.urandom(size))
                        await f.flush()
                        os.fsync(f.fileno())
                
                p.unlink()
                items_processed = 1
                
            elif p.is_dir():
                if not recursive:
                    # Check if directory is empty
                    if any(p.iterdir()):
                        return OperationResult(
                            success=False,
                            operation='delete',
                            error="Directory not empty and recursive=False"
                        )
                    p.rmdir()
                    items_processed = 1
                else:
                    # Count items and size first
                    for item in p.rglob('*'):
                        if item.is_file():
                            bytes_processed += item.stat().st_size
                        items_processed += 1
                    
                    # Remove directory tree
                    if force:
                        def onerror(func, path, exc_info):
                            """Error handler for shutil.rmtree."""
                            try:
                                os.chmod(path, stat.S_IWRITE)
                                func(path)
                            except:
                                pass
                        shutil.rmtree(str(p), onerror=onerror)
                    else:
                        shutil.rmtree(str(p))
            
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            
            return OperationResult(
                success=True,
                operation='delete',
                source=str(p),
                items_processed=items_processed,
                bytes_processed=bytes_processed,
                execution_time_ms=elapsed
            )
            
        except Exception as e:
            logger.error(f"Error deleting {path}: {e}")
            return OperationResult(
                success=False,
                operation='delete',
                source=str(p),
                error=str(e)
            )
    
    async def search(
        self,
        directory: str,
        pattern: str = "*",
        recursive: bool = True,
        file_type: Optional[str] = None,  # 'file', 'directory', 'symlink'
        min_size: Optional[int] = None,
        max_size: Optional[int] = None,
        modified_after: Optional[datetime] = None,
        modified_before: Optional[datetime] = None,
        content_pattern: Optional[str] = None,
        max_results: int = 1000,
        include_hidden: bool = False
    ) -> SearchResult:
        """
        Search for files matching criteria.
        
        Args:
            directory: Directory to search in
            pattern: Glob pattern (e.g., "*.py")
            recursive: Search recursively
            file_type: Filter by type
            min_size: Minimum file size
            max_size: Maximum file size
            modified_after: Modified after date
            modified_before: Modified before date
            content_pattern: Search file contents (regex)
            max_results: Maximum results
            include_hidden: Include hidden files
            
        Returns:
            SearchResult with matching files
        """
        start_time = datetime.now()
        
        try:
            dir_path = Path(directory).resolve()
            
            if not dir_path.exists():
                return SearchResult(
                    success=False,
                    query=pattern,
                    total_found=0,
                    error=f"Directory not found: {dir_path}"
                )
            
            if not dir_path.is_dir():
                return SearchResult(
                    success=False,
                    query=pattern,
                    total_found=0,
                    error=f"Not a directory: {dir_path}"
                )
            
            results = []
            content_regex = None
            if content_pattern:
                content_regex = re.compile(content_pattern)
            
            # Use glob or rglob based on recursive flag
            glob_func = dir_path.rglob if recursive else dir_path.glob
            
            for item in glob_func(pattern):
                if len(results) >= max_results:
                    break
                
                # Skip hidden files if not included
                if not include_hidden and item.name.startswith('.'):
                    continue
                
                # Filter by type
                if file_type:
                    if file_type == 'file' and not item.is_file():
                        continue
                    if file_type == 'directory' and not item.is_dir():
                        continue
                    if file_type == 'symlink' and not item.is_symlink():
                        continue
                
                try:
                    stat_info = item.stat()
                except:
                    continue
                
                # Filter by size
                if min_size is not None and stat_info.st_size < min_size:
                    continue
                if max_size is not None and stat_info.st_size > max_size:
                    continue
                
                # Filter by modification time
                mtime = datetime.fromtimestamp(stat_info.st_mtime)
                if modified_after and mtime < modified_after:
                    continue
                if modified_before and mtime > modified_before:
                    continue
                
                # Filter by content
                if content_regex and item.is_file():
                    try:
                        async with aiofiles.open(item, 'r', errors='ignore') as f:
                            content = await f.read(1024 * 1024)  # Read first 1MB
                        if not content_regex.search(content):
                            continue
                    except:
                        continue
                
                results.append({
                    'path': str(item),
                    'name': item.name,
                    'type': 'directory' if item.is_dir() else ('symlink' if item.is_symlink() else 'file'),
                    'size': stat_info.st_size,
                    'size_human': self._human_readable_size(stat_info.st_size),
                    'modified': mtime.isoformat()
                })
            
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            
            return SearchResult(
                success=True,
                query=pattern,
                total_found=len(results),
                files=results,
                search_time_ms=elapsed
            )
            
        except Exception as e:
            logger.error(f"Error searching in {directory}: {e}")
            return SearchResult(
                success=False,
                query=pattern,
                total_found=0,
                error=str(e)
            )
    
    async def chmod(
        self,
        path: str,
        mode: str,  # e.g., "755", "644"
        recursive: bool = False
    ) -> OperationResult:
        """
        Change file permissions.
        
        Args:
            path: Path to file/directory
            mode: Permission mode (octal string)
            recursive: Apply recursively
            
        Returns:
            OperationResult with details
        """
        start_time = datetime.now()
        p = Path(path).resolve()
        
        try:
            if not await self.path_validator.validate(p, 'write'):
                return OperationResult(
                    success=False,
                    operation='chmod',
                    error=f"Path validation failed: {p}"
                )
            
            if not p.exists():
                return OperationResult(
                    success=False,
                    operation='chmod',
                    error=f"Path not found: {p}"
                )
            
            # Convert mode string to int
            mode_int = int(mode, 8)
            
            items_processed = 0
            items_failed = 0
            
            if recursive and p.is_dir():
                for item in p.rglob('*'):
                    try:
                        os.chmod(item, mode_int)
                        items_processed += 1
                    except Exception as e:
                        items_failed += 1
                        logger.warning(f"Failed to chmod {item}: {e}")
                
                # Also chmod the directory itself
                os.chmod(p, mode_int)
                items_processed += 1
            else:
                os.chmod(p, mode_int)
                items_processed = 1
            
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            
            return OperationResult(
                success=items_failed == 0,
                operation='chmod',
                source=str(p),
                items_processed=items_processed,
                items_failed=items_failed,
                details={'mode': mode},
                execution_time_ms=elapsed
            )
            
        except Exception as e:
            logger.error(f"Error chmod {path}: {e}")
            return OperationResult(
                success=False,
                operation='chmod',
                error=str(e)
            )
    
    async def compare(
        self,
        file1: str,
        file2: str
    ) -> OperationResult:
        """
        Compare two files.
        
        Args:
            file1: First file path
            file2: Second file path
            
        Returns:
            OperationResult with comparison details
        """
        start_time = datetime.now()
        p1 = Path(file1).resolve()
        p2 = Path(file2).resolve()
        
        try:
            if not p1.exists():
                return OperationResult(
                    success=False,
                    operation='compare',
                    error=f"File not found: {p1}"
                )
            
            if not p2.exists():
                return OperationResult(
                    success=False,
                    operation='compare',
                    error=f"File not found: {p2}"
                )
            
            # Get file info
            stat1 = p1.stat()
            stat2 = p2.stat()
            
            # Quick check: size
            same_size = stat1.st_size == stat2.st_size
            
            # Calculate checksums
            async def get_checksum(path: Path) -> str:
                md5 = hashlib.md5()
                async with aiofiles.open(path, 'rb') as f:
                    while chunk := await f.read(8192):
                        md5.update(chunk)
                return md5.hexdigest()
            
            checksum1 = await get_checksum(p1)
            checksum2 = await get_checksum(p2)
            
            identical = checksum1 == checksum2
            
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            
            return OperationResult(
                success=True,
                operation='compare',
                source=str(p1),
                destination=str(p2),
                details={
                    'identical': identical,
                    'same_size': same_size,
                    'file1_size': stat1.st_size,
                    'file2_size': stat2.st_size,
                    'file1_checksum': checksum1,
                    'file2_checksum': checksum2
                },
                execution_time_ms=elapsed
            )
            
        except Exception as e:
            logger.error(f"Error comparing files: {e}")
            return OperationResult(
                success=False,
                operation='compare',
                error=str(e)
            )
    
    async def tree(
        self,
        directory: str,
        max_depth: int = 3,
        include_hidden: bool = False,
        dirs_only: bool = False
    ) -> OperationResult:
        """
        Get directory tree structure.
        
        Args:
            directory: Directory path
            max_depth: Maximum depth
            include_hidden: Include hidden files
            dirs_only: Show directories only
            
        Returns:
            OperationResult with tree structure
        """
        start_time = datetime.now()
        
        try:
            dir_path = Path(directory).resolve()
            
            if not dir_path.exists():
                return OperationResult(
                    success=False,
                    operation='tree',
                    error=f"Directory not found: {dir_path}"
                )
            
            def build_tree(path: Path, depth: int) -> Dict[str, Any]:
                """Recursively build tree structure."""
                if depth > max_depth:
                    return None
                
                try:
                    items = list(path.iterdir())
                except PermissionError:
                    return {'name': path.name, 'type': 'directory', 'error': 'permission denied'}
                
                # Sort: directories first, then files
                items.sort(key=lambda x: (not x.is_dir(), x.name.lower()))
                
                children = []
                for item in items:
                    if not include_hidden and item.name.startswith('.'):
                        continue
                    
                    if dirs_only and item.is_file():
                        continue
                    
                    if item.is_dir():
                        child = build_tree(item, depth + 1)
                        if child:
                            children.append(child)
                    else:
                        children.append({
                            'name': item.name,
                            'type': 'file',
                            'size': item.stat().st_size
                        })
                
                return {
                    'name': path.name,
                    'type': 'directory',
                    'children': children
                }
            
            tree_data = build_tree(dir_path, 0)
            
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            
            return OperationResult(
                success=True,
                operation='tree',
                source=str(dir_path),
                details={'tree': tree_data},
                execution_time_ms=elapsed
            )
            
        except Exception as e:
            logger.error(f"Error building tree for {directory}: {e}")
            return OperationResult(
                success=False,
                operation='tree',
                error=str(e)
            )
    
    async def execute(self, **kwargs) -> ToolResult:
        """
        Execute file operation.
        
        Supported operations:
        - copy: Copy file/directory
        - move: Move/rename file/directory
        - delete: Delete file/directory
        - info: Get file info
        - search: Search for files
        - chmod: Change permissions
        - compare: Compare files
        - tree: Get directory tree
        """
        operation = kwargs.get('operation', 'info')
        
        start_time = datetime.now()
        
        try:
            if operation == 'copy':
                source = kwargs.get('source') or kwargs.get('src')
                destination = kwargs.get('destination') or kwargs.get('dest') or kwargs.get('dst')
                
                if not source or not destination:
                    return ToolResult(
                        status=ToolStatus.FAILURE,
                        error="source and destination are required for copy"
                    )
                
                conflict_str = kwargs.get('conflict', 'fail')
                try:
                    conflict = ConflictResolution(conflict_str)
                except ValueError:
                    conflict = ConflictResolution.FAIL
                
                result = await self.copy(
                    source,
                    destination,
                    recursive=kwargs.get('recursive', True),
                    preserve_metadata=kwargs.get('preserve_metadata', True),
                    conflict=conflict
                )
                
            elif operation == 'move':
                source = kwargs.get('source') or kwargs.get('src')
                destination = kwargs.get('destination') or kwargs.get('dest') or kwargs.get('dst')
                
                if not source or not destination:
                    return ToolResult(
                        status=ToolStatus.FAILURE,
                        error="source and destination are required for move"
                    )
                
                conflict_str = kwargs.get('conflict', 'fail')
                try:
                    conflict = ConflictResolution(conflict_str)
                except ValueError:
                    conflict = ConflictResolution.FAIL
                
                result = await self.move(source, destination, conflict=conflict)
                
            elif operation == 'delete':
                path = kwargs.get('path') or kwargs.get('source')
                if not path:
                    return ToolResult(
                        status=ToolStatus.FAILURE,
                        error="path is required for delete"
                    )
                
                result = await self.delete(
                    path,
                    recursive=kwargs.get('recursive', False),
                    force=kwargs.get('force', False),
                    secure=kwargs.get('secure', False)
                )
                
            elif operation == 'info':
                path = kwargs.get('path')
                if not path:
                    return ToolResult(
                        status=ToolStatus.FAILURE,
                        error="path is required for info"
                    )
                
                info = await self.get_info(
                    path,
                    calculate_checksum=kwargs.get('checksum', False)
                )
                
                if info:
                    return ToolResult(
                        status=ToolStatus.SUCCESS,
                        data=info.to_dict()
                    )
                else:
                    return ToolResult(
                        status=ToolStatus.FAILURE,
                        error=f"Could not get info for: {path}"
                    )
                    
            elif operation == 'search':
                directory = kwargs.get('directory') or kwargs.get('path', '.')
                
                result = await self.search(
                    directory,
                    pattern=kwargs.get('pattern', '*'),
                    recursive=kwargs.get('recursive', True),
                    file_type=kwargs.get('file_type'),
                    min_size=kwargs.get('min_size'),
                    max_size=kwargs.get('max_size'),
                    max_results=kwargs.get('max_results', 1000),
                    include_hidden=kwargs.get('include_hidden', False)
                )
                
                return ToolResult(
                    status=ToolStatus.SUCCESS if result.success else ToolStatus.FAILURE,
                    data=result.to_dict() if result.success else None,
                    error=result.error
                )
                
            elif operation == 'chmod':
                path = kwargs.get('path')
                mode = kwargs.get('mode')
                
                if not path or not mode:
                    return ToolResult(
                        status=ToolStatus.FAILURE,
                        error="path and mode are required for chmod"
                    )
                
                result = await self.chmod(
                    path,
                    mode,
                    recursive=kwargs.get('recursive', False)
                )
                
            elif operation == 'compare':
                file1 = kwargs.get('file1') or kwargs.get('source')
                file2 = kwargs.get('file2') or kwargs.get('destination')
                
                if not file1 or not file2:
                    return ToolResult(
                        status=ToolStatus.FAILURE,
                        error="file1 and file2 are required for compare"
                    )
                
                result = await self.compare(file1, file2)
                
            elif operation == 'tree':
                directory = kwargs.get('directory') or kwargs.get('path', '.')
                
                result = await self.tree(
                    directory,
                    max_depth=kwargs.get('max_depth', 3),
                    include_hidden=kwargs.get('include_hidden', False),
                    dirs_only=kwargs.get('dirs_only', False)
                )
                
            else:
                return ToolResult(
                    status=ToolStatus.FAILURE,
                    error=f"Unknown operation: {operation}"
                )
            
            elapsed = (datetime.now() - start_time).total_seconds()
            
            if result.success:
                return ToolResult(
                    status=ToolStatus.SUCCESS,
                    data=result.to_dict(),
                    execution_time=elapsed
                )
            else:
                return ToolResult(
                    status=ToolStatus.FAILURE,
                    error=result.error,
                    execution_time=elapsed
                )
                
        except Exception as e:
            logger.error(f"FileOperationsTool execution error: {e}")
            return ToolResult(
                status=ToolStatus.FAILURE,
                error=str(e)
            )


# Create singleton instance
file_operations_tool = FileOperationsTool()


# Register the tool
def register():
    """Register file operations tool with the registry."""
    tool_registry.register(file_operations_tool)


# Auto-register on import
try:
    register()
except Exception as e:
    logger.warning(f"Could not auto-register file_operations tool: {e}")


# Convenience functions for direct usage
async def copy_file(source: str, destination: str, **kwargs) -> OperationResult:
    """Copy a file or directory."""
    return await file_operations_tool.copy(source, destination, **kwargs)


async def move_file(source: str, destination: str, **kwargs) -> OperationResult:
    """Move or rename a file or directory."""
    return await file_operations_tool.move(source, destination, **kwargs)


async def delete_file(path: str, **kwargs) -> OperationResult:
    """Delete a file or directory."""
    return await file_operations_tool.delete(path, **kwargs)


async def search_files(directory: str, pattern: str = "*", **kwargs) -> SearchResult:
    """Search for files."""
    return await file_operations_tool.search(directory, pattern, **kwargs)


async def get_file_info(path: str, **kwargs) -> Optional[FileInfo]:
    """Get file information."""
    return await file_operations_tool.get_info(path, **kwargs)