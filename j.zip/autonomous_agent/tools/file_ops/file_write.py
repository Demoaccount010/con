"""
File Write Tool - Comprehensive file writing operations.
Supports atomic writes, backups, streaming, and various write modes.
"""

import asyncio
import aiofiles
import aiofiles.os
import os
import shutil
import tempfile
import hashlib
from pathlib import Path
from typing import Optional, List, Dict, Any, Union
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import json
import logging

# Import from our tool system
import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from tools.base_tool import (
    BaseTool, ToolResult, ToolStatus, ToolCategory,
    RiskLevel, tool_registry
)
from security.path_validator import PathValidator
from output.output_manager import OutputManager

logger = logging.getLogger(__name__)


class WriteMode(Enum):
    """File write modes."""
    CREATE = "create"           # Create new file (fail if exists)
    OVERWRITE = "overwrite"     # Overwrite existing file
    APPEND = "append"           # Append to file
    PREPEND = "prepend"         # Prepend to file
    INSERT = "insert"           # Insert at position
    ATOMIC = "atomic"           # Atomic write (temp file + rename)


class BackupStrategy(Enum):
    """Backup strategies for writes."""
    NONE = "none"
    NUMBERED = "numbered"       # file.txt.1, file.txt.2
    TIMESTAMPED = "timestamped" # file.txt.2024-01-15_10-30-45
    SINGLE = "single"           # file.txt.bak (overwritten each time)


@dataclass
class WriteResult:
    """Result of a file write operation."""
    success: bool
    path: Optional[str] = None
    bytes_written: int = 0
    backup_path: Optional[str] = None
    checksum_md5: Optional[str] = None
    checksum_sha256: Optional[str] = None
    error: Optional[str] = None
    write_time_ms: float = 0
    mode_used: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'success': self.success,
            'path': self.path,
            'bytes_written': self.bytes_written,
            'backup_path': self.backup_path,
            'checksum_md5': self.checksum_md5,
            'checksum_sha256': self.checksum_sha256,
            'error': self.error,
            'write_time_ms': self.write_time_ms,
            'mode_used': self.mode_used
        }


class FileWriteTool(BaseTool):
    """
    Comprehensive file writing tool.
    
    Capabilities:
    - Create new files
    - Overwrite existing files
    - Append to files
    - Prepend to files
    - Insert content at position
    - Atomic writes (safe against crashes)
    - Automatic backups
    - Write with checksums
    - Write lines
    - Write JSON
    - Write binary data
    """
    
    def __init__(self, path_validator: Optional[PathValidator] = None):
        super().__init__(
            name="file_write",
            description="Write files with multiple modes (create, overwrite, append, atomic)",
            category=ToolCategory.FILE,
            risk_level=RiskLevel.MEDIUM,
            requires_confirmation=True,  # Writing requires confirmation
            timeout=120.0,
            version="1.0.0"
        )
        self.path_validator = path_validator or PathValidator()
        self.output = OutputManager()
        
        # Maximum file size for single write (500MB)
        self.max_write_size = 500 * 1024 * 1024
        
        # Backup directory
        self.backup_dir = Path.home() / '.agent_backups'
    
    async def _ensure_directory(self, path: Path) -> bool:
        """Ensure parent directory exists."""
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            return True
        except Exception as e:
            logger.error(f"Failed to create directory {path.parent}: {e}")
            return False
    
    async def _create_backup(
        self,
        path: Path,
        strategy: BackupStrategy
    ) -> Optional[str]:
        """Create backup of existing file."""
        if not path.exists() or strategy == BackupStrategy.NONE:
            return None
        
        try:
            if strategy == BackupStrategy.SINGLE:
                backup_path = path.with_suffix(path.suffix + '.bak')
            elif strategy == BackupStrategy.TIMESTAMPED:
                timestamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
                backup_path = path.with_suffix(f'{path.suffix}.{timestamp}')
            elif strategy == BackupStrategy.NUMBERED:
                # Find next available number
                i = 1
                while True:
                    backup_path = path.with_suffix(f'{path.suffix}.{i}')
                    if not backup_path.exists():
                        break
                    i += 1
            else:
                return None
            
            shutil.copy2(str(path), str(backup_path))
            logger.info(f"Created backup: {backup_path}")
            return str(backup_path)
            
        except Exception as e:
            logger.error(f"Failed to create backup: {e}")
            return None
    
    def _calculate_checksums(self, content: bytes) -> tuple:
        """Calculate MD5 and SHA256 checksums."""
        md5 = hashlib.md5(content).hexdigest()
        sha256 = hashlib.sha256(content).hexdigest()
        return md5, sha256
    
    async def write_text(
        self,
        file_path: str,
        content: str,
        mode: WriteMode = WriteMode.OVERWRITE,
        encoding: str = "utf-8",
        backup: BackupStrategy = BackupStrategy.NONE,
        create_dirs: bool = True,
        newline: str = "\n",
        calculate_checksum: bool = False
    ) -> WriteResult:
        """
        Write text content to file.
        
        Args:
            file_path: Path to file
            content: Text content to write
            mode: Write mode (create, overwrite, append, etc.)
            encoding: Text encoding
            backup: Backup strategy
            create_dirs: Create parent directories if needed
            newline: Newline character
            calculate_checksum: Calculate checksums after write
            
        Returns:
            WriteResult with operation details
        """
        start_time = datetime.now()
        path = Path(file_path).resolve()
        
        try:
            # Validate path
            if not await self.path_validator.validate(path, 'write'):
                return WriteResult(
                    success=False,
                    error=f"Path validation failed: {path}"
                )
            
            # Check content size
            content_bytes = content.encode(encoding)
            if len(content_bytes) > self.max_write_size:
                return WriteResult(
                    success=False,
                    error=f"Content too large: {len(content_bytes)} bytes"
                )
            
            # Handle different modes
            if mode == WriteMode.CREATE:
                if path.exists():
                    return WriteResult(
                        success=False,
                        error=f"File already exists: {path}"
                    )
                file_mode = 'w'
            elif mode == WriteMode.OVERWRITE:
                file_mode = 'w'
            elif mode == WriteMode.APPEND:
                file_mode = 'a'
            elif mode == WriteMode.ATOMIC:
                return await self._write_atomic(path, content_bytes, encoding, backup, calculate_checksum)
            elif mode == WriteMode.PREPEND:
                return await self._write_prepend(path, content, encoding, backup, calculate_checksum)
            else:
                file_mode = 'w'
            
            # Create directories if needed
            if create_dirs:
                if not await self._ensure_directory(path):
                    return WriteResult(
                        success=False,
                        error=f"Failed to create directory: {path.parent}"
                    )
            
            # Create backup if needed
            backup_path = await self._create_backup(path, backup)
            
            # Write file
            async with aiofiles.open(path, file_mode, encoding=encoding, newline=newline) as f:
                await f.write(content)
            
            # Calculate checksums if requested
            md5, sha256 = None, None
            if calculate_checksum:
                md5, sha256 = self._calculate_checksums(content_bytes)
            
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            
            return WriteResult(
                success=True,
                path=str(path),
                bytes_written=len(content_bytes),
                backup_path=backup_path,
                checksum_md5=md5,
                checksum_sha256=sha256,
                write_time_ms=elapsed,
                mode_used=mode.value
            )
            
        except PermissionError:
            return WriteResult(
                success=False,
                error=f"Permission denied: {path}"
            )
        except Exception as e:
            logger.error(f"Error writing file {path}: {e}")
            return WriteResult(success=False, error=str(e))
    
    async def _write_atomic(
        self,
        path: Path,
        content: bytes,
        encoding: str,
        backup: BackupStrategy,
        calculate_checksum: bool
    ) -> WriteResult:
        """Perform atomic write using temp file and rename."""
        start_time = datetime.now()
        temp_path = None
        
        try:
            # Create backup
            backup_path = await self._create_backup(path, backup)
            
            # Ensure directory exists
            if not await self._ensure_directory(path):
                return WriteResult(
                    success=False,
                    error=f"Failed to create directory: {path.parent}"
                )
            
            # Write to temp file
            fd, temp_path = tempfile.mkstemp(
                dir=path.parent,
                prefix='.tmp_',
                suffix=path.suffix
            )
            os.close(fd)
            
            async with aiofiles.open(temp_path, 'wb') as f:
                await f.write(content)
            
            # Sync to disk
            os.sync()
            
            # Atomic rename
            os.replace(temp_path, path)
            temp_path = None  # Successfully renamed
            
            # Calculate checksums
            md5, sha256 = None, None
            if calculate_checksum:
                md5, sha256 = self._calculate_checksums(content)
            
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            
            return WriteResult(
                success=True,
                path=str(path),
                bytes_written=len(content),
                backup_path=backup_path,
                checksum_md5=md5,
                checksum_sha256=sha256,
                write_time_ms=elapsed,
                mode_used='atomic'
            )
            
        except Exception as e:
            # Cleanup temp file on failure
            if temp_path and os.path.exists(temp_path):
                try:
                    os.unlink(temp_path)
                except:
                    pass
            logger.error(f"Atomic write failed: {e}")
            return WriteResult(success=False, error=str(e))
    
    async def _write_prepend(
        self,
        path: Path,
        content: str,
        encoding: str,
        backup: BackupStrategy,
        calculate_checksum: bool
    ) -> WriteResult:
        """Prepend content to file."""
        start_time = datetime.now()
        
        try:
            # Read existing content
            existing = ""
            if path.exists():
                async with aiofiles.open(path, 'r', encoding=encoding) as f:
                    existing = await f.read()
            
            # Combine content
            new_content = content + existing
            content_bytes = new_content.encode(encoding)
            
            # Create backup
            backup_path = await self._create_backup(path, backup)
            
            # Write combined content
            async with aiofiles.open(path, 'w', encoding=encoding) as f:
                await f.write(new_content)
            
            # Calculate checksums
            md5, sha256 = None, None
            if calculate_checksum:
                md5, sha256 = self._calculate_checksums(content_bytes)
            
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            
            return WriteResult(
                success=True,
                path=str(path),
                bytes_written=len(content_bytes),
                backup_path=backup_path,
                checksum_md5=md5,
                checksum_sha256=sha256,
                write_time_ms=elapsed,
                mode_used='prepend'
            )
            
        except Exception as e:
            logger.error(f"Prepend write failed: {e}")
            return WriteResult(success=False, error=str(e))
    
    async def write_binary(
        self,
        file_path: str,
        content: bytes,
        mode: WriteMode = WriteMode.OVERWRITE,
        backup: BackupStrategy = BackupStrategy.NONE,
        create_dirs: bool = True,
        calculate_checksum: bool = False
    ) -> WriteResult:
        """
        Write binary content to file.
        
        Args:
            file_path: Path to file
            content: Binary content to write
            mode: Write mode
            backup: Backup strategy
            create_dirs: Create parent directories
            calculate_checksum: Calculate checksums
            
        Returns:
            WriteResult with operation details
        """
        start_time = datetime.now()
        path = Path(file_path).resolve()
        
        try:
            if not await self.path_validator.validate(path, 'write'):
                return WriteResult(
                    success=False,
                    error=f"Path validation failed: {path}"
                )
            
            if len(content) > self.max_write_size:
                return WriteResult(
                    success=False,
                    error=f"Content too large: {len(content)} bytes"
                )
            
            if mode == WriteMode.CREATE and path.exists():
                return WriteResult(
                    success=False,
                    error=f"File already exists: {path}"
                )
            
            if mode == WriteMode.ATOMIC:
                return await self._write_atomic(path, content, 'binary', backup, calculate_checksum)
            
            if create_dirs:
                if not await self._ensure_directory(path):
                    return WriteResult(
                        success=False,
                        error=f"Failed to create directory: {path.parent}"
                    )
            
            backup_path = await self._create_backup(path, backup)
            
            file_mode = 'ab' if mode == WriteMode.APPEND else 'wb'
            
            async with aiofiles.open(path, file_mode) as f:
                await f.write(content)
            
            md5, sha256 = None, None
            if calculate_checksum:
                md5, sha256 = self._calculate_checksums(content)
            
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            
            return WriteResult(
                success=True,
                path=str(path),
                bytes_written=len(content),
                backup_path=backup_path,
                checksum_md5=md5,
                checksum_sha256=sha256,
                write_time_ms=elapsed,
                mode_used=mode.value
            )
            
        except Exception as e:
            logger.error(f"Error writing binary file {path}: {e}")
            return WriteResult(success=False, error=str(e))
    
    async def write_lines(
        self,
        file_path: str,
        lines: List[str],
        mode: WriteMode = WriteMode.OVERWRITE,
        encoding: str = "utf-8",
        line_ending: str = "\n",
        backup: BackupStrategy = BackupStrategy.NONE,
        calculate_checksum: bool = False
    ) -> WriteResult:
        """
        Write list of lines to file.
        
        Args:
            file_path: Path to file
            lines: List of lines to write
            mode: Write mode
            encoding: Text encoding
            line_ending: Line ending character
            backup: Backup strategy
            calculate_checksum: Calculate checksums
            
        Returns:
            WriteResult with operation details
        """
        content = line_ending.join(lines)
        if lines and not content.endswith(line_ending):
            content += line_ending
        
        return await self.write_text(
            file_path,
            content,
            mode=mode,
            encoding=encoding,
            backup=backup,
            calculate_checksum=calculate_checksum
        )
    
    async def write_json(
        self,
        file_path: str,
        data: Union[Dict, List],
        indent: int = 2,
        encoding: str = "utf-8",
        mode: WriteMode = WriteMode.OVERWRITE,
        backup: BackupStrategy = BackupStrategy.NONE,
        sort_keys: bool = False,
        ensure_ascii: bool = False
    ) -> WriteResult:
        """
        Write data as JSON file.
        
        Args:
            file_path: Path to file
            data: Data to serialize as JSON
            indent: Indentation level
            encoding: Text encoding
            mode: Write mode
            backup: Backup strategy
            sort_keys: Sort object keys
            ensure_ascii: Escape non-ASCII characters
            
        Returns:
            WriteResult with operation details
        """
        try:
            content = json.dumps(
                data,
                indent=indent,
                sort_keys=sort_keys,
                ensure_ascii=ensure_ascii
            )
            content += '\n'  # Add trailing newline
            
            return await self.write_text(
                file_path,
                content,
                mode=mode,
                encoding=encoding,
                backup=backup,
                calculate_checksum=True
            )
            
        except (TypeError, ValueError) as e:
            return WriteResult(
                success=False,
                error=f"JSON serialization error: {e}"
            )
    
    async def insert_at_line(
        self,
        file_path: str,
        content: str,
        line_number: int,
        encoding: str = "utf-8",
        backup: BackupStrategy = BackupStrategy.SINGLE
    ) -> WriteResult:
        """
        Insert content at specific line number.
        
        Args:
            file_path: Path to file
            content: Content to insert
            line_number: Line number (1-indexed) to insert at
            encoding: Text encoding
            backup: Backup strategy
            
        Returns:
            WriteResult with operation details
        """
        start_time = datetime.now()
        path = Path(file_path).resolve()
        
        try:
            if not await self.path_validator.validate(path, 'write'):
                return WriteResult(
                    success=False,
                    error=f"Path validation failed: {path}"
                )
            
            if not path.exists():
                return WriteResult(
                    success=False,
                    error=f"File not found: {path}"
                )
            
            # Read existing lines
            async with aiofiles.open(path, 'r', encoding=encoding) as f:
                lines = await f.readlines()
            
            # Validate line number
            if line_number < 1:
                line_number = 1
            if line_number > len(lines) + 1:
                line_number = len(lines) + 1
            
            # Insert content
            insert_lines = content.split('\n')
            for i, line in enumerate(insert_lines):
                if not line.endswith('\n') and i < len(insert_lines) - 1:
                    insert_lines[i] = line + '\n'
            
            lines[line_number - 1:line_number - 1] = [l + '\n' if not l.endswith('\n') else l for l in insert_lines]
            
            # Create backup
            backup_path = await self._create_backup(path, backup)
            
            # Write back
            async with aiofiles.open(path, 'w', encoding=encoding) as f:
                await f.writelines(lines)
            
            new_content = ''.join(lines).encode(encoding)
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            
            return WriteResult(
                success=True,
                path=str(path),
                bytes_written=len(new_content),
                backup_path=backup_path,
                write_time_ms=elapsed,
                mode_used='insert'
            )
            
        except Exception as e:
            logger.error(f"Error inserting at line: {e}")
            return WriteResult(success=False, error=str(e))
    
    async def replace_in_file(
        self,
        file_path: str,
        old_text: str,
        new_text: str,
        encoding: str = "utf-8",
        count: int = -1,
        backup: BackupStrategy = BackupStrategy.SINGLE
    ) -> WriteResult:
        """
        Replace text in file.
        
        Args:
            file_path: Path to file
            old_text: Text to replace
            new_text: Replacement text
            encoding: Text encoding
            count: Number of replacements (-1 for all)
            backup: Backup strategy
            
        Returns:
            WriteResult with operation details
        """
        start_time = datetime.now()
        path = Path(file_path).resolve()
        
        try:
            if not await self.path_validator.validate(path, 'write'):
                return WriteResult(
                    success=False,
                    error=f"Path validation failed: {path}"
                )
            
            if not path.exists():
                return WriteResult(
                    success=False,
                    error=f"File not found: {path}"
                )
            
            # Read file
            async with aiofiles.open(path, 'r', encoding=encoding) as f:
                content = await f.read()
            
            # Count occurrences
            occurrences = content.count(old_text)
            if occurrences == 0:
                return WriteResult(
                    success=True,
                    path=str(path),
                    bytes_written=0,
                    write_time_ms=0,
                    mode_used='replace (no changes)'
                )
            
            # Create backup
            backup_path = await self._create_backup(path, backup)
            
            # Replace
            if count == -1:
                new_content = content.replace(old_text, new_text)
            else:
                new_content = content.replace(old_text, new_text, count)
            
            # Write back
            async with aiofiles.open(path, 'w', encoding=encoding) as f:
                await f.write(new_content)
            
            content_bytes = new_content.encode(encoding)
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            
            return WriteResult(
                success=True,
                path=str(path),
                bytes_written=len(content_bytes),
                backup_path=backup_path,
                write_time_ms=elapsed,
                mode_used=f'replace ({occurrences} occurrences)'
            )
            
        except Exception as e:
            logger.error(f"Error replacing in file: {e}")
            return WriteResult(success=False, error=str(e))
    
    async def touch(
        self,
        file_path: str,
        create_dirs: bool = True
    ) -> WriteResult:
        """
        Create empty file or update timestamps.
        
        Args:
            file_path: Path to file
            create_dirs: Create parent directories
            
        Returns:
            WriteResult with operation details
        """
        start_time = datetime.now()
        path = Path(file_path).resolve()
        
        try:
            if not await self.path_validator.validate(path, 'write'):
                return WriteResult(
                    success=False,
                    error=f"Path validation failed: {path}"
                )
            
            if create_dirs:
                if not await self._ensure_directory(path):
                    return WriteResult(
                        success=False,
                        error=f"Failed to create directory: {path.parent}"
                    )
            
            path.touch(exist_ok=True)
            
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            
            return WriteResult(
                success=True,
                path=str(path),
                bytes_written=0,
                write_time_ms=elapsed,
                mode_used='touch'
            )
            
        except Exception as e:
            logger.error(f"Error touching file: {e}")
            return WriteResult(success=False, error=str(e))
    
    async def execute(self, **kwargs) -> ToolResult:
        """
        Execute file write operation.
        
        Supported operations via 'operation' parameter:
        - text: Write text content
        - binary: Write binary content
        - lines: Write list of lines
        - json: Write JSON data
        - insert: Insert at line
        - replace: Replace text in file
        - touch: Create/update file
        """
        operation = kwargs.get('operation', 'text')
        file_path = kwargs.get('file_path') or kwargs.get('path')
        
        if not file_path:
            return ToolResult(
                status=ToolStatus.FAILURE,
                error="file_path is required"
            )
        
        start_time = datetime.now()
        
        try:
            # Parse mode
            mode_str = kwargs.get('mode', 'overwrite')
            try:
                mode = WriteMode(mode_str)
            except ValueError:
                mode = WriteMode.OVERWRITE
            
            # Parse backup strategy
            backup_str = kwargs.get('backup', 'none')
            try:
                backup = BackupStrategy(backup_str)
            except ValueError:
                backup = BackupStrategy.NONE
            
            if operation == 'text':
                content = kwargs.get('content', '')
                result = await self.write_text(
                    file_path,
                    content,
                    mode=mode,
                    encoding=kwargs.get('encoding', 'utf-8'),
                    backup=backup,
                    create_dirs=kwargs.get('create_dirs', True),
                    calculate_checksum=kwargs.get('checksum', False)
                )
            elif operation == 'binary':
                content = kwargs.get('content', b'')
                if isinstance(content, str):
                    content = content.encode()
                result = await self.write_binary(
                    file_path,
                    content,
                    mode=mode,
                    backup=backup,
                    create_dirs=kwargs.get('create_dirs', True),
                    calculate_checksum=kwargs.get('checksum', False)
                )
            elif operation == 'lines':
                lines = kwargs.get('lines', [])
                result = await self.write_lines(
                    file_path,
                    lines,
                    mode=mode,
                    encoding=kwargs.get('encoding', 'utf-8'),
                    line_ending=kwargs.get('line_ending', '\n'),
                    backup=backup,
                    calculate_checksum=kwargs.get('checksum', False)
                )
            elif operation == 'json':
                data = kwargs.get('data', {})
                result = await self.write_json(
                    file_path,
                    data,
                    indent=kwargs.get('indent', 2),
                    encoding=kwargs.get('encoding', 'utf-8'),
                    mode=mode,
                    backup=backup,
                    sort_keys=kwargs.get('sort_keys', False)
                )
            elif operation == 'insert':
                result = await self.insert_at_line(
                    file_path,
                    kwargs.get('content', ''),
                    kwargs.get('line_number', 1),
                    encoding=kwargs.get('encoding', 'utf-8'),
                    backup=backup
                )
            elif operation == 'replace':
                result = await self.replace_in_file(
                    file_path,
                    kwargs.get('old_text', ''),
                    kwargs.get('new_text', ''),
                    encoding=kwargs.get('encoding', 'utf-8'),
                    count=kwargs.get('count', -1),
                    backup=backup
                )
            elif operation == 'touch':
                result = await self.touch(
                    file_path,
                    create_dirs=kwargs.get('create_dirs', True)
                )
            else:
                return ToolResult(
                    status=ToolStatus.FAILURE,
                    error=f"Unknown operation: {operation}"
                )
            
            elapsed = (datetime.now() - start_time).total_seconds()
            
            if result.success:
                return ToolResult(
                    status=ToolStatus.SUCCESS,
                    data=result.to_dict(),
                    execution_time=elapsed
                )
            else:
                return ToolResult(
                    status=ToolStatus.FAILURE,
                    error=result.error,
                    execution_time=elapsed
                )
                
        except Exception as e:
            logger.error(f"FileWriteTool execution error: {e}")
            return ToolResult(
                status=ToolStatus.FAILURE,
                error=str(e)
            )


# Create singleton instance
file_write_tool = FileWriteTool()


# Register the tool
def register():
    """Register file write tool with the registry."""
    tool_registry.register(file_write_tool)


# Auto-register on import
try:
    register()
except Exception as e:
    logger.warning(f"Could not auto-register file_write tool: {e}")