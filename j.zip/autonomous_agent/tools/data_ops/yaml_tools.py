"""
YAML Tools - YAML parsing, manipulation, and conversion.
Support for multi-document YAML, anchors, and safe loading.
"""

import asyncio
from pathlib import Path
from typing import Optional, Dict, Any, List, Union, Iterator
from dataclasses import dataclass, field
from datetime import datetime
from copy import deepcopy
import logging
import re

import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from tools.base_tool import (
    BaseTool, ToolResult, ToolContext, ResultStatus,
    ToolCategory, ToolRisk
)
from tools.registry import get_registry

logger = logging.getLogger(__name__)

# Check for PyYAML
try:
    import yaml
    from yaml import SafeLoader, SafeDumper
    HAS_YAML = True
except ImportError:
    HAS_YAML = False
    logger.warning("PyYAML not installed, YAML features limited")


class CustomSafeLoader(SafeLoader if HAS_YAML else object):
    """Custom safe loader with additional type support."""
    pass


class CustomSafeDumper(SafeDumper if HAS_YAML else object):
    """Custom safe dumper with better formatting."""
    pass


if HAS_YAML:
    # Add custom representers for better output
    def represent_none(dumper, data):
        return dumper.represent_scalar('tag:yaml.org,2002:null', '')
    
    def represent_str(dumper, data):
        # Use literal style for multiline strings
        if '\n' in data:
            return dumper.represent_scalar('tag:yaml.org,2002:str', data, style='|')
        return dumper.represent_scalar('tag:yaml.org,2002:str', data)
    
    CustomSafeDumper.add_representer(type(None), represent_none)
    CustomSafeDumper.add_representer(str, represent_str)


@dataclass
class YamlDocument:
    """A YAML document."""
    index: int
    data: Any
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'index': self.index,
            'data': self.data
        }


@dataclass
class YamlValidationResult:
    """Result of YAML validation."""
    valid: bool
    document_count: int = 0
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'valid': self.valid,
            'document_count': self.document_count,
            'errors': self.errors,
            'warnings': self.warnings
        }


class YamlTools(BaseTool):
    """
    YAML manipulation tool.
    
    Features:
    - Parse single and multi-document YAML
    - Safe loading (no code execution)
    - Convert to/from JSON
    - Merge YAML files
    - Validate YAML syntax
    - Handle anchors and aliases
    - Pretty formatting
    """
    
    def __init__(self):
        super().__init__(
            name="yaml_tools",
            description="YAML parsing, validation, and manipulation",
            category=ToolCategory.DATA,
            risk=ToolRisk.NONE,
            requires_confirmation=False,
            timeout=60.0,
            version="1.0.0"
        )
    
    async def initialize(self) -> bool:
        """Check YAML availability."""
        if not HAS_YAML:
            logger.warning("PyYAML not available")
        self._initialized = True
        return True
    
    async def parse(
        self,
        data: str,
        multi_document: bool = False,
        safe: bool = True
    ) -> Dict[str, Any]:
        """
        Parse YAML string.
        
        Args:
            data: YAML string
            multi_document: Parse as multiple documents
            safe: Use safe loader
            
        Returns:
            Parsed data with metadata
        """
        if not HAS_YAML:
            return {
                'success': False,
                'error': 'PyYAML not installed'
            }
        
        try:
            Loader = CustomSafeLoader if safe else yaml.FullLoader
            
            if multi_document:
                documents = list(yaml.load_all(data, Loader=Loader))
                return {
                    'success': True,
                    'data': documents,
                    'document_count': len(documents),
                    'multi_document': True
                }
            else:
                parsed = yaml.load(data, Loader=Loader)
                return {
                    'success': True,
                    'data': parsed,
                    'type': type(parsed).__name__
                }
                
        except yaml.YAMLError as e:
            error_msg = str(e)
            line = None
            column = None
            
            # Try to extract line/column
            if hasattr(e, 'problem_mark'):
                mark = e.problem_mark
                line = mark.line + 1
                column = mark.column + 1
            
            return {
                'success': False,
                'error': error_msg,
                'line': line,
                'column': column
            }
    
    async def dump(
        self,
        data: Any,
        default_flow_style: bool = False,
        allow_unicode: bool = True,
        sort_keys: bool = False,
        indent: int = 2,
        width: int = 80
    ) -> str:
        """
        Dump data to YAML string.
        
        Args:
            data: Data to dump
            default_flow_style: Use flow style (compact)
            allow_unicode: Allow unicode characters
            sort_keys: Sort dictionary keys
            indent: Indentation size
            width: Line width
            
        Returns:
            YAML string
        """
        if not HAS_YAML:
            raise RuntimeError("PyYAML not installed")
        
        return yaml.dump(
            data,
            Dumper=CustomSafeDumper,
            default_flow_style=default_flow_style,
            allow_unicode=allow_unicode,
            sort_keys=sort_keys,
            indent=indent,
            width=width
        )
    
    async def dump_all(
        self,
        documents: List[Any],
        **kwargs
    ) -> str:
        """
        Dump multiple documents to YAML string.
        
        Args:
            documents: List of documents
            **kwargs: Same as dump()
            
        Returns:
            Multi-document YAML string
        """
        if not HAS_YAML:
            raise RuntimeError("PyYAML not installed")
        
        return yaml.dump_all(
            documents,
            Dumper=CustomSafeDumper,
            default_flow_style=kwargs.get('default_flow_style', False),
            allow_unicode=kwargs.get('allow_unicode', True),
            sort_keys=kwargs.get('sort_keys', False),
            indent=kwargs.get('indent', 2)
        )
    
    async def validate(
        self,
        data: str,
        multi_document: bool = True
    ) -> YamlValidationResult:
        """
        Validate YAML syntax.
        
        Args:
            data: YAML string
            multi_document: Check for multiple documents
            
        Returns:
            Validation result
        """
        if not HAS_YAML:
            return YamlValidationResult(
                valid=False,
                errors=["PyYAML not installed"]
            )
        
        errors = []
        warnings = []
        doc_count = 0
        
        try:
            documents = list(yaml.load_all(data, Loader=CustomSafeLoader))
            doc_count = len(documents)
            
            # Check for common issues
            if doc_count == 0:
                warnings.append("Empty YAML document")
            
            # Check for tabs (often problematic)
            if '\t' in data:
                warnings.append("YAML contains tabs, consider using spaces")
            
            return YamlValidationResult(
                valid=True,
                document_count=doc_count,
                warnings=warnings
            )
            
        except yaml.YAMLError as e:
            error_msg = str(e)
            if hasattr(e, 'problem_mark'):
                mark = e.problem_mark
                error_msg = f"Line {mark.line + 1}, Column {mark.column + 1}: {e.problem}"
            
            errors.append(error_msg)
            
            return YamlValidationResult(
                valid=False,
                errors=errors
            )
    
    async def to_json(
        self,
        yaml_data: str,
        indent: int = 2
    ) -> Dict[str, Any]:
        """
        Convert YAML to JSON.
        
        Args:
            yaml_data: YAML string
            indent: JSON indentation
            
        Returns:
            JSON string and parsed data
        """
        import json
        
        result = await self.parse(yaml_data, multi_document=False)
        
        if not result['success']:
            return result
        
        data = result['data']
        json_str = json.dumps(data, indent=indent, default=str, ensure_ascii=False)
        
        return {
            'success': True,
            'json': json_str,
            'data': data
        }
    
    async def from_json(
        self,
        json_data: Union[str, Dict, List],
        **dump_options
    ) -> Dict[str, Any]:
        """
        Convert JSON to YAML.
        
        Args:
            json_data: JSON string or parsed data
            **dump_options: YAML dump options
            
        Returns:
            YAML string
        """
        import json
        
        if isinstance(json_data, str):
            try:
                data = json.loads(json_data)
            except json.JSONDecodeError as e:
                return {
                    'success': False,
                    'error': f"Invalid JSON: {e}"
                }
        else:
            data = json_data
        
        yaml_str = await self.dump(data, **dump_options)
        
        return {
            'success': True,
            'yaml': yaml_str,
            'data': data
        }
    
    async def merge(
        self,
        base: str,
        overlay: str,
        deep: bool = True
    ) -> Dict[str, Any]:
        """
        Merge two YAML documents.
        
        Args:
            base: Base YAML
            overlay: YAML to merge on top
            deep: Deep merge
            
        Returns:
            Merged YAML
        """
        base_result = await self.parse(base)
        overlay_result = await self.parse(overlay)
        
        if not base_result['success']:
            return base_result
        if not overlay_result['success']:
            return overlay_result
        
        base_data = base_result['data']
        overlay_data = overlay_result['data']
        
        def merge_recursive(b: Any, o: Any) -> Any:
            if not deep:
                return o
            
            if isinstance(b, dict) and isinstance(o, dict):
                result = dict(b)
                for key, value in o.items():
                    if key in result:
                        result[key] = merge_recursive(result[key], value)
                    else:
                        result[key] = value
                return result
            
            return o
        
        merged = merge_recursive(base_data, overlay_data)
        yaml_str = await self.dump(merged)
        
        return {
            'success': True,
            'yaml': yaml_str,
            'data': merged
        }
    
    async def query(
        self,
        yaml_data: str,
        path: str
    ) -> Dict[str, Any]:
        """
        Query YAML with path syntax.
        
        Args:
            yaml_data: YAML string
            path: Query path (dot notation)
            
        Returns:
            Queried value
        """
        result = await self.parse(yaml_data)
        if not result['success']:
            return result
        
        data = result['data']
        
        # Use JSON tools for querying
        from tools.data_ops.json_tools import json_tools
        value = await json_tools.query(data, path)
        
        return {
            'success': True,
            'path': path,
            'value': value
        }
    
    async def set_value(
        self,
        yaml_data: str,
        path: str,
        value: Any
    ) -> Dict[str, Any]:
        """
        Set a value in YAML at the specified path.
        
        Args:
            yaml_data: YAML string
            path: Path to set
            value: Value to set
            
        Returns:
            Modified YAML
        """
        result = await self.parse(yaml_data)
        if not result['success']:
            return result
        
        data = result['data']
        
        # Use JSON tools for setting
        from tools.data_ops.json_tools import json_tools
        set_result = await json_tools.set_value(data, path, value)
        
        if not set_result['success']:
            return set_result
        
        yaml_str = await self.dump(set_result['data'])
        
        return {
            'success': True,
            'yaml': yaml_str,
            'data': set_result['data']
        }
    
    async def extract_anchors(
        self,
        yaml_data: str
    ) -> Dict[str, Any]:
        """
        Extract anchors and aliases from YAML.
        
        Args:
            yaml_data: YAML string
            
        Returns:
            Anchor definitions
        """
        anchors = {}
        
        # Find anchors using regex
        anchor_pattern = r'&(\w+)\s+'
        alias_pattern = r'\*(\w+)'
        
        anchor_matches = re.findall(anchor_pattern, yaml_data)
        alias_matches = re.findall(alias_pattern, yaml_data)
        
        for anchor in anchor_matches:
            anchors[anchor] = {
                'type': 'anchor',
                'references': alias_matches.count(anchor)
            }
        
        return {
            'anchors': anchors,
            'anchor_count': len(anchor_matches),
            'alias_count': len(alias_matches)
        }
    
    async def format_yaml(
        self,
        yaml_data: str,
        indent: int = 2,
        sort_keys: bool = False
    ) -> str:
        """
        Format YAML with consistent styling.
        
        Args:
            yaml_data: YAML string
            indent: Indentation size
            sort_keys: Sort keys alphabetically
            
        Returns:
            Formatted YAML
        """
        result = await self.parse(yaml_data, multi_document=True)
        
        if not result['success']:
            raise ValueError(result['error'])
        
        if result.get('multi_document'):
            documents = result['data']
            if len(documents) > 1:
                return await self.dump_all(documents, indent=indent, sort_keys=sort_keys)
        
        return await self.dump(result['data'], indent=indent, sort_keys=sort_keys)
    
    async def run(self, context: ToolContext, **kwargs) -> ToolResult:
        """
        Execute YAML operation.
        
        Supported operations:
        - parse: Parse YAML string
        - dump: Convert data to YAML
        - validate: Validate YAML syntax
        - to_json: Convert to JSON
        - from_json: Convert from JSON
        - merge: Merge YAML documents
        - query: Query with path
        - set: Set value at path
        - format: Format YAML
        - anchors: Extract anchors
        """
        operation = kwargs.get('operation', 'parse')
        
        if not HAS_YAML and operation != 'validate':
            return ToolResult.fail(
                error="PyYAML not installed. Install with: pip install pyyaml"
            )
        
        try:
            if operation == 'parse':
                data = kwargs.get('data') or kwargs.get('yaml')
                if not data:
                    return ToolResult.fail(error="data is required")
                
                result = await self.parse(
                    data,
                    multi_document=kwargs.get('multi_document', False),
                    safe=kwargs.get('safe', True)
                )
                
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('error'))
            
            elif operation == 'dump':
                data = kwargs.get('data')
                if data is None:
                    return ToolResult.fail(error="data is required")
                
                yaml_str = await self.dump(
                    data,
                    default_flow_style=kwargs.get('flow_style', False),
                    sort_keys=kwargs.get('sort_keys', False),
                    indent=kwargs.get('indent', 2)
                )
                
                return ToolResult.ok(data={'yaml': yaml_str})
            
            elif operation == 'validate':
                data = kwargs.get('data') or kwargs.get('yaml')
                if not data:
                    return ToolResult.fail(error="data is required")
                
                result = await self.validate(
                    data,
                    multi_document=kwargs.get('multi_document', True)
                )
                
                return ToolResult.ok(
                    data=result.to_dict(),
                    message="Valid YAML" if result.valid else "Invalid YAML"
                )
            
            elif operation == 'to_json':
                data = kwargs.get('data') or kwargs.get('yaml')
                if not data:
                    return ToolResult.fail(error="data is required")
                
                result = await self.to_json(
                    data,
                    indent=kwargs.get('indent', 2)
                )
                
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('error'))
            
            elif operation == 'from_json':
                data = kwargs.get('data') or kwargs.get('json')
                if not data:
                    return ToolResult.fail(error="data is required")
                
                result = await self.from_json(
                    data,
                    sort_keys=kwargs.get('sort_keys', False),
                    indent=kwargs.get('indent', 2)
                )
                
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('error'))
            
            elif operation == 'merge':
                base = kwargs.get('base')
                overlay = kwargs.get('overlay')
                
                if not base or not overlay:
                    return ToolResult.fail(error="base and overlay are required")
                
                result = await self.merge(
                    base, overlay,
                    deep=kwargs.get('deep', True)
                )
                
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('error'))
            
            elif operation == 'query':
                data = kwargs.get('data') or kwargs.get('yaml')
                path = kwargs.get('path')
                
                if not data or not path:
                    return ToolResult.fail(error="data and path are required")
                
                result = await self.query(data, path)
                
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('error'))
            
            elif operation == 'set':
                data = kwargs.get('data') or kwargs.get('yaml')
                path = kwargs.get('path')
                value = kwargs.get('value')
                
                if not data or not path:
                    return ToolResult.fail(error="data and path are required")
                
                result = await self.set_value(data, path, value)
                
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('error'))
            
            elif operation == 'format':
                data = kwargs.get('data') or kwargs.get('yaml')
                if not data:
                    return ToolResult.fail(error="data is required")
                
                formatted = await self.format_yaml(
                    data,
                    indent=kwargs.get('indent', 2),
                    sort_keys=kwargs.get('sort_keys', False)
                )
                
                return ToolResult.ok(data={'formatted': formatted})
            
            elif operation == 'anchors':
                data = kwargs.get('data') or kwargs.get('yaml')
                if not data:
                    return ToolResult.fail(error="data is required")
                
                result = await self.extract_anchors(data)
                
                return ToolResult.ok(data=result)
            
            else:
                return ToolResult.fail(error=f"Unknown operation: {operation}")
            
        except Exception as e:
            logger.error(f"YamlTools error: {e}")
            return ToolResult.error(error=str(e))


# Create singleton
yaml_tools = YamlTools()


def register():
    """Register YAML tools."""
    registry = get_registry()
    registry.register_tool(yaml_tools)