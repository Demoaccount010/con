"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                            TOOL REGISTRY                                      ║
║              Central Registry for All Agent Tools                             ║
╚══════════════════════════════════════════════════════════════════════════════╝

The Tool Registry manages:
- Tool registration and discovery
- Tool categorization
- Permission management
- Tool metadata and documentation
"""

import asyncio
import logging
from datetime import datetime
from typing import Optional, Dict, Any, List, Set, Type, Callable
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
import importlib
import inspect

logger = logging.getLogger(__name__)


class ToolCategory(Enum):
    """Categories of tools"""
    FILE = "file"
    DIRECTORY = "directory"
    SYSTEM = "system"
    NETWORK = "network"
    DATA = "data"
    DATABASE = "database"
    GIT = "git"
    DOCKER = "docker"
    KUBERNETES = "kubernetes"
    BACKUP = "backup"
    LOG = "log"
    SECURITY = "security"
    COMPRESSION = "compression"
    PACKAGE = "package"
    COMMUNICATION = "communication"
    CODE = "code"
    SCHEDULING = "scheduling"
    MONITORING = "monitoring"
    AI_ML = "ai_ml"
    WEB = "web"
    CLOUD = "cloud"
    UTILITY = "utility"


class ToolRisk(Enum):
    """Risk level of tools"""
    SAFE = "safe"               # No risk, read-only
    LOW = "low"                 # Minor changes possible
    MEDIUM = "medium"           # Significant changes possible
    HIGH = "high"               # Destructive potential
    CRITICAL = "critical"       # System-level changes


class ToolStatus(Enum):
    """Status of a tool"""
    AVAILABLE = "available"
    DISABLED = "disabled"
    DEPRECATED = "deprecated"
    ERROR = "error"
    LOADING = "loading"


@dataclass
class ToolParameter:
    """A parameter for a tool"""
    name: str
    type: str
    description: str
    required: bool = True
    default: Any = None
    choices: Optional[List[Any]] = None
    
    def validate(self, value: Any) -> tuple[bool, Optional[str]]:
        """Validate parameter value"""
        if value is None:
            if self.required and self.default is None:
                return False, f"Required parameter '{self.name}' is missing"
            return True, None
        
        if self.choices and value not in self.choices:
            return False, f"Value must be one of: {self.choices}"
        
        return True, None


@dataclass
class ToolMetadata:
    """Metadata for a tool"""
    name: str
    description: str
    category: ToolCategory
    risk: ToolRisk
    
    # Parameters
    parameters: List[ToolParameter] = field(default_factory=list)
    
    # Permissions
    requires_confirmation: bool = False
    requires_permission: Optional[str] = None
    
    # Documentation
    usage_examples: List[str] = field(default_factory=list)
    notes: Optional[str] = None
    
    # Status
    status: ToolStatus = ToolStatus.AVAILABLE
    version: str = "1.0.0"
    
    # Tracking
    registered_at: datetime = field(default_factory=datetime.now)
    last_used: Optional[datetime] = None
    use_count: int = 0
    success_count: int = 0
    failure_count: int = 0
    
    @property
    def success_rate(self) -> float:
        total = self.success_count + self.failure_count
        return self.success_count / total if total > 0 else 1.0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "category": self.category.value,
            "risk": self.risk.value,
            "parameters": [
                {
                    "name": p.name,
                    "type": p.type,
                    "description": p.description,
                    "required": p.required,
                    "default": p.default
                }
                for p in self.parameters
            ],
            "requires_confirmation": self.requires_confirmation,
            "status": self.status.value,
            "version": self.version,
            "use_count": self.use_count,
            "success_rate": self.success_rate
        }


@dataclass
class RegisteredTool:
    """A registered tool"""
    metadata: ToolMetadata
    handler: Callable
    tool_class: Optional[Type] = None
    instance: Optional[Any] = None
    
    # Tags for search
    tags: Set[str] = field(default_factory=set)
    
    # Aliases
    aliases: Set[str] = field(default_factory=set)


@dataclass
class RegistryConfig:
    """Configuration for tool registry"""
    # Auto-loading
    auto_load_tools: bool = True
    tools_directory: str = "tools"
    
    # Permissions
    require_permissions: bool = True
    default_permissions: List[str] = field(default_factory=list)
    
    # Safety
    block_high_risk: bool = False
    require_confirmation_for_risk: ToolRisk = ToolRisk.HIGH
    
    # Limits
    max_tools: int = 500
    
    # Caching
    cache_tool_instances: bool = True


class ToolRegistry:
    """
    Central registry for all agent tools
    
    Features:
    - Tool registration and discovery
    - Category-based organization
    - Permission management
    - Tool search and filtering
    - Usage tracking
    """
    
    def __init__(self, config: Optional[RegistryConfig] = None):
        self.config = config or RegistryConfig()
        
        # Registry storage
        self._tools: Dict[str, RegisteredTool] = {}
        self._by_category: Dict[ToolCategory, Set[str]] = {}
        self._by_tag: Dict[str, Set[str]] = {}
        self._aliases: Dict[str, str] = {}  # alias -> tool_name
        
        # Permissions
        self._permissions: Set[str] = set(self.config.default_permissions)
        self._blocked_tools: Set[str] = set()
        
        # Statistics
        self._stats = {
            "total_registered": 0,
            "total_executions": 0,
            "successful_executions": 0,
            "failed_executions": 0
        }
        
        # Lock for thread safety
        self._lock = asyncio.Lock()
        
        logger.info("ToolRegistry initialized")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # REGISTRATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def register(
        self,
        name: str,
        handler: Callable,
        description: str,
        category: ToolCategory,
        risk: ToolRisk = ToolRisk.LOW,
        parameters: Optional[List[ToolParameter]] = None,
        requires_confirmation: bool = False,
        tags: Optional[List[str]] = None,
        aliases: Optional[List[str]] = None,
        **kwargs
    ) -> bool:
        """
        Register a new tool
        
        Args:
            name: Unique tool name
            handler: Async function to execute
            description: Tool description
            category: Tool category
            risk: Risk level
            parameters: Tool parameters
            requires_confirmation: Whether to require user confirmation
            tags: Search tags
            aliases: Alternative names
        
        Returns:
            Success status
        """
        async with self._lock:
            if name in self._tools:
                logger.warning(f"Tool already registered: {name}")
                return False
            
            if len(self._tools) >= self.config.max_tools:
                logger.error("Maximum tool limit reached")
                return False
            
            # Determine if confirmation needed based on risk
            if risk.value >= self.config.require_confirmation_for_risk.value:
                requires_confirmation = True
            
            metadata = ToolMetadata(
                name=name,
                description=description,
                category=category,
                risk=risk,
                parameters=parameters or [],
                requires_confirmation=requires_confirmation,
                **kwargs
            )
            
            tool = RegisteredTool(
                metadata=metadata,
                handler=handler,
                tags=set(tags or []),
                aliases=set(aliases or [])
            )
            
            # Add tool name as tag
            tool.tags.add(name.lower())
            tool.tags.add(category.value)
            
            # Store
            self._tools[name] = tool
            
            # Index by category
            if category not in self._by_category:
                self._by_category[category] = set()
            self._by_category[category].add(name)
            
            # Index by tags
            for tag in tool.tags:
                if tag not in self._by_tag:
                    self._by_tag[tag] = set()
                self._by_tag[tag].add(name)
            
            # Register aliases
            for alias in tool.aliases:
                self._aliases[alias.lower()] = name
            
            self._stats["total_registered"] += 1
            
            logger.debug(f"Registered tool: {name} ({category.value})")
            return True
    
    async def register_class(
        self,
        tool_class: Type,
        **kwargs
    ) -> bool:
        """Register a tool from a class"""
        # Get metadata from class
        name = getattr(tool_class, 'name', tool_class.__name__.lower())
        description = getattr(tool_class, 'description', tool_class.__doc__ or '')
        category = getattr(tool_class, 'category', ToolCategory.UTILITY)
        risk = getattr(tool_class, 'risk', ToolRisk.LOW)
        
        # Get parameters from execute method signature
        parameters = []
        if hasattr(tool_class, 'execute'):
            sig = inspect.signature(tool_class.execute)
            for param_name, param in sig.parameters.items():
                if param_name in ['self', 'args', 'kwargs']:
                    continue
                
                param_type = 'any'
                if param.annotation != inspect.Parameter.empty:
                    param_type = param.annotation.__name__ if hasattr(param.annotation, '__name__') else str(param.annotation)
                
                parameters.append(ToolParameter(
                    name=param_name,
                    type=param_type,
                    description=f"Parameter: {param_name}",
                    required=param.default == inspect.Parameter.empty,
                    default=None if param.default == inspect.Parameter.empty else param.default
                ))
        
        # Create instance if caching
        instance = None
        if self.config.cache_tool_instances:
            try:
                instance = tool_class()
            except Exception as e:
                logger.warning(f"Could not create instance of {name}: {e}")
        
        # Create handler
        async def handler(**params):
            inst = instance or tool_class()
            if asyncio.iscoroutinefunction(inst.execute):
                return await inst.execute(**params)
            return inst.execute(**params)
        
        # Register
        success = await self.register(
            name=name,
            handler=handler,
            description=description,
            category=category,
            risk=risk,
            parameters=parameters,
            **kwargs
        )
        
        if success:
            self._tools[name].tool_class = tool_class
            self._tools[name].instance = instance
        
        return success
    
    async def unregister(self, name: str) -> bool:
        """Unregister a tool"""
        async with self._lock:
            if name not in self._tools:
                return False
            
            tool = self._tools.pop(name)
            
            # Remove from category index
            if tool.metadata.category in self._by_category:
                self._by_category[tool.metadata.category].discard(name)
            
            # Remove from tag index
            for tag in tool.tags:
                if tag in self._by_tag:
                    self._by_tag[tag].discard(name)
            
            # Remove aliases
            for alias in tool.aliases:
                if alias.lower() in self._aliases:
                    del self._aliases[alias.lower()]
            
            logger.debug(f"Unregistered tool: {name}")
            return True
    
    # ═══════════════════════════════════════════════════════════════════════════
    # RETRIEVAL
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get(self, name: str) -> Optional[RegisteredTool]:
        """Get a tool by name or alias"""
        # Check direct name
        if name in self._tools:
            return self._tools[name]
        
        # Check aliases
        if name.lower() in self._aliases:
            actual_name = self._aliases[name.lower()]
            return self._tools.get(actual_name)
        
        return None
    
    def get_handler(self, name: str) -> Optional[Callable]:
        """Get tool handler"""
        tool = self.get(name)
        return tool.handler if tool else None
    
    def get_metadata(self, name: str) -> Optional[ToolMetadata]:
        """Get tool metadata"""
        tool = self.get(name)
        return tool.metadata if tool else None
    
    def exists(self, name: str) -> bool:
        """Check if tool exists"""
        return self.get(name) is not None
    
    def get_by_category(self, category: ToolCategory) -> List[RegisteredTool]:
        """Get all tools in a category"""
        names = self._by_category.get(category, set())
        return [self._tools[name] for name in names if name in self._tools]
    
    def get_by_tag(self, tag: str) -> List[RegisteredTool]:
        """Get all tools with a tag"""
        names = self._by_tag.get(tag.lower(), set())
        return [self._tools[name] for name in names if name in self._tools]
    
    def get_all(self) -> List[RegisteredTool]:
        """Get all registered tools"""
        return list(self._tools.values())
    
    def get_available(self) -> List[RegisteredTool]:
        """Get all available (non-blocked, non-disabled) tools"""
        return [
            tool for tool in self._tools.values()
            if tool.metadata.status == ToolStatus.AVAILABLE
            and tool.metadata.name not in self._blocked_tools
        ]
    
    # ═══════════════════════════════════════════════════════════════════════════
    # SEARCH
    # ═══════════════════════════════════════════════════════════════════════════
    
    def search(
        self,
        query: str,
        category: Optional[ToolCategory] = None,
        risk: Optional[ToolRisk] = None,
        limit: int = 20
    ) -> List[RegisteredTool]:
        """Search for tools"""
        results = []
        query_lower = query.lower()
        
        for tool in self._tools.values():
            # Skip blocked/disabled
            if tool.metadata.status != ToolStatus.AVAILABLE:
                continue
            if tool.metadata.name in self._blocked_tools:
                continue
            
            # Filter by category
            if category and tool.metadata.category != category:
                continue
            
            # Filter by risk
            if risk and tool.metadata.risk != risk:
                continue
            
            # Calculate relevance score
            score = 0
            
            # Name match
            if query_lower in tool.metadata.name.lower():
                score += 3
            
            # Description match
            if query_lower in tool.metadata.description.lower():
                score += 2
            
            # Tag match
            if query_lower in tool.tags:
                score += 1
            
            # Alias match
            for alias in tool.aliases:
                if query_lower in alias.lower():
                    score += 1
                    break
            
            if score > 0:
                results.append((score, tool))
        
        # Sort by score
        results.sort(key=lambda x: x[0], reverse=True)
        
        return [tool for _, tool in results[:limit]]
    
    def find_by_action(self, action: str) -> Optional[RegisteredTool]:
        """Find best tool for an action"""
        # Direct match
        tool = self.get(action)
        if tool:
            return tool
        
        # Search
        results = self.search(action, limit=1)
        return results[0] if results else None
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PERMISSIONS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def grant_permission(self, permission: str) -> None:
        """Grant a permission"""
        self._permissions.add(permission)
    
    def revoke_permission(self, permission: str) -> None:
        """Revoke a permission"""
        self._permissions.discard(permission)
    
    def has_permission(self, permission: str) -> bool:
        """Check if permission is granted"""
        return permission in self._permissions
    
    def can_use_tool(self, name: str) -> tuple[bool, Optional[str]]:
        """Check if tool can be used"""
        tool = self.get(name)
        
        if not tool:
            return False, f"Tool not found: {name}"
        
        if tool.metadata.name in self._blocked_tools:
            return False, f"Tool is blocked: {name}"
        
        if tool.metadata.status != ToolStatus.AVAILABLE:
            return False, f"Tool is not available: {tool.metadata.status.value}"
        
        if self.config.block_high_risk and tool.metadata.risk == ToolRisk.CRITICAL:
            return False, "Critical risk tools are blocked"
        
        if tool.metadata.requires_permission:
            if not self.has_permission(tool.metadata.requires_permission):
                return False, f"Missing permission: {tool.metadata.requires_permission}"
        
        return True, None
    
    def block_tool(self, name: str) -> bool:
        """Block a tool"""
        if name in self._tools:
            self._blocked_tools.add(name)
            return True
        return False
    
    def unblock_tool(self, name: str) -> bool:
        """Unblock a tool"""
        if name in self._blocked_tools:
            self._blocked_tools.discard(name)
            return True
        return False
    
    # ═══════════════════════════════════════════════════════════════════════════
    # USAGE TRACKING
    # ═══════════════════════════════════════════════════════════════════════════
    
    def record_usage(
        self,
        name: str,
        success: bool,
        execution_time_ms: float = 0.0
    ) -> None:
        """Record tool usage"""
        tool = self.get(name)
        if not tool:
            return
        
        tool.metadata.use_count += 1
        tool.metadata.last_used = datetime.now()
        
        if success:
            tool.metadata.success_count += 1
            self._stats["successful_executions"] += 1
        else:
            tool.metadata.failure_count += 1
            self._stats["failed_executions"] += 1
        
        self._stats["total_executions"] += 1
    
    # ═══════════════════════════════════════════════════════════════════════════
    # LISTING AND INFO
    # ═══════════════════════════════════════════════════════════════════════════
    
    def list_tools(
        self,
        category: Optional[ToolCategory] = None,
        include_disabled: bool = False
    ) -> List[Dict[str, Any]]:
        """List tools with summary info"""
        tools = []
        
        for tool in self._tools.values():
            if category and tool.metadata.category != category:
                continue
            
            if not include_disabled and tool.metadata.status != ToolStatus.AVAILABLE:
                continue
            
            tools.append({
                "name": tool.metadata.name,
                "description": tool.metadata.description,
                "category": tool.metadata.category.value,
                "risk": tool.metadata.risk.value,
                "status": tool.metadata.status.value,
                "use_count": tool.metadata.use_count
            })
        
        return sorted(tools, key=lambda x: x["name"])
    
    def list_categories(self) -> Dict[str, int]:
        """List categories with tool counts"""
        return {
            cat.value: len(tools)
            for cat, tools in self._by_category.items()
        }
    
    def get_tool_help(self, name: str) -> Optional[str]:
        """Get help text for a tool"""
        tool = self.get(name)
        if not tool:
            return None
        
        meta = tool.metadata
        
        lines = [
            f"📦 {meta.name}",
            f"",
            f"{meta.description}",
            f"",
            f"Category: {meta.category.value}",
            f"Risk Level: {meta.risk.value}",
            f"Status: {meta.status.value}",
        ]
        
        if meta.parameters:
            lines.append("")
            lines.append("Parameters:")
            for param in meta.parameters:
                req = "required" if param.required else "optional"
                default = f", default: {param.default}" if param.default is not None else ""
                lines.append(f"  • {param.name} ({param.type}, {req}{default})")
                lines.append(f"    {param.description}")
        
        if meta.usage_examples:
            lines.append("")
            lines.append("Examples:")
            for example in meta.usage_examples:
                lines.append(f"  {example}")
        
        if meta.notes:
            lines.append("")
            lines.append(f"Notes: {meta.notes}")
        
        return "\n".join(lines)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get registry statistics"""
        return {
            **self._stats,
            "categories": len(self._by_category),
            "blocked_tools": len(self._blocked_tools),
            "permissions": len(self._permissions)
        }


# ═══════════════════════════════════════════════════════════════════════════════
# DECORATORS
# ═══════════════════════════════════════════════════════════════════════════════

def tool(
    name: Optional[str] = None,
    description: str = "",
    category: ToolCategory = ToolCategory.UTILITY,
    risk: ToolRisk = ToolRisk.LOW,
    **kwargs
):
    """Decorator to mark a function as a tool"""
    def decorator(func):
        func._tool_metadata = {
            "name": name or func.__name__,
            "description": description or func.__doc__ or "",
            "category": category,
            "risk": risk,
            **kwargs
        }
        return func
    return decorator


# ═══════════════════════════════════════════════════════════════════════════════
# GLOBAL REGISTRY
# ═══════════════════════════════════════════════════════════════════════════════

_global_registry: Optional[ToolRegistry] = None


def get_registry() -> ToolRegistry:
    """Get global tool registry"""
    global _global_registry
    if _global_registry is None:
        _global_registry = ToolRegistry()
    return _global_registry


async def create_registry(config: Optional[RegistryConfig] = None) -> ToolRegistry:
    """Create and configure tool registry"""
    global _global_registry
    _global_registry = ToolRegistry(config)
    return _global_registry