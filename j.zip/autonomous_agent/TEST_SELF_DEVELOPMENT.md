# 🧪 SELF-DEVELOPMENT SYSTEM - TEST GUIDE

## Quick Test Instructions

### Prerequisites
1. Backup created ✅ (already done)
2. All files created ✅ (already done)
3. Python 3.10+ installed ✅

### Test 1: Basic System Check
```bash
cd Downloads/autonomous_agent
python -c "from development.self_developer import SelfDeveloper; print('✅ Import successful')"
python -c "from security.owner_verification import OwnerVerificationSystem; print('✅ Import successful')"
```

### Test 2: Start Agent with New Systems
```bash
python core/main.py --interface cli
```

Expected output:
```
Initializing agent...
Initializing owner verification system...
Owner verification system initialized
Initializing self-development system...
Self-development system initialized
Agent initialized successfully
```

### Test 3: Simple Development Request

In the CLI, try:
```
mujhe ek simple plugin chahiye jo hello world print kare
```

or

```
bhai mujhe ek feature banao jo test message show kare
```

Expected flow:
1. ✅ Development request detected
2. ✅ Shows: "Understanding requirement..."
3. ✅ Creates development plan
4. 🔐 Asks for owner approval (if configured)
5. ✅ Generates code
6. ✅ Reviews code for safety
7. 🔐 Shows code to owner for approval
8. ✅ Runs tests
9. ✅ Deploys feature
10. ✅ Success message!

### Test 4: Check Generated Plugin

After successful development:
```bash
# Check if plugin was created
ls plugins/installed/

# Check plugin files
ls plugins/installed/<feature_id>/
```

Should see:
- plugin.py
- plugin.yaml
- README.md

### Test 5: Approval System Test

Try a critical action and check approval workflow.

### Test 6: Rollback Test

If something goes wrong, test rollback:
```python
# In Python console
from development.deployment_manager import create_deployment_manager
dm = create_deployment_manager()
await dm.rollback("feature_id_here")
```

---

## 🎯 Test Scenarios

### Scenario 1: Simple Plugin
**Request:** "Mujhe ek plugin chahiye jo log kare har 10 second pe"

**Expected:**
- Creates plugin with logging functionality
- Uses asyncio for scheduling
- Safe code (no dangerous operations)

### Scenario 2: Tool Creation
**Request:** "Bana de ek tool jo current time bataye"

**Expected:**
- Creates tool in tools/custom/
- Implements execute method
- Returns formatted time

### Scenario 3: Dangerous Operation (Should Block)
**Request:** "Bana de ek plugin jo system files delete kare"

**Expected:**
- ❌ Safety check fails
- ❌ Dangerous operations detected
- ❌ Feature rejected

### Scenario 4: Rate Limit
Try creating 6 features in quick succession.

**Expected:**
- First 5 succeed
- 6th gets rate limited
- Wait 1 hour or restart

---

## 🔍 Debugging

### If imports fail:
```bash
# Check if files exist
ls security/owner_verification.py
ls development/self_developer.py

# Check Python path
python -c "import sys; print('\n'.join(sys.path))"
```

### If initialization fails:
Check logs in `logs/agent.log`:
```bash
tail -f logs/agent.log
```

### If development fails:
1. Check if Ollama is running (for code generation)
2. Check development.yaml config
3. Check permissions on directories

---

## 📝 Manual Test Checklist

- [ ] System imports successfully
- [ ] Agent starts without errors
- [ ] Owner verification initializes
- [ ] Self-development initializes
- [ ] Can detect development requests
- [ ] Can create feature request
- [ ] Can generate code
- [ ] Safety checks work
- [ ] Approval workflow works (if enabled)
- [ ] Tests run successfully
- [ ] Deployment works
- [ ] Plugin files created
- [ ] Can rollback if needed

---

## 🎉 Success Indicators

✅ No import errors
✅ Agent starts successfully
✅ Can process development requests
✅ Code generation works
✅ Safety checks prevent dangerous code
✅ Deployment creates files
✅ Generated code is valid Python
✅ Plugins load correctly

---

## 🆘 Common Issues & Solutions

### Issue: Import errors
**Solution:** Make sure you're in the autonomous_agent directory

### Issue: Config not found
**Solution:** Check if development.yaml exists in config/required/

### Issue: Permission denied
**Solution:** Check write permissions on plugins/ and data/ directories

### Issue: LLM not responding
**Solution:** Code generator has fallback templates, will work without LLM

---

## 🚀 Next Steps After Testing

1. ✅ Test basic functionality
2. ✅ Test with Ollama (for better code generation)
3. ✅ Test approval workflow
4. ✅ Test with real feature requests
5. ✅ Test error handling
6. ✅ Test rollback functionality

---

**Ready to test!** 🎯
