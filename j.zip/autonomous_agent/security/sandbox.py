"""
═══════════════════════════════════════════════════════════════════════════════════════
SANDBOX - ISOLATED EXECUTION ENVIRONMENT
═══════════════════════════════════════════════════════════════════════════════════════
Provides sandboxed execution for potentially dangerous operations:
- Resource limits (CPU, memory, time)
- Filesystem isolation
- Network restrictions
- Process isolation
- Output capture and sanitization

SAFETY PRINCIPLES:
- Limit blast radius of any operation
- Timeout all operations
- Capture all output for audit
- Clean up after execution
"""

import asyncio
import logging
import os
import signal
import tempfile
import shutil
import subprocess
import resource
import pwd
import grp
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Tuple, Callable, Union
from pathlib import Path
import json
import uuid

logger = logging.getLogger(__name__)


class SandboxType(Enum):
    """Types of sandbox environments."""
    MINIMAL = auto()      # Basic process isolation
    STANDARD = auto()     # Standard isolation with limits
    STRICT = auto()       # Strict isolation, no network
    CONTAINER = auto()    # Docker container isolation
    NONE = auto()         # No sandbox (for trusted operations)


class ExecutionStatus(Enum):
    """Status of sandbox execution."""
    SUCCESS = "success"
    FAILED = "failed"
    TIMEOUT = "timeout"
    KILLED = "killed"
    ERROR = "error"
    RESOURCE_LIMIT = "resource_limit"


@dataclass
class ResourceLimits:
    """Resource limits for sandboxed execution."""
    max_cpu_seconds: int = 30           # CPU time limit
    max_memory_mb: int = 512            # Memory limit in MB
    max_file_size_mb: int = 100         # Max file size
    max_processes: int = 10             # Max child processes
    max_open_files: int = 100           # Max open file descriptors
    timeout_seconds: int = 60           # Wall clock timeout
    max_output_bytes: int = 1024 * 1024 # 1MB output limit
    
    def to_rlimits(self) -> Dict[int, Tuple[int, int]]:
        """Convert to resource.setrlimit format."""
        mb = 1024 * 1024
        return {
            resource.RLIMIT_CPU: (self.max_cpu_seconds, self.max_cpu_seconds + 5),
            resource.RLIMIT_AS: (self.max_memory_mb * mb, self.max_memory_mb * mb),
            resource.RLIMIT_FSIZE: (self.max_file_size_mb * mb, self.max_file_size_mb * mb),
            resource.RLIMIT_NPROC: (self.max_processes, self.max_processes),
            resource.RLIMIT_NOFILE: (self.max_open_files, self.max_open_files),
        }


@dataclass
class SandboxConfig:
    """Configuration for sandbox execution."""
    sandbox_type: SandboxType = SandboxType.STANDARD
    limits: ResourceLimits = field(default_factory=ResourceLimits)
    work_dir: Optional[Path] = None
    allowed_paths: List[Path] = field(default_factory=list)
    environment: Dict[str, str] = field(default_factory=dict)
    network_access: bool = False
    cleanup_after: bool = True
    capture_output: bool = True
    merge_stderr: bool = True


@dataclass
class SandboxResult:
    """Result of sandboxed execution."""
    status: ExecutionStatus
    exit_code: int
    stdout: str
    stderr: str
    execution_time_ms: float
    resources_used: Dict[str, Any] = field(default_factory=dict)
    sandbox_id: str = ""
    command: str = ""
    work_dir: str = ""
    error_message: Optional[str] = None
    truncated: bool = False
    
    def __post_init__(self):
        if not self.sandbox_id:
            self.sandbox_id = str(uuid.uuid4())[:8]
    
    @property
    def success(self) -> bool:
        return self.status == ExecutionStatus.SUCCESS and self.exit_code == 0
    
    @property
    def output(self) -> str:
        """Combined output."""
        if self.stderr:
            return f"{self.stdout}\n--- STDERR ---\n{self.stderr}"
        return self.stdout


class SandboxEnvironment:
    """Manages a sandboxed execution environment."""
    
    def __init__(self, config: SandboxConfig):
        self.config = config
        self.sandbox_id = str(uuid.uuid4())[:8]
        self._work_dir: Optional[Path] = None
        self._cleanup_paths: List[Path] = []
        self._active = False
    
    async def setup(self) -> Path:
        """Setup the sandbox environment."""
        # Create temporary work directory
        if self.config.work_dir:
            self._work_dir = self.config.work_dir
            self._work_dir.mkdir(parents=True, exist_ok=True)
        else:
            self._work_dir = Path(tempfile.mkdtemp(prefix=f"sandbox_{self.sandbox_id}_"))
            self._cleanup_paths.append(self._work_dir)
        
        # Setup restricted environment variables
        self._setup_environment()
        
        self._active = True
        logger.debug(f"Sandbox {self.sandbox_id} setup at {self._work_dir}")
        
        return self._work_dir
    
    def _setup_environment(self) -> None:
        """Setup restricted environment variables."""
        # Start with minimal environment
        safe_env = {
            "PATH": "/usr/local/bin:/usr/bin:/bin",
            "HOME": str(self._work_dir),
            "TMPDIR": str(self._work_dir),
            "LANG": "C.UTF-8",
            "LC_ALL": "C.UTF-8",
        }
        
        # Add user-specified environment
        safe_env.update(self.config.environment)
        
        # Remove potentially dangerous variables
        dangerous_vars = ["LD_PRELOAD", "LD_LIBRARY_PATH", "PYTHONPATH"]
        for var in dangerous_vars:
            safe_env.pop(var, None)
        
        self.environment = safe_env
    
    async def cleanup(self) -> None:
        """Cleanup sandbox environment."""
        if not self.config.cleanup_after:
            return
        
        for path in self._cleanup_paths:
            try:
                if path.exists():
                    if path.is_dir():
                        shutil.rmtree(path)
                    else:
                        path.unlink()
            except Exception as e:
                logger.warning(f"Failed to cleanup {path}: {e}")
        
        self._active = False
        logger.debug(f"Sandbox {self.sandbox_id} cleaned up")
    
    @property
    def work_dir(self) -> Path:
        """Get the work directory."""
        if not self._work_dir:
            raise RuntimeError("Sandbox not setup")
        return self._work_dir
    
    @property
    def is_active(self) -> bool:
        return self._active


class ProcessSandbox:
    """Executes commands in a sandboxed process."""
    
    def __init__(self, environment: SandboxEnvironment):
        self.environment = environment
        self.config = environment.config
    
    async def execute(
        self,
        command: Union[str, List[str]],
        input_data: Optional[str] = None
    ) -> SandboxResult:
        """Execute a command in the sandbox."""
        start_time = datetime.now()
        
        # Ensure sandbox is setup
        if not self.environment.is_active:
            await self.environment.setup()
        
        # Prepare command
        if isinstance(command, str):
            shell = True
            cmd = command
        else:
            shell = False
            cmd = command
        
        # Build result
        result = SandboxResult(
            status=ExecutionStatus.ERROR,
            exit_code=-1,
            stdout="",
            stderr="",
            execution_time_ms=0,
            command=str(cmd),
            work_dir=str(self.environment.work_dir)
        )
        
        try:
            # Create process with limits
            process = await self._create_process(cmd, shell, input_data)
            
            # Wait for completion with timeout
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(
                        input=input_data.encode() if input_data else None
                    ),
                    timeout=self.config.limits.timeout_seconds
                )
                
                # Decode output
                result.stdout = self._sanitize_output(
                    stdout.decode('utf-8', errors='replace')
                )
                result.stderr = self._sanitize_output(
                    stderr.decode('utf-8', errors='replace')
                )
                
                result.exit_code = process.returncode
                result.status = (
                    ExecutionStatus.SUCCESS 
                    if process.returncode == 0 
                    else ExecutionStatus.FAILED
                )
                
            except asyncio.TimeoutError:
                # Kill the process
                process.kill()
                await process.wait()
                result.status = ExecutionStatus.TIMEOUT
                result.error_message = f"Timeout after {self.config.limits.timeout_seconds}s"
                logger.warning(f"Sandbox command timed out: {cmd[:100]}")
            
        except Exception as e:
            result.status = ExecutionStatus.ERROR
            result.error_message = str(e)
            logger.error(f"Sandbox execution error: {e}")
        
        # Calculate execution time
        result.execution_time_ms = (datetime.now() - start_time).total_seconds() * 1000
        
        return result
    
    async def _create_process(
        self,
        command: Union[str, List[str]],
        shell: bool,
        input_data: Optional[str]
    ) -> asyncio.subprocess.Process:
        """Create sandboxed subprocess."""
        
        # Prepare preexec function for resource limits
        def set_limits():
            try:
                for limit_type, (soft, hard) in self.config.limits.to_rlimits().items():
                    try:
                        resource.setrlimit(limit_type, (soft, hard))
                    except (ValueError, resource.error):
                        pass  # Some limits might not be supported
            except Exception as e:
                logger.warning(f"Failed to set resource limits: {e}")
        
        # Create process
        process = await asyncio.create_subprocess_shell(
            command if shell else " ".join(command),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE if not self.config.merge_stderr else asyncio.subprocess.STDOUT,
            stdin=asyncio.subprocess.PIPE if input_data else None,
            cwd=str(self.environment.work_dir),
            env=self.environment.environment,
            preexec_fn=set_limits if os.name != 'nt' else None
        )
        
        return process
    
    def _sanitize_output(self, output: str) -> str:
        """Sanitize and limit output."""
        max_bytes = self.config.limits.max_output_bytes
        
        if len(output) > max_bytes:
            output = output[:max_bytes] + f"\n... [truncated at {max_bytes} bytes]"
        
        # Remove potential escape sequences that could affect terminal
        # Keep basic ANSI colors but remove cursor movement etc
        import re
        output = re.sub(r'\x1b\[[0-9;]*[HJKsu]', '', output)
        
        return output


class PythonSandbox:
    """Executes Python code in a restricted environment."""
    
    def __init__(self, environment: SandboxEnvironment):
        self.environment = environment
        self.config = environment.config
        
        # Restricted builtins
        self._safe_builtins = {
            'abs': abs, 'all': all, 'any': any, 'ascii': ascii,
            'bin': bin, 'bool': bool, 'bytearray': bytearray, 'bytes': bytes,
            'callable': callable, 'chr': chr, 'dict': dict, 'dir': dir,
            'divmod': divmod, 'enumerate': enumerate, 'filter': filter,
            'float': float, 'format': format, 'frozenset': frozenset,
            'hash': hash, 'hex': hex, 'int': int, 'isinstance': isinstance,
            'issubclass': issubclass, 'iter': iter, 'len': len, 'list': list,
            'map': map, 'max': max, 'min': min, 'next': next, 'oct': oct,
            'ord': ord, 'pow': pow, 'print': print, 'range': range,
            'repr': repr, 'reversed': reversed, 'round': round, 'set': set,
            'slice': slice, 'sorted': sorted, 'str': str, 'sum': sum,
            'tuple': tuple, 'type': type, 'zip': zip,
            'True': True, 'False': False, 'None': None,
        }
        
        # Blocked modules
        self._blocked_modules = {
            'os', 'sys', 'subprocess', 'shutil', 'socket', 'urllib',
            'requests', 'http', 'ftplib', 'smtplib', 'telnetlib',
            'importlib', 'ctypes', 'multiprocessing', 'threading',
            '__builtins__', 'builtins',
        }
    
    async def execute(
        self,
        code: str,
        globals_dict: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None
    ) -> SandboxResult:
        """Execute Python code in sandbox."""
        start_time = datetime.now()
        timeout = timeout or self.config.limits.timeout_seconds
        
        result = SandboxResult(
            status=ExecutionStatus.ERROR,
            exit_code=-1,
            stdout="",
            stderr="",
            execution_time_ms=0,
            command=f"python: {code[:100]}...",
            work_dir=str(self.environment.work_dir)
        )
        
        # Validate code
        validation = self._validate_code(code)
        if not validation[0]:
            result.error_message = validation[1]
            return result
        
        # Setup restricted globals
        safe_globals = globals_dict.copy() if globals_dict else {}
        safe_globals['__builtins__'] = self._safe_builtins
        
        # Capture output
        output_buffer = []
        
        def safe_print(*args, **kwargs):
            output_buffer.append(' '.join(str(a) for a in args))
        
        safe_globals['print'] = safe_print
        
        try:
            # Execute with timeout
            def run_code():
                exec(compile(code, '<sandbox>', 'exec'), safe_globals)
            
            # Run in thread pool with timeout
            loop = asyncio.get_event_loop()
            await asyncio.wait_for(
                loop.run_in_executor(None, run_code),
                timeout=timeout
            )
            
            result.stdout = '\n'.join(output_buffer)
            result.exit_code = 0
            result.status = ExecutionStatus.SUCCESS
            
        except asyncio.TimeoutError:
            result.status = ExecutionStatus.TIMEOUT
            result.error_message = f"Timeout after {timeout}s"
            
        except Exception as e:
            result.status = ExecutionStatus.FAILED
            result.stderr = str(e)
            result.error_message = str(e)
        
        result.execution_time_ms = (datetime.now() - start_time).total_seconds() * 1000
        return result
    
    def _validate_code(self, code: str) -> Tuple[bool, str]:
        """Validate Python code for dangerous constructs."""
        import ast
        
        try:
            tree = ast.parse(code)
        except SyntaxError as e:
            return False, f"Syntax error: {e}"
        
        # Check for dangerous imports
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name.split('.')[0] in self._blocked_modules:
                        return False, f"Blocked import: {alias.name}"
            
            elif isinstance(node, ast.ImportFrom):
                if node.module and node.module.split('.')[0] in self._blocked_modules:
                    return False, f"Blocked import: {node.module}"
            
            # Check for dangerous function calls
            elif isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name):
                    if node.func.id in ['exec', 'eval', 'compile', 'open', '__import__']:
                        return False, f"Blocked function: {node.func.id}"
                
                elif isinstance(node.func, ast.Attribute):
                    # Block getattr, setattr for security
                    if node.func.attr in ['__getattr__', '__setattr__', '__delattr__']:
                        return False, f"Blocked attribute access"
        
        return True, ""


class Sandbox:
    """
    Main sandbox class providing unified interface.
    
    Usage:
        async with Sandbox() as sandbox:
            result = await sandbox.execute("ls -la")
    """
    
    def __init__(
        self,
        config: Optional[SandboxConfig] = None,
        sandbox_type: SandboxType = SandboxType.STANDARD
    ):
        if config:
            self.config = config
        else:
            self.config = SandboxConfig(sandbox_type=sandbox_type)
        
        self.environment: Optional[SandboxEnvironment] = None
        self.process_sandbox: Optional[ProcessSandbox] = None
        self.python_sandbox: Optional[PythonSandbox] = None
    
    async def __aenter__(self) -> "Sandbox":
        """Async context manager entry."""
        await self.setup()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.cleanup()
    
    async def setup(self) -> None:
        """Setup the sandbox."""
        self.environment = SandboxEnvironment(self.config)
        await self.environment.setup()
        
        self.process_sandbox = ProcessSandbox(self.environment)
        self.python_sandbox = PythonSandbox(self.environment)
        
        logger.info(f"Sandbox ready: {self.environment.sandbox_id}")
    
    async def cleanup(self) -> None:
        """Cleanup the sandbox."""
        if self.environment:
            await self.environment.cleanup()
    
    async def execute(
        self,
        command: Union[str, List[str]],
        input_data: Optional[str] = None
    ) -> SandboxResult:
        """Execute a shell command in the sandbox."""
        if not self.process_sandbox:
            await self.setup()
        return await self.process_sandbox.execute(command, input_data)
    
    async def execute_python(
        self,
        code: str,
        globals_dict: Optional[Dict[str, Any]] = None
    ) -> SandboxResult:
        """Execute Python code in the sandbox."""
        if not self.python_sandbox:
            await self.setup()
        return await self.python_sandbox.execute(code, globals_dict)
    
    async def write_file(self, filename: str, content: str) -> Path:
        """Write a file in the sandbox work directory."""
        if not self.environment:
            await self.setup()
        
        filepath = self.environment.work_dir / filename
        filepath.write_text(content)
        return filepath
    
    async def read_file(self, filename: str) -> str:
        """Read a file from the sandbox work directory."""
        if not self.environment:
            raise RuntimeError("Sandbox not setup")
        
        filepath = self.environment.work_dir / filename
        return filepath.read_text()
    
    @property
    def work_dir(self) -> Path:
        """Get the sandbox work directory."""
        if not self.environment:
            raise RuntimeError("Sandbox not setup")
        return self.environment.work_dir
    
    @property
    def sandbox_id(self) -> str:
        """Get the sandbox ID."""
        if self.environment:
            return self.environment.sandbox_id
        return "not_initialized"


class SandboxPool:
    """Pool of reusable sandbox environments."""
    
    def __init__(
        self,
        max_size: int = 5,
        default_config: Optional[SandboxConfig] = None
    ):
        self.max_size = max_size
        self.default_config = default_config or SandboxConfig()
        
        self._available: List[Sandbox] = []
        self._in_use: List[Sandbox] = []
        self._lock = asyncio.Lock()
    
    async def acquire(self) -> Sandbox:
        """Acquire a sandbox from the pool."""
        async with self._lock:
            if self._available:
                sandbox = self._available.pop()
            else:
                if len(self._in_use) >= self.max_size:
                    raise RuntimeError("Sandbox pool exhausted")
                sandbox = Sandbox(self.default_config)
                await sandbox.setup()
            
            self._in_use.append(sandbox)
            return sandbox
    
    async def release(self, sandbox: Sandbox) -> None:
        """Release a sandbox back to the pool."""
        async with self._lock:
            if sandbox in self._in_use:
                self._in_use.remove(sandbox)
                
                # Clean up the sandbox for reuse
                if sandbox.environment:
                    # Clear work directory
                    work_dir = sandbox.environment.work_dir
                    for item in work_dir.iterdir():
                        try:
                            if item.is_dir():
                                shutil.rmtree(item)
                            else:
                                item.unlink()
                        except Exception:
                            pass
                
                self._available.append(sandbox)
    
    async def cleanup_all(self) -> None:
        """Cleanup all sandboxes in the pool."""
        async with self._lock:
            for sandbox in self._available + self._in_use:
                await sandbox.cleanup()
            self._available.clear()
            self._in_use.clear()
    
    @property
    def available_count(self) -> int:
        return len(self._available)
    
    @property
    def in_use_count(self) -> int:
        return len(self._in_use)


# Factory functions
def create_sandbox(
    sandbox_type: SandboxType = SandboxType.STANDARD,
    timeout: int = 60,
    max_memory_mb: int = 512
) -> Sandbox:
    """Create a sandbox with common settings."""
    config = SandboxConfig(
        sandbox_type=sandbox_type,
        limits=ResourceLimits(
            timeout_seconds=timeout,
            max_memory_mb=max_memory_mb
        )
    )
    return Sandbox(config)


def create_strict_sandbox(timeout: int = 30) -> Sandbox:
    """Create a strict sandbox with minimal permissions."""
    config = SandboxConfig(
        sandbox_type=SandboxType.STRICT,
        limits=ResourceLimits(
            timeout_seconds=timeout,
            max_memory_mb=256,
            max_cpu_seconds=10,
            max_processes=5
        ),
        network_access=False,
        cleanup_after=True
    )
    return Sandbox(config)


async def quick_execute(
    command: str,
    timeout: int = 30
) -> SandboxResult:
    """Quick command execution in a temporary sandbox."""
    async with Sandbox(SandboxConfig(
        sandbox_type=SandboxType.MINIMAL,
        limits=ResourceLimits(timeout_seconds=timeout)
    )) as sandbox:
        return await sandbox.execute(command)