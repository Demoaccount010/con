#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 PERMISSION MANAGER
═══════════════════════════════════════════════════════════════════════════════

 Manages permissions for users and actions.
 
 Author: System Engineer
 Version: 1.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import logging
from typing import Optional, Dict, Any, List, Set
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)


class PermissionLevel(Enum):
    """Permission levels."""
    NONE = 0
    READ = 1
    WRITE = 2
    EXECUTE = 3
    ADMIN = 4
    OWNER = 5


@dataclass
class Permission:
    """Permission definition."""
    name: str
    level: PermissionLevel
    description: str = ""
    requires_approval: bool = False
    
    # Constraints
    allowed_actions: Set[str] = field(default_factory=set)
    blocked_actions: Set[str] = field(default_factory=set)


class PermissionManager:
    """Manages permissions for the system."""
    
    def __init__(self):
        """Initialize permission manager."""
        self.logger = logging.getLogger("permission_manager")
        
        # Permission definitions
        self.permissions: Dict[str, Permission] = {}
        
        # User permissions
        self.user_permissions: Dict[str, Set[str]] = {}
        
        # Initialize default permissions
        self._initialize_default_permissions()
    
    def _initialize_default_permissions(self) -> None:
        """Initialize default permission set."""
        # Read permission
        self.add_permission(Permission(
            name="read",
            level=PermissionLevel.READ,
            description="Read-only access",
            requires_approval=False
        ))
        
        # Write permission
        self.add_permission(Permission(
            name="write",
            level=PermissionLevel.WRITE,
            description="Write and modify access",
            requires_approval=True
        ))
        
        # Execute permission
        self.add_permission(Permission(
            name="execute",
            level=PermissionLevel.EXECUTE,
            description="Execute code and commands",
            requires_approval=True
        ))
        
        # Development permission
        self.add_permission(Permission(
            name="develop",
            level=PermissionLevel.ADMIN,
            description="Self-development capabilities",
            requires_approval=True
        ))
        
        # Admin permission
        self.add_permission(Permission(
            name="admin",
            level=PermissionLevel.ADMIN,
            description="Administrative access",
            requires_approval=True
        ))
    
    def add_permission(self, permission: Permission) -> None:
        """Add a permission definition."""
        self.permissions[permission.name] = permission
        self.logger.debug(f"Added permission: {permission.name}")
    
    def grant_permission(self, user_id: str, permission_name: str) -> bool:
        """Grant permission to user."""
        if permission_name not in self.permissions:
            self.logger.error(f"Unknown permission: {permission_name}")
            return False
        
        if user_id not in self.user_permissions:
            self.user_permissions[user_id] = set()
        
        self.user_permissions[user_id].add(permission_name)
        self.logger.info(f"Granted {permission_name} to user {user_id}")
        return True
    
    def revoke_permission(self, user_id: str, permission_name: str) -> bool:
        """Revoke permission from user."""
        if user_id in self.user_permissions:
            self.user_permissions[user_id].discard(permission_name)
            self.logger.info(f"Revoked {permission_name} from user {user_id}")
            return True
        return False
    
    def has_permission(self, user_id: str, permission_name: str) -> bool:
        """Check if user has permission."""
        if user_id not in self.user_permissions:
            return False
        return permission_name in self.user_permissions[user_id]
    
    def get_user_permissions(self, user_id: str) -> List[str]:
        """Get all permissions for user."""
        return list(self.user_permissions.get(user_id, set()))
