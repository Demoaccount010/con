#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 OWNER VERIFICATION SYSTEM
═══════════════════════════════════════════════════════════════════════════════

 Global owner verification and approval system for critical operations.
 
 Features:
 - Owner identity verification
 - Permission level checking
 - Approval request/response system
 - Timeout handling
 - Audit trail logging
 
 Author: System Engineer
 Version: 1.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Callable, Awaitable
from dataclasses import dataclass, field
from enum import Enum
from uuid import uuid4
import json
from pathlib import Path

logger = logging.getLogger(__name__)


class VerificationLevel(Enum):
    """Level of verification required for an action."""
    LOW = 1          # Basic confirmation
    MEDIUM = 2       # Standard approval
    HIGH = 3         # Detailed review required
    CRITICAL = 4     # Maximum scrutiny


class PermissionType(Enum):
    """Types of permissions."""
    READ = "read"              # Read-only access
    WRITE = "write"            # Write/modify access
    EXECUTE = "execute"        # Execute code/commands
    ADMIN = "admin"            # Administrative access
    DEVELOP = "develop"        # Self-development access


class ApprovalStatus(Enum):
    """Status of approval request."""
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"


@dataclass
class ApprovalRequest:
    """Approval request data."""
    id: str = field(default_factory=lambda: str(uuid4()))
    action: str = ""
    description: str = ""
    level: VerificationLevel = VerificationLevel.MEDIUM
    details: Dict[str, Any] = field(default_factory=dict)
    
    # Status
    status: ApprovalStatus = ApprovalStatus.PENDING
    created_at: datetime = field(default_factory=datetime.now)
    expires_at: Optional[datetime] = None
    
    # Response
    responded_at: Optional[datetime] = None
    approved_by: Optional[str] = None
    rejection_reason: Optional[str] = None
    
    # Context
    context: Dict[str, Any] = field(default_factory=dict)
    requires_owner: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "action": self.action,
            "description": self.description,
            "level": self.level.value,
            "status": self.status.value,
            "created_at": self.created_at.isoformat(),
            "details": self.details
        }
    
    def is_expired(self) -> bool:
        """Check if request has expired."""
        if not self.expires_at:
            return False
        return datetime.now() > self.expires_at


@dataclass
class AuditEntry:
    """Audit log entry."""
    id: str = field(default_factory=lambda: str(uuid4()))
    timestamp: datetime = field(default_factory=datetime.now)
    action: str = ""
    user_id: Optional[str] = None
    user_name: Optional[str] = None
    
    # Action details
    action_type: str = ""
    action_details: Dict[str, Any] = field(default_factory=dict)
    
    # Result
    approved: bool = False
    result: Optional[str] = None
    error: Optional[str] = None
    
    # Context
    verification_level: Optional[VerificationLevel] = None
    approval_request_id: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "timestamp": self.timestamp.isoformat(),
            "action": self.action,
            "user_name": self.user_name,
            "action_type": self.action_type,
            "approved": self.approved,
            "result": self.result,
            "verification_level": self.verification_level.value if self.verification_level else None
        }


class OwnerVerificationSystem:
    """
    Global owner verification and approval system.
    
    This system ensures that critical operations require owner approval
    before execution. It maintains an audit trail of all actions.
    """
    
    def __init__(
        self,
        identity_manager: Optional[Any] = None,
        notification_manager: Optional[Any] = None,
        data_dir: Optional[Path] = None
    ):
        """Initialize verification system."""
        self.logger = logging.getLogger("owner_verification")
        
        # Managers
        self.identity_manager = identity_manager
        self.notification_manager = notification_manager
        
        # Data directory
        self.data_dir = data_dir or Path("data/security")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.audit_file = self.data_dir / "audit_log.jsonl"
        
        # Owner info
        self.owner_id: Optional[str] = None
        self.owner_name: Optional[str] = None
        
        # Approval requests
        self.pending_requests: Dict[str, ApprovalRequest] = {}
        self.approval_handlers: List[Callable] = []
        
        # Audit trail
        self.audit_entries: List[AuditEntry] = []
        
        # Settings
        self.default_timeout = timedelta(minutes=5)
        self.auto_reject_on_timeout = True
        
        self.logger.info("Owner verification system initialized")
    
    async def initialize(self) -> None:
        """Initialize the verification system."""
        try:
            # Load owner info from identity manager
            if self.identity_manager:
                owner_identity = await self.identity_manager.get_owner_identity()
                self.owner_id = owner_identity.id
                self.owner_name = owner_identity.name
                self.logger.info(f"Owner loaded: {self.owner_name}")
            
            # Load audit log
            await self._load_audit_log()
            
            self.logger.info("Owner verification system ready")
        except Exception as e:
            self.logger.error(f"Failed to initialize verification system: {e}")
            raise
    
    async def verify_owner_identity(
        self,
        user_id: str,
        context: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        Verify if user is the owner.
        
        Args:
            user_id: User identifier to verify
            context: Additional context for verification
            
        Returns:
            True if user is owner, False otherwise
        """
        try:
            # Check against known owner ID
            if self.owner_id and user_id == self.owner_id:
                return True
            
            # Check via identity manager
            if self.identity_manager:
                owner_identity = await self.identity_manager.get_owner_identity()
                if user_id == owner_identity.id:
                    return True
            
            self.logger.warning(f"Failed owner verification for user: {user_id}")
            return False
            
        except Exception as e:
            self.logger.error(f"Error verifying owner: {e}")
            return False
    
    async def check_permission(
        self,
        user_id: str,
        permission: PermissionType,
        context: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        Check if user has specific permission.
        
        Args:
            user_id: User to check
            permission: Permission type to check
            context: Additional context
            
        Returns:
            True if user has permission, False otherwise
        """
        try:
            # Verify owner first
            is_owner = await self.verify_owner_identity(user_id, context)
            
            if not is_owner:
                self.logger.warning(f"Permission denied for non-owner: {user_id}")
                return False
            
            # Owner has all permissions
            return True
            
        except Exception as e:
            self.logger.error(f"Error checking permission: {e}")
            return False
    
    async def require_approval(
        self,
        action: str,
        level: VerificationLevel,
        details: Optional[Dict[str, Any]] = None,
        timeout: Optional[timedelta] = None,
        description: Optional[str] = None
    ) -> ApprovalRequest:
        """
        Create approval request for an action.
        
        Args:
            action: Action name requiring approval
            level: Verification level required
            details: Action details
            timeout: Custom timeout (default: 5 minutes)
            description: Human-readable description
            
        Returns:
            ApprovalRequest object
        """
        try:
            # Create request
            request = ApprovalRequest(
                action=action,
                description=description or f"Approval required for: {action}",
                level=level,
                details=details or {},
                expires_at=datetime.now() + (timeout or self.default_timeout)
            )
            
            # Store request
            self.pending_requests[request.id] = request
            
            # Send notification to owner
            await self._notify_approval_request(request)
            
            self.logger.info(f"Approval request created: {request.id} for action: {action}")
            
            return request
            
        except Exception as e:
            self.logger.error(f"Error creating approval request: {e}")
            raise
    
    async def wait_for_approval(
        self,
        request_id: str,
        timeout: Optional[timedelta] = None
    ) -> ApprovalStatus:
        """
        Wait for approval response.
        
        Args:
            request_id: Request ID to wait for
            timeout: Custom timeout
            
        Returns:
            Final approval status
        """
        try:
            request = self.pending_requests.get(request_id)
            if not request:
                raise ValueError(f"Request not found: {request_id}")
            
            timeout_seconds = (timeout or self.default_timeout).total_seconds()
            start_time = datetime.now()
            
            # Poll for response
            while True:
                # Check if responded
                if request.status != ApprovalStatus.PENDING:
                    return request.status
                
                # Check if expired
                if request.is_expired():
                    request.status = ApprovalStatus.TIMEOUT
                    if self.auto_reject_on_timeout:
                        await self._log_audit(
                            action=request.action,
                            approved=False,
                            result="Timeout - Auto rejected",
                            request=request
                        )
                    return ApprovalStatus.TIMEOUT
                
                # Check timeout
                elapsed = (datetime.now() - start_time).total_seconds()
                if elapsed > timeout_seconds:
                    request.status = ApprovalStatus.TIMEOUT
                    return ApprovalStatus.TIMEOUT
                
                # Wait before next check
                await asyncio.sleep(1)
                
        except Exception as e:
            self.logger.error(f"Error waiting for approval: {e}")
            raise
    
    async def approve_action(
        self,
        request_id: str,
        approved_by: str,
        comment: Optional[str] = None
    ) -> bool:
        """
        Approve a pending request.
        
        Args:
            request_id: Request ID to approve
            approved_by: User approving the request
            comment: Optional comment
            
        Returns:
            True if approved successfully
        """
        try:
            request = self.pending_requests.get(request_id)
            if not request:
                self.logger.error(f"Request not found: {request_id}")
                return False
            
            # Verify approver is owner
            is_owner = await self.verify_owner_identity(approved_by)
            if not is_owner and request.requires_owner:
                self.logger.error(f"Non-owner tried to approve: {approved_by}")
                return False
            
            # Update request
            request.status = ApprovalStatus.APPROVED
            request.responded_at = datetime.now()
            request.approved_by = approved_by
            
            # Log to audit
            await self._log_audit(
                action=request.action,
                user_id=approved_by,
                user_name=self.owner_name,
                approved=True,
                result="Approved",
                request=request
            )
            
            self.logger.info(f"Request approved: {request_id} by {approved_by}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error approving action: {e}")
            return False
    
    async def reject_action(
        self,
        request_id: str,
        rejected_by: str,
        reason: Optional[str] = None
    ) -> bool:
        """
        Reject a pending request.
        
        Args:
            request_id: Request ID to reject
            rejected_by: User rejecting the request
            reason: Rejection reason
            
        Returns:
            True if rejected successfully
        """
        try:
            request = self.pending_requests.get(request_id)
            if not request:
                self.logger.error(f"Request not found: {request_id}")
                return False
            
            # Verify rejector is owner
            is_owner = await self.verify_owner_identity(rejected_by)
            if not is_owner and request.requires_owner:
                self.logger.error(f"Non-owner tried to reject: {rejected_by}")
                return False
            
            # Update request
            request.status = ApprovalStatus.REJECTED
            request.responded_at = datetime.now()
            request.rejection_reason = reason or "No reason provided"
            
            # Log to audit
            await self._log_audit(
                action=request.action,
                user_id=rejected_by,
                user_name=self.owner_name,
                approved=False,
                result=f"Rejected: {request.rejection_reason}",
                request=request
            )
            
            self.logger.info(f"Request rejected: {request_id} by {rejected_by}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error rejecting action: {e}")
            return False
    
    async def get_pending_requests(
        self,
        include_expired: bool = False
    ) -> List[ApprovalRequest]:
        """
        Get all pending approval requests.
        
        Args:
            include_expired: Include expired requests
            
        Returns:
            List of pending requests
        """
        requests = [
            r for r in self.pending_requests.values()
            if r.status == ApprovalStatus.PENDING
        ]
        
        if not include_expired:
            requests = [r for r in requests if not r.is_expired()]
        
        return requests
    
    async def get_audit_log(
        self,
        limit: Optional[int] = None,
        action_type: Optional[str] = None
    ) -> List[AuditEntry]:
        """
        Get audit log entries.
        
        Args:
            limit: Maximum number of entries to return
            action_type: Filter by action type
            
        Returns:
            List of audit entries
        """
        entries = self.audit_entries
        
        if action_type:
            entries = [e for e in entries if e.action_type == action_type]
        
        # Sort by timestamp (newest first)
        entries = sorted(entries, key=lambda e: e.timestamp, reverse=True)
        
        if limit:
            entries = entries[:limit]
        
        return entries
    
    async def _notify_approval_request(self, request: ApprovalRequest) -> None:
        """Send notification about approval request."""
        try:
            if self.notification_manager:
                await self.notification_manager.send_notification(
                    title="🔐 Approval Required",
                    message=request.description,
                    data={
                        "type": "approval_request",
                        "request_id": request.id,
                        "action": request.action,
                        "level": request.level.value,
                        "details": request.details
                    },
                    priority="high"
                )
        except Exception as e:
            self.logger.error(f"Failed to send approval notification: {e}")
    
    async def _log_audit(
        self,
        action: str,
        approved: bool,
        result: Optional[str] = None,
        user_id: Optional[str] = None,
        user_name: Optional[str] = None,
        request: Optional[ApprovalRequest] = None
    ) -> None:
        """Log action to audit trail."""
        try:
            entry = AuditEntry(
                action=action,
                user_id=user_id or self.owner_id,
                user_name=user_name or self.owner_name,
                action_type=request.action if request else action,
                action_details=request.details if request else {},
                approved=approved,
                result=result,
                verification_level=request.level if request else None,
                approval_request_id=request.id if request else None
            )
            
            self.audit_entries.append(entry)
            
            # Write to file
            await self._write_audit_entry(entry)
            
        except Exception as e:
            self.logger.error(f"Failed to log audit entry: {e}")
    
    async def _write_audit_entry(self, entry: AuditEntry) -> None:
        """Write audit entry to file."""
        try:
            with open(self.audit_file, "a") as f:
                f.write(json.dumps(entry.to_dict()) + "\n")
        except Exception as e:
            self.logger.error(f"Failed to write audit entry: {e}")
    
    async def _load_audit_log(self) -> None:
        """Load audit log from file."""
        try:
            if not self.audit_file.exists():
                return
            
            with open(self.audit_file, "r") as f:
                for line in f:
                    if line.strip():
                        data = json.loads(line)
                        # Just keep count, don't load all into memory
                        pass
            
            self.logger.info("Audit log loaded")
        except Exception as e:
            self.logger.error(f"Failed to load audit log: {e}")


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

async def create_owner_verification_system(
    identity_manager: Optional[Any] = None,
    notification_manager: Optional[Any] = None,
    data_dir: Optional[Path] = None
) -> OwnerVerificationSystem:
    """Create and initialize owner verification system."""
    system = OwnerVerificationSystem(
        identity_manager=identity_manager,
        notification_manager=notification_manager,
        data_dir=data_dir
    )
    await system.initialize()
    return system
