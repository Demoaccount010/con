from pyrogram import Client
from config import API_ID, API_HASH

with Client("session-gen", api_id=API_ID, api_hash=API_HASH) as app:
    print(app.export_session_string())
