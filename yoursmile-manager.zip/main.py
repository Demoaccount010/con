import asyncio, sys
from clients import bot_client, user_client
from pyrogram import filters

if sys.platform.startswith("win"):
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

# BASIC PROOF HANDLER (keep this always)
@bot_client.on_message(filters.all)
async def proof(_, msg):
    print("UPDATE:", msg.chat.id, msg.text)
    await msg.reply("BOT WORKING")

async def main():
    await bot_client.start()
    await user_client.start()
    print("Bot + Userbot running")
    await asyncio.Event().wait()

if __name__ == "__main__":
    asyncio.run(main())
