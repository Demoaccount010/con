from pyrogram import Client
from config import *

bot_client = Client(
    "bot_main_fresh",
    api_id=API_ID,
    api_hash=API_HASH,
    bot_token=BOT_TOKEN
)

user_client = Client(
    "user_main_fresh",
    api_id=API_ID,
    api_hash=API_HASH,
    session_string=USER_SESSION
)
