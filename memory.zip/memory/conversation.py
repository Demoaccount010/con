"""
Conversation Manager
====================
Stores and retrieves chat history.
"""

from datetime import datetime
from typing import List, Dict, Any
from main_agent.memory.db import MemoryDB

class ConversationManager:
    """
    Manages chat history for context-aware responses.
    """
    
    def __init__(self, db: MemoryDB):
        self.db = db
        self.collection = db.get_collection("conversations")
        self.user_collection = db.get_collection("users")
    
    def add_message(self, user_id: int, role: str, content: str):
        """
        Save a message to history.
        
        Args:
            user_id: Telegram User ID
            role: 'user' or 'assistant'
            content: Message text
        """
        if not self.collection:
            return
            
        doc = {
            "user_id": user_id,
            "role": role,
            "content": content,
            "timestamp": datetime.now()
        }
        self.collection.insert_one(doc)
    
    def get_history(self, user_id: int, limit: int = 10) -> List[Dict[str, str]]:
        """
        Get recent chat history for context.
        """
        if not self.collection:
            return []
            
        cursor = self.collection.find(
            {"user_id": user_id}
        ).sort("timestamp", -1).limit(limit)
        
        # Return in chronological order (oldest to newest)
        history = []
        for doc in cursor:
            history.append({"role": doc["role"], "content": doc["content"]})
        
        return history[::-1]
    
    def update_user_profile(self, user_id: int, key: str, value: Any):
        """Save user preference (e.g., name, coding style)."""
        if not self.user_collection:
            return
            
        self.user_collection.update_one(
            {"user_id": user_id},
            {"$set": {key: value, "updated_at": datetime.now()}},
            upsert=True
        )
    
    def get_user_profile(self, user_id: int) -> Dict[str, Any]:
        """Get user details."""
        if not self.user_collection:
            return {}
        return self.user_collection.find_one({"user_id": user_id}) or {}