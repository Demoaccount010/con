"""
Capability Manager - Track what JEEVA can and cannot do
JEEVA ki saari capabilities manage karta hai
"""

import yaml
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional, Callable
import importlib
import sys


class CapabilityManager:
    """
    JEEVA ki capabilities manage karta hai
    - Installed capabilities track karo
    - New capabilities add karo
    - Capability check karo
    - Dynamic capability loading
    - Capability execution
    """

    def __init__(self, config_path: str = "config/capabilities.yaml"):
        self.config_path = Path(config_path)
        self.capabilities = self._load_capabilities()
        
        self.runtime_capabilities = {}
        
        self.execution_history = []
        self.max_history = 100
        
        self.capability_keywords = {
            "file_operations": ["file", "folder", "directory", "read", "write", "create", "delete", "copy", "move"],
            "system_info": ["system", "info", "memory", "cpu", "disk", "process", "ram"],
            "browser_control": ["browser", "firefox", "chrome", "web", "url", "website", "internet"],
            "app_control": ["app", "application", "open", "close", "launch", "start", "program"],
            "code_execution": ["run", "execute", "code", "python", "script", "eval"],
            "self_modification": ["self", "modify", "update", "upgrade", "improve", "change myself"],
            "github_scraper": ["github", "repo", "repository", "git", "clone", "scrape"],
            "pdf_reader": ["pdf", "document", "read pdf"],
            "image_processing": ["image", "picture", "photo", "resize", "convert image"],
            "database": ["database", "db", "sql", "query", "table"],
            "api_calls": ["api", "request", "http", "rest", "endpoint"],
            "email": ["email", "mail", "send email", "smtp"]
        }

    def _load_capabilities(self) -> Dict[str, Any]:
        """Load capabilities from config"""
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    data = yaml.safe_load(f)
                    caps = data.get('capabilities', {})
                    print(f"⚡ Loaded {len(caps)} capabilities from config")
                    return caps
            except Exception as e:
                print(f"⚠️ Could not load capabilities: {e}")
        
        return self._get_default_capabilities()

    def _get_default_capabilities(self) -> Dict[str, Any]:
        """Get default capabilities"""
        return {
            "file_operations": {
                "installed": True,
                "description": "File read, write, create, delete operations",
                "risk_level": "medium",
                "module": "tools.file_tools",
                "class": "FileTools"
            },
            "system_info": {
                "installed": True,
                "description": "Get system information like CPU, memory, disk",
                "risk_level": "low",
                "module": "tools.system_tools",
                "class": "SystemTools"
            },
            "code_execution": {
                "installed": True,
                "description": "Execute Python code safely",
                "risk_level": "critical",
                "requires_permission": True
            },
            "self_modification": {
                "installed": True,
                "description": "Modify own code and add new features",
                "risk_level": "critical",
                "requires_permission": True
            }
        }

    def _save_capabilities(self):
        """Save capabilities to config"""
        try:
            self.config_path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(self.config_path, 'w', encoding='utf-8') as f:
                yaml.dump({'capabilities': self.capabilities}, f, default_flow_style=False)
                
        except Exception as e:
            print(f"⚠️ Could not save capabilities: {e}")

    def check_capability(self, action: str) -> Dict[str, Any]:
        """
        Check if JEEVA can perform this action
        
        Args:
            action: The action to check
            
        Returns:
            Dict with capability info
        """
        action_lower = action.lower()
        
        for cap_name, cap_info in self.capabilities.items():
            if cap_name.lower() in action_lower or action_lower in cap_name.lower():
                if cap_info.get('installed', False):
                    return {
                        "has_capability": True,
                        "capability_name": cap_name,
                        "description": cap_info.get('description', ''),
                        "risk_level": cap_info.get('risk_level', 'medium'),
                        "requires_permission": cap_info.get('requires_permission', False)
                    }
                else:
                    return {
                        "has_capability": False,
                        "capability_name": cap_name,
                        "can_be_built": cap_info.get('can_be_built', True),
                        "description": cap_info.get('description', ''),
                        "reason": f"Capability '{cap_name}' is not installed"
                    }
        
        for cap_name, cap_info in self.runtime_capabilities.items():
            if cap_name.lower() in action_lower:
                return {
                    "has_capability": True,
                    "capability_name": cap_name,
                    "is_runtime": True,
                    "description": cap_info.get('description', '')
                }
        
        matched_cap = self._match_by_keywords(action_lower)
        if matched_cap:
            cap_info = self.capabilities.get(matched_cap, {})
            if cap_info.get('installed', False):
                return {
                    "has_capability": True,
                    "capability_name": matched_cap,
                    "matched_by": "keywords",
                    "description": cap_info.get('description', ''),
                    "risk_level": cap_info.get('risk_level', 'medium')
                }
            else:
                return {
                    "has_capability": False,
                    "capability_name": matched_cap,
                    "can_be_built": cap_info.get('can_be_built', True),
                    "description": cap_info.get('description', ''),
                    "reason": f"Capability '{matched_cap}' is not installed"
                }
        
        return {
            "has_capability": False,
            "capability_name": "unknown",
            "can_be_built": True,
            "description": f"No matching capability for: {action}",
            "reason": "No matching capability found"
        }

    def _match_by_keywords(self, action: str) -> Optional[str]:
        """Match action to capability by keywords"""
        action_words = set(action.split())
        best_match = None
        best_score = 0
        
        for cap_name, keywords in self.capability_keywords.items():
            score = 0
            for keyword in keywords:
                if keyword in action:
                    score += 1
                if keyword in action_words:
                    score += 0.5
            
            if score > best_score:
                best_score = score
                best_match = cap_name
        
        return best_match if best_score >= 1 else None

    def add_capability(
        self,
        name: str,
        description: str,
        implementation: Callable = None,
        risk_level: str = "medium",
        module_path: str = None,
        class_name: str = None,
        keywords: List[str] = None
    ) -> Dict[str, Any]:
        """
        New capability add karo
        
        Args:
            name: Capability name
            description: What it does
            implementation: Optional callable implementation
            risk_level: low/medium/high/critical
            module_path: Path to module (e.g., 'tools.file_tools')
            class_name: Class name in module
            keywords: Keywords for matching
            
        Returns:
            Dict with result
        """
        cap_data = {
            "installed": True,
            "description": description,
            "risk_level": risk_level,
            "added_at": datetime.now().isoformat(),
            "can_be_built": True
        }
        
        if module_path:
            cap_data["module"] = module_path
        if class_name:
            cap_data["class"] = class_name
        
        self.capabilities[name] = cap_data
        
        if implementation:
            self.runtime_capabilities[name] = {
                "description": description,
                "implementation": implementation,
                "added_at": datetime.now().isoformat()
            }
        
        if keywords:
            self.capability_keywords[name] = keywords
        
        self._save_capabilities()
        
        return {
            "success": True,
            "message": f"Capability '{name}' added successfully!",
            "capability": cap_data
        }

    def remove_capability(self, name: str) -> Dict[str, Any]:
        """
        Remove a capability
        
        Args:
            name: Capability name to remove
            
        Returns:
            Dict with result
        """
        if name in self.capabilities:
            self.capabilities[name]["installed"] = False
            self.capabilities[name]["removed_at"] = datetime.now().isoformat()
            self._save_capabilities()
            
            if name in self.runtime_capabilities:
                del self.runtime_capabilities[name]
            
            return {"success": True, "message": f"Capability '{name}' removed"}
        
        return {"success": False, "error": f"Capability '{name}' not found"}

    def enable_capability(self, name: str) -> Dict[str, Any]:
        """Enable a disabled capability"""
        if name in self.capabilities:
            self.capabilities[name]["installed"] = True
            self.capabilities[name]["enabled_at"] = datetime.now().isoformat()
            self._save_capabilities()
            return {"success": True, "message": f"Capability '{name}' enabled"}
        
        return {"success": False, "error": f"Capability '{name}' not found"}

    def disable_capability(self, name: str) -> Dict[str, Any]:
        """Disable a capability"""
        if name in self.capabilities:
            self.capabilities[name]["installed"] = False
            self.capabilities[name]["disabled_at"] = datetime.now().isoformat()
            self._save_capabilities()
            return {"success": True, "message": f"Capability '{name}' disabled"}
        
        return {"success": False, "error": f"Capability '{name}' not found"}

    def list_capabilities(self, installed_only: bool = False) -> List[Dict[str, Any]]:
        """
        List all capabilities
        
        Args:
            installed_only: If True, only show installed capabilities
            
        Returns:
            List of capability info dicts
        """
        result = []
        
        for name, info in self.capabilities.items():
            if installed_only and not info.get('installed', False):
                continue
            
            result.append({
                "name": name,
                "installed": info.get('installed', False),
                "description": info.get('description', ''),
                "risk_level": info.get('risk_level', 'medium'),
                "can_be_built": info.get('can_be_built', True),
                "has_runtime": name in self.runtime_capabilities
            })
        
        for name, info in self.runtime_capabilities.items():
            if name not in self.capabilities:
                result.append({
                    "name": name,
                    "installed": True,
                    "description": info.get('description', ''),
                    "risk_level": "medium",
                    "is_runtime_only": True
                })
        
        return result

    def get_capability_info(self, name: str) -> Optional[Dict[str, Any]]:
        """Get detailed info about a capability"""
        if name in self.capabilities:
            info = self.capabilities[name].copy()
            info["name"] = name
            info["has_runtime"] = name in self.runtime_capabilities
            return info
        
        if name in self.runtime_capabilities:
            info = self.runtime_capabilities[name].copy()
            info["name"] = name
            info["is_runtime_only"] = True
            if "implementation" in info:
                del info["implementation"]
            return info
        
        return None

    def load_capability_module(self, name: str) -> Dict[str, Any]:
        """
        Load capability module dynamically
        
        Args:
            name: Capability name
            
        Returns:
            Dict with loaded module/class or error
        """
        if name not in self.capabilities:
            return {"success": False, "error": f"Capability '{name}' not found"}
        
        cap_info = self.capabilities[name]
        module_path = cap_info.get("module")
        class_name = cap_info.get("class")
        
        if not module_path:
            return {"success": False, "error": "No module path specified"}
        
        try:
            module = importlib.import_module(module_path)
            
            if class_name:
                if hasattr(module, class_name):
                    cls = getattr(module, class_name)
                    instance = cls()
                    
                    self.runtime_capabilities[name] = {
                        "description": cap_info.get("description", ""),
                        "implementation": instance,
                        "module": module,
                        "class": cls
                    }
                    
                    return {
                        "success": True,
                        "module": module,
                        "class": cls,
                        "instance": instance
                    }
                else:
                    return {"success": False, "error": f"Class '{class_name}' not found in module"}
            else:
                return {"success": True, "module": module}
                
        except ImportError as e:
            return {"success": False, "error": f"Could not import module: {e}"}
        except Exception as e:
            return {"success": False, "error": f"Error loading capability: {e}"}

    def execute_capability(
        self,
        name: str,
        method: str = None,
        *args,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Execute a capability
        
        Args:
            name: Capability name
            method: Method to call (optional)
            *args: Positional arguments
            **kwargs: Keyword arguments
            
        Returns:
            Dict with execution result
        """
        if name not in self.runtime_capabilities:
            load_result = self.load_capability_module(name)
            if not load_result.get("success"):
                return load_result
        
        if name not in self.runtime_capabilities:
            return {"success": False, "error": f"Capability '{name}' not loaded"}
        
        cap = self.runtime_capabilities[name]
        impl = cap.get("implementation")
        
        if impl is None:
            return {"success": False, "error": "No implementation available"}
        
        try:
            if callable(impl) and not method:
                result = impl(*args, **kwargs)
            elif method and hasattr(impl, method):
                func = getattr(impl, method)
                result = func(*args, **kwargs)
            else:
                return {"success": False, "error": f"Method '{method}' not found"}
            
            self._add_execution_history(name, method, True)
            
            return {"success": True, "result": result}
            
        except Exception as e:
            self._add_execution_history(name, method, False, str(e))
            return {"success": False, "error": str(e)}

    def _add_execution_history(
        self,
        capability: str,
        method: str,
        success: bool,
        error: str = None
    ):
        """Add to execution history"""
        entry = {
            "capability": capability,
            "method": method,
            "success": success,
            "timestamp": datetime.now().isoformat()
        }
        
        if error:
            entry["error"] = error
        
        self.execution_history.append(entry)
        
        if len(self.execution_history) > self.max_history:
            self.execution_history = self.execution_history[-self.max_history:]

    def get_capability_for_action(self, action: str) -> Optional[str]:
        """
        Get the best capability name for an action
        
        Args:
            action: The action description
            
        Returns:
            Capability name or None
        """
        check_result = self.check_capability(action)
        
        if check_result.get("has_capability"):
            return check_result.get("capability_name")
        
        return None

    def get_buildable_capabilities(self) -> List[Dict[str, Any]]:
        """Get list of capabilities that can be built but are not installed"""
        buildable = []
        
        for name, info in self.capabilities.items():
            if not info.get('installed', False) and info.get('can_be_built', True):
                buildable.append({
                    "name": name,
                    "description": info.get('description', ''),
                    "risk_level": info.get('risk_level', 'medium')
                })
        
        return buildable

    def get_execution_history(self, limit: int = 20) -> List[Dict]:
        """Get execution history"""
        return self.execution_history[-limit:]

    def get_stats(self) -> Dict[str, Any]:
        """Get capability statistics"""
        installed = sum(1 for c in self.capabilities.values() if c.get('installed', False))
        total = len(self.capabilities)
        runtime = len(self.runtime_capabilities)
        
        executions = len(self.execution_history)
        successful = sum(1 for e in self.execution_history if e.get('success', False))
        
        return {
            "total_defined": total,
            "installed": installed,
            "not_installed": total - installed,
            "runtime_loaded": runtime,
            "total_executions": executions,
            "successful_executions": successful,
            "failed_executions": executions - successful,
            "success_rate": round(successful / executions * 100, 1) if executions > 0 else 0
        }

    def search_capabilities(self, query: str) -> List[Dict[str, Any]]:
        """
        Search capabilities by query
        
        Args:
            query: Search query
            
        Returns:
            List of matching capabilities
        """
        query_lower = query.lower()
        results = []
        
        for name, info in self.capabilities.items():
            score = 0
            
            if query_lower in name.lower():
                score += 2
            
            if query_lower in info.get('description', '').lower():
                score += 1
            
            keywords = self.capability_keywords.get(name, [])
            for kw in keywords:
                if kw in query_lower or query_lower in kw:
                    score += 0.5
            
            if score > 0:
                results.append({
                    "name": name,
                    "description": info.get('description', ''),
                    "installed": info.get('installed', False),
                    "score": score
                })
        
        results.sort(key=lambda x: x['score'], reverse=True)
        
        return results

    def export_capabilities(self, file_path: str) -> Dict[str, Any]:
        """Export capabilities to file"""
        try:
            export_data = {
                "capabilities": self.capabilities,
                "keywords": self.capability_keywords,
                "exported_at": datetime.now().isoformat()
            }
            
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=2, ensure_ascii=False)
            
            return {"success": True, "file": file_path}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def import_capabilities(self, file_path: str) -> Dict[str, Any]:
        """Import capabilities from file"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            imported_count = 0
            
            for name, info in data.get("capabilities", {}).items():
                if name not in self.capabilities:
                    self.capabilities[name] = info
                    imported_count += 1
            
            for name, keywords in data.get("keywords", {}).items():
                if name not in self.capability_keywords:
                    self.capability_keywords[name] = keywords
            
            self._save_capabilities()
            
            return {"success": True, "imported": imported_count}
        except Exception as e:
            return {"success": False, "error": str(e)}