#!/usr/bin/env python3
"""
JEEVA - Self-Developing AI Agent
Main Entry Point

Usage:
    python main.py
    python main.py --restored  (after restart)
"""

import os
import sys
from pathlib import Path
from datetime import datetime

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.markdown import Markdown
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False

try:
    from prompt_toolkit import prompt as pt_prompt
    from prompt_toolkit.history import FileHistory
    PROMPT_TOOLKIT_AVAILABLE = True
except ImportError:
    PROMPT_TOOLKIT_AVAILABLE = False

sys.path.insert(0, str(Path(__file__).parent))

from core.brain import Brain
from learning.memory_manager import MemoryManager
from learning.self_learner import SelfLearner
from capabilities.capability_manager import CapabilityManager
from self_development.code_modifier import CodeModifier
from self_development.code_generator import CodeGenerator
from self_development.error_checker import ErrorChecker
from security.permission_manager import PermissionManager
from tools.file_tools import FileTools
from tools.system_tools import SystemTools


if RICH_AVAILABLE:
    console = Console()
else:
    class SimpleConsole:
        def print(self, *args, **kwargs):
            text = str(args[0]) if args else ""
            text = text.replace("[bold cyan]", "").replace("[/bold cyan]", "")
            text = text.replace("[green]", "").replace("[/green]", "")
            text = text.replace("[red]", "").replace("[/red]", "")
            text = text.replace("[yellow]", "").replace("[/yellow]", "")
            text = text.replace("[dim]", "").replace("[/dim]", "")
            print(text)
    console = SimpleConsole()


class JEEVA:
    """
    Main JEEVA Agent Class
    """

    def __init__(self):
        self._print_banner()
        
        console.print("[dim]Initializing systems...[/dim]\n")
        
        self.brain = Brain()
        self.memory = MemoryManager()
        self.learner = SelfLearner(self.memory)
        self.capabilities = CapabilityManager()
        self.code_modifier = CodeModifier()
        self.code_generator = CodeGenerator(self.brain.thinking_engine)
        self.error_checker = ErrorChecker()
        self.permissions = PermissionManager()
        self.file_tools = FileTools()
        self.system_tools = SystemTools()
        
        self.permissions.authenticate_owner()
        
        self.brain.start()
        
        self.running = True
        self.session_start = datetime.now()
        
        console.print("[green]✅ All systems initialized![/green]\n")

    def _print_banner(self):
        """Print welcome banner"""
        banner = """
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║        🤖 JEEVA - Self-Developing AI Agent 🤖             ║
║                                                           ║
║   Just Enough Intelligent Virtual Assistant               ║
║   Version 1.0.0                                           ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
"""
        console.print(banner, style="bold cyan" if RICH_AVAILABLE else None)

    def process_input(self, user_input: str) -> str:
        """Process user input and return response"""
        user_input = user_input.strip()
        
        if not user_input:
            return ""
        
        self.memory.add_to_conversation("user", user_input)
        
        if user_input.lower() in ['exit', 'quit', 'bye', 'band karo', 'goodbye']:
            self.running = False
            return "👋 Bye bhai! Take care! Phir milenge!"
        
        if user_input.lower() in ['yes', 'haan', 'han', 'ha', 'y', 'ok', 'okay', 'theek', 'thik']:
            response = self.brain.confirm_action(True)
            self.memory.add_to_conversation("assistant", response)
            return response
        
        if user_input.lower() in ['no', 'nahi', 'nhi', 'n', 'na', 'cancel', 'mat']:
            response = self.brain.confirm_action(False)
            self.memory.add_to_conversation("assistant", response)
            return response
        
        if user_input.lower() == 'status':
            return self._get_status()
        
        if user_input.lower() == 'capabilities':
            return self._list_capabilities()
        
        if user_input.lower() == 'memory':
            return self._get_memory_stats()
        
        if user_input.lower() == 'help':
            return self._get_help()
        
        if user_input.lower() == 'history':
            return self._get_conversation_history()
        
        if user_input.lower().startswith('learn:'):
            learning = user_input[6:].strip()
            self.memory.remember_fact(learning, source="user_taught")
            return "✅ Seekh liya bhai! Yaad rakhunga."
        
        response = self.brain.process(user_input)
        
        self.learner.learn_from_interaction(
            user_input=user_input,
            agent_response=response,
            was_successful=True,
            intent_type=None
        )
        
        self.memory.add_to_conversation("assistant", response)
        
        return response

    def _get_status(self) -> str:
        """Get system status"""
        brain_status = self.brain.consciousness.get_introspection_report()
        memory_stats = self.memory.get_memory_stats()
        learning_stats = self.learner.get_learning_stats()
        uptime = datetime.now() - self.session_start
        
        status = f"""
📊 **JEEVA Status**
{'═' * 40}

🧠 **Brain:**
   Status: {brain_status['current_state']['status']}
   Thinking: {'Yes' if brain_status['current_state']['thinking'] else 'No'}

💾 **Memory:**
   Short-term items: {memory_stats['short_term_count']}
   Long-term facts: {memory_stats['long_term_facts']}
   Conversation length: {memory_stats['conversation_length']}

📚 **Learning:**
   Successful patterns: {learning_stats['successful_patterns']}
   Failed patterns: {learning_stats['failed_patterns']}
   User corrections: {learning_stats['user_corrections']}

⚡ **Capabilities:**
   Installed: {len(self.capabilities.list_capabilities(installed_only=True))}
   Total defined: {len(self.capabilities.list_capabilities())}

⏱️ **Session Uptime:** {str(uptime).split('.')[0]}
"""
        return status

    def _list_capabilities(self) -> str:
        """List all capabilities"""
        caps = self.capabilities.list_capabilities()
        
        result = "📋 **Capabilities:**\n\n"
        
        installed = [c for c in caps if c['installed']]
        not_installed = [c for c in caps if not c['installed']]
        
        if installed:
            result += "**Installed:**\n"
            for cap in installed:
                result += f"   ✅ {cap['name']}: {cap['description'][:50]}...\n"
        
        if not_installed:
            result += "\n**Available to Build:**\n"
            for cap in not_installed:
                result += f"   🔨 {cap['name']}: {cap['description'][:50]}...\n"
        
        return result

    def _get_memory_stats(self) -> str:
        """Get memory statistics"""
        stats = self.memory.get_memory_stats()
        
        return f"""
💾 **Memory Statistics:**
{'═' * 40}

📌 Short-term: {stats['short_term_count']} items
📚 Long-term facts: {stats['long_term_facts']}
🔄 Patterns learned: {stats['long_term_patterns']}
🎯 Skills learned: {stats['learned_skills']}
💬 Current conversation: {stats['conversation_length']} messages
👤 User info keys: {len(stats.get('user_info_keys', []))}
"""

    def _get_help(self) -> str:
        """Get help text"""
        return """
🆘 **JEEVA Help**
{'═' * 40}

**Special Commands:**
   • `status` - System status dekho
   • `capabilities` - Available capabilities dekho
   • `memory` - Memory stats dekho
   • `history` - Conversation history dekho
   • `help` - Ye help message
   • `exit/bye` - JEEVA band karo

**Learning:**
   • `learn: <fact>` - Mujhe kuch sikhao

**Permissions:**
   • `haan/yes` - Permission do
   • `nahi/no` - Permission deny karo

**Kuch Bhi Pucho:**
   • Sawaal pucho
   • Kaam batao
   • Code likhwao
   • Naya feature banwao
   • System info lo
   • Files manage karo

**Tips:**
   • Main Hinglish samajhta hu
   • Honestly bataunga agar kuch nahi aata
   • Permission maangunga risky kaam ke liye
   • Khud ko improve kar sakta hu
"""

    def _get_conversation_history(self) -> str:
        """Get conversation history"""
        history = self.memory.get_conversation_history(limit=10)
        
        if not history:
            return "📝 Koi conversation history nahi hai abhi."
        
        result = "📝 **Recent Conversation:**\n\n"
        
        for entry in history:
            role = "👤 You" if entry['role'] == 'user' else "🤖 JEEVA"
            content = entry['content'][:100] + "..." if len(entry['content']) > 100 else entry['content']
            result += f"{role}: {content}\n\n"
        
        return result

    def run(self):
        """Main run loop"""
        if RICH_AVAILABLE:
            console.print(Panel(
                "🎯 Ready! Kuch bhi pucho ya kaam batao.\n"
                "Special commands: 'status', 'capabilities', 'memory', 'help', 'exit'",
                title="JEEVA Ready",
                border_style="green"
            ))
        else:
            print("\n🎯 Ready! Kuch bhi pucho ya kaam batao.")
            print("Special commands: 'status', 'capabilities', 'memory', 'help', 'exit'\n")
        
        if PROMPT_TOOLKIT_AVAILABLE:
            history_file = Path("data/.jeeva_history")
            history_file.parent.mkdir(parents=True, exist_ok=True)
            history = FileHistory(str(history_file))
        else:
            history = None
        
        while self.running:
            try:
                if PROMPT_TOOLKIT_AVAILABLE and history:
                    user_input = pt_prompt("\n👤 You: ", history=history)
                else:
                    user_input = input("\n👤 You: ")
                
                user_input = user_input.strip()
                
                if not user_input:
                    continue
                
                response = self.process_input(user_input)
                
                if response:
                    console.print(f"\n🤖 JEEVA: {response}")
                
            except KeyboardInterrupt:
                console.print("\n\n👋 Ctrl+C detected. Bye bhai!")
                break
            except EOFError:
                console.print("\n\n👋 EOF detected. Bye bhai!")
                break
            except Exception as e:
                console.print(f"\n[red]Error: {e}[/red]")
                continue
        
        self._shutdown()

    def _shutdown(self):
        """Cleanup and shutdown"""
        console.print("\n[yellow]Saving state...[/yellow]")
        
        try:
            self.memory.consolidate_memory()
        except Exception:
            pass
        
        try:
            self.brain.shutdown()
        except Exception:
            pass
        
        console.print("[green]✅ Shutdown complete![/green]")


def main():
    """Entry point"""
    try:
        required_dirs = [
            "data/memory",
            "data/knowledge",
            "data/backups",
            "data/github_repos",
            "data/restart_state",
            "data/security",
            "config",
            "tools",
            "logs"
        ]
        
        for dir_path in required_dirs:
            Path(dir_path).mkdir(parents=True, exist_ok=True)
        
        agent = JEEVA()
        agent.run()
        
    except KeyboardInterrupt:
        print("\n\n👋 Interrupted. Bye!")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()