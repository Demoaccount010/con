"""
Permission Manager - Owner permission system
JEEVA ke actions ko control karta hai
"""

from datetime import datetime
from typing import Dict, Any, List, Optional, Callable
from enum import Enum
import json
from pathlib import Path


class PermissionLevel(Enum):
    """Permission levels"""
    NONE = 0
    LOW = 1       # Read only operations
    MEDIUM = 2    # Read + safe writes
    HIGH = 3      # Most operations
    OWNER = 4     # Everything


class ActionRisk(Enum):
    """Risk levels for actions"""
    SAFE = "safe"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class PermissionManager:
    """
    Permission system - Owner ke bina kuch nahi hoga (important cheezein)
    
    Features:
    - Permission levels
    - Action risk assessment
    - Permission request queue
    - Audit logging
    """

    def __init__(self, data_path: str = "data/security"):
        self.data_path = Path(data_path)
        self.data_path.mkdir(parents=True, exist_ok=True)
        
        self.owner_authenticated = False
        self.current_permission_level = PermissionLevel.NONE
        self.owner_id = None
        
        self.always_ask_actions = [
            "self_modify",
            "delete_file",
            "system_command",
            "install_package",
            "code_execution",
            "capability_add",
            "settings_change",
            "restart",
            "shutdown",
            "network_request",
            "database_modify"
        ]
        
        self.auto_approved = [
            "read_file",
            "list_files",
            "get_info",
            "chat",
            "question_answer",
            "search",
            "help",
            "status"
        ]
        
        self.action_risk_map = {
            "read_file": ActionRisk.LOW,
            "write_file": ActionRisk.MEDIUM,
            "delete_file": ActionRisk.HIGH,
            "create_file": ActionRisk.MEDIUM,
            "list_files": ActionRisk.SAFE,
            "system_info": ActionRisk.SAFE,
            "system_command": ActionRisk.CRITICAL,
            "code_execution": ActionRisk.CRITICAL,
            "self_modify": ActionRisk.CRITICAL,
            "install_package": ActionRisk.HIGH,
            "network_request": ActionRisk.MEDIUM,
            "database_query": ActionRisk.MEDIUM,
            "database_modify": ActionRisk.HIGH,
            "restart": ActionRisk.HIGH,
            "shutdown": ActionRisk.CRITICAL
        }
        
        self.pending_requests = []
        self.permission_history = []
        self.audit_log = []
        self.max_history = 200
        
        self._load_state()

    def _load_state(self):
        """Load saved state"""
        state_file = self.data_path / "permission_state.json"
        if state_file.exists():
            try:
                with open(state_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.permission_history = data.get("history", [])[-self.max_history:]
                    self.audit_log = data.get("audit", [])[-self.max_history:]
            except Exception:
                pass

    def _save_state(self):
        """Save state to file"""
        state_file = self.data_path / "permission_state.json"
        try:
            with open(state_file, 'w', encoding='utf-8') as f:
                json.dump({
                    "history": self.permission_history[-self.max_history:],
                    "audit": self.audit_log[-self.max_history:],
                    "saved_at": datetime.now().isoformat()
                }, f, indent=2)
        except Exception:
            pass

    def authenticate_owner(self, auth_token: str = None, owner_id: str = None) -> Dict[str, Any]:
        """
        Owner authenticate karo
        
        Args:
            auth_token: Authentication token (optional)
            owner_id: Owner identifier (optional)
            
        Returns:
            Dict with authentication result
        """
        self.owner_authenticated = True
        self.current_permission_level = PermissionLevel.OWNER
        self.owner_id = owner_id or "default_owner"
        
        self._audit("authenticate", "Owner authenticated", True)
        
        return {
            "success": True,
            "message": "Owner authenticated successfully",
            "permission_level": self.current_permission_level.name
        }

    def deauthenticate(self) -> Dict[str, Any]:
        """Remove owner authentication"""
        self.owner_authenticated = False
        self.current_permission_level = PermissionLevel.NONE
        
        self._audit("deauthenticate", "Owner deauthenticated", True)
        
        return {
            "success": True,
            "message": "Deauthenticated successfully"
        }

    def is_authenticated(self) -> bool:
        """Check if owner is authenticated"""
        return self.owner_authenticated

    def get_permission_level(self) -> PermissionLevel:
        """Get current permission level"""
        return self.current_permission_level

    def set_permission_level(self, level: PermissionLevel) -> Dict[str, Any]:
        """Set permission level (requires owner auth)"""
        if not self.owner_authenticated:
            return {"success": False, "error": "Owner authentication required"}
        
        self.current_permission_level = level
        self._audit("set_permission", f"Permission level set to {level.name}", True)
        
        return {"success": True, "level": level.name}

    def get_action_risk(self, action: str) -> ActionRisk:
        """
        Get risk level for an action
        
        Args:
            action: Action name or description
            
        Returns:
            ActionRisk level
        """
        action_lower = action.lower()
        
        for action_name, risk in self.action_risk_map.items():
            if action_name in action_lower:
                return risk
        
        if any(word in action_lower for word in ["delete", "remove", "drop", "hata", "mita"]):
            return ActionRisk.HIGH
        
        if any(word in action_lower for word in ["system", "command", "execute", "run code", "exec"]):
            return ActionRisk.CRITICAL
        
        if any(word in action_lower for word in ["modify", "update", "change", "edit", "write"]):
            return ActionRisk.MEDIUM
        
        if any(word in action_lower for word in ["self", "khud", "apna", "restart", "shutdown"]):
            return ActionRisk.CRITICAL
        
        if any(word in action_lower for word in ["read", "get", "list", "show", "dikha"]):
            return ActionRisk.LOW
        
        return ActionRisk.MEDIUM

    def check_permission(self, action: str, risk_level: ActionRisk = None) -> Dict[str, Any]:
        """
        Check if action is permitted
        
        Args:
            action: Action to check
            risk_level: Risk level (auto-detected if None)
            
        Returns:
            Dict with permission status
        """
        action_lower = action.lower()
        
        if risk_level is None:
            risk_level = self.get_action_risk(action)
        
        for approved in self.auto_approved:
            if approved in action_lower:
                return {
                    "permitted": True,
                    "reason": "Auto-approved safe action",
                    "needs_confirmation": False,
                    "risk_level": risk_level.value
                }
        
        for ask_action in self.always_ask_actions:
            if ask_action in action_lower:
                return {
                    "permitted": False,
                    "reason": f"Action '{ask_action}' requires explicit permission",
                    "needs_confirmation": True,
                    "risk_level": risk_level.value
                }
        
        if risk_level == ActionRisk.CRITICAL:
            return {
                "permitted": False,
                "reason": "Critical action requires owner permission",
                "needs_confirmation": True,
                "risk_level": "critical"
            }
        
        elif risk_level == ActionRisk.HIGH:
            permitted = self.current_permission_level.value >= PermissionLevel.HIGH.value
            return {
                "permitted": permitted,
                "reason": "High risk action",
                "needs_confirmation": not permitted,
                "risk_level": "high"
            }
        
        elif risk_level == ActionRisk.MEDIUM:
            permitted = self.current_permission_level.value >= PermissionLevel.MEDIUM.value
            return {
                "permitted": permitted,
                "reason": "Medium risk action",
                "needs_confirmation": not permitted,
                "risk_level": "medium"
            }
        
        elif risk_level == ActionRisk.LOW:
            permitted = self.current_permission_level.value >= PermissionLevel.LOW.value
            return {
                "permitted": permitted,
                "reason": "Low risk action",
                "needs_confirmation": not permitted,
                "risk_level": "low"
            }
        
        else:
            return {
                "permitted": True,
                "reason": "Safe action",
                "needs_confirmation": False,
                "risk_level": "safe"
            }

    def request_permission(
        self,
        action: str,
        description: str,
        risk_level: ActionRisk = None,
        details: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """
        Owner se permission mango
        
        Args:
            action: Action name
            description: What will be done
            risk_level: Risk level
            details: Additional details
            
        Returns:
            Dict with request info
        """
        if risk_level is None:
            risk_level = self.get_action_risk(action)
        
        request = {
            "id": len(self.pending_requests) + 1,
            "action": action,
            "description": description,
            "risk_level": risk_level.value,
            "details": details or {},
            "requested_at": datetime.now().isoformat(),
            "status": "pending"
        }
        
        self.pending_requests.append(request)
        
        return {
            "request_id": request["id"],
            "message": self._format_permission_request(request),
            "risk_level": risk_level.value
        }

    def _format_permission_request(self, request: Dict) -> str:
        """Format permission request for display"""
        risk_emoji = {
            "safe": "✅",
            "low": "🟢",
            "medium": "🟡",
            "high": "🟠",
            "critical": "🔴"
        }
        
        emoji = risk_emoji.get(request["risk_level"], "⚪")
        
        message = f"""
🔐 PERMISSION REQUEST #{request['id']}
{'─' * 40}

📋 Action: {request['action']}
📝 Description: {request['description']}
{emoji} Risk Level: {request['risk_level'].upper()}

{'─' * 40}
⏳ Waiting for approval...

Reply with 'haan' or 'yes' to approve
Reply with 'nahi' or 'no' to deny
"""
        return message

    def grant_permission(self, request_id: int) -> Dict[str, Any]:
        """
        Permission grant karo
        
        Args:
            request_id: ID of request to grant
            
        Returns:
            Dict with result
        """
        for request in self.pending_requests:
            if request["id"] == request_id and request["status"] == "pending":
                request["status"] = "granted"
                request["granted_at"] = datetime.now().isoformat()
                
                self.permission_history.append(request)
                self._audit("grant_permission", f"Granted: {request['action']}", True)
                self._save_state()
                
                return {
                    "success": True,
                    "message": f"✅ Permission granted for: {request['action']}",
                    "request": request
                }
        
        return {"success": False, "error": f"Request {request_id} not found or already processed"}

    def deny_permission(self, request_id: int, reason: str = "") -> Dict[str, Any]:
        """
        Permission deny karo
        
        Args:
            request_id: ID of request to deny
            reason: Reason for denial
            
        Returns:
            Dict with result
        """
        for request in self.pending_requests:
            if request["id"] == request_id and request["status"] == "pending":
                request["status"] = "denied"
                request["denied_at"] = datetime.now().isoformat()
                request["denial_reason"] = reason
                
                self.permission_history.append(request)
                self._audit("deny_permission", f"Denied: {request['action']} - {reason}", True)
                self._save_state()
                
                return {
                    "success": True,
                    "message": f"❌ Permission denied for: {request['action']}",
                    "request": request
                }
        
        return {"success": False, "error": f"Request {request_id} not found or already processed"}

    def process_response(self, response: str) -> Dict[str, Any]:
        """
        Process user response to permission request
        
        Args:
            response: User's response (yes/no/haan/nahi)
            
        Returns:
            Dict with result
        """
        pending = self.get_pending_requests()
        
        if not pending:
            return {"success": False, "error": "No pending requests"}
        
        latest = pending[0]
        response_lower = response.lower().strip()
        
        if response_lower in ["yes", "y", "haan", "han", "ha", "ok", "okay", "theek", "thik"]:
            return self.grant_permission(latest["id"])
        elif response_lower in ["no", "n", "nahi", "nhi", "na", "cancel", "mat"]:
            return self.deny_permission(latest["id"], "User denied")
        else:
            return {
                "success": False,
                "error": "Invalid response. Use 'haan/yes' or 'nahi/no'",
                "pending_request": latest
            }

    def get_pending_requests(self) -> List[Dict]:
        """Get all pending permission requests"""
        return [r for r in self.pending_requests if r["status"] == "pending"]

    def clear_pending_requests(self):
        """Clear all pending requests"""
        for request in self.pending_requests:
            if request["status"] == "pending":
                request["status"] = "cleared"
                request["cleared_at"] = datetime.now().isoformat()
        
        self._save_state()

    def is_action_permitted(self, request_id: int) -> bool:
        """Check if a specific request was granted"""
        for request in self.permission_history:
            if request["id"] == request_id and request["status"] == "granted":
                return True
        return False

    def get_permission_history(self, limit: int = 20) -> List[Dict]:
        """Get permission history"""
        return self.permission_history[-limit:]

    def _audit(self, action: str, details: str, success: bool):
        """Add audit log entry"""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "action": action,
            "details": details,
            "success": success,
            "permission_level": self.current_permission_level.name,
            "authenticated": self.owner_authenticated
        }
        
        self.audit_log.append(entry)
        
        if len(self.audit_log) > self.max_history:
            self.audit_log = self.audit_log[-self.max_history:]

    def get_audit_log(self, limit: int = 50) -> List[Dict]:
        """Get audit log"""
        return self.audit_log[-limit:]

    def add_auto_approved_action(self, action: str):
        """Add action to auto-approved list"""
        if action not in self.auto_approved:
            self.auto_approved.append(action)
            self._audit("config_change", f"Added to auto-approved: {action}", True)

    def remove_auto_approved_action(self, action: str):
        """Remove action from auto-approved list"""
        if action in self.auto_approved:
            self.auto_approved.remove(action)
            self._audit("config_change", f"Removed from auto-approved: {action}", True)

    def add_always_ask_action(self, action: str):
        """Add action to always-ask list"""
        if action not in self.always_ask_actions:
            self.always_ask_actions.append(action)
            self._audit("config_change", f"Added to always-ask: {action}", True)

    def get_stats(self) -> Dict[str, Any]:
        """Get permission statistics"""
        granted = sum(1 for r in self.permission_history if r.get("status") == "granted")
        denied = sum(1 for r in self.permission_history if r.get("status") == "denied")
        
        return {
            "authenticated": self.owner_authenticated,
            "permission_level": self.current_permission_level.name,
            "pending_requests": len(self.get_pending_requests()),
            "total_requests": len(self.permission_history),
            "granted": granted,
            "denied": denied,
            "approval_rate": round(granted / len(self.permission_history) * 100, 1) if self.permission_history else 0,
            "audit_entries": len(self.audit_log)
        }

    def format_risk_warning(self, action: str, risks: List[str] = None) -> str:
        """Format risk warning message"""
        risk_level = self.get_action_risk(action)
        
        warning = f"⚠️ Action: {action}\n"
        warning += f"Risk Level: {risk_level.value.upper()}\n"
        
        if risks:
            warning += "\nPotential Risks:\n"
            for risk in risks:
                warning += f"  • {risk}\n"
        
        warning += "\n🔐 Permission required to proceed."
        
        return warning