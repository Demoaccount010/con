"""
Self Learner - JEEVA ka learning system
Har interaction se seekhta hai aur improve hota hai
"""

import json
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple


class SelfLearner:
    """
    Self-learning system
    """

    def __init__(self, memory_manager=None, knowledge_path: str = "data/knowledge"):
        self.memory = memory_manager
        self.knowledge_path = Path(knowledge_path)
        self.knowledge_path.mkdir(parents=True, exist_ok=True)
        
        self.learning_enabled = True
        self.current_learnings = []
        self.learning_stats = {
            "total_learned": 0,
            "from_success": 0,
            "from_failure": 0,
            "from_correction": 0
        }
        
        self.knowledge_base = self._load_knowledge()

    def _load_knowledge(self) -> Dict[str, Any]:
        """Load existing knowledge"""
        kb_path = self.knowledge_path / "knowledge_base.json"
        
        if kb_path.exists():
            try:
                with open(kb_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    print(f"📚 Loaded knowledge base with {len(data.get('successful_patterns', []))} patterns")
                    return data
            except Exception as e:
                print(f"⚠️ Could not load knowledge base: {e}")
        
        return {
            "learned_responses": [],
            "successful_patterns": [],
            "failed_patterns": [],
            "user_corrections": [],
            "skill_improvements": [],
            "intent_patterns": {},
            "word_associations": {},
            "metadata": {
                "created_at": datetime.now().isoformat(),
                "version": "1.0"
            }
        }

    def _save_knowledge(self):
        """Save knowledge to disk"""
        kb_path = self.knowledge_path / "knowledge_base.json"
        
        try:
            self.knowledge_base["metadata"]["last_saved"] = datetime.now().isoformat()
            self.knowledge_base["metadata"]["total_patterns"] = len(self.knowledge_base.get("successful_patterns", []))
            
            with open(kb_path, 'w', encoding='utf-8') as f:
                json.dump(self.knowledge_base, f, indent=2, ensure_ascii=False)
                
        except Exception as e:
            print(f"⚠️ Could not save knowledge: {e}")

    def enable_learning(self):
        """Enable learning"""
        self.learning_enabled = True

    def disable_learning(self):
        """Disable learning"""
        self.learning_enabled = False

    def learn_from_interaction(
        self,
        user_input: str,
        agent_response: str,
        was_successful: bool,
        intent_type: str = None,
        confidence: float = None,
        user_feedback: str = None
    ) -> Dict[str, Any]:
        """
        Interaction se seekho
        """
        if not self.learning_enabled:
            return {"learned": False, "reason": "Learning disabled"}
        
        learning = {
            "input": user_input,
            "response": agent_response,
            "successful": was_successful,
            "intent": intent_type,
            "confidence": confidence,
            "feedback": user_feedback,
            "timestamp": datetime.now().isoformat()
        }
        
        if was_successful:
            result = self._learn_success(learning)
        else:
            result = self._learn_failure(learning)
        
        if intent_type:
            self._learn_intent_pattern(user_input, intent_type, was_successful)
            self._learn_word_associations(user_input, intent_type, was_successful)
        
        self._save_knowledge()
        
        self.learning_stats["total_learned"] += 1
        
        return result

    def _learn_success(self, learning: Dict) -> Dict[str, Any]:
        """Success se seekho"""
        pattern = {
            "id": len(self.knowledge_base.get("successful_patterns", [])),
            "input_pattern": learning["input"],
            "response_pattern": learning["response"],
            "intent": learning.get("intent"),
            "count": 1,
            "first_learned": learning["timestamp"],
            "last_used": learning["timestamp"]
        }
        
        existing = self._find_similar_pattern(learning["input"], "successful_patterns")
        
        if existing:
            existing["count"] = existing.get("count", 0) + 1
            existing["last_used"] = learning["timestamp"]
        else:
            self.knowledge_base["successful_patterns"].append(pattern)
        
        # FIXED: Correct method call with proper arguments
        if self.memory:
            try:
                self.memory.remember_pattern(
                    pattern_type="successful_interaction",
                    pattern_data={
                        "input": learning["input"],
                        "response": learning["response"],
                        "intent": learning.get("intent")
                    },
                    success=True
                )
            except Exception as e:
                print(f"Warning: Could not save to memory: {e}")
            
            try:
                self.memory.remember_successful_response(
                    learning["input"],
                    learning["response"]
                )
            except Exception as e:
                pass
        
        self.learning_stats["from_success"] += 1
        
        return {
            "learned": True,
            "type": "success",
            "pattern_id": pattern["id"]
        }

    def _learn_failure(self, learning: Dict) -> Dict[str, Any]:
        """Failure se seekho"""
        pattern = {
            "id": len(self.knowledge_base.get("failed_patterns", [])),
            "input_pattern": learning["input"],
            "failed_response": learning["response"],
            "intent": learning.get("intent"),
            "feedback": learning.get("feedback"),
            "timestamp": learning["timestamp"]
        }
        
        self.knowledge_base["failed_patterns"].append(pattern)
        
        if len(self.knowledge_base["failed_patterns"]) > 200:
            self.knowledge_base["failed_patterns"] = self.knowledge_base["failed_patterns"][-200:]
        
        # FIXED: Correct method call with proper arguments
        if self.memory:
            try:
                self.memory.remember_pattern(
                    pattern_type="failed_interaction",
                    pattern_data={
                        "input": learning["input"],
                        "response": learning["response"],
                        "feedback": learning.get("feedback")
                    },
                    success=False
                )
            except Exception as e:
                print(f"Warning: Could not save to memory: {e}")
            
            try:
                self.memory.remember_failed_response(
                    learning["input"],
                    learning["response"],
                    learning.get("feedback", "")
                )
            except Exception as e:
                pass
            
            try:
                self.memory.remember_fact(
                    fact=f"Failed: For input like '{learning['input'][:50]}...', response did not work",
                    confidence=0.9,
                    source="failure_learning",
                    category="failure"
                )
            except Exception as e:
                pass
        
        self.learning_stats["from_failure"] += 1
        
        return {
            "learned": True,
            "type": "failure",
            "pattern_id": pattern["id"]
        }

    def _learn_intent_pattern(self, user_input: str, intent_type: str, successful: bool):
        """Learn intent patterns"""
        if not intent_type:
            return
        
        words = user_input.lower().split()
        
        if intent_type not in self.knowledge_base["intent_patterns"]:
            self.knowledge_base["intent_patterns"][intent_type] = {
                "keywords": {},
                "phrases": [],
                "success_count": 0,
                "failure_count": 0
            }
        
        pattern_data = self.knowledge_base["intent_patterns"][intent_type]
        
        if successful:
            pattern_data["success_count"] += 1
        else:
            pattern_data["failure_count"] += 1
        
        for word in words:
            if len(word) > 2:
                if word not in pattern_data["keywords"]:
                    pattern_data["keywords"][word] = {"count": 0, "success_rate": 0}
                
                pattern_data["keywords"][word]["count"] += 1
                
                total = pattern_data["success_count"] + pattern_data["failure_count"]
                if total > 0:
                    pattern_data["keywords"][word]["success_rate"] = pattern_data["success_count"] / total

    def _learn_word_associations(self, user_input: str, intent_type: str, successful: bool):
        """Learn word to intent associations"""
        if not intent_type or not successful:
            return
        
        words = user_input.lower().split()
        
        for word in words:
            if len(word) > 2:
                if word not in self.knowledge_base["word_associations"]:
                    self.knowledge_base["word_associations"][word] = {}
                
                if intent_type not in self.knowledge_base["word_associations"][word]:
                    self.knowledge_base["word_associations"][word][intent_type] = 0
                
                self.knowledge_base["word_associations"][word][intent_type] += 1

    def _find_similar_pattern(self, text: str, pattern_type: str) -> Optional[Dict]:
        """Find similar pattern in knowledge base"""
        patterns = self.knowledge_base.get(pattern_type, [])
        text_lower = text.lower()
        text_words = set(text_lower.split())
        
        for pattern in patterns:
            pattern_input = pattern.get("input_pattern", "").lower()
            pattern_words = set(pattern_input.split())
            
            if text_words and pattern_words:
                overlap = len(text_words & pattern_words)
                total = len(text_words | pattern_words)
                similarity = overlap / total if total > 0 else 0
                
                if similarity >= 0.7:
                    return pattern
        
        return None

    def learn_from_correction(
        self,
        original_response: str,
        corrected_response: str,
        context: str,
        user_explanation: str = None
    ) -> Dict[str, Any]:
        """User correction se seekho"""
        if not self.learning_enabled:
            return {"learned": False, "reason": "Learning disabled"}
        
        correction = {
            "id": len(self.knowledge_base.get("user_corrections", [])),
            "context": context,
            "original": original_response,
            "corrected": corrected_response,
            "explanation": user_explanation,
            "timestamp": datetime.now().isoformat(),
            "applied": False
        }
        
        self.knowledge_base["user_corrections"].append(correction)
        
        if self.memory:
            try:
                self.memory.remember_correction(
                    original_response,
                    corrected_response,
                    context
                )
            except Exception as e:
                pass
            
            try:
                self.memory.remember_fact(
                    fact=f"Correction: Instead of '{original_response[:30]}...', should say '{corrected_response[:30]}...'",
                    confidence=1.0,
                    source="user_correction",
                    category="correction"
                )
            except Exception as e:
                pass
        
        self.learning_stats["from_correction"] += 1
        
        self._save_knowledge()
        
        return {
            "learned": True,
            "type": "correction",
            "correction_id": correction["id"]
        }

    def improve_skill(
        self,
        skill_name: str,
        improvement: Dict[str, Any],
        reason: str = None
    ) -> Dict[str, Any]:
        """Skill improve karo"""
        skill_improvement = {
            "id": len(self.knowledge_base.get("skill_improvements", [])),
            "skill": skill_name,
            "improvement": improvement,
            "reason": reason,
            "timestamp": datetime.now().isoformat()
        }
        
        self.knowledge_base["skill_improvements"].append(skill_improvement)
        
        if self.memory:
            try:
                self.memory.remember_skill({
                    "name": skill_name,
                    "improvement": improvement,
                    "reason": reason
                })
            except Exception as e:
                pass
        
        self._save_knowledge()
        
        return {
            "learned": True,
            "type": "skill_improvement",
            "skill": skill_name
        }

    def get_learned_response(self, user_input: str) -> Optional[str]:
        """Check if we have a learned response for similar input"""
        pattern = self._find_similar_pattern(user_input, "successful_patterns")
        
        if pattern:
            pattern["count"] = pattern.get("count", 0) + 1
            pattern["last_used"] = datetime.now().isoformat()
            self._save_knowledge()
            
            return pattern.get("response_pattern")
        
        return None

    def should_avoid_response(self, response: str, context: str = "") -> Tuple[bool, str]:
        """Check if this response should be avoided"""
        response_lower = response.lower()
        
        for pattern in self.knowledge_base.get("failed_patterns", []):
            failed_response = pattern.get("failed_response", "").lower()
            
            if self._text_similarity(response_lower, failed_response) > 0.7:
                return True, f"Similar response failed before: {pattern.get('feedback', 'No feedback')}"
        
        for correction in self.knowledge_base.get("user_corrections", []):
            original = correction.get("original", "").lower()
            
            if self._text_similarity(response_lower, original) > 0.7:
                return True, f"User corrected this: {correction.get('corrected', '')[:50]}"
        
        if self.memory:
            try:
                if self.memory.should_avoid_response(response):
                    return True, "Memory indicates this response failed before"
            except Exception:
                pass
        
        return False, ""

    def get_correction_for_context(self, context: str) -> Optional[str]:
        """Get corrected response for similar context"""
        context_lower = context.lower()
        
        for correction in self.knowledge_base.get("user_corrections", []):
            correction_context = correction.get("context", "").lower()
            
            if self._text_similarity(context_lower, correction_context) > 0.6:
                return correction.get("corrected")
        
        return None

    def _text_similarity(self, text1: str, text2: str) -> float:
        """Calculate simple text similarity"""
        if not text1 or not text2:
            return 0.0
        
        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())
        
        if not words1 or not words2:
            return 0.0
        
        overlap = len(words1 & words2)
        total = len(words1 | words2)
        
        return overlap / total if total > 0 else 0.0

    def get_intent_keywords(self, intent_type: str) -> List[str]:
        """Get top keywords for an intent type"""
        pattern_data = self.knowledge_base.get("intent_patterns", {}).get(intent_type, {})
        keywords = pattern_data.get("keywords", {})
        
        sorted_keywords = sorted(
            keywords.items(),
            key=lambda x: x[1].get("count", 0),
            reverse=True
        )
        
        return [k for k, v in sorted_keywords[:20]]

    def predict_intent_from_words(self, words: List[str]) -> Optional[str]:
        """Predict intent based on word associations"""
        intent_scores = {}
        
        for word in words:
            word_lower = word.lower()
            associations = self.knowledge_base.get("word_associations", {}).get(word_lower, {})
            
            for intent, count in associations.items():
                if intent not in intent_scores:
                    intent_scores[intent] = 0
                intent_scores[intent] += count
        
        if intent_scores:
            best_intent = max(intent_scores, key=intent_scores.get)
            return best_intent
        
        return None

    def get_learning_stats(self) -> Dict[str, Any]:
        """Get learning statistics"""
        return {
            "learning_enabled": self.learning_enabled,
            "total_learned": self.learning_stats["total_learned"],
            "from_success": self.learning_stats["from_success"],
            "from_failure": self.learning_stats["from_failure"],
            "from_correction": self.learning_stats["from_correction"],
            "successful_patterns": len(self.knowledge_base.get("successful_patterns", [])),
            "failed_patterns": len(self.knowledge_base.get("failed_patterns", [])),
            "user_corrections": len(self.knowledge_base.get("user_corrections", [])),
            "skill_improvements": len(self.knowledge_base.get("skill_improvements", [])),
            "known_intents": list(self.knowledge_base.get("intent_patterns", {}).keys()),
            "word_associations_count": len(self.knowledge_base.get("word_associations", {}))
        }

    def get_improvement_suggestions(self) -> List[Dict[str, str]]:
        """Get suggestions based on learning"""
        suggestions = []
        
        failed_count = len(self.knowledge_base.get("failed_patterns", []))
        if failed_count > 10:
            suggestions.append({
                "type": "review_failures",
                "priority": "high",
                "suggestion": f"There are {failed_count} failed patterns. Consider reviewing them."
            })
        
        corrections = self.knowledge_base.get("user_corrections", [])
        if len(corrections) > 5:
            suggestions.append({
                "type": "apply_corrections",
                "priority": "high",
                "suggestion": f"There are {len(corrections)} user corrections. Consider updating response logic."
            })
        
        for intent, data in self.knowledge_base.get("intent_patterns", {}).items():
            total = data.get("success_count", 0) + data.get("failure_count", 0)
            if total > 10:
                success_rate = data.get("success_count", 0) / total
                if success_rate < 0.7:
                    suggestions.append({
                        "type": "improve_intent",
                        "priority": "medium",
                        "suggestion": f"Intent '{intent}' has low success rate ({success_rate:.1%}). Consider improving."
                    })
        
        return suggestions

    def export_knowledge(self, file_path: str) -> Dict[str, Any]:
        """Export knowledge to file"""
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(self.knowledge_base, f, indent=2, ensure_ascii=False)
            return {"success": True, "file": file_path}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def import_knowledge(self, file_path: str) -> Dict[str, Any]:
        """Import knowledge from file"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                imported = json.load(f)
            
            for pattern in imported.get("successful_patterns", []):
                if not self._find_similar_pattern(pattern.get("input_pattern", ""), "successful_patterns"):
                    self.knowledge_base["successful_patterns"].append(pattern)
            
            self._save_knowledge()
            
            return {"success": True, "imported": True}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def clear_knowledge(self, confirm: bool = False) -> Dict[str, Any]:
        """Clear all knowledge"""
        if not confirm:
            return {"success": False, "error": "Confirmation required"}
        
        self.knowledge_base = {
            "learned_responses": [],
            "successful_patterns": [],
            "failed_patterns": [],
            "user_corrections": [],
            "skill_improvements": [],
            "intent_patterns": {},
            "word_associations": {},
            "metadata": {
                "created_at": datetime.now().isoformat(),
                "cleared_at": datetime.now().isoformat(),
                "version": "1.0"
            }
        }
        
        self._save_knowledge()
        
        return {"success": True, "message": "Knowledge cleared"}