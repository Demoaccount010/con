"""
Memory Manager - Short-term and Long-term memory
JEEVA ki complete memory system
"""

import json
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Union
from collections import deque
import threading


class MemoryManager:
    """
    JEEVA ki memory manage karta hai
    - Short-term: Recent conversations, temporary data
    - Long-term: Learned patterns, important facts
    - Working: Current session data
    """

    def __init__(self, data_path: str = "data/memory"):
        self.data_path = Path(data_path)
        self.data_path.mkdir(parents=True, exist_ok=True)

        # Short-term memory (in-memory, limited size)
        self.short_term = deque(maxlen=100)

        # Long-term memory paths
        self.long_term_path = self.data_path / "long_term.json"
        self.facts_path = self.data_path / "facts.json"
        self.patterns_path = self.data_path / "patterns.json"
        self.skills_path = self.data_path / "skills.json"

        # Load long-term memory
        self.long_term = self._load_long_term()

        # Working memory (current session)
        self.working_memory = {
            "current_context": None,
            "conversation_history": [],
            "active_tasks": [],
            "user_preferences": {},
            "session_start": datetime.now().isoformat()
        }

        # Auto-save thread
        self._auto_save_enabled = True
        self._save_lock = threading.Lock()

    def _load_long_term(self) -> Dict[str, Any]:
        """Load long-term memory from disk"""
        if self.long_term_path.exists():
            try:
                with open(self.long_term_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    print(f"📚 Loaded {len(data.get('facts', []))} facts from memory")
                    return data
            except Exception as e:
                print(f"⚠️ Could not load memory: {e}")

        # Default structure
        return {
            "facts": [],
            "patterns": [],
            "user_info": {},
            "learned_skills": [],
            "important_events": [],
            "corrections": [],
            "successful_responses": [],
            "failed_responses": [],
            "metadata": {
                "created_at": datetime.now().isoformat(),
                "version": "1.0"
            }
        }

    def _save_long_term(self):
        """Save long-term memory to disk"""
        with self._save_lock:
            try:
                # Update metadata
                self.long_term["metadata"]["last_saved"] = datetime.now().isoformat()
                self.long_term["metadata"]["total_facts"] = len(self.long_term.get("facts", []))
                self.long_term["metadata"]["total_patterns"] = len(self.long_term.get("patterns", []))

                with open(self.long_term_path, 'w', encoding='utf-8') as f:
                    json.dump(self.long_term, f, indent=2, ensure_ascii=False)

            except Exception as e:
                print(f"⚠️ Could not save memory: {e}")

    # ==================== SHORT-TERM MEMORY ====================

    def remember_short(self, item: Dict[str, Any], important: bool = False):
        """
        Short-term memory mein add karo
        
        Args:
            item: Data to remember
            important: If True, will be considered for long-term storage
        """
        memory_item = {
            **item,
            "timestamp": datetime.now().isoformat(),
            "important": important,
            "id": len(self.short_term)
        }
        self.short_term.append(memory_item)

        # Auto-promote important items
        if important:
            self._consider_for_long_term(memory_item)

    def get_recent(self, n: int = 10) -> List[Dict]:
        """Recent n items from short-term memory"""
        items = list(self.short_term)
        return items[-n:] if len(items) >= n else items

    def get_recent_context(self, n: int = 10) -> List[Dict]:
        """Recent n items for context building"""
        return self.get_recent(n)

    def search_short_term(self, query: str, limit: int = 10) -> List[Dict]:
        """Search in short-term memory"""
        results = []
        query_lower = query.lower()

        for item in reversed(list(self.short_term)):
            item_str = json.dumps(item, ensure_ascii=False).lower()
            if query_lower in item_str:
                results.append(item)
                if len(results) >= limit:
                    break

        return results

    def clear_short_term(self):
        """Clear short-term memory"""
        self.short_term.clear()

    # ==================== LONG-TERM MEMORY: FACTS ====================

    def remember_fact(
        self,
        fact: str,
        confidence: float = 1.0,
        source: str = "learned",
        category: str = "general",
        tags: List[str] = None
    ):
        """
        Long-term memory mein fact store karo
        
        Args:
            fact: The fact to remember
            confidence: How confident (0.0 to 1.0)
            source: Where did we learn this
            category: Category of fact
            tags: Searchable tags
        """
        # Check for duplicates
        existing = self._find_similar_fact(fact)
        if existing:
            # Update existing fact's confidence
            existing["confidence"] = max(existing["confidence"], confidence)
            existing["recall_count"] = existing.get("recall_count", 0) + 1
            existing["last_updated"] = datetime.now().isoformat()
            self._save_long_term()
            return

        fact_entry = {
            "id": len(self.long_term["facts"]),
            "fact": fact,
            "confidence": confidence,
            "source": source,
            "category": category,
            "tags": tags or [],
            "learned_at": datetime.now().isoformat(),
            "last_recalled": None,
            "recall_count": 0
        }

        self.long_term["facts"].append(fact_entry)
        self._save_long_term()

    def _find_similar_fact(self, fact: str, threshold: float = 0.8) -> Optional[Dict]:
        """Find if similar fact already exists"""
        fact_lower = fact.lower()
        fact_words = set(fact_lower.split())

        for existing in self.long_term.get("facts", []):
            existing_lower = existing.get("fact", "").lower()
            existing_words = set(existing_lower.split())

            # Simple word overlap similarity
            if fact_words and existing_words:
                overlap = len(fact_words & existing_words)
                total = len(fact_words | existing_words)
                similarity = overlap / total if total > 0 else 0

                if similarity >= threshold:
                    return existing

        return None

    def recall_facts(
        self,
        query: str = None,
        category: str = None,
        min_confidence: float = 0.0,
        limit: int = 10
    ) -> List[Dict]:
        """
        Facts recall karo
        
        Args:
            query: Search query (optional)
            category: Filter by category
            min_confidence: Minimum confidence level
            limit: Maximum results
        """
        facts = self.long_term.get("facts", [])

        # Filter by category
        if category:
            facts = [f for f in facts if f.get("category") == category]

        # Filter by confidence
        facts = [f for f in facts if f.get("confidence", 0) >= min_confidence]

        # Search by query
        if query:
            query_lower = query.lower()
            scored_facts = []

            for fact in facts:
                fact_text = fact.get("fact", "").lower()
                tags = " ".join(fact.get("tags", [])).lower()

                score = 0
                if query_lower in fact_text:
                    score += 2
                if query_lower in tags:
                    score += 1

                # Word overlap
                query_words = set(query_lower.split())
                fact_words = set(fact_text.split())
                overlap = len(query_words & fact_words)
                score += overlap * 0.5

                if score > 0:
                    scored_facts.append((score, fact))

            # Sort by score
            scored_facts.sort(key=lambda x: x[0], reverse=True)
            facts = [f for _, f in scored_facts]

        # Update recall stats
        for fact in facts[:limit]:
            fact["recall_count"] = fact.get("recall_count", 0) + 1
            fact["last_recalled"] = datetime.now().isoformat()

        self._save_long_term()

        return facts[:limit]

    def forget_fact(self, fact_id: int) -> bool:
        """Fact bhool jao (delete)"""
        facts = self.long_term.get("facts", [])
        for i, fact in enumerate(facts):
            if fact.get("id") == fact_id:
                facts.pop(i)
                self._save_long_term()
                return True
        return False

    # ==================== LONG-TERM MEMORY: PATTERNS ====================

    def remember_pattern(
        self,
        pattern_type: str,
        pattern_data: Dict[str, Any],
        success: bool = True
    ):
        """
        Pattern remember karo
        
        Args:
            pattern_type: Type of pattern (e.g., 'user_request', 'successful_response')
            pattern_data: The pattern data
            success: Was this pattern successful?
        """
        pattern_entry = {
            "id": len(self.long_term.get("patterns", [])),
            "type": pattern_type,
            "data": pattern_data,
            "success": success,
            "learned_at": datetime.now().isoformat(),
            "use_count": 0
        }

        self.long_term["patterns"].append(pattern_entry)
        self._save_long_term()

    def recall_patterns(
        self,
        pattern_type: str = None,
        successful_only: bool = False,
        limit: int = 20
    ) -> List[Dict]:
        """Patterns recall karo"""
        patterns = self.long_term.get("patterns", [])

        if pattern_type:
            patterns = [p for p in patterns if p.get("type") == pattern_type]

        if successful_only:
            patterns = [p for p in patterns if p.get("success", False)]

        # Sort by use count
        patterns.sort(key=lambda x: x.get("use_count", 0), reverse=True)

        return patterns[:limit]

    def find_matching_pattern(self, input_text: str) -> Optional[Dict]:
        """Find a pattern that matches the input"""
        input_lower = input_text.lower()
        input_words = set(input_lower.split())

        best_match = None
        best_score = 0

        for pattern in self.long_term.get("patterns", []):
            if not pattern.get("success", False):
                continue

            pattern_input = pattern.get("data", {}).get("input", "").lower()
            pattern_words = set(pattern_input.split())

            if pattern_words:
                overlap = len(input_words & pattern_words)
                score = overlap / len(pattern_words)

                if score > best_score and score > 0.5:
                    best_score = score
                    best_match = pattern

        if best_match:
            best_match["use_count"] = best_match.get("use_count", 0) + 1
            self._save_long_term()

        return best_match

    # ==================== LONG-TERM MEMORY: USER INFO ====================

    def remember_user_info(self, key: str, value: Any, confidence: float = 1.0):
        """User ke baare mein info store karo"""
        self.long_term["user_info"][key] = {
            "value": value,
            "confidence": confidence,
            "updated_at": datetime.now().isoformat(),
            "update_count": self.long_term["user_info"].get(key, {}).get("update_count", 0) + 1
        }
        self._save_long_term()

    def recall_user_info(self, key: str) -> Any:
        """User info recall karo"""
        info = self.long_term.get("user_info", {}).get(key)
        if info:
            return info.get("value")
        return None

    def get_all_user_info(self) -> Dict[str, Any]:
        """Get all stored user info"""
        return {k: v.get("value") for k, v in self.long_term.get("user_info", {}).items()}

    # ==================== LONG-TERM MEMORY: SKILLS ====================

    def remember_skill(
        self,
        skill_name: str,
        skill_data: Dict[str, Any],
        proficiency: float = 0.5
    ):
        """Learned skill store karo"""
        # Check if skill exists
        existing = None
        for skill in self.long_term.get("learned_skills", []):
            if skill.get("name") == skill_name:
                existing = skill
                break

        if existing:
            # Update existing skill
            existing["proficiency"] = max(existing.get("proficiency", 0), proficiency)
            existing["data"].update(skill_data)
            existing["last_used"] = datetime.now().isoformat()
            existing["use_count"] = existing.get("use_count", 0) + 1
        else:
            # Add new skill
            skill_entry = {
                "id": len(self.long_term.get("learned_skills", [])),
                "name": skill_name,
                "data": skill_data,
                "proficiency": proficiency,
                "learned_at": datetime.now().isoformat(),
                "last_used": datetime.now().isoformat(),
                "use_count": 1
            }
            self.long_term["learned_skills"].append(skill_entry)

        self._save_long_term()

    def recall_skills(self, min_proficiency: float = 0.0) -> List[Dict]:
        """Recall all skills"""
        skills = self.long_term.get("learned_skills", [])
        return [s for s in skills if s.get("proficiency", 0) >= min_proficiency]

    def has_skill(self, skill_name: str) -> bool:
        """Check if we have a skill"""
        for skill in self.long_term.get("learned_skills", []):
            if skill.get("name", "").lower() == skill_name.lower():
                return True
        return False

    # ==================== LONG-TERM MEMORY: EVENTS ====================

    def remember_event(
        self,
        event: str,
        event_type: str = "general",
        importance: int = 1,
        data: Dict[str, Any] = None
    ):
        """Important event store karo"""
        event_entry = {
            "id": len(self.long_term.get("important_events", [])),
            "event": event,
            "type": event_type,
            "importance": importance,
            "data": data or {},
            "timestamp": datetime.now().isoformat()
        }

        self.long_term["important_events"].append(event_entry)

        # Keep only last 500 events
        if len(self.long_term["important_events"]) > 500:
            # Keep high importance events + recent ones
            events = self.long_term["important_events"]
            high_importance = [e for e in events if e.get("importance", 0) >= 3]
            recent = events[-200:]
            self.long_term["important_events"] = list({
                e["id"]: e for e in (high_importance + recent)
            }.values())

        self._save_long_term()

    def recall_events(
        self,
        event_type: str = None,
        min_importance: int = 0,
        limit: int = 20
    ) -> List[Dict]:
        """Recall events"""
        events = self.long_term.get("important_events", [])

        if event_type:
            events = [e for e in events if e.get("type") == event_type]

        events = [e for e in events if e.get("importance", 0) >= min_importance]

        # Sort by timestamp (recent first)
        events.sort(key=lambda x: x.get("timestamp", ""), reverse=True)

        return events[:limit]

    # ==================== LEARNING FROM INTERACTIONS ====================

    def remember_correction(
        self,
        original_response: str,
        corrected_response: str,
        context: str
    ):
        """User correction se seekho"""
        correction = {
            "id": len(self.long_term.get("corrections", [])),
            "context": context,
            "original": original_response,
            "corrected": corrected_response,
            "timestamp": datetime.now().isoformat()
        }

        self.long_term["corrections"].append(correction)

        # Also remember as a fact
        self.remember_fact(
            f"Correction: For '{context[:50]}...', should respond with '{corrected_response[:50]}...'",
            confidence=1.0,
            source="user_correction",
            category="correction"
        )

        self._save_long_term()

    def remember_successful_response(self, input_text: str, response: str):
        """Successful response remember karo"""
        entry = {
            "input": input_text,
            "response": response,
            "timestamp": datetime.now().isoformat()
        }

        self.long_term["successful_responses"].append(entry)

        # Also remember as pattern
        self.remember_pattern(
            pattern_type="successful_response",
            pattern_data=entry,
            success=True
        )

        # Keep only last 200
        if len(self.long_term["successful_responses"]) > 200:
            self.long_term["successful_responses"] = self.long_term["successful_responses"][-200:]

        self._save_long_term()

    def remember_failed_response(self, input_text: str, response: str, reason: str = ""):
        """Failed response remember karo (to avoid in future)"""
        entry = {
            "input": input_text,
            "response": response,
            "reason": reason,
            "timestamp": datetime.now().isoformat()
        }

        self.long_term["failed_responses"].append(entry)

        # Also remember as pattern
        self.remember_pattern(
            pattern_type="failed_response",
            pattern_data=entry,
            success=False
        )

        # Keep only last 100
        if len(self.long_term["failed_responses"]) > 100:
            self.long_term["failed_responses"] = self.long_term["failed_responses"][-100:]

        self._save_long_term()

    def should_avoid_response(self, response: str) -> bool:
        """Check if this response should be avoided"""
        response_lower = response.lower()

        for failed in self.long_term.get("failed_responses", []):
            failed_response = failed.get("response", "").lower()
            if self._text_similarity(response_lower, failed_response) > 0.8:
                return True

        return False

    def _text_similarity(self, text1: str, text2: str) -> float:
        """Simple text similarity"""
        words1 = set(text1.split())
        words2 = set(text2.split())

        if not words1 or not words2:
            return 0.0

        overlap = len(words1 & words2)
        total = len(words1 | words2)

        return overlap / total if total > 0 else 0.0

    # ==================== WORKING MEMORY ====================

    def set_context(self, context: Dict[str, Any]):
        """Current context set karo"""
        self.working_memory["current_context"] = {
            **context,
            "set_at": datetime.now().isoformat()
        }

    def get_context(self) -> Optional[Dict[str, Any]]:
        """Current context get karo"""
        return self.working_memory.get("current_context")

    def clear_context(self):
        """Clear current context"""
        self.working_memory["current_context"] = None

    def add_to_conversation(self, role: str, content: str):
        """Conversation history mein add karo"""
        entry = {
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat()
        }

        self.working_memory["conversation_history"].append(entry)

        # Also add to short-term
        self.remember_short({
            "type": "conversation",
            "role": role,
            "content": content
        })

        # Keep working memory conversation limited
        if len(self.working_memory["conversation_history"]) > 100:
            self.working_memory["conversation_history"] = \
                self.working_memory["conversation_history"][-100:]

    def get_conversation_history(self, limit: int = 20) -> List[Dict]:
        """Conversation history get karo"""
        history = self.working_memory.get("conversation_history", [])
        return history[-limit:] if len(history) >= limit else history

    def add_active_task(self, task: Dict[str, Any]):
        """Add active task"""
        task["added_at"] = datetime.now().isoformat()
        task["status"] = "active"
        self.working_memory["active_tasks"].append(task)

    def complete_task(self, task_id: int):
        """Mark task as complete"""
        for task in self.working_memory.get("active_tasks", []):
            if task.get("id") == task_id:
                task["status"] = "completed"
                task["completed_at"] = datetime.now().isoformat()
                break

    def get_active_tasks(self) -> List[Dict]:
        """Get active tasks"""
        return [
            t for t in self.working_memory.get("active_tasks", [])
            if t.get("status") == "active"
        ]

    # ==================== MEMORY CONSOLIDATION ====================

    def _consider_for_long_term(self, item: Dict[str, Any]):
        """Consider short-term item for long-term storage"""
        item_type = item.get("type")

        if item_type == "fact":
            self.remember_fact(
                item.get("content", str(item)),
                source="short_term_promotion"
            )
        elif item_type == "pattern":
            self.remember_pattern(
                pattern_type=item.get("pattern_type", "general"),
                pattern_data=item
            )

    def consolidate_memory(self):
        """
        Short-term important items ko long-term mein move karo
        Call this periodically or before shutdown
        """
        consolidated = 0

        for item in self.short_term:
            if item.get("important", False):
                self._consider_for_long_term(item)
                consolidated += 1

        # Clear consolidated items' important flag
        for item in self.short_term:
            item["important"] = False

        self._save_long_term()

        return {"consolidated": consolidated}

    def cleanup_old_memories(self, days: int = 30):
        """Clean up old, unused memories"""
        cutoff_date = (datetime.now() - timedelta(days=days)).isoformat()
        cleaned = 0

        # Clean old facts with low recall
        facts = self.long_term.get("facts", [])
        self.long_term["facts"] = [
            f for f in facts
            if f.get("recall_count", 0) > 0 or f.get("learned_at", "") > cutoff_date
        ]
        cleaned += len(facts) - len(self.long_term["facts"])

        # Clean old patterns
        patterns = self.long_term.get("patterns", [])
        self.long_term["patterns"] = [
            p for p in patterns
            if p.get("use_count", 0) > 0 or p.get("learned_at", "") > cutoff_date
        ]
        cleaned += len(patterns) - len(self.long_term["patterns"])

        self._save_long_term()

        return {"cleaned": cleaned}

    # ==================== STATS & EXPORT ====================

    def get_memory_stats(self) -> Dict[str, Any]:
        """Memory stats"""
        return {
            "short_term_count": len(self.short_term),
            "long_term_facts": len(self.long_term.get("facts", [])),
            "long_term_patterns": len(self.long_term.get("patterns", [])),
            "learned_skills": len(self.long_term.get("learned_skills", [])),
            "important_events": len(self.long_term.get("important_events", [])),
            "corrections": len(self.long_term.get("corrections", [])),
            "successful_responses": len(self.long_term.get("successful_responses", [])),
            "failed_responses": len(self.long_term.get("failed_responses", [])),
            "conversation_length": len(self.working_memory.get("conversation_history", [])),
            "user_info_keys": list(self.long_term.get("user_info", {}).keys()),
            "session_start": self.working_memory.get("session_start")
        }

    def export_memory(self, file_path: str) -> Dict[str, Any]:
        """Export all memory to file"""
        try:
            export_data = {
                "long_term": self.long_term,
                "working_memory": self.working_memory,
                "short_term": list(self.short_term),
                "exported_at": datetime.now().isoformat()
            }

            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=2, ensure_ascii=False)

            return {"success": True, "file": file_path}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def import_memory(self, file_path: str) -> Dict[str, Any]:
        """Import memory from file"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                import_data = json.load(f)

            if "long_term" in import_data:
                # Merge with existing
                imported_facts = import_data["long_term"].get("facts", [])
                for fact in imported_facts:
                    self.remember_fact(fact.get("fact", ""), source="import")

            return {"success": True, "imported": True}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_state_for_save(self) -> Dict[str, Any]:
        """Get complete state for saving (used during restart)"""
        return {
            "short_term": list(self.short_term),
            "working_memory": self.working_memory,
            "timestamp": datetime.now().isoformat()
        }

    def restore_state(self, saved_state: Dict[str, Any]):
        """Restore state from saved data"""
        if "short_term" in saved_state:
            for item in saved_state["short_term"]:
                self.short_term.append(item)

        if "working_memory" in saved_state:
            wm = saved_state["working_memory"]
            if "conversation_history" in wm:
                self.working_memory["conversation_history"] = wm["conversation_history"]
            if "current_context" in wm:
                self.working_memory["current_context"] = wm["current_context"]