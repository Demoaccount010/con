"""
Code Modifier - JEEVA apna code khud modify kar sake
Safe code modification with backup and validation
"""

import os
import ast
import shutil
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional
import json


class CodeModifier:
    """
    Self-modification system
    - Apna code read karo
    - Modifications karo
    - Backup lo
    - Safely apply karo
    - Rollback if needed
    """

    def __init__(self, base_path: str = ".", backup_path: str = "data/backups"):
        self.base_path = Path(base_path)
        self.backup_path = Path(backup_path)
        self.backup_path.mkdir(parents=True, exist_ok=True)
        
        self.modification_history = []
        self.pending_modifications = []
        self.max_backups = 50

    def read_file(self, file_path: str) -> Dict[str, Any]:
        """
        File read karo
        
        Args:
            file_path: Relative path to file
            
        Returns:
            Dict with file content and metadata
        """
        full_path = self.base_path / file_path
        
        if not full_path.exists():
            return {
                "success": False,
                "error": f"File not found: {file_path}",
                "can_create": True
            }
        
        try:
            content = full_path.read_text(encoding='utf-8')
            
            return {
                "success": True,
                "path": file_path,
                "content": content,
                "lines": len(content.splitlines()),
                "size": len(content),
                "modified": datetime.fromtimestamp(full_path.stat().st_mtime).isoformat()
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def write_file(self, file_path: str, content: str, create_backup: bool = True) -> Dict[str, Any]:
        """
        File write karo
        
        Args:
            file_path: Relative path to file
            content: Content to write
            create_backup: Whether to create backup first
            
        Returns:
            Dict with result
        """
        full_path = self.base_path / file_path
        
        try:
            if create_backup and full_path.exists():
                backup_result = self.create_backup(file_path)
                if not backup_result.get("success"):
                    return {"success": False, "error": f"Backup failed: {backup_result.get('error')}"}
            
            full_path.parent.mkdir(parents=True, exist_ok=True)
            
            full_path.write_text(content, encoding='utf-8')
            
            return {
                "success": True,
                "path": file_path,
                "size": len(content),
                "lines": len(content.splitlines())
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def analyze_file(self, file_path: str) -> Dict[str, Any]:
        """
        Python file analyze karo
        
        Args:
            file_path: Path to Python file
            
        Returns:
            Dict with file analysis
        """
        read_result = self.read_file(file_path)
        if not read_result.get("success"):
            return read_result
        
        content = read_result["content"]
        
        try:
            tree = ast.parse(content)
            
            analysis = {
                "success": True,
                "path": file_path,
                "classes": [],
                "functions": [],
                "imports": [],
                "global_variables": [],
                "lines": read_result["lines"],
                "size": read_result["size"]
            }
            
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    methods = []
                    for item in node.body:
                        if isinstance(item, ast.FunctionDef):
                            methods.append(item.name)
                    
                    analysis["classes"].append({
                        "name": node.name,
                        "line": node.lineno,
                        "methods": methods,
                        "method_count": len(methods)
                    })
                    
                elif isinstance(node, ast.FunctionDef):
                    is_method = False
                    for cls in analysis["classes"]:
                        if node.name in cls.get("methods", []):
                            is_method = True
                            break
                    
                    if not is_method:
                        analysis["functions"].append({
                            "name": node.name,
                            "line": node.lineno,
                            "args": [arg.arg for arg in node.args.args],
                            "has_return": any(isinstance(n, ast.Return) for n in ast.walk(node))
                        })
                        
                elif isinstance(node, ast.Import):
                    for alias in node.names:
                        analysis["imports"].append({
                            "type": "import",
                            "name": alias.name,
                            "alias": alias.asname
                        })
                        
                elif isinstance(node, ast.ImportFrom):
                    analysis["imports"].append({
                        "type": "from",
                        "module": node.module,
                        "names": [alias.name for alias in node.names]
                    })
            
            return analysis
            
        except SyntaxError as e:
            return {
                "success": False,
                "error": f"Syntax error in file: {e.msg}",
                "line": e.lineno,
                "offset": e.offset
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def create_backup(self, file_path: str) -> Dict[str, Any]:
        """
        File ka backup lo
        
        Args:
            file_path: Path to file to backup
            
        Returns:
            Dict with backup info
        """
        full_path = self.base_path / file_path
        
        if not full_path.exists():
            return {"success": False, "error": f"File not found: {file_path}"}
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        safe_name = file_path.replace("/", "_").replace("\\", "_")
        backup_name = f"{Path(safe_name).stem}_{timestamp}{Path(file_path).suffix}"
        backup_file = self.backup_path / backup_name
        
        try:
            shutil.copy2(full_path, backup_file)
            
            self._cleanup_old_backups(file_path)
            
            return {
                "success": True,
                "original": file_path,
                "backup": str(backup_file),
                "timestamp": timestamp,
                "size": backup_file.stat().st_size
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def _cleanup_old_backups(self, file_path: str):
        """Remove old backups keeping only max_backups"""
        safe_name = file_path.replace("/", "_").replace("\\", "_")
        stem = Path(safe_name).stem
        
        backups = list(self.backup_path.glob(f"{stem}_*"))
        
        if len(backups) > self.max_backups:
            backups.sort(key=lambda x: x.stat().st_mtime)
            for old_backup in backups[:-self.max_backups]:
                try:
                    old_backup.unlink()
                except Exception:
                    pass

    def get_backups(self, file_path: str = None) -> List[Dict[str, Any]]:
        """Get list of backups"""
        backups = []
        
        if file_path:
            safe_name = file_path.replace("/", "_").replace("\\", "_")
            stem = Path(safe_name).stem
            pattern = f"{stem}_*"
        else:
            pattern = "*"
        
        for backup_file in self.backup_path.glob(pattern):
            try:
                backups.append({
                    "file": backup_file.name,
                    "path": str(backup_file),
                    "size": backup_file.stat().st_size,
                    "created": datetime.fromtimestamp(backup_file.stat().st_mtime).isoformat()
                })
            except Exception:
                pass
        
        backups.sort(key=lambda x: x["created"], reverse=True)
        
        return backups

    def restore_backup(self, backup_path: str, target_path: str) -> Dict[str, Any]:
        """
        Backup se restore karo
        
        Args:
            backup_path: Path to backup file
            target_path: Where to restore
            
        Returns:
            Dict with result
        """
        backup_file = Path(backup_path)
        
        if not backup_file.exists():
            backup_file = self.backup_path / backup_path
        
        if not backup_file.exists():
            return {"success": False, "error": f"Backup not found: {backup_path}"}
        
        target_file = self.base_path / target_path
        
        try:
            if target_file.exists():
                self.create_backup(target_path)
            
            target_file.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(backup_file, target_file)
            
            return {
                "success": True,
                "restored_from": str(backup_file),
                "restored_to": target_path
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def validate_python_code(self, code: str) -> Dict[str, Any]:
        """
        Python code validate karo
        
        Args:
            code: Python code to validate
            
        Returns:
            Dict with validation result
        """
        try:
            ast.parse(code)
            
            try:
                import black
                formatted = black.format_str(code, mode=black.Mode())
                formatting_changed = code != formatted
            except ImportError:
                formatted = code
                formatting_changed = False
            except Exception:
                formatted = code
                formatting_changed = False
            
            return {
                "valid": True,
                "formatted_code": formatted,
                "formatting_applied": formatting_changed
            }
            
        except SyntaxError as e:
            return {
                "valid": False,
                "error": f"Syntax error: {e.msg}",
                "line": e.lineno,
                "offset": e.offset,
                "text": e.text
            }

    def propose_modification(
        self,
        file_path: str,
        modification_type: str,
        details: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Modification propose karo (apply nahi, sirf plan)
        
        Args:
            file_path: File to modify
            modification_type: Type of modification
            details: Modification details
            
        Returns:
            Dict with proposal info
        """
        modification = {
            "id": len(self.pending_modifications) + 1,
            "file_path": file_path,
            "type": modification_type,
            "details": details,
            "proposed_at": datetime.now().isoformat(),
            "status": "pending"
        }
        
        self.pending_modifications.append(modification)
        
        return {
            "success": True,
            "modification_id": modification["id"],
            "message": f"Modification proposed. ID: {modification['id']}. Use confirm_modification() to apply."
        }

    def get_pending_modifications(self) -> List[Dict]:
        """Get pending modifications"""
        return [m for m in self.pending_modifications if m["status"] == "pending"]

    def confirm_modification(self, modification_id: int) -> Dict[str, Any]:
        """
        Proposed modification apply karo
        
        Args:
            modification_id: ID of modification to apply
            
        Returns:
            Dict with result
        """
        modification = None
        for mod in self.pending_modifications:
            if mod["id"] == modification_id:
                modification = mod
                break
        
        if not modification:
            return {"success": False, "error": f"Modification {modification_id} not found"}
        
        if modification["status"] != "pending":
            return {"success": False, "error": f"Modification already {modification['status']}"}
        
        backup_result = self.create_backup(modification["file_path"])
        if not backup_result.get("success") and "not found" not in backup_result.get("error", ""):
            return backup_result
        
        try:
            result = self._apply_modification(modification)
            
            if result.get("success"):
                modification["status"] = "applied"
                modification["applied_at"] = datetime.now().isoformat()
                modification["backup"] = backup_result.get("backup")
                self.modification_history.append(modification)
            else:
                modification["status"] = "failed"
                modification["error"] = result.get("error")
            
            return result
            
        except Exception as e:
            modification["status"] = "failed"
            modification["error"] = str(e)
            return {"success": False, "error": str(e)}

    def _apply_modification(self, modification: Dict) -> Dict[str, Any]:
        """Apply the modification"""
        file_path = modification["file_path"]
        mod_type = modification["type"]
        details = modification["details"]
        
        read_result = self.read_file(file_path)
        
        if read_result.get("success"):
            original_content = read_result["content"]
        else:
            original_content = ""
        
        new_content = original_content
        
        if mod_type == "add_function":
            new_content = original_content.rstrip() + "\n\n\n" + details.get("code", "")
            
        elif mod_type == "add_class":
            new_content = original_content.rstrip() + "\n\n\n" + details.get("code", "")
            
        elif mod_type == "add_import":
            import_line = details.get("import_line", "")
            lines = original_content.splitlines()
            
            last_import = -1
            for i, line in enumerate(lines):
                if line.startswith("import ") or line.startswith("from "):
                    last_import = i
            
            if last_import >= 0:
                lines.insert(last_import + 1, import_line)
            else:
                lines.insert(0, import_line)
            
            new_content = "\n".join(lines)
            
        elif mod_type == "replace_content":
            new_content = details.get("new_content", original_content)
            
        elif mod_type == "append":
            new_content = original_content + details.get("content", "")
            
        elif mod_type == "prepend":
            new_content = details.get("content", "") + original_content
            
        elif mod_type == "replace_function":
            func_name = details.get("function_name")
            new_code = details.get("new_code")
            new_content = self._replace_function(original_content, func_name, new_code)
            
        else:
            return {"success": False, "error": f"Unknown modification type: {mod_type}"}
        
        validation = self.validate_python_code(new_content)
        if not validation.get("valid"):
            return {"success": False, "error": validation.get("error")}
        
        new_content = validation.get("formatted_code", new_content)
        
        return self.write_file(file_path, new_content, create_backup=False)

    def _replace_function(self, content: str, func_name: str, new_code: str) -> str:
        """Replace a function in content"""
        lines = content.splitlines()
        result = []
        skip_until_next_def = False
        indent_level = 0
        func_found = False
        
        for i, line in enumerate(lines):
            if f"def {func_name}" in line and "(" in line:
                skip_until_next_def = True
                indent_level = len(line) - len(line.lstrip())
                func_found = True
                result.append(new_code)
                continue
            
            if skip_until_next_def:
                stripped = line.lstrip()
                current_indent = len(line) - len(stripped)
                
                if stripped and current_indent <= indent_level and not stripped.startswith("#"):
                    if stripped.startswith("def ") or stripped.startswith("class ") or stripped.startswith("@"):
                        skip_until_next_def = False
                        result.append(line)
                continue
            
            result.append(line)
        
        if not func_found:
            result.append("")
            result.append(new_code)
        
        return "\n".join(result)

    def cancel_modification(self, modification_id: int) -> Dict[str, Any]:
        """Cancel a pending modification"""
        for mod in self.pending_modifications:
            if mod["id"] == modification_id and mod["status"] == "pending":
                mod["status"] = "cancelled"
                mod["cancelled_at"] = datetime.now().isoformat()
                return {"success": True, "message": f"Modification {modification_id} cancelled"}
        
        return {"success": False, "error": f"Pending modification {modification_id} not found"}

    def rollback(self, modification_id: int) -> Dict[str, Any]:
        """
        Modification rollback karo
        
        Args:
            modification_id: ID of modification to rollback
            
        Returns:
            Dict with result
        """
        modification = None
        for mod in self.modification_history:
            if mod["id"] == modification_id:
                modification = mod
                break
        
        if not modification:
            return {"success": False, "error": f"Modification {modification_id} not found in history"}
        
        backup_path = modification.get("backup")
        if not backup_path or not Path(backup_path).exists():
            return {"success": False, "error": "Backup file not found"}
        
        result = self.restore_backup(backup_path, modification["file_path"])
        
        if result.get("success"):
            modification["status"] = "rolled_back"
            modification["rolled_back_at"] = datetime.now().isoformat()
        
        return result

    def get_modification_history(self, limit: int = 20) -> List[Dict]:
        """Get modification history"""
        return self.modification_history[-limit:]

    def clear_history(self):
        """Clear modification history"""
        self.modification_history = []

    def get_stats(self) -> Dict[str, Any]:
        """Get modification statistics"""
        applied = sum(1 for m in self.modification_history if m.get("status") == "applied")
        failed = sum(1 for m in self.modification_history if m.get("status") == "failed")
        rolled_back = sum(1 for m in self.modification_history if m.get("status") == "rolled_back")
        
        return {
            "total_modifications": len(self.modification_history),
            "applied": applied,
            "failed": failed,
            "rolled_back": rolled_back,
            "pending": len(self.get_pending_modifications()),
            "backups": len(list(self.backup_path.glob("*")))
        }