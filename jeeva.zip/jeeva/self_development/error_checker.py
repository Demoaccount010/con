"""
Error Checker - Code check karo before running
Syntax, security, aur runtime errors check karta hai
"""

import ast
import sys
import traceback
import subprocess
import tempfile
import re
from typing import Dict, Any, List, Optional
from pathlib import Path
from datetime import datetime


class ErrorChecker:
    """
    Code error check karo
    - Syntax errors
    - Import errors
    - Security issues
    - Runtime errors (sandbox mein)
    - Code quality checks
    """

    def __init__(self):
        self.last_check_result = None
        self.check_history = []
        self.max_history = 50
        
        self.dangerous_patterns = [
            (r'\beval\s*\(', "eval() is dangerous - can execute arbitrary code"),
            (r'\bexec\s*\(', "exec() is dangerous - can execute arbitrary code"),
            (r'__import__\s*\(', "Dynamic imports can be dangerous"),
            (r'\bos\.system\s*\(', "os.system() can execute shell commands"),
            (r'\bos\.popen\s*\(', "os.popen() can execute shell commands"),
            (r'subprocess\.call\s*\(.*shell\s*=\s*True', "subprocess with shell=True is risky"),
            (r'subprocess\.run\s*\(.*shell\s*=\s*True', "subprocess with shell=True is risky"),
            (r'\bopen\s*\([^)]*["\'][wa]["\']', "File write operations need caution"),
            (r'shutil\.rmtree\s*\(', "Recursive deletion is dangerous"),
            (r'\brm\s+-rf\b', "Dangerous file deletion command"),
            (r'pickle\.loads?\s*\(', "pickle can execute arbitrary code"),
            (r'input\s*\(', "input() can hang the process"),
            (r'compile\s*\(', "compile() can be used for code injection"),
            (r'globals\s*\(\s*\)\s*\[', "Modifying globals is risky"),
            (r'locals\s*\(\s*\)\s*\[', "Modifying locals is risky"),
            (r'setattr\s*\(', "setattr can modify object attributes"),
            (r'delattr\s*\(', "delattr can delete object attributes"),
            (r'__class__\s*=', "Modifying __class__ is dangerous"),
        ]
        
        self.warning_patterns = [
            (r'while\s+True\s*:', "Infinite loop detected - ensure break condition exists"),
            (r'except\s*:', "Bare except clause - catches all exceptions including KeyboardInterrupt"),
            (r'from\s+\S+\s+import\s+\*', "Wildcard import - may cause namespace pollution"),
            (r'#\s*TODO', "TODO comment found"),
            (r'#\s*FIXME', "FIXME comment found"),
            (r'#\s*HACK', "HACK comment found"),
            (r'pass\s*$', "Empty pass statement"),
            (r'print\s*\(', "Print statement found - consider using logging"),
        ]

    def check_syntax(self, code: str) -> Dict[str, Any]:
        """
        Syntax errors check karo
        
        Args:
            code: Python code to check
            
        Returns:
            Dict with syntax check result
        """
        try:
            ast.parse(code)
            return {
                "has_errors": False,
                "errors": [],
                "valid": True
            }
        except SyntaxError as e:
            return {
                "has_errors": True,
                "valid": False,
                "errors": [{
                    "type": "SyntaxError",
                    "message": e.msg,
                    "line": e.lineno,
                    "offset": e.offset,
                    "text": e.text.strip() if e.text else None
                }]
            }
        except Exception as e:
            return {
                "has_errors": True,
                "valid": False,
                "errors": [{
                    "type": type(e).__name__,
                    "message": str(e)
                }]
            }

    def check_imports(self, code: str) -> Dict[str, Any]:
        """
        Check if all imports are available
        
        Args:
            code: Python code to check
            
        Returns:
            Dict with import check result
        """
        try:
            tree = ast.parse(code)
            imports = []
            
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        imports.append({
                            "type": "import",
                            "module": alias.name.split('.')[0],
                            "full_name": alias.name
                        })
                elif isinstance(node, ast.ImportFrom):
                    if node.module:
                        imports.append({
                            "type": "from",
                            "module": node.module.split('.')[0],
                            "full_name": node.module
                        })
            
            missing = []
            available = []
            
            checked_modules = set()
            for imp in imports:
                module = imp["module"]
                if module in checked_modules:
                    continue
                checked_modules.add(module)
                
                try:
                    __import__(module)
                    available.append(module)
                except ImportError:
                    missing.append(module)
            
            return {
                "has_errors": len(missing) > 0,
                "imports_found": list(checked_modules),
                "available": available,
                "missing": missing,
                "total_imports": len(imports)
            }
            
        except SyntaxError:
            return {
                "has_errors": True,
                "error": "Cannot parse code - syntax error"
            }
        except Exception as e:
            return {
                "has_errors": True,
                "error": str(e)
            }

    def check_security(self, code: str) -> Dict[str, Any]:
        """
        Security issues check karo
        
        Args:
            code: Python code to check
            
        Returns:
            Dict with security check result
        """
        issues = []
        warnings = []
        
        for pattern, message in self.dangerous_patterns:
            matches = re.finditer(pattern, code, re.IGNORECASE)
            for match in matches:
                line_num = code[:match.start()].count('\n') + 1
                issues.append({
                    "type": "security",
                    "severity": "high",
                    "pattern": pattern,
                    "message": message,
                    "line": line_num,
                    "match": match.group()
                })
        
        for pattern, message in self.warning_patterns:
            matches = re.finditer(pattern, code, re.MULTILINE)
            for match in matches:
                line_num = code[:match.start()].count('\n') + 1
                warnings.append({
                    "type": "warning",
                    "severity": "low",
                    "message": message,
                    "line": line_num
                })
        
        high_severity = [i for i in issues if i.get("severity") == "high"]
        
        return {
            "has_issues": len(issues) > 0,
            "has_warnings": len(warnings) > 0,
            "issues": issues,
            "warnings": warnings,
            "is_safe": len(high_severity) == 0,
            "risk_level": "high" if len(high_severity) > 2 else "medium" if len(high_severity) > 0 else "low"
        }

    def check_code_quality(self, code: str) -> Dict[str, Any]:
        """
        Code quality check karo
        
        Args:
            code: Python code to check
            
        Returns:
            Dict with quality metrics
        """
        lines = code.splitlines()
        
        total_lines = len(lines)
        blank_lines = sum(1 for line in lines if not line.strip())
        comment_lines = sum(1 for line in lines if line.strip().startswith('#'))
        code_lines = total_lines - blank_lines - comment_lines
        
        try:
            tree = ast.parse(code)
            
            functions = []
            classes = []
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    func_lines = node.end_lineno - node.lineno + 1 if hasattr(node, 'end_lineno') else 0
                    has_docstring = (
                        node.body and 
                        isinstance(node.body[0], ast.Expr) and 
                        isinstance(node.body[0].value, (ast.Str, ast.Constant))
                    )
                    functions.append({
                        "name": node.name,
                        "lines": func_lines,
                        "has_docstring": has_docstring,
                        "args_count": len(node.args.args)
                    })
                elif isinstance(node, ast.ClassDef):
                    has_docstring = (
                        node.body and 
                        isinstance(node.body[0], ast.Expr) and 
                        isinstance(node.body[0].value, (ast.Str, ast.Constant))
                    )
                    classes.append({
                        "name": node.name,
                        "has_docstring": has_docstring,
                        "method_count": sum(1 for n in node.body if isinstance(n, ast.FunctionDef))
                    })
            
            long_functions = [f for f in functions if f["lines"] > 50]
            undocumented = [f for f in functions if not f["has_docstring"]]
            
            issues = []
            if long_functions:
                issues.append(f"{len(long_functions)} functions are too long (>50 lines)")
            if undocumented:
                issues.append(f"{len(undocumented)} functions lack docstrings")
            
            score = 100
            if long_functions:
                score -= len(long_functions) * 5
            if undocumented:
                score -= len(undocumented) * 3
            if blank_lines < total_lines * 0.1:
                score -= 5
            
            score = max(0, min(100, score))
            
            return {
                "total_lines": total_lines,
                "code_lines": code_lines,
                "blank_lines": blank_lines,
                "comment_lines": comment_lines,
                "functions": len(functions),
                "classes": len(classes),
                "long_functions": len(long_functions),
                "undocumented_functions": len(undocumented),
                "quality_score": score,
                "issues": issues
            }
            
        except SyntaxError:
            return {
                "total_lines": total_lines,
                "error": "Cannot analyze - syntax error"
            }

    def test_run(self, code: str, timeout: int = 5) -> Dict[str, Any]:
        """
        Code ko sandbox mein test run karo
        
        Args:
            code: Python code to run
            timeout: Maximum execution time in seconds
            
        Returns:
            Dict with execution result
        """
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
            f.write(code)
            temp_path = f.name
        
        try:
            result = subprocess.run(
                [sys.executable, temp_path],
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=tempfile.gettempdir()
            )
            
            return {
                "success": result.returncode == 0,
                "return_code": result.returncode,
                "stdout": result.stdout[:2000] if result.stdout else "",
                "stderr": result.stderr[:2000] if result.stderr else "",
                "timed_out": False
            }
            
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "error": f"Code execution timed out after {timeout} seconds",
                "timed_out": True
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
        finally:
            try:
                Path(temp_path).unlink()
            except Exception:
                pass

    def full_check(self, code: str, run_test: bool = False) -> Dict[str, Any]:
        """
        Complete check - syntax, imports, security, quality
        
        Args:
            code: Python code to check
            run_test: Whether to test run the code
            
        Returns:
            Dict with complete check results
        """
        results = {
            "overall_safe": True,
            "can_run": True,
            "checks": {},
            "summary": [],
            "timestamp": datetime.now().isoformat()
        }
        
        syntax_result = self.check_syntax(code)
        results["checks"]["syntax"] = syntax_result
        
        if syntax_result["has_errors"]:
            results["overall_safe"] = False
            results["can_run"] = False
            results["blocking_issue"] = "Syntax errors found"
            results["summary"].append("❌ Syntax errors - cannot proceed")
            
            self._record_check(code, results)
            return results
        else:
            results["summary"].append("✅ Syntax OK")
        
        import_result = self.check_imports(code)
        results["checks"]["imports"] = import_result
        
        if import_result.get("has_errors"):
            missing = import_result.get("missing", [])
            results["can_run"] = False
            results["summary"].append(f"⚠️ Missing imports: {missing}")
        else:
            results["summary"].append("✅ Imports OK")
        
        security_result = self.check_security(code)
        results["checks"]["security"] = security_result
        
        if security_result.get("has_issues"):
            high_risk = [i for i in security_result.get("issues", []) if i.get("severity") == "high"]
            if high_risk:
                results["overall_safe"] = False
                results["summary"].append(f"🔴 {len(high_risk)} security issues found")
            else:
                results["summary"].append(f"🟡 {len(security_result.get('issues', []))} security warnings")
        else:
            results["summary"].append("✅ Security OK")
        
        quality_result = self.check_code_quality(code)
        results["checks"]["quality"] = quality_result
        
        score = quality_result.get("quality_score", 0)
        if score >= 80:
            results["summary"].append(f"✅ Quality: {score}/100")
        elif score >= 50:
            results["summary"].append(f"🟡 Quality: {score}/100")
        else:
            results["summary"].append(f"🔴 Quality: {score}/100")
        
        if run_test and results["can_run"] and results["overall_safe"]:
            test_result = self.test_run(code)
            results["checks"]["test_run"] = test_result
            
            if test_result.get("success"):
                results["summary"].append("✅ Test run passed")
            else:
                results["summary"].append(f"⚠️ Test run failed: {test_result.get('error', 'Unknown error')[:50]}")
        
        self.last_check_result = results
        self._record_check(code, results)
        
        return results

    def _record_check(self, code: str, results: Dict):
        """Record check in history"""
        self.check_history.append({
            "code_hash": hash(code),
            "code_preview": code[:100],
            "overall_safe": results.get("overall_safe"),
            "can_run": results.get("can_run"),
            "timestamp": datetime.now().isoformat()
        })
        
        if len(self.check_history) > self.max_history:
            self.check_history = self.check_history[-self.max_history:]

    def get_fix_suggestions(self, check_result: Dict = None) -> List[Dict[str, str]]:
        """
        Get fix suggestions for errors
        
        Args:
            check_result: Check result dict (uses last result if None)
            
        Returns:
            List of fix suggestions
        """
        if check_result is None:
            check_result = self.last_check_result
        
        if not check_result:
            return []
        
        suggestions = []
        
        checks = check_result.get("checks", {})
        
        if "syntax" in checks and checks["syntax"].get("has_errors"):
            for error in checks["syntax"].get("errors", []):
                suggestions.append({
                    "type": "syntax",
                    "priority": "high",
                    "message": f"Fix syntax error at line {error.get('line')}: {error.get('message')}",
                    "line": error.get("line")
                })
        
        if "imports" in checks:
            for missing in checks["imports"].get("missing", []):
                suggestions.append({
                    "type": "import",
                    "priority": "high",
                    "message": f"Install missing package: pip install {missing}",
                    "package": missing
                })
        
        if "security" in checks:
            for issue in checks["security"].get("issues", []):
                suggestions.append({
                    "type": "security",
                    "priority": "high" if issue.get("severity") == "high" else "medium",
                    "message": issue.get("message"),
                    "line": issue.get("line")
                })
        
        if "quality" in checks:
            for issue in checks["quality"].get("issues", []):
                suggestions.append({
                    "type": "quality",
                    "priority": "low",
                    "message": issue
                })
        
        return suggestions

    def is_safe_to_run(self, code: str) -> bool:
        """Quick check if code is safe to run"""
        syntax = self.check_syntax(code)
        if syntax.get("has_errors"):
            return False
        
        security = self.check_security(code)
        if not security.get("is_safe"):
            return False
        
        return True

    def get_check_history(self, limit: int = 20) -> List[Dict]:
        """Get check history"""
        return self.check_history[-limit:]

    def get_stats(self) -> Dict[str, Any]:
        """Get checker statistics"""
        safe_count = sum(1 for c in self.check_history if c.get("overall_safe"))
        runnable_count = sum(1 for c in self.check_history if c.get("can_run"))
        
        return {
            "total_checks": len(self.check_history),
            "safe_code_count": safe_count,
            "runnable_count": runnable_count,
            "safety_rate": round(safe_count / len(self.check_history) * 100, 1) if self.check_history else 0
        }