#!/usr/bin/env python3
"""
JEEVA Supervisor - Manages JEEVA process lifecycle
Ye file KABHI modify nahi hoti - stable rehti hai

Usage:
    python jeeva_supervisor.py

Features:
    - Start/Stop/Restart JEEVA
    - Health monitoring
    - Crash recovery
    - IPC communication
"""

import os
import sys
import json
import time
import signal
import socket
import subprocess
import threading
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any


class JeevaSupervisor:
    """
    JEEVA process ko manage karta hai
    - Start/Stop/Restart
    - Health monitoring
    - Crash recovery
    - State management
    """

    def __init__(self):
        self.base_dir = Path(__file__).parent
        self.data_dir = self.base_dir / "data" / "supervisor"
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.pid_file = self.data_dir / "jeeva.pid"
        self.state_file = self.data_dir / "jeeva_state.json"
        self.log_file = self.data_dir / "supervisor.log"
        
        self.socket_port = 19999
        
        self.jeeva_process: Optional[subprocess.Popen] = None
        
        self.running = False
        self.restart_count = 0
        self.max_restarts = 10
        self.restart_window = 60
        self.recent_restarts = []
        
        self.python = sys.executable
        self.main_script = self.base_dir / "main.py"

    def log(self, message: str, level: str = "INFO"):
        """Log message"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_line = f"[{timestamp}] [{level}] {message}"
        print(log_line)
        
        try:
            with open(self.log_file, 'a', encoding='utf-8') as f:
                f.write(log_line + "\n")
        except Exception:
            pass

    def start_jeeva(self, restored: bool = False) -> bool:
        """
        JEEVA process start karo
        """
        if self.jeeva_process and self.jeeva_process.poll() is None:
            self.log("JEEVA already running!", "WARN")
            return False
        
        if not self.main_script.exists():
            self.log(f"Main script not found: {self.main_script}", "ERROR")
            return False
        
        args = [self.python, str(self.main_script)]
        
        if restored:
            args.append("--restored")
        
        try:
            self.log(f"Starting JEEVA: {' '.join(args)}")
            
            self.jeeva_process = subprocess.Popen(
                args,
                cwd=str(self.base_dir),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                bufsize=1,
                universal_newlines=True
            )
            
            self.pid_file.write_text(str(self.jeeva_process.pid))
            
            self.log(f"JEEVA started with PID: {self.jeeva_process.pid}")
            
            self.recent_restarts.append(time.time())
            self.recent_restarts = [
                t for t in self.recent_restarts
                if time.time() - t < self.restart_window
            ]
            
            output_thread = threading.Thread(target=self._handle_output, daemon=True)
            output_thread.start()
            
            return True
            
        except Exception as e:
            self.log(f"Failed to start JEEVA: {e}", "ERROR")
            return False

    def _handle_output(self):
        """Handle JEEVA process output"""
        if not self.jeeva_process:
            return
        
        try:
            for line in self.jeeva_process.stdout:
                line = line.strip()
                if line:
                    print(f"[JEEVA] {line}")
        except Exception:
            pass

    def stop_jeeva(self, timeout: float = 10.0) -> bool:
        """
        JEEVA gracefully stop karo
        """
        if not self.jeeva_process:
            self.log("No JEEVA process to stop", "WARN")
            return True
        
        if self.jeeva_process.poll() is not None:
            self.log("JEEVA already stopped", "WARN")
            return True
        
        try:
            self.log(f"Stopping JEEVA (PID: {self.jeeva_process.pid})...")
            
            self.jeeva_process.terminate()
            
            try:
                self.jeeva_process.wait(timeout=timeout)
                self.log("JEEVA stopped gracefully")
            except subprocess.TimeoutExpired:
                self.log("JEEVA not responding, force killing...", "WARN")
                self.jeeva_process.kill()
                self.jeeva_process.wait()
                self.log("JEEVA force killed")
            
            if self.pid_file.exists():
                self.pid_file.unlink()
            
            return True
            
        except Exception as e:
            self.log(f"Error stopping JEEVA: {e}", "ERROR")
            return False

    def restart_jeeva(self, reason: str = "Requested") -> bool:
        """
        JEEVA restart karo
        """
        self.log(f"Restart requested: {reason}")
        
        if len(self.recent_restarts) >= self.max_restarts:
            self.log(f"Too many restarts ({len(self.recent_restarts)} in {self.restart_window}s). Cooling down...", "WARN")
            time.sleep(30)
            self.recent_restarts = []
        
        self.stop_jeeva()
        
        time.sleep(2)
        
        return self.start_jeeva(restored=True)

    def health_check(self) -> Dict[str, Any]:
        """
        JEEVA health check
        """
        if not self.jeeva_process:
            return {"healthy": False, "reason": "No process"}
        
        poll_result = self.jeeva_process.poll()
        
        if poll_result is not None:
            return {
                "healthy": False,
                "reason": f"Process exited with code {poll_result}"
            }
        
        return {
            "healthy": True,
            "pid": self.jeeva_process.pid,
            "uptime_restarts": len(self.recent_restarts)
        }

    def monitor_loop(self):
        """
        Continuous monitoring loop
        """
        self.log("Starting monitor loop...")
        
        while self.running:
            if self.jeeva_process:
                poll_result = self.jeeva_process.poll()
                
                if poll_result is not None:
                    self.log(f"JEEVA exited with code {poll_result}", "WARN")
                    
                    if self.running:
                        self.log("Auto-restarting JEEVA...", "INFO")
                        time.sleep(2)
                        self.start_jeeva(restored=True)
            
            time.sleep(2)

    def start_ipc_server(self):
        """
        IPC server for JEEVA communication
        """
        def server_loop():
            try:
                server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                server.bind(('localhost', self.socket_port))
                server.listen(1)
                server.settimeout(1)
                
                self.log(f"IPC server listening on port {self.socket_port}")
                
                while self.running:
                    try:
                        client, addr = server.accept()
                        data = client.recv(4096).decode('utf-8')
                        
                        if data:
                            response = self.handle_ipc_message(data)
                            client.send(response.encode('utf-8'))
                        
                        client.close()
                    except socket.timeout:
                        continue
                    except Exception as e:
                        self.log(f"IPC error: {e}", "ERROR")
                
                server.close()
            except Exception as e:
                self.log(f"IPC server error: {e}", "ERROR")
        
        self.ipc_thread = threading.Thread(target=server_loop, daemon=True)
        self.ipc_thread.start()

    def handle_ipc_message(self, message: str) -> str:
        """
        Handle IPC message from JEEVA
        """
        try:
            data = json.loads(message)
            command = data.get("command")
            
            if command == "restart":
                reason = data.get("reason", "Requested by JEEVA")
                self.log(f"Received restart request: {reason}")
                
                threading.Thread(
                    target=lambda: self.restart_jeeva(reason),
                    daemon=True
                ).start()
                
                return json.dumps({"status": "restart_scheduled"})
            
            elif command == "health":
                return json.dumps(self.health_check())
            
            elif command == "status":
                return json.dumps({
                    "running": self.running,
                    "jeeva_pid": self.jeeva_process.pid if self.jeeva_process else None,
                    "restarts": len(self.recent_restarts)
                })
            
            elif command == "stop":
                self.log("Received stop request")
                self.running = False
                return json.dumps({"status": "stopping"})
            
            else:
                return json.dumps({"error": f"Unknown command: {command}"})
                
        except Exception as e:
            return json.dumps({"error": str(e)})

    def handle_signal(self, signum, frame):
        """Handle shutdown signals"""
        self.log(f"Received signal {signum}, shutting down...")
        self.running = False

    def run(self):
        """
        Main supervisor run loop
        """
        self.running = True
        
        signal.signal(signal.SIGINT, self.handle_signal)
        signal.signal(signal.SIGTERM, self.handle_signal)
        
        print("=" * 60)
        print("🔧 JEEVA SUPERVISOR")
        print("=" * 60)
        self.log("Supervisor starting...")
        
        self.start_ipc_server()
        
        if not self.start_jeeva():
            self.log("Failed to start JEEVA initially", "ERROR")
            return
        
        try:
            self.monitor_loop()
        except KeyboardInterrupt:
            self.log("Interrupt received")
        except Exception as e:
            self.log(f"Monitor error: {e}", "ERROR")
        
        self.log("Supervisor shutting down...")
        self.stop_jeeva()
        self.log("Supervisor stopped")


def main():
    """Entry point"""
    supervisor = JeevaSupervisor()
    supervisor.run()


if __name__ == "__main__":
    main()