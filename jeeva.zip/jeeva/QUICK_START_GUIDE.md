# 🚀 JEEVA - Quick Start Guide (Hindi)

## 🎯 JEEVA Start Karne Ka Complete Guide

---

## ⚡ Quick Start (5 Minutes)

### Step 1: Dependencies Install Karo
```bash
# Folder mein jao
cd "Desktop\all bots\jeeva"

# Install karo (double-click)
install_dependencies.bat
```

### Step 2: Ollama Setup
```bash
# Terminal 1 - Ollama start karo (running rakhna hai!)
ollama serve

# Terminal 2 - Model download karo (~2GB, 5-10 min)
ollama pull llama3.2
```

### Step 3: Check Karo
```bash
python check_system.py
```
✅ All green? Great! Next step

❌ Red hai koi? Issues fix karo (neeche dekho)

### Step 4: Start JEEVA
```bash
# Double-click ya run karo
start_jeeva.bat
```

**Done! JEEVA ready hai! 🎉**

---

## 💬 Basic Usage Examples

### Example 1: Simple Chat
```
You: hello
JEEVA: Yo! Kya hal hai bhai?

You: tu kya kar sakta hai?
JEEVA: Bhai, main bahut kuch kar sakta hu:
       • File operations (create, read, write)
       • Code generation & execution
       • System information
       • Self-learning & improvement
       • Aur bhi bahut kuch!
       
       Kuch specific kaam bata, main help karunga!
```

---

### Example 2: File Operations
```
You: ek file bana hello.txt
JEEVA: ✅ Main ye kar sakta hu!
       
       📋 Steps:
          1. hello.txt file create karunga
          2. Basic content add karunga
          3. Save karke confirm karunga
       
       🔐 Permission chahiye. Karun? (haan/nahi)

You: haan
JEEVA: ✅ File created successfully!
       Location: ./hello.txt

You: is file ko read kar
JEEVA: 📄 File content:
       [File ka content dikhega]
```

---

### Example 3: Code Generation
```
You: calculator ka code likh
JEEVA: 💻 Code generate kiya hai:

```python
def calculator():
    """Simple calculator function"""
    print("Calculator")
    
    while True:
        try:
            num1 = float(input("First number: "))
            operator = input("Operator (+,-,*,/): ")
            num2 = float(input("Second number: "))
            
            if operator == '+':
                result = num1 + num2
            elif operator == '-':
                result = num1 - num2
            elif operator == '*':
                result = num1 * num2
            elif operator == '/':
                result = num1 / num2 if num2 != 0 else "Error: Div by 0"
            else:
                result = "Invalid operator"
            
            print(f"Result: {result}")
            
            cont = input("Continue? (y/n): ")
            if cont.lower() != 'y':
                break
                
        except ValueError:
            print("Error: Invalid input")

if __name__ == "__main__":
    calculator()
```

       ✅ Code error-free hai!
       🔐 Code run karun? (haan/nahi)

You: haan
JEEVA: [Code execute hoga with output]
```

---

### Example 4: System Info
```
You: system info bata
JEEVA: 💻 System Information:
       
       🖥️ OS: Windows 11
       🐍 Python: 3.10.11
       💾 RAM: 16 GB (8 GB used)
       💿 CPU: Intel Core i7 (45% usage)
       📊 Disk: 512 GB (250 GB free)
       🌐 Network: Connected
```

---

### Example 5: Self-Improvement
```
You: apne code ko better bana
JEEVA: 🔧 Self-modification request detected!
       
       📋 Analysis:
          Current state: Working fine
          Possible improvements:
          • Better error handling
          • Faster response time
          • More detailed logging
       
       ⚠️ Risks:
          • Code modification required
          • Restart may be needed
          • Backup will be created
       
       🔐 Explicit permission chahiye. Karun? (haan/nahi)

You: haan
JEEVA: 📦 Backup created: backup_20260204_183000
       🔧 Applying improvements...
       ✅ Improvements applied!
       🔄 Restarting for changes...
       
       [System restarts]
       
       ✅ Restart successful! Improvements active!
```

---

### Example 6: Build New Capability
```
You: weather check karne ki capability bana
JEEVA: 💡 New capability request!
       
       📋 Plan:
          Capability: Weather Checker
          
          Implementation:
          1. API integration module create karunga
          2. Location detection add karunga
          3. Weather data parsing karunga
          4. Testing karke activate karunga
       
       Requirements:
          • Network access required
          • API key may be needed
          • New file: tools/weather_tools.py
       
       ⚠️ Risks: Medium (network access)
       
       🔐 Permission chahiye. Bana dun? (haan/nahi)

You: haan
JEEVA: 🔨 Building capability...
       
       [Progress shown]
       
       ✅ Capability built successfully!
       ✅ Registered and activated!
       
       Ab tum bol sakte ho: "weather check kar Delhi ka"
```

---

## 🎨 Advanced Commands

### Learning Commands
```
You: "meri preferences yaad rakh"
You: "ye pattern seekh le"
You: "is tareeke se respond kar"
```

### Code Commands
```
You: "ye code explain kar [code]"
You: "is code ko optimize kar"
You: "is code mein bugs dhundh"
You: "test cases likh is function ke liye"
```

### Self-Development Commands
```
You: "apne [component] ko improve kar"
You: "[feature] add kar apne mein"
You: "apni memory system enhance kar"
```

### File Commands
```
You: "file list kar"
You: "folder structure dikha"
You: "file search kar [name]"
You: "file compare kar [file1] [file2]"
```

---

## ⚙️ Configuration

### Change Settings
```bash
# Edit config file
notepad config/settings.yaml
```

**Common settings:**
```yaml
agent:
  name: "JEEVA"          # Change agent name
  language: "hinglish"   # Language mode

ollama:
  thinking_model: "llama3.2"  # Change AI model

security:
  require_permission_for_code_changes: true  # Permission toggle
  sandbox_enabled: true                       # Sandbox mode

behavior:
  always_honest: true                    # Honesty mode
  show_thinking_process: false           # Show AI thinking
```

---

## 🐛 Troubleshooting

### Problem 1: Ollama Not Connected
```
Error: Could not connect to Ollama

Solution:
1. Check if Ollama is running:
   ollama serve

2. Check Ollama models:
   ollama list

3. Pull model if missing:
   ollama pull llama3.2
```

### Problem 2: Import Errors
```
Error: ModuleNotFoundError: No module named 'ollama'

Solution:
1. Run installer:
   install_dependencies.bat

2. Or manually:
   pip install ollama pyyaml rich prompt_toolkit psutil requests colorama black
```

### Problem 3: Permission Denied
```
Error: Permission denied

Solution:
1. Run as Administrator
2. Check file permissions
3. Check config/settings.yaml
```

### Problem 4: Data Directory Missing
```
Error: Directory not found: data/logs

Solution:
Run check_system.py - it will auto-create directories
```

---

## 📊 Performance Tips

### Faster Responses
```yaml
# config/settings.yaml
ollama:
  thinking_model: "phi"  # Smaller, faster model
  timeout: 30            # Reduce timeout
```

### Less Memory Usage
```yaml
behavior:
  show_thinking_process: false  # Reduce output
  
learning:
  max_memory_items: 5000        # Reduce memory
```

### More Security
```yaml
security:
  require_permission_for_code_changes: true
  require_permission_for_system_access: true
  sandbox_enabled: true
  max_backup_count: 20  # More backups
```

---

## 🎯 Best Practices

### 1. Always Use Supervisor Mode
```bash
# Recommended
python jeeva_supervisor.py

# Instead of
python main.py
```

### 2. Regular Backups
JEEVA automatically creates backups, but you can:
```bash
# Manual backup
cp -r data/ backups/data_backup_$(date +%Y%m%d)
```

### 3. Monitor Logs
```bash
# View logs
tail -f data/logs/jeeva.log

# On Windows
Get-Content data/logs/jeeva.log -Wait
```

### 4. Keep Ollama Running
Always keep `ollama serve` running in background

### 5. Update Regularly
```bash
# Update Ollama
ollama pull llama3.2

# Update dependencies
pip install --upgrade ollama pyyaml rich
```

---

## 🔥 Pro Tips

### Tip 1: Use Shortcuts
```
Instead of: "ek file create kar hello.txt"
Use: "file bana hello.txt"

Instead of: "system information dikha"
Use: "sys info"
```

### Tip 2: Chain Commands
```
You: "file bana test.txt aur usme hello world likh"
JEEVA: [Will create file and add content in one go]
```

### Tip 3: Learn Mode
```
You: "ab se mujhe Boss bulao"
JEEVA: ✅ Yaad rakh liya! Ab tumhe Boss bolunga.

Next time:
JEEVA: Yo Boss! Kya kaam hai?
```

### Tip 4: Batch Operations
```
You: "saari .log files delete kar"
You: "saare Python files ki list bana"
```

---

## 📞 Help Commands

### Get Help Anytime
```
You: "help"
You: "commands dikha"
You: "kya kar sakta hai tu"
You: "examples do"
```

### Check Status
```
You: "status check"
You: "health check"
You: "memory usage dikha"
```

### Reset if Needed
```
You: "reset kar"
You: "fresh start"
You: "memory clear kar"
```

---

## 🎊 Ready to Start!

Ab tum ready ho! Bas ye karo:

1. ✅ `install_dependencies.bat` run karo
2. ✅ `ollama serve` start karo
3. ✅ `ollama pull llama3.2` download karo
4. ✅ `start_jeeva.bat` run karo

**Enjoy your AI assistant! 🚀**

---

## 💡 Remember

- JEEVA **honest** hai - jhooth nahi bolega
- Dangerous actions ke liye **permission** maangega
- **Learn** karta rahega tumse
- **Improve** hota rahega khud ko
- Hamesha **helpful** rahega

---

**Questions? Just ask JEEVA! 😊**

`You: "help chahiye"`
`JEEVA: Haan bhai, batao kya help chahiye?`
