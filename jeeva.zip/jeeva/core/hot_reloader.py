"""
Hot Reloader - Bina restart ke code reload karo
JEEVA ko bina band kiye naya code load karne deta hai
"""

import sys
import importlib
import importlib.util
import time
import threading
from pathlib import Path
from typing import Dict, Any, List, Optional, Callable
from datetime import datetime


class HotReloader:
    """
    Python modules ko bina restart ke reload karta hai
    
    Features:
    - Single module reload
    - Package reload (with submodules)
    - File watcher for auto-reload
    - Reload history tracking
    """

    def __init__(self):
        self.loaded_modules = {}
        self.reload_history = []
        self.watching = False
        self.watch_thread = None
        self.file_timestamps = {}
        self.reload_callbacks = []
        self.max_history = 100

    def add_reload_callback(self, callback: Callable):
        """Add callback to be called after reload"""
        self.reload_callbacks.append(callback)

    def reload_module(self, module_name: str) -> Dict[str, Any]:
        """
        Single module reload karo
        
        Args:
            module_name: Name of module to reload (e.g., 'tools.file_tools')
            
        Returns:
            Dict with success status and details
        """
        try:
            if module_name in sys.modules:
                module = sys.modules[module_name]
                
                old_dict = dict(module.__dict__) if hasattr(module, '__dict__') else {}
                
                reloaded = importlib.reload(module)
                
                self._add_to_history(module_name, True)
                
                for callback in self.reload_callbacks:
                    try:
                        callback(module_name, reloaded)
                    except Exception:
                        pass
                
                return {
                    "success": True,
                    "module": module_name,
                    "message": f"Module '{module_name}' reloaded successfully!",
                    "timestamp": datetime.now().isoformat()
                }
            else:
                module = importlib.import_module(module_name)
                sys.modules[module_name] = module
                
                self._add_to_history(module_name, True, is_new=True)
                
                return {
                    "success": True,
                    "module": module_name,
                    "message": f"Module '{module_name}' imported fresh!",
                    "timestamp": datetime.now().isoformat()
                }

        except Exception as e:
            self._add_to_history(module_name, False, error=str(e))
            
            return {
                "success": False,
                "module": module_name,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }

    def _add_to_history(self, module_name: str, success: bool, error: str = None, is_new: bool = False):
        """Add entry to reload history"""
        entry = {
            "module": module_name,
            "timestamp": datetime.now().isoformat(),
            "success": success,
            "is_new_import": is_new
        }
        
        if error:
            entry["error"] = error
        
        self.reload_history.append(entry)
        
        if len(self.reload_history) > self.max_history:
            self.reload_history = self.reload_history[-self.max_history:]

    def reload_package(self, package_name: str) -> Dict[str, Any]:
        """
        Pura package reload karo (saare submodules)
        
        Args:
            package_name: Name of package to reload (e.g., 'tools')
            
        Returns:
            Dict with success status and details for all modules
        """
        results = []
        
        modules_to_reload = [
            name for name in list(sys.modules.keys())
            if name == package_name or name.startswith(f"{package_name}.")
        ]
        
        modules_to_reload.sort(key=lambda x: x.count('.'), reverse=True)
        
        for module_name in modules_to_reload:
            result = self.reload_module(module_name)
            results.append(result)
        
        success_count = sum(1 for r in results if r.get("success", False))
        
        return {
            "success": success_count == len(results),
            "package": package_name,
            "total": len(results),
            "successful": success_count,
            "failed": len(results) - success_count,
            "details": results,
            "timestamp": datetime.now().isoformat()
        }

    def reload_file(self, file_path: str) -> Dict[str, Any]:
        """
        File path se module reload karo
        
        Args:
            file_path: Path to Python file (e.g., 'tools/file_tools.py')
            
        Returns:
            Dict with success status
        """
        path = Path(file_path)
        
        if not path.exists():
            return {
                "success": False,
                "error": f"File not found: {file_path}"
            }
        
        if path.suffix != '.py':
            return {
                "success": False,
                "error": "Not a Python file"
            }
        
        try:
            try:
                relative = path.relative_to(Path.cwd())
            except ValueError:
                relative = path
            
            module_name = str(relative.with_suffix('')).replace('/', '.').replace('\\', '.')
            
            if module_name.startswith('.'):
                module_name = module_name[1:]
            
            return self.reload_module(module_name)
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "file": file_path
            }

    def reload_all_tools(self) -> Dict[str, Any]:
        """Saare tools reload karo"""
        return self.reload_package("tools")

    def reload_all_capabilities(self) -> Dict[str, Any]:
        """Saari capabilities reload karo"""
        return self.reload_package("capabilities")

    def reload_all_learning(self) -> Dict[str, Any]:
        """Saare learning modules reload karo"""
        return self.reload_package("learning")

    def start_watching(self, directories: List[str] = None, interval: float = 1.0):
        """
        File changes ke liye watch karo (auto-reload)
        
        Args:
            directories: List of directories to watch
            interval: Check interval in seconds
        """
        if directories is None:
            directories = ["tools", "capabilities", "plugins", "learning"]
        
        if self.watching:
            return {"success": False, "error": "Already watching"}
        
        self.watching = True
        
        for dir_name in directories:
            dir_path = Path(dir_name)
            if dir_path.exists():
                for py_file in dir_path.rglob("*.py"):
                    try:
                        self.file_timestamps[str(py_file)] = py_file.stat().st_mtime
                    except Exception:
                        pass
        
        def watch_loop():
            while self.watching:
                try:
                    for dir_name in directories:
                        dir_path = Path(dir_name)
                        if not dir_path.exists():
                            continue
                        
                        for py_file in dir_path.rglob("*.py"):
                            try:
                                file_str = str(py_file)
                                current_mtime = py_file.stat().st_mtime
                                
                                if file_str in self.file_timestamps:
                                    if current_mtime > self.file_timestamps[file_str]:
                                        print(f"🔄 File changed: {py_file.name}")
                                        result = self.reload_file(file_str)
                                        if result.get("success"):
                                            print(f"   ✅ Reloaded successfully")
                                        else:
                                            print(f"   ❌ Reload failed: {result.get('error', 'Unknown error')}")
                                
                                self.file_timestamps[file_str] = current_mtime
                                
                            except Exception:
                                pass
                    
                    time.sleep(interval)
                    
                except Exception as e:
                    print(f"Watch error: {e}")
                    time.sleep(interval)
        
        self.watch_thread = threading.Thread(target=watch_loop, daemon=True)
        self.watch_thread.start()
        
        return {
            "success": True,
            "message": f"Watching directories: {directories}",
            "interval": interval
        }

    def stop_watching(self):
        """Watching band karo"""
        self.watching = False
        
        if self.watch_thread and self.watch_thread.is_alive():
            self.watch_thread.join(timeout=2)
        
        return {"success": True, "message": "File watching stopped"}

    def is_watching(self) -> bool:
        """Check if currently watching"""
        return self.watching

    def get_reload_history(self, limit: int = 20) -> List[Dict]:
        """Get reload history"""
        return self.reload_history[-limit:]

    def get_watched_files(self) -> List[str]:
        """Get list of watched files"""
        return list(self.file_timestamps.keys())

    def clear_history(self):
        """Clear reload history"""
        self.reload_history = []

    def get_stats(self) -> Dict[str, Any]:
        """Get reloader stats"""
        successful = sum(1 for h in self.reload_history if h.get("success", False))
        failed = len(self.reload_history) - successful
        
        return {
            "total_reloads": len(self.reload_history),
            "successful": successful,
            "failed": failed,
            "watching": self.watching,
            "watched_files": len(self.file_timestamps),
            "success_rate": round(successful / len(self.reload_history) * 100, 1) if self.reload_history else 0
        }


class ConfigReloader:
    """
    Config files reload karo (YAML, JSON)
    Bina restart ke configuration update karo
    """

    def __init__(self):
        self.configs = {}
        self.last_loaded = {}
        self.reload_callbacks = []

    def add_reload_callback(self, callback: Callable):
        """Add callback for config reload"""
        self.reload_callbacks.append(callback)

    def reload_yaml(self, file_path: str) -> Dict[str, Any]:
        """
        YAML config reload karo
        
        Args:
            file_path: Path to YAML file
            
        Returns:
            Dict with success status and loaded config
        """
        try:
            import yaml
        except ImportError:
            return {"success": False, "error": "PyYAML not installed"}
        
        path = Path(file_path)
        if not path.exists():
            return {"success": False, "error": f"File not found: {file_path}"}
        
        try:
            with open(path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            
            self.configs[file_path] = config
            self.last_loaded[file_path] = datetime.now().isoformat()
            
            for callback in self.reload_callbacks:
                try:
                    callback(file_path, config)
                except Exception:
                    pass
            
            return {
                "success": True,
                "file": file_path,
                "config": config,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            return {"success": False, "error": str(e), "file": file_path}

    def reload_json(self, file_path: str) -> Dict[str, Any]:
        """
        JSON config reload karo
        
        Args:
            file_path: Path to JSON file
            
        Returns:
            Dict with success status and loaded config
        """
        import json
        
        path = Path(file_path)
        if not path.exists():
            return {"success": False, "error": f"File not found: {file_path}"}
        
        try:
            with open(path, 'r', encoding='utf-8') as f:
                config = json.load(f)
            
            self.configs[file_path] = config
            self.last_loaded[file_path] = datetime.now().isoformat()
            
            for callback in self.reload_callbacks:
                try:
                    callback(file_path, config)
                except Exception:
                    pass
            
            return {
                "success": True,
                "file": file_path,
                "config": config,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            return {"success": False, "error": str(e), "file": file_path}

    def reload_all_configs(self, config_dir: str = "config") -> Dict[str, Any]:
        """
        Saare configs reload karo
        
        Args:
            config_dir: Directory containing config files
            
        Returns:
            Dict with results for all configs
        """
        results = []
        
        config_path = Path(config_dir)
        if not config_path.exists():
            return {"success": False, "error": f"Config directory not found: {config_dir}"}
        
        for yaml_file in config_path.glob("*.yaml"):
            results.append(self.reload_yaml(str(yaml_file)))
        
        for yml_file in config_path.glob("*.yml"):
            results.append(self.reload_yaml(str(yml_file)))
        
        for json_file in config_path.glob("*.json"):
            results.append(self.reload_json(str(json_file)))
        
        success_count = sum(1 for r in results if r.get("success", False))
        
        return {
            "success": success_count == len(results),
            "total": len(results),
            "successful": success_count,
            "failed": len(results) - success_count,
            "details": results
        }

    def get_config(self, file_path: str) -> Optional[Any]:
        """Get loaded config by path"""
        return self.configs.get(file_path)

    def get_all_configs(self) -> Dict[str, Any]:
        """Get all loaded configs"""
        return self.configs.copy()

    def get_last_loaded(self, file_path: str) -> Optional[str]:
        """Get last loaded timestamp for a config"""
        return self.last_loaded.get(file_path)

    def is_loaded(self, file_path: str) -> bool:
        """Check if config is loaded"""
        return file_path in self.configs

    def clear_configs(self):
        """Clear all loaded configs"""
        self.configs = {}
        self.last_loaded = {}