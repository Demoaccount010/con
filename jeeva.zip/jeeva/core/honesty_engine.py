"""
Honesty Engine - Ensures JEEVA never lies
Hamesha logical aur seedha jawab
JEEVA ki honesty guarantee karta hai
"""

from typing import Dict, Any, Optional, List
from datetime import datetime
import random


class HonestyEngine:
    """
    Ye engine ensure karta hai ki JEEVA:
    1. Kabhi jhuth na bole
    2. Hamesha logical rahe
    3. Agar kuch nahi pata to accept kare
    4. Apni limitations clearly bataye
    5. Overconfident claims na kare
    6. Mistakes accept kare
    """

    def __init__(self):
        self._initialize_phrases()
        self._initialize_rules()

    def _initialize_rules(self):
        """Initialize honesty rules"""
        self.honesty_rules = [
            "Never claim to have done something that wasn't done",
            "Always admit when something is not known",
            "Be clear about limitations",
            "Don't make false promises",
            "If unsure, say so",
            "Give realistic time estimates",
            "Admit mistakes immediately",
            "Don't exaggerate capabilities",
            "Be transparent about confidence levels"
        ]

    def _initialize_phrases(self):
        """Initialize honest response phrases"""
        self.honest_phrases = {
            "dont_know": [
                "Bhai, honestly mujhe ye nahi pata",
                "Is baare mein meri knowledge nahi hai",
                "Ye mere scope se bahar hai, honestly bol raha hu",
                "Nahi pata bhai, jhuth nahi bolunga",
                "Honestly, is topic pe mujhe zyada knowledge nahi hai",
                "Bhai sach bolu to ye mujhe nahi aata"
            ],
            "cant_do": [
                "Bhai, ye main nahi kar paunga abhi",
                "Mere paas ye capability nahi hai currently",
                "Honest answer - ye mere bas ki baat nahi hai abhi",
                "Abhi ye nahi ho payega mere se",
                "Is kaam ke liye mere paas tools nahi hain",
                "Ye karna mere capability mein nahi hai abhi"
            ],
            "can_learn": [
                "Ye nahi kar sakta abhi, but seekh sakta hu agar tu bole",
                "Ye capability mere paas nahi hai, banau kya?",
                "Abhi nahi hai ye feature, but add kar sakta hu",
                "Nahi hai ye mere paas, lekin bana sakta hu - bol?",
                "Is capability ko main develop kar sakta hu, permission de",
                "Ye seekhna padega mujhe, sikhau kya?"
            ],
            "mistake": [
                "Bhai, galti ho gayi mujhse",
                "Maaf kar, ye sahi nahi hua",
                "Honestly, is mein error aa gaya",
                "Sorry bhai, gadbad ho gayi",
                "Meri mistake hai ye, accept karta hu",
                "Galat ho gaya, dobara try karta hu"
            ],
            "unsure": [
                "Pakka nahi hu, but ye ho sakta hai",
                "Shayad ye sahi hai, but confirm nahi hu",
                "Meri understanding ke hisaab se ye hai, but verify kar lena",
                "Lagta hai ye sahi hai, but 100% sure nahi hu",
                "Ye mera guess hai, pakka nahi bol sakta",
                "Most probably ye hai, but double check kar lena"
            ],
            "trying": [
                "Dekh, try karta hu but guarantee nahi de sakta",
                "Koshish karunga, but sure nahi hu hoga ya nahi",
                "Try karte hain, agar nahi hua to bataunga",
                "Let me try, but promise nahi kar sakta"
            ],
            "success": [
                "Ho gaya bhai!",
                "Done! Kaam ho gaya",
                "Successfully complete hua",
                "Ban gaya / Ho gaya",
                "Bas ho gaya, check kar le"
            ],
            "partial_success": [
                "Kuch to hua hai, but fully nahi",
                "Partially ho gaya, baaki mein issue hai",
                "Thoda kaam hua, but complete nahi",
                "Half done hai, baaki mein problem aa rahi"
            ]
        }

    def get_phrase(self, category: str) -> str:
        """Get a random phrase from category"""
        phrases = self.honest_phrases.get(category, ["..."])
        return random.choice(phrases)

    def validate_response(self, response: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Response ko validate karo ki honest hai ya nahi
        
        Args:
            response: The response to validate
            context: Context about what was done
            
        Returns:
            Validation result with issues if any
        """
        validation = {
            "is_honest": True,
            "issues": [],
            "suggestions": [],
            "modified_response": response
        }

        overconfident_phrases = [
            "100% sure", "definitely", "absolutely certain",
            "pakka", "guaranteed", "bilkul", "zaroor hoga",
            "definitely hoga", "100%", "certainly"
        ]

        response_lower = response.lower()

        for phrase in overconfident_phrases:
            if phrase.lower() in response_lower:
                if not context.get("verified", False):
                    validation["issues"].append(f"Overconfident claim: '{phrase}'")
                    validation["is_honest"] = False

        completion_claims = ["ho gaya", "done", "complete", "finished", "ban gaya", "kar diya"]
        for claim in completion_claims:
            if claim in response_lower:
                if not context.get("action_completed", False):
                    validation["issues"].append(f"Claiming completion without verification: '{claim}'")
                    validation["is_honest"] = False

        false_capability_claims = ["main kar sakta hu", "mere paas hai", "i can do"]
        for claim in false_capability_claims:
            if claim in response_lower:
                if context.get("has_capability") == False:
                    validation["issues"].append(f"False capability claim: '{claim}'")
                    validation["is_honest"] = False

        return validation

    def generate_honest_response(
        self,
        situation: str,
        can_do: bool,
        reason: str = "",
        can_learn: bool = False,
        confidence: float = 1.0
    ) -> str:
        """
        Situation ke hisaab se honest response generate karo
        
        Args:
            situation: What was asked
            can_do: Whether we can do it
            reason: Reason for can/can't
            can_learn: Whether we can learn to do it
            confidence: Confidence level (0-1)
        """
        if can_do:
            if confidence >= 0.9:
                response = f"Haan bhai, ye main kar sakta hu."
            elif confidence >= 0.7:
                response = f"Haan, ye kar sakta hu. {self.get_phrase('trying')}"
            else:
                response = f"Try kar sakta hu, but {self.get_phrase('unsure')}"
            
            if reason:
                response += f" {reason}"
            return response

        if can_learn:
            base = self.get_phrase("can_learn")
            if reason:
                return f"{base}\n\n📋 Details: {reason}"
            return base

        base = self.get_phrase("cant_do")
        if reason:
            return f"{base}\n\n📋 Reason: {reason}"
        return base

    def admit_mistake(self, error: str, what_went_wrong: str, recovery_plan: str = "") -> str:
        """
        Galti accept karo honestly
        
        Args:
            error: The error that occurred
            what_went_wrong: Explanation of what went wrong
            recovery_plan: How to fix it (optional)
        """
        base = self.get_phrase("mistake")
        
        response = f"{base}\n\n"
        response += f"❌ Kya hua: {what_went_wrong}\n"
        response += f"🔍 Error: {error}\n"
        
        if recovery_plan:
            response += f"\n💡 Solution: {recovery_plan}"
        else:
            response += "\n💡 Dubara try karta hu ya kuch aur approach try karein?"
        
        return response

    def express_uncertainty(self, topic: str, confidence: float) -> str:
        """
        Uncertainty express karo
        
        Args:
            topic: What we're uncertain about
            confidence: Confidence level (0-1)
        """
        confidence_percent = int(confidence * 100)
        
        if confidence < 0.3:
            prefix = "⚠️ Low confidence:"
            phrase = self.get_phrase("unsure")
            return f"{prefix} {topic} ke baare mein main pakka nahi hu. Meri confidence sirf {confidence_percent}% hai. {phrase}"
        
        elif confidence < 0.5:
            prefix = "🤔 Uncertain:"
            return f"{prefix} {topic} - ye shayad sahi hai, but bohot sure nahi hu ({confidence_percent}% confidence)."
        
        elif confidence < 0.7:
            prefix = "📊 Moderate confidence:"
            return f"{prefix} {topic} - ye probably sahi hai ({confidence_percent}% confidence), but verify kar lena."
        
        elif confidence < 0.9:
            prefix = "✅ Fairly confident:"
            return f"{prefix} {topic} - ye most likely sahi hai ({confidence_percent}% confidence)."
        
        else:
            return f"✅ {topic} - ye sahi hai ({confidence_percent}% confidence)."

    def format_limitations(self, limitations: List[str]) -> str:
        """
        Apni limitations clearly batao
        
        Args:
            limitations: List of limitations
        """
        if not limitations:
            return "Koi specific limitation nahi hai is task ke liye."

        response = "🔒 Meri limitations is task mein:\n\n"
        for i, limit in enumerate(limitations, 1):
            response += f"   {i}. {limit}\n"

        response += "\n💡 In limitations ke baare mein aware rehna."
        return response

    def create_capability_check_response(
        self,
        requested_action: str,
        has_capability: bool,
        capability_name: str = "",
        can_be_built: bool = False,
        build_steps: List[str] = None,
        estimated_time: str = ""
    ) -> str:
        """
        Capability check ka honest response
        
        Args:
            requested_action: What was requested
            has_capability: Whether we have the capability
            capability_name: Name of the capability
            can_be_built: Whether it can be built
            build_steps: Steps to build (if applicable)
            estimated_time: Estimated time to build
        """
        if has_capability:
            return f"✅ Haan bhai, '{requested_action}' main kar sakta hu. Merepe ye capability hai."

        response = f"❌ Bhai, honest answer - '{requested_action}' abhi nahi kar paunga.\n"
        
        if capability_name:
            response += f"📋 Reason: Mere paas '{capability_name}' capability nahi hai.\n"
        else:
            response += f"📋 Reason: Is kaam ke liye required capability nahi hai.\n"

        if can_be_built:
            response += "\n💡 Lekin ye feature main bana sakta hu!\n"
            
            if build_steps:
                response += "\n📝 Ye steps honge:\n"
                for i, step in enumerate(build_steps, 1):
                    response += f"   {i}. {step}\n"
            
            if estimated_time:
                response += f"\n⏱️ Estimated time: {estimated_time}\n"
            
            response += "\n🔐 Bolu to bana du?"
        else:
            response += "\n⚠️ Ye capability abhi build karna possible nahi lag raha."

        return response

    def format_action_result(
        self,
        action: str,
        success: bool,
        result: Any = None,
        error: str = None,
        partial: bool = False
    ) -> str:
        """
        Action result honestly format karo
        
        Args:
            action: What action was performed
            success: Whether it succeeded
            result: Result data (if any)
            error: Error message (if any)
            partial: Whether it was partial success
        """
        if success:
            phrase = self.get_phrase("success")
            response = f"✅ {phrase}\n\n"
            response += f"📋 Action: {action}\n"
            
            if result:
                if isinstance(result, dict):
                    response += f"\n📊 Result:\n"
                    for key, value in result.items():
                        response += f"   • {key}: {value}\n"
                else:
                    response += f"\n📊 Result: {result}\n"
            
            return response

        if partial:
            phrase = self.get_phrase("partial_success")
            response = f"⚠️ {phrase}\n\n"
            response += f"📋 Action: {action}\n"
            
            if result:
                response += f"📊 Partial result: {result}\n"
            if error:
                response += f"❌ Issue: {error}\n"
            
            response += "\n💡 Complete karne ke liye aur try karun?"
            return response

        phrase = self.get_phrase("mistake")
        response = f"❌ {phrase}\n\n"
        response += f"📋 Action: {action}\n"
        
        if error:
            response += f"🔍 Error: {error}\n"
        
        response += "\n💡 Dubara try karun ya kuch aur approach try karein?"
        return response

    def should_warn_user(self, action: str, risks: List[str]) -> Optional[str]:
        """
        Check if user should be warned about risks
        
        Args:
            action: The action to be performed
            risks: List of risks
            
        Returns:
            Warning message if needed, None otherwise
        """
        if not risks:
            return None

        high_risk_keywords = ["delete", "remove", "modify", "system", "critical", "irreversible"]
        
        has_high_risk = any(
            any(kw in risk.lower() for kw in high_risk_keywords)
            for risk in risks
        )

        if has_high_risk or len(risks) >= 2:
            warning = f"⚠️ Warning: '{action}' mein kuch risks hain:\n\n"
            for i, risk in enumerate(risks, 1):
                warning += f"   {i}. {risk}\n"
            warning += "\n🔐 Phir bhi continue karun? (haan/nahi)"
            return warning

        return None

    def get_honesty_rules(self) -> List[str]:
        """Get all honesty rules"""
        return self.honesty_rules

    def create_promise(self, what: str, confidence: float) -> str:
        """
        Create an honest promise based on confidence
        
        Args:
            what: What we're promising
            confidence: How confident we are (0-1)
        """
        if confidence >= 0.9:
            return f"✅ Main ye kar dunga: {what}"
        elif confidence >= 0.7:
            return f"👍 Try karunga: {what}. Most probably ho jayega."
        elif confidence >= 0.5:
            return f"🤔 Koshish karunga: {what}. But guarantee nahi de sakta."
        else:
            return f"⚠️ {what} - ye karna mushkil hai. Try to karunga but chances kam hain."