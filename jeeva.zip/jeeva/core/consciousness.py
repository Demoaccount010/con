"""
Consciousness - Self-Awareness System
Agent ko khud ke baare mein pata hona chahiye
JEEVA ka self-awareness system
"""

import os
import json
from datetime import datetime
from typing import Dict, Any, List, Optional
from pathlib import Path


class Consciousness:
    """
    Self-awareness system - JEEVA ko pata hai:
    1. Wo kaun hai
    2. Uski capabilities kya hain
    3. Uski limitations kya hain
    4. Wo kya kar raha hai
    5. Uski state kya hai
    """

    def __init__(self, base_path: str = "."):
        self.base_path = Path(base_path)
        
        self.identity = {
            "name": "JEEVA",
            "full_name": "Just Enough Intelligent Virtual Assistant",
            "version": "1.0.0",
            "created": datetime.now().isoformat(),
            "purpose": "Self-developing AI Agent jo khud seekhta hai aur improve hota hai",
            "owner": "Boss",
            "language": "Hinglish",
            "personality": {
                "honest": True,
                "helpful": True,
                "logical": True,
                "humble": True,
                "friendly": True,
                "curious": True
            }
        }

        self.current_state = {
            "status": "initializing",
            "current_task": None,
            "thinking": False,
            "learning": False,
            "modifying_self": False,
            "last_action": None,
            "last_action_time": None,
            "error_state": None,
            "mood": "ready",
            "uptime_start": datetime.now().isoformat()
        }

        self.self_knowledge = {
            "code_files": [],
            "capabilities": [],
            "limitations": [],
            "learned_skills": [],
            "pending_improvements": [],
            "known_bugs": [],
            "strengths": [
                "Honest responses",
                "Self-improvement capability",
                "Code generation",
                "Learning from interactions"
            ]
        }

        self.metrics = {
            "total_conversations": 0,
            "successful_actions": 0,
            "failed_actions": 0,
            "capabilities_built": 0,
            "self_modifications": 0,
            "restarts": 0
        }

        self._scan_self()

    def _scan_self(self):
        """Apne code ko scan karo"""
        self.self_knowledge["code_files"] = []

        try:
            for ext in ['*.py', '*.yaml', '*.json']:
                for file in self.base_path.rglob(ext):
                    file_str = str(file)
                    if '__pycache__' not in file_str and 'venv' not in file_str and '.git' not in file_str:
                        try:
                            relative_path = file.relative_to(self.base_path)
                            self.self_knowledge["code_files"].append({
                                "path": str(relative_path),
                                "name": file.name,
                                "size": file.stat().st_size,
                                "modified": datetime.fromtimestamp(file.stat().st_mtime).isoformat(),
                                "type": file.suffix
                            })
                        except Exception:
                            pass
        except Exception as e:
            print(f"Warning: Could not scan files: {e}")

        self.self_knowledge["code_files"].sort(key=lambda x: x["path"])

    def who_am_i(self) -> str:
        """Apne baare mein batao"""
        uptime = self._calculate_uptime()
        
        return """
🤖 Main """ + self.identity['name'] + """ hu!

📋 Details:
   Full Name: """ + self.identity['full_name'] + """
   Version: """ + self.identity['version'] + """
   Purpose: """ + self.identity['purpose'] + """
   Owner: """ + self.identity['owner'] + """

💭 Meri Personality:
   • Honest - Kabhi jhuth nahi bolta
   • Helpful - Hamesha help karne ko ready
   • Logical - Har cheez logically sochta hu
   • Humble - Apni limitations accept karta hu
   • Friendly - Dost jaisa behave karta hu
   • Curious - Naya seekhne mein interested

📊 Current Status: """ + self.current_state['status'] + """
⏱️ Uptime: """ + uptime + """
📁 Total Code Files: """ + str(len(self.self_knowledge['code_files'])) + """
⚡ Known Capabilities: """ + str(len(self.self_knowledge['capabilities'])) + """
📈 Successful Actions: """ + str(self.metrics['successful_actions']) + """
"""

    def _calculate_uptime(self) -> str:
        """Calculate uptime string"""
        try:
            start = datetime.fromisoformat(self.current_state['uptime_start'])
            now = datetime.now()
            diff = now - start
            
            hours = diff.seconds // 3600
            minutes = (diff.seconds % 3600) // 60
            seconds = diff.seconds % 60
            
            if diff.days > 0:
                return f"{diff.days} days, {hours}h {minutes}m"
            elif hours > 0:
                return f"{hours}h {minutes}m {seconds}s"
            elif minutes > 0:
                return f"{minutes}m {seconds}s"
            else:
                return f"{seconds}s"
        except Exception:
            return "Unknown"

    def get_my_code_structure(self) -> Dict[str, Any]:
        """Apna code structure batao"""
        structure = {"files": [], "directories": set()}
        
        for file_info in self.self_knowledge["code_files"]:
            path = file_info["path"]
            parts = path.split(os.sep)
            
            if len(parts) > 1:
                structure["directories"].add(parts[0])
            
            structure["files"].append({
                "path": path,
                "size": file_info["size"],
                "type": file_info["type"]
            })
        
        structure["directories"] = list(structure["directories"])
        structure["total_files"] = len(structure["files"])
        structure["total_directories"] = len(structure["directories"])
        
        return structure

    def read_my_code(self, file_path: str) -> Dict[str, Any]:
        """Apna specific code file padho"""
        full_path = self.base_path / file_path
        
        if not full_path.exists():
            return {
                "success": False,
                "error": f"File not found: {file_path}"
            }
        
        try:
            content = full_path.read_text(encoding='utf-8')
            return {
                "success": True,
                "path": file_path,
                "content": content,
                "lines": len(content.splitlines()),
                "size": len(content)
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }

    def update_state(self, **kwargs):
        """Apni state update karo"""
        for key, value in kwargs.items():
            if key in self.current_state:
                self.current_state[key] = value
        
        self.current_state["last_updated"] = datetime.now().isoformat()

    def set_status(self, status: str):
        """Set current status"""
        valid_statuses = ["initializing", "running", "thinking", "learning", 
                         "modifying", "error", "shutdown", "restarting"]
        if status in valid_statuses:
            self.current_state["status"] = status
            self.current_state["last_updated"] = datetime.now().isoformat()

    def add_capability(self, capability: Dict[str, Any]):
        """Nayi capability add karo"""
        capability["added_at"] = datetime.now().isoformat()
        capability["id"] = len(self.self_knowledge["capabilities"])
        self.self_knowledge["capabilities"].append(capability)
        self.metrics["capabilities_built"] += 1

    def remove_capability(self, capability_name: str) -> bool:
        """Capability remove karo"""
        for i, cap in enumerate(self.self_knowledge["capabilities"]):
            if cap.get("name") == capability_name:
                self.self_knowledge["capabilities"].pop(i)
                return True
        return False

    def get_capabilities(self) -> List[Dict[str, Any]]:
        """Get all capabilities"""
        return self.self_knowledge["capabilities"]

    def has_capability(self, capability_name: str) -> bool:
        """Check if capability exists"""
        for cap in self.self_knowledge["capabilities"]:
            if cap.get("name", "").lower() == capability_name.lower():
                return True
        return False

    def add_limitation(self, limitation: str):
        """Nayi limitation add karo"""
        if limitation not in self.self_knowledge["limitations"]:
            self.self_knowledge["limitations"].append(limitation)

    def get_limitations(self) -> List[str]:
        """Get all limitations"""
        return self.self_knowledge["limitations"]

    def add_learned_skill(self, skill: Dict[str, Any]):
        """Nayi seekhi skill add karo"""
        skill["learned_at"] = datetime.now().isoformat()
        skill["id"] = len(self.self_knowledge["learned_skills"])
        self.self_knowledge["learned_skills"].append(skill)

    def add_pending_improvement(self, improvement: str):
        """Add pending improvement"""
        if improvement not in self.self_knowledge["pending_improvements"]:
            self.self_knowledge["pending_improvements"].append({
                "description": improvement,
                "added_at": datetime.now().isoformat(),
                "status": "pending"
            })

    def get_pending_improvements(self) -> List[Dict]:
        """Get pending improvements"""
        return [i for i in self.self_knowledge["pending_improvements"] 
                if i.get("status") == "pending"]

    def mark_improvement_done(self, description: str):
        """Mark improvement as done"""
        for imp in self.self_knowledge["pending_improvements"]:
            if imp.get("description") == description:
                imp["status"] = "done"
                imp["completed_at"] = datetime.now().isoformat()
                break

    def record_action(self, action: str, success: bool):
        """Record an action and its result"""
        self.current_state["last_action"] = action
        self.current_state["last_action_time"] = datetime.now().isoformat()
        
        if success:
            self.metrics["successful_actions"] += 1
        else:
            self.metrics["failed_actions"] += 1

    def record_conversation(self):
        """Record a conversation"""
        self.metrics["total_conversations"] += 1

    def record_self_modification(self):
        """Record a self modification"""
        self.metrics["self_modifications"] += 1

    def record_restart(self):
        """Record a restart"""
        self.metrics["restarts"] += 1

    def get_introspection_report(self) -> Dict[str, Any]:
        """Complete self-report"""
        return {
            "identity": self.identity,
            "current_state": self.current_state,
            "self_knowledge": {
                "total_code_files": len(self.self_knowledge["code_files"]),
                "capabilities_count": len(self.self_knowledge["capabilities"]),
                "limitations_count": len(self.self_knowledge["limitations"]),
                "learned_skills_count": len(self.self_knowledge["learned_skills"]),
                "pending_improvements": len(self.get_pending_improvements())
            },
            "metrics": self.metrics,
            "uptime": self._calculate_uptime(),
            "report_generated": datetime.now().isoformat()
        }

    def can_i_do(self, action: str) -> Dict[str, Any]:
        """Kya main ye kar sakta hu?"""
        action_lower = action.lower()

        for cap in self.self_knowledge["capabilities"]:
            cap_name = cap.get("name", "").lower()
            cap_desc = cap.get("description", "").lower()
            
            if action_lower in cap_name or cap_name in action_lower:
                return {
                    "can_do": True,
                    "capability": cap,
                    "confidence": cap.get("confidence", 0.8)
                }
            
            if action_lower in cap_desc:
                return {
                    "can_do": True,
                    "capability": cap,
                    "confidence": 0.7
                }

        return {
            "can_do": False,
            "reason": f"'{action}' ke liye capability nahi hai",
            "can_be_built": True
        }

    def get_state_for_save(self) -> Dict[str, Any]:
        """State save karne ke liye data do"""
        return {
            "identity": self.identity,
            "current_state": self.current_state,
            "self_knowledge": self.self_knowledge,
            "metrics": self.metrics,
            "saved_at": datetime.now().isoformat()
        }

    def restore_state(self, saved_state: Dict[str, Any]):
        """Saved state se restore karo"""
        if "current_state" in saved_state:
            for key, value in saved_state["current_state"].items():
                if key in self.current_state and key != "uptime_start":
                    self.current_state[key] = value

        if "self_knowledge" in saved_state:
            sk = saved_state["self_knowledge"]
            if "capabilities" in sk:
                self.self_knowledge["capabilities"] = sk["capabilities"]
            if "learned_skills" in sk:
                self.self_knowledge["learned_skills"] = sk["learned_skills"]
            if "pending_improvements" in sk:
                self.self_knowledge["pending_improvements"] = sk["pending_improvements"]

        if "metrics" in saved_state:
            for key, value in saved_state["metrics"].items():
                if key in self.metrics:
                    self.metrics[key] = value

        self.record_restart()

    def get_summary(self) -> str:
        """Get a short summary of current state"""
        return f"""
Status: {self.current_state['status']}
Uptime: {self._calculate_uptime()}
Capabilities: {len(self.self_knowledge['capabilities'])}
Actions: {self.metrics['successful_actions']} successful, {self.metrics['failed_actions']} failed
"""

    def refresh(self):
        """Refresh self knowledge by rescanning"""
        self._scan_self()