"""
Brain - Main Orchestrator
Ye pura system control karta hai
JEEVA ka main brain jo sabko coordinate karta hai
"""

import yaml
import json
from pathlib import Path
from typing import Dict, Any, Optional, List, Callable
from datetime import datetime

from .thinking_engine import ThinkingEngine
from .intent_detector import IntentDetector, IntentType
from .consciousness import Consciousness
from .honesty_engine import HonestyEngine
from .hot_reloader import HotReloader, ConfigReloader
from .self_restart import SelfRestarter, SupervisorClient, RestartManager


class Brain:
    """
    JEEVA ka main brain
    Sabko coordinate karta hai
    
    Components:
    - ThinkingEngine: Ollama se sochta hai
    - IntentDetector: User intent detect karta hai
    - Consciousness: Self-awareness
    - HonestyEngine: Honest responses ensure karta hai
    - RestartManager: Hot reload aur restart manage karta hai
    """

    def __init__(self, config_path: str = "config/settings.yaml"):
        self.config_path = Path(config_path)
        self.config = self._load_config()
        
        print("🧠 Initializing JEEVA Brain...")
        
        self.thinking_engine = ThinkingEngine(self.config)
        self.consciousness = Consciousness()
        self.honesty_engine = HonestyEngine()
        self.intent_detector = IntentDetector(self.thinking_engine)
        
        self.hot_reloader = HotReloader()
        self.config_reloader = ConfigReloader()
        self.self_restarter = SelfRestarter()
        self.supervisor_client = SupervisorClient()
        self.restart_manager = RestartManager(self.hot_reloader, self.self_restarter)
        
        self.is_running = False
        self.conversation_history = []
        self.pending_actions = []
        self.action_handlers = {}
        
        self.capabilities = self._load_capabilities()
        
        self._register_default_handlers()
        
        print("✅ Brain initialized successfully!")

    def _load_config(self) -> Dict[str, Any]:
        """Load configuration"""
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    config = yaml.safe_load(f)
                    print(f"📋 Config loaded from {self.config_path}")
                    return config
            except Exception as e:
                print(f"⚠️ Could not load config: {e}")
        
        return {
            "agent": {"name": "JEEVA", "version": "1.0.0"},
            "ollama": {"model": "llama3.2", "host": "http://localhost:11434"},
            "behavior": {"always_honest": True}
        }

    def _load_capabilities(self) -> Dict[str, Any]:
        """Load capabilities from config"""
        cap_path = Path("config/capabilities.yaml")
        if cap_path.exists():
            try:
                with open(cap_path, 'r', encoding='utf-8') as f:
                    data = yaml.safe_load(f)
                    return data.get('capabilities', {})
            except Exception:
                pass
        return {}

    def _register_default_handlers(self):
        """Register default action handlers"""
        self.action_handlers = {
            "build_capability": self._build_capability,
            "self_modify": self._perform_self_modification,
            "run_code": self._execute_code,
            "execute_action": self._execute_action,
            "save_capability": self._save_capability,
            "apply_and_restart": self._apply_and_restart
        }

    def register_handler(self, action_type: str, handler: Callable):
        """Register a custom action handler"""
        self.action_handlers[action_type] = handler

    def start(self):
        """Brain start karo"""
        self.is_running = True
        self.consciousness.set_status("running")
        
        if not self.thinking_engine.connect():
            print("⚠️ Ollama not connected. Some features will be limited.")
        
        if self.self_restarter.is_restarted():
            self._restore_from_restart()
        
        print(self.consciousness.who_am_i())

    def _restore_from_restart(self):
        """Restart ke baad state restore karo"""
        print("🔄 Restoring from previous session...")
        
        saved_state = self.self_restarter.load_state()
        
        if saved_state and "state" in saved_state:
            state = saved_state["state"]
            
            if "conversation_history" in state:
                self.conversation_history = state["conversation_history"]
                print(f"   ✅ Restored {len(self.conversation_history)} conversation entries")
            
            if "consciousness_state" in state:
                self.consciousness.restore_state(state["consciousness_state"])
                print("   ✅ Restored consciousness state")
            
            if "pending_actions" in state:
                self.pending_actions = state["pending_actions"]
                print(f"   ✅ Restored {len(self.pending_actions)} pending actions")
            
            self.self_restarter.clear_state()
            self.consciousness.record_restart()
            
            print("✅ State restored successfully!")
        else:
            print("   ℹ️ No saved state found")

    def get_state_for_save(self) -> Dict[str, Any]:
        """Save ke liye current state do"""
        return {
            "conversation_history": self.conversation_history[-50:],
            "consciousness_state": self.consciousness.get_state_for_save(),
            "pending_actions": self.pending_actions,
            "capabilities": list(self.capabilities.keys()),
            "saved_at": datetime.now().isoformat()
        }

    def process(self, user_input: str) -> str:
        """
        Main processing function
        User input ko process karo aur response do
        
        Args:
            user_input: What user said
            
        Returns:
            Response string
        """
        if not user_input or not user_input.strip():
            return "Kuch to bol bhai!"
        
        self.consciousness.update_state(current_task=user_input, thinking=True)
        self.consciousness.record_conversation()
        
        self.conversation_history.append({
            "role": "user",
            "content": user_input,
            "timestamp": datetime.now().isoformat()
        })
        
        intent, confidence, details = self.intent_detector.detect(user_input)
        
        context = self._build_context(intent, confidence)
        thought = self.thinking_engine.think(context, user_input)
        
        self.consciousness.update_state(thinking=False)
        
        response = self._handle_intent(intent, user_input, thought, details)
        
        self.conversation_history.append({
            "role": "assistant",
            "content": response,
            "intent": intent.value,
            "timestamp": datetime.now().isoformat()
        })
        
        self.consciousness.update_state(
            current_task=None,
            last_action=user_input
        )
        
        return response

    def _build_context(self, intent: IntentType, confidence: float) -> str:
        """Build context string for thinking"""
        recent_conv = self.conversation_history[-5:] if self.conversation_history else []
        conv_summary = ""
        for entry in recent_conv:
            role = entry.get("role", "unknown")
            content = entry.get("content", "")[:100]
            conv_summary += f"{role}: {content}\n"
        
        capabilities_list = list(self.capabilities.keys())
        
        context = f"""
Intent: {intent.value}
Confidence: {confidence:.2f}
Available Capabilities: {capabilities_list}

Recent Conversation:
{conv_summary}
"""
        return context

    def _handle_intent(self, intent: IntentType, user_input: str, thought: Dict, details: Dict) -> str:
        """Handle different intents"""
        handlers = {
            IntentType.ACTION: self._handle_action,
            IntentType.QUESTION: self._handle_question,
            IntentType.CODE_REQUEST: self._handle_code_request,
            IntentType.CAPABILITY_REQUEST: self._handle_capability_request,
            IntentType.SELF_MODIFY: self._handle_self_modify,
            IntentType.SYSTEM_COMMAND: self._handle_system_command,
            IntentType.CHAT: self._handle_chat
        }
        
        handler = handlers.get(intent, self._handle_chat)
        return handler(user_input, thought)

    def _handle_action(self, user_input: str, thought: Dict) -> str:
        """Action request handle karo"""
        is_possible = thought.get("is_possible", False)
        
        if not is_possible:
            reason = thought.get("reason_if_not_possible", "Capability nahi hai")
            can_build = thought.get("can_be_built", True)
            steps = thought.get("steps_to_complete", [])
            
            response = self.honesty_engine.create_capability_check_response(
                requested_action=user_input,
                has_capability=False,
                capability_name=reason,
                can_be_built=can_build,
                build_steps=steps
            )
            
            if can_build:
                self.pending_actions.append({
                    "type": "build_capability",
                    "action": user_input,
                    "thought": thought,
                    "awaiting_permission": True
                })
            
            return response
        
        steps = thought.get("steps_to_complete", [])
        requires_permission = thought.get("requires_permission", True)
        risks = thought.get("risks", [])
        
        response = "✅ Haan bhai, ye main kar sakta hu!\n\n"
        
        if steps:
            response += "📋 Ye steps follow karunga:\n"
            for i, step in enumerate(steps, 1):
                response += f"   {i}. {step}\n"
        
        warning = self.honesty_engine.should_warn_user(user_input, risks)
        if warning:
            response += f"\n{warning}"
            requires_permission = True
        
        if requires_permission:
            response += "\n\n🔐 Permission chahiye. Karun? (haan/nahi)"
            self.pending_actions.append({
                "type": "execute_action",
                "action": user_input,
                "thought": thought,
                "awaiting_permission": True
            })
        
        return response

    def _handle_question(self, user_input: str, thought: Dict) -> str:
        """Question handle karo"""
        honest_response = thought.get("honest_response", "")
        confidence = thought.get("confidence", 50)
        
        if confidence < 30:
            return self.honesty_engine.express_uncertainty(user_input, confidence / 100)
        
        if confidence < 70:
            uncertain = self.honesty_engine.express_uncertainty(user_input, confidence / 100)
            return f"{uncertain}\n\n{honest_response}" if honest_response else uncertain
        
        return honest_response if honest_response else "Is sawaal ka jawab dhundh raha hu..."

    def _handle_code_request(self, user_input: str, thought: Dict) -> str:
        """Code request handle karo"""
        self.consciousness.update_state(status="generating_code")
        
        code = self.thinking_engine.generate_solution(user_input)
        
        analysis = self.thinking_engine.analyze_code(code)
        
        response = "💻 Code generate kiya hai:\n\n"
        response += "```python\n"
        response += code
        response += "\n```\n\n"
        
        if analysis.get("has_errors"):
            response += "⚠️ Warning: Code mein kuch issues ho sakte hain:\n"
            for error in analysis.get("errors", [])[:3]:
                response += f"   • {error}\n"
            response += "\n"
        else:
            response += "✅ Code error-free lagta hai!\n\n"
        
        if analysis.get("is_safe_to_run", True):
            response += "🔐 Code run karun? (haan/nahi)"
            self.pending_actions.append({
                "type": "run_code",
                "code": code,
                "awaiting_permission": True
            })
        else:
            response += "⚠️ Ye code run karna safe nahi lag raha."
        
        self.consciousness.update_state(status="running")
        
        return response

    def _handle_capability_request(self, user_input: str, thought: Dict) -> str:
        """Capability request handle karo"""
        can_build = thought.get("can_be_built", True)
        
        if can_build:
            response = "💡 Ye capability main bana sakta hu!\n\n"
            
            steps = thought.get("steps_to_complete", [])
            if steps:
                response += "📋 Iske liye ye karunga:\n"
                for i, step in enumerate(steps, 1):
                    response += f"   {i}. {step}\n"
            
            risks = thought.get("risks", [])
            if risks:
                response += "\n⚠️ Risks:\n"
                for risk in risks[:3]:
                    response += f"   • {risk}\n"
            
            response += "\n🔐 Permission de, bana dun? (haan/nahi)"
            
            self.pending_actions.append({
                "type": "build_capability",
                "request": user_input,
                "thought": thought,
                "awaiting_permission": True
            })
        else:
            response = self.honesty_engine.create_capability_check_response(
                requested_action=user_input,
                has_capability=False,
                can_be_built=False
            )
        
        return response

    def _handle_self_modify(self, user_input: str, thought: Dict) -> str:
        """Self modification request handle karo"""
        response = "🔧 Self-modification request!\n\n"
        
        understanding = thought.get("understanding", user_input)
        response += f"📋 Samjha: {understanding}\n\n"
        
        steps = thought.get("steps_to_complete", [])
        if steps:
            response += "Ye karunga:\n"
            for i, step in enumerate(steps, 1):
                response += f"   {i}. {step}\n"
        
        response += "\n⚠️ Important:\n"
        response += "   • Apna code modify karunga\n"
        response += "   • Pehle backup lunga\n"
        response += "   • Error check karunga\n"
        response += "   • Restart ho sakta hai\n"
        
        response += "\n🔐 Teri explicit permission chahiye. Karun? (haan/nahi)"
        
        self.pending_actions.append({
            "type": "self_modify",
            "request": user_input,
            "thought": thought,
            "awaiting_permission": True
        })
        
        return response

    def _handle_system_command(self, user_input: str, thought: Dict) -> str:
        """System command handle karo"""
        response = "⚠️ System command detected!\n\n"
        response += "Ye ek system-level operation hai. Extra careful rehna padega.\n"
        
        risks = thought.get("risks", ["System modification"])
        response += "\n🔴 Risks:\n"
        for risk in risks:
            response += f"   • {risk}\n"
        
        response += "\n🔐 Bahut sure hai? (haan/nahi)"
        
        self.pending_actions.append({
            "type": "system_command",
            "command": user_input,
            "thought": thought,
            "awaiting_permission": True
        })
        
        return response

    def _handle_chat(self, user_input: str, thought: Dict) -> str:
        """Normal chat handle karo"""
        response = thought.get("honest_response", "")
        
        if not response:
            response = self.thinking_engine.generate_chat_response(user_input)
        
        if not response:
            response = "Haan bhai, bol! Kya baat hai?"
        
        return response

    def confirm_action(self, confirmed: bool) -> str:
        """
        Pending action ko confirm karo
        
        Args:
            confirmed: True if user confirmed, False otherwise
            
        Returns:
            Response string
        """
        if not self.pending_actions:
            return "Koi pending action nahi hai bhai."
        
        action = self.pending_actions.pop(0)
        
        if not confirmed:
            self.consciousness.record_action(action.get("type", "unknown"), False)
            return "👍 Theek hai, cancel kar diya."
        
        action_type = action.get("type", "unknown")
        
        handler = self.action_handlers.get(action_type)
        
        if handler:
            result = handler(action)
            self.consciousness.record_action(action_type, "error" not in result.lower() if isinstance(result, str) else True)
            return result
        else:
            return f"⚠️ Unknown action type: {action_type}"

    def _build_capability(self, action: Dict) -> str:
        """New capability build karo"""
        self.consciousness.update_state(status="building_capability")
        
        thought = action.get("thought", {})
        request = action.get("request", action.get("action", ""))
        
        response = "🔧 Building new capability...\n\n"
        
        code = self.thinking_engine.generate_capability_code(
            capability_name=request,
            description=thought.get("understanding", request)
        )
        
        response += "📝 Code generated\n"
        response += "🔍 Checking for errors...\n"
        
        analysis = self.thinking_engine.analyze_code(code)
        
        if analysis.get("has_errors"):
            errors = analysis.get("errors", [])
            response += f"⚠️ Issues found: {errors[:2]}\n"
            response += "Attempting to fix...\n"
        
        response += "✅ Capability code ready!\n\n"
        response += "```python\n"
        
        code_preview = code[:800] + ("..." if len(code) > 800 else "")
        response += code_preview
        response += "\n```\n\n"
        
        response += "📦 Save karke activate karun? (haan/nahi)"
        
        self.pending_actions.insert(0, {
            "type": "save_capability",
            "code": code,
            "name": request,
            "awaiting_permission": True
        })
        
        self.consciousness.update_state(status="running")
        
        return response

    def _save_capability(self, action: Dict) -> str:
        """Save capability to file"""
        code = action.get("code", "")
        name = action.get("name", "new_capability")
        
        safe_name = "".join(c if c.isalnum() or c == "_" else "_" for c in name.lower())
        safe_name = safe_name[:50]
        
        tools_dir = Path("tools")
        tools_dir.mkdir(exist_ok=True)
        
        file_path = tools_dir / f"{safe_name}.py"
        
        try:
            file_path.write_text(code, encoding='utf-8')
            
            self.hot_reloader.reload_file(str(file_path))
            
            self.capabilities[safe_name] = {
                "name": name,
                "file": str(file_path),
                "installed": True,
                "added_at": datetime.now().isoformat()
            }
            
            self.consciousness.add_capability({
                "name": name,
                "file": str(file_path)
            })
            
            return f"✅ Capability saved to {file_path} and activated!"
            
        except Exception as e:
            return f"❌ Error saving capability: {e}"

    def _perform_self_modification(self, action: Dict) -> str:
        """Self modification perform karo"""
        self.consciousness.update_state(status="modifying", modifying_self=True)
        
        thought = action.get("thought", {})
        request = action.get("request", "")
        
        response = "🔧 Self-modifying...\n\n"
        
        code = self.thinking_engine.generate_solution(
            f"Improve JEEVA AI agent: {request}",
            context="This is for self-improvement of an AI agent"
        )
        
        response += "📝 Improvement code generated\n"
        response += "📦 Creating backup...\n"
        
        analysis = self.thinking_engine.analyze_code(code)
        
        if analysis.get("has_errors"):
            errors = analysis.get("errors", [])
            response += f"❌ Errors found, cannot apply:\n"
            for error in errors[:3]:
                response += f"   • {error}\n"
            
            self.consciousness.update_state(status="running", modifying_self=False)
            return response
        
        response += "✅ Code looks good!\n\n"
        response += "⚠️ Ye change apply karne ke liye restart chahiye.\n"
        response += "Apply aur restart karun? (haan/nahi)"
        
        self.pending_actions.insert(0, {
            "type": "apply_and_restart",
            "code": code,
            "request": request,
            "awaiting_permission": True
        })
        
        self.consciousness.update_state(status="running", modifying_self=False)
        
        return response

    def _apply_and_restart(self, action: Dict) -> str:
        """Apply changes and restart"""
        code = action.get("code", "")
        request = action.get("request", "")
        
        improvements_dir = Path("self_improvements")
        improvements_dir.mkdir(exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_path = improvements_dir / f"improvement_{timestamp}.py"
        
        try:
            file_path.write_text(code, encoding='utf-8')
            
            self.consciousness.record_self_modification()
            self.consciousness.mark_improvement_done(request)
            
            return self.request_restart(reason=f"Self-improvement: {request[:50]}")
            
        except Exception as e:
            return f"❌ Error applying changes: {e}"

    def _execute_code(self, action: Dict) -> str:
        """Code execute karo"""
        code = action.get("code", "")
        
        if not code:
            return "❌ No code to execute"
        
        try:
            import io
            import contextlib
            
            stdout_capture = io.StringIO()
            stderr_capture = io.StringIO()
            
            local_vars = {}
            
            with contextlib.redirect_stdout(stdout_capture), contextlib.redirect_stderr(stderr_capture):
                exec(code, {"__builtins__": __builtins__}, local_vars)
            
            output = stdout_capture.getvalue()
            errors = stderr_capture.getvalue()
            
            response = "✅ Code executed!\n\n"
            
            if output:
                response += f"📤 Output:\n```\n{output[:1000]}\n```\n"
            
            if errors:
                response += f"⚠️ Stderr:\n```\n{errors[:500]}\n```\n"
            
            if not output and not errors:
                response += "Code ran successfully (no output)\n"
            
            self.consciousness.record_action("code_execution", True)
            
            return response
            
        except Exception as e:
            self.consciousness.record_action("code_execution", False)
            return f"❌ Execution error:\n```\n{str(e)}\n```"

    def _execute_action(self, action: Dict) -> str:
        """Action execute karo"""
        thought = action.get("thought", {})
        action_desc = action.get("action", "")
        
        response = f"⚡ Executing: {action_desc}\n\n"
        
        steps = thought.get("steps_to_complete", [])
        for i, step in enumerate(steps, 1):
            response += f"   {i}. {step} ✅\n"
        
        response += "\n✅ Action completed!"
        
        self.consciousness.record_action("action", True)
        
        return response

    def request_restart(self, reason: str = "Requested") -> str:
        """Restart request karo"""
        messages = []
        
        def notify(msg):
            messages.append(msg)
            print(msg)
        
        def save_callback():
            return self.get_state_for_save()
        
        if self.supervisor_client.is_supervisor_running():
            notify("📡 Supervisor detected, requesting restart...")
            
            self.self_restarter.save_state(save_callback())
            result = self.supervisor_client.request_restart(reason)
            
            if "error" not in result:
                return f"🔄 Restart requested via supervisor. Reason: {reason}"
        
        result = self.self_restarter.graceful_restart(
            save_state_callback=save_callback,
            notify_callback=notify,
            reason=reason
        )
        
        return "\n".join(messages) if messages else f"🔄 Restarting... Reason: {reason}"

    def get_pending_actions(self) -> List[Dict]:
        """Get pending actions"""
        return self.pending_actions

    def clear_pending_actions(self):
        """Clear all pending actions"""
        self.pending_actions = []

    def shutdown(self):
        """Brain shutdown karo"""
        print("\n👋 JEEVA Brain shutting down...")
        
        self.is_running = False
        self.consciousness.set_status("shutdown")
        
        self.hot_reloader.stop_watching()
        
        print("✅ Brain shutdown complete")