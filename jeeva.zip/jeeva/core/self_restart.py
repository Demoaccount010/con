"""
Self Restart System - JEEVA khud ko restart kar sake
State preserve karke safely restart karta hai
"""

import os
import sys
import json
import subprocess
import time
import atexit
import signal
import socket
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Optional, Callable, List


class SelfRestarter:
    """
    JEEVA ko safely restart karta hai
    State preserve karke
    
    Features:
    - State save before restart
    - Graceful restart with callbacks
    - Multiple restart methods (execv, subprocess)
    - Restart history tracking
    """

    def __init__(self, state_dir: str = "data/restart_state"):
        self.state_dir = Path(state_dir)
        self.state_dir.mkdir(parents=True, exist_ok=True)
        
        self.state_file = self.state_dir / "restart_state.json"
        self.pid_file = self.state_dir / "jeeva.pid"
        self.restart_flag = self.state_dir / "restart_requested"
        self.history_file = self.state_dir / "restart_history.json"
        
        self.restart_history = self._load_history()
        
        self._save_pid()
        
        atexit.register(self._cleanup)

    def _save_pid(self):
        """Current process PID save karo"""
        try:
            self.pid_file.write_text(str(os.getpid()))
        except Exception:
            pass

    def _cleanup(self):
        """Cleanup on exit"""
        try:
            if self.pid_file.exists():
                self.pid_file.unlink()
        except Exception:
            pass

    def _load_history(self) -> List[Dict]:
        """Load restart history"""
        if self.history_file.exists():
            try:
                with open(self.history_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception:
                pass
        return []

    def _save_history(self):
        """Save restart history"""
        try:
            history_to_save = self.restart_history[-50:]
            with open(self.history_file, 'w', encoding='utf-8') as f:
                json.dump(history_to_save, f, indent=2)
        except Exception:
            pass

    def _add_to_history(self, reason: str, success: bool, method: str = "unknown"):
        """Add entry to restart history"""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "reason": reason,
            "success": success,
            "method": method,
            "pid": os.getpid()
        }
        self.restart_history.append(entry)
        self._save_history()

    def save_state(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Current state save karo restart ke liye
        
        Args:
            state: State dictionary to save
            
        Returns:
            Dict with success status
        """
        state_data = {
            "saved_at": datetime.now().isoformat(),
            "pid": os.getpid(),
            "python_executable": sys.executable,
            "script": sys.argv[0] if sys.argv else "main.py",
            "working_dir": os.getcwd(),
            "argv": sys.argv,
            "state": state
        }
        
        try:
            with open(self.state_file, 'w', encoding='utf-8') as f:
                json.dump(state_data, f, indent=2, ensure_ascii=False)
            
            return {
                "success": True,
                "state_file": str(self.state_file),
                "size": self.state_file.stat().st_size
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def load_state(self) -> Optional[Dict[str, Any]]:
        """
        Saved state load karo
        
        Returns:
            Saved state dict or None
        """
        if not self.state_file.exists():
            return None
        
        try:
            with open(self.state_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return None

    def clear_state(self):
        """State file delete karo (after successful restore)"""
        try:
            if self.state_file.exists():
                self.state_file.unlink()
        except Exception:
            pass

    def is_restarted(self) -> bool:
        """Check if this is a restarted instance"""
        return "--restarted" in sys.argv or os.environ.get("JEEVA_RESTARTED") == "1"

    def get_restart_info(self) -> Optional[Dict[str, Any]]:
        """Get info about the restart if this is a restarted instance"""
        if not self.is_restarted():
            return None
        
        state = self.load_state()
        if state:
            return {
                "restarted": True,
                "previous_pid": state.get("pid"),
                "saved_at": state.get("saved_at"),
                "has_state": "state" in state
            }
        
        return {"restarted": True, "has_state": False}

    def perform_restart(self, method: str = "auto") -> None:
        """
        Actually restart karo - YE FUNCTION RETURN NAHI HOTA!
        
        Args:
            method: 'execv', 'subprocess', or 'auto'
        """
        python = sys.executable
        script = os.path.abspath(sys.argv[0]) if sys.argv else "main.py"
        args = [arg for arg in sys.argv[1:] if arg != "--restarted"]
        args.append("--restarted")
        
        print("\n" + "=" * 50)
        print("🔄 RESTARTING JEEVA...")
        print("=" * 50)
        print(f"Python: {python}")
        print(f"Script: {script}")
        print("=" * 50 + "\n")
        
        time.sleep(0.5)
        
        os.environ["JEEVA_RESTARTED"] = "1"
        
        if method == "auto" or method == "execv":
            try:
                os.execv(python, [python, script] + args)
            except Exception as e:
                print(f"execv failed: {e}")
                if method == "execv":
                    raise
        
        if method == "auto" or method == "subprocess":
            try:
                if sys.platform == 'win32':
                    subprocess.Popen(
                        [python, script] + args,
                        creationflags=subprocess.CREATE_NEW_CONSOLE
                    )
                else:
                    subprocess.Popen(
                        [python, script] + args,
                        start_new_session=True,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL
                    )
                
                self._add_to_history("Restart via subprocess", True, "subprocess")
                
                sys.exit(0)
                
            except Exception as e:
                print(f"subprocess restart failed: {e}")
                self._add_to_history(f"Restart failed: {e}", False, "subprocess")
                raise

    def graceful_restart(
        self,
        save_state_callback: Callable,
        notify_callback: Callable = None,
        delay: float = 2.0,
        reason: str = "Requested"
    ) -> Dict[str, Any]:
        """
        Graceful restart with callbacks
        
        Args:
            save_state_callback: Function that returns state dict to save
            notify_callback: Function to call with status messages
            delay: Delay before restart in seconds
            reason: Reason for restart
            
        Returns:
            Dict with status (may not return if restart succeeds)
        """
        try:
            if notify_callback:
                notify_callback("🔄 Preparing for restart...")
                notify_callback("📦 Saving state...")
            
            state = save_state_callback()
            save_result = self.save_state(state)
            
            if not save_result.get("success", False):
                error_msg = f"Failed to save state: {save_result.get('error', 'Unknown')}"
                if notify_callback:
                    notify_callback(f"❌ {error_msg}")
                return {"success": False, "error": error_msg}
            
            if notify_callback:
                notify_callback("✅ State saved!")
                notify_callback(f"🔄 Restarting in {delay} seconds...")
            
            self._add_to_history(reason, True, "graceful")
            
            time.sleep(delay)
            
            self.perform_restart()
            
            return {"success": True}
            
        except Exception as e:
            error_msg = str(e)
            self._add_to_history(f"Graceful restart failed: {error_msg}", False, "graceful")
            
            if notify_callback:
                notify_callback(f"❌ Restart failed: {error_msg}")
            
            return {"success": False, "error": error_msg}

    def schedule_restart(
        self,
        delay: float,
        save_state_callback: Callable,
        reason: str = "Scheduled"
    ) -> Dict[str, Any]:
        """
        Schedule a restart after delay
        
        Args:
            delay: Delay in seconds
            save_state_callback: Function to save state
            reason: Reason for restart
        """
        import threading
        
        def do_restart():
            time.sleep(delay)
            self.graceful_restart(save_state_callback, reason=reason)
        
        thread = threading.Thread(target=do_restart, daemon=True)
        thread.start()
        
        return {
            "success": True,
            "message": f"Restart scheduled in {delay} seconds",
            "reason": reason
        }

    def get_restart_history(self, limit: int = 10) -> List[Dict]:
        """Get restart history"""
        return self.restart_history[-limit:]

    def get_stats(self) -> Dict[str, Any]:
        """Get restart statistics"""
        successful = sum(1 for h in self.restart_history if h.get("success", False))
        
        return {
            "total_restarts": len(self.restart_history),
            "successful": successful,
            "failed": len(self.restart_history) - successful,
            "current_pid": os.getpid(),
            "is_restarted_instance": self.is_restarted()
        }


class SupervisorClient:
    """
    JEEVA mein use karo supervisor se baat karne ke liye
    Supervisor process ke saath IPC communication
    """

    def __init__(self, host: str = "localhost", port: int = 19999):
        self.host = host
        self.port = port
        self.timeout = 5

    def send_command(self, command: str, **kwargs) -> Dict[str, Any]:
        """
        Send command to supervisor
        
        Args:
            command: Command to send
            **kwargs: Additional arguments
            
        Returns:
            Response from supervisor
        """
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(self.timeout)
            sock.connect((self.host, self.port))
            
            message = json.dumps({"command": command, **kwargs})
            sock.send(message.encode('utf-8'))
            
            response = sock.recv(4096).decode('utf-8')
            sock.close()
            
            return json.loads(response)
            
        except socket.timeout:
            return {"error": "Connection timeout", "supervisor_available": False}
        except ConnectionRefusedError:
            return {"error": "Connection refused", "supervisor_available": False}
        except Exception as e:
            return {"error": str(e), "supervisor_available": False}

    def request_restart(self, reason: str = "Code update") -> Dict[str, Any]:
        """Request restart from supervisor"""
        return self.send_command("restart", reason=reason)

    def health_check(self) -> Dict[str, Any]:
        """Health check"""
        return self.send_command("health")

    def is_supervisor_running(self) -> bool:
        """Check if supervisor is running"""
        result = self.health_check()
        return result.get("supervisor_available", False) or "error" not in result

    def get_status(self) -> Dict[str, Any]:
        """Get supervisor status"""
        return self.send_command("status")

    def request_stop(self) -> Dict[str, Any]:
        """Request stop from supervisor"""
        return self.send_command("stop")


class RestartManager:
    """
    High-level restart management
    Decides when to hot reload vs full restart
    """

    def __init__(self, hot_reloader=None, self_restarter=None):
        self.hot_reloader = hot_reloader
        self.self_restarter = self_restarter or SelfRestarter()
        self.supervisor_client = SupervisorClient()
        
        self.restart_required_files = [
            "main.py",
            "brain.py",
            "__init__.py",
            "consciousness.py",
            "self_restart.py",
            "hot_reloader.py"
        ]
        
        self.hot_reload_directories = [
            "tools",
            "plugins",
            "capabilities/plugins",
            "learning"
        ]

    def needs_restart(self, file_path: str) -> bool:
        """
        Check if file change needs restart
        
        Args:
            file_path: Path to changed file
            
        Returns:
            True if restart needed, False if hot reload possible
        """
        file_name = Path(file_path).name
        
        for pattern in self.restart_required_files:
            if pattern == file_name or pattern in file_path:
                return True
        
        for directory in self.hot_reload_directories:
            if file_path.startswith(directory):
                return False
        
        if "core/" in file_path or "core\\" in file_path:
            return True
        
        return False

    def handle_code_change(
        self,
        file_path: str,
        save_state_callback: Callable,
        notify_callback: Callable = None
    ) -> Dict[str, Any]:
        """
        Code change ke baad decide karo - hot reload ya restart
        
        Args:
            file_path: Path to changed file
            save_state_callback: Function to save state
            notify_callback: Function for notifications
            
        Returns:
            Dict with result
        """
        file_name = Path(file_path).name
        
        if self.needs_restart(file_path):
            if notify_callback:
                notify_callback(f"⚠️ '{file_name}' is a core file, restart required.")
            
            if self.supervisor_client.is_supervisor_running():
                if notify_callback:
                    notify_callback("📡 Requesting restart from supervisor...")
                
                state = save_state_callback()
                self.self_restarter.save_state(state)
                
                result = self.supervisor_client.request_restart(f"Code update: {file_name}")
                
                if "error" not in result:
                    return {"success": True, "method": "supervisor", "result": result}
            
            if notify_callback:
                notify_callback("🔄 Performing self-restart...")
            
            return self.self_restarter.graceful_restart(
                save_state_callback=save_state_callback,
                notify_callback=notify_callback,
                reason=f"Code update: {file_name}"
            )
        
        else:
            if self.hot_reloader:
                if notify_callback:
                    notify_callback(f"🔄 Hot reloading '{file_name}'...")
                
                result = self.hot_reloader.reload_file(file_path)
                
                if result.get("success", False):
                    if notify_callback:
                        notify_callback(f"✅ '{file_name}' hot reloaded successfully!")
                    return result
                else:
                    if notify_callback:
                        notify_callback(f"⚠️ Hot reload failed, trying restart...")
                    
                    return self.self_restarter.graceful_restart(
                        save_state_callback=save_state_callback,
                        notify_callback=notify_callback,
                        reason=f"Hot reload failed for: {file_name}"
                    )
            else:
                return self.self_restarter.graceful_restart(
                    save_state_callback=save_state_callback,
                    notify_callback=notify_callback,
                    reason=f"Code update: {file_name}"
                )

    def get_reload_recommendation(self, file_path: str) -> Dict[str, Any]:
        """
        Get recommendation for how to handle file change
        
        Args:
            file_path: Path to file
            
        Returns:
            Dict with recommendation
        """
        needs_restart = self.needs_restart(file_path)
        
        return {
            "file": file_path,
            "needs_restart": needs_restart,
            "recommended_method": "restart" if needs_restart else "hot_reload",
            "reason": "Core file" if needs_restart else "Safe for hot reload"
        }