"""
Thinking Engine - Connects to Ollama for reasoning
Ye sirf sochne ke liye hai - actual work agent karega
JEEVA ka brain jo deep thinking karta hai
"""

import ollama
import json
import re
from typing import Dict, Any, Optional, List
from datetime import datetime


class ThinkingEngine:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.ollama_host = config.get('ollama', {}).get('host', 'http://localhost:11434')
        self.model = config.get('ollama', {}).get('thinking_model', 'llama3.2')
        self.timeout = config.get('ollama', {}).get('timeout', 120)
        self.is_connected = False
        self.thinking_history = []
        self.max_history = 100

    def connect(self) -> bool:
        try:
            models = ollama.list()
            self.is_connected = True
            available_models = [m.get('name', '') for m in models.get('models', [])]
            model_base = self.model.split(':')[0]
            model_found = any(model_base in m for m in available_models)
            
            if model_found:
                print(f"✅ Thinking Engine connected to Ollama ({self.model})")
            else:
                print(f"⚠️ Model '{self.model}' not found. Available: {available_models}")
                if available_models:
                    self.model = available_models[0]
                    print(f"   Using '{self.model}' instead")
            
            return True
            
        except Exception as e:
            self.is_connected = False
            print(f"❌ Ollama connection failed: {e}")
            print("   Make sure Ollama is running: ollama serve")
            return False

    def _get_thinking_prompt(self, context: str, question: str) -> str:
        return """Tu ek intelligent AI agent ka thinking brain hai. Tujhe sirf SOCHNA hai aur analysis dena hai.
KABHI JHUTH MAT BOLNA. Agar kuch nahi pata to bol "mujhe nahi pata".
Hamesha helpful aur friendly reh.

CONTEXT:
""" + context + """

USER KA INPUT:
""" + question + """

Apna analysis is EXACT JSON format mein de (koi extra text nahi):
{
    "understanding": "user kya chahta hai - 1-2 lines mein",
    "intent_type": "chat ya action ya question ya code_request ya capability_request ya self_modify",
    "is_possible": true ya false,
    "reason_if_not_possible": "agar possible nahi hai to kyu (warna empty string)",
    "can_be_built": true ya false,
    "steps_to_complete": ["step1", "step2", "step3"],
    "risks": ["risk1", "risk2"],
    "confidence": 85,
    "requires_permission": true ya false,
    "honest_response": "user ko kya bolna chahiye - friendly aur helpful response in Hinglish"
}

IMPORTANT: Sirf JSON return karo, koi aur text nahi!"""

    def think(self, context: str, question: str) -> Dict[str, Any]:
        if not self.is_connected:
            if not self.connect():
                return self._offline_think(context, question)

        thinking_prompt = self._get_thinking_prompt(context, question)

        try:
            response = ollama.chat(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "Tu ek logical thinking engine hai. SIRF valid JSON format mein reply kar. Koi explanation ya extra text nahi. Hamesha honest aur helpful reh."
                    },
                    {
                        "role": "user",
                        "content": thinking_prompt
                    }
                ],
                options={
                    "temperature": 0.3,
                    "num_predict": 1000
                }
            )

            response_text = response['message']['content']
            thought = self._parse_thought(response_text)
            self._add_to_history(question, thought)
            return thought

        except Exception as e:
            error_thought = {
                "understanding": "Thinking mein error aaya",
                "intent_type": "unknown",
                "is_possible": False,
                "reason_if_not_possible": str(e),
                "can_be_built": False,
                "steps_to_complete": [],
                "risks": ["Ollama connection issue"],
                "confidence": 0,
                "requires_permission": False,
                "honest_response": "Bhai, abhi meri thinking mein problem aa rahi hai. Error: " + str(e)[:100]
            }
            return error_thought

    def _offline_think(self, context: str, question: str) -> Dict[str, Any]:
        question_lower = question.lower()
        
        intent = "chat"
        if any(w in question_lower for w in ["karo", "kar", "open", "khol", "bana", "create"]):
            intent = "action"
        elif "?" in question or any(w in question_lower for w in ["kya", "kaise", "kyu", "bata"]):
            intent = "question"
        elif any(w in question_lower for w in ["code", "script", "function", "likh"]):
            intent = "code_request"
        
        return {
            "understanding": question[:100],
            "intent_type": intent,
            "is_possible": True,
            "reason_if_not_possible": "",
            "can_be_built": True,
            "steps_to_complete": ["Process request", "Generate response"],
            "risks": [],
            "confidence": 50,
            "requires_permission": False,
            "honest_response": "Bhai, abhi Ollama connected nahi hai, but main basic help kar sakta hu. Ollama start karo for better responses."
        }

    def _parse_thought(self, response: str) -> Dict[str, Any]:
        try:
            json_match = re.search(r'\{[\s\S]*\}', response)
            if json_match:
                json_str = json_match.group()
                parsed = json.loads(json_str)
                
                required_fields = ["understanding", "intent_type", "is_possible", "honest_response"]
                for field in required_fields:
                    if field not in parsed:
                        parsed[field] = self._get_default_value(field)
                
                return parsed
        except json.JSONDecodeError:
            pass
        except Exception:
            pass

        return {
            "understanding": response[:200] if response else "Could not understand",
            "intent_type": "unknown",
            "is_possible": True,
            "reason_if_not_possible": "",
            "can_be_built": True,
            "steps_to_complete": [],
            "risks": [],
            "confidence": 40,
            "requires_permission": False,
            "honest_response": response if response else "Kuch samajh nahi aaya bhai, dubara bol?"
        }

    def _get_default_value(self, field: str) -> Any:
        defaults = {
            "understanding": "Processing...",
            "intent_type": "unknown",
            "is_possible": True,
            "reason_if_not_possible": "",
            "can_be_built": True,
            "steps_to_complete": [],
            "risks": [],
            "confidence": 50,
            "requires_permission": False,
            "honest_response": "Main samajhne ki koshish kar raha hu..."
        }
        return defaults.get(field, "")

    def _add_to_history(self, question: str, thought: Dict[str, Any]):
        self.thinking_history.append({
            "timestamp": datetime.now().isoformat(),
            "question": question[:200],
            "thought_summary": {
                "intent": thought.get("intent_type"),
                "confidence": thought.get("confidence"),
                "possible": thought.get("is_possible")
            }
        })
        
        if len(self.thinking_history) > self.max_history:
            self.thinking_history = self.thinking_history[-self.max_history:]

    def _get_code_analysis_prompt(self, code: str) -> str:
        return """Is Python code ko analyze kar:

CODE:
\"\"\"
""" + code + """
\"\"\"

Analysis is EXACT JSON format mein de:
{
    "has_errors": true ya false,
    "errors": ["error description 1", "error description 2"],
    "has_security_issues": true ya false,
    "security_issues": ["security issue 1"],
    "has_syntax_errors": true ya false,
    "syntax_errors": ["syntax error 1"],
    "improvements": ["improvement suggestion 1"],
    "is_safe_to_run": true ya false,
    "explanation": "code kya karta hai - 1-2 lines",
    "risk_level": "low ya medium ya high"
}

Sirf JSON return karo!"""

    def analyze_code(self, code: str) -> Dict[str, Any]:
        if not self.is_connected:
            if not self.connect():
                return {"has_errors": False, "is_safe_to_run": True, "note": "Offline mode"}

        prompt = self._get_code_analysis_prompt(code)

        try:
            response = ollama.chat(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "Tu ek code analyzer hai. Sirf valid JSON return kar."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                options={"temperature": 0.2}
            )
            
            result = self._parse_thought(response['message']['content'])
            
            if "has_errors" not in result:
                result["has_errors"] = False
            if "is_safe_to_run" not in result:
                result["is_safe_to_run"] = True
            if "errors" not in result:
                result["errors"] = []
                
            return result
            
        except Exception as e:
            return {
                "has_errors": True,
                "errors": ["Analysis error: " + str(e)],
                "is_safe_to_run": False,
                "explanation": "Could not analyze code"
            }

    def _get_solution_prompt(self, problem: str, context: str) -> str:
        base = """Problem: """ + problem
        
        if context:
            base += """

Context: """ + context
        
        base += """

Ek working Python solution likh jo:
1. Error-free ho
2. Well-commented ho (Hindi comments bhi OK)
3. Safe ho
4. Efficient ho
5. Easy to understand ho

Code ko triple quotes mein wrap karke de."""
        
        return base

    def generate_solution(self, problem: str, context: str = "") -> str:
        if not self.is_connected:
            if not self.connect():
                return "# Ollama not connected. Cannot generate code."

        prompt = self._get_solution_prompt(problem, context)

        try:
            response = ollama.chat(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "Tu ek expert Python developer hai. Clean, working code likh."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                options={"temperature": 0.4}
            )
            
            code = response['message']['content']
            
            # Extract code from various formats
            patterns = [
                r'```python\s*([\s\S]*?)\s*```',
                r'```\s*([\s\S]*?)\s*```',
                r'"""([\s\S]*?)"""',
                r"'''([\s\S]*?)'''"
            ]
            
            for pattern in patterns:
                code_match = re.search(pattern, code)
                if code_match:
                    return code_match.group(1).strip()
            
            return code
            
        except Exception as e:
            return "# Error generating solution: " + str(e)

    def _get_capability_prompt(self, capability_name: str, description: str, requirements: List[str] = None) -> str:
        reqs_text = ""
        if requirements:
            reqs_text = "\nRequirements:\n" + "\n".join("- " + r for r in requirements)

        return """Ek complete Python capability class bana:

Capability Name: """ + capability_name + """
Description: """ + description + reqs_text + """

Code structure:
1. Proper imports at top
2. Main class with descriptive name
3. __init__ method for setup
4. Main functionality methods
5. Error handling with try-except
6. Return Dict with 'success' and 'result' or 'error' keys
7. Docstrings in Hindi/English mix
8. Type hints

Full working code de."""

    def generate_capability_code(self, capability_name: str, description: str, requirements: List[str] = None) -> str:
        if not self.is_connected:
            if not self.connect():
                return "# Ollama not connected. Cannot generate capability."

        prompt = self._get_capability_prompt(capability_name, description, requirements)

        try:
            response = ollama.chat(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "Tu ek expert Python developer hai. Production-ready code likh with proper error handling."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                options={"temperature": 0.3}
            )
            
            code = response['message']['content']
            
            patterns = [
                r'```python\s*([\s\S]*?)\s*```',
                r'```\s*([\s\S]*?)\s*```'
            ]
            
            for pattern in patterns:
                code_match = re.search(pattern, code)
                if code_match:
                    return code_match.group(1).strip()
            
            return code
            
        except Exception as e:
            return "# Error generating capability: " + str(e)

    def _get_improve_prompt(self, code: str, improvement_request: str) -> str:
        return """Is code ko improve kar:

Current Code:
\"\"\"
""" + code + """
\"\"\"

Improvement Request: """ + improvement_request + """

Improved code de with:
1. Requested improvements
2. Better error handling (agar nahi hai)
3. Better comments
4. Same functionality preserved

Sirf improved code return kar."""

    def improve_code(self, code: str, improvement_request: str) -> str:
        if not self.is_connected:
            if not self.connect():
                return code

        prompt = self._get_improve_prompt(code, improvement_request)

        try:
            response = ollama.chat(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "Tu ek code reviewer hai. Code improve kar without breaking functionality."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                options={"temperature": 0.3}
            )
            
            improved = response['message']['content']
            
            patterns = [
                r'```python\s*([\s\S]*?)\s*```',
                r'```\s*([\s\S]*?)\s*```',
                r'"""([\s\S]*?)"""'
            ]
            
            for pattern in patterns:
                code_match = re.search(pattern, improved)
                if code_match:
                    return code_match.group(1).strip()
            
            return improved
            
        except Exception:
            return code

    def _get_explain_prompt(self, code: str) -> str:
        return """Is code ko simple Hinglish mein explain kar:

CODE:
\"\"\"
""" + code + """
\"\"\"

Explanation mein include kar:
1. Code kya karta hai (summary)
2. Main functions/classes kya hain
3. Important variables
4. Flow kaise hai

Simple language mein explain kar."""

    def explain_code(self, code: str) -> str:
        if not self.is_connected:
            if not self.connect():
                return "Cannot explain - Ollama not connected."

        prompt = self._get_explain_prompt(code)

        try:
            response = ollama.chat(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "Tu ek teacher hai jo code explain karta hai simple language mein."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                options={"temperature": 0.5}
            )
            
            return response['message']['content']
            
        except Exception as e:
            return "Explanation error: " + str(e)

    def _get_suggestions_prompt(self, code: str) -> str:
        return """Is code ke liye improvements suggest kar:

CODE:
\"\"\"
""" + code + """
\"\"\"

Response is JSON format mein:
{
    "suggestions": [
        {"type": "performance", "suggestion": "...", "priority": "high ya medium ya low"},
        {"type": "readability", "suggestion": "...", "priority": "high ya medium ya low"}
    ]
}

Sirf JSON return kar."""

    def suggest_improvements(self, code: str) -> List[Dict[str, str]]:
        if not self.is_connected:
            return []

        prompt = self._get_suggestions_prompt(code)

        try:
            response = ollama.chat(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                options={"temperature": 0.3}
            )
            
            result = self._parse_thought(response['message']['content'])
            return result.get("suggestions", [])
            
        except Exception:
            return []

    def _get_chat_prompt(self, user_input: str, context: str) -> str:
        base = "User ne ye bola: " + user_input
        
        if context:
            base += "\n\nPrevious context: " + context
        
        base += """

Ek friendly, helpful response de in Hinglish.
- Casual aur friendly tone
- Helpful ho
- Concise ho (2-3 lines max for simple queries)
- Agar kuch nahi pata to honestly bol"""
        
        return base

    def generate_chat_response(self, user_input: str, context: str = "") -> str:
        if not self.is_connected:
            if not self.connect():
                return "Bhai, abhi Ollama se connection nahi hai. Thodi der baad try kar."

        prompt = self._get_chat_prompt(user_input, context)

        try:
            response = ollama.chat(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "Tu JEEVA hai, ek friendly AI assistant. Hinglish mein baat kar. Casual aur helpful reh."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                options={"temperature": 0.7}
            )
            
            return response['message']['content']
            
        except Exception as e:
            return "Bhai, response generate karne mein problem aa gayi: " + str(e)[:50]

    def get_thinking_history(self, limit: int = 20) -> List[Dict]:
        return self.thinking_history[-limit:]

    def clear_history(self):
        self.thinking_history = []

    def get_stats(self) -> Dict[str, Any]:
        return {
            "is_connected": self.is_connected,
            "model": self.model,
            "history_count": len(self.thinking_history),
            "ollama_host": self.ollama_host
        }