"""
Intent Detector - Detect if user wants to chat or get work done
User ke intent ko accurately detect karta hai
"""

from typing import Dict, Any, Tuple, List
from enum import Enum


class IntentType(Enum):
    CHAT = "chat"
    ACTION = "action"
    QUESTION = "question"
    CODE_REQUEST = "code_request"
    CAPABILITY_REQUEST = "capability_request"
    SYSTEM_COMMAND = "system_command"
    SELF_MODIFY = "self_modify"
    UNKNOWN = "unknown"


class IntentDetector:
    """
    User ke intent ko detect karo
    - Chat: Casual baat cheet
    - Action: Kuch karna hai
    - Question: Kuch puchna hai
    - Code Request: Code likhna hai
    - Capability Request: Nayi capability chahiye
    - Self Modify: Khud ko update karna hai
    """

    def __init__(self, thinking_engine=None):
        self.thinking_engine = thinking_engine
        self._initialize_keywords()

    def _initialize_keywords(self):
        """Initialize all keyword lists"""
        
        self.action_keywords = [
            "open", "khol", "close", "band", "start", "stop", "run",
            "create", "bana", "banao", "delete", "hata", "hatao",
            "chala", "chalao", "execute", "install", "download",
            "upload", "send", "bhej", "bhejo", "move", "copy",
            "rename", "search", "find", "dhoond", "dhoondo",
            "save", "load", "fetch", "get", "le", "la", "lao",
            "do", "kar", "karo", "karde", "kardena", "krde", "krdo",
            "dikha", "dikhao", "show", "list", "remove", "add",
            "set", "change", "update", "modify", "edit"
        ]

        self.question_keywords = [
            "kya", "kaise", "kyu", "kyun", "kab", "kahan", "kaun",
            "what", "how", "why", "when", "where", "who", "which",
            "?", "bta", "bata", "batao", "explain", "samjha",
            "samjhao", "tell", "describe", "meaning", "matlab",
            "difference", "compare", "kon", "kitna", "kitne"
        ]

        self.code_keywords = [
            "code", "script", "program", "function", "class",
            "fix", "debug", "error", "bug", "feature", "add code",
            "modify code", "change code", "update code", "likh",
            "likho", "likhna", "implement", "create function",
            "create class", "method", "variable", "loop", "algorithm",
            "syntax", "compile", "runtime"
        ]

        self.capability_keywords = [
            "capability", "feature", "power", "ability", "skill",
            "sakta", "kar sakta", "ho sakta", "add kar", "add karo",
            "seekh", "learn", "sikh", "sikho", "seekho", "sikhna",
            "banana", "bana de", "bana do", "add karde", "install kar",
            "new feature", "nayi", "naya", "seekh le", "seekh ja"
        ]

        self.self_modify_keywords = [
            "khud", "apne", "self", "tere", "tumhare", "apna",
            "tera", "tumhara", "khudko", "khud ko", "apne aap",
            "improve yourself", "update yourself", "fix yourself",
            "tera code", "tumhara code", "apna code", "khud ka code",
            "tujhe", "tumhe", "apne ko"
        ]

        self.modify_action_keywords = [
            "update", "modify", "change", "improve", "fix",
            "badal", "badlo", "sudhar", "sudharo", "theek",
            "theek kar", "better", "enhance", "upgrade", "optimize"
        ]

        self.chat_keywords = [
            "hi", "hello", "hey", "bhai", "dost", "yaar", "bro",
            "kya haal", "kaisa hai", "kaise ho", "good", "nice",
            "thanks", "thank you", "shukriya", "dhanyawad",
            "theek", "thik", "haan", "nahi", "ok", "okay", "fine",
            "hmm", "accha", "acha", "sahi", "badiya", "mast",
            "bye", "goodbye", "alvida", "tata", "chal", "baad mein",
            "good morning", "good night", "suprabhat", "shubh ratri"
        ]

        self.system_keywords = [
            "system", "os", "windows", "linux", "mac", "terminal",
            "cmd", "command", "shell", "process", "task", "memory",
            "cpu", "disk", "network", "wifi", "bluetooth", "restart",
            "shutdown", "reboot", "kill", "terminate"
        ]

    def detect(self, user_input: str) -> Tuple[IntentType, float, Dict[str, Any]]:
        """
        Detect user intent
        
        Args:
            user_input: What user said
            
        Returns:
            Tuple of (intent_type, confidence, details)
        """
        if not user_input or not user_input.strip():
            return IntentType.UNKNOWN, 0.0, {"error": "Empty input"}

        input_lower = user_input.lower().strip()
        input_words = set(input_lower.split())

        scores = {
            IntentType.CHAT: self._score_chat(input_lower, input_words),
            IntentType.ACTION: self._score_action(input_lower, input_words),
            IntentType.QUESTION: self._score_question(input_lower, input_words),
            IntentType.CODE_REQUEST: self._score_code(input_lower, input_words),
            IntentType.CAPABILITY_REQUEST: self._score_capability(input_lower, input_words),
            IntentType.SELF_MODIFY: self._score_self_modify(input_lower, input_words),
            IntentType.SYSTEM_COMMAND: self._score_system(input_lower, input_words)
        }

        max_intent = max(scores, key=scores.get)
        max_score = scores[max_intent]

        if max_score < 0.3:
            if self.thinking_engine:
                return self._deep_detect(user_input)
            else:
                max_intent = IntentType.CHAT
                max_score = 0.5

        details = {
            "all_scores": {k.value: round(v, 2) for k, v in scores.items()},
            "detected_keywords": self._get_detected_keywords(input_lower),
            "input_length": len(user_input),
            "word_count": len(input_words),
            "has_question_mark": "?" in user_input,
            "is_short": len(input_words) <= 3
        }

        return max_intent, round(max_score, 2), details

    def _score_chat(self, text: str, words: set) -> float:
        score = 0.0

        for keyword in self.chat_keywords:
            if keyword in text:
                score += 0.2

        if len(words) <= 2:
            score += 0.3

        if len(words) == 1 and list(words)[0] in self.chat_keywords:
            score += 0.4

        greetings = ["hi", "hello", "hey", "bye", "thanks"]
        if any(g in text for g in greetings):
            score += 0.3

        return min(score, 1.0)

    def _score_action(self, text: str, words: set) -> float:
        score = 0.0

        for keyword in self.action_keywords:
            if keyword in words or keyword in text:
                score += 0.2

        word_list = text.split()
        if word_list and word_list[0] in self.action_keywords:
            score += 0.3

        imperative_endings = ["kar", "karo", "de", "do", "le", "lo"]
        if word_list and any(word_list[-1].endswith(end) for end in imperative_endings):
            score += 0.2

        return min(score, 1.0)

    def _score_question(self, text: str, words: set) -> float:
        score = 0.0

        if "?" in text:
            score += 0.5

        for keyword in self.question_keywords:
            if keyword in words or text.startswith(keyword):
                score += 0.25

        word_list = text.split()
        if word_list and word_list[0] in self.question_keywords:
            score += 0.2

        return min(score, 1.0)

    def _score_code(self, text: str, words: set) -> float:
        score = 0.0

        for keyword in self.code_keywords:
            if keyword in text:
                score += 0.25

        if "```" in text:
            score += 0.5

        code_indicators = ["python", "javascript", "function", "class", "def ", "import "]
        for indicator in code_indicators:
            if indicator in text:
                score += 0.2

        return min(score, 1.0)

    def _score_capability(self, text: str, words: set) -> float:
        score = 0.0

        for keyword in self.capability_keywords:
            if keyword in text:
                score += 0.2

        if "nahi hai" in text or "nhi hai" in text:
            if any(k in text for k in ["bana", "add", "seekh", "install"]):
                score += 0.4

        if ("bana" in text or "add" in text) and ("feature" in text or "capability" in text):
            score += 0.3

        if "seekh" in text or "learn" in text or "sikh" in text:
            score += 0.25

        return min(score, 1.0)

    def _score_self_modify(self, text: str, words: set) -> float:
        score = 0.0

        has_self = any(k in text for k in self.self_modify_keywords)
        has_modify = any(k in text for k in self.modify_action_keywords)

        if has_self and has_modify:
            score = 0.85
        elif has_self and any(k in text for k in ["code", "system", "feature"]):
            score = 0.7
        elif has_self:
            score = 0.3
        elif has_modify and ("code" in text or "system" in text):
            score = 0.4

        if "apne aap" in text or "khud ko" in text:
            score += 0.2

        return min(score, 1.0)

    def _score_system(self, text: str, words: set) -> float:
        score = 0.0

        for keyword in self.system_keywords:
            if keyword in text:
                score += 0.25

        dangerous_commands = ["shutdown", "restart", "reboot", "kill", "terminate", "format"]
        for cmd in dangerous_commands:
            if cmd in text:
                score += 0.3

        return min(score, 1.0)

    def _get_detected_keywords(self, text: str) -> List[str]:
        detected = []
        
        all_keywords = (
            self.action_keywords +
            self.question_keywords +
            self.code_keywords +
            self.capability_keywords +
            self.chat_keywords +
            self.self_modify_keywords +
            self.system_keywords
        )

        for keyword in all_keywords:
            if keyword in text and keyword not in detected:
                detected.append(keyword)
                if len(detected) >= 10:
                    break

        return detected

    def _deep_detect(self, user_input: str) -> Tuple[IntentType, float, Dict[str, Any]]:
        """Use thinking engine for deep detection when unsure"""
        if not self.thinking_engine:
            return IntentType.UNKNOWN, 0.3, {"method": "fallback"}

        try:
            thought = self.thinking_engine.think(
                context="Intent detection needed. Determine what user wants.",
                question=user_input
            )

            intent_map = {
                "chat": IntentType.CHAT,
                "action": IntentType.ACTION,
                "question": IntentType.QUESTION,
                "code_request": IntentType.CODE_REQUEST,
                "capability_request": IntentType.CAPABILITY_REQUEST,
                "self_modify": IntentType.SELF_MODIFY,
                "system_command": IntentType.SYSTEM_COMMAND
            }

            detected_intent = thought.get("intent_type", "unknown")
            intent_type = intent_map.get(detected_intent, IntentType.UNKNOWN)
            confidence = thought.get("confidence", 50) / 100

            return intent_type, confidence, {
                "method": "deep_detection",
                "thought": thought
            }

        except Exception as e:
            return IntentType.UNKNOWN, 0.3, {"error": str(e)}

    def get_intent_description(self, intent_type: IntentType) -> str:
        """Get human readable description of intent"""
        descriptions = {
            IntentType.CHAT: "Casual conversation / baat cheet",
            IntentType.ACTION: "Wants to perform an action / kuch karna hai",
            IntentType.QUESTION: "Asking a question / sawaal puch raha hai",
            IntentType.CODE_REQUEST: "Wants code written / code likhwana hai",
            IntentType.CAPABILITY_REQUEST: "Wants new capability / nayi feature chahiye",
            IntentType.SELF_MODIFY: "Wants agent to modify itself / agent khud update kare",
            IntentType.SYSTEM_COMMAND: "System level command / system command",
            IntentType.UNKNOWN: "Could not determine intent / samajh nahi aaya"
        }
        return descriptions.get(intent_type, "Unknown")

    def is_dangerous_intent(self, intent_type: IntentType, details: Dict) -> bool:
        """Check if the intent is potentially dangerous"""
        dangerous_intents = [IntentType.SELF_MODIFY, IntentType.SYSTEM_COMMAND]
        
        if intent_type in dangerous_intents:
            return True

        keywords = details.get("detected_keywords", [])
        dangerous_keywords = ["delete", "remove", "hata", "shutdown", "kill", "format"]
        
        return any(k in keywords for k in dangerous_keywords)