# 🧠 JEEVA - Self-Developing AI Agent

<div align="center">

**An intelligent AI agent that can learn, self-modify, and grow its capabilities**

[![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![Ollama](https://img.shields.io/badge/Ollama-Required-green.svg)](https://ollama.ai/)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

</div>

---

## 🌟 Features

### 🤖 Self-Development
- **Dynamic Capability Building**: Can create new skills on demand
- **Self-Modification**: Improves own code with permission
- **Hot Reload**: Updates without restart
- **Learning Engine**: Learns from every interaction

### 💬 Hinglish Communication
- Natural Hindi-English mix conversations
- Friendly and casual tone
- Honest about limitations
- Context-aware responses

### 🔐 Security First
- Permission system for code changes
- Risk assessment before actions
- Sandbox mode for safe execution
- Backup before modifications

### 🧠 Advanced Intelligence
- **Ollama Integration**: Uses LLaMA 3.2 for deep thinking
- **Intent Detection**: Understands user requests
- **Context Memory**: Remembers conversation history
- **Consciousness System**: Self-awareness and state tracking

---

## 🚀 Quick Start

### Prerequisites
- Python 3.8 or higher
- [Ollama](https://ollama.ai/download) installed and running

### Installation

1. **Install Dependencies**
   ```bash
   # Run the installer script
   install_dependencies.bat
   
   # Or manually
   pip install ollama pyyaml rich prompt_toolkit psutil requests colorama black
   ```

2. **Setup Ollama**
   ```bash
   # Start Ollama server
   ollama serve
   
   # Pull the model (in another terminal)
   ollama pull llama3.2
   ```

3. **Check System**
   ```bash
   python check_system.py
   ```

4. **Run JEEVA**
   ```bash
   # Simple start
   python main.py
   
   # Or with supervisor (recommended)
   python jeeva_supervisor.py
   
   # Or use batch file
   start_jeeva.bat
   ```

---

## 📖 Usage Examples

### Basic Conversation
```
You: kya hal hai?
JEEVA: Sab badhiya bhai! Kya kaam hai?

You: tu kaun hai?
JEEVA: Main JEEVA hu - ek self-developing AI agent. 
       Main seekh sakta hu, code likh sakta hu, 
       aur khud ko improve bhi kar sakta hu!
```

### File Operations
```
You: ek file bana readme.txt naam se
JEEVA: ✅ Haan bhai, ye main kar sakta hu!

      📋 Ye steps follow karunga:
         1. readme.txt file create karunga
         2. Basic content add karunga
         3. Save karke confirm karunga
      
      🔐 Permission chahiye. Karun? (haan/nahi)

You: haan
JEEVA: ✅ File created successfully!
```

### Code Generation
```
You: calculator ka code likh
JEEVA: 💻 Code generate kiya hai:

      ```python
      def calculator():
          # Simple calculator
          ...
      ```
      
      ✅ Code error-free lagta hai!
      
      🔐 Code run karun? (haan/nahi)
```

### Building New Capabilities
```
You: browser open karne ki capability bana
JEEVA: 💡 Ye capability main bana sakta hu!

      📋 Iske liye ye karunga:
         1. Browser control module create karunga
         2. Cross-platform support add karunga
         3. Testing karke activate karunga
      
      ⚠️ Risks:
         • System access required
         • May need admin permissions
      
      🔐 Permission de, bana dun? (haan/nahi)
```

### Self-Improvement
```
You: apne error handling ko better bana
JEEVA: 🔧 Self-modification request!

      📋 Samjha: Improve error handling system
      
      Ye karunga:
         1. Current error handling analyze karunga
         2. Better try-catch blocks add karunga
         3. Logging improve karunga
         4. Backup le kar apply karunga
      
      ⚠️ Important:
         • Apna code modify karunga
         • Pehle backup lunga
         • Error check karunga
         • Restart ho sakta hai
      
      🔐 Teri explicit permission chahiye. Karun? (haan/nahi)
```

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────┐
│           JEEVA Brain                    │
│  (Main Orchestrator & Coordinator)       │
└──────────────┬──────────────────────────┘
               │
       ┌───────┴───────┐
       │               │
┌──────▼──────┐  ┌────▼────────┐
│  Thinking   │  │ Consciousness│
│  Engine     │  │   System     │
│  (Ollama)   │  │ (Self-Aware) │
└──────┬──────┘  └────┬─────────┘
       │               │
       └───────┬───────┘
               │
    ┌──────────┼──────────┐
    │          │          │
┌───▼───┐  ┌──▼──┐  ┌───▼────┐
│Learning│  │Tools│  │Security│
│Engine  │  │     │  │Manager │
└────────┘  └─────┘  └────────┘
```

### Core Components

#### 🧠 Brain (`core/brain.py`)
- Main orchestrator
- Coordinates all components
- Handles user interactions
- Manages action flow

#### 💭 Thinking Engine (`core/thinking_engine.py`)
- Ollama integration
- Deep reasoning
- Code analysis
- Response generation

#### 🎯 Intent Detector (`core/intent_detector.py`)
- Detects user intent
- Classifies requests
- Confidence scoring

#### 🤝 Honesty Engine (`core/honesty_engine.py`)
- Ensures honest responses
- Admits limitations
- Risk warnings

#### 🔄 Hot Reloader (`core/hot_reloader.py`)
- Live code updates
- No restart needed
- Config reloading

#### 💾 Memory Manager (`learning/memory_manager.py`)
- Conversation history
- Context memory
- Long-term storage

#### 🛡️ Permission Manager (`security/permission_manager.py`)
- Action authorization
- Risk assessment
- User confirmation

---

## ⚙️ Configuration

### `config/settings.yaml`

```yaml
agent:
  name: "JEEVA"
  version: "1.0.0"
  owner: "Boss"
  language: "hinglish"

ollama:
  host: "http://localhost:11434"
  thinking_model: "llama3.2"
  timeout: 120

security:
  require_permission_for_code_changes: true
  require_permission_for_system_access: true
  max_backup_count: 10
  sandbox_enabled: true

learning:
  enabled: true
  auto_save_interval: 300
  max_memory_items: 10000

behavior:
  always_honest: true
  explain_before_action: true
  ask_before_dangerous_action: true
  show_thinking_process: false

restart:
  supervisor_port: 19999
  state_save_on_restart: true
  auto_restart_on_crash: true
```

### `config/capabilities.yaml`

```yaml
capabilities:
  file_operations:
    installed: true
    description: "File read, write, create, delete"
    risk_level: "medium"
  
  system_info:
    installed: true
    description: "Get system information"
    risk_level: "low"
  
  code_execution:
    installed: true
    description: "Execute Python code"
    risk_level: "critical"
  
  self_modification:
    installed: true
    description: "Modify own code"
    risk_level: "critical"
  
  browser_control:
    installed: false
    description: "Control web browser"
    risk_level: "high"
    can_be_built: true
```

---

## 🛠️ Development

### Project Structure

```
jeeva/
├── main.py                    # Main entry point
├── jeeva_supervisor.py        # Process supervisor
├── requirements.txt           # Python dependencies
├── check_system.py           # System verification tool
├── config/
│   ├── settings.yaml         # Main configuration
│   └── capabilities.yaml     # Capability definitions
├── core/
│   ├── brain.py             # Main orchestrator
│   ├── thinking_engine.py   # Ollama integration
│   ├── consciousness.py     # Self-awareness system
│   ├── honesty_engine.py    # Honesty system
│   ├── intent_detector.py   # Intent detection
│   ├── hot_reloader.py      # Hot reload system
│   └── self_restart.py      # Restart manager
├── learning/
│   ├── memory_manager.py    # Memory system
│   └── self_learner.py      # Learning engine
├── security/
│   └── permission_manager.py # Permission system
├── capabilities/
│   └── capability_manager.py # Capability manager
├── self_development/
│   ├── code_generator.py    # Code generation
│   ├── code_modifier.py     # Code modification
│   └── error_checker.py     # Error checking
├── tools/
│   ├── file_tools.py        # File operations
│   ├── system_tools.py      # System operations
│   └── github_tools.py      # GitHub integration
└── data/
    ├── supervisor/          # Supervisor data
    ├── logs/               # Log files
    ├── memory/             # Memory storage
    ├── learning/           # Learning data
    ├── backups/            # Code backups
    └── permissions/        # Permission records
```

### Adding New Capabilities

1. Create a new file in `tools/`
2. Implement your capability class
3. Add entry to `config/capabilities.yaml`
4. Register in Brain if needed

Example:
```python
# tools/my_capability.py

class MyCapability:
    """My custom capability"""
    
    def __init__(self):
        self.name = "my_capability"
    
    def execute(self, params):
        """Execute the capability"""
        try:
            # Your logic here
            return {
                "success": True,
                "result": "Done!"
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
```

---

## 🐛 Troubleshooting

### Ollama Connection Issues

```bash
# Check if Ollama is running
curl http://localhost:11434/api/tags

# Start Ollama
ollama serve

# Check available models
ollama list

# Pull required model
ollama pull llama3.2
```

### Import Errors

```bash
# Reinstall all dependencies
pip install -r requirements.txt

# Or use the batch file
install_dependencies.bat
```

### Permission Errors

- Check `config/settings.yaml`
- Ensure permissions are set correctly
- Run with admin rights if needed

### Data Directory Issues

```bash
# Run system check
python check_system.py

# It will auto-create missing directories
```

---

## 📊 System Check

Run the system check tool to verify everything is working:

```bash
python check_system.py
```

Output:
```
==================================================
🔍 JEEVA SYSTEM CHECK
==================================================
✅ Python Version
✅ Dependencies
✅ Ollama Connection
✅ Data Directories
✅ Config Files
✅ Core Files
==================================================
🎉 All checks passed! JEEVA is ready to run!
```

---

## 🔐 Security Features

### Permission System
- All code modifications require explicit permission
- System-level operations need confirmation
- Risk assessment before dangerous actions

### Sandbox Mode
- Execute code in isolated environment
- Limited system access
- Safe testing environment

### Backup System
- Automatic backups before modifications
- Rolling backup with configurable count
- Easy rollback on errors

### Honesty Engine
- Never lies or misleads
- Admits when doesn't know something
- Warns about potential risks
- Explains limitations clearly

---

## 🎯 Roadmap

- [x] Core brain system
- [x] Ollama integration
- [x] Permission system
- [x] Hot reload
- [x] Memory management
- [x] Self-modification
- [ ] Web interface
- [ ] Voice interaction
- [ ] Multi-agent collaboration
- [ ] Advanced learning algorithms
- [ ] Plugin system

---

## 🤝 Contributing

Contributions welcome! Please:
1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

---

## 📝 License

MIT License - See LICENSE file for details

---

## 💡 Tips

1. **Start Ollama First**: Always ensure Ollama is running before starting JEEVA
2. **Use Supervisor**: Run with `jeeva_supervisor.py` for better stability
3. **Check System**: Run `check_system.py` if you face issues
4. **Read Config**: Check `config/settings.yaml` to customize behavior
5. **Be Patient**: First run may take time to load models

---

## 📞 Support

- **Issues**: Report bugs via GitHub Issues
- **Questions**: Check documentation first
- **Features**: Suggest via Pull Requests

---

<div align="center">

**Made with ❤️ by the JEEVA Team**

*An AI that grows with you*

</div>
