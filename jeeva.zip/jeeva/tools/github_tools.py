"""
GitHub Tools - GitHub repos search, scrape and save karne ke liye
JEEVA ke liye GitHub integration
"""

import os
import json
import time
import base64
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, asdict, field


@dataclass
class RepoInfo:
    """Repository information structure"""
    name: str
    full_name: str
    description: str
    url: str
    html_url: str
    stars: int
    forks: int
    watchers: int
    language: str
    topics: List[str]
    created_at: str
    updated_at: str
    license: str
    owner: str
    owner_url: str
    default_branch: str
    open_issues: int
    size: int
    scraped_at: str = field(default_factory=lambda: datetime.now().isoformat())


class GitHubTools:
    """
    GitHub se repos search aur scrape karta hai
    
    Features:
    - Search repositories
    - Get repository details
    - Save repos to local database
    - Search saved repos
    - Get README and file contents
    """

    def __init__(self, data_path: str = "data/github_repos", token: str = None):
        self.data_path = Path(data_path)
        self.data_path.mkdir(parents=True, exist_ok=True)
        
        self.base_url = "https://api.github.com"
        self.token = token or os.environ.get("GITHUB_TOKEN")
        
        self.headers = {
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "JEEVA-Agent"
        }
        
        if self.token:
            self.headers["Authorization"] = f"token {self.token}"
        
        self.db_path = self.data_path / "repos_database.json"
        self.index_path = self.data_path / "search_index.json"
        
        self.database = self._load_database()
        self.search_index = self._load_index()
        
        self.last_request_time = 0
        self.min_request_interval = 1.0
        
        self.request_count = 0
        self.cache = {}

    def _load_database(self) -> Dict[str, Any]:
        """Load repos database"""
        if self.db_path.exists():
            try:
                with open(self.db_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception:
                pass
        
        return {
            "repos": {},
            "collections": {},
            "stats": {
                "total_repos": 0,
                "created_at": datetime.now().isoformat()
            }
        }

    def _load_index(self) -> Dict[str, List[str]]:
        """Load search index"""
        if self.index_path.exists():
            try:
                with open(self.index_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception:
                pass
        
        return {
            "by_name": {},
            "by_language": {},
            "by_topic": {},
            "by_keyword": {}
        }

    def _save_database(self):
        """Save repos database"""
        try:
            with open(self.db_path, 'w', encoding='utf-8') as f:
                json.dump(self.database, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Error saving database: {e}")

    def _save_index(self):
        """Save search index"""
        try:
            with open(self.index_path, 'w', encoding='utf-8') as f:
                json.dump(self.search_index, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Error saving index: {e}")

    def _rate_limit(self):
        """Respect rate limits"""
        elapsed = time.time() - self.last_request_time
        if elapsed < self.min_request_interval:
            time.sleep(self.min_request_interval - elapsed)
        self.last_request_time = time.time()

    def _make_request(self, url: str, params: Dict = None) -> Dict[str, Any]:
        """Make API request with rate limiting"""
        try:
            import requests
        except ImportError:
            return {"success": False, "error": "requests library not installed. Run: pip install requests"}
        
        self._rate_limit()
        self.request_count += 1
        
        try:
            response = requests.get(url, headers=self.headers, params=params, timeout=30)
            
            if response.status_code == 200:
                return {"success": True, "data": response.json()}
            elif response.status_code == 403:
                return {"success": False, "error": "Rate limit exceeded. Try again later or add GITHUB_TOKEN."}
            elif response.status_code == 404:
                return {"success": False, "error": "Not found"}
            elif response.status_code == 401:
                return {"success": False, "error": "Unauthorized. Check your GITHUB_TOKEN."}
            else:
                return {"success": False, "error": f"HTTP {response.status_code}: {response.text[:200]}"}
                
        except Exception as e:
            return {"success": False, "error": str(e)}

    def search_repos(
        self,
        query: str,
        max_results: int = 30,
        sort: str = "stars",
        order: str = "desc",
        language: str = None,
        save: bool = True
    ) -> Dict[str, Any]:
        """
        GitHub pe repos search karo
        
        Args:
            query: Search query
            max_results: Maximum repos to fetch
            sort: Sort by (stars, forks, updated)
            order: Order (desc, asc)
            language: Filter by language
            save: Save results to database
            
        Returns:
            Dict with search results
        """
        search_query = query
        if language:
            search_query += f" language:{language}"
        
        all_repos = []
        page = 1
        per_page = min(100, max_results)
        
        while len(all_repos) < max_results:
            url = f"{self.base_url}/search/repositories"
            params = {
                "q": search_query,
                "sort": sort,
                "order": order,
                "page": page,
                "per_page": per_page
            }
            
            result = self._make_request(url, params)
            
            if not result["success"]:
                if all_repos:
                    break
                return result
            
            items = result["data"].get("items", [])
            if not items:
                break
            
            total_count = result["data"].get("total_count", 0)
            
            for item in items:
                if len(all_repos) >= max_results:
                    break
                
                repo_info = RepoInfo(
                    name=item.get("name", ""),
                    full_name=item.get("full_name", ""),
                    description=item.get("description") or "",
                    url=item.get("url", ""),
                    html_url=item.get("html_url", ""),
                    stars=item.get("stargazers_count", 0),
                    forks=item.get("forks_count", 0),
                    watchers=item.get("watchers_count", 0),
                    language=item.get("language") or "Unknown",
                    topics=item.get("topics", []),
                    created_at=item.get("created_at", ""),
                    updated_at=item.get("updated_at", ""),
                    license=item.get("license", {}).get("name") if item.get("license") else "None",
                    owner=item.get("owner", {}).get("login", ""),
                    owner_url=item.get("owner", {}).get("html_url", ""),
                    default_branch=item.get("default_branch", "main"),
                    open_issues=item.get("open_issues_count", 0),
                    size=item.get("size", 0)
                )
                all_repos.append(repo_info)
            
            page += 1
            
            if len(all_repos) >= total_count:
                break
        
        if save and all_repos:
            collection_name = query.replace(" ", "_")[:30]
            self.save_repos(all_repos, collection_name)
        
        return {
            "success": True,
            "query": query,
            "total_found": result["data"].get("total_count", len(all_repos)),
            "fetched": len(all_repos),
            "repos": [asdict(r) for r in all_repos]
        }

    def save_repos(self, repos: List[RepoInfo], collection_name: str = "default") -> Dict[str, Any]:
        """
        Repos ko database mein save karo
        
        Args:
            repos: List of RepoInfo objects
            collection_name: Collection name
            
        Returns:
            Dict with result
        """
        saved_count = 0
        
        for repo in repos:
            repo_id = repo.full_name.replace("/", "_")
            
            if isinstance(repo, RepoInfo):
                self.database["repos"][repo_id] = asdict(repo)
            else:
                self.database["repos"][repo_id] = repo
            
            self._update_index(repo if isinstance(repo, RepoInfo) else RepoInfo(**repo))
            saved_count += 1
        
        if collection_name not in self.database["collections"]:
            self.database["collections"][collection_name] = {
                "created_at": datetime.now().isoformat(),
                "repos": []
            }
        
        collection_repos = [r.full_name if isinstance(r, RepoInfo) else r.get("full_name", "") for r in repos]
        self.database["collections"][collection_name]["repos"].extend(collection_repos)
        self.database["collections"][collection_name]["repos"] = list(
            set(self.database["collections"][collection_name]["repos"])
        )
        
        self.database["stats"]["total_repos"] = len(self.database["repos"])
        self.database["stats"]["last_updated"] = datetime.now().isoformat()
        
        self._save_database()
        self._save_index()
        
        return {
            "success": True,
            "saved": saved_count,
            "collection": collection_name,
            "total_in_db": len(self.database["repos"])
        }

    def _update_index(self, repo: RepoInfo):
        """Update search indexes"""
        repo_id = repo.full_name.replace("/", "_")
        
        name_lower = repo.name.lower()
        if name_lower not in self.search_index["by_name"]:
            self.search_index["by_name"][name_lower] = []
        if repo_id not in self.search_index["by_name"][name_lower]:
            self.search_index["by_name"][name_lower].append(repo_id)
        
        lang = repo.language.lower()
        if lang not in self.search_index["by_language"]:
            self.search_index["by_language"][lang] = []
        if repo_id not in self.search_index["by_language"][lang]:
            self.search_index["by_language"][lang].append(repo_id)
        
        for topic in repo.topics:
            topic_lower = topic.lower()
            if topic_lower not in self.search_index["by_topic"]:
                self.search_index["by_topic"][topic_lower] = []
            if repo_id not in self.search_index["by_topic"][topic_lower]:
                self.search_index["by_topic"][topic_lower].append(repo_id)
        
        keywords = set()
        keywords.update(repo.name.lower().replace("-", " ").replace("_", " ").split())
        if repo.description:
            words = repo.description.lower().split()
            keywords.update(w for w in words if len(w) > 3)
        
        for keyword in list(keywords)[:20]:
            if keyword not in self.search_index["by_keyword"]:
                self.search_index["by_keyword"][keyword] = []
            if repo_id not in self.search_index["by_keyword"][keyword]:
                self.search_index["by_keyword"][keyword].append(repo_id)

    def get_repo(self, repo_name: str) -> Optional[Dict[str, Any]]:
        """
        Saved repo details lo
        
        Args:
            repo_name: Repository name or full name
            
        Returns:
            Repo data or None
        """
        repo_id = repo_name.replace("/", "_")
        if repo_id in self.database["repos"]:
            return self.database["repos"][repo_id]
        
        name_lower = repo_name.lower()
        if name_lower in self.search_index["by_name"]:
            repo_ids = self.search_index["by_name"][name_lower]
            if repo_ids:
                return self.database["repos"].get(repo_ids[0])
        
        for repo_id, repo_data in self.database["repos"].items():
            if name_lower in repo_id.lower() or name_lower in repo_data.get("name", "").lower():
                return repo_data
        
        return None

    def search_saved_repos(
        self,
        query: str = None,
        language: str = None,
        topic: str = None,
        min_stars: int = 0,
        limit: int = 20
    ) -> List[Dict[str, Any]]:
        """
        Saved repos mein search karo
        
        Args:
            query: Search query
            language: Filter by language
            topic: Filter by topic
            min_stars: Minimum stars
            limit: Maximum results
            
        Returns:
            List of matching repos
        """
        repo_ids = set()
        
        if query:
            query_lower = query.lower()
            
            if query_lower in self.search_index["by_keyword"]:
                repo_ids.update(self.search_index["by_keyword"][query_lower])
            
            for name, ids in self.search_index["by_name"].items():
                if query_lower in name:
                    repo_ids.update(ids)
            
            for topic_name, ids in self.search_index["by_topic"].items():
                if query_lower in topic_name:
                    repo_ids.update(ids)
        else:
            repo_ids = set(self.database["repos"].keys())
        
        if language:
            lang_repos = set(self.search_index["by_language"].get(language.lower(), []))
            repo_ids = repo_ids.intersection(lang_repos) if repo_ids else lang_repos
        
        if topic:
            topic_repos = set(self.search_index["by_topic"].get(topic.lower(), []))
            repo_ids = repo_ids.intersection(topic_repos) if repo_ids else topic_repos
        
        results = []
        for repo_id in repo_ids:
            repo_data = self.database["repos"].get(repo_id)
            if repo_data and repo_data.get("stars", 0) >= min_stars:
                results.append(repo_data)
        
        results.sort(key=lambda x: x.get("stars", 0), reverse=True)
        
        return results[:limit]

    def get_repo_readme(self, repo_full_name: str) -> Dict[str, Any]:
        """
        Repo ka README fetch karo
        
        Args:
            repo_full_name: Full repo name (owner/repo)
            
        Returns:
            Dict with README content
        """
        url = f"{self.base_url}/repos/{repo_full_name}/readme"
        result = self._make_request(url)
        
        if result["success"]:
            content = result["data"].get("content", "")
            try:
                decoded = base64.b64decode(content).decode('utf-8')
                return {"success": True, "readme": decoded, "name": result["data"].get("name")}
            except Exception:
                return {"success": False, "error": "Could not decode README"}
        
        return result

    def get_repo_contents(self, repo_full_name: str, path: str = "") -> Dict[str, Any]:
        """
        Repo ke contents list karo
        
        Args:
            repo_full_name: Full repo name
            path: Path within repo
            
        Returns:
            Dict with contents
        """
        url = f"{self.base_url}/repos/{repo_full_name}/contents/{path}"
        result = self._make_request(url)
        
        if result["success"]:
            data = result["data"]
            
            if isinstance(data, list):
                files = []
                for item in data:
                    files.append({
                        "name": item.get("name"),
                        "path": item.get("path"),
                        "type": item.get("type"),
                        "size": item.get("size", 0),
                        "url": item.get("download_url")
                    })
                return {"success": True, "files": files, "count": len(files)}
            else:
                return {"success": True, "file": data}
        
        return result

    def get_file_content(self, repo_full_name: str, file_path: str) -> Dict[str, Any]:
        """
        Specific file ka content lo
        
        Args:
            repo_full_name: Full repo name
            file_path: Path to file
            
        Returns:
            Dict with file content
        """
        url = f"{self.base_url}/repos/{repo_full_name}/contents/{file_path}"
        result = self._make_request(url)
        
        if result["success"]:
            content = result["data"].get("content", "")
            try:
                decoded = base64.b64decode(content).decode('utf-8')
                return {
                    "success": True,
                    "content": decoded,
                    "path": file_path,
                    "size": len(decoded)
                }
            except Exception:
                return {"success": False, "error": "Could not decode file"}
        
        return result

    def get_repo_languages(self, repo_full_name: str) -> Dict[str, Any]:
        """Get languages used in repo"""
        url = f"{self.base_url}/repos/{repo_full_name}/languages"
        return self._make_request(url)

    def get_collections(self) -> List[str]:
        """Get all collection names"""
        return list(self.database.get("collections", {}).keys())

    def get_collection_repos(self, collection_name: str) -> List[Dict[str, Any]]:
        """Get repos in a collection"""
        collection = self.database.get("collections", {}).get(collection_name, {})
        repo_names = collection.get("repos", [])
        
        repos = []
        for name in repo_names:
            repo = self.get_repo(name)
            if repo:
                repos.append(repo)
        
        return repos

    def get_stats(self) -> Dict[str, Any]:
        """
        Database stats lo
        """
        repos = list(self.database.get("repos", {}).values())
        
        if not repos:
            return {
                "total_repos": 0,
                "message": "No repos saved yet"
            }
        
        languages = {}
        total_stars = 0
        
        for repo in repos:
            lang = repo.get("language", "Unknown")
            languages[lang] = languages.get(lang, 0) + 1
            total_stars += repo.get("stars", 0)
        
        top_repos = sorted(repos, key=lambda x: x.get("stars", 0), reverse=True)[:5]
        
        return {
            "total_repos": len(repos),
            "total_stars": total_stars,
            "languages": languages,
            "collections": list(self.database.get("collections", {}).keys()),
            "top_repos": [{"name": r["name"], "stars": r["stars"]} for r in top_repos],
            "last_updated": self.database.get("stats", {}).get("last_updated", "Never")
        }

    def list_repos(self, limit: int = 20, sort_by: str = "stars") -> List[Dict[str, Any]]:
        """
        Saved repos list karo
        
        Args:
            limit: Maximum repos
            sort_by: Sort field
            
        Returns:
            List of repos
        """
        repos = list(self.database.get("repos", {}).values())
        
        if sort_by == "stars":
            repos.sort(key=lambda x: x.get("stars", 0), reverse=True)
        elif sort_by == "updated":
            repos.sort(key=lambda x: x.get("updated_at", ""), reverse=True)
        elif sort_by == "name":
            repos.sort(key=lambda x: x.get("name", "").lower())
        
        return repos[:limit]

    def clear_database(self, confirm: bool = False) -> Dict[str, Any]:
        """Clear the database"""
        if not confirm:
            return {"success": False, "error": "Confirmation required"}
        
        self.database = {
            "repos": {},
            "collections": {},
            "stats": {
                "total_repos": 0,
                "created_at": datetime.now().isoformat()
            }
        }
        self.search_index = {
            "by_name": {},
            "by_language": {},
            "by_topic": {},
            "by_keyword": {}
        }
        
        self._save_database()
        self._save_index()
        
        return {"success": True, "message": "Database cleared"}