"""
File Tools - File operations ke liye
Read, write, create, delete, copy, move files and folders
"""

import os
import shutil
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime
import json


class FileTools:
    """
    File operations handle karta hai
    
    Features:
    - Read/Write files
    - Create/Delete files and folders
    - Copy/Move files
    - Search files
    - Get file info
    """

    def __init__(self, base_path: str = ".", allowed_extensions: List[str] = None):
        """
        Initialize FileTools
        
        Args:
            base_path: Base path for operations
            allowed_extensions: List of allowed file extensions (None = all)
        """
        self.base_path = Path(base_path).resolve()
        self.allowed_extensions = allowed_extensions
        self.operation_history = []
        self.max_history = 100

    def _validate_path(self, file_path: str) -> Path:
        """Validate and resolve path"""
        path = Path(file_path)
        
        if not path.is_absolute():
            path = self.base_path / path
        
        path = path.resolve()
        
        return path

    def _check_extension(self, file_path: Path) -> bool:
        """Check if file extension is allowed"""
        if self.allowed_extensions is None:
            return True
        return file_path.suffix.lower() in self.allowed_extensions

    def _record_operation(self, operation: str, path: str, success: bool, details: str = ""):
        """Record operation in history"""
        self.operation_history.append({
            "operation": operation,
            "path": path,
            "success": success,
            "details": details,
            "timestamp": datetime.now().isoformat()
        })
        
        if len(self.operation_history) > self.max_history:
            self.operation_history = self.operation_history[-self.max_history:]

    def read_file(self, file_path: str, encoding: str = 'utf-8') -> Dict[str, Any]:
        """
        File read karo
        
        Args:
            file_path: Path to file
            encoding: File encoding
            
        Returns:
            Dict with file content and metadata
        """
        try:
            path = self._validate_path(file_path)
            
            if not path.exists():
                return {
                    "success": False,
                    "error": f"File not found: {file_path}",
                    "can_create": True
                }
            
            if not path.is_file():
                return {
                    "success": False,
                    "error": f"Not a file: {file_path}"
                }
            
            content = path.read_text(encoding=encoding)
            
            self._record_operation("read", str(path), True)
            
            return {
                "success": True,
                "content": content,
                "path": str(path),
                "name": path.name,
                "size": path.stat().st_size,
                "lines": len(content.splitlines()),
                "encoding": encoding,
                "modified": datetime.fromtimestamp(path.stat().st_mtime).isoformat()
            }
            
        except UnicodeDecodeError:
            return {
                "success": False,
                "error": f"Cannot decode file with {encoding} encoding. Try different encoding."
            }
        except Exception as e:
            self._record_operation("read", file_path, False, str(e))
            return {"success": False, "error": str(e)}

    def read_binary(self, file_path: str) -> Dict[str, Any]:
        """Read binary file"""
        try:
            path = self._validate_path(file_path)
            
            if not path.exists():
                return {"success": False, "error": f"File not found: {file_path}"}
            
            content = path.read_bytes()
            
            return {
                "success": True,
                "content": content,
                "path": str(path),
                "size": len(content)
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}

    def write_file(
        self,
        file_path: str,
        content: str,
        encoding: str = 'utf-8',
        create_dirs: bool = True,
        append: bool = False
    ) -> Dict[str, Any]:
        """
        File write karo
        
        Args:
            file_path: Path to file
            content: Content to write
            encoding: File encoding
            create_dirs: Create parent directories if needed
            append: Append to file instead of overwrite
            
        Returns:
            Dict with result
        """
        try:
            path = self._validate_path(file_path)
            
            if create_dirs:
                path.parent.mkdir(parents=True, exist_ok=True)
            
            mode = 'a' if append else 'w'
            
            with open(path, mode, encoding=encoding) as f:
                f.write(content)
            
            self._record_operation("write", str(path), True, f"append={append}")
            
            return {
                "success": True,
                "path": str(path),
                "size": path.stat().st_size,
                "mode": "appended" if append else "written"
            }
            
        except Exception as e:
            self._record_operation("write", file_path, False, str(e))
            return {"success": False, "error": str(e)}

    def create_file(self, file_path: str, content: str = "") -> Dict[str, Any]:
        """Create new file"""
        path = self._validate_path(file_path)
        
        if path.exists():
            return {"success": False, "error": f"File already exists: {file_path}"}
        
        return self.write_file(file_path, content)

    def delete_file(self, file_path: str) -> Dict[str, Any]:
        """
        File delete karo
        
        Args:
            file_path: Path to file
            
        Returns:
            Dict with result
        """
        try:
            path = self._validate_path(file_path)
            
            if not path.exists():
                return {"success": False, "error": f"File not found: {file_path}"}
            
            if path.is_file():
                path.unlink()
                self._record_operation("delete", str(path), True, "file")
            else:
                return {"success": False, "error": f"Not a file: {file_path}. Use delete_folder for directories."}
            
            return {
                "success": True,
                "deleted": str(path),
                "type": "file"
            }
            
        except Exception as e:
            self._record_operation("delete", file_path, False, str(e))
            return {"success": False, "error": str(e)}

    def create_folder(self, folder_path: str) -> Dict[str, Any]:
        """
        Folder create karo
        
        Args:
            folder_path: Path to folder
            
        Returns:
            Dict with result
        """
        try:
            path = self._validate_path(folder_path)
            
            if path.exists():
                return {"success": False, "error": f"Path already exists: {folder_path}"}
            
            path.mkdir(parents=True, exist_ok=True)
            
            self._record_operation("create_folder", str(path), True)
            
            return {
                "success": True,
                "path": str(path),
                "created": True
            }
            
        except Exception as e:
            self._record_operation("create_folder", folder_path, False, str(e))
            return {"success": False, "error": str(e)}

    def delete_folder(self, folder_path: str, recursive: bool = False) -> Dict[str, Any]:
        """
        Folder delete karo
        
        Args:
            folder_path: Path to folder
            recursive: Delete contents recursively
            
        Returns:
            Dict with result
        """
        try:
            path = self._validate_path(folder_path)
            
            if not path.exists():
                return {"success": False, "error": f"Folder not found: {folder_path}"}
            
            if not path.is_dir():
                return {"success": False, "error": f"Not a folder: {folder_path}"}
            
            if recursive:
                shutil.rmtree(path)
            else:
                try:
                    path.rmdir()
                except OSError:
                    return {
                        "success": False,
                        "error": "Folder is not empty. Use recursive=True to delete contents."
                    }
            
            self._record_operation("delete_folder", str(path), True, f"recursive={recursive}")
            
            return {
                "success": True,
                "deleted": str(path),
                "type": "folder",
                "recursive": recursive
            }
            
        except Exception as e:
            self._record_operation("delete_folder", folder_path, False, str(e))
            return {"success": False, "error": str(e)}

    def copy_file(self, source: str, destination: str) -> Dict[str, Any]:
        """
        File copy karo
        
        Args:
            source: Source file path
            destination: Destination path
            
        Returns:
            Dict with result
        """
        try:
            src = self._validate_path(source)
            dst = self._validate_path(destination)
            
            if not src.exists():
                return {"success": False, "error": f"Source not found: {source}"}
            
            dst.parent.mkdir(parents=True, exist_ok=True)
            
            if src.is_file():
                shutil.copy2(src, dst)
            else:
                shutil.copytree(src, dst)
            
            self._record_operation("copy", f"{src} -> {dst}", True)
            
            return {
                "success": True,
                "source": str(src),
                "destination": str(dst)
            }
            
        except Exception as e:
            self._record_operation("copy", f"{source} -> {destination}", False, str(e))
            return {"success": False, "error": str(e)}

    def move_file(self, source: str, destination: str) -> Dict[str, Any]:
        """
        File move karo
        
        Args:
            source: Source path
            destination: Destination path
            
        Returns:
            Dict with result
        """
        try:
            src = self._validate_path(source)
            dst = self._validate_path(destination)
            
            if not src.exists():
                return {"success": False, "error": f"Source not found: {source}"}
            
            dst.parent.mkdir(parents=True, exist_ok=True)
            
            shutil.move(str(src), str(dst))
            
            self._record_operation("move", f"{src} -> {dst}", True)
            
            return {
                "success": True,
                "source": str(src),
                "destination": str(dst)
            }
            
        except Exception as e:
            self._record_operation("move", f"{source} -> {destination}", False, str(e))
            return {"success": False, "error": str(e)}

    def rename(self, old_path: str, new_name: str) -> Dict[str, Any]:
        """
        File/folder rename karo
        
        Args:
            old_path: Current path
            new_name: New name (not full path)
            
        Returns:
            Dict with result
        """
        try:
            old = self._validate_path(old_path)
            
            if not old.exists():
                return {"success": False, "error": f"Path not found: {old_path}"}
            
            new = old.parent / new_name
            
            if new.exists():
                return {"success": False, "error": f"Target already exists: {new_name}"}
            
            old.rename(new)
            
            self._record_operation("rename", f"{old} -> {new}", True)
            
            return {
                "success": True,
                "old_path": str(old),
                "new_path": str(new)
            }
            
        except Exception as e:
            self._record_operation("rename", old_path, False, str(e))
            return {"success": False, "error": str(e)}

    def list_files(
        self,
        directory: str = ".",
        pattern: str = "*",
        recursive: bool = False
    ) -> Dict[str, Any]:
        """
        Directory mein files list karo
        
        Args:
            directory: Directory path
            pattern: Glob pattern
            recursive: Search recursively
            
        Returns:
            Dict with file list
        """
        try:
            dir_path = self._validate_path(directory)
            
            if not dir_path.exists():
                return {"success": False, "error": f"Directory not found: {directory}"}
            
            if not dir_path.is_dir():
                return {"success": False, "error": f"Not a directory: {directory}"}
            
            if recursive:
                files = list(dir_path.rglob(pattern))
            else:
                files = list(dir_path.glob(pattern))
            
            file_list = []
            for f in files:
                try:
                    stat = f.stat()
                    file_list.append({
                        "name": f.name,
                        "path": str(f),
                        "relative_path": str(f.relative_to(dir_path)),
                        "is_dir": f.is_dir(),
                        "is_file": f.is_file(),
                        "size": stat.st_size if f.is_file() else 0,
                        "modified": datetime.fromtimestamp(stat.st_mtime).isoformat()
                    })
                except Exception:
                    file_list.append({
                        "name": f.name,
                        "path": str(f),
                        "error": "Could not get file info"
                    })
            
            file_list.sort(key=lambda x: (not x.get("is_dir", False), x.get("name", "").lower()))
            
            return {
                "success": True,
                "directory": str(dir_path),
                "pattern": pattern,
                "count": len(file_list),
                "files": file_list
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_file_info(self, file_path: str) -> Dict[str, Any]:
        """
        File info lo
        
        Args:
            file_path: Path to file
            
        Returns:
            Dict with file info
        """
        try:
            path = self._validate_path(file_path)
            
            if not path.exists():
                return {"success": False, "error": f"Path not found: {file_path}"}
            
            stat = path.stat()
            
            info = {
                "success": True,
                "path": str(path),
                "name": path.name,
                "stem": path.stem,
                "extension": path.suffix,
                "is_file": path.is_file(),
                "is_dir": path.is_dir(),
                "size": stat.st_size,
                "size_human": self._human_readable_size(stat.st_size),
                "created": datetime.fromtimestamp(stat.st_ctime).isoformat(),
                "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                "accessed": datetime.fromtimestamp(stat.st_atime).isoformat()
            }
            
            if path.is_dir():
                try:
                    contents = list(path.iterdir())
                    info["contents_count"] = len(contents)
                    info["files_count"] = sum(1 for c in contents if c.is_file())
                    info["folders_count"] = sum(1 for c in contents if c.is_dir())
                except Exception:
                    pass
            
            return info
            
        except Exception as e:
            return {"success": False, "error": str(e)}

    def _human_readable_size(self, size: int) -> str:
        """Convert bytes to human readable format"""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size < 1024:
                return f"{size:.1f} {unit}"
            size /= 1024
        return f"{size:.1f} PB"

    def search_files(
        self,
        directory: str = ".",
        name_pattern: str = None,
        content_pattern: str = None,
        extension: str = None,
        recursive: bool = True
    ) -> Dict[str, Any]:
        """
        Files search karo
        
        Args:
            directory: Directory to search in
            name_pattern: Pattern to match in filename
            content_pattern: Pattern to match in file content
            extension: File extension filter
            recursive: Search recursively
            
        Returns:
            Dict with search results
        """
        try:
            dir_path = self._validate_path(directory)
            
            if not dir_path.exists():
                return {"success": False, "error": f"Directory not found: {directory}"}
            
            if extension:
                if not extension.startswith('.'):
                    extension = '.' + extension
                pattern = f"*{extension}"
            else:
                pattern = "*"
            
            if recursive:
                files = list(dir_path.rglob(pattern))
            else:
                files = list(dir_path.glob(pattern))
            
            results = []
            
            for f in files:
                if not f.is_file():
                    continue
                
                if name_pattern:
                    if name_pattern.lower() not in f.name.lower():
                        continue
                
                if content_pattern:
                    try:
                        content = f.read_text(encoding='utf-8', errors='ignore')
                        if content_pattern.lower() not in content.lower():
                            continue
                    except Exception:
                        continue
                
                results.append({
                    "name": f.name,
                    "path": str(f),
                    "relative_path": str(f.relative_to(dir_path)),
                    "size": f.stat().st_size
                })
            
            return {
                "success": True,
                "directory": str(dir_path),
                "count": len(results),
                "results": results
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}

    def file_exists(self, file_path: str) -> bool:
        """Check if file exists"""
        path = self._validate_path(file_path)
        return path.exists() and path.is_file()

    def folder_exists(self, folder_path: str) -> bool:
        """Check if folder exists"""
        path = self._validate_path(folder_path)
        return path.exists() and path.is_dir()

    def get_operation_history(self, limit: int = 20) -> List[Dict]:
        """Get operation history"""
        return self.operation_history[-limit:]

    def get_stats(self) -> Dict[str, Any]:
        """Get file tools statistics"""
        ops = self.operation_history
        successful = sum(1 for o in ops if o.get("success"))
        
        by_operation = {}
        for o in ops:
            op = o.get("operation", "unknown")
            by_operation[op] = by_operation.get(op, 0) + 1
        
        return {
            "total_operations": len(ops),
            "successful": successful,
            "failed": len(ops) - successful,
            "by_operation": by_operation,
            "base_path": str(self.base_path)
        }