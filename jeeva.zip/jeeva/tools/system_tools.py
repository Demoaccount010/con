"""
System Tools - System operations ke liye
CPU, Memory, Disk, Process information aur control
"""

import os
import sys
import platform
import subprocess
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime


class SystemTools:
    """
    System level operations
    
    Features:
    - System information
    - Process management
    - Application control
    - Command execution (with safety)
    """

    def __init__(self):
        """Initialize SystemTools"""
        self.command_history = []
        self.max_history = 50
        
        self.dangerous_commands = [
            "rm -rf /",
            "rm -rf /*",
            "mkfs",
            "dd if=",
            ":(){:|:&};:",
            "format c:",
            "del /f /s /q",
            "> /dev/sda",
            "chmod -R 777 /",
            "shutdown",
            "reboot",
            "init 0",
            "init 6"
        ]

    def get_system_info(self) -> Dict[str, Any]:
        """
        System info lo
        
        Returns:
            Dict with system information
        """
        try:
            info = {
                "success": True,
                "system": {
                    "os": platform.system(),
                    "os_release": platform.release(),
                    "os_version": platform.version(),
                    "hostname": platform.node(),
                    "machine": platform.machine(),
                    "processor": platform.processor(),
                    "python_version": platform.python_version(),
                    "python_implementation": platform.python_implementation()
                },
                "timestamp": datetime.now().isoformat()
            }
            
            try:
                import psutil
                
                cpu_percent = psutil.cpu_percent(interval=0.1)
                cpu_count = psutil.cpu_count()
                cpu_count_logical = psutil.cpu_count(logical=True)
                
                memory = psutil.virtual_memory()
                
                disk = psutil.disk_usage('/')
                
                boot_time = datetime.fromtimestamp(psutil.boot_time())
                uptime = datetime.now() - boot_time
                
                info["resources"] = {
                    "cpu": {
                        "percent": cpu_percent,
                        "cores_physical": cpu_count,
                        "cores_logical": cpu_count_logical
                    },
                    "memory": {
                        "total": memory.total,
                        "total_gb": round(memory.total / (1024**3), 2),
                        "available": memory.available,
                        "available_gb": round(memory.available / (1024**3), 2),
                        "used": memory.used,
                        "used_gb": round(memory.used / (1024**3), 2),
                        "percent": memory.percent
                    },
                    "disk": {
                        "total": disk.total,
                        "total_gb": round(disk.total / (1024**3), 2),
                        "used": disk.used,
                        "used_gb": round(disk.used / (1024**3), 2),
                        "free": disk.free,
                        "free_gb": round(disk.free / (1024**3), 2),
                        "percent": disk.percent
                    },
                    "uptime": {
                        "boot_time": boot_time.isoformat(),
                        "uptime_seconds": int(uptime.total_seconds()),
                        "uptime_human": str(uptime).split('.')[0]
                    }
                }
                
            except ImportError:
                info["resources"] = {
                    "note": "Install psutil for detailed resource info: pip install psutil"
                }
            
            return info
            
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_cpu_info(self) -> Dict[str, Any]:
        """Get CPU information"""
        try:
            import psutil
            
            cpu_percent = psutil.cpu_percent(interval=0.5, percpu=True)
            cpu_freq = psutil.cpu_freq()
            
            return {
                "success": True,
                "cores_physical": psutil.cpu_count(logical=False),
                "cores_logical": psutil.cpu_count(logical=True),
                "usage_percent": psutil.cpu_percent(interval=0.1),
                "usage_per_core": cpu_percent,
                "frequency": {
                    "current": cpu_freq.current if cpu_freq else None,
                    "min": cpu_freq.min if cpu_freq else None,
                    "max": cpu_freq.max if cpu_freq else None
                } if cpu_freq else None
            }
            
        except ImportError:
            return {"success": False, "error": "psutil not installed"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_memory_info(self) -> Dict[str, Any]:
        """Get memory information"""
        try:
            import psutil
            
            mem = psutil.virtual_memory()
            swap = psutil.swap_memory()
            
            return {
                "success": True,
                "ram": {
                    "total_gb": round(mem.total / (1024**3), 2),
                    "available_gb": round(mem.available / (1024**3), 2),
                    "used_gb": round(mem.used / (1024**3), 2),
                    "percent": mem.percent
                },
                "swap": {
                    "total_gb": round(swap.total / (1024**3), 2),
                    "used_gb": round(swap.used / (1024**3), 2),
                    "free_gb": round(swap.free / (1024**3), 2),
                    "percent": swap.percent
                }
            }
            
        except ImportError:
            return {"success": False, "error": "psutil not installed"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_disk_info(self) -> Dict[str, Any]:
        """Get disk information"""
        try:
            import psutil
            
            partitions = []
            for partition in psutil.disk_partitions():
                try:
                    usage = psutil.disk_usage(partition.mountpoint)
                    partitions.append({
                        "device": partition.device,
                        "mountpoint": partition.mountpoint,
                        "filesystem": partition.fstype,
                        "total_gb": round(usage.total / (1024**3), 2),
                        "used_gb": round(usage.used / (1024**3), 2),
                        "free_gb": round(usage.free / (1024**3), 2),
                        "percent": usage.percent
                    })
                except Exception:
                    pass
            
            return {
                "success": True,
                "partitions": partitions
            }
            
        except ImportError:
            return {"success": False, "error": "psutil not installed"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def list_processes(self, limit: int = 20, sort_by: str = "memory") -> Dict[str, Any]:
        """
        Running processes list karo
        
        Args:
            limit: Maximum processes to return
            sort_by: Sort by 'memory', 'cpu', or 'name'
            
        Returns:
            Dict with process list
        """
        try:
            import psutil
            
            processes = []
            for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent', 'status']):
                try:
                    pinfo = proc.info
                    processes.append({
                        "pid": pinfo['pid'],
                        "name": pinfo['name'],
                        "cpu_percent": pinfo['cpu_percent'] or 0,
                        "memory_percent": round(pinfo['memory_percent'] or 0, 2),
                        "status": pinfo['status']
                    })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
            
            if sort_by == "memory":
                processes.sort(key=lambda x: x['memory_percent'], reverse=True)
            elif sort_by == "cpu":
                processes.sort(key=lambda x: x['cpu_percent'], reverse=True)
            elif sort_by == "name":
                processes.sort(key=lambda x: x['name'].lower())
            
            return {
                "success": True,
                "total": len(processes),
                "showing": min(limit, len(processes)),
                "sort_by": sort_by,
                "processes": processes[:limit]
            }
            
        except ImportError:
            return {"success": False, "error": "psutil not installed"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_process_info(self, pid: int) -> Dict[str, Any]:
        """
        Specific process ki info lo
        
        Args:
            pid: Process ID
            
        Returns:
            Dict with process info
        """
        try:
            import psutil
            
            proc = psutil.Process(pid)
            
            with proc.oneshot():
                info = {
                    "success": True,
                    "pid": pid,
                    "name": proc.name(),
                    "status": proc.status(),
                    "cpu_percent": proc.cpu_percent(),
                    "memory_percent": round(proc.memory_percent(), 2),
                    "created": datetime.fromtimestamp(proc.create_time()).isoformat(),
                    "cwd": proc.cwd() if hasattr(proc, 'cwd') else None,
                    "num_threads": proc.num_threads()
                }
                
                try:
                    info["username"] = proc.username()
                except Exception:
                    pass
                
                try:
                    info["cmdline"] = proc.cmdline()
                except Exception:
                    pass
            
            return info
            
        except ImportError:
            return {"success": False, "error": "psutil not installed"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def kill_process(self, pid: int, force: bool = False) -> Dict[str, Any]:
        """
        Process kill karo
        
        Args:
            pid: Process ID
            force: Force kill (SIGKILL)
            
        Returns:
            Dict with result
        """
        try:
            import psutil
            
            proc = psutil.Process(pid)
            proc_name = proc.name()
            
            if force:
                proc.kill()
            else:
                proc.terminate()
            
            return {
                "success": True,
                "message": f"Process {pid} ({proc_name}) {'killed' if force else 'terminated'}"
            }
            
        except ImportError:
            return {"success": False, "error": "psutil not installed"}
        except psutil.NoSuchProcess:
            return {"success": False, "error": f"Process {pid} not found"}
        except psutil.AccessDenied:
            return {"success": False, "error": f"Access denied to process {pid}"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def run_command(
        self,
        command: str,
        timeout: int = 30,
        shell: bool = True,
        capture_output: bool = True
    ) -> Dict[str, Any]:
        """
        Shell command run karo (carefully!)
        
        Args:
            command: Command to run
            timeout: Maximum execution time
            shell: Use shell
            capture_output: Capture stdout/stderr
            
        Returns:
            Dict with command result
        """
        if self._is_dangerous_command(command):
            return {
                "success": False,
                "error": "Dangerous command blocked for safety",
                "blocked": True
            }
        
        try:
            result = subprocess.run(
                command,
                shell=shell,
                capture_output=capture_output,
                text=True,
                timeout=timeout,
                cwd=os.getcwd()
            )
            
            self._record_command(command, result.returncode == 0)
            
            return {
                "success": result.returncode == 0,
                "return_code": result.returncode,
                "stdout": result.stdout[:5000] if result.stdout else "",
                "stderr": result.stderr[:2000] if result.stderr else "",
                "command": command
            }
            
        except subprocess.TimeoutExpired:
            self._record_command(command, False, "timeout")
            return {
                "success": False,
                "error": f"Command timed out after {timeout} seconds"
            }
        except Exception as e:
            self._record_command(command, False, str(e))
            return {"success": False, "error": str(e)}

    def _is_dangerous_command(self, command: str) -> bool:
        """Check if command is dangerous"""
        command_lower = command.lower()
        
        for dangerous in self.dangerous_commands:
            if dangerous.lower() in command_lower:
                return True
        
        return False

    def _record_command(self, command: str, success: bool, error: str = None):
        """Record command in history"""
        self.command_history.append({
            "command": command[:200],
            "success": success,
            "error": error,
            "timestamp": datetime.now().isoformat()
        })
        
        if len(self.command_history) > self.max_history:
            self.command_history = self.command_history[-self.max_history:]

    def open_application(self, app_name: str) -> Dict[str, Any]:
        """
        Application open karo
        
        Args:
            app_name: Application name or path
            
        Returns:
            Dict with result
        """
        try:
            system = platform.system()
            
            if system == "Windows":
                os.startfile(app_name)
            elif system == "Darwin":
                subprocess.Popen(['open', '-a', app_name])
            else:
                subprocess.Popen([app_name], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            return {
                "success": True,
                "message": f"Opened {app_name}"
            }
            
        except FileNotFoundError:
            return {"success": False, "error": f"Application not found: {app_name}"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def open_url(self, url: str) -> Dict[str, Any]:
        """
        URL open karo browser mein
        
        Args:
            url: URL to open
            
        Returns:
            Dict with result
        """
        try:
            import webbrowser
            
            webbrowser.open(url)
            
            return {
                "success": True,
                "message": f"Opened {url} in browser"
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}

    def open_file_explorer(self, path: str = ".") -> Dict[str, Any]:
        """
        File explorer open karo
        
        Args:
            path: Path to open
            
        Returns:
            Dict with result
        """
        try:
            path = os.path.abspath(path)
            system = platform.system()
            
            if system == "Windows":
                os.startfile(path)
            elif system == "Darwin":
                subprocess.Popen(['open', path])
            else:
                subprocess.Popen(['xdg-open', path])
            
            return {
                "success": True,
                "message": f"Opened file explorer at {path}"
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_environment_variable(self, name: str) -> Dict[str, Any]:
        """Get environment variable"""
        value = os.environ.get(name)
        
        if value is not None:
            return {
                "success": True,
                "name": name,
                "value": value
            }
        else:
            return {
                "success": False,
                "error": f"Environment variable '{name}' not found"
            }

    def list_environment_variables(self) -> Dict[str, Any]:
        """List all environment variables"""
        return {
            "success": True,
            "count": len(os.environ),
            "variables": dict(os.environ)
        }

    def get_python_info(self) -> Dict[str, Any]:
        """Get Python environment info"""
        return {
            "success": True,
            "version": sys.version,
            "version_info": {
                "major": sys.version_info.major,
                "minor": sys.version_info.minor,
                "micro": sys.version_info.micro
            },
            "executable": sys.executable,
            "platform": sys.platform,
            "prefix": sys.prefix,
            "path": sys.path[:10]
        }

    def install_package(self, package_name: str, upgrade: bool = False) -> Dict[str, Any]:
        """
        Python package install karo
        
        Args:
            package_name: Package to install
            upgrade: Upgrade if exists
            
        Returns:
            Dict with result
        """
        try:
            cmd = [sys.executable, "-m", "pip", "install"]
            
            if upgrade:
                cmd.append("--upgrade")
            
            cmd.append(package_name)
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=120
            )
            
            return {
                "success": result.returncode == 0,
                "package": package_name,
                "output": result.stdout[-1000:] if result.stdout else "",
                "error": result.stderr[-500:] if result.stderr and result.returncode != 0 else ""
            }
            
        except subprocess.TimeoutExpired:
            return {"success": False, "error": "Installation timed out"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def list_installed_packages(self) -> Dict[str, Any]:
        """List installed Python packages"""
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "list", "--format=json"],
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.returncode == 0:
                import json
                packages = json.loads(result.stdout)
                return {
                    "success": True,
                    "count": len(packages),
                    "packages": packages
                }
            else:
                return {"success": False, "error": result.stderr}
                
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_network_info(self) -> Dict[str, Any]:
        """Get network information"""
        try:
            import psutil
            
            interfaces = {}
            
            for name, addrs in psutil.net_if_addrs().items():
                interfaces[name] = []
                for addr in addrs:
                    interfaces[name].append({
                        "family": str(addr.family),
                        "address": addr.address,
                        "netmask": addr.netmask
                    })
            
            io_counters = psutil.net_io_counters()
            
            return {
                "success": True,
                "interfaces": interfaces,
                "io": {
                    "bytes_sent": io_counters.bytes_sent,
                    "bytes_recv": io_counters.bytes_recv,
                    "packets_sent": io_counters.packets_sent,
                    "packets_recv": io_counters.packets_recv
                }
            }
            
        except ImportError:
            return {"success": False, "error": "psutil not installed"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_command_history(self, limit: int = 20) -> List[Dict]:
        """Get command history"""
        return self.command_history[-limit:]

    def get_stats(self) -> Dict[str, Any]:
        """Get system tools statistics"""
        successful = sum(1 for c in self.command_history if c.get("success"))
        
        return {
            "total_commands": len(self.command_history),
            "successful": successful,
            "failed": len(self.command_history) - successful,
            "system": platform.system(),
            "python_version": platform.python_version()
        }