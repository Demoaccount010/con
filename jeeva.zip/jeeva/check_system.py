#!/usr/bin/env python3
"""
JEEVA System Check
Verifies all dependencies and configurations
"""

import sys
from pathlib import Path

def check_python_version():
    """Check Python version"""
    print("🐍 Checking Python version...")
    version = sys.version_info
    if version.major >= 3 and version.minor >= 8:
        print(f"   ✅ Python {version.major}.{version.minor}.{version.micro}")
        return True
    else:
        print(f"   ❌ Python {version.major}.{version.minor} (Need 3.8+)")
        return False

def check_dependencies():
    """Check required Python packages"""
    print("\n📦 Checking dependencies...")
    
    dependencies = {
        "ollama": "Ollama API client",
        "yaml": "YAML configuration (PyYAML)",
        "rich": "Rich terminal output",
        "prompt_toolkit": "Interactive prompts",
        "psutil": "System utilities",
        "requests": "HTTP requests",
        "colorama": "Terminal colors",
        "black": "Code formatter"
    }
    
    all_ok = True
    for module, desc in dependencies.items():
        try:
            __import__(module)
            print(f"   ✅ {module:20s} - {desc}")
        except ImportError:
            print(f"   ❌ {module:20s} - {desc} (MISSING)")
            all_ok = False
    
    return all_ok

def check_ollama_connection():
    """Check Ollama server connection"""
    print("\n🤖 Checking Ollama connection...")
    try:
        import ollama
        models = ollama.list()
        print(f"   ✅ Ollama connected")
        
        available = [m.get('name', '') for m in models.get('models', [])]
        print(f"   📋 Available models: {len(available)}")
        for model in available[:5]:
            print(f"      • {model}")
        
        if 'llama3.2' in str(available):
            print("   ✅ llama3.2 found")
        else:
            print("   ⚠️  llama3.2 not found. Run: ollama pull llama3.2")
        
        return True
    except Exception as e:
        print(f"   ❌ Ollama not connected: {e}")
        print("   💡 Start Ollama: ollama serve")
        return False

def check_data_directories():
    """Check if data directories exist"""
    print("\n📁 Checking data directories...")
    
    required_dirs = [
        "data/supervisor",
        "data/logs",
        "data/memory",
        "data/learning",
        "data/backups",
        "data/permissions"
    ]
    
    all_ok = True
    for dir_path in required_dirs:
        path = Path(dir_path)
        if path.exists():
            print(f"   ✅ {dir_path}")
        else:
            print(f"   ⚠️  {dir_path} (Creating...)")
            path.mkdir(parents=True, exist_ok=True)
            print(f"      ✅ Created")
    
    return all_ok

def check_config_files():
    """Check configuration files"""
    print("\n⚙️  Checking configuration files...")
    
    configs = [
        "config/settings.yaml",
        "config/capabilities.yaml"
    ]
    
    all_ok = True
    for config in configs:
        path = Path(config)
        if path.exists():
            print(f"   ✅ {config}")
        else:
            print(f"   ❌ {config} (MISSING)")
            all_ok = False
    
    return all_ok

def check_core_files():
    """Check core Python files"""
    print("\n🧠 Checking core files...")
    
    core_files = [
        "main.py",
        "jeeva_supervisor.py",
        "core/brain.py",
        "core/thinking_engine.py",
        "core/consciousness.py",
        "core/honesty_engine.py",
        "core/intent_detector.py"
    ]
    
    all_ok = True
    for file in core_files:
        path = Path(file)
        if path.exists():
            print(f"   ✅ {file}")
            # Try to compile
            try:
                import py_compile
                py_compile.compile(str(path), doraise=True)
            except Exception as e:
                print(f"      ❌ Syntax error: {e}")
                all_ok = False
        else:
            print(f"   ❌ {file} (MISSING)")
            all_ok = False
    
    return all_ok

def main():
    """Run all checks"""
    print("="*50)
    print("🔍 JEEVA SYSTEM CHECK")
    print("="*50)
    
    checks = [
        ("Python Version", check_python_version),
        ("Dependencies", check_dependencies),
        ("Ollama Connection", check_ollama_connection),
        ("Data Directories", check_data_directories),
        ("Config Files", check_config_files),
        ("Core Files", check_core_files)
    ]
    
    results = {}
    for name, check_func in checks:
        try:
            results[name] = check_func()
        except Exception as e:
            print(f"\n❌ Error in {name}: {e}")
            results[name] = False
    
    print("\n" + "="*50)
    print("📊 SUMMARY")
    print("="*50)
    
    all_passed = True
    for name, passed in results.items():
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{status:10s} - {name}")
        if not passed:
            all_passed = False
    
    print("="*50)
    
    if all_passed:
        print("\n🎉 All checks passed! JEEVA is ready to run!")
        print("\n🚀 Start JEEVA:")
        print("   python main.py")
        print("   OR")
        print("   python jeeva_supervisor.py")
    else:
        print("\n⚠️  Some checks failed. Please fix the issues above.")
        print("\n💡 Quick fixes:")
        print("   • Install dependencies: pip install -r requirements.txt")
        print("   • Start Ollama: ollama serve")
        print("   • Pull model: ollama pull llama3.2")
    
    print()

if __name__ == "__main__":
    main()
