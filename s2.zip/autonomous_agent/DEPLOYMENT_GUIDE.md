# 🚀 Complete Deployment Guide (Hindi + English)

## Remote Ollama Setup - Step by Step

Is guide mein hum 2 VPS setup karenge:
- **VPS 1:** Agent (छोटा server)
- **VPS 2:** Ollama LLM (बड़ा server with GPU)

---

## 📦 Quick Deployment

### VPS 2 (Ollama Server) Setup:

```bash
# 1. Download setup script
wget https://your-repo/deploy/scripts/setup_remote_ollama.sh

# 2. Make executable
chmod +x setup_remote_ollama.sh

# 3. Run as root
sudo bash setup_remote_ollama.sh

# Script automatically करेगा:
# - Ollama install
# - Network पर expose
# - Firewall configure
# - Model download
# - Test
```

### VPS 1 (Agent) Setup:

```bash
# 1. Clone repository
git clone https://your-repo/autonomous_agent.git
cd autonomous_agent

# 2. Setup script run करें
bash deploy/scripts/setup_agent_vps.sh

# 3. Test connection
python test_remote_ollama.py

# 4. Start agent
python main.py
```

---

## 🔧 Manual Setup (Detailed)

### Part 1: VPS 2 (Ollama Server)

#### Step 1: Install Ollama
```bash
curl -fsSL https://ollama.ai/install.sh | sh
```

#### Step 2: Configure for Network Access
```bash
# Edit service
sudo systemctl edit ollama.service

# Add these lines:
[Service]
Environment="OLLAMA_HOST=0.0.0.0:11434"

# Save and exit (Ctrl+X, Y, Enter)
```

#### Step 3: Restart Ollama
```bash
sudo systemctl daemon-reload
sudo systemctl restart ollama
sudo systemctl enable ollama
```

#### Step 4: Download Model
```bash
ollama pull llama3        # Main model (4.7GB)
ollama pull mistral       # Alternative (4.1GB)
```

#### Step 5: Configure Firewall
```bash
# Get VPS 1 IP
VPS1_IP="1.2.3.4"  # Replace with actual IP

# Allow only VPS 1
sudo ufw allow from $VPS1_IP to any port 11434
sudo ufw deny 11434
sudo ufw enable
```

#### Step 6: Test
```bash
# Should show models
curl http://localhost:11434/api/tags

# Test from VPS 1
# From VPS 1: curl http://VPS2_IP:11434/api/tags
```

---

### Part 2: VPS 1 (Agent Server)

#### Step 1: Install Dependencies
```bash
sudo apt update
sudo apt install -y python3 python3-pip git

# Install Python packages
pip3 install -r requirements.txt
```

#### Step 2: Configure Agent
```bash
# Copy example config
cp .env.example .env

# Edit .env
nano .env
```

**Add to .env:**
```bash
OLLAMA_URL=http://VPS2_IP:11434
OLLAMA_MODEL=llama3
ENABLE_OLLAMA=true
```

#### Step 3: Test Connection
```bash
python test_remote_ollama.py

# Should show:
# ✅ Server is reachable!
# ✅ Model 'llama3' is available
# ✅ Response: Four
```

#### Step 4: Run Agent
```bash
# Test mode
python main.py

# Or as service (recommended)
sudo cp deploy/systemd/autonomous-agent.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable autonomous-agent
sudo systemctl start autonomous-agent
```

---

## 🔒 Production Security Setup

### Option 1: SSH Tunnel (सबसे आसान)

VPS 1 से VPS 2 को secure connect करें:

```bash
# VPS 1 पर tunnel बनाएं
ssh -L 11434:localhost:11434 user@VPS2_IP -N -f

# अब .env में use करें:
OLLAMA_URL=http://localhost:11434
```

**Auto-start at boot:**
```bash
# Add to /etc/rc.local
ssh -L 11434:localhost:11434 user@VPS2_IP -N -f
```

---

### Option 2: Nginx Reverse Proxy with SSL

#### VPS 2 पर:

```bash
# Install Nginx
sudo apt install nginx

# Copy config
sudo cp deploy/nginx/ollama-proxy.conf /etc/nginx/sites-available/

# Setup SSL (Let's Encrypt)
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d ollama.yourdomain.com

# Enable site
sudo ln -s /etc/nginx/sites-available/ollama-proxy.conf /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx

# Create password for auth
sudo htpasswd -c /etc/nginx/.htpasswd admin
```

**VPS 1 .env:**
```bash
OLLAMA_URL=https://ollama.yourdomain.com
OLLAMA_AUTH_USER=admin
OLLAMA_AUTH_PASS=your_password
```

---

### Option 3: VPN (सबसे secure)

```bash
# Install Tailscale (easiest VPN)

# Both VPS पर:
curl -fsSL https://tailscale.com/install.sh | sh
sudo tailscale up

# VPS 2 का Tailscale IP मिलेगा (e.g., 100.64.1.1)

# VPS 1 .env में:
OLLAMA_URL=http://100.64.1.1:11434
```

---

## 📊 Monitoring Setup

### VPS 2 (Ollama) Monitor:

```bash
# Install htop
sudo apt install htop

# Watch Ollama logs
sudo journalctl -u ollama -f

# Check resource usage
htop
```

### VPS 1 (Agent) Monitor:

```bash
# Agent logs
tail -f logs/agent.log

# Or with systemd:
sudo journalctl -u autonomous-agent -f
```

---

## 🧪 Testing Checklist

- [ ] VPS 2: Ollama running
- [ ] VPS 2: Firewall configured
- [ ] VPS 2: Model downloaded
- [ ] VPS 1: Dependencies installed
- [ ] VPS 1: .env configured
- [ ] VPS 1: Connection test passed
- [ ] VPS 1: Agent starts successfully
- [ ] End-to-end: Agent can think with Ollama

---

## 🐛 Troubleshooting

### Problem: Connection Refused
```bash
# VPS 2 पर check करें
sudo netstat -tlnp | grep 11434
# Should show: 0.0.0.0:11434 (not 127.0.0.1)

# If 127.0.0.1, fix:
sudo systemctl edit ollama.service
# Add: Environment="OLLAMA_HOST=0.0.0.0:11434"
sudo systemctl daemon-reload
sudo systemctl restart ollama
```

### Problem: Firewall Blocking
```bash
# VPS 2 पर
sudo ufw status
sudo ufw allow from VPS1_IP to any port 11434

# Test from VPS 1
telnet VPS2_IP 11434
```

### Problem: Slow Response
```bash
# Use smaller model
ollama pull mistral  # 4.1GB
# या
ollama pull phi      # 2.7GB

# Update .env:
OLLAMA_MODEL=mistral
```

---

## 💰 Cost Examples

### Budget Setup ($10-15/month):
- **VPS 1:** Contabo VPS S (2GB RAM) - $6/month
- **VPS 2:** Hetzner CX21 (4GB RAM) - $5/month
- **Total:** $11/month

### Recommended Setup ($20-30/month):
- **VPS 1:** DigitalOcean Droplet (2GB) - $12/month
- **VPS 2:** Hetzner CX31 (8GB RAM) - $16/month
- **Total:** $28/month

### Production Setup ($50-100/month):
- **VPS 1:** DigitalOcean (4GB) - $24/month
- **VPS 2:** GPU Instance (RTX 3060) - $80/month
- **Total:** $104/month (बहुत fast!)

---

## 🎯 Quick Commands Reference

### VPS 2 (Ollama):
```bash
# Start/Stop
sudo systemctl start ollama
sudo systemctl stop ollama
sudo systemctl restart ollama

# Logs
sudo journalctl -u ollama -f

# List models
ollama list

# Remove model
ollama rm model_name

# Pull new model
ollama pull llama3
```

### VPS 1 (Agent):
```bash
# Start agent
python main.py

# Test connection
python test_remote_ollama.py

# Check logs
tail -f logs/agent.log

# Stop agent (if running as service)
sudo systemctl stop autonomous-agent
```

---

## ✅ Deployment Complete!

Ab tum ye kar sakte ho:
- Agent VPS 1 par safely chal raha hai
- Ollama VPS 2 par GPU ke sath fast chal raha hai
- Multiple agents same Ollama server use kar sakte hain
- Scale kar sakte ho as needed

**🚀 Happy Automating!**
