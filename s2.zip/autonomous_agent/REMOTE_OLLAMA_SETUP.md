# 🌐 Remote Ollama Setup Guide (Hindi + English)

## क्या है यह Setup?

इस setup में:
- **Agent VPS 1** पर चलेगा (छोटा server, बिना GPU)
- **Ollama LLM Model VPS 2** पर चलेगा (बड़ा server, GPU के साथ)
- दोनों **HTTP API** से connect करेंगे

---

## 🎯 Advantages (फायदे)

✅ **Cost Saving** - Agent को powerful GPU नहीं चाहिए
✅ **Scalability** - Multiple agents एक ही Ollama server use कर सकते हैं
✅ **Flexibility** - Ollama server को अलग से upgrade/scale कर सकते हैं
✅ **Performance** - Ollama dedicated resources के साथ fast चलेगा

---

## 📋 Architecture (कैसे काम करता है)

```
┌─────────────────────┐         HTTP API          ┌──────────────────────┐
│   VPS 1 (Agent)     │ ◄──────────────────────► │  VPS 2 (Ollama LLM)  │
│                     │                           │                      │
│  • Agent Code       │    Request: "Think..."    │  • Ollama Server     │
│  • Skills           │ ────────────────────────► │  • LLM Models        │
│  • Memory           │                           │  • GPU               │
│  • System Control   │ ◄──────────────────────── │  • 8GB+ RAM          │
│                     │    Response: "Answer..."  │                      │
│  Requirements:      │                           │  Requirements:       │
│  - 2GB RAM          │                           │  - 16GB+ RAM         │
│  - No GPU needed    │                           │  - GPU (optional)    │
└─────────────────────┘                           └──────────────────────┘
```

---

## 🚀 Setup Steps

### **Step 1: VPS 2 पर Ollama Setup करें**

#### VPS 2 (Ollama Server) पर:

```bash
# 1. Ollama install करें
curl -fsSL https://ollama.ai/install.sh | sh

# 2. Ollama को network पर expose करें
# Method A: Environment variable से
export OLLAMA_HOST=0.0.0.0:11434

# Method B: Service file edit करें
sudo systemctl edit ollama.service
# Add:
# [Service]
# Environment="OLLAMA_HOST=0.0.0.0:11434"

# 3. Ollama restart करें
sudo systemctl restart ollama

# 4. Model download करें
ollama pull llama3        # 4.7GB
ollama pull mistral       # 4.1GB (faster alternative)
ollama pull codellama     # Code specialist

# 5. Test करें
curl http://localhost:11434/api/tags
```

#### Firewall खोलें:

```bash
# Ubuntu/Debian
sudo ufw allow 11434/tcp

# CentOS/RHEL
sudo firewall-cmd --permanent --add-port=11434/tcp
sudo firewall-cmd --reload

# या specific IP से allow करें (more secure)
sudo ufw allow from VPS1_IP to any port 11434
```

#### Security (ज़रूरी!):

```bash
# Option 1: Nginx reverse proxy with authentication
sudo apt install nginx

# /etc/nginx/sites-available/ollama
server {
    listen 80;
    server_name ollama.yourdomain.com;
    
    location / {
        proxy_pass http://localhost:11434;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        
        # Basic auth
        auth_basic "Ollama API";
        auth_basic_user_file /etc/nginx/.htpasswd;
    }
}

# Create password
sudo htpasswd -c /etc/nginx/.htpasswd admin

# Enable site
sudo ln -s /etc/nginx/sites-available/ollama /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

#### या फिर SSH Tunnel से secure करें:

```bash
# VPS 1 से VPS 2 को SSH tunnel के through access करें
ssh -L 11434:localhost:11434 user@VPS2_IP -N -f
# अब VPS 1 से localhost:11434 पर Ollama available होगा
```

---

### **Step 2: VPS 1 पर Agent Setup करें**

#### VPS 1 (Agent Server) पर:

```bash
# 1. Repository clone करें
cd /opt
git clone <your-repo-url> autonomous_agent
cd autonomous_agent

# 2. Dependencies install करें
pip install -r requirements.txt

# 3. Configuration file बनाएं
cp .env.example .env
nano .env
```

#### `.env` file में add करें:

```bash
# Remote Ollama Configuration
OLLAMA_URL=http://VPS2_IP:11434
# या अगर domain setup किया है
OLLAMA_URL=http://ollama.yourdomain.com

# Model name
OLLAMA_MODEL=llama3

# Enable Ollama
ENABLE_OLLAMA=true

# Optional: Authentication (if using nginx)
# OLLAMA_AUTH_USER=admin
# OLLAMA_AUTH_PASS=your_password

# GitHub Token (optional)
GITHUB_TOKEN=your_github_token_here
```

---

### **Step 3: Test Connection**

#### VPS 1 से test करें:

```bash
# Test करें कि Ollama accessible है
curl http://VPS2_IP:11434/api/tags

# Output आना चाहिए:
# {"models":[{"name":"llama3","modified_at":"2024-01-01T00:00:00Z",...}]}
```

#### Python से test करें:

```bash
cd /opt/autonomous_agent

# Test script
python -c "
import requests
url = 'http://VPS2_IP:11434/api/tags'
response = requests.get(url)
print('✅ Connected!' if response.status_code == 200 else '❌ Failed')
print(response.json())
"
```

---

### **Step 4: Agent Configuration Update**

Agent automatically `.env` file से settings load करेगा, लेकिन manually भी set कर सकते हो:

```python
# config.py में already है:
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3")
ENABLE_OLLAMA = os.getenv("ENABLE_OLLAMA", "true").lower() == "true"
```

---

### **Step 5: Run Agent**

```bash
cd /opt/autonomous_agent

# Run in background with nohup
nohup python main.py > logs/agent.log 2>&1 &

# Or with systemd service (recommended)
sudo nano /etc/systemd/system/autonomous-agent.service
```

#### Systemd service file:

```ini
[Unit]
Description=Autonomous AI Agent
After=network.target

[Service]
Type=simple
User=your_user
WorkingDirectory=/opt/autonomous_agent
Environment="PATH=/usr/local/bin:/usr/bin:/bin"
EnvironmentFile=/opt/autonomous_agent/.env
ExecStart=/usr/bin/python3 /opt/autonomous_agent/main.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

```bash
# Enable and start service
sudo systemctl daemon-reload
sudo systemctl enable autonomous-agent
sudo systemctl start autonomous-agent

# Check status
sudo systemctl status autonomous-agent

# View logs
sudo journalctl -u autonomous-agent -f
```

---

## 🔒 Security Best Practices (सुरक्षा)

### 1. **VPN Use करें** (Most Secure)
```bash
# Both servers को private VPN में connect करें
# Recommended: Tailscale, Wireguard, या OpenVPN
```

### 2. **Firewall Rules** (ज़रूरी)
```bash
# VPS 2 पर - सिर्फ VPS 1 का IP allow करें
sudo ufw allow from VPS1_IP to any port 11434
sudo ufw deny 11434
```

### 3. **Authentication** (अच्छा practice)
Nginx reverse proxy के through password protection:
```nginx
auth_basic "Ollama API";
auth_basic_user_file /etc/nginx/.htpasswd;
```

### 4. **HTTPS/SSL** (Production के लिए)
```bash
# Let's Encrypt से free SSL
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d ollama.yourdomain.com
```

### 5. **Rate Limiting** (DDoS protection)
```nginx
# Nginx में
limit_req_zone $binary_remote_addr zone=ollama:10m rate=10r/s;

location / {
    limit_req zone=ollama burst=20 nodelay;
    proxy_pass http://localhost:11434;
}
```

---

## 📊 Monitoring Setup (Optional but Recommended)

### VPS 2 (Ollama) Monitoring:

```bash
# Install monitoring
pip install prometheus-client

# Script: monitor_ollama.py
import requests
import time
from prometheus_client import start_http_server, Gauge

ollama_requests = Gauge('ollama_requests_total', 'Total requests')
ollama_response_time = Gauge('ollama_response_time', 'Response time')

start_http_server(8000)

while True:
    try:
        start = time.time()
        response = requests.get('http://localhost:11434/api/tags')
        duration = time.time() - start
        
        if response.status_code == 200:
            ollama_requests.inc()
            ollama_response_time.set(duration)
    except:
        pass
    
    time.sleep(60)
```

---

## 🧪 Testing Remote Connection

### Test Script (`test_remote_ollama.py`):

```python
#!/usr/bin/env python3
"""
Test remote Ollama connection
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from core.ollama_brain import OllamaBrain

def test_connection():
    print("Testing Remote Ollama Connection...\n")
    
    # Initialize brain
    brain = OllamaBrain()
    
    # Test connection
    print(f"Ollama URL: {brain.ollama_url}")
    print(f"Model: {brain.model_name}")
    print(f"Enabled: {brain.enabled}\n")
    
    if not brain.enabled:
        print("❌ Ollama not connected!")
        print("\nTroubleshooting:")
        print("1. Check if Ollama server is running on VPS 2")
        print("2. Check firewall allows port 11434")
        print("3. Verify OLLAMA_URL in .env file")
        return False
    
    # Test thinking
    print("Testing AI thinking...")
    result = brain.think("Say hello in 5 words", mode=brain.ThinkingMode.FAST)
    
    if result['success']:
        print(f"✅ Success! Response: {result['response']}\n")
        return True
    else:
        print(f"❌ Failed: {result}\n")
        return False

if __name__ == "__main__":
    success = test_connection()
    sys.exit(0 if success else 1)
```

Run test:
```bash
python test_remote_ollama.py
```

---

## 💡 Tips & Tricks

### Multiple Agents से Same Ollama:
```bash
# VPS 1, VPS 3, VPS 4 सब एक ही Ollama server (VPS 2) use कर सकते हैं
# Bas सबमें OLLAMA_URL same set करो
```

### Load Balancing:
```bash
# अगर बहुत traffic है तो multiple Ollama servers बना सकते हो
# और Nginx से load balance करो:

upstream ollama_backend {
    server vps2:11434;
    server vps3:11434;
    server vps4:11434;
}
```

### Faster Models:
```bash
# Light-weight models for faster response:
ollama pull phi           # 2.7GB - very fast
ollama pull tinyllama     # 637MB - extremely fast
ollama pull mistral       # 4.1GB - good balance
```

---

## 🐛 Troubleshooting (समस्या का समाधान)

### Problem 1: Connection Refused
```bash
# Check if Ollama is listening on 0.0.0.0
netstat -tlnp | grep 11434

# Should show: 0.0.0.0:11434 (not 127.0.0.1:11434)
```

### Problem 2: Firewall Blocking
```bash
# VPS 2 पर
sudo ufw status
sudo ufw allow 11434/tcp

# Test from VPS 1
telnet VPS2_IP 11434
```

### Problem 3: Slow Response
```bash
# Use smaller model
ollama pull mistral

# Or optimize Ollama
export OLLAMA_NUM_PARALLEL=4
export OLLAMA_MAX_LOADED_MODELS=2
```

### Problem 4: Out of Memory
```bash
# VPS 2 पर memory check करें
free -h

# Smaller model use करें
ollama pull phi    # Only 2.7GB
```

---

## 📈 Performance Comparison

### Local Setup (सब एक ही server पर):
- Agent + Ollama = 16GB RAM needed
- GPU recommended
- Single point of failure

### Remote Setup (यह approach):
- Agent VPS: 2-4GB RAM enough
- Ollama VPS: 8-16GB RAM
- Can scale independently
- Better resource utilization

---

## 🎯 Cost Optimization

### Budget Setup:
- **VPS 1 (Agent):** $5/month (1GB RAM, 1 CPU)
- **VPS 2 (Ollama):** $20/month (8GB RAM, 4 CPU)
- **Total:** $25/month

### Better Setup:
- **VPS 1 (Agent):** $10/month (2GB RAM, 2 CPU)
- **VPS 2 (Ollama with GPU):** $50/month (16GB RAM, GPU)
- **Total:** $60/month (बहुत fast!)

---

## ✅ Quick Checklist

Setup complete होने के बाद check करें:

- [ ] VPS 2 पर Ollama running है
- [ ] Port 11434 खुला है
- [ ] Firewall rules सही हैं
- [ ] VPS 1 से Ollama access हो रहा है
- [ ] Test script pass हो रहा है
- [ ] Agent successfully connect हो रहा है
- [ ] Security measures लगाए हैं (firewall/auth)
- [ ] Monitoring setup है (optional)

---

## 📞 Need Help?

अगर कोई problem आए तो:
1. Check logs: `sudo journalctl -u autonomous-agent -f`
2. Test connection: `python test_remote_ollama.py`
3. Check Ollama logs on VPS 2: `sudo journalctl -u ollama -f`

---

**Happy Coding! 🚀**

यह setup production-ready है और multiple agents scale कर सकते हो! 💪
