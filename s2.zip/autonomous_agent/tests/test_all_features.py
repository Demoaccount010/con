"""
Comprehensive tests for all features
"""
import unittest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from agent import AutonomousAgent

class TestVectorMemory(unittest.TestCase):
    """Test vector memory system"""
    
    def setUp(self):
        """Setup test agent"""
        self.agent = AutonomousAgent(name="TestAgent")
    
    def test_vector_memory_initialization(self):
        """Test vector memory is initialized"""
        self.assertIsNotNone(self.agent.memory)
        # Check if vector memory is available (may not be if dependencies missing)
        if hasattr(self.agent.memory, 'vector_memory'):
            print("✅ Vector memory available")
        else:
            print("⚠️  Vector memory not available (missing dependencies)")
    
    def test_semantic_search(self):
        """Test semantic search functionality"""
        if not hasattr(self.agent.memory, 'semantic_search'):
            self.skipTest("Semantic search not available")
        
        # Store some memories
        self.agent.memory.store_episode(
            "Create a file",
            "File created successfully",
            "create",
            "success"
        )
        
        # Search semantically
        results = self.agent.memory.semantic_search("make a new file", top_k=3)
        self.assertIsInstance(results, list)
        print(f"✅ Semantic search returned {len(results)} results")

class TestCodeModifier(unittest.TestCase):
    """Test code modification system"""
    
    def test_code_modifier_initialization(self):
        """Test code modifier can be initialized"""
        from core.code_modifier import CodeModifier
        
        modifier = CodeModifier()
        self.assertIsNotNone(modifier)
        print("✅ Code modifier initialized")
    
    def test_analyze_structure(self):
        """Test code structure analysis"""
        from core.code_modifier import CodeModifier
        
        modifier = CodeModifier()
        
        # Analyze agent.py
        agent_file = Path(__file__).parent.parent / "agent.py"
        if agent_file.exists():
            structure = modifier.analyze_structure(str(agent_file))
            self.assertIn('classes', structure)
            self.assertIn('functions', structure)
            print(f"✅ Analyzed code: {len(structure['classes'])} classes, {len(structure['functions'])} functions")

class TestAdvancedLearning(unittest.TestCase):
    """Test advanced learning system"""
    
    def test_advanced_learning_initialization(self):
        """Test advanced learning initialization"""
        agent = AutonomousAgent(name="TestAgent")
        
        if hasattr(agent.learning_engine, 'advanced_learning'):
            self.assertIsNotNone(agent.learning_engine.advanced_learning)
            print("✅ Advanced learning initialized")
        else:
            print("⚠️  Advanced learning not available")
    
    def test_pattern_detection(self):
        """Test pattern detection"""
        agent = AutonomousAgent(name="TestAgent")
        
        if not hasattr(agent.learning_engine, 'advanced_learning'):
            self.skipTest("Advanced learning not available")
        
        # Create task sequence
        tasks = [
            {'type': 'create', 'timestamp': '2024-01-01T10:00:00'},
            {'type': 'read', 'timestamp': '2024-01-01T10:05:00'},
            {'type': 'update', 'timestamp': '2024-01-01T10:10:00'},
            {'type': 'create', 'timestamp': '2024-01-01T10:15:00'},
            {'type': 'read', 'timestamp': '2024-01-01T10:20:00'},
        ]
        
        patterns = agent.learning_engine.advanced_learning.detect_pattern(tasks)
        self.assertIsInstance(patterns, list)
        print(f"✅ Detected {len(patterns)} patterns")

class TestOllamaBrain(unittest.TestCase):
    """Test Ollama brain integration"""
    
    def test_ollama_brain_initialization(self):
        """Test Ollama brain initialization"""
        agent = AutonomousAgent(name="TestAgent")
        
        if agent.ollama_brain:
            print(f"✅ Ollama brain initialized: {agent.ollama_brain.model_name}")
            if agent.ollama_brain.enabled:
                print("✅ Ollama is connected and available")
            else:
                print("⚠️  Ollama not connected (is ollama running?)")
        else:
            print("⚠️  Ollama brain not available")
    
    def test_ollama_thinking(self):
        """Test Ollama thinking capability"""
        agent = AutonomousAgent(name="TestAgent")
        
        if not agent.ollama_brain or not agent.ollama_brain.enabled:
            self.skipTest("Ollama not available")
        
        result = agent.ollama_brain.think("What is 2+2?")
        self.assertIn('success', result)
        if result['success']:
            print(f"✅ Ollama thinking works: {result['response'][:50]}...")

class TestSystemControl(unittest.TestCase):
    """Test system control skills"""
    
    def test_system_skills_available(self):
        """Test system skills are available"""
        agent = AutonomousAgent(name="TestAgent")
        
        skills = [
            ('system_skill', 'System Control'),
            ('file_skill', 'File Operations'),
            ('process_skill', 'Process Management'),
            ('browser_skill', 'Browser Control'),
        ]
        
        for skill_attr, skill_name in skills:
            if hasattr(agent, skill_attr) and getattr(agent, skill_attr):
                print(f"✅ {skill_name} available")
            else:
                print(f"⚠️  {skill_name} not available")
    
    def test_system_info(self):
        """Test getting system information"""
        agent = AutonomousAgent(name="TestAgent")
        
        if not agent.system_skill:
            self.skipTest("System skill not available")
        
        result = agent.system_skill.run(action='info')
        self.assertTrue(result.get('success'))
        print(f"✅ System info: {result['result'].get('system')}")

class TestGitHubLearning(unittest.TestCase):
    """Test GitHub learning capabilities"""
    
    def test_github_learner_available(self):
        """Test GitHub learner initialization"""
        agent = AutonomousAgent(name="TestAgent")
        
        if agent.skill_generator.github_learner:
            print("✅ GitHub learner available")
        else:
            print("⚠️  GitHub learner not available")
    
    def test_github_search(self):
        """Test GitHub repository search"""
        agent = AutonomousAgent(name="TestAgent")
        
        if not agent.skill_generator.github_learner:
            self.skipTest("GitHub learner not available")
        
        repos = agent.skill_generator.search_github_repos("python hello world", limit=1)
        self.assertIsInstance(repos, list)
        print(f"✅ GitHub search returned {len(repos)} results")

class TestProactiveAssistant(unittest.TestCase):
    """Test proactive assistant"""
    
    def test_proactive_assistant_available(self):
        """Test proactive assistant initialization"""
        agent = AutonomousAgent(name="TestAgent")
        
        if agent.proactive_assistant:
            print("✅ Proactive assistant available")
        else:
            print("⚠️  Proactive assistant not available")
    
    def test_system_health_check(self):
        """Test system health check"""
        agent = AutonomousAgent(name="TestAgent")
        
        if not agent.proactive_assistant:
            self.skipTest("Proactive assistant not available")
        
        health = agent.proactive_assistant.check_system_health()
        self.assertIn('success', health)
        if health['success']:
            print(f"✅ System health: {health['overall_status']}")

class TestIntegration(unittest.TestCase):
    """Test full integration"""
    
    def test_full_workflow(self):
        """Test complete workflow"""
        agent = AutonomousAgent(name="TestAgent")
        
        # Test basic processing
        response = agent.process("What can you do?")
        self.assertIn('success', response)
        print(f"✅ Full workflow: {response.get('message', '')[:50]}...")
    
    def test_agent_statistics(self):
        """Test getting agent statistics"""
        agent = AutonomousAgent(name="TestAgent")
        
        stats = agent.get_statistics()
        self.assertIsInstance(stats, dict)
        self.assertIn('agent_name', stats)
        print(f"✅ Agent statistics retrieved")

def run_all_tests():
    """Run all tests"""
    print("\n" + "="*70)
    print("  🧪 COMPREHENSIVE TEST SUITE")
    print("="*70 + "\n")
    
    # Create test suite
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Add all test classes
    suite.addTests(loader.loadTestsFromTestCase(TestVectorMemory))
    suite.addTests(loader.loadTestsFromTestCase(TestCodeModifier))
    suite.addTests(loader.loadTestsFromTestCase(TestAdvancedLearning))
    suite.addTests(loader.loadTestsFromTestCase(TestOllamaBrain))
    suite.addTests(loader.loadTestsFromTestCase(TestSystemControl))
    suite.addTests(loader.loadTestsFromTestCase(TestGitHubLearning))
    suite.addTests(loader.loadTestsFromTestCase(TestProactiveAssistant))
    suite.addTests(loader.loadTestsFromTestCase(TestIntegration))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Print summary
    print("\n" + "="*70)
    print("  📊 TEST SUMMARY")
    print("="*70)
    print(f"✅ Tests run: {result.testsRun}")
    print(f"✅ Passed: {result.testsRun - len(result.failures) - len(result.errors)}")
    if result.failures:
        print(f"❌ Failures: {len(result.failures)}")
    if result.errors:
        print(f"❌ Errors: {len(result.errors)}")
    if result.skipped:
        print(f"⚠️  Skipped: {len(result.skipped)}")
    
    print("\n" + "="*70 + "\n")
    
    return result.wasSuccessful()

if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
