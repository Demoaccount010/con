# 🔗 VPS Connection Guide - Step by Step (Hindi + English)

## VPS को आपस में कैसे Connect करें

3 तरीके हैं VPS connect करने के:
1. **Direct IP Connection** (सबसे आसान, basic security)
2. **SSH Tunnel** (Medium security, recommended)
3. **VPN Connection** (Best security, professional)

---

## 🎯 Method 1: Direct IP Connection (सबसे आसान)

### **सबसे पहले: IP Addresses पता करो**

#### VPS 2 (Ollama Server) पर:
```bash
# Login करो VPS 2 में
ssh root@your-vps2-ip

# IP address निकालो
ip addr show | grep 'inet '
# या
curl ifconfig.me

# Output: 203.0.113.50 (example)
# यह है tumhara VPS 2 का PUBLIC IP
```

#### VPS 1 (Agent Server) पर:
```bash
# Login करो VPS 1 में
ssh root@your-vps1-ip

# IP address निकालो
curl ifconfig.me

# Output: 198.51.100.25 (example)
# यह है tumhara VPS 1 का PUBLIC IP
```

---

### **Step 1: VPS 2 पर Ollama Setup**

```bash
# VPS 2 में login करो
ssh root@203.0.113.50

# Ollama install करो
curl -fsSL https://ollama.ai/install.sh | sh

# Ollama को network पर expose करो
sudo mkdir -p /etc/systemd/system/ollama.service.d/
sudo nano /etc/systemd/system/ollama.service.d/override.conf
```

**File में यह paste करो:**
```ini
[Service]
Environment="OLLAMA_HOST=0.0.0.0:11434"
```

**Save करो (Ctrl+X, Y, Enter)**

```bash
# Restart करो
sudo systemctl daemon-reload
sudo systemctl restart ollama

# Check करो - 0.0.0.0:11434 दिखना चाहिए
sudo netstat -tlnp | grep 11434

# Model download करो
ollama pull llama3

# Test करो locally
curl http://localhost:11434/api/tags
```

---

### **Step 2: VPS 2 पर Firewall Setup**

```bash
# VPS 1 का IP address note करो (example: 198.51.100.25)

# Ubuntu/Debian (UFW)
sudo ufw allow from 198.51.100.25 to any port 11434 proto tcp
sudo ufw deny 11434/tcp
sudo ufw status

# CentOS/RHEL (Firewalld)
sudo firewall-cmd --permanent --add-rich-rule='rule family="ipv4" source address="198.51.100.25" port protocol="tcp" port="11434" accept'
sudo firewall-cmd --reload
sudo firewall-cmd --list-all
```

**Important:** अगर cloud provider का firewall भी है (AWS Security Group, DigitalOcean Firewall), वहां भी allow करो!

---

### **Step 3: VPS 1 से Test करो**

```bash
# VPS 1 में login करो
ssh root@198.51.100.25

# VPS 2 को access करने की कोशिश करो
curl http://203.0.113.50:11434/api/tags

# Success होगा तो models की list आएगी:
# {"models":[{"name":"llama3","modified_at":"..."}]}
```

**अगर error आए:**
```bash
# Ping test करो
ping 203.0.113.50

# Port check करो
telnet 203.0.113.50 11434

# या
nc -zv 203.0.113.50 11434
```

---

### **Step 4: VPS 1 पर Agent Configure करो**

```bash
# Agent code की directory में जाओ
cd /opt/autonomous_agent

# .env file बनाओ
nano .env
```

**File में यह डालो:**
```bash
# VPS 2 का PUBLIC IP use करो
OLLAMA_URL=http://203.0.113.50:11434
OLLAMA_MODEL=llama3
ENABLE_OLLAMA=true
```

**Save करो (Ctrl+X, Y, Enter)**

---

### **Step 5: Connection Test करो**

```bash
# Test script run करो
python3 test_remote_ollama.py

# Success होगा तो दिखेगा:
# ✅ Server is reachable!
# ✅ Model 'llama3' is available
# ✅ AI Thinking Test passed
```

---

## 🔒 Method 2: SSH Tunnel (Recommended - More Secure)

### **यह method में:**
- Public internet पर Ollama expose नहीं होगा
- सिर्फ SSH के through access होगा
- ज्यादा secure है

---

### **Step 1: VPS 2 Setup (Simple)**

```bash
# VPS 2 में login करो
ssh root@203.0.113.50

# Ollama install करो (already किया होगा)
curl -fsSL https://ollama.ai/install.sh | sh

# इस बार LOCAL में ही रखो (0.0.0.0 नहीं)
# Default configuration ठीक है (127.0.0.1:11434)

# Model download करो
ollama pull llama3

# Firewall में कुछ नहीं खोलना - SSH port (22) ही enough है
```

---

### **Step 2: VPS 1 से SSH Tunnel बनाओ**

#### **Manual Method (Testing के लिए):**

```bash
# VPS 1 में login करो
ssh root@198.51.100.25

# SSH tunnel create करो
ssh -L 11434:localhost:11434 root@203.0.113.50 -N -f

# अब VPS 1 पर localhost:11434 से VPS 2 का Ollama accessible है!

# Test करो
curl http://localhost:11434/api/tags
```

**Explanation:**
- `-L 11434:localhost:11434` = Local port 11434 को remote localhost:11434 से connect करो
- `-N` = कोई command execute मत करो, सिर्फ tunnel बनाओ
- `-f` = Background में run करो

---

#### **Auto-start Method (Production के लिए):**

**Option A: Using systemd**

```bash
# VPS 1 पर service file बनाओ
sudo nano /etc/systemd/system/ollama-tunnel.service
```

**File में paste करो:**
```ini
[Unit]
Description=SSH Tunnel to Ollama Server
After=network.target

[Service]
Type=simple
User=root
ExecStart=/usr/bin/ssh -N -L 11434:localhost:11434 root@203.0.113.50
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

**Enable करो:**
```bash
sudo systemctl daemon-reload
sudo systemctl enable ollama-tunnel
sudo systemctl start ollama-tunnel
sudo systemctl status ollama-tunnel
```

---

**Option B: Using AutoSSH (Better - auto-reconnect)**

```bash
# VPS 1 पर AutoSSH install करो
sudo apt install autossh

# Service file बनाओ
sudo nano /etc/systemd/system/ollama-autossh.service
```

**File में paste करो:**
```ini
[Unit]
Description=AutoSSH Tunnel to Ollama Server
After=network.target

[Service]
Type=simple
User=root
Environment="AUTOSSH_GATETIME=0"
ExecStart=/usr/bin/autossh -M 0 -N -L 11434:localhost:11434 root@203.0.113.50 -o "ServerAliveInterval=60" -o "ServerAliveCountMax=3"
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

**Enable करो:**
```bash
sudo systemctl daemon-reload
sudo systemctl enable ollama-autossh
sudo systemctl start ollama-autossh
sudo systemctl status ollama-autossh
```

---

### **Step 3: SSH Key Setup (Password-less login)**

```bash
# VPS 1 पर SSH key बनाओ
ssh-keygen -t rsa -b 4096 -f ~/.ssh/ollama_key -N ""

# Public key को VPS 2 में copy करो
ssh-copy-id -i ~/.ssh/ollama_key.pub root@203.0.113.50

# Test करो (password नहीं पूछेगा)
ssh -i ~/.ssh/ollama_key root@203.0.113.50 "echo Connected successfully"
```

**Service file में key use करो:**
```ini
ExecStart=/usr/bin/autossh -M 0 -N -L 11434:localhost:11434 -i /root/.ssh/ollama_key root@203.0.113.50
```

---

### **Step 4: Agent Configure करो**

```bash
# VPS 1 पर .env file
nano /opt/autonomous_agent/.env
```

**Paste करो:**
```bash
# Localhost use करो क्योंकि tunnel है
OLLAMA_URL=http://localhost:11434
OLLAMA_MODEL=llama3
ENABLE_OLLAMA=true
```

---

### **Step 5: Test करो**

```bash
# Check tunnel
curl http://localhost:11434/api/tags

# Agent test
cd /opt/autonomous_agent
python3 test_remote_ollama.py
```

---

## 🛡️ Method 3: VPN Connection (Most Secure)

### **Using Tailscale (सबसे आसान VPN):**

#### **Step 1: VPS 2 पर Install करो**

```bash
# VPS 2 में login
ssh root@203.0.113.50

# Tailscale install
curl -fsSL https://tailscale.com/install.sh | sh

# Start करो
sudo tailscale up

# IP address note करो
tailscale ip -4
# Output: 100.64.1.50 (example - यह internal VPN IP है)
```

---

#### **Step 2: VPS 1 पर Install करो**

```bash
# VPS 1 में login
ssh root@198.51.100.25

# Tailscale install
curl -fsSL https://tailscale.com/install.sh | sh

# Start करो
sudo tailscale up

# IP address note करो
tailscale ip -4
# Output: 100.64.1.25 (example)
```

---

#### **Step 3: Connect करो**

```bash
# VPS 1 से VPS 2 को ping करो
ping 100.64.1.50

# Ollama access करो
curl http://100.64.1.50:11434/api/tags
```

---

#### **Step 4: Agent Configure करो**

```bash
# VPS 1 पर .env
nano /opt/autonomous_agent/.env
```

**Paste:**
```bash
# Tailscale IP use करो
OLLAMA_URL=http://100.64.1.50:11434
OLLAMA_MODEL=llama3
ENABLE_OLLAMA=true
```

---

## 🔍 Troubleshooting (समस्या का समाधान)

### Problem 1: Connection Refused

```bash
# VPS 2 पर check करो
sudo netstat -tlnp | grep 11434

# 0.0.0.0:11434 दिखना चाहिए, not 127.0.0.1:11434
# अगर 127.0.0.1 है तो:

sudo nano /etc/systemd/system/ollama.service.d/override.conf
# Add: Environment="OLLAMA_HOST=0.0.0.0:11434"

sudo systemctl daemon-reload
sudo systemctl restart ollama
```

---

### Problem 2: Firewall Blocking

```bash
# VPS 2 पर firewall check करो
sudo ufw status

# VPS 1 का IP allow करो
sudo ufw allow from 198.51.100.25 to any port 11434

# Cloud provider firewall भी check करो!
```

---

### Problem 3: SSH Tunnel Disconnect

```bash
# AutoSSH use करो (ऊपर दिया है)
# या check करो:
ps aux | grep ssh | grep 11434

# Restart करो
sudo systemctl restart ollama-autossh
```

---

### Problem 4: Can't Reach VPS

```bash
# Basic connectivity check
ping 203.0.113.50

# DNS check
nslookup yourdomain.com

# Port check
telnet 203.0.113.50 11434
# या
nc -zv 203.0.113.50 11434
```

---

## 📊 Method Comparison

| Method | Security | Ease | Speed | Cost |
|--------|----------|------|-------|------|
| Direct IP | ⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | Free |
| SSH Tunnel | ⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | Free |
| VPN (Tailscale) | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | Free |

---

## 💡 Recommended Setup:

### **For Testing:**
- Use **Direct IP** (Method 1)
- Quick और आसान

### **For Production:**
- Use **SSH Tunnel** (Method 2) या **Tailscale VPN** (Method 3)
- Secure और reliable

---

## ✅ Quick Commands Cheatsheet

```bash
# VPS 2 - Check if Ollama is accessible
curl http://localhost:11434/api/tags

# VPS 1 - Test connection to VPS 2
curl http://VPS2_IP:11434/api/tags

# Check tunnel is running (Method 2)
ps aux | grep ssh | grep 11434

# Check Tailscale connection (Method 3)
tailscale status

# Test agent connection
cd /opt/autonomous_agent
python3 test_remote_ollama.py
```

---

## 🎯 Final Checklist

- [ ] VPS 2: Ollama installed और running
- [ ] VPS 2: Port 11434 accessible (Method 1) या tunnel ready (Method 2,3)
- [ ] VPS 2: Firewall configured
- [ ] VPS 2: Model downloaded
- [ ] VPS 1: Can ping VPS 2
- [ ] VPS 1: Can access Ollama API
- [ ] VPS 1: .env configured with correct URL
- [ ] VPS 1: test_remote_ollama.py passes
- [ ] VPS 1: Agent starts successfully

---

**Ab समझ आया भाई? Koi doubt ho to poocho! 🚀**
