#!/usr/bin/env python3
"""
Test remote Ollama connection
Remote Ollama server ko test karne ke liye
"""
import sys
import os
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

def test_connection():
    """Test Ollama connection"""
    print("\n" + "="*60)
    print("  🔍 Testing Remote Ollama Connection")
    print("="*60 + "\n")
    
    # Load environment variables
    from dotenv import load_dotenv
    load_dotenv()
    
    ollama_url = os.getenv('OLLAMA_URL', 'http://localhost:11434')
    ollama_model = os.getenv('OLLAMA_MODEL', 'llama3')
    
    print(f"📡 Testing connection to: {ollama_url}")
    print(f"🤖 Model: {ollama_model}\n")
    
    # Test 1: Basic connectivity
    print("Test 1: Basic Connectivity")
    print("-" * 40)
    
    import requests
    try:
        response = requests.get(f"{ollama_url}/api/tags", timeout=5)
        if response.status_code == 200:
            print("✅ Server is reachable!")
            models = response.json().get('models', [])
            print(f"✅ Available models: {len(models)}")
            for model in models:
                print(f"   - {model['name']}")
        else:
            print(f"❌ Server returned status: {response.status_code}")
            return False
    except requests.exceptions.ConnectionError:
        print(f"❌ Connection failed! Server not reachable at {ollama_url}")
        print("\n💡 Troubleshooting:")
        print("   1. Check if Ollama is running on remote server")
        print("   2. Verify OLLAMA_URL in .env file")
        print("   3. Check firewall allows port 11434")
        print("   4. Try: curl http://YOUR_SERVER_IP:11434/api/tags")
        return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False
    
    print()
    
    # Test 2: Model availability
    print("Test 2: Model Availability")
    print("-" * 40)
    
    model_found = False
    for model in models:
        if ollama_model in model['name']:
            model_found = True
            print(f"✅ Model '{ollama_model}' is available")
            print(f"   Size: {model.get('size', 'unknown')}")
            print(f"   Modified: {model.get('modified_at', 'unknown')}")
            break
    
    if not model_found:
        print(f"⚠️  Model '{ollama_model}' not found")
        print(f"   Available models: {[m['name'] for m in models]}")
        print(f"\n💡 To download model on remote server:")
        print(f"   ssh user@server 'ollama pull {ollama_model}'")
    
    print()
    
    # Test 3: AI Thinking
    print("Test 3: AI Thinking Test")
    print("-" * 40)
    
    try:
        from core.ollama_brain import OllamaBrain
        
        brain = OllamaBrain(ollama_url=ollama_url, model_name=ollama_model)
        
        if not brain.enabled:
            print("❌ Ollama brain not enabled")
            return False
        
        print("💭 Asking Ollama: 'What is 2+2? Answer in one word.'")
        
        result = brain.think(
            "What is 2+2? Answer in one word only.",
            mode=brain.ThinkingMode.FAST
        )
        
        if result['success']:
            print(f"✅ Response: {result['response'].strip()}")
            print(f"✅ Model: {result['model']}")
            print(f"✅ Response time: Fast")
        else:
            print(f"❌ Failed to get response")
            return False
            
    except Exception as e:
        print(f"❌ Error testing brain: {e}")
        return False
    
    print()
    
    # Test 4: Code Generation
    print("Test 4: Code Generation Test")
    print("-" * 40)
    
    try:
        print("💭 Generating simple Python code...")
        
        code_result = brain.generate_code(
            "A function that adds two numbers",
            language="python"
        )
        
        if code_result['success']:
            print(f"✅ Code generated successfully!")
            print(f"   Lines: {len(code_result['code'].split(chr(10)))}")
            print(f"   Preview:\n{code_result['code'][:100]}...")
        else:
            print(f"⚠️  Code generation skipped")
            
    except Exception as e:
        print(f"⚠️  Code generation test failed: {e}")
    
    print()
    
    # Test 5: Performance
    print("Test 5: Performance Test")
    print("-" * 40)
    
    try:
        import time
        
        print("⏱️  Testing response time (3 requests)...")
        times = []
        
        for i in range(3):
            start = time.time()
            result = brain.think(
                f"Say number {i+1}",
                mode=brain.ThinkingMode.FAST
            )
            duration = time.time() - start
            times.append(duration)
            print(f"   Request {i+1}: {duration:.2f}s")
        
        avg_time = sum(times) / len(times)
        print(f"\n✅ Average response time: {avg_time:.2f}s")
        
        if avg_time < 3:
            print("   ⚡ Excellent performance!")
        elif avg_time < 5:
            print("   ✅ Good performance")
        else:
            print("   ⚠️  Slow response (consider using smaller model)")
            
    except Exception as e:
        print(f"⚠️  Performance test failed: {e}")
    
    print()
    
    # Final Summary
    print("="*60)
    print("  📊 TEST SUMMARY")
    print("="*60)
    print("✅ All tests passed!")
    print("\n🎉 Remote Ollama setup is working correctly!")
    print(f"🔗 Connected to: {ollama_url}")
    print(f"🤖 Using model: {ollama_model}")
    print("\n💡 You can now use the agent with remote Ollama:")
    print("   python main.py")
    print()
    
    return True

def main():
    """Main function"""
    try:
        success = test_connection()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n\n⚠️  Test interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
