"""
Ollama Brain - Real AI thinking using Ollama local LLM
Provides intelligent reasoning, code generation, and analysis
"""
import json
import requests
from typing import Dict, List, Optional, Any
from enum import Enum

try:
    from ..utils import setup_logger, timestamp
    from ..config import OLLAMA_URL, OLLAMA_MODEL, OLLAMA_TIMEOUT, ENABLE_OLLAMA
except ImportError:
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from utils import setup_logger, timestamp
    from config import OLLAMA_URL, OLLAMA_MODEL, OLLAMA_TIMEOUT, ENABLE_OLLAMA

class ThinkingMode(Enum):
    """Different modes of thinking for various tasks"""
    FAST = "fast"           # Quick responses, less detailed
    NORMAL = "normal"       # Balanced speed and quality
    DEEP = "deep"          # Thorough analysis, slower
    CREATIVE = "creative"   # Creative problem solving

class OllamaBrain:
    """
    Main brain of the agent using Ollama LLM for real AI thinking
    """
    
    def __init__(self, model_name: str = None, ollama_url: str = None):
        """Initialize Ollama Brain"""
        self.logger = setup_logger(self.__class__.__name__)
        self.ollama_url = ollama_url or OLLAMA_URL
        self.model_name = model_name or OLLAMA_MODEL
        self.enabled = ENABLE_OLLAMA
        self.timeout = OLLAMA_TIMEOUT
        
        # Test connection on init
        if self.enabled:
            connected = self.test_connection()
            if connected:
                self.logger.info(f"Ollama Brain connected: {self.model_name}")
            else:
                self.logger.warning("Ollama not available, using fallback mode")
                self.enabled = False
        else:
            self.logger.info("Ollama Brain disabled in config")
    
    def test_connection(self) -> bool:
        """Test connection to Ollama server"""
        try:
            response = requests.get(f"{self.ollama_url}/api/tags", timeout=5)
            if response.status_code == 200:
                models = response.json().get('models', [])
                available_models = [m['name'] for m in models]
                self.logger.info(f"Available Ollama models: {available_models}")
                return True
            return False
        except Exception as e:
            self.logger.error(f"Ollama connection failed: {e}")
            return False
    
    def think(self, prompt: str, context: Dict = None, mode: ThinkingMode = ThinkingMode.NORMAL) -> Dict:
        """
        Main thinking function - uses Ollama to process prompts
        
        Args:
            prompt: The question or task to think about
            context: Optional context information
            mode: Thinking mode (fast, normal, deep, creative)
        
        Returns:
            Dict with response and metadata
        """
        if not self.enabled:
            return self._fallback_response(prompt)
        
        try:
            # Build the full prompt with context
            full_prompt = self._build_prompt(prompt, context, mode)
            
            # Set temperature based on mode
            temperature = self._get_temperature(mode)
            
            # Call Ollama API
            response = requests.post(
                f"{self.ollama_url}/api/generate",
                json={
                    "model": self.model_name,
                    "prompt": full_prompt,
                    "temperature": temperature,
                    "stream": False
                },
                timeout=self.timeout
            )
            
            if response.status_code == 200:
                result = response.json()
                return {
                    'success': True,
                    'response': result.get('response', ''),
                    'model': self.model_name,
                    'mode': mode.value,
                    'timestamp': timestamp()
                }
            else:
                self.logger.error(f"Ollama API error: {response.status_code}")
                return self._fallback_response(prompt)
                
        except Exception as e:
            self.logger.error(f"Error in think(): {e}")
            return self._fallback_response(prompt)
    
    def analyze_task(self, task_description: str) -> Dict:
        """
        Break down a task into steps using AI analysis
        
        Args:
            task_description: Description of the task
        
        Returns:
            Dict with task breakdown and analysis
        """
        prompt = f"""Analyze this task and break it into clear steps:

Task: {task_description}

Provide:
1. Task category (e.g., file_operation, system_command, skill_creation)
2. Difficulty level (easy, medium, hard)
3. Required capabilities
4. Step-by-step breakdown
5. Potential risks or challenges

Format your response as JSON."""

        result = self.think(prompt, mode=ThinkingMode.DEEP)
        
        if result['success']:
            try:
                # Try to parse JSON from response
                response_text = result['response']
                # Extract JSON if wrapped in markdown
                if '```json' in response_text:
                    json_start = response_text.find('```json') + 7
                    json_end = response_text.find('```', json_start)
                    response_text = response_text[json_start:json_end].strip()
                elif '```' in response_text:
                    json_start = response_text.find('```') + 3
                    json_end = response_text.find('```', json_start)
                    response_text = response_text[json_start:json_end].strip()
                
                analysis = json.loads(response_text)
                return {
                    'success': True,
                    'analysis': analysis,
                    'raw_response': result['response']
                }
            except json.JSONDecodeError:
                # If JSON parsing fails, return structured text
                return {
                    'success': True,
                    'analysis': {
                        'raw_analysis': result['response'],
                        'steps': self._extract_steps(result['response'])
                    },
                    'raw_response': result['response']
                }
        
        return {'success': False, 'error': 'Failed to analyze task'}
    
    def evaluate_capability(self, task: str, available_skills: List[str]) -> Dict:
        """
        Evaluate if the agent can perform a task with available skills
        
        Args:
            task: The task to evaluate
            available_skills: List of available skill names
        
        Returns:
            Dict with capability assessment
        """
        prompt = f"""Evaluate if this task can be completed with the available skills:

Task: {task}

Available Skills: {', '.join(available_skills)}

Determine:
1. Can the task be completed? (yes/no/partial)
2. Which skills are needed?
3. What skills are missing (if any)?
4. Confidence level (0-100%)
5. Suggested approach

Respond in JSON format."""

        result = self.think(prompt, mode=ThinkingMode.NORMAL)
        
        if result['success']:
            try:
                response_text = result['response']
                if '```json' in response_text:
                    json_start = response_text.find('```json') + 7
                    json_end = response_text.find('```', json_start)
                    response_text = response_text[json_start:json_end].strip()
                
                evaluation = json.loads(response_text)
                return {
                    'success': True,
                    'can_complete': evaluation.get('can_complete', 'no'),
                    'needed_skills': evaluation.get('needed_skills', []),
                    'missing_skills': evaluation.get('missing_skills', []),
                    'confidence': evaluation.get('confidence', 0),
                    'approach': evaluation.get('approach', ''),
                    'raw_response': result['response']
                }
            except:
                return {
                    'success': True,
                    'can_complete': 'partial',
                    'raw_response': result['response']
                }
        
        return {'success': False, 'error': 'Failed to evaluate capability'}
    
    def generate_code(self, specification: str, language: str = "python") -> Dict:
        """
        Generate code based on specification using LLM
        
        Args:
            specification: What the code should do
            language: Programming language (default: python)
        
        Returns:
            Dict with generated code and explanation
        """
        prompt = f"""Generate {language} code for the following specification:

Specification: {specification}

Requirements:
1. Write clean, well-documented code
2. Include error handling
3. Add type hints (for Python)
4. Follow best practices
5. Add docstrings

Provide the code in a code block, followed by a brief explanation."""

        result = self.think(prompt, mode=ThinkingMode.NORMAL)
        
        if result['success']:
            response = result['response']
            
            # Extract code from response
            code = self._extract_code(response, language)
            explanation = self._extract_explanation(response)
            
            return {
                'success': True,
                'code': code,
                'explanation': explanation,
                'language': language,
                'raw_response': response
            }
        
        return {'success': False, 'error': 'Failed to generate code'}
    
    def self_reflect(self, action_taken: str, result: Dict) -> Dict:
        """
        Reflect on an action and its result for learning
        
        Args:
            action_taken: Description of what was done
            result: Result of the action
        
        Returns:
            Dict with reflection and learnings
        """
        prompt = f"""Reflect on this action and its result:

Action: {action_taken}
Result: {json.dumps(result, indent=2)}

Provide:
1. Was it successful?
2. What went well?
3. What could be improved?
4. Key learnings
5. How to approach similar tasks in the future

Be honest and critical for better learning."""

        reflection = self.think(prompt, mode=ThinkingMode.DEEP)
        
        if reflection['success']:
            return {
                'success': True,
                'reflection': reflection['response'],
                'timestamp': timestamp()
            }
        
        return {'success': False, 'error': 'Failed to reflect'}
    
    def chain_of_thought(self, problem: str) -> List[str]:
        """
        Perform step-by-step reasoning on a problem
        
        Args:
            problem: The problem to solve
        
        Returns:
            List of reasoning steps
        """
        prompt = f"""Use chain-of-thought reasoning to solve this problem:

Problem: {problem}

Think step-by-step:
1. What do we know?
2. What do we need to find out?
3. What approach should we take?
4. Step-by-step solution
5. Final answer

Explain your reasoning at each step."""

        result = self.think(prompt, mode=ThinkingMode.DEEP)
        
        if result['success']:
            # Extract steps from response
            steps = self._extract_steps(result['response'])
            return steps
        
        return ["Failed to generate chain of thought"]
    
    def understand_intent(self, user_input: str, conversation_history: List[Dict] = None) -> Dict:
        """
        Deep understanding of user intent using LLM
        
        Args:
            user_input: User's input text
            conversation_history: Previous conversation
        
        Returns:
            Dict with intent, entities, and confidence
        """
        context = ""
        if conversation_history:
            context = "Previous conversation:\n"
            for msg in conversation_history[-3:]:  # Last 3 messages
                context += f"User: {msg.get('user', '')}\nAgent: {msg.get('agent', '')}\n"
        
        prompt = f"""{context}

Current user input: "{user_input}"

Analyze this input and provide:
1. Primary intent (create, read, update, delete, execute, learn, search, help, etc.)
2. Secondary intents (if any)
3. Extracted entities (files, URLs, names, numbers, etc.)
4. Language detected (english, hindi, hinglish)
5. Sentiment (positive, negative, neutral)
6. Confidence level (0-100%)
7. Any ambiguities or unclear parts

Respond in JSON format."""

        result = self.think(prompt, mode=ThinkingMode.FAST)
        
        if result['success']:
            try:
                response_text = result['response']
                if '```json' in response_text:
                    json_start = response_text.find('```json') + 7
                    json_end = response_text.find('```', json_start)
                    response_text = response_text[json_start:json_end].strip()
                
                understanding = json.loads(response_text)
                return {
                    'success': True,
                    'intent': understanding.get('primary_intent', 'unknown'),
                    'secondary_intents': understanding.get('secondary_intents', []),
                    'entities': understanding.get('entities', {}),
                    'language': understanding.get('language', 'english'),
                    'sentiment': understanding.get('sentiment', 'neutral'),
                    'confidence': understanding.get('confidence', 50) / 100.0,
                    'ambiguities': understanding.get('ambiguities', []),
                    'raw_response': result['response']
                }
            except:
                # Fallback to basic response
                return {
                    'success': True,
                    'intent': 'unknown',
                    'confidence': 0.3,
                    'raw_response': result['response']
                }
        
        return {'success': False, 'error': 'Failed to understand intent'}
    
    def _build_prompt(self, prompt: str, context: Dict, mode: ThinkingMode) -> str:
        """Build full prompt with context"""
        full_prompt = ""
        
        # Add mode-specific instructions
        if mode == ThinkingMode.FAST:
            full_prompt += "Respond quickly and concisely.\n\n"
        elif mode == ThinkingMode.DEEP:
            full_prompt += "Think deeply and provide thorough analysis.\n\n"
        elif mode == ThinkingMode.CREATIVE:
            full_prompt += "Think creatively and suggest innovative solutions.\n\n"
        
        # Add context if provided
        if context:
            full_prompt += f"Context: {json.dumps(context, indent=2)}\n\n"
        
        # Add main prompt
        full_prompt += prompt
        
        return full_prompt
    
    def _get_temperature(self, mode: ThinkingMode) -> float:
        """Get temperature based on thinking mode"""
        temps = {
            ThinkingMode.FAST: 0.3,
            ThinkingMode.NORMAL: 0.7,
            ThinkingMode.DEEP: 0.5,
            ThinkingMode.CREATIVE: 0.9
        }
        return temps.get(mode, 0.7)
    
    def _fallback_response(self, prompt: str) -> Dict:
        """Fallback response when Ollama is not available"""
        return {
            'success': False,
            'response': 'Ollama not available. Using basic mode.',
            'fallback': True,
            'original_prompt': prompt
        }
    
    def _extract_code(self, response: str, language: str) -> str:
        """Extract code block from response"""
        # Look for code blocks
        if f'```{language}' in response:
            start = response.find(f'```{language}') + len(f'```{language}')
            end = response.find('```', start)
            return response[start:end].strip()
        elif '```' in response:
            start = response.find('```') + 3
            end = response.find('```', start)
            return response[start:end].strip()
        
        return response
    
    def _extract_explanation(self, response: str) -> str:
        """Extract explanation from response"""
        # Get text after code blocks
        if '```' in response:
            last_block = response.rfind('```')
            explanation = response[last_block+3:].strip()
            return explanation if explanation else "No explanation provided"
        
        return response
    
    def _extract_steps(self, text: str) -> List[str]:
        """Extract numbered steps from text"""
        import re
        # Look for numbered items (1. , 2. , etc.)
        pattern = r'\d+\.\s+(.+?)(?=\d+\.|$)'
        steps = re.findall(pattern, text, re.DOTALL)
        
        if steps:
            return [step.strip() for step in steps]
        
        # Fallback: split by newlines
        lines = text.split('\n')
        return [line.strip() for line in lines if line.strip()]
    
    def get_model_info(self) -> Dict:
        """Get information about the current model"""
        if not self.enabled:
            return {'enabled': False, 'message': 'Ollama is disabled'}
        
        try:
            response = requests.get(f"{self.ollama_url}/api/tags", timeout=5)
            if response.status_code == 200:
                models = response.json().get('models', [])
                current_model = next((m for m in models if self.model_name in m['name']), None)
                
                return {
                    'enabled': True,
                    'current_model': self.model_name,
                    'model_info': current_model,
                    'available_models': [m['name'] for m in models]
                }
        except:
            pass
        
        return {'enabled': False, 'message': 'Failed to get model info'}
