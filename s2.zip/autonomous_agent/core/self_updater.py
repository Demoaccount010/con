"""
Self-Updater - Allows the agent to modify its own code safely
"""
import ast
import difflib
import shutil
from typing import Dict, List, Optional, Tuple
from pathlib import Path
import re

try:
    from ..utils import setup_logger, timestamp, validate_python_code, hash_content
    from ..config import BASE_DIR, LOGS_DIR
except ImportError:
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from utils import setup_logger, timestamp, validate_python_code, hash_content
    from config import BASE_DIR, LOGS_DIR

class SelfUpdater:
    """
    Manages self-modification of agent code with safety checks
    """
    
    def __init__(self):
        """Initialize Self-Updater"""
        self.logger = setup_logger(self.__class__.__name__)
        self.backup_dir = BASE_DIR / "backups"
        self.backup_dir.mkdir(exist_ok=True)
        self.modification_log = LOGS_DIR / "modifications.log"
        self.logger.info("Self-Updater initialized")
    
    def analyze_code(self, filepath: Path) -> Dict:
        """
        Analyze a Python file and extract structure
        
        Args:
            filepath: Path to Python file
        
        Returns:
            Dict with code structure information
        """
        try:
            with open(filepath, 'r') as f:
                code = f.read()
            
            tree = ast.parse(code)
            
            structure = {
                'filepath': str(filepath),
                'classes': [],
                'functions': [],
                'imports': [],
                'lines': len(code.split('\n')),
                'hash': hash_content(code)
            }
            
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    structure['classes'].append({
                        'name': node.name,
                        'lineno': node.lineno,
                        'methods': [m.name for m in node.body if isinstance(m, ast.FunctionDef)]
                    })
                elif isinstance(node, ast.FunctionDef):
                    # Only top-level functions
                    if node.col_offset == 0:
                        structure['functions'].append({
                            'name': node.name,
                            'lineno': node.lineno,
                            'args': [arg.arg for arg in node.args.args]
                        })
                elif isinstance(node, (ast.Import, ast.ImportFrom)):
                    if isinstance(node, ast.Import):
                        for alias in node.names:
                            structure['imports'].append(alias.name)
                    else:
                        structure['imports'].append(node.module)
            
            return structure
            
        except Exception as e:
            self.logger.error(f"Error analyzing code: {e}")
            return {'error': str(e)}
    
    def backup_file(self, filepath: Path) -> Optional[Path]:
        """
        Create backup of file before modification
        
        Args:
            filepath: Path to file to backup
        
        Returns:
            Path to backup file or None if failed
        """
        try:
            # Generate backup filename with timestamp
            backup_name = f"{filepath.stem}_{timestamp().replace(':', '-')}{filepath.suffix}"
            backup_path = self.backup_dir / backup_name
            
            # Copy file
            shutil.copy2(filepath, backup_path)
            
            self.logger.info(f"Created backup: {backup_path}")
            return backup_path
            
        except Exception as e:
            self.logger.error(f"Error creating backup: {e}")
            return None
    
    def modify_function(self, filepath: Path, function_name: str, 
                       new_code: str, backup: bool = True) -> bool:
        """
        Modify a specific function in a file
        
        Args:
            filepath: Path to Python file
            function_name: Name of function to modify
            new_code: New function code
            backup: Whether to create backup before modification
        
        Returns:
            True if modification successful
        """
        try:
            # Read current code
            with open(filepath, 'r') as f:
                original_code = f.read()
            
            # Validate new code
            is_valid, error = validate_python_code(new_code)
            if not is_valid:
                self.logger.error(f"Invalid code provided: {error}")
                return False
            
            # Create backup if requested
            if backup:
                backup_path = self.backup_file(filepath)
                if not backup_path:
                    return False
            
            # Parse original code
            tree = ast.parse(original_code)
            
            # Find the function
            function_found = False
            start_line = None
            end_line = None
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef) and node.name == function_name:
                    start_line = node.lineno - 1  # 0-indexed
                    end_line = node.end_lineno
                    function_found = True
                    break
            
            if not function_found:
                self.logger.error(f"Function {function_name} not found in {filepath}")
                return False
            
            # Replace function
            lines = original_code.split('\n')
            new_lines = lines[:start_line] + [new_code] + lines[end_line:]
            modified_code = '\n'.join(new_lines)
            
            # Validate modified code
            is_valid, error = validate_python_code(modified_code)
            if not is_valid:
                self.logger.error(f"Modified code is invalid: {error}")
                return False
            
            # Write modified code
            with open(filepath, 'w') as f:
                f.write(modified_code)
            
            # Log modification
            self._log_modification(filepath, function_name, "function_modify")
            
            self.logger.info(f"Successfully modified function {function_name} in {filepath}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error modifying function: {e}")
            return False
    
    def add_function(self, filepath: Path, function_code: str, 
                    position: str = 'end', backup: bool = True) -> bool:
        """
        Add a new function to a file
        
        Args:
            filepath: Path to Python file
            function_code: Code for new function
            position: Where to add ('start', 'end', or after specific function)
            backup: Whether to create backup
        
        Returns:
            True if addition successful
        """
        try:
            # Validate function code
            is_valid, error = validate_python_code(function_code)
            if not is_valid:
                self.logger.error(f"Invalid function code: {error}")
                return False
            
            # Read current code
            with open(filepath, 'r') as f:
                original_code = f.read()
            
            # Create backup if requested
            if backup:
                backup_path = self.backup_file(filepath)
                if not backup_path:
                    return False
            
            # Add function
            if position == 'end':
                modified_code = original_code + '\n\n' + function_code
            elif position == 'start':
                modified_code = function_code + '\n\n' + original_code
            else:
                # TODO: Add after specific function
                modified_code = original_code + '\n\n' + function_code
            
            # Validate modified code
            is_valid, error = validate_python_code(modified_code)
            if not is_valid:
                self.logger.error(f"Modified code is invalid: {error}")
                return False
            
            # Write modified code
            with open(filepath, 'w') as f:
                f.write(modified_code)
            
            # Log modification
            self._log_modification(filepath, "new_function", "function_add")
            
            self.logger.info(f"Successfully added function to {filepath}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error adding function: {e}")
            return False
    
    def remove_function(self, filepath: Path, function_name: str, 
                       backup: bool = True) -> bool:
        """
        Remove a function from a file
        
        Args:
            filepath: Path to Python file
            function_name: Name of function to remove
            backup: Whether to create backup
        
        Returns:
            True if removal successful
        """
        try:
            # Read current code
            with open(filepath, 'r') as f:
                original_code = f.read()
            
            # Create backup if requested
            if backup:
                backup_path = self.backup_file(filepath)
                if not backup_path:
                    return False
            
            # Parse code
            tree = ast.parse(original_code)
            
            # Find the function
            function_found = False
            start_line = None
            end_line = None
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef) and node.name == function_name:
                    start_line = node.lineno - 1
                    end_line = node.end_lineno
                    function_found = True
                    break
            
            if not function_found:
                self.logger.error(f"Function {function_name} not found in {filepath}")
                return False
            
            # Remove function
            lines = original_code.split('\n')
            new_lines = lines[:start_line] + lines[end_line:]
            modified_code = '\n'.join(new_lines)
            
            # Validate modified code
            is_valid, error = validate_python_code(modified_code)
            if not is_valid:
                self.logger.error(f"Modified code is invalid: {error}")
                return False
            
            # Write modified code
            with open(filepath, 'w') as f:
                f.write(modified_code)
            
            # Log modification
            self._log_modification(filepath, function_name, "function_remove")
            
            self.logger.info(f"Successfully removed function {function_name} from {filepath}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error removing function: {e}")
            return False
    
    def modify_class(self, filepath: Path, class_name: str, 
                    modifications: Dict, backup: bool = True) -> bool:
        """
        Modify a class in a file
        
        Args:
            filepath: Path to Python file
            class_name: Name of class to modify
            modifications: Dict with modifications (add_methods, remove_methods, etc.)
            backup: Whether to create backup
        
        Returns:
            True if modification successful
        """
        try:
            # Read current code
            with open(filepath, 'r') as f:
                original_code = f.read()
            
            # Create backup if requested
            if backup:
                backup_path = self.backup_file(filepath)
                if not backup_path:
                    return False
            
            # For now, this is a placeholder for class modification
            # Full implementation would require more complex AST manipulation
            
            self.logger.warning("Class modification not fully implemented yet")
            return False
            
        except Exception as e:
            self.logger.error(f"Error modifying class: {e}")
            return False
    
    def restore_backup(self, backup_path: Path, target_path: Path = None) -> bool:
        """
        Restore a file from backup
        
        Args:
            backup_path: Path to backup file
            target_path: Optional target path (defaults to original location)
        
        Returns:
            True if restoration successful
        """
        try:
            if not backup_path.exists():
                self.logger.error(f"Backup file not found: {backup_path}")
                return False
            
            # Determine target path
            if not target_path:
                # Extract original filename from backup name
                original_name = backup_path.stem.rsplit('_', 1)[0] + backup_path.suffix
                target_path = BASE_DIR / "core" / original_name
            
            # Restore file
            shutil.copy2(backup_path, target_path)
            
            self.logger.info(f"Restored {target_path} from backup")
            return True
            
        except Exception as e:
            self.logger.error(f"Error restoring backup: {e}")
            return False
    
    def diff_files(self, file1: Path, file2: Path) -> List[str]:
        """
        Generate diff between two files
        
        Args:
            file1: First file path
            file2: Second file path
        
        Returns:
            List of diff lines
        """
        try:
            with open(file1, 'r') as f:
                lines1 = f.readlines()
            
            with open(file2, 'r') as f:
                lines2 = f.readlines()
            
            diff = list(difflib.unified_diff(
                lines1, lines2,
                fromfile=str(file1),
                tofile=str(file2),
                lineterm=''
            ))
            
            return diff
            
        except Exception as e:
            self.logger.error(f"Error generating diff: {e}")
            return []
    
    def _log_modification(self, filepath: Path, target: str, action: str):
        """Log a modification to the modification log"""
        try:
            with open(self.modification_log, 'a') as f:
                log_entry = f"{timestamp()} | {action} | {filepath} | {target}\n"
                f.write(log_entry)
        except Exception as e:
            self.logger.error(f"Error logging modification: {e}")
    
    def get_modification_history(self, limit: int = 20) -> List[Dict]:
        """Get recent modification history"""
        try:
            if not self.modification_log.exists():
                return []
            
            with open(self.modification_log, 'r') as f:
                lines = f.readlines()
            
            history = []
            for line in lines[-limit:]:
                parts = line.strip().split(' | ')
                if len(parts) == 4:
                    history.append({
                        'timestamp': parts[0],
                        'action': parts[1],
                        'filepath': parts[2],
                        'target': parts[3]
                    })
            
            return list(reversed(history))
            
        except Exception as e:
            self.logger.error(f"Error reading modification history: {e}")
            return []
    
    def list_backups(self) -> List[Dict]:
        """List all available backups"""
        backups = []
        
        for backup_file in self.backup_dir.glob('*.py'):
            backups.append({
                'filename': backup_file.name,
                'path': str(backup_file),
                'size': backup_file.stat().st_size,
                'modified': backup_file.stat().st_mtime
            })
        
        return sorted(backups, key=lambda x: x['modified'], reverse=True)
    
    def validate_modification(self, original_code: str, modified_code: str) -> Tuple[bool, Dict]:
        """
        Validate that a modification is safe
        
        Args:
            original_code: Original code
            modified_code: Modified code
        
        Returns:
            Tuple of (is_safe, details)
        """
        details = {
            'syntax_valid': False,
            'breaking_changes': [],
            'warnings': []
        }
        
        # Check syntax
        is_valid, error = validate_python_code(modified_code)
        details['syntax_valid'] = is_valid
        
        if not is_valid:
            details['breaking_changes'].append(f"Syntax error: {error}")
            return False, details
        
        # Parse both versions
        try:
            old_tree = ast.parse(original_code)
            new_tree = ast.parse(modified_code)
            
            # Check for removed functions/classes
            old_functions = {node.name for node in ast.walk(old_tree) if isinstance(node, ast.FunctionDef)}
            new_functions = {node.name for node in ast.walk(new_tree) if isinstance(node, ast.FunctionDef)}
            
            removed_functions = old_functions - new_functions
            if removed_functions:
                details['breaking_changes'].extend([f"Removed function: {f}" for f in removed_functions])
            
            # Check for signature changes
            # This is a simplified check
            for old_node in ast.walk(old_tree):
                if isinstance(old_node, ast.FunctionDef):
                    for new_node in ast.walk(new_tree):
                        if isinstance(new_node, ast.FunctionDef) and new_node.name == old_node.name:
                            old_args = len(old_node.args.args)
                            new_args = len(new_node.args.args)
                            if old_args != new_args:
                                details['warnings'].append(
                                    f"Function {old_node.name} signature changed: {old_args} -> {new_args} args"
                                )
            
        except Exception as e:
            details['warnings'].append(f"Could not fully validate: {e}")
        
        # Determine if safe
        is_safe = details['syntax_valid'] and len(details['breaking_changes']) == 0
        
        return is_safe, details
