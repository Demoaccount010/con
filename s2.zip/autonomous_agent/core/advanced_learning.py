"""
Advanced Learning System
Meta-learning, transfer learning, and pattern recognition
"""
import json
from typing import Dict, List, Optional, Tuple
from collections import defaultdict, Counter
from datetime import datetime, timedelta
import sqlite3
from pathlib import Path

try:
    from ..utils import setup_logger, timestamp
    from ..config import DATA_DIR
except ImportError:
    import sys
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from utils import setup_logger, timestamp
    from config import DATA_DIR

class AdvancedLearning:
    """
    Advanced learning capabilities including meta-learning and transfer learning
    """
    
    def __init__(self, db_path: Path = None):
        """Initialize Advanced Learning"""
        self.logger = setup_logger(self.__class__.__name__)
        self.db_path = db_path or DATA_DIR / "advanced_learning.db"
        self._initialize_db()
        self.pattern_cache = {}
        self.logger.info("Advanced Learning initialized")
    
    def _initialize_db(self):
        """Initialize database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Patterns table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS learned_patterns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                pattern_type TEXT NOT NULL,
                pattern_signature TEXT NOT NULL,
                pattern_data TEXT NOT NULL,
                success_count INTEGER DEFAULT 0,
                failure_count INTEGER DEFAULT 0,
                confidence REAL DEFAULT 0.5,
                first_seen TEXT NOT NULL,
                last_used TEXT,
                usage_count INTEGER DEFAULT 0
            )
        ''')
        
        # Transfer learning table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS transfer_knowledge (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_domain TEXT NOT NULL,
                target_domain TEXT NOT NULL,
                knowledge_type TEXT NOT NULL,
                knowledge_data TEXT NOT NULL,
                applicability_score REAL DEFAULT 0.0,
                created_at TEXT NOT NULL
            )
        ''')
        
        # Meta-learning table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS meta_learning (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                learning_strategy TEXT NOT NULL,
                context TEXT NOT NULL,
                effectiveness REAL DEFAULT 0.0,
                sample_size INTEGER DEFAULT 0,
                updated_at TEXT NOT NULL
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def detect_pattern(self, task_sequence: List[Dict]) -> List[Dict]:
        """
        Detect patterns in task sequences
        
        Args:
            task_sequence: List of task records
            
        Returns:
            List of detected patterns
        """
        if len(task_sequence) < 3:
            return []
        
        patterns = []
        
        # Sequential patterns (A → B → C)
        for i in range(len(task_sequence) - 2):
            seq = [
                task_sequence[i].get('type'),
                task_sequence[i+1].get('type'),
                task_sequence[i+2].get('type')
            ]
            
            if None not in seq:
                pattern_sig = " → ".join(seq)
                patterns.append({
                    'type': 'sequential',
                    'signature': pattern_sig,
                    'occurrences': 1,
                    'confidence': 0.6
                })
        
        # Repetitive patterns (A, A, A)
        task_types = [t.get('type') for t in task_sequence]
        task_counter = Counter(task_types)
        
        for task_type, count in task_counter.items():
            if count >= 3:
                patterns.append({
                    'type': 'repetitive',
                    'signature': f"repeat_{task_type}",
                    'occurrences': count,
                    'confidence': min(1.0, count / 5.0)
                })
        
        # Time-based patterns
        if len(task_sequence) >= 5:
            times = []
            for task in task_sequence:
                if 'timestamp' in task:
                    try:
                        dt = datetime.fromisoformat(task['timestamp'])
                        times.append(dt.hour)
                    except:
                        pass
            
            if times:
                time_counter = Counter(times)
                most_common_hour = time_counter.most_common(1)[0]
                if most_common_hour[1] >= 3:
                    patterns.append({
                        'type': 'temporal',
                        'signature': f"peak_hour_{most_common_hour[0]}",
                        'occurrences': most_common_hour[1],
                        'confidence': most_common_hour[1] / len(times)
                    })
        
        return patterns
    
    def store_pattern(self, pattern: Dict) -> int:
        """Store a learned pattern"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Check if pattern exists
        cursor.execute('''
            SELECT id, success_count, failure_count, usage_count
            FROM learned_patterns
            WHERE pattern_signature = ?
        ''', (pattern['signature'],))
        
        existing = cursor.fetchone()
        
        if existing:
            # Update existing
            pattern_id, success, failure, usage = existing
            cursor.execute('''
                UPDATE learned_patterns
                SET usage_count = usage_count + 1,
                    last_used = ?,
                    confidence = ?
                WHERE id = ?
            ''', (timestamp(), pattern.get('confidence', 0.5), pattern_id))
        else:
            # Insert new
            cursor.execute('''
                INSERT INTO learned_patterns
                (pattern_type, pattern_signature, pattern_data, confidence, first_seen)
                VALUES (?, ?, ?, ?, ?)
            ''', (
                pattern['type'],
                pattern['signature'],
                json.dumps(pattern),
                pattern.get('confidence', 0.5),
                timestamp()
            ))
            pattern_id = cursor.lastrowid
        
        conn.commit()
        conn.close()
        
        return pattern_id
    
    def get_applicable_patterns(self, current_context: Dict) -> List[Dict]:
        """
        Get patterns applicable to current context
        
        Args:
            current_context: Current situation
            
        Returns:
            List of applicable patterns
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get all patterns with good confidence
        cursor.execute('''
            SELECT pattern_type, pattern_signature, pattern_data, confidence, usage_count
            FROM learned_patterns
            WHERE confidence > 0.6
            ORDER BY confidence DESC, usage_count DESC
            LIMIT 10
        ''')
        
        patterns = []
        for row in cursor.fetchall():
            pattern_data = json.loads(row[2])
            patterns.append({
                'type': row[0],
                'signature': row[1],
                'data': pattern_data,
                'confidence': row[3],
                'usage_count': row[4]
            })
        
        conn.close()
        return patterns
    
    def transfer_knowledge(self, source_domain: str, target_domain: str,
                          knowledge: Dict) -> int:
        """
        Transfer knowledge from one domain to another
        
        Args:
            source_domain: Where knowledge comes from
            target_domain: Where to apply it
            knowledge: What to transfer
            
        Returns:
            Transfer ID
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Calculate applicability (simple heuristic)
        applicability = 0.5  # Base score
        
        # Boost if domains are related
        if source_domain in target_domain or target_domain in source_domain:
            applicability += 0.2
        
        cursor.execute('''
            INSERT INTO transfer_knowledge
            (source_domain, target_domain, knowledge_type, knowledge_data,
             applicability_score, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (
            source_domain,
            target_domain,
            knowledge.get('type', 'general'),
            json.dumps(knowledge),
            applicability,
            timestamp()
        ))
        
        transfer_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        self.logger.info(f"Transferred knowledge: {source_domain} → {target_domain}")
        return transfer_id
    
    def get_transferable_knowledge(self, target_domain: str, limit: int = 5) -> List[Dict]:
        """
        Get knowledge that can be transferred to target domain
        
        Args:
            target_domain: Domain to get knowledge for
            limit: Maximum results
            
        Returns:
            List of transferable knowledge
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT source_domain, knowledge_type, knowledge_data, applicability_score
            FROM transfer_knowledge
            WHERE target_domain = ? OR target_domain = 'general'
            ORDER BY applicability_score DESC
            LIMIT ?
        ''', (target_domain, limit))
        
        knowledge_items = []
        for row in cursor.fetchall():
            knowledge_items.append({
                'source': row[0],
                'type': row[1],
                'data': json.loads(row[2]),
                'applicability': row[3]
            })
        
        conn.close()
        return knowledge_items
    
    def update_learning_strategy(self, strategy: str, context: str,
                                effectiveness: float):
        """
        Update meta-learning about which strategies work
        
        Args:
            strategy: Learning strategy used
            context: Context it was used in
            effectiveness: How well it worked (0-1)
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Check if exists
        cursor.execute('''
            SELECT id, effectiveness, sample_size
            FROM meta_learning
            WHERE learning_strategy = ? AND context = ?
        ''', (strategy, context))
        
        existing = cursor.fetchone()
        
        if existing:
            # Update with running average
            meta_id, old_eff, sample_size = existing
            new_sample_size = sample_size + 1
            new_effectiveness = ((old_eff * sample_size) + effectiveness) / new_sample_size
            
            cursor.execute('''
                UPDATE meta_learning
                SET effectiveness = ?, sample_size = ?, updated_at = ?
                WHERE id = ?
            ''', (new_effectiveness, new_sample_size, timestamp(), meta_id))
        else:
            # Insert new
            cursor.execute('''
                INSERT INTO meta_learning
                (learning_strategy, context, effectiveness, sample_size, updated_at)
                VALUES (?, ?, ?, 1, ?)
            ''', (strategy, context, effectiveness, timestamp()))
        
        conn.commit()
        conn.close()
    
    def get_best_strategy(self, context: str) -> Optional[str]:
        """
        Get the best learning strategy for a context
        
        Args:
            context: Current context
            
        Returns:
            Best strategy name or None
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT learning_strategy, effectiveness
            FROM meta_learning
            WHERE context = ? AND sample_size >= 3
            ORDER BY effectiveness DESC
            LIMIT 1
        ''', (context,))
        
        result = cursor.fetchone()
        conn.close()
        
        if result:
            return result[0]
        return None
    
    def generalize_from_examples(self, examples: List[Dict]) -> Dict:
        """
        Generalize a concept from examples
        
        Args:
            examples: List of example instances
            
        Returns:
            Generalized concept
        """
        if not examples:
            return {}
        
        # Extract common features
        all_features = defaultdict(list)
        
        for example in examples:
            for key, value in example.items():
                all_features[key].append(value)
        
        # Find consensus
        concept = {}
        for feature, values in all_features.items():
            # Count occurrences
            value_counter = Counter(values)
            most_common = value_counter.most_common(1)[0]
            
            # If >50% agreement, include in concept
            if most_common[1] / len(values) > 0.5:
                concept[feature] = most_common[0]
        
        return {
            'concept': concept,
            'confidence': len(concept) / len(all_features) if all_features else 0,
            'sample_size': len(examples)
        }
    
    def predict_next_action(self, recent_actions: List[str]) -> Tuple[str, float]:
        """
        Predict next likely action based on patterns
        
        Args:
            recent_actions: Recent action sequence
            
        Returns:
            (predicted_action, confidence)
        """
        if len(recent_actions) < 2:
            return ("unknown", 0.0)
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Look for sequential patterns that match recent actions
        recent_sig = " → ".join(recent_actions[-2:])
        
        cursor.execute('''
            SELECT pattern_signature, confidence
            FROM learned_patterns
            WHERE pattern_type = 'sequential'
            AND pattern_signature LIKE ?
            ORDER BY confidence DESC, usage_count DESC
            LIMIT 1
        ''', (f"{recent_sig} → %",))
        
        result = cursor.fetchone()
        conn.close()
        
        if result:
            # Extract next action from pattern
            full_pattern = result[0]
            parts = full_pattern.split(" → ")
            if len(parts) > len(recent_actions):
                next_action = parts[len(recent_actions)]
                return (next_action, result[1])
        
        return ("unknown", 0.0)
    
    def get_statistics(self) -> Dict:
        """Get advanced learning statistics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Count patterns
        cursor.execute('SELECT COUNT(*) FROM learned_patterns')
        total_patterns = cursor.fetchone()[0]
        
        # Average confidence
        cursor.execute('SELECT AVG(confidence) FROM learned_patterns')
        avg_confidence = cursor.fetchone()[0] or 0.0
        
        # Transfer knowledge count
        cursor.execute('SELECT COUNT(*) FROM transfer_knowledge')
        transfer_count = cursor.fetchone()[0]
        
        # Meta-learning strategies
        cursor.execute('SELECT COUNT(*) FROM meta_learning')
        strategy_count = cursor.fetchone()[0]
        
        conn.close()
        
        return {
            'total_patterns': total_patterns,
            'average_confidence': round(avg_confidence, 3),
            'transfer_knowledge_items': transfer_count,
            'meta_strategies': strategy_count
        }
