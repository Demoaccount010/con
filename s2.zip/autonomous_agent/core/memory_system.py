"""
Memory System - Multi-tier memory management (Short-term, Long-term, Episodic)
"""
import json
import sqlite3
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from pathlib import Path
import pickle

try:
    from ..utils import setup_logger, timestamp, hash_content, calculate_similarity
    from ..config import (
        DATA_DIR, 
        SHORT_TERM_MEMORY_SIZE, 
        LONG_TERM_MEMORY_THRESHOLD,
        EPISODIC_MEMORY_RETENTION_DAYS
    )
except ImportError:
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from utils import setup_logger, timestamp, hash_content, calculate_similarity
    from config import (
        DATA_DIR, 
        SHORT_TERM_MEMORY_SIZE, 
        LONG_TERM_MEMORY_THRESHOLD,
        EPISODIC_MEMORY_RETENTION_DAYS
    )

class MemorySystem:
    """
    Multi-tier memory system for the agent
    - Short-term: Recent interactions (last N items)
    - Long-term: Important information (high relevance)
    - Episodic: Conversation history with temporal context
    """
    
    def __init__(self, db_path: Path = None):
        """Initialize Memory System"""
        self.logger = setup_logger(self.__class__.__name__)
        self.db_path = db_path or DATA_DIR / "memory.db"
        self._initialize_db()
        self.short_term = []  # In-memory cache
        
        # NEW: Initialize vector memory
        try:
            from .vector_memory import VectorMemory
            self.vector_memory = VectorMemory()
            self.use_vector_search = self.vector_memory.available
            if self.use_vector_search:
                self.logger.info("Vector memory enabled")
        except Exception as e:
            self.logger.warning(f"Vector memory not available: {e}")
            self.vector_memory = None
            self.use_vector_search = False
        
        self.logger.info("Memory System initialized")
    
    def _initialize_db(self):
        """Initialize database for memory storage"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Short-term memory table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS short_term_memory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                memory_type TEXT NOT NULL,
                content TEXT NOT NULL,
                metadata TEXT,
                access_count INTEGER DEFAULT 0,
                last_accessed TEXT
            )
        ''')
        
        # Long-term memory table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS long_term_memory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                memory_type TEXT NOT NULL,
                content TEXT NOT NULL,
                importance REAL NOT NULL,
                tags TEXT,
                metadata TEXT,
                access_count INTEGER DEFAULT 0,
                last_accessed TEXT,
                content_hash TEXT UNIQUE
            )
        ''')
        
        # Episodic memory table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS episodic_memory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                episode_type TEXT NOT NULL,
                user_input TEXT,
                agent_response TEXT,
                intent TEXT,
                outcome TEXT,
                emotions TEXT,
                context TEXT,
                duration_ms INTEGER
            )
        ''')
        
        # Memory associations table (for linking related memories)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS memory_associations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_id INTEGER NOT NULL,
                target_id INTEGER NOT NULL,
                association_type TEXT NOT NULL,
                strength REAL DEFAULT 1.0,
                timestamp TEXT NOT NULL
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def store_short_term(self, content: str, memory_type: str = "general", metadata: Dict = None) -> int:
        """
        Store information in short-term memory
        
        Args:
            content: The content to store
            memory_type: Type of memory (interaction, observation, thought, etc.)
            metadata: Additional metadata
        
        Returns:
            Memory ID
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO short_term_memory (timestamp, memory_type, content, metadata, last_accessed)
            VALUES (?, ?, ?, ?, ?)
        ''', (timestamp(), memory_type, content, json.dumps(metadata or {}), timestamp()))
        
        memory_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        # Add to in-memory cache
        self.short_term.append({
            'id': memory_id,
            'timestamp': timestamp(),
            'type': memory_type,
            'content': content,
            'metadata': metadata or {}
        })
        
        # Keep only recent items in cache
        if len(self.short_term) > SHORT_TERM_MEMORY_SIZE:
            self.short_term.pop(0)
        
        self.logger.debug(f"Stored short-term memory: {content[:50]}...")
        return memory_id
    
    def store_long_term(self, content: str, importance: float, 
                       memory_type: str = "knowledge", tags: List[str] = None,
                       metadata: Dict = None) -> Optional[int]:
        """
        Store information in long-term memory
        
        Args:
            content: The content to store
            importance: Importance score (0.0 to 1.0)
            memory_type: Type of memory
            tags: List of tags for categorization
            metadata: Additional metadata
        
        Returns:
            Memory ID or None if duplicate
        """
        content_hash = hash_content(content)
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO long_term_memory 
                (timestamp, memory_type, content, importance, tags, metadata, last_accessed, content_hash)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                timestamp(), 
                memory_type, 
                content, 
                importance,
                json.dumps(tags or []),
                json.dumps(metadata or {}),
                timestamp(),
                content_hash
            ))
            
            memory_id = cursor.lastrowid
            conn.commit()
            self.logger.info(f"Stored long-term memory (importance: {importance:.2f})")
            return memory_id
            
        except sqlite3.IntegrityError:
            # Duplicate content
            self.logger.debug("Duplicate content, not storing")
            return None
        finally:
            conn.close()
    
    def store_episode(self, user_input: str, agent_response: str, 
                     intent: str, outcome: str = "success",
                     duration_ms: int = 0, emotions: Dict = None,
                     context: Dict = None) -> int:
        """
        Store an episodic memory (interaction event)
        
        Args:
            user_input: User's input
            agent_response: Agent's response
            intent: Detected intent
            outcome: Outcome of interaction (success, failure, partial)
            duration_ms: Duration in milliseconds
            emotions: Emotional context
            context: Additional context
        
        Returns:
            Episode ID
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO episodic_memory 
            (timestamp, episode_type, user_input, agent_response, intent, 
             outcome, emotions, context, duration_ms)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            timestamp(),
            'interaction',
            user_input,
            agent_response,
            intent,
            outcome,
            json.dumps(emotions or {}),
            json.dumps(context or {}),
            duration_ms
        ))
        
        episode_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        # NEW: Also store in vector DB
        if self.use_vector_search:
            try:
                metadata = {
                    'intent': intent,
                    'outcome': outcome,
                    'duration_ms': duration_ms
                }
                if emotions:
                    metadata['emotions'] = emotions
                if context:
                    metadata['context'] = context
                
                self.vector_memory.store_conversation(
                    user_input=user_input,
                    agent_response=agent_response,
                    metadata=metadata
                )
            except Exception as e:
                self.logger.error(f"Error storing in vector memory: {e}")
        
        self.logger.debug(f"Stored episode: {intent} -> {outcome}")
        return episode_id
    
    def recall_short_term(self, limit: int = None) -> List[Dict]:
        """Recall recent short-term memories"""
        limit = limit or SHORT_TERM_MEMORY_SIZE
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, timestamp, memory_type, content, metadata, access_count
            FROM short_term_memory
            ORDER BY id DESC
            LIMIT ?
        ''', (limit,))
        
        memories = []
        for row in cursor.fetchall():
            memories.append({
                'id': row[0],
                'timestamp': row[1],
                'type': row[2],
                'content': row[3],
                'metadata': json.loads(row[4]) if row[4] else {},
                'access_count': row[5]
            })
            
            # Update access count
            cursor.execute('''
                UPDATE short_term_memory 
                SET access_count = access_count + 1, last_accessed = ?
                WHERE id = ?
            ''', (timestamp(), row[0]))
        
        conn.commit()
        conn.close()
        
        return memories
    
    def recall_long_term(self, query: str = None, tags: List[str] = None, 
                        min_importance: float = 0.0, limit: int = 10) -> List[Dict]:
        """
        Recall long-term memories based on query, tags, or importance
        
        Args:
            query: Search query (uses simple text matching)
            tags: Filter by tags
            min_importance: Minimum importance threshold
            limit: Maximum number of results
        
        Returns:
            List of matching memories
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        sql = '''
            SELECT id, timestamp, memory_type, content, importance, tags, metadata, access_count
            FROM long_term_memory
            WHERE importance >= ?
        '''
        params = [min_importance]
        
        if query:
            sql += ' AND content LIKE ?'
            params.append(f'%{query}%')
        
        sql += ' ORDER BY importance DESC, access_count DESC LIMIT ?'
        params.append(limit)
        
        cursor.execute(sql, params)
        
        memories = []
        for row in cursor.fetchall():
            memory_tags = json.loads(row[5]) if row[5] else []
            
            # Filter by tags if specified
            if tags and not any(tag in memory_tags for tag in tags):
                continue
            
            memories.append({
                'id': row[0],
                'timestamp': row[1],
                'type': row[2],
                'content': row[3],
                'importance': row[4],
                'tags': memory_tags,
                'metadata': json.loads(row[6]) if row[6] else {},
                'access_count': row[7]
            })
            
            # Update access count
            cursor.execute('''
                UPDATE long_term_memory 
                SET access_count = access_count + 1, last_accessed = ?
                WHERE id = ?
            ''', (timestamp(), row[0]))
        
        conn.commit()
        conn.close()
        
        self.logger.debug(f"Recalled {len(memories)} long-term memories")
        return memories
    
    def recall_episodes(self, intent: str = None, outcome: str = None,
                       days_back: int = 7, limit: int = 20) -> List[Dict]:
        """
        Recall episodic memories (past interactions)
        
        Args:
            intent: Filter by intent
            outcome: Filter by outcome
            days_back: How many days back to search
            limit: Maximum number of results
        
        Returns:
            List of episodes
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cutoff_date = (datetime.now() - timedelta(days=days_back)).isoformat()
        
        sql = '''
            SELECT id, timestamp, episode_type, user_input, agent_response, 
                   intent, outcome, emotions, context, duration_ms
            FROM episodic_memory
            WHERE timestamp >= ?
        '''
        params = [cutoff_date]
        
        if intent:
            sql += ' AND intent = ?'
            params.append(intent)
        
        if outcome:
            sql += ' AND outcome = ?'
            params.append(outcome)
        
        sql += ' ORDER BY timestamp DESC LIMIT ?'
        params.append(limit)
        
        cursor.execute(sql, params)
        
        episodes = []
        for row in cursor.fetchall():
            episodes.append({
                'id': row[0],
                'timestamp': row[1],
                'type': row[2],
                'user_input': row[3],
                'agent_response': row[4],
                'intent': row[5],
                'outcome': row[6],
                'emotions': json.loads(row[7]) if row[7] else {},
                'context': json.loads(row[8]) if row[8] else {},
                'duration_ms': row[9]
            })
        
        conn.close()
        
        self.logger.debug(f"Recalled {len(episodes)} episodes")
        return episodes
    
    def consolidate_memories(self):
        """
        Consolidate memories: promote important short-term to long-term
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Find frequently accessed short-term memories
        cursor.execute('''
            SELECT id, content, memory_type, metadata, access_count
            FROM short_term_memory
            WHERE access_count >= 3
            ORDER BY access_count DESC
        ''')
        
        promoted = 0
        for row in cursor.fetchall():
            memory_id, content, memory_type, metadata_str, access_count = row
            
            # Calculate importance based on access count
            importance = min(1.0, access_count / 10.0)
            
            if importance >= LONG_TERM_MEMORY_THRESHOLD:
                metadata = json.loads(metadata_str) if metadata_str else {}
                
                # Promote to long-term
                result = self.store_long_term(
                    content=content,
                    importance=importance,
                    memory_type=memory_type,
                    tags=['promoted'],
                    metadata=metadata
                )
                
                if result:
                    promoted += 1
                    # Remove from short-term
                    cursor.execute('DELETE FROM short_term_memory WHERE id = ?', (memory_id,))
        
        conn.commit()
        conn.close()
        
        if promoted > 0:
            self.logger.info(f"Promoted {promoted} memories to long-term storage")
        
        return promoted
    
    def cleanup_old_memories(self):
        """Remove old episodic memories beyond retention period"""
        cutoff_date = (datetime.now() - timedelta(days=EPISODIC_MEMORY_RETENTION_DAYS)).isoformat()
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            DELETE FROM episodic_memory
            WHERE timestamp < ?
        ''', (cutoff_date,))
        
        deleted = cursor.rowcount
        conn.commit()
        conn.close()
        
        if deleted > 0:
            self.logger.info(f"Cleaned up {deleted} old episodic memories")
        
        return deleted
    
    def get_statistics(self) -> Dict:
        """Get memory system statistics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Count memories
        cursor.execute('SELECT COUNT(*) FROM short_term_memory')
        short_term_count = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(*) FROM long_term_memory')
        long_term_count = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(*) FROM episodic_memory')
        episodic_count = cursor.fetchone()[0]
        
        # Average importance
        cursor.execute('SELECT AVG(importance) FROM long_term_memory')
        avg_importance = cursor.fetchone()[0] or 0.0
        
        # Most accessed long-term memory
        cursor.execute('''
            SELECT content, access_count 
            FROM long_term_memory 
            ORDER BY access_count DESC 
            LIMIT 1
        ''')
        most_accessed = cursor.fetchone()
        
        conn.close()
        
        return {
            'short_term_count': short_term_count,
            'long_term_count': long_term_count,
            'episodic_count': episodic_count,
            'average_importance': round(avg_importance, 3),
            'most_accessed': {
                'content': most_accessed[0][:100] if most_accessed else None,
                'count': most_accessed[1] if most_accessed else 0
            }
        }
    
    def search_similar(self, query: str, top_k: int = 5) -> List[Dict]:
        """
        Search for similar memories using simple text similarity
        
        Args:
            query: Search query
            top_k: Number of results to return
        
        Returns:
            List of similar memories with similarity scores
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get all long-term memories
        cursor.execute('SELECT id, content, importance FROM long_term_memory')
        
        similarities = []
        for row in cursor.fetchall():
            memory_id, content, importance = row
            similarity = calculate_similarity(query, content)
            
            if similarity > 0.1:  # Minimum threshold
                similarities.append({
                    'id': memory_id,
                    'content': content,
                    'importance': importance,
                    'similarity': similarity,
                    'score': similarity * importance  # Combined score
                })
        
        conn.close()
        
        # Sort by combined score
        similarities.sort(key=lambda x: x['score'], reverse=True)
        
        return similarities[:top_k]
    
    def semantic_search(self, query: str, memory_type: str = "all", top_k: int = 5) -> List[Dict]:
        """
        Semantic search across all memories using vector embeddings
        
        Args:
            query: Search query
            memory_type: Type of memory to search
            top_k: Number of results
            
        Returns:
            List of relevant memories
        """
        if not self.use_vector_search:
            # Fallback to keyword search
            self.logger.debug("Using fallback keyword search")
            return self.search_similar(query, top_k)
        
        return self.vector_memory.semantic_search(query, memory_type, top_k)
