"""
Skill Generator - Dynamically creates new Python functions/skills
"""
import ast
import inspect
import importlib
import sys
from typing import Dict, List, Optional, Callable
from pathlib import Path
import textwrap

try:
    from ..utils import setup_logger, timestamp, validate_python_code, sanitize_filename
    from ..config import SKILLS_DIR, SKILL_TEST_TIMEOUT
except ImportError:
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from utils import setup_logger, timestamp, validate_python_code, sanitize_filename
    from config import SKILLS_DIR, SKILL_TEST_TIMEOUT

class SkillGenerator:
    """
    Generates and manages dynamic Python skills/functions
    """
    
    def __init__(self, ollama_brain=None, github_token=None):
        """Initialize Skill Generator"""
        self.logger = setup_logger(self.__class__.__name__)
        self.generated_skills = {}
        self.skill_templates = self._load_templates()
        self.ollama_brain = ollama_brain
        self.github_token = github_token
        self.github_learner = None
        
        # Initialize GitHub learner if available
        try:
            import sys
            from pathlib import Path
            sys.path.insert(0, str(Path(__file__).parent.parent))
            from skills.github_learner import GitHubLearner
            self.github_learner = GitHubLearner(github_token=github_token, ollama_brain=ollama_brain)
            self.logger.info("GitHub learner initialized")
        except Exception as e:
            self.logger.warning(f"GitHub learner not available: {e}")
        
        self.logger.info("Skill Generator initialized")
    
    def _load_templates(self) -> Dict[str, str]:
        """Load skill templates for common patterns"""
        return {
            'file_reader': '''
def read_file(filepath: str) -> str:
    """Read and return file contents"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        return f"Error reading file: {e}"
''',
            'file_writer': '''
def write_file(filepath: str, content: str) -> bool:
    """Write content to file"""
    try:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        return True
    except Exception as e:
        print(f"Error writing file: {e}")
        return False
''',
            'web_fetcher': '''
def fetch_url(url: str) -> str:
    """Fetch content from URL"""
    try:
        import requests
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        return response.text
    except Exception as e:
        return f"Error fetching URL: {e}"
''',
            'json_parser': '''
def parse_json(json_string: str) -> dict:
    """Parse JSON string to dictionary"""
    try:
        import json
        return json.loads(json_string)
    except Exception as e:
        return {"error": str(e)}
''',
            'data_processor': '''
def process_data(data: list, operation: str):
    """Process data with specified operation"""
    try:
        if operation == "sum":
            return sum(data)
        elif operation == "average":
            return sum(data) / len(data) if data else 0
        elif operation == "max":
            return max(data) if data else None
        elif operation == "min":
            return min(data) if data else None
        else:
            return data
    except Exception as e:
        return f"Error processing data: {e}"
'''
        }
    
    def generate_from_description(self, description: str, function_name: str = None,
                                  parameters: List[str] = None) -> Optional[Dict]:
        """
        Generate a skill from natural language description
        
        Args:
            description: Natural language description of what the skill should do
            function_name: Optional custom function name
            parameters: Optional list of parameter names
        
        Returns:
            Dict with skill info or None if generation failed
        """
        self.logger.info(f"Generating skill from description: {description[:50]}...")
        
        # Generate function name if not provided
        if not function_name:
            function_name = self._generate_function_name(description)
        
        # Check if we have a matching template
        template = self._find_matching_template(description)
        
        if template:
            code = template
            self.logger.info(f"Using template for skill: {function_name}")
        else:
            # Generate custom code
            code = self._generate_custom_code(description, function_name, parameters or [])
        
        # Validate the generated code
        is_valid, error = validate_python_code(code)
        if not is_valid:
            self.logger.error(f"Generated invalid code: {error}")
            return None
        
        # Create skill info
        skill_info = {
            'name': function_name,
            'code': code,
            'description': description,
            'parameters': parameters or self._extract_parameters(code),
            'timestamp': timestamp(),
            'source': 'template' if template else 'generated'
        }
        
        return skill_info
    
    def _generate_function_name(self, description: str) -> str:
        """Generate a valid Python function name from description"""
        # Extract key words
        words = description.lower().split()
        
        # Remove common words
        stop_words = {'the', 'a', 'an', 'to', 'from', 'for', 'with', 'and', 'or'}
        key_words = [w for w in words[:5] if w.isalnum() and w not in stop_words]
        
        # Create function name
        if key_words:
            name = '_'.join(key_words[:3])
        else:
            name = 'custom_function'
        
        # Ensure it's a valid Python identifier
        name = ''.join(c if c.isalnum() or c == '_' else '_' for c in name)
        if name[0].isdigit():
            name = 'func_' + name
        
        return name
    
    def _find_matching_template(self, description: str) -> Optional[str]:
        """Find a matching template for the description"""
        desc_lower = description.lower()
        
        if 'read' in desc_lower and 'file' in desc_lower:
            return self.skill_templates['file_reader']
        elif 'write' in desc_lower and 'file' in desc_lower:
            return self.skill_templates['file_writer']
        elif 'fetch' in desc_lower or 'get' in desc_lower and 'url' in desc_lower:
            return self.skill_templates['web_fetcher']
        elif 'parse' in desc_lower and 'json' in desc_lower:
            return self.skill_templates['json_parser']
        elif 'process' in desc_lower or 'calculate' in desc_lower:
            return self.skill_templates['data_processor']
        
        return None
    
    def _generate_custom_code(self, description: str, function_name: str,
                             parameters: List[str]) -> str:
        """Generate custom Python code for the skill"""
        # Create parameter signature
        params = ', '.join(parameters) if parameters else '*args, **kwargs'
        
        # Generate basic function structure
        code = f'''
def {function_name}({params}):
    """
    {description}
    
    Auto-generated function.
    """
    try:
        # TODO: Implement the actual logic
        # This is a placeholder implementation
        result = f"Executing {function_name} with parameters"
        return result
    except Exception as e:
        return f"Error in {function_name}: {{e}}"
'''
        return textwrap.dedent(code).strip()
    
    def _extract_parameters(self, code: str) -> List[str]:
        """Extract parameter names from function code"""
        try:
            tree = ast.parse(code)
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    return [arg.arg for arg in node.args.args]
        except:
            pass
        return []
    
    def compile_skill(self, skill_info: Dict) -> Optional[Callable]:
        """
        Compile skill code into executable function
        
        Args:
            skill_info: Skill information dictionary
        
        Returns:
            Compiled function or None if compilation failed
        """
        try:
            # Create a namespace for execution
            namespace = {}
            
            # Execute the code to define the function
            exec(skill_info['code'], namespace)
            
            # Get the function object
            function_name = skill_info['name']
            if function_name in namespace:
                func = namespace[function_name]
                
                # Store in generated skills
                self.generated_skills[function_name] = {
                    'function': func,
                    'info': skill_info
                }
                
                self.logger.info(f"Successfully compiled skill: {function_name}")
                return func
            else:
                self.logger.error(f"Function {function_name} not found in namespace")
                return None
                
        except Exception as e:
            self.logger.error(f"Error compiling skill: {e}")
            return None
    
    def test_skill(self, function_name: str, test_inputs: List[tuple]) -> Dict:
        """
        Test a generated skill with sample inputs
        
        Args:
            function_name: Name of the function to test
            test_inputs: List of tuples containing test arguments
        
        Returns:
            Dict with test results
        """
        if function_name not in self.generated_skills:
            return {'error': 'Skill not found'}
        
        func = self.generated_skills[function_name]['function']
        results = []
        
        for i, inputs in enumerate(test_inputs):
            try:
                if isinstance(inputs, tuple):
                    result = func(*inputs)
                else:
                    result = func(inputs)
                
                results.append({
                    'test': i + 1,
                    'inputs': inputs,
                    'output': result,
                    'success': True
                })
            except Exception as e:
                results.append({
                    'test': i + 1,
                    'inputs': inputs,
                    'error': str(e),
                    'success': False
                })
        
        # Calculate success rate
        success_count = sum(1 for r in results if r.get('success'))
        success_rate = success_count / len(results) if results else 0
        
        return {
            'function_name': function_name,
            'total_tests': len(results),
            'passed': success_count,
            'success_rate': success_rate,
            'results': results
        }
    
    def save_skill(self, function_name: str, filepath: Path = None) -> bool:
        """
        Save skill to file
        
        Args:
            function_name: Name of skill to save
            filepath: Optional custom filepath
        
        Returns:
            True if saved successfully
        """
        if function_name not in self.generated_skills:
            self.logger.error(f"Skill {function_name} not found")
            return False
        
        skill_info = self.generated_skills[function_name]['info']
        
        # Generate filepath if not provided
        if not filepath:
            filename = sanitize_filename(f"{function_name}.py")
            filepath = SKILLS_DIR / filename
        
        try:
            with open(filepath, 'w') as f:
                f.write(f"# Skill: {function_name}\n")
                f.write(f"# Description: {skill_info['description']}\n")
                f.write(f"# Generated: {skill_info['timestamp']}\n\n")
                f.write(skill_info['code'])
            
            self.logger.info(f"Saved skill to {filepath}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error saving skill: {e}")
            return False
    
    def load_skill(self, filepath: Path) -> Optional[str]:
        """
        Load skill from file
        
        Args:
            filepath: Path to skill file
        
        Returns:
            Function name if loaded successfully
        """
        try:
            with open(filepath, 'r') as f:
                code = f.read()
            
            # Extract function name
            tree = ast.parse(code)
            function_name = None
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    function_name = node.name
                    break
            
            if not function_name:
                self.logger.error("No function definition found in file")
                return None
            
            # Create skill info
            skill_info = {
                'name': function_name,
                'code': code,
                'description': f"Loaded from {filepath.name}",
                'parameters': self._extract_parameters(code),
                'timestamp': timestamp(),
                'source': 'file'
            }
            
            # Compile the skill
            func = self.compile_skill(skill_info)
            
            if func:
                self.logger.info(f"Loaded skill: {function_name}")
                return function_name
            else:
                return None
                
        except Exception as e:
            self.logger.error(f"Error loading skill: {e}")
            return None
    
    def get_skill(self, function_name: str) -> Optional[Callable]:
        """Get a compiled skill function"""
        if function_name in self.generated_skills:
            return self.generated_skills[function_name]['function']
        return None
    
    def list_skills(self) -> List[Dict]:
        """List all generated skills"""
        return [
            {
                'name': name,
                'description': info['info']['description'],
                'parameters': info['info']['parameters'],
                'source': info['info']['source']
            }
            for name, info in self.generated_skills.items()
        ]
    
    def remove_skill(self, function_name: str) -> bool:
        """Remove a skill from memory"""
        if function_name in self.generated_skills:
            del self.generated_skills[function_name]
            self.logger.info(f"Removed skill: {function_name}")
            return True
        return False
    
    def generate_from_github_repo(self, repo_url: str, skill_name: str) -> Optional[Dict]:
        """
        Generate a skill by learning from a GitHub repository
        
        Args:
            repo_url: GitHub repository URL
            skill_name: Name for the new skill
        
        Returns:
            Dict with skill info or None if generation failed
        """
        if not self.github_learner:
            self.logger.error("GitHub learner not available")
            return None
        
        self.logger.info(f"Learning from GitHub repo: {repo_url}")
        
        try:
            # Use GitHub learner to create skill
            result = self.github_learner.create_skill_from_repo(repo_url, skill_name)
            
            if result.get('success'):
                skill_info = {
                    'name': result['skill_name'],
                    'code': result['skill_code'],
                    'description': result.get('explanation', 'Generated from GitHub'),
                    'parameters': [],
                    'timestamp': timestamp(),
                    'source': 'github',
                    'repository': result.get('repository'),
                    'analysis': result.get('analysis')
                }
                
                self.logger.info(f"Successfully generated skill from GitHub: {skill_name}")
                return skill_info
            else:
                self.logger.error(f"Failed to generate skill from GitHub: {result.get('error')}")
                return None
        
        except Exception as e:
            self.logger.error(f"Error generating skill from GitHub: {e}")
            return None
    
    def search_github_repos(self, query: str, limit: int = 10) -> List[Dict]:
        """
        Search GitHub repositories
        
        Args:
            query: Search query
            limit: Number of results
        
        Returns:
            List of repository information
        """
        if not self.github_learner:
            self.logger.error("GitHub learner not available")
            return []
        
        try:
            result = self.github_learner.search_repos(query, limit)
            
            if result.get('success'):
                return result['repos']
            else:
                self.logger.error(f"GitHub search failed: {result.get('error')}")
                return []
        
        except Exception as e:
            self.logger.error(f"Error searching GitHub: {e}")
            return []
    
    def generate_with_ollama(self, description: str, function_name: str = None) -> Optional[Dict]:
        """
        Generate skill using Ollama brain for better code generation
        
        Args:
            description: Description of what the skill should do
            function_name: Optional function name
        
        Returns:
            Dict with skill info or None if generation failed
        """
        if not self.ollama_brain or not self.ollama_brain.enabled:
            # Fallback to basic generation
            return self.generate_from_description(description, function_name)
        
        try:
            if not function_name:
                function_name = self._generate_function_name(description)
            
            self.logger.info(f"Generating skill with Ollama: {function_name}")
            
            # Use Ollama to generate code
            code_result = self.ollama_brain.generate_code(
                f"Create a Python function named '{function_name}' that: {description}",
                language="python"
            )
            
            if code_result['success']:
                skill_info = {
                    'name': function_name,
                    'code': code_result['code'],
                    'description': description,
                    'parameters': self._extract_parameters(code_result['code']),
                    'timestamp': timestamp(),
                    'source': 'ollama',
                    'explanation': code_result['explanation']
                }
                
                self.logger.info(f"Successfully generated skill with Ollama: {function_name}")
                return skill_info
            else:
                self.logger.warning("Ollama generation failed, falling back to template")
                return self.generate_from_description(description, function_name)
        
        except Exception as e:
            self.logger.error(f"Error generating with Ollama: {e}")
            return self.generate_from_description(description, function_name)
