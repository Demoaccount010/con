"""
Intent Detector - Understands and classifies user intentions
"""
import json
import re
from typing import Dict, List, Tuple, Optional
from datetime import datetime
import sqlite3
from pathlib import Path

try:
    from ..utils import setup_logger, timestamp
    from ..config import DATA_DIR, INTENT_CONFIDENCE_THRESHOLD
except ImportError:
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from utils import setup_logger, timestamp
    from config import DATA_DIR, INTENT_CONFIDENCE_THRESHOLD

class IntentDetector:
    """
    Detects and classifies user intents from natural language
    """
    
    # Intent categories
    INTENT_CATEGORIES = {
        'create': ['create', 'make', 'build', 'generate', 'write', 'add', 'new'],
        'read': ['read', 'show', 'display', 'get', 'fetch', 'list', 'view', 'what', 'tell'],
        'update': ['update', 'modify', 'change', 'edit', 'fix', 'improve', 'refactor'],
        'delete': ['delete', 'remove', 'clear', 'drop', 'erase'],
        'execute': ['run', 'execute', 'start', 'launch', 'do', 'perform'],
        'learn': ['learn', 'remember', 'train', 'teach', 'memorize', 'study'],
        'search': ['search', 'find', 'look', 'query', 'locate'],
        'analyze': ['analyze', 'check', 'test', 'evaluate', 'assess', 'review'],
        'help': ['help', 'how', 'explain', 'describe', 'guide', 'tutorial']
    }
    
    # Entity patterns
    ENTITY_PATTERNS = {
        'file': r'(?:file|document|script|code)\s+["\']?([^\s"\']+)["\']?',
        'function': r'(?:function|method|def)\s+([a-zA-Z_][a-zA-Z0-9_]*)',
        'url': r'https?://[^\s]+',
        'path': r'(?:path|directory|folder)\s+["\']?([^\s"\']+)["\']?',
        'variable': r'(?:variable|var)\s+([a-zA-Z_][a-zA-Z0-9_]*)',
        'skill': r'(?:skill|ability|capability)\s+["\']?([^\s"\']+)["\']?',
    }
    
    def __init__(self, db_path: Path = None, ollama_brain=None):
        """Initialize Intent Detector"""
        self.logger = setup_logger(self.__class__.__name__)
        self.db_path = db_path or DATA_DIR / "intents.db"
        self.ollama_brain = ollama_brain
        self._initialize_db()
        
        # Try to import langdetect for language detection
        try:
            import langdetect
            self.langdetect = langdetect
            self.lang_detect_available = True
        except ImportError:
            self.lang_detect_available = False
            self.logger.warning("langdetect not available, using fallback")
        
        self.logger.info("Intent Detector initialized")
    
    def _initialize_db(self):
        """Initialize database for intent storage"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS intent_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                user_input TEXT NOT NULL,
                detected_intent TEXT NOT NULL,
                confidence REAL NOT NULL,
                entities TEXT,
                metadata TEXT
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS intent_patterns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                pattern TEXT NOT NULL,
                intent TEXT NOT NULL,
                confidence_boost REAL DEFAULT 0.1,
                usage_count INTEGER DEFAULT 0
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def detect(self, user_input: str, context: Dict = None) -> Dict:
        """
        Detect intent from user input with optional Ollama brain assistance
        
        Args:
            user_input: Natural language input from user
            context: Optional context information
        
        Returns:
            Dict with intent, confidence, entities, and metadata
        """
        self.logger.info(f"Detecting intent for: {user_input[:50]}...")
        
        # Try using Ollama brain for better understanding
        if self.ollama_brain and self.ollama_brain.enabled:
            try:
                brain_result = self.ollama_brain.understand_intent(
                    user_input, 
                    conversation_history=context.get('conversation_history') if context else None
                )
                
                if brain_result.get('success'):
                    # Detect language
                    language = self.detect_language(user_input)
                    
                    # Extract entities with brain help
                    entities = brain_result.get('entities', {})
                    
                    result = {
                        'intent': brain_result.get('intent', 'unknown'),
                        'confidence': brain_result.get('confidence', 0.5),
                        'entities': entities,
                        'original_input': user_input,
                        'timestamp': timestamp(),
                        'requires_permission': self._requires_permission(brain_result.get('intent', 'unknown')),
                        'language': language,
                        'sentiment': brain_result.get('sentiment', 'neutral'),
                        'ambiguities': brain_result.get('ambiguities', []),
                        'metadata': {
                            'source': 'ollama',
                            'has_context': context is not None
                        }
                    }
                    
                    # Store in history
                    self._store_intent(result)
                    
                    self.logger.info(f"Detected intent with Ollama: {result['intent']} (confidence: {result['confidence']:.2f})")
                    return result
            except Exception as e:
                self.logger.warning(f"Ollama detection failed, using fallback: {e}")
        
        # Fallback to basic detection
        # Normalize input
        normalized = user_input.lower().strip()
        
        # Detect language
        language = self.detect_language(user_input)
        
        # Detect intent category
        intent, confidence = self._detect_intent_category(normalized)
        
        # Extract entities
        entities = self._extract_entities(user_input)
        
        # Apply context if available
        if context:
            confidence = self._apply_context(intent, confidence, context)
        
        # Check for learned patterns
        pattern_boost = self._check_learned_patterns(normalized)
        confidence = min(1.0, confidence + pattern_boost)
        
        result = {
            'intent': intent,
            'confidence': confidence,
            'entities': entities,
            'original_input': user_input,
            'timestamp': timestamp(),
            'requires_permission': self._requires_permission(intent),
            'language': language,
            'metadata': {
                'source': 'basic',
                'pattern_boost': pattern_boost,
                'has_context': context is not None
            }
        }
        
        # Store in history
        self._store_intent(result)
        
        self.logger.info(f"Detected intent: {intent} (confidence: {confidence:.2f})")
        return result
    
    def _detect_intent_category(self, text: str) -> Tuple[str, float]:
        """Detect primary intent category"""
        scores = {}
        
        for intent, keywords in self.INTENT_CATEGORIES.items():
            score = 0
            for keyword in keywords:
                if keyword in text:
                    # Word boundary match for better accuracy
                    if re.search(rf'\b{keyword}\b', text):
                        score += 1.0
                    else:
                        score += 0.5
            
            if score > 0:
                # Normalize by number of keywords
                scores[intent] = score / len(keywords)
        
        if not scores:
            return 'unknown', 0.3
        
        # Get highest scoring intent
        best_intent = max(scores.items(), key=lambda x: x[1])
        return best_intent[0], min(1.0, best_intent[1])
    
    def _extract_entities(self, text: str) -> Dict[str, List[str]]:
        """Extract entities from text"""
        entities = {}
        
        for entity_type, pattern in self.ENTITY_PATTERNS.items():
            matches = re.findall(pattern, text, re.IGNORECASE)
            if matches:
                entities[entity_type] = matches if isinstance(matches, list) else [matches]
        
        # Extract quoted strings
        quoted = re.findall(r'["\']([^"\']+)["\']', text)
        if quoted:
            entities['quoted'] = quoted
        
        # Extract numbers
        numbers = re.findall(r'\b\d+(?:\.\d+)?\b', text)
        if numbers:
            entities['numbers'] = numbers
        
        return entities
    
    def _apply_context(self, intent: str, confidence: float, context: Dict) -> float:
        """Apply contextual information to improve confidence"""
        boost = 0.0
        
        # If previous intent is similar, boost confidence
        if context.get('previous_intent') == intent:
            boost += 0.1
        
        # If context mentions related entities, boost confidence
        if context.get('entities'):
            boost += 0.05
        
        # If we're in a conversation flow, boost confidence
        if context.get('conversation_active'):
            boost += 0.05
        
        return min(1.0, confidence + boost)
    
    def _check_learned_patterns(self, text: str) -> float:
        """Check for learned patterns and return confidence boost"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT confidence_boost FROM intent_patterns
            WHERE ? LIKE '%' || pattern || '%'
            ORDER BY usage_count DESC
            LIMIT 1
        ''', (text,))
        
        result = cursor.fetchone()
        conn.close()
        
        return result[0] if result else 0.0
    
    def _requires_permission(self, intent: str) -> bool:
        """Check if intent requires user permission"""
        risky_intents = ['delete', 'execute', 'update', 'create']
        return intent in risky_intents
    
    def _store_intent(self, result: Dict):
        """Store detected intent in history"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO intent_history 
            (timestamp, user_input, detected_intent, confidence, entities, metadata)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (
            result['timestamp'],
            result['original_input'],
            result['intent'],
            result['confidence'],
            json.dumps(result['entities']),
            json.dumps(result['metadata'])
        ))
        
        conn.commit()
        conn.close()
    
    def learn_pattern(self, pattern: str, intent: str, confidence_boost: float = 0.1):
        """Learn a new intent pattern"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO intent_patterns (pattern, intent, confidence_boost)
            VALUES (?, ?, ?)
        ''', (pattern, intent, confidence_boost))
        
        conn.commit()
        conn.close()
        
        self.logger.info(f"Learned new pattern: {pattern} -> {intent}")
    
    def get_history(self, limit: int = 10) -> List[Dict]:
        """Get recent intent detection history"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT timestamp, user_input, detected_intent, confidence, entities, metadata
            FROM intent_history
            ORDER BY id DESC
            LIMIT ?
        ''', (limit,))
        
        results = []
        for row in cursor.fetchall():
            results.append({
                'timestamp': row[0],
                'user_input': row[1],
                'intent': row[2],
                'confidence': row[3],
                'entities': json.loads(row[4]) if row[4] else {},
                'metadata': json.loads(row[5]) if row[5] else {}
            })
        
        conn.close()
        return results
    
    def detect_language(self, text: str) -> str:
        """
        Detect language (english, hindi, hinglish)
        
        Args:
            text: Input text
        
        Returns:
            Language code (english, hindi, hinglish)
        """
        if not self.lang_detect_available:
            # Simple fallback: check for Hindi characters
            hindi_chars = sum(1 for c in text if '\u0900' <= c <= '\u097F')
            if hindi_chars > len(text) * 0.3:
                return 'hindi'
            elif hindi_chars > 0:
                return 'hinglish'
            return 'english'
        
        try:
            detected = self.langdetect.detect(text)
            if detected == 'hi':
                # Check if it's mixed (Hinglish)
                english_words = sum(1 for c in text if c.isascii() and c.isalpha())
                if english_words > len(text) * 0.2:
                    return 'hinglish'
                return 'hindi'
            return 'english'
        except:
            return 'english'
    
    def detect_ambiguity(self, text: str, context: Dict = None) -> bool:
        """
        Detect if input is ambiguous
        
        Args:
            text: Input text
            context: Context information
        
        Returns:
            True if ambiguous
        """
        # Simple ambiguity detection
        ambiguous_words = ['it', 'that', 'this', 'there', 'something', 'file', 'thing']
        
        words = text.lower().split()
        ambiguous_count = sum(1 for word in words if word in ambiguous_words)
        
        # If more than 30% ambiguous words, it's likely ambiguous
        if len(words) > 0 and ambiguous_count / len(words) > 0.3:
            return True
        
        # Check if no entities extracted
        entities = self._extract_entities(text)
        if not entities and len(words) < 3:
            return True
        
        return False
    
    def generate_clarification_questions(self, text: str) -> List[str]:
        """
        Generate clarification questions for ambiguous input
        
        Args:
            text: Ambiguous input
        
        Returns:
            List of clarification questions
        """
        questions = []
        
        entities = self._extract_entities(text)
        
        # Check what's missing
        if 'file' in text.lower() and not entities.get('file'):
            questions.append("Which file do you want to work with?")
        
        if any(word in text.lower() for word in ['open', 'run', 'start']) and not entities:
            questions.append("What would you like me to open/run?")
        
        if 'create' in text.lower() and len(text.split()) < 4:
            questions.append("What would you like me to create?")
        
        if not questions:
            questions.append("Could you provide more details about what you'd like me to do?")
        
        return questions
    
    def understand_with_context(self, text: str, conversation_history: List[Dict]) -> Dict:
        """
        Understand input with conversation context
        
        Args:
            text: Current input
            conversation_history: Previous messages
        
        Returns:
            Enhanced understanding with context
        """
        # Use Ollama if available
        if self.ollama_brain and self.ollama_brain.enabled:
            return self.ollama_brain.understand_intent(text, conversation_history)
        
        # Basic context understanding
        context_entities = {}
        
        # Look for entities in recent history
        for msg in conversation_history[-3:]:
            if msg.get('entities'):
                for entity_type, values in msg['entities'].items():
                    if entity_type not in context_entities:
                        context_entities[entity_type] = values
        
        # Detect current intent
        result = self.detect(text)
        
        # Merge context entities
        for entity_type, values in context_entities.items():
            if entity_type not in result['entities']:
                result['entities'][entity_type] = values
        
        return result
    
    def detect_sentiment(self, text: str) -> Dict:
        """
        Detect sentiment of input
        
        Args:
            text: Input text
        
        Returns:
            Dict with sentiment info
        """
        # Simple rule-based sentiment
        positive_words = ['good', 'great', 'excellent', 'awesome', 'thanks', 'please', 'love']
        negative_words = ['bad', 'error', 'wrong', 'fail', 'problem', 'issue', 'hate']
        
        text_lower = text.lower()
        
        pos_count = sum(1 for word in positive_words if word in text_lower)
        neg_count = sum(1 for word in negative_words if word in text_lower)
        
        if pos_count > neg_count:
            sentiment = 'positive'
            score = min(1.0, pos_count / 3.0)
        elif neg_count > pos_count:
            sentiment = 'negative'
            score = min(1.0, neg_count / 3.0)
        else:
            sentiment = 'neutral'
            score = 0.5
        
        return {
            'sentiment': sentiment,
            'score': score,
            'positive_indicators': pos_count,
            'negative_indicators': neg_count
        }
    
    def get_statistics(self) -> Dict:
        """Get intent detection statistics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Total detections
        cursor.execute('SELECT COUNT(*) FROM intent_history')
        total = cursor.fetchone()[0]
        
        # Average confidence
        cursor.execute('SELECT AVG(confidence) FROM intent_history')
        avg_confidence = cursor.fetchone()[0] or 0.0
        
        # Intent distribution
        cursor.execute('''
            SELECT detected_intent, COUNT(*) as count
            FROM intent_history
            GROUP BY detected_intent
            ORDER BY count DESC
        ''')
        distribution = dict(cursor.fetchall())
        
        # Learned patterns
        cursor.execute('SELECT COUNT(*) FROM intent_patterns')
        learned_patterns = cursor.fetchone()[0]
        
        conn.close()
        
        return {
            'total_detections': total,
            'average_confidence': round(avg_confidence, 3),
            'intent_distribution': distribution,
            'learned_patterns': learned_patterns
        }
