"""
Permission Manager - Handles user permissions and approvals for risky operations
"""
import json
import sqlite3
from typing import Dict, List, Optional, Callable
from pathlib import Path
from enum import Enum

try:
    from ..utils import setup_logger, timestamp
    from ..config import (
        DATA_DIR,
        REQUIRE_PERMISSION_FOR_FILE_OPS,
        REQUIRE_PERMISSION_FOR_NETWORK,
        REQUIRE_PERMISSION_FOR_SYSTEM,
        REQUIRE_PERMISSION_FOR_SELF_MODIFY,
        AUTO_APPROVE_SAFE_SKILLS
    )
except ImportError:
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from utils import setup_logger, timestamp
    from config import (
        DATA_DIR,
        REQUIRE_PERMISSION_FOR_FILE_OPS,
        REQUIRE_PERMISSION_FOR_NETWORK,
        REQUIRE_PERMISSION_FOR_SYSTEM,
        REQUIRE_PERMISSION_FOR_SELF_MODIFY,
        AUTO_APPROVE_SAFE_SKILLS
    )

class PermissionLevel(Enum):
    """Permission levels for operations"""
    SAFE = 1        # No permission needed
    LOW_RISK = 2    # Ask for permission
    MEDIUM_RISK = 3 # Ask with warning
    HIGH_RISK = 4   # Ask with strong warning
    CRITICAL = 5    # Require explicit confirmation

class PermissionManager:
    """
    Manages permissions and user approvals for agent operations
    """
    
    def __init__(self, db_path: Path = None):
        """Initialize Permission Manager"""
        self.logger = setup_logger(self.__class__.__name__)
        self.db_path = db_path or DATA_DIR / "permissions.db"
        self._initialize_db()
        self.pending_requests = {}
        self.approval_callback = None
        self.logger.info("Permission Manager initialized")
    
    def _initialize_db(self):
        """Initialize database for permission tracking"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Permission requests table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS permission_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                operation_type TEXT NOT NULL,
                operation_description TEXT NOT NULL,
                risk_level TEXT NOT NULL,
                status TEXT NOT NULL,
                user_response TEXT,
                response_time TEXT,
                metadata TEXT
            )
        ''')
        
        # Permission rules table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS permission_rules (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                rule_type TEXT NOT NULL,
                pattern TEXT NOT NULL,
                permission_level TEXT NOT NULL,
                auto_approve BOOLEAN DEFAULT 0,
                created_at TEXT NOT NULL
            )
        ''')
        
        # Trusted operations table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS trusted_operations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                operation_hash TEXT UNIQUE NOT NULL,
                operation_description TEXT NOT NULL,
                trust_level REAL DEFAULT 1.0,
                usage_count INTEGER DEFAULT 0,
                last_used TEXT
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def request_permission(self, operation_type: str, description: str,
                          risk_level: PermissionLevel = PermissionLevel.LOW_RISK,
                          metadata: Dict = None) -> Dict:
        """
        Request permission for an operation
        
        Args:
            operation_type: Type of operation (file, network, system, etc.)
            description: Human-readable description
            risk_level: Risk level of operation
            metadata: Additional metadata
        
        Returns:
            Dict with permission result
        """
        # Check if auto-approve rules exist
        if self._check_auto_approve(operation_type, description):
            self.logger.info(f"Auto-approved: {description}")
            return {
                'approved': True,
                'reason': 'auto_approved',
                'timestamp': timestamp()
            }
        
        # Check configuration settings
        if not self._requires_permission(operation_type):
            return {
                'approved': True,
                'reason': 'no_permission_required',
                'timestamp': timestamp()
            }
        
        # Store request
        request_id = self._store_request(operation_type, description, risk_level, metadata)
        
        # For now, we'll simulate user approval
        # In a real implementation, this would wait for actual user input
        approval = self._simulate_user_approval(operation_type, risk_level)
        
        # Update request with response
        self._update_request(request_id, approval)
        
        self.logger.info(f"Permission {'granted' if approval else 'denied'}: {description}")
        
        return {
            'approved': approval,
            'request_id': request_id,
            'reason': 'user_decision',
            'timestamp': timestamp()
        }
    
    def _requires_permission(self, operation_type: str) -> bool:
        """Check if operation type requires permission based on config"""
        permission_map = {
            'file': REQUIRE_PERMISSION_FOR_FILE_OPS,
            'network': REQUIRE_PERMISSION_FOR_NETWORK,
            'system': REQUIRE_PERMISSION_FOR_SYSTEM,
            'self_modify': REQUIRE_PERMISSION_FOR_SELF_MODIFY
        }
        return permission_map.get(operation_type, True)
    
    def _check_auto_approve(self, operation_type: str, description: str) -> bool:
        """Check if operation matches auto-approve rules"""
        if not AUTO_APPROVE_SAFE_SKILLS:
            return False
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT auto_approve FROM permission_rules
            WHERE rule_type = ? AND ? LIKE '%' || pattern || '%' AND auto_approve = 1
        ''', (operation_type, description))
        
        result = cursor.fetchone()
        conn.close()
        
        return bool(result)
    
    def _store_request(self, operation_type: str, description: str,
                      risk_level: PermissionLevel, metadata: Dict) -> int:
        """Store permission request in database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO permission_requests
            (timestamp, operation_type, operation_description, risk_level, status, metadata)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (
            timestamp(),
            operation_type,
            description,
            risk_level.name,
            'pending',
            json.dumps(metadata or {})
        ))
        
        request_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return request_id
    
    def _update_request(self, request_id: int, approved: bool):
        """Update permission request with user response"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            UPDATE permission_requests
            SET status = ?, user_response = ?, response_time = ?
            WHERE id = ?
        ''', (
            'approved' if approved else 'denied',
            'yes' if approved else 'no',
            timestamp(),
            request_id
        ))
        
        conn.commit()
        conn.close()
    
    def _simulate_user_approval(self, operation_type: str, 
                               risk_level: PermissionLevel) -> bool:
        """
        Simulate user approval (placeholder for actual user interaction)
        In production, this would present a UI prompt to the user
        """
        # For demonstration, approve safe and low-risk operations
        if risk_level in [PermissionLevel.SAFE, PermissionLevel.LOW_RISK]:
            return True
        
        # For higher risk, use more conservative approach
        return risk_level != PermissionLevel.CRITICAL
    
    def add_permission_rule(self, rule_type: str, pattern: str,
                           permission_level: PermissionLevel,
                           auto_approve: bool = False) -> int:
        """
        Add a permission rule
        
        Args:
            rule_type: Type of operation
            pattern: Pattern to match against
            permission_level: Required permission level
            auto_approve: Whether to auto-approve matching operations
        
        Returns:
            Rule ID
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO permission_rules
            (rule_type, pattern, permission_level, auto_approve, created_at)
            VALUES (?, ?, ?, ?, ?)
        ''', (
            rule_type,
            pattern,
            permission_level.name,
            1 if auto_approve else 0,
            timestamp()
        ))
        
        rule_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        self.logger.info(f"Added permission rule: {rule_type}/{pattern}")
        return rule_id
    
    def mark_as_trusted(self, operation_description: str, trust_level: float = 1.0):
        """Mark an operation as trusted"""
        try:
            from ..utils import hash_content
        except ImportError:
            from utils import hash_content
        
        operation_hash = hash_content(operation_description)
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO trusted_operations
                (operation_hash, operation_description, trust_level, usage_count, last_used)
                VALUES (?, ?, ?, 1, ?)
            ''', (operation_hash, operation_description, trust_level, timestamp()))
        except sqlite3.IntegrityError:
            # Already exists, update it
            cursor.execute('''
                UPDATE trusted_operations
                SET usage_count = usage_count + 1,
                    last_used = ?,
                    trust_level = MAX(trust_level, ?)
                WHERE operation_hash = ?
            ''', (timestamp(), trust_level, operation_hash))
        
        conn.commit()
        conn.close()
        
        self.logger.info(f"Marked as trusted: {operation_description[:50]}...")
    
    def is_trusted(self, operation_description: str, min_trust_level: float = 0.8) -> bool:
        """Check if an operation is trusted"""
        try:
            from ..utils import hash_content
        except ImportError:
            from utils import hash_content
        
        operation_hash = hash_content(operation_description)
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT trust_level FROM trusted_operations
            WHERE operation_hash = ?
        ''', (operation_hash,))
        
        result = cursor.fetchone()
        conn.close()
        
        if result and result[0] >= min_trust_level:
            return True
        return False
    
    def get_permission_history(self, limit: int = 20) -> List[Dict]:
        """Get recent permission requests"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT timestamp, operation_type, operation_description, 
                   risk_level, status, user_response
            FROM permission_requests
            ORDER BY id DESC
            LIMIT ?
        ''', (limit,))
        
        history = []
        for row in cursor.fetchall():
            history.append({
                'timestamp': row[0],
                'operation_type': row[1],
                'description': row[2],
                'risk_level': row[3],
                'status': row[4],
                'user_response': row[5]
            })
        
        conn.close()
        return history
    
    def get_statistics(self) -> Dict:
        """Get permission statistics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Total requests
        cursor.execute('SELECT COUNT(*) FROM permission_requests')
        total = cursor.fetchone()[0]
        
        # Approved/denied
        cursor.execute('''
            SELECT status, COUNT(*) 
            FROM permission_requests 
            GROUP BY status
        ''')
        status_counts = dict(cursor.fetchall())
        
        # By risk level
        cursor.execute('''
            SELECT risk_level, COUNT(*) 
            FROM permission_requests 
            GROUP BY risk_level
        ''')
        risk_counts = dict(cursor.fetchall())
        
        # Trusted operations
        cursor.execute('SELECT COUNT(*) FROM trusted_operations')
        trusted_count = cursor.fetchone()[0]
        
        conn.close()
        
        return {
            'total_requests': total,
            'approved': status_counts.get('approved', 0),
            'denied': status_counts.get('denied', 0),
            'pending': status_counts.get('pending', 0),
            'by_risk_level': risk_counts,
            'trusted_operations': trusted_count
        }
