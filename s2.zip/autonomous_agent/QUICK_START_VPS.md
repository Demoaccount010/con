# ⚡ Quick Start - VPS Connection (Ultra Simple)

## 5 Minutes में Setup करो! 🚀

---

## 📝 Prerequisites (पहले यह करो)

1. **2 VPS ready होने चाहिए:**
   - VPS 1 (Agent) - कोई भी, 2GB RAM
   - VPS 2 (Ollama) - Better specs, 8GB+ RAM

2. **Root access होना चाहिए दोनों में**

3. **दोनों VPS के IP addresses पता होने चाहिए**

---

## 🎯 Super Quick Setup (Direct Connection)

### **Step 1: VPS 2 में यह commands run करो**

```bash
# Login करो
ssh root@YOUR_VPS2_IP

# Copy-paste करो यह पूरा block:
curl -fsSL https://ollama.ai/install.sh | sh && \
sudo mkdir -p /etc/systemd/system/ollama.service.d/ && \
echo -e "[Service]\nEnvironment=\"OLLAMA_HOST=0.0.0.0:11434\"" | sudo tee /etc/systemd/system/ollama.service.d/override.conf && \
sudo systemctl daemon-reload && \
sudo systemctl restart ollama && \
ollama pull llama3 && \
echo "✅ VPS 2 Setup Complete!"
```

**Wait करो 5-10 minutes (model download होगा)**

---

### **Step 2: VPS 2 पर Firewall खोलो**

```bash
# VPS 1 का IP डालो यहाँ:
VPS1_IP="YOUR_VPS1_IP_HERE"

# Run करो:
sudo ufw allow from $VPS1_IP to any port 11434 && \
sudo ufw deny 11434 && \
echo "✅ Firewall Configured!"
```

---

### **Step 3: VPS 2 का IP note करो**

```bash
# यह IP note कर लो (example: 203.0.113.50)
curl ifconfig.me
```

---

### **Step 4: VPS 1 में यह commands run करो**

```bash
# Login करो
ssh root@YOUR_VPS1_IP

# Python और dependencies install करो
sudo apt update && \
sudo apt install -y python3 python3-pip git && \
echo "✅ Python Installed!"
```

---

### **Step 5: Agent code download करो**

```bash
# Directory बनाओ
cd /opt
git clone https://your-repo/autonomous_agent.git
cd autonomous_agent

# Dependencies install करो
pip3 install -r requirements.txt
```

---

### **Step 6: Configuration करो**

```bash
# VPS 2 का IP यहाँ डालो:
VPS2_IP="YOUR_VPS2_IP_HERE"

# .env file बनाओ
cat > .env <<EOF
OLLAMA_URL=http://$VPS2_IP:11434
OLLAMA_MODEL=llama3
ENABLE_OLLAMA=true
EOF

echo "✅ Configuration Done!"
```

---

### **Step 7: Test करो**

```bash
# Connection test
python3 test_remote_ollama.py

# अगर सब green ✅ दिखे, तो success!
```

---

### **Step 8: Agent start करो**

```bash
# Start करो
python3 main.py

# या background में:
nohup python3 main.py > logs/agent.log 2>&1 &
```

---

## ✅ Done! 🎉

Ab tumhara agent VPS 1 पर chal raha hai और Ollama VPS 2 से connected hai!

---

## 🔍 Quick Checks

### **VPS 2 पर check करो:**
```bash
# Ollama running hai?
systemctl status ollama

# Model download हुआ?
ollama list

# Port खुला है?
sudo netstat -tlnp | grep 11434
```

### **VPS 1 पर check करो:**
```bash
# VPS 2 accessible hai?
curl http://VPS2_IP:11434/api/tags

# Agent running hai?
ps aux | grep python | grep main.py
```

---

## 🐛 Problems?

### Connection नहीं हो रहा?
```bash
# VPS 1 से VPS 2 को ping करो
ping VPS2_IP

# Port check करो
telnet VPS2_IP 11434
```

### Firewall issue?
```bash
# VPS 2 पर temporarily सब traffic allow करो (testing)
sudo ufw allow 11434
```

### Ollama नहीं चल रहा?
```bash
# VPS 2 पर restart करो
sudo systemctl restart ollama
sudo journalctl -u ollama -f
```

---

## 💡 Pro Tips

### Auto-start agent on boot:
```bash
# VPS 1 पर crontab खोलो
crontab -e

# Add करो:
@reboot cd /opt/autonomous_agent && nohup python3 main.py > logs/agent.log 2>&1 &
```

### Monitor logs:
```bash
# Agent logs देखो
tail -f /opt/autonomous_agent/logs/agent.log

# Ollama logs देखो (VPS 2)
sudo journalctl -u ollama -f
```

### Stop agent:
```bash
pkill -f "python3 main.py"
```

---

## 🎯 One-Line Setup Commands

### **VPS 2 Complete Setup:**
```bash
curl -fsSL https://ollama.ai/install.sh | sh && sudo mkdir -p /etc/systemd/system/ollama.service.d/ && echo -e "[Service]\nEnvironment=\"OLLAMA_HOST=0.0.0.0:11434\"" | sudo tee /etc/systemd/system/ollama.service.d/override.conf && sudo systemctl daemon-reload && sudo systemctl restart ollama && ollama pull llama3
```

### **VPS 1 Test Connection:**
```bash
curl http://VPS2_IP:11434/api/tags && echo "✅ Connected!" || echo "❌ Failed!"
```

---

**Happy Coding! 🚀**

Koi problem ho to VPS_CONNECTION_GUIDE.md dekho (detailed guide hai).
