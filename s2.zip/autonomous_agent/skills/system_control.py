"""
System Control Skills - Browser, File, Process, System operations
Provides comprehensive system automation capabilities
"""
import os
import sys
import subprocess
import psutil
import platform
from pathlib import Path
from typing import Dict, List, Optional, Any
import webbrowser
import shutil

try:
    import pyautogui
    import pyperclip
    from PIL import ImageGrab
    AUTOMATION_AVAILABLE = True
except ImportError:
    AUTOMATION_AVAILABLE = False

try:
    from .base_skill import BaseSkill
except ImportError:
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from skills.base_skill import BaseSkill

# ============================================================================
# BROWSER CONTROL SKILLS
# ============================================================================

class BrowserSkill(BaseSkill):
    """Browser control operations"""
    
    def __init__(self):
        super().__init__(
            name="BrowserControl",
            description="Control web browsers",
            category="system"
        )
        self.browser_map = {
            'chrome': 'chrome',
            'firefox': 'firefox',
            'edge': 'msedge',
            'safari': 'safari'
        }
    
    def execute(self, action: str, **kwargs) -> Dict[str, Any]:
        """Execute browser action"""
        if action == 'open':
            return self.open_browser(kwargs.get('browser', 'chrome'))
        elif action == 'navigate':
            return self.navigate_to_url(kwargs.get('url'))
        elif action == 'close':
            return self.close_browser(kwargs.get('browser', 'chrome'))
        else:
            return {'error': f'Unknown action: {action}'}
    
    def open_browser(self, browser_name: str = "chrome") -> Dict:
        """Open a web browser"""
        try:
            browser_name = browser_name.lower()
            
            if platform.system() == 'Windows':
                if browser_name == 'chrome':
                    subprocess.Popen(['start', 'chrome'], shell=True)
                elif browser_name == 'firefox':
                    subprocess.Popen(['start', 'firefox'], shell=True)
                elif browser_name == 'edge':
                    subprocess.Popen(['start', 'msedge'], shell=True)
                else:
                    return {'success': False, 'error': f'Unknown browser: {browser_name}'}
            elif platform.system() == 'Darwin':  # macOS
                subprocess.Popen(['open', '-a', browser_name.capitalize()])
            else:  # Linux
                subprocess.Popen([browser_name])
            
            return {'success': True, 'message': f'{browser_name} opened'}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def navigate_to_url(self, url: str) -> Dict:
        """Open URL in default browser"""
        try:
            webbrowser.open(url)
            return {'success': True, 'message': f'Navigated to {url}'}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def close_browser(self, browser_name: str) -> Dict:
        """Close a browser (by killing process)"""
        try:
            browser_name = browser_name.lower()
            process_name = self.browser_map.get(browser_name, browser_name)
            
            killed = False
            for proc in psutil.process_iter(['name']):
                if process_name in proc.info['name'].lower():
                    proc.kill()
                    killed = True
            
            if killed:
                return {'success': True, 'message': f'{browser_name} closed'}
            else:
                return {'success': False, 'error': f'{browser_name} not running'}
        except Exception as e:
            return {'success': False, 'error': str(e)}

# ============================================================================
# FILE OPERATION SKILLS
# ============================================================================

class FileSkill(BaseSkill):
    """File operations"""
    
    def __init__(self):
        super().__init__(
            name="FileOperations",
            description="File system operations",
            category="file"
        )
    
    def execute(self, action: str, **kwargs) -> Dict[str, Any]:
        """Execute file action"""
        if action == 'read':
            return self.read_file(kwargs.get('file_path'))
        elif action == 'write':
            return self.write_file(kwargs.get('file_path'), kwargs.get('content'))
        elif action == 'delete':
            return self.delete_file(kwargs.get('file_path'))
        elif action == 'move':
            return self.move_file(kwargs.get('source'), kwargs.get('destination'))
        elif action == 'search':
            return self.search_files(kwargs.get('directory'), kwargs.get('pattern'))
        elif action == 'info':
            return self.get_file_info(kwargs.get('file_path'))
        else:
            return {'error': f'Unknown action: {action}'}
    
    def read_file(self, file_path: str) -> Dict:
        """Read file contents"""
        try:
            path = Path(file_path)
            if not path.exists():
                return {'success': False, 'error': 'File not found'}
            
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            return {
                'success': True,
                'content': content,
                'size': len(content),
                'path': str(path)
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def write_file(self, file_path: str, content: str) -> Dict:
        """Write content to file"""
        try:
            path = Path(file_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(path, 'w', encoding='utf-8') as f:
                f.write(content)
            
            return {
                'success': True,
                'message': f'Written to {file_path}',
                'size': len(content)
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def delete_file(self, file_path: str) -> Dict:
        """Delete a file"""
        try:
            path = Path(file_path)
            if not path.exists():
                return {'success': False, 'error': 'File not found'}
            
            path.unlink()
            return {'success': True, 'message': f'Deleted {file_path}'}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def move_file(self, source: str, destination: str) -> Dict:
        """Move/rename file"""
        try:
            src = Path(source)
            dst = Path(destination)
            
            if not src.exists():
                return {'success': False, 'error': 'Source file not found'}
            
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(src), str(dst))
            
            return {
                'success': True,
                'message': f'Moved {source} to {destination}'
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def search_files(self, directory: str, pattern: str) -> Dict:
        """Search for files matching pattern"""
        try:
            path = Path(directory)
            if not path.exists():
                return {'success': False, 'error': 'Directory not found'}
            
            matches = list(path.rglob(pattern))
            
            return {
                'success': True,
                'matches': [str(m) for m in matches],
                'count': len(matches)
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def get_file_info(self, file_path: str) -> Dict:
        """Get file information"""
        try:
            path = Path(file_path)
            if not path.exists():
                return {'success': False, 'error': 'File not found'}
            
            stat = path.stat()
            
            return {
                'success': True,
                'path': str(path),
                'name': path.name,
                'size': stat.st_size,
                'modified': stat.st_mtime,
                'is_file': path.is_file(),
                'is_dir': path.is_dir(),
                'extension': path.suffix
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}

# ============================================================================
# PROCESS CONTROL SKILLS
# ============================================================================

class ProcessSkill(BaseSkill):
    """Process management operations"""
    
    def __init__(self):
        super().__init__(
            name="ProcessControl",
            description="Manage system processes",
            category="system"
        )
    
    def execute(self, action: str, **kwargs) -> Dict[str, Any]:
        """Execute process action"""
        if action == 'list':
            return self.list_processes()
        elif action == 'kill':
            return self.kill_process(kwargs.get('process'))
        elif action == 'start':
            return self.start_application(kwargs.get('app'))
        elif action == 'info':
            return self.get_process_info(kwargs.get('process'))
        else:
            return {'error': f'Unknown action: {action}'}
    
    def list_processes(self) -> Dict:
        """List all running processes"""
        try:
            processes = []
            for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
                try:
                    processes.append({
                        'pid': proc.info['pid'],
                        'name': proc.info['name'],
                        'cpu': proc.info['cpu_percent'],
                        'memory': proc.info['memory_percent']
                    })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
            
            return {
                'success': True,
                'processes': processes,
                'count': len(processes)
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def kill_process(self, process_name_or_pid: str) -> Dict:
        """Kill a process by name or PID"""
        try:
            killed = False
            
            # Try as PID first
            try:
                pid = int(process_name_or_pid)
                proc = psutil.Process(pid)
                proc.kill()
                return {'success': True, 'message': f'Killed process {pid}'}
            except (ValueError, psutil.NoSuchProcess):
                pass
            
            # Try as name
            for proc in psutil.process_iter(['name', 'pid']):
                if process_name_or_pid.lower() in proc.info['name'].lower():
                    proc.kill()
                    killed = True
            
            if killed:
                return {'success': True, 'message': f'Killed {process_name_or_pid}'}
            else:
                return {'success': False, 'error': 'Process not found'}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def start_application(self, app_path_or_name: str) -> Dict:
        """Start an application"""
        try:
            if platform.system() == 'Windows':
                subprocess.Popen(['start', app_path_or_name], shell=True)
            elif platform.system() == 'Darwin':
                subprocess.Popen(['open', '-a', app_path_or_name])
            else:
                subprocess.Popen([app_path_or_name])
            
            return {'success': True, 'message': f'Started {app_path_or_name}'}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def get_process_info(self, process_name: str) -> Dict:
        """Get detailed process information"""
        try:
            for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent', 'status']):
                if process_name.lower() in proc.info['name'].lower():
                    return {
                        'success': True,
                        'pid': proc.info['pid'],
                        'name': proc.info['name'],
                        'cpu': proc.info['cpu_percent'],
                        'memory': proc.info['memory_percent'],
                        'status': proc.info['status']
                    }
            
            return {'success': False, 'error': 'Process not found'}
        except Exception as e:
            return {'success': False, 'error': str(e)}

# ============================================================================
# SYSTEM CONTROL SKILLS
# ============================================================================

class SystemSkill(BaseSkill):
    """System-level operations"""
    
    def __init__(self):
        super().__init__(
            name="SystemControl",
            description="System commands and monitoring",
            category="system"
        )
    
    def execute(self, action: str, **kwargs) -> Dict[str, Any]:
        """Execute system action"""
        if action == 'command':
            return self.execute_command(kwargs.get('command'), kwargs.get('shell', 'bash'))
        elif action == 'info':
            return self.get_system_info()
        elif action == 'monitor':
            return self.monitor_resources()
        elif action == 'env':
            return self.set_environment_variable(kwargs.get('key'), kwargs.get('value'))
        else:
            return {'error': f'Unknown action: {action}'}
    
    def execute_command(self, command: str, shell: str = "bash") -> Dict:
        """Execute a system command"""
        try:
            if platform.system() == 'Windows':
                result = subprocess.run(
                    command,
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=30
                )
            else:
                result = subprocess.run(
                    command,
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=30
                )
            
            return {
                'success': result.returncode == 0,
                'stdout': result.stdout,
                'stderr': result.stderr,
                'returncode': result.returncode
            }
        except subprocess.TimeoutExpired:
            return {'success': False, 'error': 'Command timed out'}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def get_system_info(self) -> Dict:
        """Get system information"""
        try:
            return {
                'success': True,
                'system': platform.system(),
                'release': platform.release(),
                'version': platform.version(),
                'machine': platform.machine(),
                'processor': platform.processor(),
                'cpu_count': psutil.cpu_count(),
                'memory_total': psutil.virtual_memory().total,
                'memory_available': psutil.virtual_memory().available,
                'disk_total': psutil.disk_usage('/').total,
                'disk_free': psutil.disk_usage('/').free
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def monitor_resources(self) -> Dict:
        """Monitor current system resource usage"""
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            
            return {
                'success': True,
                'cpu_percent': cpu_percent,
                'memory_percent': memory.percent,
                'memory_used': memory.used,
                'memory_available': memory.available,
                'disk_percent': disk.percent,
                'disk_used': disk.used,
                'disk_free': disk.free
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def set_environment_variable(self, key: str, value: str) -> Dict:
        """Set environment variable"""
        try:
            os.environ[key] = value
            return {'success': True, 'message': f'Set {key}={value}'}
        except Exception as e:
            return {'success': False, 'error': str(e)}

# ============================================================================
# AUTOMATION SKILLS (GUI)
# ============================================================================

class AutomationSkill(BaseSkill):
    """GUI automation (keyboard, mouse, screenshot)"""
    
    def __init__(self):
        super().__init__(
            name="GUIAutomation",
            description="Keyboard, mouse, and screenshot automation",
            category="automation"
        )
        self.available = AUTOMATION_AVAILABLE
    
    def execute(self, action: str, **kwargs) -> Dict[str, Any]:
        """Execute automation action"""
        if not self.available:
            return {'success': False, 'error': 'Automation libraries not available'}
        
        if action == 'screenshot':
            return self.take_screenshot(kwargs.get('save_path'))
        elif action == 'type':
            return self.type_text(kwargs.get('text'))
        elif action == 'click':
            return self.click_mouse(kwargs.get('x'), kwargs.get('y'))
        elif action == 'clipboard':
            return self.clipboard_operation(kwargs.get('operation'), kwargs.get('text'))
        else:
            return {'error': f'Unknown action: {action}'}
    
    def take_screenshot(self, save_path: str) -> Dict:
        """Take a screenshot"""
        try:
            screenshot = ImageGrab.grab()
            screenshot.save(save_path)
            return {'success': True, 'message': f'Screenshot saved to {save_path}'}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def type_text(self, text: str) -> Dict:
        """Type text using keyboard automation"""
        try:
            pyautogui.write(text)
            return {'success': True, 'message': f'Typed: {text}'}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def click_mouse(self, x: int, y: int) -> Dict:
        """Click mouse at coordinates"""
        try:
            pyautogui.click(x, y)
            return {'success': True, 'message': f'Clicked at ({x}, {y})'}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def clipboard_operation(self, operation: str, text: str = None) -> Dict:
        """Clipboard operations (copy/paste)"""
        try:
            if operation == 'copy':
                pyperclip.copy(text)
                return {'success': True, 'message': 'Copied to clipboard'}
            elif operation == 'paste':
                content = pyperclip.paste()
                return {'success': True, 'content': content}
            else:
                return {'success': False, 'error': f'Unknown operation: {operation}'}
        except Exception as e:
            return {'success': False, 'error': str(e)}
