"""
Main entry point for the Autonomous Agent
Enhanced with Rich terminal UI
"""
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent))

from agent import AutonomousAgent

# Try to import rich for better UI
try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.progress import Progress, SpinnerColumn, TextColumn
    from rich.table import Table
    from rich import print as rprint
    from rich.prompt import Prompt
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False
    print("Note: Install 'rich' for better UI: pip install rich")

def print_header():
    """Print application header"""
    if RICH_AVAILABLE:
        console = Console()
        console.print("\n", style="bold")
        console.print(Panel.fit(
            "[bold cyan]🤖 AUTONOMOUS AI AGENT[/bold cyan]\n"
            "[yellow]With Self-Learning & System Control[/yellow]\n"
            "[dim]Version 2.0 Enhanced[/dim]",
            border_style="cyan"
        ))
    else:
        print("\n" + "="*60)
        print("  🤖 AUTONOMOUS AI AGENT")
        print("  With Self-Learning & System Control")
        print("  Version 2.0 Enhanced")
        print("="*60 + "\n")

def print_help():
    """Print help information"""
    if RICH_AVAILABLE:
        console = Console()
        help_text = """
## 🎯 Available Commands

### Basic Commands
- `help` - Show this help message
- `exit` or `quit` - Exit the agent
- `stats` - Show agent statistics
- `clear` - Clear screen

### Skills & Learning
- `create skill to [task]` - Generate new skill
- `show skills` - List all skills
- `learn [information]` - Store knowledge
- `search [query]` - Search memories

### System Control
- `open [browser/app]` - Open application
- `system info` - Show system information
- `list processes` - Show running processes
- `monitor resources` - Check CPU/RAM/Disk

### GitHub Learning
- `search github for [topic]` - Search repositories
- `learn from [repo URL]` - Create skill from repo

### Advanced
- `analyze performance` - Performance analysis
- `check health` - System health check
- `patterns` - Show detected patterns
"""
        console.print(Markdown(help_text))
    else:
        print("""
🎯 AVAILABLE COMMANDS:

Basic:
  help, exit, stats, clear

Skills & Learning:
  create skill to [task]
  show skills
  learn [information]
  search [query]

System Control:
  open [browser/app]
  system info
  list processes

GitHub:
  search github for [topic]
  learn from [repo URL]

Advanced:
  analyze performance
  check health
  patterns
""")

def print_thinking(message: str = "Thinking..."):
    """Show thinking indicator"""
    if RICH_AVAILABLE:
        console = Console()
        console.print(f"[dim cyan]💭 {message}[/dim cyan]")
    else:
        print(f"💭 {message}")

def print_response(response: Dict):
    """Print agent response with rich formatting"""
    if not RICH_AVAILABLE:
        # Fallback to simple print
        status = "✅" if response.get('success') else "❌"
        print(f"\n{status} {response.get('message', 'No message')}\n")
        if response.get('data'):
            print(f"Data: {response['data']}\n")
        return
    
    console = Console()
    
    # Status
    status = "✅ Success" if response.get('success') else "❌ Failed"
    style = "green" if response.get('success') else "red"
    
    # Message
    message = response.get('message', 'No message')
    
    # Create panel
    console.print(Panel(
        f"[{style}]{status}[/{style}]\n\n{message}",
        border_style=style,
        padding=(1, 2)
    ))
    
    # Show data if present
    if response.get('data'):
        data = response['data']
        if isinstance(data, dict):
            table = Table(title="Response Data", show_header=True)
            table.add_column("Key", style="cyan")
            table.add_column("Value", style="yellow")
            
            for key, value in data.items():
                if isinstance(value, (dict, list)):
                    value_str = str(value)[:50] + "..."
                else:
                    value_str = str(value)
                table.add_row(key, value_str)
            
            console.print(table)
        elif isinstance(data, list) and len(data) > 0:
            console.print(f"\n[cyan]Items ({len(data)}):[/cyan]")
            for i, item in enumerate(data[:5], 1):  # Show first 5
                console.print(f"  {i}. {item}")
            if len(data) > 5:
                console.print(f"  ... and {len(data) - 5} more")
        else:
            console.print(f"\n[cyan]Data:[/cyan] {data}")
    
    # Show duration
    if response.get('duration_ms'):
        console.print(f"\n[dim]⏱️  Completed in {response['duration_ms']}ms[/dim]")

def print_stats(stats: Dict):
    """Print statistics table"""
    if not RICH_AVAILABLE:
        print("\n📊 AGENT STATISTICS:\n")
        for key, value in stats.items():
            print(f"  {key}: {value}")
        print()
        return
    
    console = Console()
    
    table = Table(title="🤖 Agent Statistics", show_header=True, header_style="bold cyan")
    table.add_column("Component", style="cyan")
    table.add_column("Metric", style="yellow")
    table.add_column("Value", style="green")
    
    # Add rows from stats
    for component, data in stats.items():
        if isinstance(data, dict):
            for metric, value in data.items():
                table.add_row(component, metric, str(value))
        else:
            table.add_row(component, "-", str(data))
    
    console.print(table)

def main():
    """Main function to run the agent"""
    # Print header
    print_header()
    
    # Show initialization
    if RICH_AVAILABLE:
        console = Console()
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("[cyan]Initializing agent...", total=None)
            agent = AutonomousAgent(name="Autonomous Agent")
            progress.update(task, completed=True)
        
        console.print("✅ [green]Agent initialized successfully![/green]\n")
    else:
        print("Initializing agent...")
        agent = AutonomousAgent(name="Autonomous Agent")
        print("✅ Agent initialized!\n")
    
    # Show features
    if RICH_AVAILABLE:
        console = Console()
        console.print("[dim]💡 Type 'help' for commands, 'exit' to quit[/dim]\n")
    else:
        print("💡 Type 'help' for commands, 'exit' to quit\n")
    
    # Main loop
    while True:
        try:
            # Get input
            if RICH_AVAILABLE:
                user_input = Prompt.ask("[bold cyan]You[/bold cyan]").strip()
            else:
                user_input = input("You: ").strip()
            
            if not user_input:
                continue
            
            # Check for special commands
            if user_input.lower() in ['exit', 'quit', 'bye']:
                if RICH_AVAILABLE:
                    console = Console()
                    console.print("\n[yellow]👋 Goodbye![/yellow]\n")
                else:
                    print("\n👋 Goodbye!\n")
                break
            
            elif user_input.lower() == 'help':
                print_help()
                continue
            
            elif user_input.lower() == 'clear':
                import os
                os.system('cls' if os.name == 'nt' else 'clear')
                print_header()
                continue
            
            elif user_input.lower() == 'stats':
                stats = agent.get_statistics()
                print_stats(stats)
                continue
            
            # Show thinking
            print_thinking()
            
            # Process input
            response = agent.process(user_input)
            
            # Show response
            print_response(response)
            
        except KeyboardInterrupt:
            if RICH_AVAILABLE:
                console = Console()
                console.print("\n[yellow]👋 Interrupted. Goodbye![/yellow]\n")
            else:
                print("\n👋 Interrupted. Goodbye!\n")
            break
        
        except Exception as e:
            if RICH_AVAILABLE:
                console = Console()
                console.print(f"\n[red]❌ Error: {e}[/red]\n")
            else:
                print(f"\n❌ Error: {e}\n")

if __name__ == "__main__":
    main()

