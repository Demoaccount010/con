"""
Basic Usage Examples for Autonomous Agent
"""
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from agent import AutonomousAgent

def example_1_basic_interaction():
    """Example 1: Basic interaction with the agent"""
    print("\n" + "="*60)
    print("EXAMPLE 1: Basic Interaction")
    print("="*60 + "\n")
    
    agent = AutonomousAgent(name="MyAgent")
    
    # Simple questions
    response = agent.process("Hello! What can you do?")
    print(f"User: Hello! What can you do?")
    print(f"Agent: {response['message']}\n")
    
    # Show statistics
    response = agent.process("Show me your statistics")
    print(f"User: Show me your statistics")
    print(f"Agent: {response['message']}")
    print(f"Data: {response['data']}\n")

def example_2_create_skill():
    """Example 2: Creating a new skill"""
    print("\n" + "="*60)
    print("EXAMPLE 2: Creating a New Skill")
    print("="*60 + "\n")
    
    agent = AutonomousAgent(name="MyAgent")
    
    # Create a skill
    response = agent.process("Create a skill to calculate the square of a number")
    print(f"User: Create a skill to calculate the square of a number")
    print(f"Agent: {response['message']}\n")
    
    # List skills
    response = agent.process("Show me all skills")
    print(f"User: Show me all skills")
    print(f"Agent: {response['message']}")
    if response['data']:
        for skill in response['data']:
            print(f"  - {skill['name']}: {skill['description']}")

def example_3_memory_system():
    """Example 3: Using the memory system"""
    print("\n" + "="*60)
    print("EXAMPLE 3: Memory System")
    print("="*60 + "\n")
    
    agent = AutonomousAgent(name="MyAgent")
    
    # Teach the agent
    response = agent.process("Learn that my favorite color is blue")
    print(f"User: Learn that my favorite color is blue")
    print(f"Agent: {response['message']}\n")
    
    response = agent.process("Learn that I work as a software developer")
    print(f"User: Learn that I work as a software developer")
    print(f"Agent: {response['message']}\n")
    
    # Search memory
    response = agent.process("Search for information about me")
    print(f"User: Search for information about me")
    print(f"Agent: {response['message']}")
    if response['data']:
        print(f"Found {len(response['data'])} relevant memories")

def example_4_learning_analysis():
    """Example 4: Performance analysis and learning"""
    print("\n" + "="*60)
    print("EXAMPLE 4: Performance Analysis")
    print("="*60 + "\n")
    
    agent = AutonomousAgent(name="MyAgent")
    
    # Generate some interactions
    agent.process("Create a skill to add two numbers")
    agent.process("Show me your skills")
    agent.process("Learn that Python is awesome")
    agent.process("Search for Python")
    
    # Analyze performance
    response = agent.process("Analyze your performance")
    print(f"User: Analyze your performance")
    print(f"Agent: {response['message']}")
    if response['data']:
        print(f"\nPerformance Details:")
        print(f"  Total Actions: {response['data'].get('total_actions', 0)}")
        print(f"  Success Rate: {response['data'].get('success_rate', 0):.1%}")
        print(f"  Outcomes: {response['data'].get('outcomes', {})}")

def example_5_statistics():
    """Example 5: Comprehensive statistics"""
    print("\n" + "="*60)
    print("EXAMPLE 5: Comprehensive Statistics")
    print("="*60 + "\n")
    
    agent = AutonomousAgent(name="MyAgent")
    
    # Generate some activity
    agent.process("Create a skill to multiply numbers")
    agent.process("Learn that the sky is blue")
    agent.process("Show me your skills")
    
    # Get all statistics
    stats = agent.get_statistics()
    
    print("Agent Statistics:\n")
    print(f"Agent Name: {stats['agent_name']}")
    print(f"Conversation Length: {stats['conversation_length']}\n")
    
    print("Intent Detector:")
    print(f"  Total Detections: {stats['intent_detector']['total_detections']}")
    print(f"  Average Confidence: {stats['intent_detector']['average_confidence']}\n")
    
    print("Memory System:")
    print(f"  Short-term Count: {stats['memory']['short_term_count']}")
    print(f"  Long-term Count: {stats['memory']['long_term_count']}")
    print(f"  Episodic Count: {stats['memory']['episodic_count']}\n")
    
    print("Skills:")
    print(f"  Total Skills: {stats['skills']['total_skills']}")
    print(f"  Active Skills: {stats['skills']['active_skills']}\n")
    
    print("Learning:")
    print(f"  Feedback Records: {stats['learning']['total_feedback_records']}")
    print(f"  Success Rate: {stats['learning']['overall_success_rate']:.1f}%\n")

def example_6_skill_execution():
    """Example 6: Creating and executing skills"""
    print("\n" + "="*60)
    print("EXAMPLE 6: Skill Creation and Execution")
    print("="*60 + "\n")
    
    agent = AutonomousAgent(name="MyAgent")
    
    # Create a skill
    print("Creating a data processing skill...")
    skill_info = agent.skill_generator.generate_from_description(
        "Process a list of numbers and return the sum",
        function_name="sum_numbers"
    )
    
    if skill_info:
        func = agent.skill_generator.compile_skill(skill_info)
        
        # Register it
        agent.skill_registry.register_skill(
            name=skill_info['name'],
            description=skill_info['description'],
            code=skill_info['code']
        )
        
        print(f"✓ Created skill: {skill_info['name']}")
        print(f"  Description: {skill_info['description']}\n")
        
        # Test the skill
        print("Testing the skill...")
        test_results = agent.skill_generator.test_skill('sum_numbers', [
            ([1, 2, 3],),
            ([10, 20, 30],),
        ])
        
        print(f"✓ Tests passed: {test_results['passed']}/{test_results['total_tests']}")
        print(f"  Success rate: {test_results['success_rate']:.1%}\n")

def main():
    """Run all examples"""
    print("\n" + "="*60)
    print("  AUTONOMOUS AGENT - USAGE EXAMPLES")
    print("="*60)
    
    try:
        example_1_basic_interaction()
        example_2_create_skill()
        example_3_memory_system()
        example_4_learning_analysis()
        example_5_statistics()
        example_6_skill_execution()
        
        print("\n" + "="*60)
        print("  All examples completed successfully!")
        print("="*60 + "\n")
        
    except Exception as e:
        print(f"\n❌ Error running examples: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
