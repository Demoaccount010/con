#!/bin/bash
# Setup script for Agent VPS
# VPS 1 (Agent Server) par ye script run karein

set -e

echo "========================================="
echo "  🤖 Agent VPS Setup Script"
echo "========================================="
echo ""

# Configuration
INSTALL_DIR="/opt/autonomous_agent"
OLLAMA_URL=""
OLLAMA_MODEL="llama3"

echo "Step 1: System Update"
echo "-----------------------------------"
sudo apt update
sudo apt upgrade -y
echo "✅ System updated"

echo ""
echo "Step 2: Installing Python & Dependencies"
echo "-----------------------------------"
sudo apt install -y python3 python3-pip python3-venv git
echo "✅ Python installed"

echo ""
echo "Step 3: Creating Installation Directory"
echo "-----------------------------------"
sudo mkdir -p $INSTALL_DIR
sudo chown $USER:$USER $INSTALL_DIR
echo "✅ Directory created: $INSTALL_DIR"

echo ""
echo "Step 4: Cloning/Copying Agent Code"
echo "-----------------------------------"
echo "📁 Copy your code to: $INSTALL_DIR"
echo "   Or clone from git repo"
read -p "Press Enter to continue..."

echo ""
echo "Step 5: Installing Dependencies"
echo "-----------------------------------"
cd $INSTALL_DIR
pip3 install -r requirements.txt
echo "✅ Dependencies installed"

echo ""
echo "Step 6: Configuration"
echo "-----------------------------------"
read -p "Enter Ollama Server URL (e.g., http://192.168.1.100:11434): " OLLAMA_URL
read -p "Enter Model name [llama3]: " MODEL_INPUT
OLLAMA_MODEL=${MODEL_INPUT:-llama3}

# Create .env file
cat > $INSTALL_DIR/.env <<EOF
OLLAMA_URL=$OLLAMA_URL
OLLAMA_MODEL=$OLLAMA_MODEL
ENABLE_OLLAMA=true
EOF

echo "✅ Configuration saved to .env"

echo ""
echo "Step 7: Testing Connection"
echo "-----------------------------------"
cd $INSTALL_DIR
python3 test_remote_ollama.py

echo ""
echo "========================================="
echo "  ✅ Agent Setup Complete!"
echo "========================================="
echo ""
echo "🚀 To start agent:"
echo "   cd $INSTALL_DIR"
echo "   python3 main.py"
echo ""
