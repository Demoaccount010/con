#!/bin/bash
# Setup script for Remote Ollama Server
# VPS 2 (Ollama Server) par ye script run karein

set -e

echo "========================================="
echo "  🚀 Remote Ollama Setup Script"
echo "========================================="
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "⚠️  Please run as root: sudo bash setup_remote_ollama.sh"
    exit 1
fi

# Configuration
OLLAMA_PORT=11434
ALLOWED_IP=""

echo "📋 Configuration:"
echo "   Port: $OLLAMA_PORT"
echo ""

# Ask for allowed IP
read -p "Enter VPS 1 (Agent) IP address to allow: " ALLOWED_IP

if [ -z "$ALLOWED_IP" ]; then
    echo "❌ IP address required!"
    exit 1
fi

echo ""
echo "Step 1: Installing Ollama..."
echo "-----------------------------------"

# Check if ollama already installed
if command -v ollama &> /dev/null; then
    echo "✅ Ollama already installed"
else
    echo "📥 Downloading and installing Ollama..."
    curl -fsSL https://ollama.ai/install.sh | sh
    echo "✅ Ollama installed"
fi

echo ""
echo "Step 2: Configuring Ollama to listen on 0.0.0.0..."
echo "-----------------------------------"

# Create systemd override directory
mkdir -p /etc/systemd/system/ollama.service.d/

# Create override configuration
cat > /etc/systemd/system/ollama.service.d/override.conf <<EOF
[Service]
Environment="OLLAMA_HOST=0.0.0.0:${OLLAMA_PORT}"
EOF

echo "✅ Configuration created"

# Reload systemd
echo "🔄 Reloading systemd..."
systemctl daemon-reload

# Restart ollama
echo "🔄 Restarting Ollama..."
systemctl restart ollama

# Enable ollama to start on boot
systemctl enable ollama

echo "✅ Ollama configured and restarted"

echo ""
echo "Step 3: Configuring Firewall..."
echo "-----------------------------------"

# Check if ufw is installed
if command -v ufw &> /dev/null; then
    echo "🔥 Configuring UFW firewall..."
    
    # Allow from specific IP
    ufw allow from $ALLOWED_IP to any port $OLLAMA_PORT proto tcp
    
    # Deny from everyone else
    ufw deny $OLLAMA_PORT/tcp
    
    echo "✅ Firewall configured"
    echo "   Allowed IP: $ALLOWED_IP"
    
    # Show firewall status
    ufw status numbered
    
elif command -v firewall-cmd &> /dev/null; then
    echo "🔥 Configuring firewalld..."
    
    # Add rich rule for specific IP
    firewall-cmd --permanent --add-rich-rule="rule family='ipv4' source address='$ALLOWED_IP' port protocol='tcp' port='$OLLAMA_PORT' accept"
    firewall-cmd --reload
    
    echo "✅ Firewall configured"
    echo "   Allowed IP: $ALLOWED_IP"
else
    echo "⚠️  No firewall detected (ufw or firewalld)"
    echo "   Please configure firewall manually!"
fi

echo ""
echo "Step 4: Downloading Models..."
echo "-----------------------------------"

echo "📥 Available models:"
echo "   1. llama3 (4.7GB) - Recommended, best quality"
echo "   2. mistral (4.1GB) - Fast and efficient"
echo "   3. phi (2.7GB) - Smaller, faster"
echo "   4. tinyllama (637MB) - Very fast, basic tasks"
echo ""

read -p "Which model to download? (1-4) [1]: " MODEL_CHOICE
MODEL_CHOICE=${MODEL_CHOICE:-1}

case $MODEL_CHOICE in
    1)
        MODEL="llama3"
        ;;
    2)
        MODEL="mistral"
        ;;
    3)
        MODEL="phi"
        ;;
    4)
        MODEL="tinyllama"
        ;;
    *)
        MODEL="llama3"
        ;;
esac

echo "📥 Downloading $MODEL..."
ollama pull $MODEL

echo "✅ Model downloaded: $MODEL"

# Download additional useful models
read -p "Download codellama for code tasks? (y/n) [y]: " DOWNLOAD_CODE
DOWNLOAD_CODE=${DOWNLOAD_CODE:-y}

if [ "$DOWNLOAD_CODE" = "y" ]; then
    echo "📥 Downloading codellama..."
    ollama pull codellama
    echo "✅ Codellama downloaded"
fi

echo ""
echo "Step 5: Testing Installation..."
echo "-----------------------------------"

# Test ollama
echo "🧪 Testing Ollama..."

if ollama list > /dev/null 2>&1; then
    echo "✅ Ollama is working"
    echo ""
    echo "📦 Installed models:"
    ollama list
else
    echo "❌ Ollama test failed"
    exit 1
fi

# Test API
echo ""
echo "🧪 Testing API endpoint..."

if curl -s http://localhost:$OLLAMA_PORT/api/tags > /dev/null; then
    echo "✅ API endpoint working"
else
    echo "❌ API endpoint not responding"
    exit 1
fi

echo ""
echo "========================================="
echo "  ✅ Setup Complete!"
echo "========================================="
echo ""
echo "📊 Summary:"
echo "   Ollama URL: http://$(hostname -I | awk '{print $1}'):$OLLAMA_PORT"
echo "   Allowed IP: $ALLOWED_IP"
echo "   Model(s): $(ollama list | tail -n +2 | awk '{print $1}' | tr '\n' ', ')"
echo ""
echo "🔧 Next steps on VPS 1 (Agent):"
echo "   1. Edit .env file:"
echo "      OLLAMA_URL=http://$(hostname -I | awk '{print $1}'):$OLLAMA_PORT"
echo "      OLLAMA_MODEL=$MODEL"
echo ""
echo "   2. Test connection:"
echo "      python test_remote_ollama.py"
echo ""
echo "   3. Start agent:"
echo "      python main.py"
echo ""
echo "💡 Useful commands:"
echo "   Check status: systemctl status ollama"
echo "   View logs: journalctl -u ollama -f"
echo "   List models: ollama list"
echo "   Remove model: ollama rm <model_name>"
echo ""
echo "🔒 Security recommendations:"
echo "   • Use VPN or SSH tunnel for production"
echo "   • Setup Nginx reverse proxy with SSL"
echo "   • Monitor with fail2ban"
echo "   • Regular security updates"
echo ""
