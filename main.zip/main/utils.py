import re
from config import REPLACE_TAG

MENTION = re.compile(r"@\w+")
EPISODE = re.compile(
    r"(episode|ep|e)\s*([0-9]{1,3})|s([0-9]{1,2})e([0-9]{1,3})",
    re.IGNORECASE
)

def clean_text(text: str | None):
    if not text:
        return text
    return MENTION.sub(REPLACE_TAG, text)

def detect_episode(text: str | None):
    if not text:
        return None
    m = EPISODE.search(text)
    if not m:
        return None
    if m.group(2):
        return f"EP{m.group(2)}"
    if m.group(3) and m.group(4):
        return f"S{m.group(3)}E{m.group(4)}"
    return None
