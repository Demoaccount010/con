from controller_bot import bot

print("🤖 Bot started")

bot.run_until_disconnected()
