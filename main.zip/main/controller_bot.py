import asyncio
from urllib.parse import urlparse, parse_qs

from telethon import TelegramClient, events

from config import API_ID, API_HASH, BOT_TOKEN, OWNER_ID
from storage import load_map, save_map
from logger import log

# 🔥 USERBOT FUNCTIONS
from user_worker import (
    start_worker,
    start_dm_watch_for,
    get_last_channel_message
)

# ---------------- BOT CLIENT ----------------
bot = TelegramClient(
    "controller_bot",
    API_ID,
    API_HASH
).start(bot_token=BOT_TOKEN)


# ---------------- HELPERS ----------------
def extract_bot_and_payload(msg):
    """
    Channel post se button ka bot username aur start payload nikalta hai
    """
    if not msg.buttons:
        return None, None

    for row in msg.buttons:
        for btn in row:
            if not btn.url:
                continue

            parsed = urlparse(btn.url)
            if parsed.netloc not in ("t.me", "telegram.me"):
                continue

            bot_username = parsed.path.strip("/")
            payload = parse_qs(parsed.query).get("start", [None])[0]
            return bot_username, payload

    return None, None


# ---------------- COMMAND HANDLER ----------------
@bot.on(events.NewMessage(from_users=OWNER_ID))
async def handler(event):
    text = (event.text or "").strip()

    # -------- START USERBOT --------
    if text == "/start_worker":
        asyncio.create_task(start_worker())
        await event.reply("Userbot starting...")
        return

    # -------- ADD MAP --------
    if text.startswith("/add_map"):
        parts = text.split()
        if len(parts) != 3:
            await event.reply("Usage: /add_map <source_id> <target_id>")
            return

        _, source, target = parts
        data = load_map()
        data.setdefault(source, [])
        if target not in data[source]:
            data[source].append(target)
        save_map(data)

        log.info(f"Mapping added: {source} -> {target}")
        await event.reply("Mapping added")
        return

    # -------- LIST MAP --------
    if text == "/list_map":
        data = load_map()
        if not data:
            await event.reply("No mappings found")
            return

        msg = "Mappings:\n\n"
        for s, t in data.items():
            msg += f"{s} -> {', '.join(t)}\n"

        await event.reply(msg)
        return

    # -------- TEST --------
    if text.startswith("/test"):
        parts = text.split(maxsplit=1)
        if len(parts) != 2:
            await event.reply("Usage: /test <channel_id>")
            return

        channel_id = int(parts[1])

        # ✅ READ CHANNEL VIA USERBOT
        try:
            msg = await get_last_channel_message(channel_id)
        except Exception as e:
            await event.reply(f"Channel read error: {e}")
            return

        bot_username, payload = extract_bot_and_payload(msg)

        if not bot_username:
            await event.reply("No bot button found in last post")
            return

        # 🔥 START DM WATCHER
        await start_dm_watch_for(bot_username)

        # 🔥 TRIGGER BOT
        from user_worker import trigger_bot
        await trigger_bot(bot_username, payload)

        await event.reply(
            f"Triggered @{bot_username}\n"
            f"DM watcher active\n"
            f"Waiting for file..."
        )
        return

    await event.reply(
        "Commands:\n"
        "/start_worker\n"
        "/add_map\n"
        "/list_map\n"
        "/test <channel_id>"
    )


# ---------------- RUN ----------------
log.info("Controller bot running")
bot.run_until_disconnected()
