import os
from dotenv import load_dotenv

# load .env file
load_dotenv()

API_ID = int(os.getenv("API_ID", 0))
API_HASH = os.getenv("API_HASH", "")
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
OWNER_ID = int(os.getenv("OWNER_ID", 0))

REPLACE_TAG = "@Hindi_Animes_Series"
DATA_DIR = "data"

# create data folder
os.makedirs(DATA_DIR, exist_ok=True)

# safety check
if not API_ID or not API_HASH or not BOT_TOKEN or not OWNER_ID:
    raise RuntimeError("❌ Missing values in .env file")
