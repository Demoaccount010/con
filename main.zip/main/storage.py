import json, os, time
from config import DATA_DIR

MAP_FILE = os.path.join(DATA_DIR, "mapping.json")
SENT_FILE = os.path.join(DATA_DIR, "sent.json")

def _load(path, default):
    if not os.path.exists(path):
        return default
    with open(path, "r") as f:
        return json.load(f)

def _save(path, data):
    with open(path, "w") as f:
        json.dump(data, f, indent=2)

def load_map():
    return _load(MAP_FILE, {})

def save_map(m):
    _save(MAP_FILE, m)

def sent_exists(key):
    return key in _load(SENT_FILE, {})

def mark_sent(key):
    data = _load(SENT_FILE, {})
    data[key] = int(time.time())
    _save(SENT_FILE, data)
