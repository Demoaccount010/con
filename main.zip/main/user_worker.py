import os
import re
import asyncio
from telethon import TelegramClient, events
from telethon.sessions import StringSession
from telethon.tl.types import MessageMediaDocument, MessageMediaPhoto
from telethon.errors import FloodWaitError

from config import API_ID, API_HASH, DATA_DIR
from storage import load_map
from logger import log


SESSION_FILE = os.path.join(DATA_DIR, "user.session")

# -------- GLOBAL STATE --------
_ACTIVE_CLIENT = None
_WATCHER = None
_STARTED_WATCH = set()


def clean_caption(text):
    if not text:
        return ""
    return re.sub(r"@\w+", "@Hindi_Animes_Series", text)


# -------- DM WATCHER --------
class DMWatcher:
    def __init__(self, client):
        self.client = client
        self.last_ids = {}  # bot_username -> last_msg_id

    async def watch(self, bot_username):
        log.info(f"DM Watcher STARTED for @{bot_username}")

        while True:
            try:
                msgs = await self.client.get_messages(bot_username, limit=5)

                for msg in reversed(msgs):
                    last_id = self.last_ids.get(bot_username, 0)
                    if msg.id <= last_id:
                        continue

                    self.last_ids[bot_username] = msg.id

                    if not msg.media:
                        continue

                    if isinstance(msg.media, (MessageMediaDocument, MessageMediaPhoto)):
                        await self.forward(msg)

            except Exception as e:
                log.error(f"DM Watcher error @{bot_username}: {e}")

            await asyncio.sleep(1.5)

    async def forward(self, msg):
        mappings = load_map()
        if not mappings:
            return

        caption = clean_caption(msg.text or "")
        log.info("File captured via DM Watcher")

        for _, targets in mappings.items():
            for tgt in targets:
                try:
                    await self.client.send_file(
                        int(tgt),
                        msg.media,
                        caption=caption,
                        force_document=isinstance(msg.media, MessageMediaDocument)
                    )
                    log.info(f"Forwarded to {tgt}")

                except FloodWaitError as fw:
                    await asyncio.sleep(fw.seconds)
                except Exception as e:
                    log.error(f"Forward error: {e}")


# -------- PUBLIC API --------
async def start_dm_watch_for(bot_username):
    global _WATCHER, _STARTED_WATCH

    if not _WATCHER or not _ACTIVE_CLIENT:
        log.error("DM Watcher not ready")
        return

    if bot_username in _STARTED_WATCH:
        return

    _STARTED_WATCH.add(bot_username)
    asyncio.create_task(_WATCHER.watch(bot_username))


async def get_last_channel_message(channel_id):
    if not _ACTIVE_CLIENT:
        raise RuntimeError("Userbot not ready")

    msgs = await _ACTIVE_CLIENT.get_messages(channel_id, limit=1)
    if not msgs:
        raise RuntimeError("No messages in channel")

    return msgs[0]


async def trigger_bot(bot_username, payload=None):
    if not _ACTIVE_CLIENT:
        log.error("Userbot not ready for trigger")
        return

    if payload:
        await _ACTIVE_CLIENT.send_message(
            bot_username, f"/start {payload}"
        )
    else:
        await _ACTIVE_CLIENT.send_message(bot_username, "/start")



# -------- USERBOT ENTRYPOINT --------
async def start_worker():
    global _ACTIVE_CLIENT, _WATCHER

    if not os.path.exists(SESSION_FILE):
        log.error("User session not found")
        return

    session = open(SESSION_FILE).read().strip()
    client = TelegramClient(StringSession(session), API_ID, API_HASH)
    await client.start()

    _ACTIVE_CLIENT = client
    _WATCHER = DMWatcher(client)

    log.info("Userbot STARTED (DM watcher ready)")

    # Backup event listener (optional)
    

    await client.run_until_disconnected()
