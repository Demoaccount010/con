from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from db import save_file, update_setting, generate_key
from fetcher import fetch_anime_info
import os

temp_uploads = {}
OWNER_ID = int(os.getenv("OWNER_ID"))
BIN_CHANNEL = int(os.getenv("BIN_CHANNEL"))

# OWNER UPLOAD
@Client.on_message(filters.private & (filters.document | filters.video) & filters.user(OWNER_ID))
async def owner_upload(client, message):
    fwd = await message.forward(BIN_CHANNEL)
    file = message.video or message.document
    fname = file.file_name or "video.mp4"
    
    uid = message.from_user.id
    temp_uploads[uid] = {
        "msg_id": fwd.id,
        "unique_id": file.file_unique_id,
        "file_id": file.file_id,
        "filename": fname,
        "size": file.file_size,
        "caption": message.caption or fname
    }
    
    btns = [
        [InlineKeyboardButton("🎬 Movie", callback_data="cat_Movie"), InlineKeyboardButton("📺 Series", callback_data="cat_Series")],
        [InlineKeyboardButton("🔞 NSFW", callback_data="cat_NSFW"), InlineKeyboardButton("📦 Other", callback_data="cat_Other")]
    ]
    await message.reply_text(f"📂 **File Saved to Bin!**\nSelect Category:", reply_markup=InlineKeyboardMarkup(btns))

# CALLBACKS
@Client.on_callback_query()
async def cb_handler(client, query):
    data = query.data
    uid = query.from_user.id
    if uid not in temp_uploads and "cat_" in data: return
    
    if data.startswith("cat_"):
        temp_uploads[uid]['category'] = data.split("_")[1]
        await query.message.edit_text("⏳ Searching Info...")
        results = await fetch_anime_info(temp_uploads[uid]['caption'])
        temp_uploads[uid]['search'] = results
        
        btns = []
        for i, res in enumerate(results):
            btns.append([InlineKeyboardButton(f"{res['title']}", callback_data=f"sel_{i}")])
        btns.append([InlineKeyboardButton("❌ Manual", callback_data="sel_none")])
        await query.message.edit_text("🔍 Select Info:", reply_markup=InlineKeyboardMarkup(btns))

    elif data.startswith("sel_"):
        idx = data.split("_")[1]
        meta = {}
        if idx == "none":
            meta = {"title": temp_uploads[uid]['caption'], "poster": "https://via.placeholder.com/300", "rating": "N/A", "synopsis": "", "genres": ""}
        else:
            meta = temp_uploads[uid]['search'][int(idx)]
            
        final_data = {**temp_uploads[uid], **meta, "public": True}
        await save_file(final_data)
        del temp_uploads[uid]
        await query.message.edit_text(f"✅ **Added:** {final_data['title']}")

# ADMIN CMDS
@Client.on_message(filters.command("gen") & filters.user(OWNER_ID))
async def gen_key(client, message):
    try:
        days = int(message.text.split()[1])
        key = await generate_key(days)
        await message.reply_text(f"🔑 Key: `{key}`\n⏳ {days} Days")
    except: pass

@Client.on_message(filters.command("set_short") & filters.user(OWNER_ID))
async def set_short(client, message):
    try:
        _, api, url = message.text.split()
        await update_setting("short_api", api)
        await update_setting("short_url", url)
        await message.reply_text("✅ Done")
    except: pass