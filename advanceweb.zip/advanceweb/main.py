import uvicorn
import os
import mimetypes
import logging
from urllib.parse import quote
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from pyrogram import Client
from dotenv import load_dotenv
from db import get_latest_uploads, search_files, get_file_details, get_setting, redeem_key
import plugins 

logging.basicConfig(level=logging.ERROR)
load_dotenv()

API_ID = int(os.getenv("API_ID"))
API_HASH = os.getenv("API_HASH")
BOT_TOKEN = os.getenv("BOT_TOKEN")
BIN_CHANNEL = int(os.getenv("BIN_CHANNEL"))

bot = Client("ott_bot", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN, plugins=dict(root="backend"))

@asynccontextmanager
async def lifespan(app: FastAPI):
    print("🚀 Server Started")
    await bot.start()
    yield
    await bot.stop()

app = FastAPI(lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

@app.get("/api/latest")
async def latest(): return {"results": await get_latest_uploads()}

@app.get("/api/search")
async def search(q: str): return {"results": await search_files(q)}

@app.get("/api/details/{id}")
async def details(id: str): return await get_file_details(id)

@app.get("/api/get_link")
async def get_link():
    api = await get_setting("short_api")
    url = await get_setting("short_url")
    return {"link": f"https://{url}/api?api={api}&url=https://your-site.pages.dev/verified.html"}

@app.get("/api/redeem")
async def redeem(key: str): return await redeem_key(key)

@app.get("/stream/{db_id}")
async def stream_video(db_id: str, request: Request):
    data = await get_file_details(db_id)
    if not data: raise HTTPException(404)
    
    file_name = data['filename']
    file_size = data['size']
    safe_name = quote(file_name)
    mime_type = mimetypes.guess_type(file_name)[0] or "video/mp4"
    
    range_header = request.headers.get("Range")
    start, end = 0, file_size - 1
    
    if range_header:
        try:
            bytes_str = range_header.replace("bytes=", "").split("-")
            start = int(bytes_str[0])
            if len(bytes_str) > 1 and bytes_str[1]: end = int(bytes_str[1])
        except: pass
        
    chunk_size = 1024 * 1024 
    content_length = end - start + 1

    async def media_streamer():
        try:
            msg = await bot.get_messages(BIN_CHANNEL, data['msg_id'])
            media = msg.video or msg.document
            if not media: return
            async for chunk in bot.stream_media(media.file_id, offset=start, limit=content_length):
                yield chunk
        except: pass

    headers = {
        "Content-Range": f"bytes {start}-{end}/{file_size}",
        "Accept-Ranges": "bytes",
        "Content-Length": str(content_length),
        "Content-Type": mime_type,
        "Content-Disposition": f'inline; filename="{safe_name}"',
    }
    return StreamingResponse(media_streamer(), status_code=206, headers=headers)

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8080)