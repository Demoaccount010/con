"""
Advanced Demo - Showcasing ALL New Features
Demonstrates Ollama Brain, GitHub Learning, System Control, and more!
"""
import sys
import time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from agent import AutonomousAgent

def print_header(title):
    """Print section header"""
    print("\n" + "="*70)
    print(f"  {title}")
    print("="*70 + "\n")

def print_result(result, show_data=True):
    """Print result nicely"""
    status = "✅" if result.get('success') else "❌"
    print(f"{status} {result.get('message', 'No message')}")
    
    if show_data and result.get('data'):
        print(f"   Data: {result['data']}")
    
    print()

def demo_1_ollama_brain():
    """Demo 1: Ollama Brain Integration"""
    print_header("DEMO 1: Ollama Brain Integration 🧠")
    
    agent = AutonomousAgent(name="BrainAgent")
    
    if not agent.ollama_brain or not agent.ollama_brain.enabled:
        print("⚠️  Ollama not available. Make sure Ollama is running:")
        print("   1. Install Ollama: https://ollama.ai")
        print("   2. Run: ollama serve")
        print("   3. Run: ollama pull llama3")
        print("\n   Skipping Ollama demos...\n")
        return False
    
    print("✅ Ollama Brain is active!")
    print(f"   Model: {agent.ollama_brain.model_name}")
    print(f"   URL: {agent.ollama_brain.ollama_url}\n")
    
    # Test thinking
    print("🧠 Testing AI Thinking...")
    result = agent.ollama_brain.think(
        "What is the best way to organize Python code in a project?",
        mode=agent.ollama_brain.ThinkingMode.NORMAL
    )
    
    if result['success']:
        print(f"✅ AI Response:\n{result['response'][:200]}...\n")
    
    # Test task analysis
    print("🔍 Testing Task Analysis...")
    analysis = agent.ollama_brain.analyze_task(
        "Create a web scraper that downloads images from a website"
    )
    
    if analysis['success']:
        print(f"✅ Task Analysis Complete!")
        print(f"   Analysis: {str(analysis['analysis'])[:150]}...\n")
    
    # Test code generation
    print("⚙️  Testing Code Generation...")
    code_result = agent.ollama_brain.generate_code(
        "A function that calculates fibonacci numbers efficiently",
        language="python"
    )
    
    if code_result['success']:
        print(f"✅ Code Generated!")
        print(f"   Lines: {len(code_result['code'].split(chr(10)))}")
        print(f"   Code:\n{code_result['code'][:200]}...\n")
    
    return True

def demo_2_github_learning():
    """Demo 2: GitHub Learning"""
    print_header("DEMO 2: GitHub Learning & Skill Generation 🛠️")
    
    agent = AutonomousAgent(name="LearnerAgent")
    
    if not agent.skill_generator.github_learner:
        print("⚠️  GitHub learner not available (missing dependencies)")
        print("   Install: pip install GitPython beautifulsoup4 lxml")
        return False
    
    # Search GitHub repos
    print("🔍 Searching GitHub for 'python telegram bot'...")
    repos = agent.skill_generator.search_github_repos("python telegram bot", limit=3)
    
    if repos:
        print(f"✅ Found {len(repos)} repositories:\n")
        for i, repo in enumerate(repos, 1):
            print(f"   {i}. {repo['name']} ({repo['stars']}⭐)")
            print(f"      {repo['description'][:80]}...")
            print(f"      {repo['url']}\n")
    else:
        print("❌ No repositories found\n")
        return False
    
    # Analyze a specific repo
    print("📊 Analyzing repository structure...")
    if repos:
        repo_url = repos[0]['url']
        print(f"   Repository: {repo_url}\n")
        
        analysis = agent.skill_generator.github_learner.analyze_repo(repo_url)
        
        if analysis.get('success'):
            print(f"✅ Analysis Complete!")
            print(f"   Language: {analysis.get('language')}")
            print(f"   Stars: {analysis.get('stars')}")
            print(f"   Main Files: {len(analysis.get('main_files', []))}")
            if analysis.get('ai_analysis'):
                print(f"   AI Insight: {analysis['ai_analysis'][:150]}...\n")
    
    return True

def demo_3_system_control():
    """Demo 3: System Control Skills"""
    print_header("DEMO 3: System Control & Automation 💻")
    
    agent = AutonomousAgent(name="SystemAgent")
    
    if not agent.system_skill:
        print("⚠️  System skills not available")
        return False
    
    # Get system info
    print("📊 Getting System Information...")
    result = agent.system_skill.run(action='info')
    
    if result['success']:
        info = result['result']
        print(f"✅ System Info:")
        print(f"   OS: {info.get('system')} {info.get('release')}")
        print(f"   CPU Cores: {info.get('cpu_count')}")
        print(f"   Memory: {info.get('memory_total') / (1024**3):.1f} GB")
        print(f"   Disk: {info.get('disk_free') / (1024**3):.1f} GB free\n")
    
    # Monitor resources
    print("📈 Monitoring System Resources...")
    result = agent.system_skill.run(action='monitor')
    
    if result['success']:
        monitor = result['result']
        print(f"✅ Current Usage:")
        print(f"   CPU: {monitor.get('cpu_percent')}%")
        print(f"   Memory: {monitor.get('memory_percent')}%")
        print(f"   Disk: {monitor.get('disk_percent')}%\n")
    
    # List processes
    print("🔍 Listing Running Processes (top 5)...")
    result = agent.process_skill.run(action='list')
    
    if result['success']:
        processes = result['result']['processes'][:5]
        print(f"✅ Found {result['result']['count']} processes\n")
        print(f"   {'PID':<8} {'Name':<25} {'CPU%':<8} {'Memory%'}")
        print(f"   {'-'*60}")
        for proc in processes:
            print(f"   {proc['pid']:<8} {proc['name'][:24]:<25} {proc['cpu']:<8.1f} {proc['memory']:.2f}%")
        print()
    
    # File operations
    print("📁 Testing File Operations...")
    test_file = Path("test_agent_file.txt")
    
    # Write file
    result = agent.file_skill.run(action='write', file_path=str(test_file), 
                                  content="Hello from Autonomous Agent!")
    print_result(result, show_data=False)
    
    # Read file
    result = agent.file_skill.run(action='read', file_path=str(test_file))
    if result['success']:
        print(f"✅ Read file: {result['result']['content']}\n")
    
    # Delete file
    result = agent.file_skill.run(action='delete', file_path=str(test_file))
    print_result(result, show_data=False)
    
    return True

def demo_4_intent_detection():
    """Demo 4: Enhanced Intent Detection"""
    print_header("DEMO 4: Enhanced Intent Detection 🗣️")
    
    agent = AutonomousAgent(name="IntentAgent")
    
    test_inputs = [
        "Create a skill to parse JSON",
        "file kholo yaar",  # Hinglish
        "Show me system statistics",
        "Can you help me?",
        "GitHub se telegram bot code seekho"  # Hinglish
    ]
    
    for user_input in test_inputs:
        print(f"📝 Input: \"{user_input}\"")
        
        result = agent.intent_detector.detect(user_input)
        
        print(f"   Intent: {result['intent']}")
        print(f"   Confidence: {result['confidence']:.2f}")
        print(f"   Language: {result.get('language', 'english')}")
        if result.get('sentiment'):
            print(f"   Sentiment: {result.get('sentiment')}")
        if result.get('entities'):
            print(f"   Entities: {result['entities']}")
        print()
    
    return True

def demo_5_proactive_assistant():
    """Demo 5: Proactive Assistant"""
    print_header("DEMO 5: Proactive Assistant 🤖")
    
    agent = AutonomousAgent(name="ProactiveAgent")
    
    if not agent.proactive_assistant:
        print("⚠️  Proactive assistant not available")
        return False
    
    # Simulate some interactions
    print("📊 Analyzing User Patterns...")
    print("   (After using the agent, patterns will be detected)\n")
    
    patterns = agent.proactive_assistant.analyze_user_patterns()
    
    if patterns.get('success'):
        pattern_data = patterns.get('patterns', {})
        print(f"✅ Pattern Analysis:")
        print(f"   Total Interactions: {pattern_data.get('total_interactions', 0)}")
        
        if pattern_data.get('repetitive_commands'):
            print(f"   Repetitive Commands: {len(pattern_data['repetitive_commands'])}")
        
        if pattern_data.get('insights'):
            print(f"\n   💡 Insights:")
            for insight in pattern_data['insights']:
                print(f"      • {insight}")
    
    # System health check
    print(f"\n🏥 System Health Check...")
    health = agent.proactive_assistant.check_system_health()
    
    if health.get('success'):
        status = health['health_status']
        print(f"✅ Overall Status: {health['overall_status'].upper()}")
        print(f"   CPU: {status['cpu']['usage_percent']:.1f}% ({status['cpu']['status']})")
        print(f"   Memory: {status['memory']['usage_percent']:.1f}% ({status['memory']['status']})")
        print(f"   Disk: {status['disk']['usage_percent']:.1f}% ({status['disk']['status']})")
        
        if health.get('maintenance_suggestions'):
            print(f"\n   🔧 Maintenance Suggestions:")
            for suggestion in health['maintenance_suggestions']:
                print(f"      • [{suggestion['priority'].upper()}] {suggestion['message']}")
    
    print()
    return True

def demo_6_skill_generation():
    """Demo 6: AI-Powered Skill Generation"""
    print_header("DEMO 6: AI-Powered Skill Generation ⚙️")
    
    agent = AutonomousAgent(name="SkillAgent")
    
    # Test skill generation
    print("🔨 Generating skill: 'Calculate prime numbers'...")
    
    response = agent.process("Create a skill to check if a number is prime")
    
    print_result(response)
    
    # List generated skills
    print("📋 Listing All Skills...")
    skills = agent.skill_registry.list_skills()
    
    if skills:
        print(f"✅ Total Skills: {len(skills)}\n")
        for i, skill in enumerate(skills[:5], 1):
            print(f"   {i}. {skill['name']}")
            print(f"      Category: {skill['category']}")
            print(f"      Description: {skill['description'][:60]}...")
            print()
    else:
        print("   No skills registered yet\n")
    
    return True

def demo_7_comprehensive_workflow():
    """Demo 7: Complete Workflow"""
    print_header("DEMO 7: Complete Autonomous Workflow 🚀")
    
    agent = AutonomousAgent(name="FullAgent")
    
    # Comprehensive interaction
    test_scenarios = [
        "What can you do?",
        "Show me your statistics",
        "Analyze system resources",
        "Create a skill to add two numbers",
    ]
    
    for scenario in test_scenarios:
        print(f"🎯 Scenario: {scenario}")
        response = agent.process(scenario)
        
        print(f"   Status: {'✅ Success' if response['success'] else '❌ Failed'}")
        print(f"   Response: {response['message'][:100]}...")
        print(f"   Duration: {response['duration_ms']}ms\n")
    
    # Final statistics
    print("📊 Final Agent Statistics:")
    stats = agent.get_statistics()
    
    print(f"\n   Agent: {stats['agent_name']}")
    print(f"   Conversations: {stats['conversation_length']}")
    print(f"   Intent Detections: {stats['intent_detector']['total_detections']}")
    print(f"   Skills: {stats['skills']['total_skills']}")
    print(f"   Success Rate: {stats['learning']['overall_success_rate']:.1f}%")
    
    return True

def main():
    """Run all advanced demos"""
    print("\n" + "="*70)
    print("  🤖 AUTONOMOUS AI AGENT - ADVANCED FEATURE DEMONSTRATION")
    print("  Version 2.0 - Enhanced with Ollama, GitHub, System Control")
    print("="*70)
    
    demos = [
        ("Ollama Brain Integration", demo_1_ollama_brain),
        ("GitHub Learning", demo_2_github_learning),
        ("System Control", demo_3_system_control),
        ("Intent Detection", demo_4_intent_detection),
        ("Proactive Assistant", demo_5_proactive_assistant),
        ("Skill Generation", demo_6_skill_generation),
        ("Complete Workflow", demo_7_comprehensive_workflow),
    ]
    
    results = []
    
    for name, demo_func in demos:
        try:
            success = demo_func()
            results.append((name, success))
            time.sleep(1)  # Brief pause between demos
        except Exception as e:
            print(f"\n❌ Error in {name}: {e}\n")
            results.append((name, False))
    
    # Summary
    print("\n" + "="*70)
    print("  📊 DEMO SUMMARY")
    print("="*70 + "\n")
    
    for name, success in results:
        status = "✅" if success else "❌"
        print(f"{status} {name}")
    
    successful = sum(1 for _, success in results if success)
    print(f"\n✅ Completed: {successful}/{len(results)} demos")
    
    print("\n" + "="*70)
    print("  🎉 ADVANCED DEMO COMPLETE!")
    print("="*70)
    
    print("\n📚 Next Steps:")
    print("   1. Install Ollama for AI features: https://ollama.ai")
    print("   2. Run: ollama serve && ollama pull llama3")
    print("   3. Install dependencies: pip install -r requirements.txt")
    print("   4. Try interactive mode: python main.py")
    print("   5. Check FEATURE_STATUS.md for all capabilities")
    print("\n🚀 Happy Automating!\n")

if __name__ == "__main__":
    main()
