"""
Safe self-code modification system
Allows agent to update its own code with safety checks
"""

import ast
import os
import shutil
from datetime import datetime
from typing import Dict, List, Optional, Tuple
import inspect
import importlib
import sys
from pathlib import Path

try:
    from ..utils import setup_logger, timestamp, validate_python_code
except ImportError:
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from utils import setup_logger, timestamp, validate_python_code

class CodeModifier:
    """
    Safely modify Python code files
    """
    
    def __init__(self, backup_dir: str = "backups/code"):
        """
        Initialize code modifier
        
        Args:
            backup_dir: Directory to store backups
        """
        self.logger = setup_logger(self.__class__.__name__)
        self.backup_dir = Path(backup_dir)
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        self.modification_history = []
        
    def read_file(self, file_path: str) -> str:
        """
        Read a Python file
        
        Args:
            file_path: Path to file
            
        Returns:
            File content as string
        """
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()
    
    def parse_code(self, code: str) -> ast.Module:
        """
        Parse Python code into AST
        
        Args:
            code: Python code string
            
        Returns:
            AST Module
        """
        try:
            return ast.parse(code)
        except SyntaxError as e:
            raise ValueError(f"Invalid Python code: {e}")
    
    def analyze_structure(self, file_path: str) -> Dict:
        """
        Analyze code structure
        
        Args:
            file_path: Path to Python file
            
        Returns:
            Dict with classes, functions, imports
        """
        code = self.read_file(file_path)
        tree = self.parse_code(code)
        
        structure = {
            "classes": [],
            "functions": [],
            "imports": [],
            "global_vars": []
        }
        
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                methods = [m.name for m in node.body if isinstance(m, ast.FunctionDef)]
                structure["classes"].append({
                    "name": node.name,
                    "methods": methods,
                    "line": node.lineno
                })
            elif isinstance(node, ast.FunctionDef):
                # Only top-level functions
                if node.col_offset == 0:
                    structure["functions"].append({
                        "name": node.name,
                        "line": node.lineno,
                        "args": [arg.arg for arg in node.args.args]
                    })
            elif isinstance(node, (ast.Import, ast.ImportFrom)):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        structure["imports"].append(alias.name)
                else:
                    structure["imports"].append(f"{node.module}")
        
        return structure
    
    def backup_file(self, file_path: str) -> str:
        """
        Create backup before modification
        
        Args:
            file_path: File to backup
            
        Returns:
            Path to backup file
        """
        file_path = Path(file_path)
        timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"{file_path.stem}_{timestamp_str}{file_path.suffix}"
        backup_path = self.backup_dir / backup_name
        
        shutil.copy2(file_path, backup_path)
        self.logger.info(f"Created backup: {backup_path}")
        
        return str(backup_path)
    
    def add_function_to_file(self, file_path: str, function_code: str, 
                            position: str = "end") -> bool:
        """
        Add a new function to a Python file
        
        Args:
            file_path: Path to file
            function_code: Code for the new function
            position: Where to add ("start", "end")
            
        Returns:
            True if successful
        """
        try:
            # Validate function code
            is_valid, error = validate_python_code(function_code)
            if not is_valid:
                self.logger.error(f"Invalid function code: {error}")
                return False
            
            # Backup original file
            backup_path = self.backup_file(file_path)
            
            # Read original code
            original_code = self.read_file(file_path)
            
            # Add function
            if position == "end":
                modified_code = original_code + "\n\n" + function_code
            else:  # start
                modified_code = function_code + "\n\n" + original_code
            
            # Validate modified code
            is_valid, error = validate_python_code(modified_code)
            if not is_valid:
                self.logger.error(f"Modified code invalid: {error}")
                return False
            
            # Write modified code
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(modified_code)
            
            self.modification_history.append({
                "file": file_path,
                "action": "add_function",
                "backup": backup_path,
                "timestamp": timestamp()
            })
            
            self.logger.info(f"Added function to {file_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error adding function: {e}")
            return False
    
    def modify_function(self, file_path: str, function_name: str, 
                       new_function_code: str) -> bool:
        """
        Replace an existing function with new code
        
        Args:
            file_path: Path to file
            function_name: Name of function to replace
            new_function_code: New function code
            
        Returns:
            True if successful
        """
        try:
            # Validate new code
            is_valid, error = validate_python_code(new_function_code)
            if not is_valid:
                self.logger.error(f"Invalid function code: {error}")
                return False
            
            # Backup
            backup_path = self.backup_file(file_path)
            
            # Read and parse original
            original_code = self.read_file(file_path)
            tree = self.parse_code(original_code)
            
            # Find function
            lines = original_code.split('\n')
            function_found = False
            start_line = None
            end_line = None
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef) and node.name == function_name:
                    start_line = node.lineno - 1  # 0-indexed
                    end_line = node.end_lineno
                    function_found = True
                    break
            
            if not function_found:
                self.logger.error(f"Function {function_name} not found")
                return False
            
            # Replace function
            new_lines = lines[:start_line] + [new_function_code] + lines[end_line:]
            modified_code = '\n'.join(new_lines)
            
            # Validate
            is_valid, error = validate_python_code(modified_code)
            if not is_valid:
                self.logger.error(f"Modified code invalid: {error}")
                return False
            
            # Write
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(modified_code)
            
            self.modification_history.append({
                "file": file_path,
                "action": "modify_function",
                "function": function_name,
                "backup": backup_path,
                "timestamp": timestamp()
            })
            
            self.logger.info(f"Modified function {function_name} in {file_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error modifying function: {e}")
            return False
    
    def add_import(self, file_path: str, import_statement: str) -> bool:
        """
        Add an import statement to a file
        
        Args:
            file_path: Path to file
            import_statement: Import statement (e.g., "import os" or "from x import y")
            
        Returns:
            True if successful
        """
        try:
            # Backup
            backup_path = self.backup_file(file_path)
            
            # Read code
            original_code = self.read_file(file_path)
            lines = original_code.split('\n')
            
            # Find where to insert (after last import or at top)
            insert_line = 0
            for i, line in enumerate(lines):
                if line.strip().startswith(('import ', 'from ')):
                    insert_line = i + 1
            
            # Insert import
            lines.insert(insert_line, import_statement)
            modified_code = '\n'.join(lines)
            
            # Validate
            is_valid, error = validate_python_code(modified_code)
            if not is_valid:
                self.logger.error(f"Modified code invalid: {error}")
                return False
            
            # Write
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(modified_code)
            
            self.logger.info(f"Added import to {file_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error adding import: {e}")
            return False
    
    def rollback(self, modification_index: int = -1) -> bool:
        """
        Rollback a modification
        
        Args:
            modification_index: Index in history (-1 for last)
            
        Returns:
            True if successful
        """
        try:
            if not self.modification_history:
                self.logger.warning("No modifications to rollback")
                return False
            
            mod = self.modification_history[modification_index]
            backup_path = mod['backup']
            file_path = mod['file']
            
            # Restore from backup
            shutil.copy2(backup_path, file_path)
            
            self.logger.info(f"Rolled back {file_path} from {backup_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error rolling back: {e}")
            return False
    
    def get_modification_history(self) -> List[Dict]:
        """Get list of all modifications"""
        return self.modification_history.copy()
    
    def test_modified_code(self, file_path: str) -> Tuple[bool, str]:
        """
        Test if modified code can be imported/executed
        
        Args:
            file_path: Path to modified file
            
        Returns:
            (success, error_message)
        """
        try:
            # Try to compile
            code = self.read_file(file_path)
            compile(code, file_path, 'exec')
            
            return True, "Code compiles successfully"
            
        except Exception as e:
            return False, str(e)
    
    def suggest_improvements(self, file_path: str, ollama_brain=None) -> List[str]:
        """
        Use Ollama to suggest code improvements
        
        Args:
            file_path: Path to file
            ollama_brain: Ollama brain instance
            
        Returns:
            List of suggestions
        """
        if not ollama_brain or not ollama_brain.enabled:
            return ["Ollama brain not available for suggestions"]
        
        try:
            code = self.read_file(file_path)
            
            prompt = f"""Analyze this Python code and suggest improvements:

```python
{code[:2000]}  # First 2000 chars
```

Provide:
1. Code quality issues
2. Performance improvements
3. Best practice violations
4. Security concerns
5. Specific suggestions

Be concise and practical."""
            
            result = ollama_brain.think(prompt, mode=ollama_brain.ThinkingMode.DEEP)
            
            if result['success']:
                # Parse suggestions from response
                response = result['response']
                suggestions = response.split('\n')
                return [s.strip() for s in suggestions if s.strip() and len(s.strip()) > 10]
            
            return ["Failed to get suggestions from Ollama"]
            
        except Exception as e:
            self.logger.error(f"Error getting suggestions: {e}")
            return [f"Error: {e}"]
