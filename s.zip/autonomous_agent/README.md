# 🤖 Autonomous AI Agent with Self-Learning

A fully autonomous AI agent capable of self-improvement, dynamic skill generation, and learning from user feedback.

## ✨ Features

- **🧠 Intent Detection**: Understands natural language commands with high accuracy
- **💾 Multi-Tier Memory System**: Short-term, long-term, and episodic memory
- **🛠️ Dynamic Skill Generation**: Creates new Python functions on-the-fly
- **🔄 Self-Modification**: Can update its own code safely
- **📚 Learning Engine**: Learns from feedback and improves over time
- **🔐 Permission Management**: Requests approval for risky operations
- **📊 Skill Registry**: Tracks and manages all learned capabilities

## 🚀 Quick Start

### Installation

```bash
# Clone or download the project
cd autonomous_agent

# No pip install needed - uses only Python standard library!
# Optional: Install enhanced features
# pip install -r requirements.txt
```

### Usage

```bash
# Start the agent in interactive mode
python main.py
```

### Example Interactions

```
You: Create a skill to calculate fibonacci numbers

Agent: Created skill: calculate_fibonacci_numbers

You: Show me your skills

Agent: Found 1 skills
[Data: [{'name': 'calculate_fibonacci_numbers', ...}]]

You: Learn that Python is my favorite programming language

Agent: I've learned and stored that information

You: Analyze your performance

Agent: Performance analysis
[Data: {'success_rate': 0.95, 'total_actions': 20, ...}]
```

## 📂 Project Structure

```
autonomous_agent/
├── agent.py                    # Main agent orchestrator
├── main.py                     # Entry point
├── config.py                   # Configuration settings
├── utils.py                    # Utility functions
├── core/
│   ├── __init__.py
│   ├── intent_detector.py      # Natural language understanding
│   ├── memory_system.py        # Memory management
│   ├── skill_generator.py      # Dynamic skill creation
│   ├── self_updater.py         # Self-modification system
│   ├── learning_engine.py      # Learning from feedback
│   ├── permission_manager.py   # Permission handling
│   └── skill_registry.py       # Skill tracking
├── data/                       # SQLite databases (auto-created)
├── skills/                     # Generated skills (auto-created)
├── logs/                       # Log files (auto-created)
└── backups/                    # Code backups (auto-created)
```

## 🎯 Core Capabilities

### Intent Detection
- Recognizes 9 primary intent categories
- Extracts entities (files, URLs, variables, etc.)
- Context-aware with confidence scoring
- Learns new patterns over time

### Memory System
- **Short-term**: Recent interactions (last 20 items)
- **Long-term**: Important information with importance scoring
- **Episodic**: Conversation history with temporal context
- Automatic memory consolidation

### Skill Generation
- Generates Python functions from descriptions
- Template-based for common patterns
- Code validation and safety checks
- Test execution and performance tracking

### Learning Engine
- Records feedback from all interactions
- Analyzes performance metrics
- Identifies improvement areas
- Updates patterns based on success rates

### Permission Management
- Risk-level assessment (Safe → Critical)
- User approval for risky operations
- Auto-approve rules for trusted operations
- Full audit trail

## 🔧 Configuration

Edit `config.py` to customize:

```python
# Intent detection
INTENT_CONFIDENCE_THRESHOLD = 0.7

# Memory
SHORT_TERM_MEMORY_SIZE = 20
LONG_TERM_MEMORY_THRESHOLD = 0.8

# Learning
LEARNING_RATE = 0.01
SUCCESS_THRESHOLD = 0.8

# Safety
REQUIRE_PERMISSION_FOR_FILE_OPS = True
REQUIRE_PERMISSION_FOR_NETWORK = True
AUTO_APPROVE_SAFE_SKILLS = False
```

## 📊 Monitoring

Get comprehensive statistics:

```python
from agent import AutonomousAgent

agent = AutonomousAgent()
stats = agent.get_statistics()

print(stats['intent_detector'])  # Intent detection stats
print(stats['memory'])           # Memory usage
print(stats['learning'])         # Learning metrics
print(stats['skills'])           # Skill performance
```

## 🛡️ Safety Features

1. **Code Validation**: All generated code is validated before execution
2. **Backups**: Automatic backups before self-modification
3. **Permission System**: User approval required for risky operations
4. **Sandboxing**: Skills run in controlled environments
5. **Audit Trail**: Complete logging of all operations

## 🧪 Testing

The agent includes built-in testing capabilities:

```python
# Test a generated skill
agent.skill_generator.test_skill('my_function', [
    (arg1, arg2),
    (arg3, arg4)
])
```

## 📈 Performance

- Intent detection: ~50ms
- Memory retrieval: ~10ms
- Skill generation: ~200ms
- Total response time: <2 seconds (target)

## 🔮 Future Enhancements

- Integration with LLM APIs (OpenAI, Anthropic)
- Voice interface support
- Multi-agent collaboration
- Advanced reasoning capabilities
- Web interface
- Plugin system

## 📝 License

MIT License - Feel free to use and modify!

## 🤝 Contributing

Contributions welcome! The agent can even help you contribute by:
1. Analyzing the codebase
2. Generating new features
3. Creating test cases
4. Improving documentation

## 💡 Tips

1. **Start Simple**: Begin with basic commands to let the agent learn
2. **Provide Feedback**: The agent learns from your responses
3. **Check Stats**: Monitor performance regularly
4. **Save Skills**: Important skills are automatically registered
5. **Trust Building**: Approve operations to build trust patterns

## 🐛 Troubleshooting

**Agent not responding?**
- Check logs in `logs/agent.log`
- Verify database integrity in `data/` directory

**Skills not working?**
- Use `agent.skill_registry.get_skill_statistics('skill_name')`
- Check error messages in execution history

**Memory issues?**
- Run `agent.memory.consolidate_memories()`
- Clean up old data with `agent.memory.cleanup_old_memories()`

## 📧 Contact

For questions or issues, please refer to the documentation or check the logs.

---

**Made with ❤️ by the Autonomous Agent Team**
