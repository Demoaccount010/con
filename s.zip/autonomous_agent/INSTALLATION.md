# 🚀 Installation & Setup Guide

Complete guide to install and configure the Autonomous AI Agent with all features.

## 📋 Prerequisites

- **Python 3.8+** (Python 3.11 recommended)
- **Windows, macOS, or Linux**
- **8GB RAM** (16GB recommended for Ollama)
- **5GB free disk space**

## 🔧 Quick Installation

### Step 1: Install Python Dependencies

```bash
cd "Desktop/all bots/autonomous_agent"
pip install -r requirements.txt
```

### Step 2: Install Ollama (Optional but Recommended)

Ollama provides the AI brain for intelligent features.

#### Windows
```bash
# Download and install from: https://ollama.ai/download/windows
# Or use PowerShell:
winget install Ollama.Ollama
```

#### macOS
```bash
brew install ollama
```

#### Linux
```bash
curl -fsSL https://ollama.ai/install.sh | sh
```

### Step 3: Download AI Models

```bash
# Start Ollama service
ollama serve

# In another terminal, download models
ollama pull llama3        # Main model (4.7GB)
ollama pull mistral       # Alternative (4.1GB)
ollama pull codellama     # Code specialist (3.8GB)
```

### Step 4: Verify Installation

```bash
# Test basic functionality
python demo.py

# Test advanced features
python demo_advanced.py
```

## 📦 Full Dependency List

### Core Dependencies (Required)
```bash
pip install requests>=2.31.0
pip install psutil>=5.9.0
```

### AI & Learning (Recommended)
```bash
pip install chromadb>=0.4.0
pip install sentence-transformers>=2.2.0
pip install langdetect>=1.0.9
```

### System Control
```bash
pip install pyautogui>=0.9.54
pip install pyperclip>=1.8.2
pip install Pillow>=10.0.0
```

### GitHub Integration
```bash
pip install GitPython>=3.1.40
pip install beautifulsoup4>=4.12.0
pip install lxml>=4.9.3
```

### UI Enhancements
```bash
pip install rich>=13.7.0
pip install colorama>=0.4.6
```

## 🔑 Environment Variables

Create a `.env` file in the project root:

```env
# Ollama Configuration
OLLAMA_URL=http://localhost:11434
OLLAMA_MODEL=llama3
ENABLE_OLLAMA=true

# GitHub Integration (optional)
GITHUB_TOKEN=your_github_token_here

# OpenAI API (optional alternative to Ollama)
OPENAI_API_KEY=your_openai_key_here
```

## 🎯 Feature-Specific Setup

### 1. Ollama Brain (AI Thinking)

```bash
# Install Ollama
curl -fsSL https://ollama.ai/install.sh | sh

# Start service
ollama serve

# Download model
ollama pull llama3

# Test connection
python -c "import requests; print(requests.get('http://localhost:11434/api/tags').json())"
```

### 2. GitHub Learning

```bash
# Install Git
# Windows: https://git-scm.com/download/win
# macOS: brew install git
# Linux: sudo apt install git

# Install Python packages
pip install GitPython beautifulsoup4 lxml

# Optional: Set GitHub token for higher API limits
export GITHUB_TOKEN="your_token_here"
```

### 3. System Control

```bash
# Install system control packages
pip install psutil pyautogui pyperclip Pillow

# On Linux, you may need additional dependencies
sudo apt-get install python3-tk python3-dev scrot
```

### 4. Vector Search (Semantic Memory)

```bash
# Install ChromaDB and embeddings
pip install chromadb sentence-transformers

# Or use FAISS (alternative)
pip install faiss-cpu
```

## 🧪 Testing Installation

### Basic Test
```bash
python -c "from agent import AutonomousAgent; a = AutonomousAgent(); print('✅ Agent initialized successfully')"
```

### Feature Tests
```bash
# Test Ollama
python -c "from core.ollama_brain import OllamaBrain; b = OllamaBrain(); print('✅ Ollama:', b.test_connection())"

# Test System Control
python -c "from skills.system_control import SystemSkill; s = SystemSkill(); print('✅ System Control available')"

# Test GitHub
python -c "from skills.github_learner import GitHubLearner; g = GitHubLearner(); print('✅ GitHub Learner available')"
```

### Run Demo Suite
```bash
# Basic demo
python demo.py

# Advanced demo (all features)
python demo_advanced.py

# Run tests
python test_agent.py
```

## 🔧 Troubleshooting

### Ollama Connection Failed
```bash
# Check if Ollama is running
curl http://localhost:11434/api/tags

# Restart Ollama
pkill ollama
ollama serve

# Check model is downloaded
ollama list
```

### Import Errors
```bash
# Reinstall dependencies
pip install --upgrade -r requirements.txt

# Check Python version
python --version  # Should be 3.8+

# Verify installation
pip list | grep -E "requests|psutil|chromadb"
```

### Permission Errors (Linux/macOS)
```bash
# Install with user flag
pip install --user -r requirements.txt

# Or use virtual environment
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### System Control Issues
```bash
# Windows: Run as Administrator
# Linux: Install X11 dependencies
sudo apt-get install python3-tk python3-dev

# macOS: Grant accessibility permissions
# System Preferences > Security & Privacy > Accessibility
```

## 🌟 Optional Enhancements

### 1. Faster Embeddings (GPU)
```bash
# Install CUDA version for faster embeddings
pip install sentence-transformers[cuda]
```

### 2. Advanced NLP
```bash
# Install spaCy for better language understanding
pip install spacy
python -m spacy download en_core_web_sm
python -m spacy download en_core_web_md  # Larger model
```

### 3. Browser Automation
```bash
# Install Selenium for advanced browser control
pip install selenium
# Download ChromeDriver: https://chromedriver.chromium.org/
```

## 📊 Verification Checklist

After installation, verify:

- [ ] Python 3.8+ installed
- [ ] All pip packages installed (`pip list`)
- [ ] Ollama running (optional but recommended)
- [ ] Ollama model downloaded (`ollama list`)
- [ ] Basic demo works (`python demo.py`)
- [ ] Advanced demo works (`python demo_advanced.py`)
- [ ] Agent can be imported (`python -c "from agent import AutonomousAgent"`)
- [ ] No error messages in logs (`logs/agent.log`)

## 🚀 First Run

```bash
# Interactive mode
python main.py

# Try these commands:
# - "help"
# - "Create a skill to add two numbers"
# - "Show me system information"
# - "Analyze your performance"
# - "What can you do?"
```

## 🔄 Updating

```bash
# Pull latest changes
git pull origin main

# Update dependencies
pip install --upgrade -r requirements.txt

# Update Ollama models
ollama pull llama3
```

## 💡 Performance Tips

1. **Use SSD** for faster model loading
2. **Close unnecessary apps** to free RAM for Ollama
3. **Use smaller models** (mistral) on limited hardware
4. **Disable features** you don't need in `config.py`
5. **Enable caching** for faster repeated operations

## 📞 Getting Help

- Check `FEATURE_STATUS.md` for feature availability
- Read `README.md` for usage examples
- Check `logs/agent.log` for error details
- Review `config.py` for configuration options

## ✅ Installation Complete!

You're ready to use the Autonomous AI Agent with all features!

```bash
python main.py
```

---

**Need Help?** Check the documentation or logs for troubleshooting.
