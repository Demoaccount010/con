"""
GitHub Learner - Learn from GitHub repositories
Fetches, analyzes, and creates skills from public repositories
"""
import os
import json
import requests
from pathlib import Path
from typing import Dict, List, Optional, Any
import tempfile
import shutil
import subprocess

try:
    from git import Repo
    GIT_AVAILABLE = True
except ImportError:
    GIT_AVAILABLE = False

try:
    from bs4 import BeautifulSoup
    BS4_AVAILABLE = True
except ImportError:
    BS4_AVAILABLE = False

try:
    from .base_skill import BaseSkill
except ImportError:
    import sys
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from skills.base_skill import BaseSkill

class GitHubLearner(BaseSkill):
    """
    Learn from GitHub repositories and create skills
    """
    
    def __init__(self, github_token: str = None, ollama_brain = None):
        super().__init__(
            name="GitHubLearner",
            description="Learn from GitHub repositories",
            category="learning"
        )
        self.github_token = github_token or os.getenv('GITHUB_TOKEN')
        self.api_base = "https://api.github.com"
        self.headers = {
            'Accept': 'application/vnd.github.v3+json'
        }
        if self.github_token:
            self.headers['Authorization'] = f'token {self.github_token}'
        
        self.ollama_brain = ollama_brain
        self.cache_dir = Path(tempfile.gettempdir()) / "github_cache"
        self.cache_dir.mkdir(exist_ok=True)
    
    def execute(self, action: str, **kwargs) -> Dict[str, Any]:
        """Execute GitHub learning action"""
        if action == 'search':
            return self.search_repos(kwargs.get('query'), kwargs.get('limit', 10))
        elif action == 'analyze':
            return self.analyze_repo(kwargs.get('repo_url'))
        elif action == 'download':
            return self.download_repo(kwargs.get('repo_url'))
        elif action == 'extract_patterns':
            return self.extract_patterns(kwargs.get('code'))
        elif action == 'create_skill':
            return self.create_skill_from_repo(kwargs.get('repo_url'), kwargs.get('skill_name'))
        else:
            return {'error': f'Unknown action: {action}'}
    
    def search_repos(self, query: str, limit: int = 10) -> Dict:
        """Search GitHub repositories"""
        try:
            url = f"{self.api_base}/search/repositories"
            params = {
                'q': query,
                'sort': 'stars',
                'order': 'desc',
                'per_page': limit
            }
            
            response = requests.get(url, headers=self.headers, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                repos = []
                
                for item in data.get('items', []):
                    repos.append({
                        'name': item['name'],
                        'full_name': item['full_name'],
                        'url': item['html_url'],
                        'description': item['description'],
                        'stars': item['stargazers_count'],
                        'language': item['language'],
                        'clone_url': item['clone_url']
                    })
                
                return {
                    'success': True,
                    'repos': repos,
                    'total_count': data.get('total_count', 0),
                    'query': query
                }
            else:
                return {'success': False, 'error': f'API error: {response.status_code}'}
        
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def analyze_repo(self, repo_url: str) -> Dict:
        """Analyze a GitHub repository structure and content"""
        try:
            # Extract owner and repo name from URL
            parts = repo_url.rstrip('/').split('/')
            owner = parts[-2]
            repo = parts[-1]
            
            # Get repository info
            repo_info_url = f"{self.api_base}/repos/{owner}/{repo}"
            response = requests.get(repo_info_url, headers=self.headers, timeout=10)
            
            if response.status_code != 200:
                return {'success': False, 'error': f'Repo not found: {response.status_code}'}
            
            repo_data = response.json()
            
            # Get README
            readme_content = self._get_readme(owner, repo)
            
            # Get main files
            contents = self._get_repo_contents(owner, repo)
            
            # Analyze with Ollama if available
            analysis = {
                'success': True,
                'name': repo_data['name'],
                'description': repo_data['description'],
                'language': repo_data['language'],
                'stars': repo_data['stargazers_count'],
                'forks': repo_data['forks_count'],
                'topics': repo_data.get('topics', []),
                'readme': readme_content[:500] if readme_content else None,
                'main_files': contents[:10],
                'clone_url': repo_data['clone_url']
            }
            
            # Use Ollama for deeper analysis if available
            if self.ollama_brain and self.ollama_brain.enabled:
                prompt = f"""Analyze this GitHub repository:

Name: {repo_data['name']}
Description: {repo_data['description']}
Language: {repo_data['language']}
README (first 500 chars): {readme_content[:500] if readme_content else 'N/A'}

Provide:
1. What does this repository do?
2. Key technologies and patterns used
3. How could we create a skill from this?
4. What would be the main functions needed?

Be concise and practical."""
                
                brain_result = self.ollama_brain.think(prompt)
                if brain_result['success']:
                    analysis['ai_analysis'] = brain_result['response']
            
            return analysis
        
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def download_repo(self, repo_url: str, destination: str = None) -> Dict:
        """Download a GitHub repository"""
        if not GIT_AVAILABLE:
            return {'success': False, 'error': 'GitPython not installed'}
        
        try:
            if destination is None:
                # Create temp directory
                destination = self.cache_dir / repo_url.split('/')[-1]
            
            dest_path = Path(destination)
            
            # Clone the repo
            if dest_path.exists():
                shutil.rmtree(dest_path)
            
            Repo.clone_from(repo_url, dest_path, depth=1)
            
            return {
                'success': True,
                'path': str(dest_path),
                'message': f'Downloaded to {dest_path}'
            }
        
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def extract_patterns(self, code: str) -> Dict:
        """Extract code patterns using Ollama"""
        if not self.ollama_brain or not self.ollama_brain.enabled:
            return {'success': False, 'error': 'Ollama brain not available'}
        
        try:
            prompt = f"""Analyze this code and extract key patterns:

```
{code[:2000]}  # First 2000 chars
```

Extract:
1. Main classes and their purposes
2. Key functions and what they do
3. Design patterns used
4. Dependencies and imports
5. Reusable code patterns

Format as JSON."""
            
            result = self.ollama_brain.think(prompt, mode=self.ollama_brain.ThinkingMode.DEEP)
            
            if result['success']:
                return {
                    'success': True,
                    'patterns': result['response'],
                    'raw_code_length': len(code)
                }
            else:
                return result
        
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def create_skill_from_repo(self, repo_url: str, skill_name: str) -> Dict:
        """
        Complete workflow: Download repo, analyze, and create a skill
        """
        try:
            # Step 1: Analyze the repo
            print(f"[1/5] Analyzing repository: {repo_url}")
            analysis = self.analyze_repo(repo_url)
            
            if not analysis.get('success'):
                return analysis
            
            # Step 2: Download the repo
            print(f"[2/5] Downloading repository...")
            download_result = self.download_repo(repo_url)
            
            if not download_result.get('success'):
                return download_result
            
            repo_path = Path(download_result['path'])
            
            # Step 3: Read main Python files
            print(f"[3/5] Reading Python files...")
            python_files = list(repo_path.rglob('*.py'))[:5]  # First 5 Python files
            
            if not python_files:
                return {'success': False, 'error': 'No Python files found'}
            
            code_samples = []
            for py_file in python_files:
                try:
                    with open(py_file, 'r', encoding='utf-8') as f:
                        code_samples.append(f.read()[:1000])  # First 1000 chars
                except:
                    pass
            
            combined_code = '\n\n'.join(code_samples)
            
            # Step 4: Extract patterns
            print(f"[4/5] Extracting patterns with AI...")
            patterns = self.extract_patterns(combined_code)
            
            # Step 5: Generate skill code
            print(f"[5/5] Generating skill: {skill_name}")
            
            if self.ollama_brain and self.ollama_brain.enabled:
                spec = f"""Based on this GitHub repository analysis, create a Python skill:

Repository: {analysis['name']}
Description: {analysis['description']}
Language: {analysis['language']}

Extracted Patterns:
{patterns.get('patterns', 'N/A')}

Create a skill class named '{skill_name}' that:
1. Inherits from BaseSkill
2. Implements the main functionality
3. Has proper error handling
4. Includes docstrings

Make it practical and working."""
                
                code_result = self.ollama_brain.generate_code(spec, language="python")
                
                if code_result['success']:
                    return {
                        'success': True,
                        'skill_name': skill_name,
                        'skill_code': code_result['code'],
                        'explanation': code_result['explanation'],
                        'repository': analysis['name'],
                        'analysis': analysis,
                        'patterns': patterns
                    }
            
            # Fallback: Create basic template
            template_code = f'''"""
{skill_name} - Generated from {analysis['name']}
{analysis['description']}
"""

from .base_skill import BaseSkill
from typing import Dict, Any

class {skill_name}(BaseSkill):
    """
    Generated skill from GitHub repository: {analysis['name']}
    """
    
    def __init__(self):
        super().__init__(
            name="{skill_name}",
            description="{analysis['description']}",
            category="generated"
        )
    
    def execute(self, *args, **kwargs) -> Dict[str, Any]:
        """Execute the skill"""
        # TODO: Implement based on repository patterns
        return {{'success': True, 'message': 'Skill executed'}}
'''
            
            return {
                'success': True,
                'skill_name': skill_name,
                'skill_code': template_code,
                'explanation': 'Generated from template',
                'repository': analysis['name'],
                'analysis': analysis
            }
        
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def _get_readme(self, owner: str, repo: str) -> Optional[str]:
        """Get README content"""
        try:
            url = f"{self.api_base}/repos/{owner}/{repo}/readme"
            response = requests.get(url, headers=self.headers, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                # README is base64 encoded
                import base64
                content = base64.b64decode(data['content']).decode('utf-8')
                return content
            
            return None
        except:
            return None
    
    def _get_repo_contents(self, owner: str, repo: str, path: str = "") -> List[Dict]:
        """Get repository contents"""
        try:
            url = f"{self.api_base}/repos/{owner}/{repo}/contents/{path}"
            response = requests.get(url, headers=self.headers, timeout=10)
            
            if response.status_code == 200:
                contents = response.json()
                if isinstance(contents, list):
                    return [
                        {
                            'name': item['name'],
                            'path': item['path'],
                            'type': item['type'],
                            'size': item.get('size', 0)
                        }
                        for item in contents
                    ]
            
            return []
        except:
            return []
    
    def install_dependencies(self, requirements: List[str]) -> Dict:
        """Install Python dependencies"""
        try:
            for package in requirements:
                result = subprocess.run(
                    [sys.executable, '-m', 'pip', 'install', package],
                    capture_output=True,
                    text=True,
                    timeout=60
                )
                
                if result.returncode != 0:
                    return {
                        'success': False,
                        'error': f'Failed to install {package}: {result.stderr}'
                    }
            
            return {
                'success': True,
                'message': f'Installed {len(requirements)} packages',
                'packages': requirements
            }
        
        except Exception as e:
            return {'success': False, 'error': str(e)}
