const API_BASE = "https://api.yoursmile.qzz.io"; 

window.onload = loadLatest;

async function loadLatest() {
    toggleLoader(true);
    try {
        const res = await fetch(`${API_BASE}/latest`);
        const data = await res.json();
        renderVideos(data.results);
    } catch (e) {
        document.getElementById('resultsGrid').innerHTML = '<p style="text-align:center">Failed to load.</p>';
    }
    toggleLoader(false);
}

async function searchAnime() {
    const query = document.getElementById('searchInput').value;
    if(!query) return loadLatest();

    toggleLoader(true);
    document.getElementById('gridTitle').innerText = `Results for "${query}"`;
    try {
        const res = await fetch(`${API_BASE}/search?q=${encodeURIComponent(query)}`);
        const data = await res.json();
        renderVideos(data.results);
    } catch (e) {
        console.error(e);
    }
    toggleLoader(false);
}

function renderVideos(videos) {
    const grid = document.getElementById('resultsGrid');
    grid.innerHTML = '';

    if(!videos || videos.length === 0) {
        grid.innerHTML = '<p style="text-align:center; width:100%">No videos found.</p>';
        return;
    }

    videos.forEach(anime => {
        const card = document.createElement('div');
        card.className = 'card';
        
        const fname = anime.filename ? anime.filename.toLowerCase() : "";
        const isMKV = fname.includes('.mkv');
        const sizeMB = (anime.size / 1024 / 1024).toFixed(1);

        card.innerHTML = `
            <div class="poster">
                <div class="play-icon">▶</div>
            </div>
            <div class="details">
                <div class="title">${anime.title}</div>
                <div class="meta">
                    <span>${sizeMB} MB</span>
                    ${isMKV ? '<span class="badge mkv">MKV</span>' : '<span class="badge">MP4</span>'}
                </div>
            </div>
        `;
        card.onclick = () => play(anime.id, anime.title, fname);
        grid.appendChild(card);
    });
}

function toggleLoader(show) {
    const l = document.getElementById('loader');
    if(show) l.classList.remove('hidden');
    else l.classList.add('hidden');
}

let currentUrl = "";

function play(id, title, filename) {
    currentUrl = `${API_BASE}/stream/${id}`;
    
    // MKV -> Direct Open
    if (filename.includes('.mkv')) {
        window.location.href = currentUrl;
        return;
    }

    // MP4 -> Modal
    const modal = document.getElementById('videoModal');
    const player = document.getElementById('player');
    
    document.getElementById('videoTitle').innerText = title;
    player.src = currentUrl;
    
    modal.style.display = 'flex';
    player.play();
}

function closeModal() {
    const player = document.getElementById('player');
    player.pause();
    player.src = "";
    document.getElementById('videoModal').style.display = 'none';
}

function openVLC() {
    window.location.href = `vlc://${currentUrl}`;
}

function copyLink() {
    navigator.clipboard.writeText(currentUrl);
    alert("Link Copied!");
}