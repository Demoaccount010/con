const API_BASE = "https://api.yoursmile.qzz.io"; 

// Initial Load
window.onload = loadLatest;

async function loadLatest() {
    toggleLoader(true);
    try {
        const res = await fetch(`${API_BASE}/latest`);
        const data = await res.json();
        
        // 1. Setup Hero (First item)
        if(data.results.length > 0) {
            setupHero(data.results[0]);
        }
        
        // 2. Render List
        renderVideos(data.results);
        showToast("Updates Loaded 🔥");
    } catch (e) {
        document.getElementById('resultsGrid').innerHTML = '<p style="color:#aaa; padding:20px;">Server Offline</p>';
    }
    toggleLoader(false);
}

function setupHero(anime) {
    document.getElementById('heroTitle').innerText = anime.title;
    if(anime.poster) document.getElementById('heroImg').src = anime.poster;
    // Store ID for Hero Button
    document.getElementById('heroSection').dataset.id = anime.id;
    document.getElementById('heroSection').dataset.title = anime.title;
    document.getElementById('heroSection').dataset.file = anime.filename;
}

function playHero() {
    const section = document.getElementById('heroSection');
    if(section.dataset.id) {
        triggerModal(section.dataset.id, section.dataset.title, section.dataset.file);
    }
}

async function searchAnime() {
    const query = document.getElementById('searchInput').value;
    if(!query) return loadLatest();

    toggleLoader(true);
    document.getElementById('gridTitle').innerText = `Results: ${query}`;
    
    try {
        const res = await fetch(`${API_BASE}/search?q=${encodeURIComponent(query)}`);
        const data = await res.json();
        renderVideos(data.results);
    } catch (e) {
        console.error(e);
    }
    toggleLoader(false);
}

function renderVideos(videos) {
    const grid = document.getElementById('resultsGrid');
    grid.innerHTML = '';

    if(!videos || videos.length === 0) {
        grid.innerHTML = '<p style="color:#aaa; padding:20px;">No results found.</p>';
        return;
    }

    videos.forEach(anime => {
        const div = document.createElement('div');
        div.className = 'anime-card'; // New Class
        
        const fname = anime.filename ? anime.filename.toLowerCase() : "";
        
        // New Card HTML Structure
        div.innerHTML = `
            <div class="poster-wrapper">
                <img src="${anime.poster || 'https://via.placeholder.com/200x300'}" class="poster-img">
                <div class="card-overlay"></div>
            </div>
            <div class="card-title">${anime.title}</div>
        `;
        
        div.onclick = () => triggerModal(anime.id, anime.title, fname);
        grid.appendChild(div);
    });
}

function toggleLoader(show) {
    const l = document.getElementById('loader');
    if(show) l.classList.remove('hidden');
    else l.classList.add('hidden');
}

// --- NEW MODAL LOGIC ---

let currentStreamUrl = "";
let currentTitle = "";

function triggerModal(id, title, filename) {
    currentStreamUrl = `${API_BASE}/stream/${id}`;
    currentTitle = title;
    
    document.getElementById('videoTitle').innerText = title;
    
    // Open Bottom Sheet
    const modal = document.getElementById('videoModal');
    modal.classList.add('active'); // CSS Transition handles slide up
}

function closeModal(event) {
    // Only close if clicking overlay or explicitly closing
    if (event) {
        document.getElementById('videoModal').classList.remove('active');
    }
}

function openVLC() {
    window.location.href = `vlc://${currentStreamUrl}`;
    showToast("Opening VLC...");
}

function openWebPlayer() {
    closeModal(true); // Close bottom sheet
    const webModal = document.getElementById('webPlayerModal');
    const player = document.getElementById('player');
    
    player.src = currentStreamUrl;
    webModal.style.display = 'flex';
    player.play();
}

function closeWebPlayer() {
    const webModal = document.getElementById('webPlayerModal');
    const player = document.getElementById('player');
    player.pause();
    player.src = "";
    webModal.style.display = 'none';
}

function copyLink() {
    navigator.clipboard.writeText(currentStreamUrl);
    showToast("Link Copied!");
    closeModal(true);
}

function showToast(msg) {
    const t = document.getElementById('toast');
    t.innerText = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 3000);
}