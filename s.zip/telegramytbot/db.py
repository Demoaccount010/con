import os
import uuid
import datetime
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv
from bson.objectid import ObjectId

load_dotenv()
MONGO_URL = os.getenv("MONGO_URL")
client = AsyncIOMotorClient(MONGO_URL)
db = client['anime_db']
col = db['videos']
settings = db['settings']
keys_col = db['keys'] # New Collection

# --- KEY FUNCTIONS ---
async def generate_key(days):
    key = str(uuid.uuid4())[:8].upper() # 8 Char Key
    expiry = datetime.datetime.utcnow() + datetime.timedelta(days=int(days))
    
    await keys_col.insert_one({
        "key": key,
        "days": int(days),
        "created_at": datetime.datetime.utcnow(),
        "is_used": False
    })
    return key

async def redeem_key(key):
    data = await keys_col.find_one({"key": key})
    
    if not data:
        return {"status": False, "msg": "Invalid Key"}
    
    if data['is_used']:
        return {"status": False, "msg": "Key Already Used"}
        
    # Mark as used
    await keys_col.update_one({"key": key}, {"$set": {"is_used": True}})
    
    # Return duration in hours
    return {"status": True, "hours": data['days'] * 24}

# --- SETTINGS ---
async def get_setting(key):
    data = await settings.find_one({"_id": "config"})
    if data: return data.get(key)
    return None

async def update_setting(key, value):
    await settings.update_one({"_id": "config"}, {"$set": {key: value}}, upsert=True)

# --- ANIME ---
async def add_anime(data):
    await col.update_one({"message_id": data['msg_id']}, {"$set": data}, upsert=True)

async def get_latest_anime():
    cursor = col.find().sort("_id", -1).limit(20)
    return await cursor.to_list(length=20)

async def get_categories():
    return await col.distinct("category")

async def search_anime(query):
    cursor = col.find({"$or": [{"title": {"$regex": query, "$options": "i"}}, {"category": {"$regex": query, "$options": "i"}}]}).sort("_id", -1).limit(50)
    return await cursor.to_list(length=50)

async def get_anime_details(id_str):
    try:
        data = await col.find_one({"_id": ObjectId(id_str)})
        if data: data['id'] = str(data['_id']); del data['_id']
        return data
    except: return None

async def get_meta(message_id):
    data = await col.find_one({"message_id": int(message_id)})
    if data: return data['real_filename'], data['file_size']
    return None, 0

async def get_all_for_delete():
    cursor = col.find().sort("_id", -1).limit(10)
    return await cursor.to_list(length=10)

async def delete_anime(id_str):
    await col.delete_one({"_id": ObjectId(id_str)})