import sqlite3

DB_NAME = "anime.db"

def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    # Naya Table Structure
    c.execute('''
        CREATE TABLE IF NOT EXISTS anime (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            message_id INTEGER UNIQUE,
            title TEXT,
            real_filename TEXT, 
            file_size INTEGER,
            duration INTEGER,
            poster TEXT,
            synopsis TEXT,
            rating TEXT,
            genres TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

def add_anime(msg_id, title, real_filename, size, duration, meta):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    try:
        c.execute("""
            INSERT OR IGNORE INTO anime 
            (message_id, title, real_filename, file_size, duration, poster, synopsis, rating, genres) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (msg_id, title, real_filename, size, duration, 
              meta['poster'], meta['synopsis'], meta['rating'], meta['genres']))
        conn.commit()
    except Exception as e:
        print(f"DB Error: {e}")
    finally:
        conn.close()

def get_latest_anime():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row # Dictionary format ke liye
    c = conn.cursor()
    c.execute("SELECT * FROM anime ORDER BY id DESC LIMIT 20")
    rows = c.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def search_anime(query):
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT * FROM anime WHERE title LIKE ? OR real_filename LIKE ? ORDER BY id DESC", (f'%{query}%', f'%{query}%'))
    rows = c.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_anime_details(id):
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT * FROM anime WHERE id=?", (id,))
    row = c.fetchone()
    conn.close()
    return dict(row) if row else None

def get_meta(message_id):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT real_filename, file_size FROM anime WHERE message_id=?", (message_id,))
    row = c.fetchone()
    conn.close()
    return row