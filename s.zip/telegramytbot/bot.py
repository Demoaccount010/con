import os
import logging
import asyncio
from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from dotenv import load_dotenv
from db import add_anime, update_setting, get_setting, get_all_for_delete, delete_anime, generate_key
from fetcher import search_jikan

logging.basicConfig(level=logging.ERROR)
load_dotenv()

API_ID = int(os.getenv("API_ID"))
API_HASH = os.getenv("API_HASH")
BOT_TOKEN = os.getenv("BOT_TOKEN")
CHANNEL_ID = int(os.getenv("CHANNEL_ID")) 
OWNER_ID = int(os.getenv("OWNER_ID"))

client = Client("bot_session", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN, ipv6=False)
temp_data = {}

@client.on_message(filters.command("start"))
async def start(c, m: Message):
    if m.from_user.id == OWNER_ID:
        await m.reply_text(
            "👋 **Boss!**\n"
            "`/gen <days>` - Generate Premium Key\n"
            "`/set_short <API> <URL>` - Set Shortener\n"
            "`/delete` - Delete Files"
        )

# --- KEY GENERATION ---
@client.on_message(filters.command("gen") & filters.user(OWNER_ID))
async def gen_handler(c, m: Message):
    try:
        days = int(m.text.split()[1])
        key = await generate_key(days)
        await m.reply_text(f"🔑 **Premium Key Generated:**\n`{key}`\n\n📅 Validity: {days} Days\n✨ One-time use.")
    except:
        await m.reply_text("❌ Usage: `/gen 30` (for 30 days)")

# --- UPLOAD & OTHER COMMANDS (Same as before) ---
@client.on_message(filters.command("set_short") & filters.user(OWNER_ID))
async def set_short(c, m: Message):
    try:
        _, api, url = m.text.split()
        await update_setting("short_api", api)
        await update_setting("short_url", url)
        await m.reply_text("✅ Shortener Updated!")
    except: await m.reply_text("❌ Error")

@client.on_message(filters.command("set_time") & filters.user(OWNER_ID))
async def set_time(c, m: Message):
    try:
        hours = int(m.text.split()[1])
        await update_setting("verify_time", hours)
        await m.reply_text(f"✅ Time set to {hours} hours.")
    except: await m.reply_text("❌ Error")

@client.on_message(filters.command("delete") & filters.user(OWNER_ID))
async def delete_handler(c, m: Message):
    items = await get_all_for_delete()
    if not items: await m.reply_text("Empty.")
    buttons = [[InlineKeyboardButton(f"🗑 {i['title']}", callback_data=f"del_{i['_id']}")] for i in items]
    await m.reply_text("Select to Delete:", reply_markup=InlineKeyboardMarkup(buttons))

@client.on_callback_query(filters.regex(r"^del_"))
async def delete_cb(c, q: CallbackQuery):
    await delete_anime(q.data.split("_")[1])
    await q.answer("Deleted!")
    await q.message.delete()

@client.on_message(filters.private & (filters.video | filters.document | filters.forwarded))
async def receive_video(c, m: Message):
    if m.from_user.id != OWNER_ID: return
    if m.forward_from_chat and m.forward_from_chat.id == CHANNEL_ID:
        fname = m.video.file_name if m.video else m.document.file_name
        uid = m.from_user.id
        temp_data[uid] = {
            "msg_id": m.forward_from_message_id,
            "filename": fname or "video.mp4",
            "size": m.video.file_size if m.video else m.document.file_size,
            "raw_caption": m.caption or fname
        }
        buttons = [
            [InlineKeyboardButton("🎬 Movie", callback_data="cat_Movies"),
             InlineKeyboardButton("📺 Series", callback_data="cat_Series")],
            [InlineKeyboardButton("🔞 NSFW", callback_data="cat_NSFW"),
             InlineKeyboardButton("📂 Other", callback_data="cat_Others")]
        ]
        await m.reply_text(f"📂 **Category:**", reply_markup=InlineKeyboardMarkup(buttons))

@client.on_callback_query(filters.regex(r"^cat_"))
async def cat_cb(c, q: CallbackQuery):
    uid = q.from_user.id
    temp_data[uid]['category'] = q.data.split("_")[1]
    await q.message.edit_text("⏳ **Searching Info...**")
    res = search_jikan(temp_data[uid]['raw_caption'])
    if not res:
        save_final(uid, {"title": temp_data[uid]['raw_caption'], "poster": "", "synopsis": "", "rating": "", "genres": ""})
        await q.message.edit_text("✅ Saved.")
        return
    temp_data[uid]['results'] = res
    btns = [[InlineKeyboardButton(f"{r['title']}", callback_data=f"sel_{i}")] for i, r in enumerate(res)]
    btns.append([InlineKeyboardButton("❌ Skip", callback_data="sel_none")])
    await q.message.edit_text("🔍 Select:", reply_markup=InlineKeyboardMarkup(btns))

@client.on_callback_query(filters.regex(r"^sel_"))
async def sel_cb(c, q: CallbackQuery):
    uid = q.from_user.id
    sel = q.data.split("_")[1]
    meta = temp_data[uid]['results'][int(sel)] if sel != "none" else {"title": temp_data[uid]['raw_caption'], "poster": "", "synopsis": "", "rating": "", "genres": ""}
    save_final(uid, meta)
    await q.message.edit_text("✅ Saved.")

def save_final(uid, meta):
    loop = asyncio.get_event_loop()
    loop.create_task(add_anime({**temp_data[uid], **meta}))
    del temp_data[uid]

if __name__ == "__main__":
    client.run()