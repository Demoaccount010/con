import httpx

def search_jikan(query):
    try:
        clean = query.replace(".mkv", "").replace(".mp4", "").replace("_", " ")
        url = f"https://api.jikan.moe/v4/anime?q={clean}&limit=5" # 5 results layega
        res = httpx.get(url, timeout=10)
        data = res.json()
        
        results = []
        if data.get('data'):
            for item in data['data']:
                results.append({
                    "title": item['title'],
                    "poster": item['images']['jpg']['large_image_url'],
                    "synopsis": item.get('synopsis', 'No details.'),
                    "rating": str(item.get('score', 'N/A')),
                    "genres": ", ".join([g['name'] for g in item.get('genres', [])]),
                    "id": item['mal_id'] # Unique ID for selection
                })
        return results
    except:
        return []