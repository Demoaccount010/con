import httpx

# Jikan API (Free Anime Database) use karenge
def get_anime_info(query):
    try:
        # File extension hata do search ke liye
        clean_query = query.replace(".mkv", "").replace(".mp4", "").replace("_", " ")
        
        url = f"https://api.jikan.moe/v4/anime?q={clean_query}&limit=1"
        response = httpx.get(url, timeout=10)
        data = response.json()
        
        if data['data']:
            anime = data['data'][0]
            return {
                "poster": anime['images']['jpg']['large_image_url'],
                "synopsis": anime['synopsis'],
                "rating": str(anime['score']),
                "genres": ", ".join([g['name'] for g in anime['genres']])
            }
    except Exception as e:
        print(f"Fetch Error: {e}")
    
    # Agar kuch na mile to Dummy Data
    return {
        "poster": "https://via.placeholder.com/300x450?text=No+Poster",
        "synopsis": "No description available.",
        "rating": "N/A",
        "genres": "Anime"
    }