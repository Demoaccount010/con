#!/usr/bin/env python3
"""
Main Agent Entry Point
======================
Primary entry point for starting the Main AI Agent.

Usage:
    python -m main_agent.main
    # or
    python main_agent/main.py
    
Environment Variables:
    MAINAGENT_LOG_LEVEL    - Set log level (DEBUG, INFO, WARNING, ERROR)
    MAINAGENT_AGENT_NAME   - Custom agent name
    MAINAGENT_MIN_RAM_GB   - Minimum RAM requirement
    
Exit Codes:
    0 - Success
    1 - Configuration error
    2 - Startup error
    3 - Runtime error
    4 - Unknown error
"""

import sys
from typing import Optional

from main_agent.config import Config, ConfigValidationError
from main_agent.core.agent import MainAgent, AgentState
from main_agent.core.errors import (
    AgentError,
    StartupError,
    format_error_response,
    ErrorCategory,
    ErrorSeverity,
)
from main_agent.utils.logger import get_logger, Logger


# Exit codes
EXIT_SUCCESS = 0
EXIT_CONFIG_ERROR = 1
EXIT_STARTUP_ERROR = 2
EXIT_RUNTIME_ERROR = 3
EXIT_UNKNOWN_ERROR = 4


def initialize_config() -> Config:
    """
    Initialize and validate configuration.
    
    Returns:
        Validated Config object
        
    Raises:
        ConfigValidationError: If configuration is invalid
    """
    config = Config()
    config.load()
    config.validate()
    return config


def initialize_logger(config: Config) -> Logger:
    """
    Initialize the logging system.
    
    Args:
        config: Configuration object
        
    Returns:
        Logger instance
    """
    return get_logger(
        name=config.agent.name,
        level=config.logging.level,
        log_dir=config.logging.log_dir,
        log_file=config.logging.log_file,
        console_output=config.logging.console_output,
        file_output=config.logging.file_output,
    )


def run_agent(agent: MainAgent) -> int:
    """
    Run the main agent loop.
    
    In PART-1A, this just demonstrates the agent is ready.
    PART-1B will add actual Ollama interaction.
    
    Args:
        agent: Initialized and started MainAgent
        
    Returns:
        Exit code
    """
    logger = agent._logger
    
    logger.info("Agent is running in PART-1A mode (core foundation only)")
    logger.info("Components available:")
    logger.info(f"  - Planner: {agent.planner.status}")
    logger.info(f"  - Ollama: Not yet implemented (PART-1B)")
    
    # Display status
    status = agent.get_status()
    logger.info("-" * 50)
    logger.info("Agent Status:")
    logger.info(f"  Name: {status['agent']['name']}")
    logger.info(f"  Version: {status['agent']['version']}")
    logger.info(f"  State: {status['agent']['state']}")
    logger.info("-" * 50)
    
    if status['system']:
        sys_info = status['system']
        logger.info("System Information:")
        logger.info(f"  OS: {sys_info['os']['type']} ({sys_info['os']['architecture']})")
        logger.info(f"  CPU: {sys_info['cpu']['cores']} cores")
        logger.info(f"  RAM: {sys_info['memory']['available_gb']:.1f}GB available "
                   f"/ {sys_info['memory']['total_gb']:.1f}GB total")
        logger.info("-" * 50)
    
    # In PART-1A, we demonstrate readiness then exit
    logger.info("PART-1A demonstration complete.")
    logger.info("To continue, implement PART-1B for Ollama integration.")
    
    return EXIT_SUCCESS


def main() -> int:
    """
    Main entry point.
    
    Orchestrates:
    1. Configuration loading
    2. Logger initialization
    3. Agent creation and startup
    4. Agent operation
    5. Graceful shutdown
    
    Returns:
        Exit code (0 for success, non-zero for errors)
    """
    logger: Optional[Logger] = None
    agent: Optional[MainAgent] = None
    
    try:
        # Step 1: Initialize configuration
        print("Loading configuration...")
        config = initialize_config()
        
        # Step 2: Initialize logging
        logger = initialize_logger(config)
        logger.info("Configuration loaded successfully")
        logger.debug(f"Config: {config.to_dict()}")
        
        # Step 3: Create agent
        logger.info("Creating Main Agent...")
        agent = MainAgent(config=config, logger=logger)
        
        # Step 4: Start agent
        logger.info("Starting Main Agent...")
        startup_report = agent.start()
        
        # Log startup report
        logger.info(str(startup_report))
        
        # Step 5: Run agent
        exit_code = run_agent(agent)
        
        # Step 6: Stop agent
        agent.stop(reason="Normal completion")
        
        return exit_code
        
    except ConfigValidationError as e:
        error_msg = f"Configuration Error: {e}"
        if logger:
            logger.error(error_msg)
        else:
            print(f"ERROR: {error_msg}", file=sys.stderr)
        return EXIT_CONFIG_ERROR
        
    except StartupError as e:
        if logger:
            logger.error(str(e))
        else:
            print(str(e), file=sys.stderr)
        return EXIT_STARTUP_ERROR
        
    except AgentError as e:
        if logger:
            logger.error(str(e))
        else:
            print(str(e), file=sys.stderr)
        return EXIT_RUNTIME_ERROR
        
    except KeyboardInterrupt:
        if logger:
            logger.warning("Interrupted by user")
        if agent and agent.state not in (AgentState.STOPPED, AgentState.STOPPING):
            agent.stop(reason="User interrupt")
        return EXIT_SUCCESS
        
    except Exception as e:
        error_response = format_error_response(
            e,
            category=ErrorCategory.UNKNOWN,
            severity=ErrorSeverity.CRITICAL,
            suggestion="This is an unexpected error. Please report it with logs.",
        )
        
        if logger:
            logger.critical(str(error_response))
            logger.exception("Unhandled exception")
        else:
            print(str(error_response), file=sys.stderr)
        
        if agent and agent.state not in (AgentState.STOPPED, AgentState.STOPPING):
            try:
                agent.stop(reason=f"Fatal error: {type(e).__name__}")
            except:
                pass
        
        return EXIT_UNKNOWN_ERROR
        
    finally:
        if logger:
            logger.info("Main Agent process ended")


if __name__ == "__main__":
    sys.exit(main())