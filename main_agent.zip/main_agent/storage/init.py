"""
Storage Module
==============
Handles persistent storage for configuration and data.

Features:
- JSON-based config storage
- Automatic file creation
- Secure token storage
- Easy config updates
"""

from main_agent.storage.config_store import (
    ConfigStore,
    BotSettings,
    load_config,
    save_config,
    config_exists,
    delete_config,
)

__all__ = [
    "ConfigStore",
    "BotSettings",
    "load_config",
    "save_config",
    "config_exists",
    "delete_config",
]