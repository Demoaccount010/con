"""
Worker API Server
=================
HTTP server for receiving and executing tasks.

Uses aiohttp for async HTTP handling.
Falls back to simple http.server if aiohttp not available.
"""

import os
import sys
import json
import asyncio
import time
import uuid
from typing import Dict, Any, Optional, List, Callable
from dataclasses import dataclass, field
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor

try:
    from aiohttp import web
    AIOHTTP_AVAILABLE = True
except ImportError:
    AIOHTTP_AVAILABLE = False
    print("⚠️ aiohttp not installed. Install with: pip install aiohttp")

from worker_agent.config import WorkerConfig
from worker_agent.api.auth import TokenAuth, extract_token


@dataclass
class TaskInfo:
    """Information about a running task."""
    task_id: str
    action: str
    status: str  # pending, running, completed, failed, cancelled
    started_at: datetime
    completed_at: Optional[datetime] = None
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    progress: int = 0


class WorkerServer:
    """
    Worker API Server
    =================
    
    Exposes REST API for task execution.
    
    Endpoints:
        GET  /              - Server info
        GET  /health        - Health check
        GET  /status        - Worker status
        POST /execute       - Execute a task
        GET  /capabilities  - List capabilities
        GET  /tasks         - List running tasks
        GET  /tasks/{id}    - Get task status
        POST /tasks/{id}/cancel - Cancel a task
    
    Usage:
        server = WorkerServer(config)
        await server.start_async()
        # or
        server.start()  # Blocking
    """
    
    def __init__(
        self,
        config: WorkerConfig,
        executors: Optional[Dict[str, Callable]] = None,
    ):
        """
        Initialize worker server.
        
        Args:
            config: Worker configuration
            executors: Optional dict of action -> executor function
        """
        self.config = config
        self._executors = executors or {}
        
        # Authentication
        self._auth = TokenAuth(
            valid_tokens=[config.auth_token],
            allowed_ips=config.allowed_ips if config.allowed_ips else None,
            require_token=config.require_auth,
        )
        
        # Task tracking
        self._tasks: Dict[str, TaskInfo] = {}
        self._task_lock = asyncio.Lock()
        
        # Server state
        self._app: Optional[web.Application] = None
        self._runner: Optional[web.AppRunner] = None
        self._site: Optional[web.TCPSite] = None
        self._running = False
        self._start_time: Optional[datetime] = None
        
        # Thread pool for blocking operations
        self._thread_pool = ThreadPoolExecutor(
            max_workers=config.max_concurrent_tasks
        )
        
        # Register default executors
        self._register_default_executors()
    
    def _register_default_executors(self):
        """Register default task executors."""
        # These will be replaced by actual executors from executors module
        self._executors["echo"] = self._execute_echo
        self._executors["shell"] = self._execute_shell
        self._executors["http_request"] = self._execute_http
        self._executors["file_read"] = self._execute_file_read
        self._executors["file_write"] = self._execute_file_write
    
    def register_executor(self, action: str, executor: Callable):
        """
        Register a task executor.
        
        Args:
            action: Action name
            executor: Async or sync function(params) -> result
        """
        self._executors[action] = executor
    
    @property
    def current_tasks(self) -> int:
        """Get number of running tasks."""
        return len([t for t in self._tasks.values() if t.status == "running"])
    
    @property
    def available_slots(self) -> int:
        """Get available task slots."""
        return max(0, self.config.max_concurrent_tasks - self.current_tasks)
    
    @property
    def is_running(self) -> bool:
        """Check if server is running."""
        return self._running
    
    async def start_async(self):
        """Start the server asynchronously."""
        if not AIOHTTP_AVAILABLE:
            raise RuntimeError("aiohttp is required. Install with: pip install aiohttp")
        
        # Create application
        self._app = web.Application()
        self._setup_routes()
        
        # Create runner
        self._runner = web.AppRunner(self._app)
        await self._runner.setup()
        
        # Create site
        self._site = web.TCPSite(
            self._runner,
            self.config.host,
            self.config.port,
        )
        
        await self._site.start()
        
        self._running = True
        self._start_time = datetime.now()
        
        print(f"✅ Worker API running at http://{self.config.host}:{self.config.port}")
        
        # Keep running
        try:
            while self._running:
                await asyncio.sleep(1)
        except asyncio.CancelledError:
            pass
        finally:
            await self.stop_async()
    
    def start(self):
        """Start the server (blocking)."""
        asyncio.run(self.start_async())
    
    async def stop_async(self):
        """Stop the server."""
        self._running = False
        
        if self._site:
            await self._site.stop()
        
        if self._runner:
            await self._runner.cleanup()
        
        self._thread_pool.shutdown(wait=False)
        
        print("✅ Worker API stopped")
    
    def stop(self):
        """Stop the server."""
        self._running = False
    
    def _setup_routes(self):
        """Setup API routes."""
        self._app.router.add_get("/", self._handle_root)
        self._app.router.add_get("/health", self._handle_health)
        self._app.router.add_get("/status", self._handle_status)
        self._app.router.add_get("/capabilities", self._handle_capabilities)
        self._app.router.add_post("/execute", self._handle_execute)
        self._app.router.add_get("/tasks", self._handle_list_tasks)
        self._app.router.add_get("/tasks/{task_id}", self._handle_get_task)
        self._app.router.add_post("/tasks/{task_id}/cancel", self._handle_cancel_task)
    
    def _check_auth(self, request: web.Request) -> Optional[web.Response]:
        """Check authentication. Returns error response if failed."""
        auth_header = request.headers.get("Authorization", "")
        token = extract_token(auth_header)
        client_ip = request.remote
        
        result = self._auth.verify(token, client_ip)
        
        if not result.authenticated:
            return web.json_response(
                {"error": "Unauthorized", "reason": result.reason},
                status=401,
            )
        
        return None
    
    async def _handle_root(self, request: web.Request) -> web.Response:
        """Handle root endpoint."""
        return web.json_response({
            "name": "Worker Agent API",
            "worker_id": self.config.worker_id,
            "worker_name": self.config.worker_name,
            "version": self.config.version,
            "endpoints": [
                "GET /health",
                "GET /status",
                "GET /capabilities",
                "POST /execute",
                "GET /tasks",
                "GET /tasks/{id}",
                "POST /tasks/{id}/cancel",
            ],
        })
    
    async def _handle_health(self, request: web.Request) -> web.Response:
        """Handle health check endpoint."""
        uptime = 0
        if self._start_time:
            uptime = (datetime.now() - self._start_time).total_seconds()
        
        return web.json_response({
            "status": "healthy",
            "worker_id": self.config.worker_id,
            "uptime_seconds": int(uptime),
            "timestamp": datetime.now().isoformat(),
        })
    
    async def _handle_status(self, request: web.Request) -> web.Response:
        """Handle status endpoint."""
        # Check auth
        auth_error = self._check_auth(request)
        if auth_error:
            return auth_error
        
        uptime = 0
        if self._start_time:
            uptime = (datetime.now() - self._start_time).total_seconds()
        
        return web.json_response({
            "worker_id": self.config.worker_id,
            "worker_name": self.config.worker_name,
            "worker_type": self.config.worker_type,
            "status": "available" if self.available_slots > 0 else "busy",
            "current_tasks": self.current_tasks,
            "max_tasks": self.config.max_concurrent_tasks,
            "available_slots": self.available_slots,
            "capabilities": self.config.capabilities,
            "uptime_seconds": int(uptime),
            "system_info": self.config.get_system_info(),
        })
    
    async def _handle_capabilities(self, request: web.Request) -> web.Response:
        """Handle capabilities endpoint."""
        return web.json_response({
            "worker_id": self.config.worker_id,
            "capabilities": self.config.capabilities,
            "actions": list(self._executors.keys()),
            "limits": {
                "max_concurrent_tasks": self.config.max_concurrent_tasks,
                "task_timeout": self.config.task_timeout,
                "max_memory_mb": self.config.max_memory_mb,
            },
        })
    
    async def _handle_execute(self, request: web.Request) -> web.Response:
        """Handle task execution."""
        # Check auth
        auth_error = self._check_auth(request)
        if auth_error:
            return auth_error
        
        # Check capacity
        if self.available_slots <= 0:
            return web.json_response(
                {"error": "Worker busy", "current_tasks": self.current_tasks},
                status=503,
            )
        
        # Parse request
        try:
            data = await request.json()
        except json.JSONDecodeError:
            return web.json_response(
                {"error": "Invalid JSON"},
                status=400,
            )
        
        # Validate request
        action = data.get("action")
        if not action:
            return web.json_response(
                {"error": "Missing 'action' field"},
                status=400,
            )
        
        # Check if action is supported
        if action not in self._executors:
            return web.json_response(
                {
                    "error": f"Unknown action: {action}",
                    "available_actions": list(self._executors.keys()),
                },
                status=400,
            )
        
        # Create task
        task_id = data.get("task_id") or f"task-{uuid.uuid4().hex[:8]}"
        params = data.get("params", {})
        timeout = data.get("timeout", self.config.task_timeout)
        
        # Create task info
        task_info = TaskInfo(
            task_id=task_id,
            action=action,
            status="running",
            started_at=datetime.now(),
        )
        
        async with self._task_lock:
            self._tasks[task_id] = task_info
        
        # Execute task
        try:
            executor = self._executors[action]
            
            # Run with timeout
            if asyncio.iscoroutinefunction(executor):
                result = await asyncio.wait_for(
                    executor(params),
                    timeout=timeout,
                )
            else:
                # Run sync function in thread pool
                loop = asyncio.get_event_loop()
                result = await asyncio.wait_for(
                    loop.run_in_executor(self._thread_pool, executor, params),
                    timeout=timeout,
                )
            
            # Update task info
            task_info.status = "completed"
            task_info.completed_at = datetime.now()
            task_info.result = result
            
            return web.json_response({
                "status": "success",
                "task_id": task_id,
                "result": result,
                "duration_ms": (task_info.completed_at - task_info.started_at).total_seconds() * 1000,
            })
            
        except asyncio.TimeoutError:
            task_info.status = "failed"
            task_info.completed_at = datetime.now()
            task_info.error = f"Task timed out after {timeout} seconds"
            
            return web.json_response(
                {"error": "Task timeout", "task_id": task_id},
                status=408,
            )
            
        except Exception as e:
            task_info.status = "failed"
            task_info.completed_at = datetime.now()
            task_info.error = str(e)
            
            return web.json_response(
                {"error": str(e), "task_id": task_id},
                status=500,
            )
    
    async def _handle_list_tasks(self, request: web.Request) -> web.Response:
        """List all tasks."""
        auth_error = self._check_auth(request)
        if auth_error:
            return auth_error
        
        tasks = []
        for task in self._tasks.values():
            tasks.append({
                "task_id": task.task_id,
                "action": task.action,
                "status": task.status,
                "started_at": task.started_at.isoformat(),
                "completed_at": task.completed_at.isoformat() if task.completed_at else None,
            })
        
        return web.json_response({"tasks": tasks})
    
    async def _handle_get_task(self, request: web.Request) -> web.Response:
        """Get task status."""
        auth_error = self._check_auth(request)
        if auth_error:
            return auth_error
        
        task_id = request.match_info["task_id"]
        task = self._tasks.get(task_id)
        
        if not task:
            return web.json_response(
                {"error": "Task not found"},
                status=404,
            )
        
        return web.json_response({
            "task_id": task.task_id,
            "action": task.action,
            "status": task.status,
            "started_at": task.started_at.isoformat(),
            "completed_at": task.completed_at.isoformat() if task.completed_at else None,
            "result": task.result,
            "error": task.error,
            "progress": task.progress,
        })
    
    async def _handle_cancel_task(self, request: web.Request) -> web.Response:
        """Cancel a task."""
        auth_error = self._check_auth(request)
        if auth_error:
            return auth_error
        
        task_id = request.match_info["task_id"]
        task = self._tasks.get(task_id)
        
        if not task:
            return web.json_response(
                {"error": "Task not found"},
                status=404,
            )
        
        if task.status != "running":
            return web.json_response(
                {"error": f"Cannot cancel task in status: {task.status}"},
                status=400,
            )
        
        task.status = "cancelled"
        task.completed_at = datetime.now()
        
        return web.json_response({
            "status": "cancelled",
            "task_id": task_id,
        })
    
    # ==================== Default Executors ====================
    
    async def _execute_echo(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Echo executor for testing."""
        return {
            "echo": params,
            "worker_id": self.config.worker_id,
            "timestamp": datetime.now().isoformat(),
        }
    
    def _execute_shell(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute shell command."""
        import subprocess
        
        command = params.get("command", "")
        
        # Security check
        if not self.config.is_command_allowed(command):
            raise PermissionError(f"Command not allowed: {command}")
        
        timeout = params.get("timeout", 60)
        cwd = params.get("cwd")
        
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=cwd,
        )
        
        return {
            "stdout": result.stdout,
            "stderr": result.stderr,
            "returncode": result.returncode,
            "success": result.returncode == 0,
        }
    
    async def _execute_http(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute HTTP request."""
        import urllib.request
        import urllib.error
        
        url = params.get("url")
        method = params.get("method", "GET").upper()
        headers = params.get("headers", {})
        body = params.get("body")
        timeout = params.get("timeout", 30)
        
        if not url:
            raise ValueError("URL is required")
        
        # Prepare request
        data = None
        if body:
            if isinstance(body, dict):
                data = json.dumps(body).encode('utf-8')
                headers["Content-Type"] = "application/json"
            else:
                data = body.encode('utf-8') if isinstance(body, str) else body
        
        request = urllib.request.Request(
            url,
            data=data,
            headers=headers,
            method=method,
        )
        
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                content = response.read().decode('utf-8', errors='replace')
                
                return {
                    "status_code": response.status,
                    "headers": dict(response.headers),
                    "content": content[:10000],  # Limit response size
                    "url": response.url,
                }
        except urllib.error.HTTPError as e:
            return {
                "status_code": e.code,
                "error": str(e.reason),
                "content": e.read().decode('utf-8', errors='replace')[:1000],
            }
        except urllib.error.URLError as e:
            raise ConnectionError(f"URL Error: {e.reason}")
    
    def _execute_file_read(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Read a file."""
        path = params.get("path")
        encoding = params.get("encoding", "utf-8")
        binary = params.get("binary", False)
        
        if not path:
            raise ValueError("Path is required")
        
        # Security check
        if not self.config.is_path_allowed(path):
            raise PermissionError(f"Path not allowed: {path}")
        
        if not os.path.exists(path):
            raise FileNotFoundError(f"File not found: {path}")
        
        mode = "rb" if binary else "r"
        
        with open(path, mode, encoding=None if binary else encoding) as f:
            content = f.read()
        
        if binary:
            import base64
            content = base64.b64encode(content).decode('ascii')
        
        return {
            "path": path,
            "content": content,
            "size": os.path.getsize(path),
            "binary": binary,
        }
    
    def _execute_file_write(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Write to a file."""
        path = params.get("path")
        content = params.get("content", "")
        encoding = params.get("encoding", "utf-8")
        mode = params.get("mode", "w")  # w, a, wb, ab
        
        if not path:
            raise ValueError("Path is required")
        
        # Security check
        if not self.config.is_path_allowed(path):
            raise PermissionError(f"Path not allowed: {path}")
        
        # Create directory if needed
        dir_path = os.path.dirname(path)
        if dir_path and not os.path.exists(dir_path):
            os.makedirs(dir_path, exist_ok=True)
        
        # Handle binary content
        if "b" in mode:
            import base64
            content = base64.b64decode(content)
            with open(path, mode) as f:
                f.write(content)
        else:
            with open(path, mode, encoding=encoding) as f:
                f.write(content)
        
        return {
            "path": path,
            "size": os.path.getsize(path),
            "mode": mode,
            "success": True,
        }