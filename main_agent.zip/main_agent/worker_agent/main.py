#!/usr/bin/env python3
"""
Worker Agent Entry Point
========================
Starts the worker agent server.

Usage:
    python -m worker_agent.main
    python -m worker_agent.main --port 8001
    python -m worker_agent.main --name "WebWorker" --type WEB
    python -m worker_agent.main --register http://main-agent:8000

Environment Variables:
    WORKER_PORT          - Server port (default: 8001)
    WORKER_NAME          - Worker name
    WORKER_TYPE          - Worker type (GENERAL, WEB, FILE, CODE)
    WORKER_AUTH_TOKEN    - Authentication token
    WORKER_MAIN_AGENT_URL - Main agent URL for registration
"""

import sys
import argparse
import signal
import asyncio
from typing import Optional

from worker_agent.config import (
    WorkerConfig,
    WorkerConfigStore,
    load_worker_config,
    load_from_env,
)
from worker_agent.api.server import WorkerServer


def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Worker Agent - Task Executor for Main AI Agent",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    python -m worker_agent.main
    python -m worker_agent.main --port 8001
    python -m worker_agent.main --name "WebWorker" --type WEB
    python -m worker_agent.main --register http://192.168.1.100:8000
        """
    )
    
    parser.add_argument(
        "--port", "-p",
        type=int,
        default=8001,
        help="Server port (default: 8001)"
    )
    
    parser.add_argument(
        "--host",
        type=str,
        default="0.0.0.0",
        help="Server host (default: 0.0.0.0)"
    )
    
    parser.add_argument(
        "--name", "-n",
        type=str,
        help="Worker name"
    )
    
    parser.add_argument(
        "--type", "-t",
        type=str,
        choices=["GENERAL", "WEB", "FILE", "CODE", "DOCKER"],
        default="GENERAL",
        help="Worker type"
    )
    
    parser.add_argument(
        "--register", "-r",
        type=str,
        help="Main Agent URL to register with"
    )
    
    parser.add_argument(
        "--token",
        type=str,
        help="Authentication token"
    )
    
    parser.add_argument(
        "--capabilities", "-c",
        type=str,
        help="Capabilities (comma-separated)"
    )
    
    parser.add_argument(
        "--debug", "-d",
        action="store_true",
        help="Enable debug mode"
    )
    
    parser.add_argument(
        "--config",
        type=str,
        help="Path to config file"
    )
    
    parser.add_argument(
        "--setup",
        action="store_true",
        help="Run interactive setup"
    )
    
    return parser.parse_args()


def print_banner(config: WorkerConfig):
    """Print startup banner."""
    print(f"""
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║           💪 WORKER AGENT - Task Executor 💪                 ║
║                                                              ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║   Worker ID:   {config.worker_id:<40} ║
║   Name:        {config.worker_name:<40} ║
║   Type:        {config.worker_type:<40} ║
║   Endpoint:    {config.get_api_url():<40} ║
║                                                              ║
║   Capabilities: {', '.join(config.capabilities[:3]):<38} ║
║                                                              ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║   API Endpoints:                                             ║
║     GET  /health      - Health check                         ║
║     GET  /status      - Worker status                        ║
║     POST /execute     - Execute task                         ║
║     GET  /capabilities - List capabilities                   ║
║                                                              ║
║   Press Ctrl+C to stop                                       ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
""")


def interactive_setup() -> WorkerConfig:
    """Run interactive setup wizard."""
    print("""
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║           💪 WORKER AGENT - SETUP WIZARD 💪                  ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
""")
    
    config = WorkerConfig()
    
    # Worker Name
    print("\n📝 Worker Configuration\n")
    
    name = input(f"→ Worker name [{config.worker_name}]: ").strip()
    if name:
        config.worker_name = name
    
    # Worker Type
    print("""
Worker Types:
  1. GENERAL  - All-purpose worker
  2. WEB      - Web scraping & downloads
  3. FILE     - File operations
  4. CODE     - Code execution
  5. DOCKER   - Docker container tasks
""")
    
    type_choice = input("→ Select type (1-5) [1]: ").strip()
    type_map = {"1": "GENERAL", "2": "WEB", "3": "FILE", "4": "CODE", "5": "DOCKER"}
    config.worker_type = type_map.get(type_choice, "GENERAL")
    
    # Port
    port = input(f"→ API port [{config.port}]: ").strip()
    if port:
        try:
            config.port = int(port)
        except:
            pass
    
    # Main Agent URL
    main_url = input("→ Main Agent URL (optional, for auto-register): ").strip()
    if main_url:
        config.main_agent_url = main_url
        config.auto_register = True
    
    # Capabilities based on type
    default_caps = {
        "GENERAL": ["FILE_READ", "FILE_WRITE", "CODE_EXECUTE", "HTTP_REQUEST"],
        "WEB": ["HTTP_REQUEST", "WEB_SCRAPE", "FILE_WRITE"],
        "FILE": ["FILE_READ", "FILE_WRITE", "FILE_DELETE"],
        "CODE": ["CODE_EXECUTE", "CODE_ANALYZE"],
        "DOCKER": ["DOCKER_RUN", "DOCKER_BUILD"],
    }
    config.capabilities = default_caps.get(config.worker_type, default_caps["GENERAL"])
    
    # Save config
    store = WorkerConfigStore()
    store.save(config)
    
    print(f"""
✅ Configuration saved!

   Worker ID: {config.worker_id}
   Name: {config.worker_name}
   Type: {config.worker_type}
   Port: {config.port}
   Auth Token: {config.auth_token[:20]}...

   Config file: {store.config_path}
""")
    
    return config


async def register_with_main_agent(config: WorkerConfig) -> bool:
    """
    Register this worker with Main Agent.
    
    Args:
        config: Worker configuration
        
    Returns:
        True if registration successful
    """
    if not config.main_agent_url:
        return False
    
    import urllib.request
    import json
    
    print(f"📡 Registering with Main Agent: {config.main_agent_url}")
    
    try:
        url = f"{config.main_agent_url.rstrip('/')}/api/workers/register"
        data = json.dumps(config.get_registration_payload()).encode('utf-8')
        
        request = urllib.request.Request(
            url,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        
        with urllib.request.urlopen(request, timeout=10) as response:
            result = json.loads(response.read().decode())
            
            if result.get("status") == "registered" or response.status == 200:
                print(f"✅ Registered successfully with Main Agent")
                return True
            else:
                print(f"⚠️ Registration response: {result}")
                return False
                
    except Exception as e:
        print(f"⚠️ Registration failed: {e}")
        print("   Worker will run in standalone mode")
        return False


async def send_heartbeat(config: WorkerConfig, server: WorkerServer):
    """
    Send periodic heartbeats to Main Agent.
    
    Args:
        config: Worker configuration
        server: Worker server instance
    """
    if not config.main_agent_url:
        return
    
    import urllib.request
    import json
    
    while server.is_running:
        try:
            await asyncio.sleep(config.heartbeat_interval)
            
            if not server.is_running:
                break
            
            url = f"{config.main_agent_url.rstrip('/')}/api/workers/heartbeat"
            data = json.dumps({
                "worker_id": config.worker_id,
                "status": "available" if server.available_slots > 0 else "busy",
                "current_tasks": server.current_tasks,
                "max_tasks": config.max_concurrent_tasks,
            }).encode('utf-8')
            
            request = urllib.request.Request(
                url,
                data=data,
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {config.auth_token}",
                },
                method="POST",
            )
            
            with urllib.request.urlopen(request, timeout=5) as response:
                pass  # Just need to send, response doesn't matter
                
        except asyncio.CancelledError:
            break
        except Exception as e:
            # Silent fail for heartbeat
            pass


def main() -> int:
    """Main entry point."""
    args = parse_arguments()
    
    try:
        # Interactive setup
        if args.setup:
            config = interactive_setup()
        else:
            # Load config from file or create new
            try:
                config = load_worker_config(args.config)
            except FileNotFoundError:
                config = WorkerConfig()
        
        # Apply command line overrides
        if args.port:
            config.port = args.port
        if args.host:
            config.host = args.host
        if args.name:
            config.worker_name = args.name
        if args.type:
            config.worker_type = args.type
        if args.token:
            config.auth_token = args.token
        if args.register:
            config.main_agent_url = args.register
            config.auto_register = True
        if args.capabilities:
            config.capabilities = [c.strip() for c in args.capabilities.split(",")]
        if args.debug:
            config.debug = True
            config.log_level = "DEBUG"
        
        # Print banner
        print_banner(config)
        
        # Create server
        server = WorkerServer(config=config)
        
        # Setup signal handlers
        def signal_handler(sig, frame):
            print("\n\n⚠️ Shutting down...")
            server.stop()
            sys.exit(0)
        
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
        
        # Run server with registration
        async def run():
            # Register with Main Agent
            if config.auto_register and config.main_agent_url:
                await register_with_main_agent(config)
                
                # Start heartbeat task
                asyncio.create_task(send_heartbeat(config, server))
            
            # Start server
            await server.start_async()
        
        # Run
        asyncio.run(run())
        
        return 0
        
    except KeyboardInterrupt:
        print("\n\n⚠️ Interrupted by user")
        return 0
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())