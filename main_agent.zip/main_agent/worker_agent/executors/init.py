"""
Task Executors Module
=====================
Executes various types of tasks.

Executor Types:
- BaseExecutor: Abstract base class
- WebExecutor: Web scraping, downloads, HTTP
- FileExecutor: File operations (read, write, copy, move)
- CodeExecutor: Code execution (Python, Shell, Node)

Each executor:
- Receives task parameters
- Executes the task
- Returns structured result
- Handles errors gracefully

Usage:
    from worker_agent.executors import WebExecutor, FileExecutor
    
    web = WebExecutor(config)
    result = await web.execute("download", {"url": "..."})
"""

from worker_agent.executors.base import (
    BaseExecutor,
    ExecutorResult,
    ExecutorError,
    ExecutorRegistry,
)
from worker_agent.executors.web import WebExecutor
from worker_agent.executors.file import FileExecutor
from worker_agent.executors.code import CodeExecutor


# Create global registry
executor_registry = ExecutorRegistry()


def register_all_executors(config):
    """
    Register all default executors.
    
    Args:
        config: WorkerConfig instance
        
    Returns:
        ExecutorRegistry with all executors registered
    """
    # Web executor
    web = WebExecutor(config)
    executor_registry.register("http_request", web.http_request)
    executor_registry.register("download_file", web.download_file)
    executor_registry.register("web_scrape", web.scrape)
    executor_registry.register("download_images", web.download_images)
    
    # File executor
    file_exec = FileExecutor(config)
    executor_registry.register("file_read", file_exec.read)
    executor_registry.register("file_write", file_exec.write)
    executor_registry.register("file_copy", file_exec.copy)
    executor_registry.register("file_move", file_exec.move)
    executor_registry.register("file_delete", file_exec.delete)
    executor_registry.register("file_list", file_exec.list_dir)
    executor_registry.register("file_info", file_exec.get_info)
    
    # Code executor
    code = CodeExecutor(config)
    executor_registry.register("code_execute", code.execute)
    executor_registry.register("python_run", code.run_python)
    executor_registry.register("shell_run", code.run_shell)
    executor_registry.register("script_run", code.run_script)
    
    return executor_registry


__all__ = [
    # Base
    "BaseExecutor",
    "ExecutorResult",
    "ExecutorError",
    "ExecutorRegistry",
    # Executors
    "WebExecutor",
    "FileExecutor",
    "CodeExecutor",
    # Registry
    "executor_registry",
    "register_all_executors",
]