"""
File Executor
=============
Handles file system operations:
- Read files
- Write files
- Copy/Move files
- Delete files
- List directories
- Get file info

Features:
- Path security checks
- Binary and text modes
- Directory operations
- File metadata
"""

import os
import shutil
import stat
import hashlib
import mimetypes
import base64
from typing import Dict, Any, Optional, List
from datetime import datetime

from worker_agent.executors.base import (
    BaseExecutor,
    ExecutorResult,
    ExecutorError,
    ValidationError,
    PermissionDeniedError,
)


class FileExecutor(BaseExecutor):
    """
    File Operations Executor
    ========================
    
    Handles file system operations with security checks.
    
    Actions:
    - file_read: Read file contents
    - file_write: Write to file
    - file_copy: Copy file
    - file_move: Move/rename file
    - file_delete: Delete file or directory
    - file_list: List directory contents
    - file_info: Get file information
    
    Security:
    - All paths checked against allowed_paths config
    - Blocked from system directories
    - Size limits enforced
    
    Usage:
        executor = FileExecutor(config)
        result = await executor.read({"path": "/tmp/file.txt"})
    """
    
    # Limits
    MAX_READ_SIZE = 10 * 1024 * 1024  # 10 MB
    MAX_WRITE_SIZE = 50 * 1024 * 1024  # 50 MB
    MAX_LIST_FILES = 1000
    
    def __init__(self, config: Any, logger=None):
        """Initialize file executor."""
        super().__init__(config, logger)
        
        self._workspace = getattr(
            config, 'workspace_dir', '/tmp/worker_agent'
        )
        
        # Ensure workspace exists
        os.makedirs(self._workspace, exist_ok=True)
    
    def get_actions(self) -> List[str]:
        """Get supported actions."""
        return [
            "file_read",
            "file_write",
            "file_copy",
            "file_move",
            "file_delete",
            "file_list",
            "file_info",
        ]
    
    async def execute(
        self,
        action: str,
        params: Dict[str, Any],
    ) -> ExecutorResult:
        """Execute file action."""
        actions = {
            "file_read": self.read,
            "file_write": self.write,
            "file_copy": self.copy,
            "file_move": self.move,
            "file_delete": self.delete,
            "file_list": self.list_dir,
            "file_info": self.get_info,
        }
        
        handler = actions.get(action)
        if not handler:
            return ExecutorResult.fail(f"Unknown action: {action}")
        
        return await handler(params)
    
    def _resolve_path(self, path: str) -> str:
        """
        Resolve path to absolute path.
        
        If path is relative, resolve relative to workspace.
        """
        if not os.path.isabs(path):
            path = os.path.join(self._workspace, path)
        return os.path.abspath(path)
    
    async def read(self, params: Dict[str, Any]) -> ExecutorResult:
        """
        Read file contents.
        
        Params:
            path: File path (required)
            encoding: Text encoding (default: utf-8)
            binary: Read as binary (default: False)
            offset: Start offset in bytes
            length: Number of bytes to read
            
        Returns:
            ExecutorResult with file content
        """
        self.validate_required(params, ["path"])
        
        path = self._resolve_path(params["path"])
        encoding = params.get("encoding", "utf-8")
        binary = params.get("binary", False)
        offset = params.get("offset", 0)
        length = params.get("length")
        
        # Security check
        self.check_path_allowed(path)
        
        # Check file exists
        if not os.path.exists(path):
            return ExecutorResult.fail(
                f"File not found: {path}",
                error_type="FileNotFoundError",
            )
        
        if not os.path.isfile(path):
            return ExecutorResult.fail(
                f"Not a file: {path}",
                error_type="IsADirectoryError",
            )
        
        # Check size
        file_size = os.path.getsize(path)
        read_size = length or (file_size - offset)
        
        if read_size > self.MAX_READ_SIZE:
            return ExecutorResult.fail(
                f"File too large: {read_size} bytes (max: {self.MAX_READ_SIZE})",
                error_type="FileTooLargeError",
            )
        
        try:
            mode = "rb" if binary else "r"
            
            with open(path, mode, encoding=None if binary else encoding) as f:
                if offset:
                    f.seek(offset)
                
                content = f.read(length) if length else f.read()
            
            # Encode binary as base64
            if binary:
                content = base64.b64encode(content).decode('ascii')
            
            return ExecutorResult.ok({
                "path": path,
                "content": content,
                "size": file_size,
                "read_bytes": len(content) if binary else len(content.encode(encoding)),
                "encoding": encoding if not binary else "base64",
                "binary": binary,
            })
            
        except UnicodeDecodeError as e:
            return ExecutorResult.fail(
                f"Encoding error: {e}. Try binary=True",
                error_type="UnicodeDecodeError",
            )
        except Exception as e:
            return ExecutorResult.fail(str(e), error_type=type(e).__name__)
    
    async def write(self, params: Dict[str, Any]) -> ExecutorResult:
        """
        Write to file.
        
        Params:
            path: File path (required)
            content: Content to write (required)
            encoding: Text encoding (default: utf-8)
            mode: Write mode - "w" (overwrite), "a" (append)
            binary: Content is base64 encoded binary
            create_dirs: Create parent directories
            
        Returns:
            ExecutorResult with write info
        """
        self.validate_required(params, ["path", "content"])
        
        path = self._resolve_path(params["path"])
        content = params["content"]
        encoding = params.get("encoding", "utf-8")
        mode = params.get("mode", "w")
        binary = params.get("binary", False)
        create_dirs = params.get("create_dirs", True)
        
        # Security check
        self.check_path_allowed(path)
        
        # Validate mode
        if mode not in ("w", "a", "wb", "ab"):
            return ExecutorResult.fail(f"Invalid mode: {mode}")
        
        # Handle binary content
        if binary:
            try:
                content = base64.b64decode(content)
                if "b" not in mode:
                    mode += "b"
            except Exception as e:
                return ExecutorResult.fail(f"Invalid base64 content: {e}")
        
        # Check size
        content_size = len(content) if isinstance(content, bytes) else len(content.encode(encoding))
        if content_size > self.MAX_WRITE_SIZE:
            return ExecutorResult.fail(
                f"Content too large: {content_size} bytes (max: {self.MAX_WRITE_SIZE})",
            )
        
        try:
            # Create directories if needed
            if create_dirs:
                dir_path = os.path.dirname(path)
                if dir_path:
                    os.makedirs(dir_path, exist_ok=True)
            
            # Write file
            if "b" in mode:
                with open(path, mode) as f:
                    f.write(content)
            else:
                with open(path, mode, encoding=encoding) as f:
                    f.write(content)
            
            return ExecutorResult.ok({
                "path": path,
                "size": os.path.getsize(path),
                "written_bytes": content_size,
                "mode": mode,
                "created": not os.path.exists(path),
            })
            
        except Exception as e:
            return ExecutorResult.fail(str(e), error_type=type(e).__name__)
    
    async def copy(self, params: Dict[str, Any]) -> ExecutorResult:
        """
        Copy file or directory.
        
        Params:
            source: Source path (required)
            destination: Destination path (required)
            overwrite: Overwrite if exists (default: False)
            
        Returns:
            ExecutorResult with copy info
        """
        self.validate_required(params, ["source", "destination"])
        
        source = self._resolve_path(params["source"])
        destination = self._resolve_path(params["destination"])
        overwrite = params.get("overwrite", False)
        
        # Security checks
        self.check_path_allowed(source)
        self.check_path_allowed(destination)
        
        # Check source exists
        if not os.path.exists(source):
            return ExecutorResult.fail(f"Source not found: {source}")
        
        # Check destination
        if os.path.exists(destination) and not overwrite:
            return ExecutorResult.fail(
                f"Destination exists: {destination}. Set overwrite=True to replace.",
            )
        
        try:
            if os.path.isdir(source):
                if os.path.exists(destination):
                    shutil.rmtree(destination)
                shutil.copytree(source, destination)
                is_dir = True
            else:
                shutil.copy2(source, destination)
                is_dir = False
            
            return ExecutorResult.ok({
                "source": source,
                "destination": destination,
                "is_directory": is_dir,
                "size": os.path.getsize(destination) if not is_dir else None,
            })
            
        except Exception as e:
            return ExecutorResult.fail(str(e), error_type=type(e).__name__)
    
    async def move(self, params: Dict[str, Any]) -> ExecutorResult:
        """
        Move/rename file or directory.
        
        Params:
            source: Source path (required)
            destination: Destination path (required)
            overwrite: Overwrite if exists (default: False)
            
        Returns:
            ExecutorResult with move info
        """
        self.validate_required(params, ["source", "destination"])
        
        source = self._resolve_path(params["source"])
        destination = self._resolve_path(params["destination"])
        overwrite = params.get("overwrite", False)
        
        # Security checks
        self.check_path_allowed(source)
        self.check_path_allowed(destination)
        
        # Check source exists
        if not os.path.exists(source):
            return ExecutorResult.fail(f"Source not found: {source}")
        
        # Check destination
        if os.path.exists(destination) and not overwrite:
            return ExecutorResult.fail(
                f"Destination exists: {destination}. Set overwrite=True to replace.",
            )
        
        try:
            if os.path.exists(destination):
                if os.path.isdir(destination):
                    shutil.rmtree(destination)
                else:
                    os.remove(destination)
            
            shutil.move(source, destination)
            
            return ExecutorResult.ok({
                "source": source,
                "destination": destination,
                "is_directory": os.path.isdir(destination),
            })
            
        except Exception as e:
            return ExecutorResult.fail(str(e), error_type=type(e).__name__)
    
    async def delete(self, params: Dict[str, Any]) -> ExecutorResult:
        """
        Delete file or directory.
        
        Params:
            path: Path to delete (required)
            recursive: Delete directory recursively (default: False)
            
        Returns:
            ExecutorResult with deletion info
        """
        self.validate_required(params, ["path"])
        
        path = self._resolve_path(params["path"])
        recursive = params.get("recursive", False)
        
        # Security check
        self.check_path_allowed(path)
        
        # Check exists
        if not os.path.exists(path):
            return ExecutorResult.ok({
                "path": path,
                "deleted": False,
                "reason": "File not found",
            })
        
        try:
            is_dir = os.path.isdir(path)
            
            if is_dir:
                if recursive:
                    shutil.rmtree(path)
                else:
                    os.rmdir(path)  # Only works for empty directories
            else:
                os.remove(path)
            
            return ExecutorResult.ok({
                "path": path,
                "deleted": True,
                "was_directory": is_dir,
            })
            
        except OSError as e:
            if "not empty" in str(e).lower():
                return ExecutorResult.fail(
                    f"Directory not empty. Set recursive=True to delete.",
                )
            return ExecutorResult.fail(str(e), error_type=type(e).__name__)
        except Exception as e:
            return ExecutorResult.fail(str(e), error_type=type(e).__name__)
    
    async def list_dir(self, params: Dict[str, Any]) -> ExecutorResult:
        """
        List directory contents.
        
        Params:
            path: Directory path (required)
            recursive: List recursively (default: False)
            pattern: Glob pattern filter
            include_hidden: Include hidden files (default: False)
            
        Returns:
            ExecutorResult with file list
        """
        self.validate_required(params, ["path"])
        
        path = self._resolve_path(params["path"])
        recursive = params.get("recursive", False)
        pattern = params.get("pattern")
        include_hidden = params.get("include_hidden", False)
        
        # Security check
        self.check_path_allowed(path)
        
        # Check exists
        if not os.path.exists(path):
            return ExecutorResult.fail(f"Directory not found: {path}")
        
        if not os.path.isdir(path):
            return ExecutorResult.fail(f"Not a directory: {path}")
        
        try:
            files = []
            dirs = []
            
            if recursive:
                for root, dirnames, filenames in os.walk(path):
                    # Filter hidden
                    if not include_hidden:
                        dirnames[:] = [d for d in dirnames if not d.startswith('.')]
                        filenames = [f for f in filenames if not f.startswith('.')]
                    
                    for dirname in dirnames:
                        full_path = os.path.join(root, dirname)
                        rel_path = os.path.relpath(full_path, path)
                        dirs.append(rel_path)
                    
                    for filename in filenames:
                        full_path = os.path.join(root, filename)
                        rel_path = os.path.relpath(full_path, path)
                        files.append({
                            "name": filename,
                            "path": rel_path,
                            "size": os.path.getsize(full_path),
                        })
                    
                    if len(files) + len(dirs) >= self.MAX_LIST_FILES:
                        break
            else:
                for entry in os.listdir(path):
                    if not include_hidden and entry.startswith('.'):
                        continue
                    
                    full_path = os.path.join(path, entry)
                    
                    if os.path.isdir(full_path):
                        dirs.append(entry)
                    else:
                        files.append({
                            "name": entry,
                            "path": entry,
                            "size": os.path.getsize(full_path),
                        })
                    
                    if len(files) + len(dirs) >= self.MAX_LIST_FILES:
                        break
            
            # Apply pattern filter
            if pattern:
                import fnmatch
                files = [f for f in files if fnmatch.fnmatch(f["name"], pattern)]
                dirs = [d for d in dirs if fnmatch.fnmatch(os.path.basename(d), pattern)]
            
            return ExecutorResult.ok({
                "path": path,
                "files": files,
                "directories": dirs,
                "total_files": len(files),
                "total_directories": len(dirs),
            })
            
        except Exception as e:
            return ExecutorResult.fail(str(e), error_type=type(e).__name__)
    
    async def get_info(self, params: Dict[str, Any]) -> ExecutorResult:
        """
        Get file/directory information.
        
        Params:
            path: File path (required)
            checksum: Calculate MD5 checksum (default: False)
            
        Returns:
            ExecutorResult with file info
        """
        self.validate_required(params, ["path"])
        
        path = self._resolve_path(params["path"])
        calc_checksum = params.get("checksum", False)
        
        # Security check
        self.check_path_allowed(path)
        
        # Check exists
        if not os.path.exists(path):
            return ExecutorResult.fail(f"Path not found: {path}")
        
        try:
            stat_info = os.stat(path)
            is_dir = os.path.isdir(path)
            
            info = {
                "path": path,
                "name": os.path.basename(path),
                "is_file": os.path.isfile(path),
                "is_directory": is_dir,
                "is_symlink": os.path.islink(path),
                "size": stat_info.st_size if not is_dir else None,
                "created": datetime.fromtimestamp(stat_info.st_ctime).isoformat(),
                "modified": datetime.fromtimestamp(stat_info.st_mtime).isoformat(),
                "accessed": datetime.fromtimestamp(stat_info.st_atime).isoformat(),
                "permissions": oct(stat_info.st_mode)[-3:],
                "owner_uid": stat_info.st_uid,
                "group_gid": stat_info.st_gid,
            }
            
            # Add file-specific info
            if os.path.isfile(path):
                info["extension"] = os.path.splitext(path)[1]
                info["mime_type"] = mimetypes.guess_type(path)[0]
                
                # Calculate checksum if requested
                if calc_checksum:
                    info["md5"] = self._calculate_md5(path)
            
            # Add directory-specific info
            if is_dir:
                try:
                    contents = os.listdir(path)
                    info["item_count"] = len(contents)
                except:
                    info["item_count"] = None
            
            return ExecutorResult.ok(info)
            
        except Exception as e:
            return ExecutorResult.fail(str(e), error_type=type(e).__name__)
    
    def _calculate_md5(self, path: str) -> str:
        """Calculate MD5 checksum of file."""
        hash_md5 = hashlib.md5()
        
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_md5.update(chunk)
        
        return hash_md5.hexdigest()