"""
Auto-Healer
===========
Attempts automatic fixes for common system problems.

Healing Actions:
- Restart Ollama service
- Switch to lighter model
- Clear memory/caches
- Request agent restart
- Escalate to user

CRITICAL RULES:
1. Every action is logged with WHY it was applied
2. No infinite healing loops (throttling)
3. Escalate if auto-fix fails
4. User notification for destructive actions
5. Always explain what was done and why

Design Philosophy:
- Start with least disruptive action
- Escalate gradually if simple fixes don't work
- Never make things worse
- Always have a fallback plan
"""

import subprocess
import platform
import time
import threading
from typing import Dict, Any, Optional, List, Callable, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta

# Import from PART-1A
from main_agent.core.errors import (
    AgentError,
    ErrorCategory,
    ErrorSeverity,
)
from main_agent.utils.logger import Logger, get_logger

# Import from monitor
from main_agent.doctor.monitor import (
    HealthReport,
    HealthStatus,
    ComponentHealth,
    ComponentType,
)


class HealActionType(Enum):
    """
    Types of healing actions.
    
    Ordered roughly by severity (least to most disruptive).
    """
    NO_ACTION = "NO_ACTION"           # Nothing needed
    CLEAR_CACHE = "CLEAR_CACHE"       # Clear memory caches
    RETRY_CONNECTION = "RETRY_CONN"   # Retry failed connections
    RESTART_OLLAMA = "RESTART_OLLAMA" # Restart Ollama service
    SWITCH_MODEL = "SWITCH_MODEL"     # Switch to lighter model
    RESTART_AGENT = "RESTART_AGENT"   # Restart main agent
    ESCALATE_USER = "ESCALATE_USER"   # Ask user for help


class HealResult(Enum):
    """Result of a healing attempt."""
    SUCCESS = "SUCCESS"       # Fix worked
    PARTIAL = "PARTIAL"       # Partially fixed
    FAILED = "FAILED"         # Fix didn't work
    SKIPPED = "SKIPPED"       # Action not needed
    BLOCKED = "BLOCKED"       # Throttled/too many attempts


@dataclass
class HealAction:
    """
    Record of a healing action.
    
    Captures what was done, why, and the result.
    """
    action_type: HealActionType
    reason: str                              # WHY this action was chosen
    component: ComponentType
    timestamp: datetime
    result: HealResult
    details: str
    duration_ms: float = 0.0
    before_status: Optional[HealthStatus] = None
    after_status: Optional[HealthStatus] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "action": self.action_type.value,
            "reason": self.reason,
            "component": self.component.value,
            "timestamp": self.timestamp.isoformat(),
            "result": self.result.value,
            "details": self.details,
            "duration_ms": round(self.duration_ms, 2),
            "before_status": self.before_status.value if self.before_status else None,
            "after_status": self.after_status.value if self.after_status else None,
        }
    
    @property
    def was_successful(self) -> bool:
        """Check if action was successful."""
        return self.result in (HealResult.SUCCESS, HealResult.PARTIAL)
    
    def __str__(self) -> str:
        """Human-readable representation."""
        status_icon = {
            HealResult.SUCCESS: "✓",
            HealResult.PARTIAL: "◐",
            HealResult.FAILED: "✗",
            HealResult.SKIPPED: "○",
            HealResult.BLOCKED: "⊘",
        }.get(self.result, "?")
        
        lines = [
            f"{status_icon} {self.action_type.value} on {self.component.value}",
            f"   Reason: {self.reason}",
            f"   Result: {self.result.value}",
            f"   Details: {self.details}",
        ]
        
        if self.duration_ms > 0:
            lines.append(f"   Duration: {self.duration_ms:.1f}ms")
        
        return "\n".join(lines)


class HealingThrottle:
    """
    Prevents excessive healing attempts.
    
    Implements cooldown and max-attempts logic to prevent
    infinite healing loops that could make problems worse.
    """
    
    def __init__(
        self,
        cooldown_minutes: int = 5,
        max_attempts: int = 3,
        window_minutes: int = 30,
    ):
        """
        Initialize throttle.
        
        Args:
            cooldown_minutes: Minimum time between same action
            max_attempts: Max attempts within window before blocking
            window_minutes: Time window for max_attempts
        """
        self.cooldown = timedelta(minutes=cooldown_minutes)
        self.max_attempts = max_attempts
        self.window = timedelta(minutes=window_minutes)
        self._actions: Dict[str, List[datetime]] = {}
        self._lock = threading.Lock()
    
    def can_heal(
        self,
        action: HealActionType,
        component: ComponentType,
    ) -> Tuple[bool, str]:
        """
        Check if healing action is allowed.
        
        Args:
            action: Type of healing action
            component: Target component
            
        Returns:
            Tuple of (allowed, reason)
        """
        key = f"{action.value}:{component.value}"
        now = datetime.now()
        
        with self._lock:
            if key not in self._actions:
                return True, "No previous attempts"
            
            # Clean old entries
            cutoff = now - self.window
            self._actions[key] = [t for t in self._actions[key] if t > cutoff]
            
            if not self._actions[key]:
                return True, "Previous attempts expired"
            
            # Check cooldown (time since last attempt)
            last_attempt = self._actions[key][-1]
            time_since_last = now - last_attempt
            
            if time_since_last < self.cooldown:
                remaining = self.cooldown - time_since_last
                return False, f"Cooldown active: {remaining.seconds}s remaining"
            
            # Check max attempts in window
            if len(self._actions[key]) >= self.max_attempts:
                return False, f"Max attempts ({self.max_attempts}) reached in {self.window.seconds // 60}min window"
            
            return True, "Allowed"
    
    def record_attempt(
        self,
        action: HealActionType,
        component: ComponentType,
    ) -> None:
        """Record a healing attempt."""
        key = f"{action.value}:{component.value}"
        
        with self._lock:
            if key not in self._actions:
                self._actions[key] = []
            self._actions[key].append(datetime.now())
    
    def reset(
        self,
        action: Optional[HealActionType] = None,
        component: Optional[ComponentType] = None,
    ) -> None:
        """
        Reset throttle state.
        
        If action and component provided, resets only that combo.
        Otherwise resets everything.
        """
        with self._lock:
            if action and component:
                key = f"{action.value}:{component.value}"
                self._actions.pop(key, None)
            else:
                self._actions.clear()
    
    def get_status(self) -> Dict[str, Any]:
        """Get throttle status."""
        with self._lock:
            status = {}
            now = datetime.now()
            
            for key, attempts in self._actions.items():
                cutoff = now - self.window
                valid_attempts = [t for t in attempts if t > cutoff]
                
                if valid_attempts:
                    last = valid_attempts[-1]
                    can_act = (now - last) >= self.cooldown and len(valid_attempts) < self.max_attempts
                    
                    status[key] = {
                        "attempts": len(valid_attempts),
                        "max_attempts": self.max_attempts,
                        "last_attempt": last.isoformat(),
                        "can_act": can_act,
                    }
            
            return status


class Healer:
    """
    Automatic System Healer
    =======================
    
    Analyzes health reports and applies appropriate fixes.
    
    Healing Philosophy:
    1. Start with least disruptive action
    2. Log every action with clear reasoning (WHY)
    3. Escalate if automatic fixes fail
    4. Never enter infinite loops
    5. Always explain to user what happened
    
    Usage:
        healer = Healer(agent)
        
        # Manual healing
        actions = healer.heal(health_report)
        
        # Or connect to monitor
        monitor.add_health_change_callback(healer.on_health_change)
    
    Integration:
        The Healer receives HealthReports from the Monitor
        and decides what automatic fixes to apply.
    """
    
    def __init__(
        self,
        agent: Any,  # MainAgent
        logger: Optional[Logger] = None,
        auto_escalate: bool = True,
        cooldown_minutes: int = 5,
        max_attempts: int = 3,
    ):
        """
        Initialize the healer.
        
        Args:
            agent: MainAgent instance
            logger: Optional logger
            auto_escalate: Automatically escalate to user if fixes fail
            cooldown_minutes: Minutes between same healing action
            max_attempts: Max healing attempts before blocking
        """
        self._agent = agent
        self._logger = logger or get_logger("Healer")
        self._auto_escalate = auto_escalate
        
        # Action history
        self._action_history: List[HealAction] = []
        self._max_history = 100  # Keep last 100 actions
        
        # Throttling to prevent healing loops
        self._throttle = HealingThrottle(
            cooldown_minutes=cooldown_minutes,
            max_attempts=max_attempts,
            window_minutes=30,
        )
        
        # User notification callback
        self._notify_user: Optional[Callable[[str, str], None]] = None
        
        # Lock for thread safety
        self._lock = threading.Lock()
        
        # Healing in progress flag
        self._healing_in_progress = False
        
        self._logger.debug("Healer initialized")
    
    def set_user_notifier(
        self,
        callback: Callable[[str, str], None],
    ) -> None:
        """
        Set callback for user notifications.
        
        Callback signature: callback(title: str, message: str)
        """
        self._notify_user = callback
    
    def heal(self, report: HealthReport) -> List[HealAction]:
        """
        Analyze health report and apply fixes.
        
        Main entry point for healing.
        
        Args:
            report: Current health report from monitor
            
        Returns:
            List of actions taken
        """
        # Prevent concurrent healing
        with self._lock:
            if self._healing_in_progress:
                self._logger.warning("Healing already in progress, skipping")
                return []
            self._healing_in_progress = True
        
        try:
            return self._do_heal(report)
        finally:
            with self._lock:
                self._healing_in_progress = False
    
    def _do_heal(self, report: HealthReport) -> List[HealAction]:
        """Internal healing logic."""
        self._logger.info(f"Analyzing health report (status: {report.overall_status.value})")
        
        actions_taken = []
        
        # Only heal if there are problems
        if report.overall_status == HealthStatus.HEALTHY:
            self._logger.debug("System healthy, no healing needed")
            return []
        
        # Get unhealthy components
        unhealthy = report.get_unhealthy_components()
        degraded = report.get_degraded_components()
        
        # Handle critical/unhealthy components first
        for component in unhealthy:
            action = self._heal_component(component, report)
            if action:
                actions_taken.append(action)
        
        # Handle degraded components if no critical issues
        if not unhealthy:
            for component in degraded:
                # Only heal degraded if they've been degraded repeatedly
                if component.consecutive_failures >= 2:
                    action = self._heal_component(component, report)
                    if action:
                        actions_taken.append(action)
        
        # Check if we should escalate
        failed_actions = [a for a in actions_taken if a.result == HealResult.FAILED]
        if failed_actions and self._auto_escalate:
            escalation = self._escalate_to_user(
                failed_actions,
                report,
            )
            actions_taken.append(escalation)
        
        # Trim history
        self._action_history.extend(actions_taken)
        if len(self._action_history) > self._max_history:
            self._action_history = self._action_history[-self._max_history:]
        
        return actions_taken
    
    def _heal_component(
        self,
        component: ComponentHealth,
        report: HealthReport,
    ) -> Optional[HealAction]:
        """
        Determine and execute healing action for a component.
        
        Returns:
            HealAction if action was taken, None otherwise
        """
        # Determine appropriate action
        action = self._determine_action(component, report)
        
        if action.action_type == HealActionType.NO_ACTION:
            return None
        
        # Check throttling
        can_heal, reason = self._throttle.can_heal(
            action.action_type,
            action.component,
        )
        
        if not can_heal:
            self._logger.warning(
                f"Healing blocked for {action.action_type.value}: {reason}"
            )
            action.result = HealResult.BLOCKED
            action.details = f"Throttled: {reason}"
            return action
        
        # Execute the action
        self._logger.info(
            f"Executing healing action: {action.action_type.value}\n"
            f"  Reason: {action.reason}"
        )
        
        result = self._execute_action(action)
        
        # Record attempt in throttle
        self._throttle.record_attempt(action.action_type, action.component)
        
        # Log result
        if result.was_successful:
            self._logger.info(f"Healing SUCCESS: {result.details}")
        else:
            self._logger.warning(f"Healing FAILED: {result.details}")
        
        return result
    
    def _determine_action(
        self,
        component: ComponentHealth,
        report: HealthReport,
    ) -> HealAction:
        """
        Determine the appropriate healing action for a component.
        
        Decision logic considers:
        - Component type
        - Failure count
        - Error type
        - Available resources
        """
        now = datetime.now()
        
        # === OLLAMA SERVICE ===
        if component.component == ComponentType.OLLAMA_SERVICE:
            if component.consecutive_failures >= 3:
                return HealAction(
                    action_type=HealActionType.RESTART_OLLAMA,
                    reason=(
                        f"Ollama has failed {component.consecutive_failures} consecutive checks. "
                        f"Last error: {component.last_error or 'unknown'}. "
                        "Restarting the service may restore connectivity."
                    ),
                    component=component.component,
                    timestamp=now,
                    result=HealResult.SKIPPED,
                    details="Pending execution",
                    before_status=component.status,
                )
            elif component.consecutive_failures >= 1:
                return HealAction(
                    action_type=HealActionType.RETRY_CONNECTION,
                    reason=(
                        f"Ollama failed {component.consecutive_failures} time(s). "
                        "Attempting to re-establish connection before restarting."
                    ),
                    component=component.component,
                    timestamp=now,
                    result=HealResult.SKIPPED,
                    details="Pending execution",
                    before_status=component.status,
                )
        
        # === SYSTEM RESOURCES ===
        elif component.component == ComponentType.SYSTEM_RESOURCES:
            ram_usage = component.metrics.get("ram_usage_percent", 0)
            ram_available = component.metrics.get("ram_available_gb", 0)
            
            if ram_usage >= 95:
                return HealAction(
                    action_type=HealActionType.SWITCH_MODEL,
                    reason=(
                        f"RAM critically low at {ram_usage:.1f}% ({ram_available:.1f}GB free). "
                        "Must switch to a smaller model to prevent system crash."
                    ),
                    component=component.component,
                    timestamp=now,
                    result=HealResult.SKIPPED,
                    details="Pending execution",
                    before_status=component.status,
                )
            elif ram_usage >= 90:
                return HealAction(
                    action_type=HealActionType.CLEAR_CACHE,
                    reason=(
                        f"RAM high at {ram_usage:.1f}% ({ram_available:.1f}GB free). "
                        "Clearing caches to free memory before considering model switch."
                    ),
                    component=component.component,
                    timestamp=now,
                    result=HealResult.SKIPPED,
                    details="Pending execution",
                    before_status=component.status,
                )
            elif ram_usage >= 80:
                return HealAction(
                    action_type=HealActionType.ESCALATE_USER,
                    reason=(
                        f"RAM at {ram_usage:.1f}% ({ram_available:.1f}GB free). "
                        "User should close applications or consider smaller model."
                    ),
                    component=component.component,
                    timestamp=now,
                    result=HealResult.SKIPPED,
                    details="Pending execution",
                    before_status=component.status,
                )
        
        # === MAIN AGENT ===
        elif component.component == ComponentType.MAIN_AGENT:
            if component.status == HealthStatus.CRITICAL:
                return HealAction(
                    action_type=HealActionType.RESTART_AGENT,
                    reason=(
                        f"Agent in CRITICAL state. "
                        f"Error: {component.last_error or 'unknown'}. "
                        "Agent restart is required to restore functionality."
                    ),
                    component=component.component,
                    timestamp=now,
                    result=HealResult.SKIPPED,
                    details="Pending execution",
                    before_status=component.status,
                )
            elif component.status == HealthStatus.UNHEALTHY:
                return HealAction(
                    action_type=HealActionType.ESCALATE_USER,
                    reason=(
                        f"Agent UNHEALTHY but not critical. "
                        "User intervention recommended."
                    ),
                    component=component.component,
                    timestamp=now,
                    result=HealResult.SKIPPED,
                    details="Pending execution",
                    before_status=component.status,
                )
        
        # === PLANNER ===
        elif component.component == ComponentType.PLANNER:
            if component.status in (HealthStatus.UNHEALTHY, HealthStatus.CRITICAL):
                return HealAction(
                    action_type=HealActionType.RETRY_CONNECTION,
                    reason=(
                        "Planner unhealthy, likely due to Ollama connection. "
                        "Attempting to re-initialize planner."
                    ),
                    component=component.component,
                    timestamp=now,
                    result=HealResult.SKIPPED,
                    details="Pending execution",
                    before_status=component.status,
                )
        
        # === DEFAULT: NO ACTION ===
        return HealAction(
            action_type=HealActionType.NO_ACTION,
            reason="No automatic fix available for this condition",
            component=component.component,
            timestamp=now,
            result=HealResult.SKIPPED,
            details="No action needed or possible",
            before_status=component.status,
        )
    
    def _execute_action(self, action: HealAction) -> HealAction:
        """
        Execute a healing action.
        
        Returns:
            Updated HealAction with result
        """
        start_time = time.time()
        
        try:
            if action.action_type == HealActionType.RESTART_OLLAMA:
                result, details = self._restart_ollama()
                
            elif action.action_type == HealActionType.SWITCH_MODEL:
                result, details = self._switch_to_lighter_model()
                
            elif action.action_type == HealActionType.CLEAR_CACHE:
                result, details = self._clear_caches()
                
            elif action.action_type == HealActionType.RETRY_CONNECTION:
                result, details = self._retry_connection(action.component)
                
            elif action.action_type == HealActionType.RESTART_AGENT:
                result, details = self._request_agent_restart()
                
            elif action.action_type == HealActionType.ESCALATE_USER:
                result, details = HealResult.SUCCESS, "Escalated to user"
                self._do_escalate(action.reason)
                
            else:
                result = HealResult.SKIPPED
                details = "No action taken"
            
            action.result = result
            action.details = details
            
        except Exception as e:
            action.result = HealResult.FAILED
            action.details = f"Exception: {str(e)}"
            self._logger.error(f"Healing action exception: {e}")
        
        action.duration_ms = (time.time() - start_time) * 1000
        return action
    
    def _restart_ollama(self) -> Tuple[HealResult, str]:
        """
        Attempt to restart Ollama service.
        
        Tries multiple methods based on OS.
        """
        self._logger.info("Attempting to restart Ollama service...")
        
        system = platform.system()
        
        try:
            if system == "Linux":
                # Try systemctl first (most common on Linux)
                try:
                    result = subprocess.run(
                        ["systemctl", "restart", "ollama"],
                        capture_output=True,
                        text=True,
                        timeout=30,
                    )
                    
                    if result.returncode == 0:
                        time.sleep(5)  # Wait for service to start
                        return HealResult.SUCCESS, "Ollama restarted via systemctl"
                    else:
                        self._logger.debug(f"systemctl failed: {result.stderr}")
                except FileNotFoundError:
                    self._logger.debug("systemctl not found")
                
                # Fallback: kill and restart manually
                try:
                    subprocess.run(["pkill", "-f", "ollama serve"], timeout=5)
                    time.sleep(2)
                    
                    # Start ollama serve in background
                    subprocess.Popen(
                        ["ollama", "serve"],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        start_new_session=True,
                    )
                    time.sleep(5)
                    return HealResult.SUCCESS, "Ollama restarted manually (pkill + serve)"
                except Exception as e:
                    return HealResult.FAILED, f"Manual restart failed: {e}"
            
            elif system == "Darwin":  # macOS
                try:
                    subprocess.run(["pkill", "-f", "ollama"], timeout=5)
                    time.sleep(2)
                    
                    subprocess.Popen(
                        ["ollama", "serve"],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                    )
                    time.sleep(5)
                    return HealResult.SUCCESS, "Ollama restarted on macOS"
                except Exception as e:
                    return HealResult.FAILED, f"macOS restart failed: {e}"
            
            elif system == "Windows":
                try:
                    subprocess.run(
                        ["taskkill", "/F", "/IM", "ollama.exe"],
                        capture_output=True,
                        timeout=10,
                    )
                    time.sleep(2)
                    
                    subprocess.Popen(
                        ["ollama", "serve"],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        creationflags=subprocess.CREATE_NEW_CONSOLE,
                    )
                    time.sleep(5)
                    return HealResult.SUCCESS, "Ollama restarted on Windows"
                except Exception as e:
                    return HealResult.FAILED, f"Windows restart failed: {e}"
            
            else:
                return HealResult.FAILED, f"Unsupported OS: {system}"
            
        except subprocess.TimeoutExpired:
            return HealResult.FAILED, "Restart command timed out"
        except Exception as e:
            return HealResult.FAILED, f"Restart error: {str(e)}"
    
    def _switch_to_lighter_model(self) -> Tuple[HealResult, str]:
        """
        Switch to a lighter/smaller model.
        
        This reduces memory usage.
        """
        self._logger.info("Attempting to switch to lighter model...")
        
        try:
            # Get model manager from agent
            model_manager = getattr(self._agent, '_model_manager', None)
            if not model_manager:
                return HealResult.FAILED, "Model manager not available"
            
            # Get current model
            current_model = getattr(self._agent, 'selected_model', None)
            current_name = current_model.name if current_model else "unknown"
            
            # Find a safer model
            try:
                models = model_manager.get_installed_models()
                safe_models = [m for m in models if m.safety_level.value == "SAFE"]
                
                if not safe_models:
                    return HealResult.FAILED, "No safe models available"
                
                # Pick the smallest safe model
                lightest = min(safe_models, key=lambda m: m.ram_required_gb)
                
                if lightest.name == current_name:
                    return HealResult.PARTIAL, f"Already using lightest model: {current_name}"
                
                # Update the client with new model
                ollama_client = getattr(self._agent, '_ollama_client', None)
                if ollama_client:
                    ollama_client.model = lightest.name
                    self._agent._selected_model = lightest
                    
                    return HealResult.SUCCESS, f"Switched from {current_name} to {lightest.name}"
                else:
                    return HealResult.FAILED, "Ollama client not available"
                    
            except Exception as e:
                return HealResult.FAILED, f"Model switch error: {e}"
            
        except Exception as e:
            return HealResult.FAILED, f"Switch model error: {str(e)}"
    
    def _clear_caches(self) -> Tuple[HealResult, str]:
        """
        Clear memory caches to free RAM.
        """
        self._logger.info("Clearing caches...")
        
        cleared = []
        
        try:
            # Clear Ollama client history
            ollama_client = getattr(self._agent, '_ollama_client', None)
            if ollama_client:
                ollama_client.clear_history()
                cleared.append("ollama_history")
            
            # Force garbage collection
            import gc
            gc.collect()
            cleared.append("gc")
            
            if cleared:
                return HealResult.SUCCESS, f"Cleared: {', '.join(cleared)}"
            else:
                return HealResult.PARTIAL, "No caches to clear"
                
        except Exception as e:
            return HealResult.FAILED, f"Cache clear error: {str(e)}"
    
    def _retry_connection(
        self,
        component: ComponentType,
    ) -> Tuple[HealResult, str]:
        """
        Retry connection to a component.
        """
        self._logger.info(f"Retrying connection to {component.value}...")
        
        try:
            if component == ComponentType.OLLAMA_SERVICE:
                ollama_client = getattr(self._agent, '_ollama_client', None)
                if ollama_client:
                    success, msg = ollama_client.test_connection()
                    if success:
                        return HealResult.SUCCESS, "Ollama connection restored"
                    else:
                        return HealResult.FAILED, f"Connection still failing: {msg}"
                else:
                    return HealResult.FAILED, "No Ollama client"
            
            elif component == ComponentType.PLANNER:
                planner = getattr(self._agent, '_planner', None)
                if planner:
                    # Re-initialize planner
                    ollama_client = getattr(self._agent, '_ollama_client', None)
                    planner.initialize(ollama_client)
                    
                    if planner.is_ready:
                        return HealResult.SUCCESS, "Planner re-initialized"
                    else:
                        return HealResult.PARTIAL, "Planner initialized without LLM"
                else:
                    return HealResult.FAILED, "No planner instance"
            
            else:
                return HealResult.SKIPPED, f"No retry logic for {component.value}"
                
        except Exception as e:
            return HealResult.FAILED, f"Retry error: {str(e)}"
    
    def _request_agent_restart(self) -> Tuple[HealResult, str]:
        """
        Request agent restart.
        
        This is a soft restart - stops and signals for restart.
        """
        self._logger.warning("Agent restart requested")
        
        try:
            # Notify user first
            self._do_escalate(
                "Agent restart required. The system will attempt to restart automatically."
            )
            
            # Set flag for restart (main loop should check this)
            # We can't directly restart from here
            
            return HealResult.PARTIAL, "Restart requested - requires external action"
            
        except Exception as e:
            return HealResult.FAILED, f"Restart request error: {str(e)}"
    
    def _escalate_to_user(
        self,
        failed_actions: List[HealAction],
        report: HealthReport,
    ) -> HealAction:
        """
        Escalate to user when auto-fixes fail.
        """
        now = datetime.now()
        
        # Build escalation message
        message_parts = [
            "Automatic healing failed for the following issues:",
            "",
        ]
        
        for action in failed_actions:
            message_parts.append(f"• {action.component.value}: {action.details}")
        
        message_parts.extend([
            "",
            "Recommendations:",
        ])
        
        for rec in report.recommendations:
            message_parts.append(f"→ {rec}")
        
        message = "\n".join(message_parts)
        
        self._do_escalate(message)
        
        return HealAction(
            action_type=HealActionType.ESCALATE_USER,
            reason=f"Auto-healing failed for {len(failed_actions)} action(s)",
            component=failed_actions[0].component if failed_actions else ComponentType.MAIN_AGENT,
            timestamp=now,
            result=HealResult.SUCCESS,
            details="User notified of issues",
        )
    
    def _do_escalate(self, message: str) -> None:
        """
        Actually send notification to user.
        """
        self._logger.warning(f"ESCALATION TO USER:\n{message}")
        
        if self._notify_user:
            try:
                self._notify_user("System Health Alert", message)
            except Exception as e:
                self._logger.error(f"Failed to notify user: {e}")
    
    def on_health_change(self, report: HealthReport) -> None:
        """
        Callback for health monitor.
        
        Connect this to HealthMonitor.add_health_change_callback()
        """
        if report.needs_healing:
            self.heal(report)
    
    def get_action_history(
        self,
        limit: int = 20,
        component: Optional[ComponentType] = None,
    ) -> List[HealAction]:
        """
        Get recent healing actions.
        
        Args:
            limit: Maximum actions to return
            component: Filter by component (optional)
        """
        history = self._action_history[-limit:]
        
        if component:
            history = [a for a in history if a.component == component]
        
        return history
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get healing statistics."""
        total = len(self._action_history)
        successful = len([a for a in self._action_history if a.was_successful])
        failed = len([a for a in self._action_history if a.result == HealResult.FAILED])
        blocked = len([a for a in self._action_history if a.result == HealResult.BLOCKED])
        
        # Count by action type
        by_action = {}
        for action in self._action_history:
            key = action.action_type.value
            if key not in by_action:
                by_action[key] = {"total": 0, "success": 0, "failed": 0}
            by_action[key]["total"] += 1
            if action.was_successful:
                by_action[key]["success"] += 1
            elif action.result == HealResult.FAILED:
                by_action[key]["failed"] += 1
        
        return {
            "total_actions": total,
            "successful": successful,
            "failed": failed,
            "blocked": blocked,
            "success_rate": (successful / total * 100) if total > 0 else 0,
            "by_action_type": by_action,
            "throttle_status": self._throttle.get_status(),
        }
    
    def reset_throttle(self) -> None:
        """Reset all throttle limits."""
        self._throttle.reset()
        self._logger.info("Healer throttle reset")
    
    @property
    def is_healing(self) -> bool:
        """Check if healing is currently in progress."""
        return self._healing_in_progress
    
    def __repr__(self) -> str:
        return (
            f"Healer(actions={len(self._action_history)}, "
            f"healing={self._healing_in_progress})"
        )
