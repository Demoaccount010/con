"""
Health Monitor
==============
Monitors the health of all system components.

Tracks:
- Main agent health and state
- Ollama availability and responsiveness
- Planner functionality
- System resources (RAM, CPU)
- Failure patterns and trends

Provides health reports that the Healer uses to decide
if automatic fixes are needed.

Design Principles:
- Non-blocking: Monitoring runs in background thread
- Lightweight: Minimal resource usage for checks
- Comprehensive: Covers all critical components
- Actionable: Reports include fix recommendations
"""

import time
import threading
from typing import Dict, Any, Optional, List, Callable
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta
from collections import deque

# Import from PART-1A
from main_agent.core.errors import (
    AgentError,
    ErrorCategory,
    ErrorSeverity,
    format_error_response,
)
from main_agent.utils.logger import Logger, get_logger
from main_agent.utils.system import get_system_info, SystemInfo


class HealthStatus(Enum):
    """
    Overall health status levels.
    
    HEALTHY   - Everything working normally
    DEGRADED  - Some issues, but functional
    UNHEALTHY - Major issues, intervention needed
    CRITICAL  - System failing, immediate action required
    UNKNOWN   - Cannot determine status
    """
    HEALTHY = "HEALTHY"
    DEGRADED = "DEGRADED"
    UNHEALTHY = "UNHEALTHY"
    CRITICAL = "CRITICAL"
    UNKNOWN = "UNKNOWN"


class ComponentType(Enum):
    """
    Types of components being monitored.
    
    Each component type has specific health check logic.
    """
    MAIN_AGENT = "MAIN_AGENT"
    OLLAMA_SERVICE = "OLLAMA"
    PLANNER = "PLANNER"
    SYSTEM_RESOURCES = "SYSTEM"
    WORKER_POOL = "WORKERS"


@dataclass
class ComponentHealth:
    """
    Health status of a single component.
    
    Contains current status, metrics, and failure history.
    """
    component: ComponentType
    status: HealthStatus
    message: str
    last_check: datetime
    metrics: Dict[str, Any] = field(default_factory=dict)
    consecutive_failures: int = 0
    last_error: Optional[str] = None
    last_success: Optional[datetime] = None
    check_duration_ms: float = 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "component": self.component.value,
            "status": self.status.value,
            "message": self.message,
            "last_check": self.last_check.isoformat(),
            "consecutive_failures": self.consecutive_failures,
            "metrics": self.metrics,
            "last_error": self.last_error,
            "last_success": self.last_success.isoformat() if self.last_success else None,
            "check_duration_ms": round(self.check_duration_ms, 2),
        }
    
    @property
    def is_healthy(self) -> bool:
        """Check if component is healthy."""
        return self.status == HealthStatus.HEALTHY
    
    @property
    def needs_attention(self) -> bool:
        """Check if component needs attention."""
        return self.status in (HealthStatus.UNHEALTHY, HealthStatus.CRITICAL)


@dataclass
class HealthReport:
    """
    Complete health report for the system.
    
    Aggregates health status of all components and provides
    overall system health assessment.
    """
    overall_status: HealthStatus
    components: List[ComponentHealth]
    timestamp: datetime
    uptime_seconds: float
    recommendations: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "overall_status": self.overall_status.value,
            "components": [c.to_dict() for c in self.components],
            "timestamp": self.timestamp.isoformat(),
            "uptime_seconds": round(self.uptime_seconds, 2),
            "recommendations": self.recommendations,
            "warnings": self.warnings,
            "summary": {
                "total_components": len(self.components),
                "healthy": len([c for c in self.components if c.status == HealthStatus.HEALTHY]),
                "degraded": len([c for c in self.components if c.status == HealthStatus.DEGRADED]),
                "unhealthy": len([c for c in self.components if c.status == HealthStatus.UNHEALTHY]),
                "critical": len([c for c in self.components if c.status == HealthStatus.CRITICAL]),
            },
        }
    
    def get_unhealthy_components(self) -> List[ComponentHealth]:
        """Get list of components that are not healthy."""
        return [
            c for c in self.components 
            if c.status in (HealthStatus.UNHEALTHY, HealthStatus.CRITICAL)
        ]
    
    def get_degraded_components(self) -> List[ComponentHealth]:
        """Get list of degraded components."""
        return [c for c in self.components if c.status == HealthStatus.DEGRADED]
    
    def get_component(self, comp_type: ComponentType) -> Optional[ComponentHealth]:
        """Get health of specific component."""
        for c in self.components:
            if c.component == comp_type:
                return c
        return None
    
    @property
    def is_system_healthy(self) -> bool:
        """Check if overall system is healthy."""
        return self.overall_status == HealthStatus.HEALTHY
    
    @property
    def needs_healing(self) -> bool:
        """Check if system needs healing intervention."""
        return self.overall_status in (HealthStatus.UNHEALTHY, HealthStatus.CRITICAL)
    
    def __str__(self) -> str:
        """Human-readable string representation."""
        status_icons = {
            HealthStatus.HEALTHY: "✓",
            HealthStatus.DEGRADED: "⚠",
            HealthStatus.UNHEALTHY: "✗",
            HealthStatus.CRITICAL: "☠",
            HealthStatus.UNKNOWN: "?",
        }
        
        lines = [
            "",
            "=" * 60,
            f"HEALTH REPORT - {self.overall_status.value} {status_icons.get(self.overall_status, '')}",
            f"Time: {self.timestamp.strftime('%Y-%m-%d %H:%M:%S')}",
            f"Uptime: {self._format_uptime()}",
            "=" * 60,
            "",
            "Components:",
        ]
        
        for comp in self.components:
            icon = status_icons.get(comp.status, "?")
            lines.append(f"  {icon} {comp.component.value}: {comp.message}")
            if comp.last_error:
                lines.append(f"      Last error: {comp.last_error[:50]}...")
            if comp.consecutive_failures > 0:
                lines.append(f"      Consecutive failures: {comp.consecutive_failures}")
        
        if self.warnings:
            lines.extend(["", "Warnings:"])
            for warn in self.warnings:
                lines.append(f"  ⚠ {warn}")
        
        if self.recommendations:
            lines.extend(["", "Recommendations:"])
            for rec in self.recommendations:
                lines.append(f"  → {rec}")
        
        lines.append("")
        lines.append("=" * 60)
        return "\n".join(lines)
    
    def _format_uptime(self) -> str:
        """Format uptime in human-readable form."""
        seconds = int(self.uptime_seconds)
        if seconds < 60:
            return f"{seconds}s"
        elif seconds < 3600:
            return f"{seconds // 60}m {seconds % 60}s"
        else:
            hours = seconds // 3600
            minutes = (seconds % 3600) // 60
            return f"{hours}h {minutes}m"


class FailureTracker:
    """
    Tracks failure patterns over time.
    
    Used to detect recurring issues that need attention.
    Helps distinguish between transient errors and persistent problems.
    """
    
    def __init__(
        self,
        window_minutes: int = 10,
        threshold: int = 3,
    ):
        """
        Initialize failure tracker.
        
        Args:
            window_minutes: Time window to track failures
            threshold: Number of failures to trigger concern
        """
        self.window = timedelta(minutes=window_minutes)
        self.threshold = threshold
        self._failures: Dict[str, deque] = {}
        self._successes: Dict[str, datetime] = {}
        self._lock = threading.Lock()
    
    def record_failure(self, component: str, error: str) -> int:
        """
        Record a failure for a component.
        
        Args:
            component: Component identifier
            error: Error message
            
        Returns:
            Current failure count in window
        """
        with self._lock:
            if component not in self._failures:
                self._failures[component] = deque()
            
            self._failures[component].append({
                "time": datetime.now(),
                "error": error,
            })
            
            self._clean_old_entries(component)
            return len(self._failures[component])
    
    def record_success(self, component: str) -> None:
        """
        Record a success for a component.
        
        Args:
            component: Component identifier
        """
        with self._lock:
            self._successes[component] = datetime.now()
    
    def get_failure_count(self, component: str) -> int:
        """Get number of failures in the current window."""
        with self._lock:
            self._clean_old_entries(component)
            return len(self._failures.get(component, []))
    
    def is_failing_repeatedly(self, component: str) -> bool:
        """Check if component is failing repeatedly."""
        return self.get_failure_count(component) >= self.threshold
    
    def get_recent_errors(self, component: str, limit: int = 5) -> List[str]:
        """Get list of recent error messages."""
        with self._lock:
            self._clean_old_entries(component)
            failures = list(self._failures.get(component, []))
            return [f["error"] for f in failures[-limit:]]
    
    def get_last_success(self, component: str) -> Optional[datetime]:
        """Get timestamp of last successful check."""
        return self._successes.get(component)
    
    def get_failure_rate(self, component: str, total_checks: int) -> float:
        """
        Calculate failure rate as percentage.
        
        Args:
            component: Component identifier
            total_checks: Total number of checks performed
            
        Returns:
            Failure rate as percentage (0-100)
        """
        if total_checks <= 0:
            return 0.0
        failure_count = self.get_failure_count(component)
        return (failure_count / total_checks) * 100
    
    def clear(self, component: Optional[str] = None) -> None:
        """Clear failure history."""
        with self._lock:
            if component:
                self._failures.pop(component, None)
                self._successes.pop(component, None)
            else:
                self._failures.clear()
                self._successes.clear()
    
    def _clean_old_entries(self, component: str) -> None:
        """Remove entries outside the time window."""
        if component not in self._failures:
            return
        
        cutoff = datetime.now() - self.window
        while self._failures[component] and self._failures[component][0]["time"] < cutoff:
            self._failures[component].popleft()
    
    def get_summary(self) -> Dict[str, Any]:
        """Get summary of all tracked components."""
        with self._lock:
            summary = {}
            for component in set(list(self._failures.keys()) + list(self._successes.keys())):
                self._clean_old_entries(component)
                summary[component] = {
                    "failures_in_window": len(self._failures.get(component, [])),
                    "is_failing": self.is_failing_repeatedly(component),
                    "last_success": self._successes.get(component).isoformat() if component in self._successes else None,
                }
            return summary


class HealthMonitor:
    """
    System Health Monitor
    =====================
    
    Continuously monitors the health of all system components.
    
    Features:
    - Periodic background health checks
    - Failure pattern detection
    - Resource usage monitoring
    - Health report generation
    - Callback notifications on health changes
    
    Usage:
        monitor = HealthMonitor(agent)
        monitor.start()
        
        # Get current health
        report = monitor.get_health_report()
        print(report)
        
        # Stop monitoring
        monitor.stop()
    
    Integration with Healer:
        The monitor generates HealthReports that the Healer
        analyzes to determine if automatic fixes are needed.
    """
    
    # Resource thresholds
    RAM_WARNING_PERCENT = 75.0
    RAM_CRITICAL_PERCENT = 90.0
    RAM_EMERGENCY_PERCENT = 95.0
    
    # Check timing
    DEFAULT_CHECK_INTERVAL = 30  # seconds
    MIN_CHECK_INTERVAL = 5
    MAX_CHECK_INTERVAL = 300
    
    def __init__(
        self,
        agent: Any,  # MainAgent - avoid circular import
        check_interval_sec: int = DEFAULT_CHECK_INTERVAL,
        logger: Optional[Logger] = None,
    ):
        """
        Initialize the health monitor.
        
        Args:
            agent: MainAgent instance to monitor
            check_interval_sec: Seconds between health checks
            logger: Optional logger instance
        """
        self._agent = agent
        self._check_interval = max(
            self.MIN_CHECK_INTERVAL,
            min(check_interval_sec, self.MAX_CHECK_INTERVAL)
        )
        self._logger = logger or get_logger("HealthMonitor")
        
        # State
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._start_time: Optional[datetime] = None
        self._check_count = 0
        self._last_check_time: Optional[datetime] = None
        
        # Component health cache
        self._component_health: Dict[ComponentType, ComponentHealth] = {}
        self._health_lock = threading.Lock()
        
        # Failure tracking
        self._failure_tracker = FailureTracker(
            window_minutes=10,
            threshold=3,
        )
        
        # Previous health status for change detection
        self._previous_status: Optional[HealthStatus] = None
        
        # Callbacks for health changes
        self._on_health_change: List[Callable[[HealthReport], None]] = []
        self._on_critical: List[Callable[[HealthReport], None]] = []
        
        self._logger.debug(
            f"HealthMonitor initialized (interval: {self._check_interval}s)"
        )
    
    def start(self) -> None:
        """Start background health monitoring."""
        if self._running:
            self._logger.warning("Monitor already running")
            return
        
        self._running = True
        self._start_time = datetime.now()
        self._check_count = 0
        
        # Run initial check synchronously
        self._run_health_checks()
        
        # Start background thread
        self._thread = threading.Thread(
            target=self._monitor_loop,
            name="HealthMonitor",
            daemon=True,
        )
        self._thread.start()
        
        self._logger.info(
            f"Health monitoring started (interval: {self._check_interval}s)"
        )
    
    def stop(self) -> None:
        """Stop background health monitoring."""
        if not self._running:
            return
        
        self._running = False
        
        if self._thread:
            self._thread.join(timeout=self._check_interval + 5)
            if self._thread.is_alive():
                self._logger.warning("Monitor thread did not stop cleanly")
        
        self._thread = None
        self._logger.info("Health monitoring stopped")
    
    def _monitor_loop(self) -> None:
        """Background monitoring loop."""
        while self._running:
            try:
                # Wait for interval (in small chunks for quick shutdown)
                for _ in range(self._check_interval):
                    if not self._running:
                        return
                    time.sleep(1)
                
                if self._running:
                    self._run_health_checks()
                    
            except Exception as e:
                self._logger.error(f"Health check loop error: {e}")
                # Continue monitoring even if one check fails
                time.sleep(5)
    
    def _run_health_checks(self) -> None:
        """Run all health checks."""
        self._logger.debug("Running health checks...")
        check_start = time.time()
        
        try:
            # Check each component
            self._check_agent_health()
            self._check_ollama_health()
            self._check_planner_health()
            self._check_system_resources()
            
            self._check_count += 1
            self._last_check_time = datetime.now()
            
            # Generate report
            report = self.get_health_report()
            
            # Check for status change
            if self._previous_status != report.overall_status:
                self._logger.info(
                    f"Health status changed: {self._previous_status} → {report.overall_status.value}"
                )
                self._notify_health_change(report)
                self._previous_status = report.overall_status
            
            # Check for critical status
            if report.overall_status == HealthStatus.CRITICAL:
                self._notify_critical(report)
            
            check_duration = (time.time() - check_start) * 1000
            self._logger.debug(
                f"Health checks completed in {check_duration:.1f}ms"
            )
            
        except Exception as e:
            self._logger.error(f"Health check error: {e}")
    
    def _check_agent_health(self) -> None:
        """Check main agent health."""
        component = ComponentType.MAIN_AGENT
        start_time = time.time()
        
        try:
            # Check agent state
            agent_state = self._agent.state.value
            is_ready = self._agent.is_ready
            
            if is_ready:
                self._update_health(
                    component=component,
                    status=HealthStatus.HEALTHY,
                    message=f"Agent running ({agent_state})",
                    metrics={
                        "state": agent_state,
                        "uptime_sec": self._get_agent_uptime(),
                    },
                    duration_ms=(time.time() - start_time) * 1000,
                )
            elif agent_state in ("STARTING", "INITIALIZING"):
                self._update_health(
                    component=component,
                    status=HealthStatus.DEGRADED,
                    message=f"Agent starting ({agent_state})",
                    metrics={"state": agent_state},
                    duration_ms=(time.time() - start_time) * 1000,
                )
            elif agent_state in ("STOPPING", "STOPPED"):
                self._update_health(
                    component=component,
                    status=HealthStatus.DEGRADED,
                    message=f"Agent stopped ({agent_state})",
                    metrics={"state": agent_state},
                    duration_ms=(time.time() - start_time) * 1000,
                )
            else:
                self._update_health(
                    component=component,
                    status=HealthStatus.UNHEALTHY,
                    message=f"Agent in unexpected state ({agent_state})",
                    metrics={"state": agent_state},
                    duration_ms=(time.time() - start_time) * 1000,
                )
                
        except Exception as e:
            self._record_check_failure(
                component,
                str(e),
                (time.time() - start_time) * 1000
            )
    
    def _check_ollama_health(self) -> None:
        """Check Ollama service health."""
        component = ComponentType.OLLAMA_SERVICE
        start_time = time.time()
        
        try:
            # Check if Ollama client exists and is responsive
            ollama_client = getattr(self._agent, 'ollama_client', None)
            selected_model = getattr(self._agent, 'selected_model', None)
            
            if not ollama_client:
                self._update_health(
                    component=component,
                    status=HealthStatus.UNKNOWN,
                    message="Ollama client not initialized",
                    metrics={},
                    duration_ms=(time.time() - start_time) * 1000,
                )
                return
            
            # Test connection
            success, message = ollama_client.test_connection()
            
            if success:
                model_name = selected_model.name if selected_model else "unknown"
                self._update_health(
                    component=component,
                    status=HealthStatus.HEALTHY,
                    message=f"Ollama responding (model: {model_name})",
                    metrics={
                        "model": model_name,
                        "api_url": ollama_client.api_url,
                    },
                    duration_ms=(time.time() - start_time) * 1000,
                )
            else:
                self._record_check_failure(
                    component,
                    message,
                    (time.time() - start_time) * 1000
                )
                
        except Exception as e:
            self._record_check_failure(
                component,
                str(e),
                (time.time() - start_time) * 1000
            )
    
    def _check_planner_health(self) -> None:
        """Check planner health."""
        component = ComponentType.PLANNER
        start_time = time.time()
        
        try:
            planner = getattr(self._agent, 'planner', None)
            
            if not planner:
                self._update_health(
                    component=component,
                    status=HealthStatus.UNKNOWN,
                    message="Planner not initialized",
                    metrics={},
                    duration_ms=(time.time() - start_time) * 1000,
                )
                return
            
            if planner.is_ready:
                status = planner.status
                self._update_health(
                    component=component,
                    status=HealthStatus.HEALTHY,
                    message=f"Planner ready (LLM: {'yes' if status.get('llm_available') else 'no'})",
                    metrics={
                        "llm_available": status.get("llm_available", False),
                        "plans_created": status.get("statistics", {}).get("plans_created", 0),
                    },
                    duration_ms=(time.time() - start_time) * 1000,
                )
            else:
                self._update_health(
                    component=component,
                    status=HealthStatus.DEGRADED,
                    message="Planner not ready",
                    metrics={},
                    duration_ms=(time.time() - start_time) * 1000,
                )
                
        except Exception as e:
            self._record_check_failure(
                component,
                str(e),
                (time.time() - start_time) * 1000
            )
    
    def _check_system_resources(self) -> None:
        """Check system resource usage."""
        component = ComponentType.SYSTEM_RESOURCES
        start_time = time.time()
        
        try:
            system = get_system_info()
            
            metrics = {
                "ram_total_gb": round(system.total_ram_gb, 2),
                "ram_available_gb": round(system.available_ram_gb, 2),
                "ram_usage_percent": round(system.ram_usage_percent, 1),
                "cpu_cores": system.cpu_cores,
            }
            
            ram_percent = system.ram_usage_percent
            
            # Determine status based on RAM usage
            if ram_percent >= self.RAM_EMERGENCY_PERCENT:
                self._update_health(
                    component=component,
                    status=HealthStatus.CRITICAL,
                    message=f"RAM EMERGENCY: {ram_percent:.1f}% used ({system.available_ram_gb:.1f}GB free)",
                    metrics=metrics,
                    duration_ms=(time.time() - start_time) * 1000,
                )
            elif ram_percent >= self.RAM_CRITICAL_PERCENT:
                self._update_health(
                    component=component,
                    status=HealthStatus.UNHEALTHY,
                    message=f"RAM critical: {ram_percent:.1f}% used ({system.available_ram_gb:.1f}GB free)",
                    metrics=metrics,
                    duration_ms=(time.time() - start_time) * 1000,
                )
            elif ram_percent >= self.RAM_WARNING_PERCENT:
                self._update_health(
                    component=component,
                    status=HealthStatus.DEGRADED,
                    message=f"RAM high: {ram_percent:.1f}% used ({system.available_ram_gb:.1f}GB free)",
                    metrics=metrics,
                    duration_ms=(time.time() - start_time) * 1000,
                )
            else:
                self._update_health(
                    component=component,
                    status=HealthStatus.HEALTHY,
                    message=f"Resources OK: {system.available_ram_gb:.1f}GB RAM free",
                    metrics=metrics,
                    duration_ms=(time.time() - start_time) * 1000,
                )
                
        except Exception as e:
            self._record_check_failure(
                component,
                str(e),
                (time.time() - start_time) * 1000
            )
    
    def _update_health(
        self,
        component: ComponentType,
        status: HealthStatus,
        message: str,
        metrics: Dict[str, Any],
        duration_ms: float,
    ) -> None:
        """Update health status for a component."""
        now = datetime.now()
        
        # Record success in failure tracker
        if status == HealthStatus.HEALTHY:
            self._failure_tracker.record_success(component.value)
        
        with self._health_lock:
            # Get previous state for comparison
            previous = self._component_health.get(component)
            last_success = now if status == HealthStatus.HEALTHY else (
                previous.last_success if previous else None
            )
            
            self._component_health[component] = ComponentHealth(
                component=component,
                status=status,
                message=message,
                last_check=now,
                metrics=metrics,
                consecutive_failures=0,
                last_error=None,
                last_success=last_success,
                check_duration_ms=duration_ms,
            )
    
    def _record_check_failure(
        self,
        component: ComponentType,
        error: str,
        duration_ms: float,
    ) -> None:
        """Record a health check failure."""
        failure_count = self._failure_tracker.record_failure(component.value, error)
        
        # Determine severity based on failure count
        if failure_count >= 5:
            status = HealthStatus.CRITICAL
        elif failure_count >= 3:
            status = HealthStatus.UNHEALTHY
        else:
            status = HealthStatus.DEGRADED
        
        with self._health_lock:
            previous = self._component_health.get(component)
            
            self._component_health[component] = ComponentHealth(
                component=component,
                status=status,
                message=f"Check failed ({failure_count} failures in window)",
                last_check=datetime.now(),
                metrics={},
                consecutive_failures=failure_count,
                last_error=error[:200] if error else None,  # Truncate long errors
                last_success=previous.last_success if previous else None,
                check_duration_ms=duration_ms,
            )
        
        self._logger.warning(
            f"Health check failed for {component.value}: {error[:100]}"
        )
    
    def _get_agent_uptime(self) -> float:
        """Get agent uptime in seconds."""
        try:
            start_time = getattr(self._agent, '_start_time', None)
            if start_time:
                return (datetime.now() - start_time).total_seconds()
        except:
            pass
        return 0.0
    
    def get_health_report(self) -> HealthReport:
        """
        Generate a complete health report.
        
        Returns:
            HealthReport with all component statuses
        """
        with self._health_lock:
            components = list(self._component_health.values())
        
        # Determine overall status (worst of all components)
        if not components:
            overall = HealthStatus.UNKNOWN
        else:
            status_priority = {
                HealthStatus.CRITICAL: 0,
                HealthStatus.UNHEALTHY: 1,
                HealthStatus.DEGRADED: 2,
                HealthStatus.UNKNOWN: 3,
                HealthStatus.HEALTHY: 4,
            }
            worst = min(components, key=lambda c: status_priority.get(c.status, 5))
            overall = worst.status
        
        # Calculate uptime
        uptime = 0.0
        if self._start_time:
            uptime = (datetime.now() - self._start_time).total_seconds()
        
        # Generate recommendations and warnings
        recommendations = self._generate_recommendations(components)
        warnings = self._generate_warnings(components)
        
        return HealthReport(
            overall_status=overall,
            components=components,
            timestamp=datetime.now(),
            uptime_seconds=uptime,
            recommendations=recommendations,
            warnings=warnings,
        )
    
    def _generate_recommendations(
        self,
        components: List[ComponentHealth],
    ) -> List[str]:
        """Generate fix recommendations based on component health."""
        recommendations = []
        
        for comp in components:
            if comp.status == HealthStatus.HEALTHY:
                continue
            
            if comp.component == ComponentType.OLLAMA_SERVICE:
                if comp.consecutive_failures >= 3:
                    recommendations.append(
                        "Restart Ollama service: 'systemctl restart ollama' or 'ollama serve'"
                    )
                elif comp.consecutive_failures >= 1:
                    recommendations.append(
                        "Check Ollama logs for errors: 'journalctl -u ollama -f'"
                    )
            
            elif comp.component == ComponentType.SYSTEM_RESOURCES:
                ram_usage = comp.metrics.get("ram_usage_percent", 0)
                if ram_usage >= self.RAM_EMERGENCY_PERCENT:
                    recommendations.append(
                        "URGENT: Free RAM immediately - close applications or switch to smaller model"
                    )
                elif ram_usage >= self.RAM_CRITICAL_PERCENT:
                    recommendations.append(
                        "Close unnecessary applications to free RAM"
                    )
                    recommendations.append(
                        "Consider switching to a smaller Ollama model"
                    )
                elif ram_usage >= self.RAM_WARNING_PERCENT:
                    recommendations.append(
                        "Monitor RAM usage - close unused applications"
                    )
            
            elif comp.component == ComponentType.MAIN_AGENT:
                if comp.status == HealthStatus.CRITICAL:
                    recommendations.append(
                        "Agent restart may be required"
                    )
                elif comp.status == HealthStatus.UNHEALTHY:
                    recommendations.append(
                        "Check agent logs for errors"
                    )
            
            elif comp.component == ComponentType.PLANNER:
                if comp.status != HealthStatus.HEALTHY:
                    recommendations.append(
                        "Verify Ollama connection for planner LLM support"
                    )
        
        return recommendations
    
    def _generate_warnings(
        self,
        components: List[ComponentHealth],
    ) -> List[str]:
        """Generate warning messages."""
        warnings = []
        
        # Check for repeated failures
        for comp in components:
            if comp.consecutive_failures >= 2:
                warnings.append(
                    f"{comp.component.value} has failed {comp.consecutive_failures} times"
                )
        
        # Check for stale data
        now = datetime.now()
        for comp in components:
            age = (now - comp.last_check).total_seconds()
            if age > self._check_interval * 3:
                warnings.append(
                    f"{comp.component.value} health data is stale ({int(age)}s old)"
                )
        
        return warnings
    
    def _notify_health_change(self, report: HealthReport) -> None:
        """Notify callbacks of health status change."""
        for callback in self._on_health_change:
            try:
                callback(report)
            except Exception as e:
                self._logger.error(f"Health change callback error: {e}")
    
    def _notify_critical(self, report: HealthReport) -> None:
        """Notify callbacks of critical health status."""
        for callback in self._on_critical:
            try:
                callback(report)
            except Exception as e:
                self._logger.error(f"Critical callback error: {e}")
    
    def add_health_change_callback(
        self,
        callback: Callable[[HealthReport], None],
    ) -> None:
        """
        Add callback for health status changes.
        
        Callback is called whenever overall health status changes.
        """
        self._on_health_change.append(callback)
    
    def add_critical_callback(
        self,
        callback: Callable[[HealthReport], None],
    ) -> None:
        """
        Add callback for critical health status.
        
        Callback is called whenever system reaches CRITICAL status.
        """
        self._on_critical.append(callback)
    
    def force_check(self) -> HealthReport:
        """Force an immediate health check."""
        self._run_health_checks()
        return self.get_health_report()
    
    def get_component_health(self, component: ComponentType) -> Optional[ComponentHealth]:
        """Get health of a specific component."""
        with self._health_lock:
            return self._component_health.get(component)
    
    def get_failure_summary(self) -> Dict[str, Any]:
        """Get failure tracking summary."""
        return self._failure_tracker.get_summary()
    
    @property
    def is_running(self) -> bool:
        """Check if monitor is running."""
        return self._running
    
    @property
    def check_count(self) -> int:
        """Get total number of health checks performed."""
        return self._check_count
    
    @property
    def uptime(self) -> float:
        """Get monitor uptime in seconds."""
        if self._start_time:
            return (datetime.now() - self._start_time).total_seconds()
        return 0.0
    
    def get_status(self) -> Dict[str, Any]:
        """Get monitor status information."""
        return {
            "running": self._running,
            "check_interval_sec": self._check_interval,
            "check_count": self._check_count,
            "uptime_sec": self.uptime,
            "last_check": self._last_check_time.isoformat() if self._last_check_time else None,
            "components_monitored": len(self._component_health),
        }
    
    def __repr__(self) -> str:
        return (
            f"HealthMonitor(running={self._running}, "
            f"checks={self._check_count}, "
            f"interval={self._check_interval}s)"
        )