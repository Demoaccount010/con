"""
Telegram Bot Main Class (Auto-Config Version)
==============================================
Main bot class with automatic configuration.
"""

import os
import asyncio
from typing import Optional, List
from dataclasses import dataclass, field

from telegram import Update, BotCommand
from telegram.ext import (
    Application,
    CommandHandler as TGCommandHandler,
    MessageHandler as TGMessageHandler,
    CallbackQueryHandler,
    filters,
    ContextTypes,
)

from main_agent.utils.logger import Logger, get_logger
from main_agent.telegram.commands import CommandHandler
from main_agent.telegram.handlers import MessageHandler, CallbackHandler
from main_agent.telegram.middleware import AuthMiddleware, RateLimiter
from main_agent.storage.config_store import BotSettings, load_config, save_config


class TelegramBot:
    """
    Main Telegram Bot Class (Auto-Config)
    ======================================
    
    Automatically loads configuration from saved settings.
    Runs setup wizard if no config exists.
    
    Usage:
        from main_agent.telegram import TelegramBot
        from main_agent.telegram.setup import ensure_setup
        
        # This will run setup wizard if needed
        settings = ensure_setup()
        
        # Create and run bot
        bot = TelegramBot(agent=agent, settings=settings)
        bot.run()
    """
    
    def __init__(
        self,
        agent: any,  # MainAgent
        settings: BotSettings,
        logger: Optional[Logger] = None,
    ):
        """
        Initialize the Telegram bot.
        
        Args:
            agent: MainAgent instance
            settings: Bot settings (from setup or config file)
            logger: Optional logger
        """
        self.agent = agent
        self.settings = settings
        self._logger = logger or get_logger("TelegramBot")
        
        # Validate settings
        is_valid, error = settings.is_valid()
        if not is_valid:
            raise ValueError(f"Invalid settings: {error}")
        
        # Initialize middleware
        self.auth = AuthMiddleware(
            admin_ids=settings.admin_ids,
            whitelist_ids=settings.whitelist_ids,
            mode=settings.auth_mode,
            logger=self._logger,
        )
        
        self.rate_limiter = RateLimiter(
            max_requests=settings.rate_limit_messages,
            window_seconds=settings.rate_limit_window,
            logger=self._logger,
        )
        
        # Initialize handlers
        self.command_handler = CommandHandler(
            agent=agent,
            auth_middleware=self.auth,
            rate_limiter=self.rate_limiter,
            logger=self._logger,
        )
        
        self.message_handler = MessageHandler(
            agent=agent,
            auth_middleware=self.auth,
            logger=self._logger,
        )
        
        self.callback_handler = CallbackHandler(
            agent=agent,
            auth_middleware=self.auth,
            message_handler=self.message_handler,
            logger=self._logger,
        )
        
        # Application
        self._app: Optional[Application] = None
        self._running = False
        
        self._logger.info(
            f"TelegramBot initialized (auth_mode={settings.auth_mode}, "
            f"admins={len(settings.admin_ids)})"
        )
    
    def _setup_handlers(self, app: Application) -> None:
        """Setup all message handlers."""
        # Command handlers
        app.add_handler(TGCommandHandler("start", self.command_handler.start_command))
        app.add_handler(TGCommandHandler("help", self.command_handler.help_command))
        app.add_handler(TGCommandHandler("task", self.command_handler.task_command))
        app.add_handler(TGCommandHandler("status", self.command_handler.status_command))
        app.add_handler(TGCommandHandler("workers", self.command_handler.workers_command))
        app.add_handler(TGCommandHandler("history", self.command_handler.history_command))
        app.add_handler(TGCommandHandler("cancel", self.command_handler.cancel_command))
        app.add_handler(TGCommandHandler("admin", self.command_handler.admin_command))
        
        # Callback query handler
        app.add_handler(CallbackQueryHandler(self.callback_handler.handle_callback))
        
        # Message handler
        app.add_handler(TGMessageHandler(
            filters.TEXT & ~filters.COMMAND,
            self.message_handler.handle_message,
        ))
        
        # Unknown command handler
        app.add_handler(TGMessageHandler(
            filters.COMMAND,
            self.command_handler.unknown_command,
        ))
        
        # Error handler
        app.add_error_handler(self._error_handler)
        
        self._logger.debug("All handlers registered")
    
    async def _set_bot_commands(self, app: Application) -> None:
        """Set bot commands for menu."""
        commands = [
            BotCommand("start", "Start the bot"),
            BotCommand("help", "Show help"),
            BotCommand("task", "Create a new task"),
            BotCommand("status", "Check agent status"),
            BotCommand("workers", "List workers"),
            BotCommand("history", "Task history"),
            BotCommand("cancel", "Cancel operation"),
        ]
        
        await app.bot.set_my_commands(commands)
        self._logger.debug("Bot commands set")
    
    async def _error_handler(
        self,
        update: object,
        context: ContextTypes.DEFAULT_TYPE,
    ) -> None:
        """Handle errors."""
        self._logger.error(f"Bot error: {context.error}")
        
        if isinstance(update, Update) and update.effective_message:
            try:
                await update.effective_message.reply_text(
                    "❌ An error occurred. Please try again."
                )
            except:
                pass
    
    async def _post_init(self, app: Application) -> None:
        """Post-initialization hook."""
        await self._set_bot_commands(app)
        
        # Notify admins that bot is online
        for admin_id in self.settings.admin_ids:
            try:
                await app.bot.send_message(
                    chat_id=admin_id,
                    text=(
                        "🤖 *Bot Started!*\n\n"
                        f"Agent: `{self.agent.config.agent.name}`\n"
                        f"Model: `{self.agent.selected_model.name if self.agent.selected_model else 'N/A'}`\n"
                        f"Status: ✅ Ready\n\n"
                        "Send /help for commands."
                    ),
                    parse_mode="Markdown",
                )
            except Exception as e:
                self._logger.warning(f"Could not notify admin {admin_id}: {e}")
        
        self._logger.info("Bot post-init complete")
    
    def run(self) -> None:
        """
        Run the bot (blocking).
        
        Uses polling mode.
        """
        self._logger.info("Starting Telegram bot...")
        
        # Create application
        self._app = (
            Application.builder()
            .token(self.settings.bot_token)
            .post_init(self._post_init)
            .build()
        )
        
        # Setup handlers
        self._setup_handlers(self._app)
        
        self._running = True
        
        # Print startup message
        print(f"""
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║               🤖 TELEGRAM BOT RUNNING 🤖                     ║
║                                                              ║
║   Bot: @{self.settings.bot_username or 'unknown':<43} ║
║   Mode: {self.settings.auth_mode:<45} ║
║   Admins: {len(self.settings.admin_ids):<43} ║
║                                                              ║
║   Press Ctrl+C to stop                                       ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
""")
        
        # Run with polling
        self._logger.info("Bot running with polling mode")
        self._app.run_polling(
            allowed_updates=Update.ALL_TYPES,
            drop_pending_updates=True,
        )
    
    async def run_async(self) -> None:
        """Run the bot asynchronously."""
        self._logger.info("Starting Telegram bot (async)...")
        
        # Create application
        self._app = (
            Application.builder()
            .token(self.settings.bot_token)
            .post_init(self._post_init)
            .build()
        )
        
        # Setup handlers
        self._setup_handlers(self._app)
        
        self._running = True
        
        # Initialize and start
        await self._app.initialize()
        await self._app.start()
        
        # Start polling
        await self._app.updater.start_polling(
            allowed_updates=Update.ALL_TYPES,
            drop_pending_updates=True,
        )
        
        self._logger.info("Bot running (async mode)")
    
    async def stop(self) -> None:
        """Stop the bot."""
        if self._app and self._running:
            self._running = False
            await self._app.updater.stop()
            await self._app.stop()
            await self._app.shutdown()
            self._logger.info("Bot stopped")
    
    def add_to_whitelist(self, user_id: int) -> bool:
        """Add user to whitelist and save."""
        self.auth.add_to_whitelist(user_id)
        
        if user_id not in self.settings.whitelist_ids:
            self.settings.whitelist_ids.append(user_id)
            return save_config(self.settings)
        return True
    
    def remove_from_whitelist(self, user_id: int) -> bool:
        """Remove user from whitelist and save."""
        self.auth.remove_from_whitelist(user_id)
        
        if user_id in self.settings.whitelist_ids:
            self.settings.whitelist_ids.remove(user_id)
            return save_config(self.settings)
        return True
    
    @property
    def is_running(self) -> bool:
        """Check if bot is running."""
        return self._running
    
    def __repr__(self) -> str:
        return (
            f"TelegramBot(running={self._running}, "
            f"auth_mode={self.settings.auth_mode})"
        )