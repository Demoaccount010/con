#!/usr/bin/env python3
"""
🚀 UNIVERSAL LAUNCHER & CONFIGURATOR
====================================
Automates the setup and startup process for the Main AI Agent.

Workflow:
1. Checks Environment (Python, OS)
2. Checks/Installs Dependencies
3. Creates Directory Structure
4. Checks Ollama Status
5. Checks Telegram Config
6. Generates Summary Report
7. Launches Main Agent

Usage:
    python launcher.py
"""

import os
import sys
import subprocess
import time
import shutil
import platform
import socket
from datetime import datetime
from pathlib import Path

# --- Configuration ---
PROJECT_ROOT = Path(__file__).parent.absolute()
MAIN_MODULE = "main_agent.main"
REQUIREMENTS_FILE = PROJECT_ROOT / "main_agent" / "requirements.txt"
CONFIG_DIR = Path.home() / ".main_agent"
CONFIG_FILE = CONFIG_DIR / "config.json"

# --- Colors for Terminal ---
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BOLD = '\033[1m'
    END = '\033[0m'

    @staticmethod
    def disable():
        Colors.HEADER = ''
        Colors.BLUE = ''
        Colors.GREEN = ''
        Colors.YELLOW = ''
        Colors.RED = ''
        Colors.END = ''

if not sys.stdout.isatty():
    Colors.disable()

# --- Helper Functions ---

def print_banner():
    print(f"""{Colors.CYAN}{Colors.BOLD}
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║           🚀 MAIN AGENT - AUTO LAUNCHER 🚀                   ║
║                                                              ║
║      Diagnosing • Configuring • Launching                    ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
{Colors.END}""")

def log_step(message):
    print(f"{Colors.BLUE}ℹ  {message}...{Colors.END}")
    time.sleep(0.5)  # Visual delay

def log_success(message):
    print(f"{Colors.GREEN}✅ {message}{Colors.END}")

def log_fail(message, error=None):
    err_msg = f" - {error}" if error else ""
    print(f"{Colors.RED}❌ {message}{err_msg} (SKIPPING){Colors.END}")

def log_header(title):
    print(f"\n{Colors.HEADER}{Colors.BOLD}=== {title} ==={Colors.END}")

# --- Configuration Steps ---

results = {
    "env": "PENDING",
    "deps": "PENDING",
    "dirs": "PENDING",
    "ollama": "PENDING",
    "telegram": "PENDING",
    "worker_dirs": "PENDING"
}

failed_reasons = []

def step_check_environment():
    """Step 1: Check Python and OS"""
    log_step("Checking System Environment")
    try:
        py_ver = sys.version.split()[0]
        os_info = platform.system() + " " + platform.release()
        
        if sys.version_info < (3, 10):
            raise Exception(f"Python 3.10+ required, found {py_ver}")
            
        log_success(f"Environment OK: Python {py_ver} on {os_info}")
        results["env"] = "SUCCESS"
    except Exception as e:
        log_fail("Environment Check Failed", str(e))
        results["env"] = "FAILED"
        failed_reasons.append(f"Environment: {str(e)}")

def step_install_dependencies():
    """Step 2: Install/Check Requirements"""
    log_step("Checking Dependencies")
    try:
        if not REQUIREMENTS_FILE.exists():
            raise FileNotFoundError(f"{REQUIREMENTS_FILE} not found")

        # Quiet install
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", "-r", str(REQUIREMENTS_FILE)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        log_success("Dependencies installed/verified")
        results["deps"] = "SUCCESS"
    except subprocess.CalledProcessError:
        log_fail("Dependency Installation Failed")
        results["deps"] = "FAILED"
        failed_reasons.append("Dependencies: pip install failed")
    except Exception as e:
        log_fail("Dependency Check Error", str(e))
        results["deps"] = "FAILED"
        failed_reasons.append(f"Dependencies: {str(e)}")

def step_create_directories():
    """Step 3: Create Necessary Directories"""
    log_step("Configuring Directory Structure")
    try:
        dirs = [
            PROJECT_ROOT / "logs",
            CONFIG_DIR,
            PROJECT_ROOT / "worker_agent" / "workspace"
        ]
        
        for d in dirs:
            os.makedirs(d, exist_ok=True)
            
        log_success("Directories created/verified")
        results["dirs"] = "SUCCESS"
    except Exception as e:
        log_fail("Directory Creation Failed", str(e))
        results["dirs"] = "FAILED"
        failed_reasons.append(f"Directories: {str(e)}")

def step_check_ollama():
    """Step 4: Check Ollama Status"""
    log_step("Checking Ollama Service")
    try:
        # Check if ollama binary exists
        if shutil.which("ollama") is None:
            raise FileNotFoundError("Ollama binary not found in PATH")

        # Check connection (quick timeout)
        import urllib.request
        try:
            with urllib.request.urlopen("http://127.0.0.1:11434/api/tags", timeout=2):
                pass
        except:
            raise ConnectionError("Ollama service not responding on port 11434")

        log_success("Ollama is running and reachable")
        results["ollama"] = "SUCCESS"
    except Exception as e:
        log_fail("Ollama Check Failed", str(e))
        results["ollama"] = "FAILED"
        failed_reasons.append(f"Ollama: {str(e)}")

def step_check_telegram_config():
    """Step 5: Check Telegram Configuration"""
    log_step("Checking Telegram Configuration")
    try:
        if not CONFIG_FILE.exists():
            raise FileNotFoundError("Config file missing")
            
        # Basic JSON check
        import json
        with open(CONFIG_FILE, 'r') as f:
            data = json.load(f)
            if not data.get("bot_token") or not data.get("setup_complete"):
                raise ValueError("Config incomplete")
                
        log_success("Telegram configuration found")
        results["telegram"] = "SUCCESS"
    except Exception as e:
        log_fail("Telegram Config Missing/Invalid", str(e))
        results["telegram"] = "FAILED"
        failed_reasons.append("Telegram: Configuration not set up")

def print_summary():
    """Generate Final Report"""
    print(f"\n{Colors.HEADER}══════════════ CONFIGURATION SUMMARY ══════════════{Colors.END}")
    
    for check, status in results.items():
        icon = "✅" if status == "SUCCESS" else "❌"
        color = Colors.GREEN if status == "SUCCESS" else Colors.RED
        print(f"{color}{icon} {check.upper().ljust(15)} : {status}{Colors.END}")
    
    print(f"{Colors.HEADER}═══════════════════════════════════════════════════{Colors.END}")

    if failed_reasons:
        print(f"\n{Colors.YELLOW}⚠️  WARNINGS (The agent will try to start anyway):{Colors.END}")
        for reason in failed_reasons:
            print(f"  • {reason}")
    else:
        print(f"\n{Colors.GREEN}✨ All systems nominal! Ready for launch.{Colors.END}")

def launch_main_agent():
    """Launch the application"""
    print(f"\n{Colors.CYAN}🚀 Launching Main Agent...{Colors.END}")
    time.sleep(1)
    
    # Construct command
    cmd = [sys.executable, "-m", "main_agent.main"]
    
    # Auto-add flags based on config status
    if results["telegram"] == "SUCCESS":
        cmd.append("--telegram")
    elif results["telegram"] == "FAILED":
        print(f"{Colors.YELLOW}ℹ  Telegram config missing. Launching Setup Wizard...{Colors.END}")
        cmd.append("--telegram") # Main logic handles setup wizard automatically
    
    # Add project root to python path
    env = os.environ.copy()
    env["PYTHONPATH"] = str(PROJECT_ROOT)
    
    print(f"{Colors.BLUE}Executing: {' '.join(cmd)}{Colors.END}\n")
    
    try:
        subprocess.run(cmd, env=env)
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}🛑 Stopped by user.{Colors.END}")
    except Exception as e:
        print(f"\n{Colors.RED}🔥 Critical Crash: {e}{Colors.END}")

# --- Main Execution ---

def main():
    print_banner()
    
    # Run Steps Sequence
    step_check_environment()
    step_install_dependencies()
    step_create_directories()
    step_check_ollama()
    step_check_telegram_config()
    
    # Report
    print_summary()
    
    # Launch
    print(f"\n{Colors.BOLD}Starting application in 3 seconds...{Colors.END}")
    try:
        time.sleep(3)
        launch_main_agent()
    except KeyboardInterrupt:
        print("\nLaunch cancelled.")

if __name__ == "__main__":
    main()