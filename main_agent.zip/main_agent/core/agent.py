# FILE: main_agent/core/agent.py

"""
Main Agent (Brain Controller)
==============================
The central lifecycle controller for the AI System.

This is NOT a chatbot - this is an AI SYSTEM CONTROLLER.

Responsibilities:
- Lifecycle management (startup, shutdown)
- System validation
- Ollama service integration
- Model selection and validation
- Planner initialization
- Component coordination
- Error handling
"""

import sys
import signal
import time
from typing import Optional, Dict, Any, Callable, List
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime

# PART-1A imports
from main_agent.config import Config
from main_agent.core.errors import (
    AgentError,
    StartupError,
    ShutdownError,
    SystemCheckError,
    ExternalServiceError,
    ErrorResponse,
    format_error_response,
    ErrorCategory,
    ErrorSeverity,
)
from main_agent.utils.logger import Logger, get_logger
from main_agent.utils.system import (
    get_system_info,
    check_system_requirements,
    SystemInfo,
)

# PART-1B imports
from main_agent.ollama.checker import (
    OllamaChecker,
    OllamaHealthReport,
    OllamaHealthStatus,
    OllamaNotAvailableError,
)
from main_agent.ollama.models import (
    OllamaModelManager,
    ModelInfo,
    ModelSafetyLevel,
    NoModelsFoundError,
    NoSafeModelsError,
)
from main_agent.ollama.client import OllamaClient, create_ollama_client
from main_agent.core.planner import Planner, PlannedTask, PlannerError


class AgentState(Enum):
    """
    Agent Lifecycle States
    ======================
    
    CREATED     → Initial state after instantiation
    INITIALIZING → Loading configuration and dependencies
    STARTING    → Running startup sequence
    READY       → Fully operational
    RUNNING     → Actively processing
    STOPPING    → Shutdown in progress
    STOPPED     → Clean shutdown complete
    FAILED      → Unrecoverable error state
    """
    CREATED = "CREATED"
    INITIALIZING = "INITIALIZING"
    STARTING = "STARTING"
    READY = "READY"
    RUNNING = "RUNNING"
    STOPPING = "STOPPING"
    STOPPED = "STOPPED"
    FAILED = "FAILED"


@dataclass
class StartupCheckResult:
    """Result of a single startup check."""
    name: str
    passed: bool
    message: str
    duration_ms: float
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class StartupReport:
    """Complete startup sequence report."""
    success: bool
    total_duration_ms: float
    checks: List[StartupCheckResult] = field(default_factory=list)
    errors: List[ErrorResponse] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    
    def __str__(self) -> str:
        lines = [
            "\n" + "=" * 60,
            "STARTUP REPORT",
            "=" * 60,
            f"Status: {'SUCCESS' if self.success else 'FAILED'}",
            f"Duration: {self.total_duration_ms:.2f}ms",
            f"Timestamp: {self.timestamp}",
            "-" * 60,
            "Checks:",
        ]
        
        for check in self.checks:
            status = "✓" if check.passed else "✗"
            lines.append(f"  {status} {check.name}: {check.message} ({check.duration_ms:.1f}ms)")
        
        if self.errors:
            lines.extend([
                "-" * 60,
                "Errors:",
            ])
            for error in self.errors:
                lines.append(f"  • {error.reason}")
        
        lines.append("=" * 60 + "\n")
        return "\n".join(lines)


class MainAgent:
    """
    Main AI Agent (Brain Controller)
    =================================
    
    The central controller for the AI system. Manages:
    - Lifecycle (startup, shutdown)
    - System validation
    - Ollama integration
    - Model management
    - Planning engine
    - Component coordination
    - Error handling
    
    This is NOT a chatbot - this is an AI SYSTEM CONTROLLER.
    
    Usage:
        config = Config()
        config.load().validate()
        
        agent = MainAgent(config)
        agent.start()
        
        # Create a plan
        task = agent.plan_task("Create a Python script...")
        print(task.to_json())
        
        agent.stop()
    """
    
    def __init__(self, config: Config, logger: Optional[Logger] = None):
        """
        Initialize the Main Agent.
        
        Args:
            config: Configuration object (must be loaded and validated)
            logger: Optional logger instance (creates default if not provided)
        """
        self._config = config
        self._logger = logger or get_logger(
            name=config.agent.name,
            level=config.logging.level,
            log_dir=config.logging.log_dir,
            log_file=config.logging.log_file,
            console_output=config.logging.console_output,
            file_output=config.logging.file_output,
        )
        
        # State management
        self._state = AgentState.CREATED
        self._state_history: List[tuple] = [(AgentState.CREATED, datetime.now())]
        
        # System info cache
        self._system_info: Optional[SystemInfo] = None
        
        # Ollama components (PART-1B)
        self._ollama_health: Optional[OllamaHealthReport] = None
        self._model_manager: Optional[OllamaModelManager] = None
        self._selected_model: Optional[ModelInfo] = None
        self._ollama_client: Optional[OllamaClient] = None
        
        # Planner (PART-1B)
        self._planner: Optional[Planner] = None
        
        # Shutdown handling
        self._shutdown_requested = False
        self._setup_signal_handlers()
        
        # Startup tracking
        self._startup_report: Optional[StartupReport] = None
        self._start_time: Optional[datetime] = None
        
        self._logger.info(
            f"MainAgent created",
            extra={"version": config.agent.version}
        )
    
    def _setup_signal_handlers(self) -> None:
        """Setup graceful shutdown signal handlers."""
        def signal_handler(signum, frame):
            self._logger.warning(f"Received signal {signum}, initiating shutdown...")
            self._shutdown_requested = True
            self.stop()
        
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
    
    def _set_state(self, new_state: AgentState) -> None:
        """
        Transition to a new state.
        
        Args:
            new_state: The target state
        """
        old_state = self._state
        self._state = new_state
        self._state_history.append((new_state, datetime.now()))
        
        self._logger.debug(
            f"State transition: {old_state.value} → {new_state.value}"
        )
    
    def _run_check(
        self,
        name: str,
        check_fn: Callable[[], bool],
        error_class: type = StartupError,
    ) -> StartupCheckResult:
        """
        Run a single startup check with timing and error handling.
        
        Args:
            name: Name of the check
            check_fn: Function that returns True on success
            error_class: Error class to raise on failure
            
        Returns:
            StartupCheckResult with pass/fail status
        """
        start_time = time.time()
        
        try:
            result = check_fn()
            duration = (time.time() - start_time) * 1000
            
            if result:
                return StartupCheckResult(
                    name=name,
                    passed=True,
                    message="OK",
                    duration_ms=duration,
                )
            else:
                return StartupCheckResult(
                    name=name,
                    passed=False,
                    message="Check returned False",
                    duration_ms=duration,
                )
                
        except AgentError as e:
            duration = (time.time() - start_time) * 1000
            return StartupCheckResult(
                name=name,
                passed=False,
                message=e.reason,
                duration_ms=duration,
                details={"error": e.to_response().to_dict()},
            )
            
        except Exception as e:
            duration = (time.time() - start_time) * 1000
            return StartupCheckResult(
                name=name,
                passed=False,
                message=str(e),
                duration_ms=duration,
                details={"error_type": type(e).__name__},
            )
    
    def _check_system_requirements(self) -> bool:
        """
        Verify system meets minimum requirements.
        
        Raises:
            SystemCheckError: If requirements not met
            
        Returns:
            True if all requirements satisfied
        """
        self._logger.info("Checking system requirements...")
        
        self._system_info = get_system_info()
        
        self._logger.debug(
            f"System info: OS={self._system_info.os_type}, "
            f"RAM={self._system_info.total_ram_gb:.1f}GB, "
            f"CPU={self._system_info.cpu_cores} cores"
        )
        
        check_result = check_system_requirements(
            system_info=self._system_info,
            min_ram_gb=self._config.system_requirements.min_ram_gb,
            min_cpu_cores=self._config.system_requirements.min_cpu_cores,
            supported_os=self._config.system_requirements.supported_os,
        )
        
        if not check_result["passed"]:
            failures = check_result.get("failures", [])
            raise SystemCheckError(
                reason="System requirements not met",
                detail="; ".join(failures),
                suggestion=self._get_system_fix_suggestion(failures),
                context={
                    "system_info": self._system_info.to_dict(),
                    "requirements": {
                        "min_ram_gb": self._config.system_requirements.min_ram_gb,
                        "min_cpu_cores": self._config.system_requirements.min_cpu_cores,
                    },
                    "failures": failures,
                },
            )
        
        self._logger.info(
            "System requirements verified",
            extra={"system": self._system_info.to_dict()}
        )
        return True
    
    def _get_system_fix_suggestion(self, failures: List[str]) -> str:
        """Generate fix suggestions based on failures."""
        suggestions = []
        
        for failure in failures:
            if "RAM" in failure:
                suggestions.append(
                    "Close other applications to free memory, or "
                    "reduce MAINAGENT_MIN_RAM_GB requirement"
                )
            if "CPU" in failure:
                suggestions.append(
                    "Ensure minimum CPU cores available, or "
                    "reduce MAINAGENT_MIN_CPU_CORES requirement"
                )
            if "OS" in failure:
                suggestions.append(
                    "This operating system may not be fully supported"
                )
        
        return ". ".join(suggestions) if suggestions else "Review system requirements"
    
    def _check_configuration(self) -> bool:
        """
        Verify configuration is valid.
        
        Returns:
            True if configuration is valid
        """
        self._logger.info("Validating configuration...")
        
        if not self._config.is_loaded:
            raise StartupError(
                reason="Configuration not loaded",
                detail="Config.load() was not called before agent startup",
                suggestion="Ensure config.load() is called before creating the agent",
            )
        
        if not self._config.is_validated:
            raise StartupError(
                reason="Configuration not validated",
                detail="Config.validate() was not called before agent startup",
                suggestion="Ensure config.validate() is called after loading",
            )
        
        self._logger.info("Configuration validated")
        return True
    
    def _prepare_components(self) -> bool:
        """
        Initialize basic internal components.
        
        Returns:
            True if components initialized successfully
        """
        self._logger.info("Preparing base components...")
        self._logger.info("Base components prepared")
        return True
    
    def _check_ollama_service(self) -> bool:
        """
        Verify Ollama service is installed and running.
        
        Raises:
            OllamaNotAvailableError: If Ollama is not available
            
        Returns:
            True if Ollama is healthy
        """
        self._logger.info("Checking Ollama service...")
        
        checker = OllamaChecker(
            host=self._config.ollama.host,
            port=self._config.ollama.port,
            timeout=10,
            logger=self._logger,
        )
        
        health_report = checker.full_health_check()
        self._ollama_health = health_report
        
        if not health_report.all_passed:
            raise OllamaNotAvailableError(health_report)
        
        self._logger.info(
            f"Ollama healthy: {health_report.ollama_version or 'unknown version'}"
        )
        return True
    
    def _check_ollama_models(self) -> bool:
        """
        Detect and validate Ollama models.
        
        Ensures at least one safe model is available.
        
        Raises:
            NoModelsFoundError: If no models installed
            NoSafeModelsError: If no models are safe for available RAM
            
        Returns:
            True if valid model found
        """
        self._logger.info("Checking Ollama models...")
        
        api_url = f"http://{self._config.ollama.host}:{self._config.ollama.port}"
        
        self._model_manager = OllamaModelManager(
            api_url=api_url,
            timeout=30,
            logger=self._logger,
        )
        
        if self._system_info:
            self._model_manager.set_system_info(self._system_info)
        
        models = self._model_manager.get_installed_models()
        
        summary = self._model_manager.get_models_summary()
        self._logger.info(
            f"Found {summary['total']} models: "
            f"{summary['safe']} safe, {summary['risky']} risky, "
            f"{summary['unsupported']} unsupported"
        )
        
        self._selected_model = self._model_manager.select_best_model()
        
        self._logger.info(
            f"Selected model: {self._selected_model.name} "
            f"({self._selected_model.safety_level.value})"
        )
        
        return True
    
    def _initialize_ollama_client(self) -> bool:
        """
        Initialize the Ollama client with selected model.
        
        Returns:
            True if client initialized and tested successfully
        """
        self._logger.info("Initializing Ollama client...")
        
        if not self._selected_model:
            raise StartupError(
                reason="No model selected",
                detail="Cannot initialize Ollama client without a selected model",
                suggestion="Run model check first",
            )
        
        api_url = f"http://{self._config.ollama.host}:{self._config.ollama.port}"
        
        self._ollama_client = create_ollama_client(
            model=self._selected_model.name,
            api_url=api_url,
            timeout=self._config.ollama.timeout_sec,
            system_prompt="You are a helpful AI assistant.",
        )
        
        success, message = self._ollama_client.test_connection()
        if not success:
            raise StartupError(
                reason="Ollama client test failed",
                detail=message,
                suggestion="Verify Ollama is responding correctly",
            )
        
        self._logger.info(f"Ollama client ready: {self._selected_model.name}")
        return True
    
    def _initialize_planner(self) -> bool:
        """
        Initialize the planning engine.
        
        Returns:
            True if planner initialized successfully
        """
        self._logger.info("Initializing planner...")
        
        self._planner = Planner(logger=self._logger)
        self._planner.initialize(ollama_client=self._ollama_client)
        
        self._logger.info(
            f"Planner ready (LLM: {'enabled' if self._planner.has_llm else 'disabled'})"
        )
        return True
    
    def start(self) -> StartupReport:
        """
        Execute the complete startup sequence.
        
        Startup Order:
        1. Validate configuration
        2. Check system requirements
        3. Prepare base components
        4. Check Ollama service
        5. Detect and validate models
        6. Initialize Ollama client
        7. Initialize planner
        8. Mark as READY
        
        Returns:
            StartupReport with detailed results
            
        Raises:
            StartupError: If any critical check fails
        """
        if self._state not in (AgentState.CREATED, AgentState.STOPPED):
            raise StartupError(
                reason="Invalid state for startup",
                detail=f"Cannot start from state {self._state.value}",
                suggestion="Stop the agent first, or create a new instance",
            )
        
        self._start_time = datetime.now()
        overall_start = time.time()
        self._set_state(AgentState.INITIALIZING)
        
        self._logger.info("=" * 50)
        self._logger.info(f"Starting {self._config.agent.name} v{self._config.agent.version}")
        self._logger.info("=" * 50)
        
        checks: List[StartupCheckResult] = []
        errors: List[ErrorResponse] = []
        
        startup_checks = [
            ("Configuration Validation", self._check_configuration, StartupError),
            ("System Requirements", self._check_system_requirements, SystemCheckError),
            ("Base Components", self._prepare_components, StartupError),
            ("Ollama Service", self._check_ollama_service, ExternalServiceError),
            ("Ollama Models", self._check_ollama_models, StartupError),
            ("Ollama Client", self._initialize_ollama_client, StartupError),
            ("Planning Engine", self._initialize_planner, StartupError),
        ]
        
        self._set_state(AgentState.STARTING)
        
        all_passed = True
        for name, check_fn, error_class in startup_checks:
            result = self._run_check(name, check_fn, error_class)
            checks.append(result)
            
            if result.passed:
                self._logger.info(f"✓ {name}: {result.message}")
            else:
                self._logger.error(f"✗ {name}: {result.message}")
                all_passed = False
                
                if "error" in result.details:
                    errors.append(ErrorResponse(**result.details["error"]))
                else:
                    errors.append(format_error_response(
                        Exception(result.message),
                        category=ErrorCategory.STARTUP,
                        severity=ErrorSeverity.CRITICAL,
                    ))
                
                break
        
        total_duration = (time.time() - overall_start) * 1000
        
        self._startup_report = StartupReport(
            success=all_passed,
            total_duration_ms=total_duration,
            checks=checks,
            errors=errors,
        )
        
        if all_passed:
            self._set_state(AgentState.READY)
            self._logger.info("=" * 50)
            self._logger.info(f"✓ {self._config.agent.name} is READY")
            self._logger.info(f"  Model: {self._selected_model.name}")
            self._logger.info(f"  Planner: {'LLM-enabled' if self._planner.has_llm else 'Pattern-based'}")
            self._logger.info(f"  Startup completed in {total_duration:.2f}ms")
            self._logger.info("=" * 50)
        else:
            self._set_state(AgentState.FAILED)
            self._logger.error("=" * 50)
            self._logger.error(f"✗ {self._config.agent.name} startup FAILED")
            self._logger.error("=" * 50)
            
            raise StartupError(
                reason="Startup sequence failed",
                detail=f"Failed check: {checks[-1].name if checks else 'Unknown'}",
                suggestion="Review the startup report and fix the failing checks",
                context={
                    "report": self._startup_report.checks[-1].details if checks else {},
                    "failed_check": checks[-1].name if checks else None,
                },
            )
        
        return self._startup_report
    
    def stop(self, reason: str = "Shutdown requested") -> bool:
        """
        Execute graceful shutdown sequence.
        
        Args:
            reason: Reason for shutdown (for logging)
            
        Returns:
            True if shutdown completed successfully
        """
        if self._state in (AgentState.STOPPED, AgentState.STOPPING):
            self._logger.warning("Agent already stopped or stopping")
            return True
        
        self._set_state(AgentState.STOPPING)
        self._logger.info(f"Initiating shutdown: {reason}")
        
        try:
            self._logger.debug("Cleaning up components...")
            
            if self._ollama_client:
                self._ollama_client.clear_history()
                self._ollama_client = None
            
            self._planner = None
            self._model_manager = None
            self._selected_model = None
            self._ollama_health = None
            self._system_info = None
            
            self._set_state(AgentState.STOPPED)
            self._logger.info("=" * 50)
            self._logger.info(f"✓ {self._config.agent.name} stopped gracefully")
            self._logger.info("=" * 50)
            
            return True
            
        except Exception as e:
            self._logger.error(f"Error during shutdown: {e}")
            self._set_state(AgentState.FAILED)
            raise ShutdownError(
                reason="Shutdown failed",
                detail=str(e),
                suggestion="Check for resource leaks and orphan processes",
            )
    
    def plan_task(self, user_input: str) -> PlannedTask:
        """
        Create a structured plan from user input.
        
        This is the main interface for creating plans.
        Does NOT execute - only plans.
        
        Args:
            user_input: Raw user text describing what they want
            
        Returns:
            PlannedTask with structured plan
            
        Raises:
            PlannerError: If planning fails
            StartupError: If agent not ready
        """
        if not self.is_ready:
            raise StartupError(
                reason="Agent not ready",
                detail=f"Current state: {self._state.value}",
                suggestion="Start the agent first with agent.start()",
            )
        
        if not self._planner:
            raise StartupError(
                reason="Planner not initialized",
                detail="Planner is None",
                suggestion="Ensure agent.start() completed successfully",
            )
        
        self._logger.info(f"Creating plan for: {user_input[:50]}...")
        
        task = self._planner.plan(user_input)
        
        self._logger.info(f"Plan created: {task.goal}")
        self._logger.debug(f"Plan details:\n{task}")
        
        return task
    
    @property
    def state(self) -> AgentState:
        """Get current agent state."""
        return self._state
    
    @property
    def is_ready(self) -> bool:
        """Check if agent is ready for operations."""
        return self._state == AgentState.READY
    
    @property
    def is_running(self) -> bool:
        """Check if agent is in an active state."""
        return self._state in (AgentState.READY, AgentState.RUNNING)
    
    @property
    def startup_report(self) -> Optional[StartupReport]:
        """Get the last startup report."""
        return self._startup_report
    
    @property
    def system_info(self) -> Optional[SystemInfo]:
        """Get cached system information."""
        return self._system_info
    
    @property
    def config(self) -> Config:
        """Get the configuration object."""
        return self._config
    
    @property
    def planner(self) -> Optional[Planner]:
        """Get the planner instance."""
        return self._planner
    
    @property
    def ollama_client(self) -> Optional[OllamaClient]:
        """Get the Ollama client instance."""
        return self._ollama_client
    
    @property
    def selected_model(self) -> Optional[ModelInfo]:
        """Get the selected Ollama model info."""
        return self._selected_model
    
    @property
    def ollama_health(self) -> Optional[OllamaHealthReport]:
        """Get the Ollama health report."""
        return self._ollama_health
    
    def get_status(self) -> Dict[str, Any]:
        """
        Get comprehensive agent status.
        
        Returns:
            Dictionary with full status information
        """
        return {
            "agent": {
                "name": self._config.agent.name,
                "version": self._config.agent.version,
                "state": self._state.value,
                "is_ready": self.is_ready,
                "start_time": self._start_time.isoformat() if self._start_time else None,
            },
            "system": self._system_info.to_dict() if self._system_info else None,
            "components": {
                "planner": self._planner.status if self._planner else None,
                "ollama": {
                    "healthy": self._ollama_health.all_passed if self._ollama_health else False,
                    "version": self._ollama_health.ollama_version if self._ollama_health else None,
                    "model": self._selected_model.name if self._selected_model else None,
                    "model_safety": self._selected_model.safety_level.value if self._selected_model else None,
                    "model_ram_gb": self._selected_model.ram_required_gb if self._selected_model else None,
                } if self._ollama_health else None,
            },
            "startup": {
                "success": self._startup_report.success if self._startup_report else None,
                "duration_ms": self._startup_report.total_duration_ms if self._startup_report else None,
                "checks_passed": len([c for c in self._startup_report.checks if c.passed]) if self._startup_report else 0,
                "checks_total": len(self._startup_report.checks) if self._startup_report else 0,
            },
        }
    
    def __repr__(self) -> str:
        model_name = self._selected_model.name if self._selected_model else "none"
        return (
            f"MainAgent(name={self._config.agent.name!r}, "
            f"state={self._state.value}, "
            f"model={model_name}, "
            f"ready={self.is_ready})"
        )
    
    def __enter__(self) -> "MainAgent":
        """Context manager entry - start the agent."""
        self.start()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit - stop the agent."""
        if exc_type:
            self.stop(reason=f"Exception: {exc_type.__name__}")
        else:
            self.stop(reason="Context manager exit")