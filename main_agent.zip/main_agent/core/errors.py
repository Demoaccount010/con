"""
Error Handling Framework
========================
Standardized error system with human-readable output.

All errors follow the format:
    STATUS: FAILED
    REASON: <human readable explanation>
    DETAIL: <technical details>
    SUGGESTION: <what to do next>
"""

from typing import Optional, Dict, Any
from enum import Enum
from dataclasses import dataclass
from datetime import datetime


class ErrorSeverity(Enum):
    """Error severity levels."""
    LOW = "LOW"          # Can continue with degraded functionality
    MEDIUM = "MEDIUM"    # Should address but not fatal
    HIGH = "HIGH"        # Should stop soon
    CRITICAL = "CRITICAL"  # Must stop immediately


class ErrorCategory(Enum):
    """Error categories for classification."""
    SYSTEM = "SYSTEM"           # OS, hardware related
    CONFIGURATION = "CONFIG"    # Configuration issues
    STARTUP = "STARTUP"         # Startup sequence failures
    SHUTDOWN = "SHUTDOWN"       # Shutdown issues
    RUNTIME = "RUNTIME"         # Runtime errors
    EXTERNAL = "EXTERNAL"       # External service issues
    VALIDATION = "VALIDATION"   # Data validation errors
    UNKNOWN = "UNKNOWN"         # Unclassified errors


@dataclass
class ErrorResponse:
    """
    Standardized Error Response
    ===========================
    
    Every error in the system is converted to this format
    for consistent handling and user-friendly output.
    """
    status: str
    reason: str
    detail: str
    suggestion: str
    category: ErrorCategory
    severity: ErrorSeverity
    timestamp: str
    error_code: Optional[str] = None
    context: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        result = {
            "status": self.status,
            "reason": self.reason,
            "detail": self.detail,
            "suggestion": self.suggestion,
            "category": self.category.value,
            "severity": self.severity.value,
            "timestamp": self.timestamp,
        }
        if self.error_code:
            result["error_code"] = self.error_code
        if self.context:
            result["context"] = self.context
        return result
    
    def __str__(self) -> str:
        """Human-readable string representation."""
        lines = [
            "=" * 60,
            f"STATUS: {self.status}",
            f"REASON: {self.reason}",
            f"DETAIL: {self.detail}",
            f"SUGGESTION: {self.suggestion}",
            "-" * 60,
            f"Category: {self.category.value} | Severity: {self.severity.value}",
            f"Timestamp: {self.timestamp}",
        ]
        if self.error_code:
            lines.append(f"Error Code: {self.error_code}")
        lines.append("=" * 60)
        return "\n".join(lines)


class AgentError(Exception):
    """
    Base Agent Error
    ================
    
    All custom exceptions inherit from this class.
    Provides automatic conversion to ErrorResponse format.
    """
    
    default_category = ErrorCategory.UNKNOWN
    default_severity = ErrorSeverity.HIGH
    default_suggestion = "Check the logs for more details and try again."
    
    def __init__(
        self,
        reason: str,
        detail: str = "",
        suggestion: Optional[str] = None,
        category: Optional[ErrorCategory] = None,
        severity: Optional[ErrorSeverity] = None,
        error_code: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ):
        self.reason = reason
        self.detail = detail or reason
        self.suggestion = suggestion or self.default_suggestion
        self.category = category or self.default_category
        self.severity = severity or self.default_severity
        self.error_code = error_code
        self.context = context or {}
        self.timestamp = datetime.now().isoformat()
        
        super().__init__(self.reason)
    
    def to_response(self) -> ErrorResponse:
        """Convert exception to standardized ErrorResponse."""
        return ErrorResponse(
            status="FAILED",
            reason=self.reason,
            detail=self.detail,
            suggestion=self.suggestion,
            category=self.category,
            severity=self.severity,
            timestamp=self.timestamp,
            error_code=self.error_code,
            context=self.context,
        )
    
    def __str__(self) -> str:
        return str(self.to_response())


class StartupError(AgentError):
    """
    Startup Sequence Error
    ======================
    Raised when agent startup fails.
    """
    default_category = ErrorCategory.STARTUP
    default_severity = ErrorSeverity.CRITICAL
    default_suggestion = (
        "Review the startup requirements and ensure all dependencies "
        "are properly installed and configured."
    )


class ShutdownError(AgentError):
    """
    Shutdown Sequence Error
    =======================
    Raised when agent shutdown encounters issues.
    """
    default_category = ErrorCategory.SHUTDOWN
    default_severity = ErrorSeverity.MEDIUM
    default_suggestion = (
        "The agent may not have shut down cleanly. "
        "Check for orphan processes and clean up if necessary."
    )


class SystemCheckError(AgentError):
    """
    System Check Error
    ==================
    Raised when system requirements are not met.
    """
    default_category = ErrorCategory.SYSTEM
    default_severity = ErrorSeverity.CRITICAL
    default_suggestion = (
        "Ensure your system meets the minimum requirements: "
        "sufficient RAM, supported OS, and available resources."
    )


class ConfigurationError(AgentError):
    """
    Configuration Error
    ===================
    Raised when configuration is invalid or missing.
    """
    default_category = ErrorCategory.CONFIGURATION
    default_severity = ErrorSeverity.HIGH
    default_suggestion = (
        "Check your configuration file and environment variables. "
        "Ensure all required settings are properly defined."
    )


class ValidationError(AgentError):
    """
    Validation Error
    ================
    Raised when data validation fails.
    """
    default_category = ErrorCategory.VALIDATION
    default_severity = ErrorSeverity.MEDIUM
    default_suggestion = "Review the input data and correct any invalid values."


class ExternalServiceError(AgentError):
    """
    External Service Error
    ======================
    Raised when an external service (like Ollama) fails.
    """
    default_category = ErrorCategory.EXTERNAL
    default_severity = ErrorSeverity.HIGH
    default_suggestion = (
        "Check that the external service is running and accessible. "
        "Verify network connectivity and service configuration."
    )


def format_error_response(
    exception: Exception,
    category: Optional[ErrorCategory] = None,
    severity: Optional[ErrorSeverity] = None,
    suggestion: Optional[str] = None,
    context: Optional[Dict[str, Any]] = None,
) -> ErrorResponse:
    """
    Convert any exception to standardized ErrorResponse.
    
    This function handles both AgentError subclasses and
    standard Python exceptions.
    
    Args:
        exception: The exception to convert
        category: Override category (for non-AgentError exceptions)
        severity: Override severity
        suggestion: Override suggestion
        context: Additional context information
        
    Returns:
        ErrorResponse with standardized format
    """
    if isinstance(exception, AgentError):
        response = exception.to_response()
        if category:
            response.category = category
        if severity:
            response.severity = severity
        if suggestion:
            response.suggestion = suggestion
        if context:
            response.context.update(context)
        return response
    
    # Handle standard exceptions
    return ErrorResponse(
        status="FAILED",
        reason=str(exception) or exception.__class__.__name__,
        detail=f"{exception.__class__.__name__}: {str(exception)}",
        suggestion=suggestion or "An unexpected error occurred. Check the logs.",
        category=category or ErrorCategory.UNKNOWN,
        severity=severity or ErrorSeverity.HIGH,
        timestamp=datetime.now().isoformat(),
        context=context,
    )


def create_error_chain(errors: list) -> str:
    """
    Create a formatted error chain from multiple errors.
    
    Useful when multiple errors occur during startup.
    
    Args:
        errors: List of ErrorResponse or AgentError objects
        
    Returns:
        Formatted string showing all errors
    """
    if not errors:
        return "No errors recorded."
    
    lines = [
        "=" * 60,
        f"ERROR CHAIN ({len(errors)} errors)",
        "=" * 60,
    ]
    
    for i, error in enumerate(errors, 1):
        if isinstance(error, AgentError):
            error = error.to_response()
        elif isinstance(error, Exception):
            error = format_error_response(error)
        
        lines.extend([
            f"\n[Error {i}]",
            f"  Reason: {error.reason}",
            f"  Category: {error.category.value}",
            f"  Severity: {error.severity.value}",
        ])
    
    lines.append("\n" + "=" * 60)
    return "\n".join(lines)