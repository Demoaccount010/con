"""
Ollama Installation & Health Checker
====================================
Verifies Ollama binary, service, and API availability.

Checks performed:
1. Binary existence (ollama command available)
2. Service running (process active)
3. API reachable (HTTP health check)
"""

import subprocess
import socket
import urllib.request
import urllib.error
import json
import os
import platform
from typing import Dict, Any, Optional, List, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime

# Import from PART-1A
from main_agent.core.errors import (
    ExternalServiceError,
    ErrorCategory,
    ErrorSeverity,
    ErrorResponse,
)
from main_agent.utils.logger import Logger, get_logger


class OllamaHealthStatus(Enum):
    """Ollama service health status levels."""
    HEALTHY = "HEALTHY"           # All checks passed
    DEGRADED = "DEGRADED"         # Partial functionality
    UNHEALTHY = "UNHEALTHY"       # Service not working
    NOT_INSTALLED = "NOT_INSTALLED"  # Binary not found


@dataclass
class HealthCheckResult:
    """Result of a single health check."""
    check_name: str
    passed: bool
    message: str
    details: Dict[str, Any] = field(default_factory=dict)
    suggestion: str = ""
    

@dataclass 
class OllamaHealthReport:
    """Complete Ollama health report."""
    status: OllamaHealthStatus
    all_passed: bool
    checks: List[HealthCheckResult] = field(default_factory=list)
    ollama_version: Optional[str] = None
    api_url: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    
    def get_first_failure(self) -> Optional[HealthCheckResult]:
        """Get the first failed check, if any."""
        for check in self.checks:
            if not check.passed:
                return check
        return None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "status": self.status.value,
            "all_passed": self.all_passed,
            "checks": [
                {
                    "name": c.check_name,
                    "passed": c.passed,
                    "message": c.message,
                }
                for c in self.checks
            ],
            "ollama_version": self.ollama_version,
            "api_url": self.api_url,
            "timestamp": self.timestamp,
        }
    
    def __str__(self) -> str:
        lines = [
            f"Ollama Health: {self.status.value}",
            f"API URL: {self.api_url}",
        ]
        if self.ollama_version:
            lines.append(f"Version: {self.ollama_version}")
        lines.append("Checks:")
        for check in self.checks:
            status = "✓" if check.passed else "✗"
            lines.append(f"  {status} {check.check_name}: {check.message}")
        return "\n".join(lines)


class OllamaChecker:
    """
    Ollama Health Checker
    =====================
    
    Performs comprehensive health checks on Ollama installation:
    1. Binary check - Is 'ollama' command available?
    2. Service check - Is Ollama process running?
    3. API check - Is API responding at configured endpoint?
    
    Usage:
        checker = OllamaChecker()
        report = checker.full_health_check()
        if not report.all_passed:
            # Handle failure
    """
    
    # Default Ollama configuration
    DEFAULT_HOST = "127.0.0.1"
    DEFAULT_PORT = 11434
    DEFAULT_TIMEOUT = 10  # seconds
    
    def __init__(
        self,
        host: str = DEFAULT_HOST,
        port: int = DEFAULT_PORT,
        timeout: int = DEFAULT_TIMEOUT,
        logger: Optional[Logger] = None,
    ):
        """
        Initialize the Ollama checker.
        
        Args:
            host: Ollama API host
            port: Ollama API port
            timeout: Connection timeout in seconds
            logger: Optional logger instance
        """
        self.host = host
        self.port = port
        self.timeout = timeout
        self.api_url = f"http://{host}:{port}"
        self._logger = logger or get_logger("OllamaChecker")
    
    def check_binary_exists(self) -> HealthCheckResult:
        """
        Check if Ollama binary is installed and accessible.
        
        Looks for 'ollama' command in system PATH.
        
        Returns:
            HealthCheckResult with pass/fail status
        """
        self._logger.debug("Checking Ollama binary existence...")
        
        try:
            # Try to get ollama version
            if platform.system() == "Windows":
                # Windows: use 'where' command
                result = subprocess.run(
                    ["where", "ollama"],
                    capture_output=True,
                    text=True,
                    timeout=self.timeout,
                )
                binary_found = result.returncode == 0
                binary_path = result.stdout.strip().split('\n')[0] if binary_found else None
            else:
                # Unix: use 'which' command
                result = subprocess.run(
                    ["which", "ollama"],
                    capture_output=True,
                    text=True,
                    timeout=self.timeout,
                )
                binary_found = result.returncode == 0
                binary_path = result.stdout.strip() if binary_found else None
            
            if binary_found:
                # Verify it's actually executable
                version_result = subprocess.run(
                    ["ollama", "--version"],
                    capture_output=True,
                    text=True,
                    timeout=self.timeout,
                )
                
                if version_result.returncode == 0:
                    version = version_result.stdout.strip()
                    return HealthCheckResult(
                        check_name="Binary Exists",
                        passed=True,
                        message=f"Found at {binary_path}",
                        details={
                            "path": binary_path,
                            "version": version,
                        },
                    )
                else:
                    return HealthCheckResult(
                        check_name="Binary Exists",
                        passed=False,
                        message="Binary found but not executable",
                        details={"path": binary_path},
                        suggestion="Check Ollama installation integrity",
                    )
            else:
                return HealthCheckResult(
                    check_name="Binary Exists",
                    passed=False,
                    message="Ollama binary not found in PATH",
                    suggestion=self._get_install_suggestion(),
                )
                
        except subprocess.TimeoutExpired:
            return HealthCheckResult(
                check_name="Binary Exists",
                passed=False,
                message="Timeout checking for Ollama binary",
                suggestion="System may be under heavy load, try again",
            )
        except FileNotFoundError:
            return HealthCheckResult(
                check_name="Binary Exists",
                passed=False,
                message="Ollama binary not found",
                suggestion=self._get_install_suggestion(),
            )
        except Exception as e:
            return HealthCheckResult(
                check_name="Binary Exists",
                passed=False,
                message=f"Error checking binary: {str(e)}",
                suggestion="Check system PATH configuration",
            )
    
    def check_service_running(self) -> HealthCheckResult:
        """
        Check if Ollama service/process is running.
        
        Checks for 'ollama' process or service status.
        
        Returns:
            HealthCheckResult with pass/fail status
        """
        self._logger.debug("Checking Ollama service status...")
        
        try:
            system = platform.system()
            
            if system == "Linux":
                # Try systemctl first (most common)
                result = subprocess.run(
                    ["systemctl", "is-active", "ollama"],
                    capture_output=True,
                    text=True,
                    timeout=self.timeout,
                )
                
                if result.returncode == 0 and "active" in result.stdout.lower():
                    return HealthCheckResult(
                        check_name="Service Running",
                        passed=True,
                        message="Ollama service is active (systemd)",
                        details={"method": "systemctl"},
                    )
                
                # Fallback: check for process
                return self._check_process_running()
                
            elif system == "Darwin":  # macOS
                # Check for process
                return self._check_process_running()
                
            elif system == "Windows":
                # Check for process on Windows
                result = subprocess.run(
                    ["tasklist", "/FI", "IMAGENAME eq ollama.exe"],
                    capture_output=True,
                    text=True,
                    timeout=self.timeout,
                )
                
                if "ollama.exe" in result.stdout.lower():
                    return HealthCheckResult(
                        check_name="Service Running",
                        passed=True,
                        message="Ollama process is running",
                        details={"method": "tasklist"},
                    )
                else:
                    return HealthCheckResult(
                        check_name="Service Running",
                        passed=False,
                        message="Ollama process not found",
                        suggestion="Start Ollama: run 'ollama serve' in a terminal",
                    )
            else:
                # Unknown OS - try process check
                return self._check_process_running()
                
        except FileNotFoundError:
            # systemctl not found, try process check
            return self._check_process_running()
        except Exception as e:
            return HealthCheckResult(
                check_name="Service Running",
                passed=False,
                message=f"Error checking service: {str(e)}",
                suggestion="Manually verify Ollama is running",
            )
    
    def _check_process_running(self) -> HealthCheckResult:
        """Check if ollama process is running using pgrep or ps."""
        try:
            # Try pgrep first
            result = subprocess.run(
                ["pgrep", "-x", "ollama"],
                capture_output=True,
                text=True,
                timeout=self.timeout,
            )
            
            if result.returncode == 0 and result.stdout.strip():
                pids = result.stdout.strip().split('\n')
                return HealthCheckResult(
                    check_name="Service Running",
                    passed=True,
                    message=f"Ollama process running (PID: {pids[0]})",
                    details={"pids": pids, "method": "pgrep"},
                )
            else:
                return HealthCheckResult(
                    check_name="Service Running",
                    passed=False,
                    message="Ollama process not running",
                    suggestion=self._get_start_suggestion(),
                )
                
        except FileNotFoundError:
            # pgrep not available, try ps
            try:
                result = subprocess.run(
                    ["ps", "aux"],
                    capture_output=True,
                    text=True,
                    timeout=self.timeout,
                )
                
                if "ollama" in result.stdout.lower():
                    return HealthCheckResult(
                        check_name="Service Running",
                        passed=True,
                        message="Ollama process found in process list",
                        details={"method": "ps"},
                    )
                else:
                    return HealthCheckResult(
                        check_name="Service Running",
                        passed=False,
                        message="Ollama process not found",
                        suggestion=self._get_start_suggestion(),
                    )
            except:
                return HealthCheckResult(
                    check_name="Service Running",
                    passed=False,
                    message="Unable to check process status",
                    suggestion="Manually verify Ollama is running",
                )
    
    def check_api_reachable(self) -> HealthCheckResult:
        """
        Check if Ollama API is reachable and responding.
        
        Makes HTTP request to the API endpoint.
        
        Returns:
            HealthCheckResult with pass/fail status
        """
        self._logger.debug(f"Checking Ollama API at {self.api_url}...")
        
        # First check if port is open
        port_open = self._check_port_open()
        if not port_open:
            return HealthCheckResult(
                check_name="API Reachable",
                passed=False,
                message=f"Port {self.port} is not open on {self.host}",
                details={"url": self.api_url},
                suggestion=self._get_start_suggestion(),
            )
        
        # Try to reach the API
        try:
            # Ollama API root returns version info
            request = urllib.request.Request(
                f"{self.api_url}/api/tags",
                method="GET",
                headers={"Content-Type": "application/json"},
            )
            
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                if response.status == 200:
                    data = json.loads(response.read().decode())
                    model_count = len(data.get("models", []))
                    
                    return HealthCheckResult(
                        check_name="API Reachable",
                        passed=True,
                        message=f"API responding ({model_count} models available)",
                        details={
                            "url": self.api_url,
                            "status_code": response.status,
                            "model_count": model_count,
                        },
                    )
                else:
                    return HealthCheckResult(
                        check_name="API Reachable",
                        passed=False,
                        message=f"API returned status {response.status}",
                        details={"status_code": response.status},
                        suggestion="Check Ollama logs for errors",
                    )
                    
        except urllib.error.URLError as e:
            reason = str(e.reason) if hasattr(e, 'reason') else str(e)
            return HealthCheckResult(
                check_name="API Reachable",
                passed=False,
                message=f"Cannot connect to Ollama API: {reason}",
                details={"url": self.api_url, "error": reason},
                suggestion=self._get_start_suggestion(),
            )
        except json.JSONDecodeError:
            return HealthCheckResult(
                check_name="API Reachable",
                passed=True,  # API responded, just not JSON
                message="API reachable (non-JSON response)",
                details={"url": self.api_url},
            )
        except Exception as e:
            return HealthCheckResult(
                check_name="API Reachable",
                passed=False,
                message=f"Error connecting to API: {str(e)}",
                details={"url": self.api_url, "error": str(e)},
                suggestion="Check network connectivity and firewall settings",
            )
    
    def _check_port_open(self) -> bool:
        """Check if the Ollama port is open."""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            result = sock.connect_ex((self.host, self.port))
            sock.close()
            return result == 0
        except:
            return False
    
    def full_health_check(self) -> OllamaHealthReport:
        """
        Perform complete health check of Ollama installation.
        
        Runs all checks in order:
        1. Binary exists
        2. Service running
        3. API reachable
        
        Stops at first failure for efficiency.
        
        Returns:
            OllamaHealthReport with complete status
        """
        self._logger.info("Starting Ollama health check...")
        
        checks: List[HealthCheckResult] = []
        all_passed = True
        status = OllamaHealthStatus.HEALTHY
        version = None
        
        # Check 1: Binary exists
        binary_check = self.check_binary_exists()
        checks.append(binary_check)
        
        if not binary_check.passed:
            self._logger.error(f"Binary check failed: {binary_check.message}")
            return OllamaHealthReport(
                status=OllamaHealthStatus.NOT_INSTALLED,
                all_passed=False,
                checks=checks,
                api_url=self.api_url,
            )
        
        # Extract version if available
        if "version" in binary_check.details:
            version = binary_check.details["version"]
        
        # Check 2: Service running
        service_check = self.check_service_running()
        checks.append(service_check)
        
        if not service_check.passed:
            self._logger.error(f"Service check failed: {service_check.message}")
            return OllamaHealthReport(
                status=OllamaHealthStatus.UNHEALTHY,
                all_passed=False,
                checks=checks,
                ollama_version=version,
                api_url=self.api_url,
            )
        
        # Check 3: API reachable
        api_check = self.check_api_reachable()
        checks.append(api_check)
        
        if not api_check.passed:
            self._logger.error(f"API check failed: {api_check.message}")
            return OllamaHealthReport(
                status=OllamaHealthStatus.UNHEALTHY,
                all_passed=False,
                checks=checks,
                ollama_version=version,
                api_url=self.api_url,
            )
        
        self._logger.info("Ollama health check passed")
        return OllamaHealthReport(
            status=OllamaHealthStatus.HEALTHY,
            all_passed=True,
            checks=checks,
            ollama_version=version,
            api_url=self.api_url,
        )
    
    def _get_install_suggestion(self) -> str:
        """Get OS-specific installation suggestion."""
        system = platform.system()
        
        if system == "Linux":
            return "Install Ollama: curl -fsSL https://ollama.com/install.sh | sh"
        elif system == "Darwin":
            return "Install Ollama: brew install ollama (or download from ollama.com)"
        elif system == "Windows":
            return "Install Ollama: Download installer from https://ollama.com/download"
        else:
            return "Install Ollama from https://ollama.com"
    
    def _get_start_suggestion(self) -> str:
        """Get OS-specific service start suggestion."""
        system = platform.system()
        
        if system == "Linux":
            return "Start Ollama: 'systemctl start ollama' or 'ollama serve'"
        elif system == "Darwin":
            return "Start Ollama: 'ollama serve' or launch Ollama app"
        elif system == "Windows":
            return "Start Ollama: Run 'ollama serve' or start Ollama from Start Menu"
        else:
            return "Start Ollama with 'ollama serve'"


def check_ollama_health(
    host: str = "127.0.0.1",
    port: int = 11434,
    timeout: int = 10,
) -> OllamaHealthReport:
    """
    Convenience function for quick Ollama health check.
    
    Args:
        host: Ollama API host
        port: Ollama API port
        timeout: Connection timeout
        
    Returns:
        OllamaHealthReport with complete status
    """
    checker = OllamaChecker(host=host, port=port, timeout=timeout)
    return checker.full_health_check()


class OllamaNotAvailableError(ExternalServiceError):
    """
    Raised when Ollama is not available.
    
    Provides detailed information about what's missing
    and how to fix it.
    """
    
    def __init__(self, health_report: OllamaHealthReport):
        self.health_report = health_report
        
        # Get first failure for main message
        failure = health_report.get_first_failure()
        
        if failure:
            reason = f"Ollama check failed: {failure.check_name}"
            detail = failure.message
            suggestion = failure.suggestion
        else:
            reason = "Ollama is not available"
            detail = f"Status: {health_report.status.value}"
            suggestion = "Check Ollama installation and service"
        
        super().__init__(
            reason=reason,
            detail=detail,
            suggestion=suggestion,
            context={
                "health_report": health_report.to_dict(),
                "api_url": health_report.api_url,
            },
        )