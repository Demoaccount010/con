"""
Ollama Client Wrapper
=====================
Clean abstraction layer for Ollama LLM interactions.

Features:
- Prompt sending with timeout handling
- Retry logic for transient failures
- Structured response format
- Human-readable error mapping
"""

import json
import time
import urllib.request
import urllib.error
from typing import Dict, Any, Optional, List, Generator
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime

# Import from PART-1A
from main_agent.core.errors import (
    ExternalServiceError,
    ErrorCategory,
    ErrorSeverity,
)
from main_agent.utils.logger import Logger, get_logger


class ResponseStatus(Enum):
    """Status of an Ollama response."""
    SUCCESS = "SUCCESS"
    ERROR = "ERROR"
    TIMEOUT = "TIMEOUT"
    RATE_LIMITED = "RATE_LIMITED"


@dataclass
class OllamaResponse:
    """
    Structured response from Ollama.
    
    Wraps the raw Ollama response with additional metadata.
    """
    status: ResponseStatus
    content: str                         # The actual response text
    model: str                           # Model used
    done: bool = True                    # Whether generation is complete
    total_duration_ms: float = 0.0       # Total processing time
    load_duration_ms: float = 0.0        # Model load time
    eval_count: int = 0                  # Tokens generated
    eval_duration_ms: float = 0.0        # Generation time
    error_message: Optional[str] = None  # Error details if failed
    raw_response: Optional[Dict] = None  # Original response data
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "status": self.status.value,
            "content": self.content,
            "model": self.model,
            "done": self.done,
            "metrics": {
                "total_duration_ms": round(self.total_duration_ms, 2),
                "eval_count": self.eval_count,
            },
            "error": self.error_message,
        }
    
    @property
    def is_success(self) -> bool:
        """Check if response was successful."""
        return self.status == ResponseStatus.SUCCESS
    
    def __str__(self) -> str:
        if self.is_success:
            return self.content
        return f"[{self.status.value}] {self.error_message or 'Unknown error'}"


@dataclass
class Message:
    """Chat message structure."""
    role: str   # "system", "user", or "assistant"
    content: str
    
    def to_dict(self) -> Dict[str, str]:
        return {"role": self.role, "content": self.content}


class OllamaClientError(ExternalServiceError):
    """Raised when Ollama client operations fail."""
    
    def __init__(
        self,
        reason: str,
        detail: str = "",
        suggestion: str = "Check Ollama service status",
        status: ResponseStatus = ResponseStatus.ERROR,
    ):
        self.response_status = status
        super().__init__(
            reason=reason,
            detail=detail,
            suggestion=suggestion,
        )


class OllamaClient:
    """
    Ollama API Client
    =================
    
    Clean wrapper for Ollama LLM interactions.
    
    Features:
    - Simple chat interface
    - Automatic retry on failures
    - Timeout handling
    - Structured responses
    
    Usage:
        client = OllamaClient(model="qwen2.5:3b")
        response = client.chat("What is Python?")
        print(response.content)
        
        # With conversation history
        messages = [
            Message("system", "You are a helpful assistant."),
            Message("user", "Hello!"),
        ]
        response = client.chat_with_history(messages)
    """
    
    # Default configuration
    DEFAULT_TIMEOUT = 120       # 2 minutes
    DEFAULT_MAX_RETRIES = 3
    DEFAULT_RETRY_DELAY = 1.0   # seconds
    
    def __init__(
        self,
        model: str,
        api_url: str = "http://127.0.0.1:11434",
        timeout: int = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        retry_delay: float = DEFAULT_RETRY_DELAY,
        system_prompt: Optional[str] = None,
        logger: Optional[Logger] = None,
    ):
        """
        Initialize the Ollama client.
        
        Args:
            model: Name of the model to use
            api_url: Ollama API base URL
            timeout: Request timeout in seconds
            max_retries: Maximum retry attempts
            retry_delay: Delay between retries
            system_prompt: Default system prompt for all conversations
            logger: Optional logger instance
        """
        self.model = model
        self.api_url = api_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.system_prompt = system_prompt
        self._logger = logger or get_logger("OllamaClient")
        
        # Conversation history for multi-turn chats
        self._history: List[Message] = []
        
        self._logger.debug(f"OllamaClient initialized with model: {model}")
    
    def chat(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        stream: bool = False,
    ) -> OllamaResponse:
        """
        Send a single prompt and get a response.
        
        This is a stateless call - doesn't use conversation history.
        
        Args:
            prompt: User message
            system_prompt: Override default system prompt
            temperature: Response randomness (0.0-1.0)
            stream: Whether to stream the response
            
        Returns:
            OllamaResponse with the model's reply
        """
        messages = []
        
        # Add system prompt if provided
        sys_prompt = system_prompt or self.system_prompt
        if sys_prompt:
            messages.append(Message("system", sys_prompt))
        
        # Add user message
        messages.append(Message("user", prompt))
        
        return self.chat_with_history(
            messages=messages,
            temperature=temperature,
            stream=stream,
        )
    
    def chat_with_history(
        self,
        messages: List[Message],
        temperature: float = 0.7,
        stream: bool = False,
    ) -> OllamaResponse:
        """
        Send a conversation with history and get a response.
        
        Args:
            messages: List of Message objects forming the conversation
            temperature: Response randomness (0.0-1.0)
            stream: Whether to stream the response
            
        Returns:
            OllamaResponse with the model's reply
        """
        self._logger.debug(f"Sending chat request with {len(messages)} messages")
        
        # Prepare request payload
        payload = {
            "model": self.model,
            "messages": [m.to_dict() for m in messages],
            "stream": stream,
            "options": {
                "temperature": temperature,
            },
        }
        
        return self._make_request("/api/chat", payload)
    
    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
    ) -> OllamaResponse:
        """
        Raw generation without chat format.
        
        Use this for completion-style prompts.
        
        Args:
            prompt: The prompt text
            system_prompt: System context
            temperature: Response randomness
            
        Returns:
            OllamaResponse with generated text
        """
        payload = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": temperature,
            },
        }
        
        if system_prompt:
            payload["system"] = system_prompt
        
        return self._make_request("/api/generate", payload)
    
    def _make_request(
        self,
        endpoint: str,
        payload: Dict[str, Any],
    ) -> OllamaResponse:
        """
        Make HTTP request to Ollama API with retry logic.
        
        Args:
            endpoint: API endpoint path
            payload: Request payload
            
        Returns:
            OllamaResponse with result
        """
        url = f"{self.api_url}{endpoint}"
        last_error = None
        
        for attempt in range(1, self.max_retries + 1):
            try:
                self._logger.debug(f"Request attempt {attempt}/{self.max_retries}")
                
                # Prepare request
                data = json.dumps(payload).encode("utf-8")
                request = urllib.request.Request(
                    url,
                    data=data,
                    method="POST",
                    headers={
                        "Content-Type": "application/json",
                    },
                )
                
                # Make request
                start_time = time.time()
                with urllib.request.urlopen(request, timeout=self.timeout) as response:
                    response_data = json.loads(response.read().decode())
                    elapsed = (time.time() - start_time) * 1000
                
                # Parse response
                return self._parse_response(response_data, elapsed)
                
            except urllib.error.URLError as e:
                last_error = self._handle_url_error(e, attempt)
                if attempt < self.max_retries:
                    time.sleep(self.retry_delay * attempt)
                    
            except urllib.error.HTTPError as e:
                last_error = self._handle_http_error(e, attempt)
                if attempt < self.max_retries and e.code >= 500:
                    time.sleep(self.retry_delay * attempt)
                else:
                    break  # Don't retry client errors
                    
            except json.JSONDecodeError as e:
                last_error = OllamaResponse(
                    status=ResponseStatus.ERROR,
                    content="",
                    model=self.model,
                    error_message=f"Invalid JSON response: {str(e)}",
                )
                break  # Don't retry parse errors
                
            except TimeoutError:
                last_error = OllamaResponse(
                    status=ResponseStatus.TIMEOUT,
                    content="",
                    model=self.model,
                    error_message=f"Request timed out after {self.timeout} seconds",
                )
                if attempt < self.max_retries:
                    time.sleep(self.retry_delay)
        
        # All retries failed
        if last_error:
            return last_error
        
        return OllamaResponse(
            status=ResponseStatus.ERROR,
            content="",
            model=self.model,
            error_message="Unknown error occurred",
        )
    
    def _parse_response(
        self,
        data: Dict[str, Any],
        elapsed_ms: float,
    ) -> OllamaResponse:
        """Parse raw Ollama response into structured format."""
        # Chat endpoint response
        if "message" in data:
            content = data["message"].get("content", "")
        # Generate endpoint response
        elif "response" in data:
            content = data["response"]
        else:
            content = ""
        
        return OllamaResponse(
            status=ResponseStatus.SUCCESS,
            content=content,
            model=data.get("model", self.model),
            done=data.get("done", True),
            total_duration_ms=data.get("total_duration", 0) / 1_000_000,  # ns to ms
            load_duration_ms=data.get("load_duration", 0) / 1_000_000,
            eval_count=data.get("eval_count", 0),
            eval_duration_ms=data.get("eval_duration", 0) / 1_000_000,
            raw_response=data,
        )
    
    def _handle_url_error(
        self,
        error: urllib.error.URLError,
        attempt: int,
    ) -> OllamaResponse:
        """Handle URL/connection errors."""
        reason = str(error.reason) if hasattr(error, 'reason') else str(error)
        
        self._logger.warning(f"Connection error (attempt {attempt}): {reason}")
        
        # Map common errors to friendly messages
        if "refused" in reason.lower():
            message = "Cannot connect to Ollama - service may not be running"
        elif "timed out" in reason.lower():
            message = f"Connection timed out after {self.timeout}s"
        else:
            message = f"Connection failed: {reason}"
        
        return OllamaResponse(
            status=ResponseStatus.ERROR,
            content="",
            model=self.model,
            error_message=message,
        )
    
    def _handle_http_error(
        self,
        error: urllib.error.HTTPError,
        attempt: int,
    ) -> OllamaResponse:
        """Handle HTTP errors."""
        self._logger.warning(f"HTTP error {error.code} (attempt {attempt})")
        
        # Map status codes to friendly messages
        error_messages = {
            400: "Bad request - check prompt format",
            404: f"Model '{self.model}' not found",
            429: "Rate limited - too many requests",
            500: "Ollama server error",
            503: "Ollama service unavailable",
        }
        
        message = error_messages.get(
            error.code,
            f"HTTP error {error.code}"
        )
        
        status = ResponseStatus.RATE_LIMITED if error.code == 429 else ResponseStatus.ERROR
        
        return OllamaResponse(
            status=status,
            content="",
            model=self.model,
            error_message=message,
        )
    
    def clear_history(self) -> None:
        """Clear conversation history."""
        self._history = []
        self._logger.debug("Conversation history cleared")
    
    def add_to_history(self, message: Message) -> None:
        """Add a message to conversation history."""
        self._history.append(message)
    
    def get_history(self) -> List[Message]:
        """Get current conversation history."""
        return self._history.copy()
    
    def test_connection(self) -> Tuple[bool, str]:
        """
        Test connection to Ollama with a simple prompt.
        
        Returns:
            Tuple of (success, message)
        """
        try:
            response = self.chat(
                prompt="Reply with just the word 'OK'.",
                temperature=0.0,
            )
            
            if response.is_success:
                return True, f"Connected successfully. Model: {self.model}"
            else:
                return False, response.error_message or "Unknown error"
                
        except Exception as e:
            return False, str(e)
    
    @property
    def is_ready(self) -> bool:
        """Check if client is ready for use."""
        success, _ = self.test_connection()
        return success
    
    def get_status(self) -> Dict[str, Any]:
        """Get client status information."""
        return {
            "model": self.model,
            "api_url": self.api_url,
            "timeout": self.timeout,
            "max_retries": self.max_retries,
            "history_length": len(self._history),
        }
    
    def __repr__(self) -> str:
        return f"OllamaClient(model={self.model!r}, api_url={self.api_url!r})"


def create_ollama_client(
    model: str,
    api_url: str = "http://127.0.0.1:11434",
    timeout: int = 120,
    system_prompt: Optional[str] = None,
) -> OllamaClient:
    """
    Factory function to create an Ollama client.
    
    Args:
        model: Model name to use
        api_url: Ollama API URL
        timeout: Request timeout
        system_prompt: Default system prompt
        
    Returns:
        Configured OllamaClient instance
    """
    return OllamaClient(
        model=model,
        api_url=api_url,
        timeout=timeout,
        system_prompt=system_prompt,
    )