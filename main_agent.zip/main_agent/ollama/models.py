"""
Ollama Model Detection & Safety Validation
==========================================
Detects installed models, validates RAM requirements,
and classifies models by safety level.

Safety Levels:
- SAFE: Model fits comfortably in available RAM
- RISKY: Model may cause system instability
- UNSUPPORTED: Model too large, blocked from use
"""

import urllib.request
import urllib.error
import json
import re
from typing import Dict, Any, Optional, List, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime

# Import from PART-1A
from main_agent.core.errors import (
    AgentError,
    ErrorCategory,
    ErrorSeverity,
)
from main_agent.utils.logger import Logger, get_logger
from main_agent.utils.system import SystemInfo, get_system_info


class ModelSafetyLevel(Enum):
    """Model safety classification based on RAM requirements."""
    SAFE = "SAFE"             # Fits comfortably (< 60% of available RAM)
    RISKY = "RISKY"           # May cause issues (60-85% of available RAM)
    UNSUPPORTED = "UNSUPPORTED"  # Too large (> 85% of available RAM)
    UNKNOWN = "UNKNOWN"       # Cannot determine size


@dataclass
class ModelInfo:
    """
    Information about an Ollama model.
    
    Contains model metadata and safety classification.
    """
    name: str                            # Model name (e.g., "llama2:latest")
    size_bytes: int                      # Model size in bytes
    size_gb: float                       # Model size in GB
    modified_at: Optional[str] = None    # Last modified timestamp
    digest: Optional[str] = None         # Model digest/hash
    family: Optional[str] = None         # Model family (llama, qwen, etc.)
    parameter_size: Optional[str] = None # Parameter count (7B, 13B, etc.)
    quantization: Optional[str] = None   # Quantization level (Q4, Q8, etc.)
    safety_level: ModelSafetyLevel = ModelSafetyLevel.UNKNOWN
    ram_required_gb: float = 0.0         # Estimated RAM required
    safety_reason: str = ""              # Explanation for safety level
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "size_gb": round(self.size_gb, 2),
            "family": self.family,
            "parameter_size": self.parameter_size,
            "quantization": self.quantization,
            "safety_level": self.safety_level.value,
            "ram_required_gb": round(self.ram_required_gb, 2),
            "safety_reason": self.safety_reason,
        }
    
    def __str__(self) -> str:
        safety_icon = {
            ModelSafetyLevel.SAFE: "✓",
            ModelSafetyLevel.RISKY: "⚠",
            ModelSafetyLevel.UNSUPPORTED: "✗",
            ModelSafetyLevel.UNKNOWN: "?",
        }.get(self.safety_level, "?")
        
        return (
            f"{self.name} – {self.safety_level.value} {safety_icon}\n"
            f"  Size: {self.size_gb:.1f}GB | RAM needed: ~{self.ram_required_gb:.1f}GB\n"
            f"  {self.safety_reason}"
        )


@dataclass
class ModelSelectionResult:
    """Result of model selection process."""
    success: bool
    selected_model: Optional[ModelInfo]
    available_models: List[ModelInfo]
    message: str
    

class NoModelsFoundError(AgentError):
    """Raised when no Ollama models are installed."""
    
    default_category = ErrorCategory.EXTERNAL
    default_severity = ErrorSeverity.CRITICAL
    default_suggestion = (
        "Pull a model with: ollama pull qwen2.5:3b (lightweight) "
        "or ollama pull llama2 (standard)"
    )


class NoSafeModelsError(AgentError):
    """Raised when no models are safe to run with available RAM."""
    
    default_category = ErrorCategory.SYSTEM
    default_severity = ErrorSeverity.HIGH
    default_suggestion = (
        "Free up RAM by closing applications, or pull a smaller model: "
        "ollama pull qwen2.5:0.5b"
    )


class OllamaModelManager:
    """
    Ollama Model Manager
    ====================
    
    Handles:
    - Model detection via Ollama API
    - Model size estimation
    - RAM safety validation
    - Model selection (interactive or automatic)
    
    Safety Classification Logic:
    - RAM needed ≈ model_size * 1.2 (20% overhead for inference)
    - SAFE: ram_needed < available_ram * 0.6
    - RISKY: available_ram * 0.6 <= ram_needed < available_ram * 0.85
    - UNSUPPORTED: ram_needed >= available_ram * 0.85
    
    Usage:
        manager = OllamaModelManager(api_url="http://127.0.0.1:11434")
        models = manager.get_installed_models()
        safe_models = manager.get_safe_models()
    """
    
    # RAM overhead factor for inference
    RAM_OVERHEAD_FACTOR = 1.2
    
    # Safety thresholds (percentage of available RAM)
    SAFE_THRESHOLD = 0.60       # Use up to 60% of available RAM
    RISKY_THRESHOLD = 0.85      # Up to 85% is risky but possible
    
    # Known model size patterns (parameter size -> approximate GB on disk)
    # These are rough estimates for Q4 quantized models
    KNOWN_SIZES = {
        "0.5b": 0.4,
        "1b": 0.7,
        "1.5b": 1.0,
        "3b": 2.0,
        "7b": 4.0,
        "8b": 4.5,
        "13b": 7.5,
        "14b": 8.0,
        "30b": 17.0,
        "34b": 19.0,
        "70b": 40.0,
    }
    
    def __init__(
        self,
        api_url: str = "http://127.0.0.1:11434",
        timeout: int = 30,
        logger: Optional[Logger] = None,
    ):
        """
        Initialize the model manager.
        
        Args:
            api_url: Ollama API base URL
            timeout: API request timeout in seconds
            logger: Optional logger instance
        """
        self.api_url = api_url.rstrip("/")
        self.timeout = timeout
        self._logger = logger or get_logger("OllamaModelManager")
        self._system_info: Optional[SystemInfo] = None
        self._models_cache: Optional[List[ModelInfo]] = None
    
    def _get_system_info(self) -> SystemInfo:
        """Get cached system info or fetch new."""
        if self._system_info is None:
            self._system_info = get_system_info()
        return self._system_info
    
    def set_system_info(self, system_info: SystemInfo) -> None:
        """Set system info from external source (e.g., main agent)."""
        self._system_info = system_info
    
    def get_installed_models(self, force_refresh: bool = False) -> List[ModelInfo]:
        """
        Get list of installed Ollama models.
        
        Queries the Ollama API for available models and
        enriches with size/safety information.
        
        Args:
            force_refresh: Bypass cache and fetch fresh data
            
        Returns:
            List of ModelInfo objects
            
        Raises:
            NoModelsFoundError: If no models are installed
        """
        if self._models_cache and not force_refresh:
            return self._models_cache
        
        self._logger.info("Fetching installed Ollama models...")
        
        try:
            request = urllib.request.Request(
                f"{self.api_url}/api/tags",
                method="GET",
                headers={"Content-Type": "application/json"},
            )
            
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                data = json.loads(response.read().decode())
                
            raw_models = data.get("models", [])
            
            if not raw_models:
                raise NoModelsFoundError(
                    reason="No Ollama models installed",
                    detail="The Ollama API returned an empty model list",
                )
            
            # Parse and enrich model information
            models = []
            for raw in raw_models:
                model = self._parse_model_info(raw)
                self._classify_model_safety(model)
                models.append(model)
            
            # Sort by safety (SAFE first) then by name
            models.sort(key=lambda m: (
                0 if m.safety_level == ModelSafetyLevel.SAFE else
                1 if m.safety_level == ModelSafetyLevel.RISKY else
                2,
                m.name
            ))
            
            self._models_cache = models
            self._logger.info(f"Found {len(models)} models")
            
            return models
            
        except urllib.error.URLError as e:
            raise AgentError(
                reason="Cannot connect to Ollama API",
                detail=str(e),
                suggestion="Ensure Ollama is running and accessible",
            )
        except json.JSONDecodeError as e:
            raise AgentError(
                reason="Invalid response from Ollama API",
                detail=str(e),
                suggestion="Check Ollama installation integrity",
            )
    
    def _parse_model_info(self, raw: Dict[str, Any]) -> ModelInfo:
        """Parse raw model data from Ollama API."""
        name = raw.get("name", "unknown")
        size_bytes = raw.get("size", 0)
        size_gb = size_bytes / (1024 ** 3)
        
        # Extract model family and parameters from name
        family, param_size, quant = self._parse_model_name(name)
        
        return ModelInfo(
            name=name,
            size_bytes=size_bytes,
            size_gb=size_gb,
            modified_at=raw.get("modified_at"),
            digest=raw.get("digest"),
            family=family,
            parameter_size=param_size,
            quantization=quant,
        )
    
    def _parse_model_name(self, name: str) -> Tuple[Optional[str], Optional[str], Optional[str]]:
        """
        Parse model name to extract family, parameter size, and quantization.
        
        Examples:
            "llama2:7b-q4_0" -> ("llama2", "7b", "q4_0")
            "qwen2.5:3b" -> ("qwen2.5", "3b", None)
            "mistral:latest" -> ("mistral", None, None)
        """
        family = None
        param_size = None
        quant = None
        
        # Split on colon
        parts = name.split(":")
        if len(parts) >= 1:
            family = parts[0]
        
        if len(parts) >= 2:
            tag = parts[1].lower()
            
            # Look for parameter size pattern
            param_match = re.search(r'(\d+\.?\d*b)', tag)
            if param_match:
                param_size = param_match.group(1)
            
            # Look for quantization pattern
            quant_match = re.search(r'(q\d+[_\w]*)', tag)
            if quant_match:
                quant = quant_match.group(1)
        
        return family, param_size, quant
    
    def _classify_model_safety(self, model: ModelInfo) -> None:
        """
        Classify model safety based on RAM requirements.
        
        Updates the model object with safety classification.
        """
        system = self._get_system_info()
        available_ram = system.available_ram_gb
        
        # Estimate RAM requirement
        # Base: model size * overhead factor
        # If we know the parameter size, use that for better estimation
        if model.parameter_size and model.parameter_size.lower() in self.KNOWN_SIZES:
            base_size = self.KNOWN_SIZES[model.parameter_size.lower()]
        else:
            base_size = model.size_gb
        
        ram_required = base_size * self.RAM_OVERHEAD_FACTOR
        model.ram_required_gb = ram_required
        
        # Calculate thresholds
        safe_limit = available_ram * self.SAFE_THRESHOLD
        risky_limit = available_ram * self.RISKY_THRESHOLD
        
        if ram_required < safe_limit:
            model.safety_level = ModelSafetyLevel.SAFE
            model.safety_reason = (
                f"Requires ~{ram_required:.1f}GB RAM, "
                f"you have {available_ram:.1f}GB available"
            )
        elif ram_required < risky_limit:
            model.safety_level = ModelSafetyLevel.RISKY
            model.safety_reason = (
                f"Uses {ram_required:.1f}GB of {available_ram:.1f}GB available RAM - "
                "may cause slowdowns"
            )
        else:
            model.safety_level = ModelSafetyLevel.UNSUPPORTED
            model.safety_reason = (
                f"Requires ~{ram_required:.1f}GB but only {available_ram:.1f}GB available - "
                "will cause system instability"
            )
    
    def get_safe_models(self) -> List[ModelInfo]:
        """Get only SAFE classified models."""
        models = self.get_installed_models()
        return [m for m in models if m.safety_level == ModelSafetyLevel.SAFE]
    
    def get_usable_models(self) -> List[ModelInfo]:
        """Get SAFE and RISKY models (excludes UNSUPPORTED)."""
        models = self.get_installed_models()
        return [
            m for m in models 
            if m.safety_level in (ModelSafetyLevel.SAFE, ModelSafetyLevel.RISKY)
        ]
    
    def select_best_model(self) -> ModelInfo:
        """
        Automatically select the best available model.
        
        Priority:
        1. First SAFE model
        2. First RISKY model (with warning)
        3. Error if no usable models
        
        Returns:
            Selected ModelInfo
            
        Raises:
            NoSafeModelsError: If no usable models available
        """
        models = self.get_installed_models()
        
        # Try SAFE models first
        safe_models = [m for m in models if m.safety_level == ModelSafetyLevel.SAFE]
        if safe_models:
            selected = safe_models[0]
            self._logger.info(f"Selected SAFE model: {selected.name}")
            return selected
        
        # Try RISKY models with warning
        risky_models = [m for m in models if m.safety_level == ModelSafetyLevel.RISKY]
        if risky_models:
            selected = risky_models[0]
            self._logger.warning(
                f"No SAFE models available. Selected RISKY model: {selected.name}"
            )
            self._logger.warning(f"  {selected.safety_reason}")
            return selected
        
        # No usable models
        raise NoSafeModelsError(
            reason="No usable models available",
            detail=(
                f"Found {len(models)} model(s), but all require more RAM than available. "
                f"Available RAM: {self._get_system_info().available_ram_gb:.1f}GB"
            ),
            context={
                "models": [m.name for m in models],
                "available_ram_gb": self._get_system_info().available_ram_gb,
            },
        )
    
    def select_model_interactive(self) -> ModelSelectionResult:
        """
        Present model selection to user (interactive mode).
        
        Shows available models with safety classification
        and allows user to choose.
        
        Returns:
            ModelSelectionResult with selected model
        """
        models = self.get_installed_models()
        usable = self.get_usable_models()
        
        if not usable:
            return ModelSelectionResult(
                success=False,
                selected_model=None,
                available_models=models,
                message="No usable models available",
            )
        
        # Print options
        print("\n" + "=" * 50)
        print("AVAILABLE OLLAMA MODELS")
        print("=" * 50)
        
        for i, model in enumerate(usable, 1):
            safety_icon = "✓ SAFE" if model.safety_level == ModelSafetyLevel.SAFE else "⚠ RISKY"
            print(f"\n  {i}. {model.name} – {safety_icon}")
            print(f"     Size: {model.size_gb:.1f}GB | RAM: ~{model.ram_required_gb:.1f}GB needed")
            if model.safety_level == ModelSafetyLevel.RISKY:
                print(f"     Warning: {model.safety_reason}")
        
        print("\n" + "-" * 50)
        
        # Get user choice
        while True:
            try:
                choice = input(f"Select model (1-{len(usable)}) or press Enter for auto: ").strip()
                
                if not choice:
                    # Auto-select
                    selected = self.select_best_model()
                    return ModelSelectionResult(
                        success=True,
                        selected_model=selected,
                        available_models=usable,
                        message=f"Auto-selected: {selected.name}",
                    )
                
                idx = int(choice) - 1
                if 0 <= idx < len(usable):
                    selected = usable[idx]
                    
                    # Confirm risky selection
                    if selected.safety_level == ModelSafetyLevel.RISKY:
                        confirm = input("This model is RISKY. Continue? (y/N): ").strip().lower()
                        if confirm != 'y':
                            print("Selection cancelled.")
                            continue
                    
                    return ModelSelectionResult(
                        success=True,
                        selected_model=selected,
                        available_models=usable,
                        message=f"Selected: {selected.name}",
                    )
                else:
                    print(f"Please enter a number between 1 and {len(usable)}")
                    
            except ValueError:
                print("Invalid input. Please enter a number.")
            except KeyboardInterrupt:
                return ModelSelectionResult(
                    success=False,
                    selected_model=None,
                    available_models=usable,
                    message="Selection cancelled by user",
                )
    
    def validate_model(self, model_name: str) -> Tuple[bool, Optional[ModelInfo], str]:
        """
        Validate a specific model by name.
        
        Args:
            model_name: Name of model to validate
            
        Returns:
            Tuple of (is_valid, model_info, message)
        """
        models = self.get_installed_models()
        
        # Find the model
        model = None
        for m in models:
            if m.name == model_name or m.name.startswith(model_name + ":"):
                model = m
                break
        
        if not model:
            return False, None, f"Model '{model_name}' not found"
        
        if model.safety_level == ModelSafetyLevel.UNSUPPORTED:
            return False, model, f"Model '{model_name}' is too large for available RAM"
        
        return True, model, f"Model '{model_name}' is usable ({model.safety_level.value})"
    
    def get_models_summary(self) -> Dict[str, Any]:
        """Get summary of available models and their status."""
        try:
            models = self.get_installed_models()
        except NoModelsFoundError:
            return {
                "total": 0,
                "safe": 0,
                "risky": 0,
                "unsupported": 0,
                "models": [],
            }
        
        return {
            "total": len(models),
            "safe": len([m for m in models if m.safety_level == ModelSafetyLevel.SAFE]),
            "risky": len([m for m in models if m.safety_level == ModelSafetyLevel.RISKY]),
            "unsupported": len([m for m in models if m.safety_level == ModelSafetyLevel.UNSUPPORTED]),
            "models": [m.to_dict() for m in models],
        }


def get_model_manager(
    api_url: str = "http://127.0.0.1:11434",
    system_info: Optional[SystemInfo] = None,
) -> OllamaModelManager:
    """
    Create and configure a model manager.
    
    Args:
        api_url: Ollama API URL
        system_info: Pre-collected system info
        
    Returns:
        Configured OllamaModelManager
    """
    manager = OllamaModelManager(api_url=api_url)
    if system_info:
        manager.set_system_info(system_info)
    return manager
