"""
Task Dispatcher
===============
Routes tasks to appropriate workers and manages execution.

Dispatcher Responsibilities:
1. Match tasks to capable workers
2. Send tasks to workers
3. Handle timeouts and retries
4. Collect and return results

Dispatch Flow:
1. Receive PlannedTask from Planner
2. Find capable workers from Registry
3. Select best worker
4. Send task to worker
5. Wait for result (with timeout)
6. Return structured result

Supported Worker Types:
- LOCAL: Direct function call
- REST_API: HTTP POST request
- SUBPROCESS: Command execution
"""

import time
import json
import threading
import urllib.request
import urllib.error
import subprocess
from typing import Dict, Any, Optional, List, Callable, Union
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, Future, TimeoutError as FutureTimeout
from abc import ABC, abstractmethod

# Import from PART-1A
from main_agent.core.errors import (
    AgentError,
    ErrorCategory,
    ErrorSeverity,
    format_error_response,
)
from main_agent.utils.logger import Logger, get_logger

# Import from registry
from main_agent.workers.registry import (
    WorkerRegistry,
    WorkerInfo,
    WorkerStatus,
    WorkerCapability,
    WorkerType,
)


class DispatchStatus(Enum):
    """Status of a dispatch operation."""
    SUCCESS = "SUCCESS"           # Task completed successfully
    PARTIAL = "PARTIAL"           # Partially completed
    FAILED = "FAILED"             # Task failed
    TIMEOUT = "TIMEOUT"           # Task timed out
    NO_WORKER = "NO_WORKER"       # No capable worker found
    REJECTED = "REJECTED"         # Worker rejected task
    CANCELLED = "CANCELLED"       # Task was cancelled


@dataclass
class TaskExecution:
    """
    Record of a task execution attempt.
    
    Tracks the journey of a task from dispatch to completion.
    """
    execution_id: str
    task_goal: str
    worker_id: Optional[str]
    worker_name: Optional[str]
    status: DispatchStatus
    started_at: datetime
    completed_at: Optional[datetime] = None
    duration_ms: float = 0.0
    attempts: int = 1
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "execution_id": self.execution_id,
            "task_goal": self.task_goal,
            "worker_id": self.worker_id,
            "worker_name": self.worker_name,
            "status": self.status.value,
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "duration_ms": round(self.duration_ms, 2),
            "attempts": self.attempts,
            "result": self.result,
            "error": self.error,
        }


@dataclass
class DispatchResult:
    """
    Result of dispatching a task.
    
    Contains execution details and task output.
    """
    status: DispatchStatus
    execution: TaskExecution
    output: Any = None                          # Task output data
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "status": self.status.value,
            "execution": self.execution.to_dict(),
            "output": self.output,
            "metadata": self.metadata,
        }
    
    @property
    def is_success(self) -> bool:
        """Check if dispatch was successful."""
        return self.status == DispatchStatus.SUCCESS
    
    @property
    def is_failure(self) -> bool:
        """Check if dispatch failed."""
        return self.status in (
            DispatchStatus.FAILED,
            DispatchStatus.TIMEOUT,
            DispatchStatus.NO_WORKER,
        )
    
    def __str__(self) -> str:
        status_icon = "✓" if self.is_success else "✗"
        return (
            f"{status_icon} Dispatch {self.status.value}\n"
            f"   Worker: {self.execution.worker_name or 'None'}\n"
            f"   Duration: {self.execution.duration_ms:.1f}ms\n"
            f"   Output: {str(self.output)[:100] if self.output else 'None'}"
        )


class DispatchError(AgentError):
    """Raised when task dispatch fails."""
    default_category = ErrorCategory.RUNTIME
    default_severity = ErrorSeverity.MEDIUM
    default_suggestion = "Check worker availability and task requirements"


class WorkerExecutor(ABC):
    """
    Abstract base for worker execution strategies.
    
    Different worker types need different execution methods.
    """
    
    @abstractmethod
    def execute(
        self,
        worker: WorkerInfo,
        task: Dict[str, Any],
        timeout_sec: int,
    ) -> Dict[str, Any]:
        """
        Execute task on worker.
        
        Args:
            worker: Worker to use
            task: Task data
            timeout_sec: Execution timeout
            
        Returns:
            Execution result dict with 'success', 'output', 'error' keys
        """
        pass


class LocalExecutor(WorkerExecutor):
    """
    Executor for LOCAL workers.
    
    Calls registered handler functions directly.
    """
    
    def __init__(self):
        self._handlers: Dict[str, Callable] = {}
    
    def register_handler(
        self,
        worker_id: str,
        handler: Callable[[Dict[str, Any]], Dict[str, Any]],
    ) -> None:
        """Register a handler function for a local worker."""
        self._handlers[worker_id] = handler
    
    def execute(
        self,
        worker: WorkerInfo,
        task: Dict[str, Any],
        timeout_sec: int,
    ) -> Dict[str, Any]:
        """Execute task via local handler."""
        handler = self._handlers.get(worker.worker_id)
        
        if not handler:
            return {
                "success": False,
                "output": None,
                "error": f"No handler registered for worker: {worker.worker_id}",
            }
        
        try:
            result = handler(task)
            return {
                "success": True,
                "output": result,
                "error": None,
            }
        except Exception as e:
            return {
                "success": False,
                "output": None,
                "error": str(e),
            }


class RestApiExecutor(WorkerExecutor):
    """
    Executor for REST_API workers.
    
    Sends tasks via HTTP POST and receives results.
    """
    
    def execute(
        self,
        worker: WorkerInfo,
        task: Dict[str, Any],
        timeout_sec: int,
    ) -> Dict[str, Any]:
        """Execute task via REST API."""
        if not worker.endpoint:
            return {
                "success": False,
                "output": None,
                "error": "Worker has no endpoint configured",
            }
        
        try:
            # Prepare request
            url = f"{worker.endpoint.rstrip('/')}/execute"
            data = json.dumps(task).encode('utf-8')
            
            headers = {
                "Content-Type": "application/json",
                "Accept": "application/json",
            }
            
            # Add auth if configured
            if worker.auth_token:
                headers["Authorization"] = f"Bearer {worker.auth_token}"
            
            request = urllib.request.Request(
                url,
                data=data,
                headers=headers,
                method="POST",
            )
            
            # Execute request
            with urllib.request.urlopen(request, timeout=timeout_sec) as response:
                result = json.loads(response.read().decode())
                
                return {
                    "success": result.get("success", True),
                    "output": result.get("output") or result.get("result"),
                    "error": result.get("error"),
                }
                
        except urllib.error.URLError as e:
            return {
                "success": False,
                "output": None,
                "error": f"Connection error: {e.reason}",
            }
        except urllib.error.HTTPError as e:
            return {
                "success": False,
                "output": None,
                "error": f"HTTP error {e.code}: {e.reason}",
            }
        except json.JSONDecodeError as e:
            return {
                "success": False,
                "output": None,
                "error": f"Invalid response: {e}",
            }
        except Exception as e:
            return {
                "success": False,
                "output": None,
                "error": str(e),
            }


class SubprocessExecutor(WorkerExecutor):
    """
    Executor for SUBPROCESS workers.
    
    Runs commands as child processes.
    """
    
    def execute(
        self,
        worker: WorkerInfo,
        task: Dict[str, Any],
        timeout_sec: int,
    ) -> Dict[str, Any]:
        """Execute task as subprocess."""
        command = task.get("command")
        
        if not command:
            return {
                "success": False,
                "output": None,
                "error": "No command specified in task",
            }
        
        # Security check: blocked commands
        if worker.blocked_commands:
            cmd_name = command.split()[0] if isinstance(command, str) else command[0]
            if cmd_name in worker.blocked_commands:
                return {
                    "success": False,
                    "output": None,
                    "error": f"Command blocked: {cmd_name}",
                }
        
        try:
            # Prepare command
            if isinstance(command, str):
                shell = True
                cmd = command
            else:
                shell = False
                cmd = command
            
            # Execute
            result = subprocess.run(
                cmd,
                shell=shell,
                capture_output=True,
                text=True,
                timeout=timeout_sec,
                cwd=task.get("cwd"),
                env=task.get("env"),
            )
            
            return {
                "success": result.returncode == 0,
                "output": {
                    "stdout": result.stdout,
                    "stderr": result.stderr,
                    "returncode": result.returncode,
                },
                "error": result.stderr if result.returncode != 0 else None,
            }
            
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "output": None,
                "error": f"Command timed out after {timeout_sec}s",
            }
        except Exception as e:
            return {
                "success": False,
                "output": None,
                "error": str(e),
            }


class TaskDispatcher:
    """
    Task Dispatcher
    ===============
    
    Routes tasks to workers and manages execution.
    
    Features:
    - Automatic worker selection
    - Multiple execution strategies
    - Timeout handling
    - Retry logic
    - Result aggregation
    
    Usage:
        registry = WorkerRegistry()
        dispatcher = TaskDispatcher(registry)
        
        # Dispatch a task
        result = dispatcher.dispatch(
            task=planned_task.to_dict(),
            required_capability=WorkerCapability.FILE_WRITE,
        )
        
        if result.is_success:
            print(result.output)
    
    Integration:
        The dispatcher receives PlannedTasks from the Planner
        and returns results to the Main Agent.
    """
    
    # Default settings
    DEFAULT_TIMEOUT_SEC = 60
    DEFAULT_MAX_RETRIES = 2
    DEFAULT_RETRY_DELAY_SEC = 1
    MAX_CONCURRENT_DISPATCHES = 10
    
    def __init__(
        self,
        registry: WorkerRegistry,
        logger: Optional[Logger] = None,
        default_timeout: int = DEFAULT_TIMEOUT_SEC,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ):
        """
        Initialize the dispatcher.
        
        Args:
            registry: Worker registry
            logger: Optional logger
            default_timeout: Default task timeout in seconds
            max_retries: Maximum retry attempts
        """
        self._registry = registry
        self._logger = logger or get_logger("TaskDispatcher")
        self._default_timeout = default_timeout
        self._max_retries = max_retries
        
        # Executors for different worker types
        self._executors: Dict[WorkerType, WorkerExecutor] = {
            WorkerType.LOCAL: LocalExecutor(),
            WorkerType.REST_API: RestApiExecutor(),
            WorkerType.SUBPROCESS: SubprocessExecutor(),
        }
        
        # Thread pool for concurrent execution
        self._executor_pool = ThreadPoolExecutor(
            max_workers=self.MAX_CONCURRENT_DISPATCHES,
            thread_name_prefix="Dispatch",
        )
        
        # Execution history
        self._execution_history: List[TaskExecution] = []
        self._max_history = 100
        self._history_lock = threading.Lock()
        
        # Active executions
        self._active_executions: Dict[str, Future] = {}
        
        # Statistics
        self._total_dispatches = 0
        self._successful_dispatches = 0
        self._failed_dispatches = 0
        
        self._logger.debug("TaskDispatcher initialized")
    
    def register_local_handler(
        self,
        worker_id: str,
        handler: Callable[[Dict[str, Any]], Dict[str, Any]],
    ) -> None:
        """
        Register a handler for a local worker.
        
        Args:
            worker_id: Worker ID
            handler: Function to handle tasks
        """
        local_executor = self._executors.get(WorkerType.LOCAL)
        if isinstance(local_executor, LocalExecutor):
            local_executor.register_handler(worker_id, handler)
            self._logger.debug(f"Handler registered for worker: {worker_id}")
    
    def dispatch(
        self,
        task: Dict[str, Any],
        required_capability: Optional[WorkerCapability] = None,
        worker_id: Optional[str] = None,
        timeout_sec: Optional[int] = None,
        retry: bool = True,
    ) -> DispatchResult:
        """
        Dispatch a task to a worker.
        
        Args:
            task: Task data (usually from PlannedTask.to_dict())
            required_capability: Required worker capability
            worker_id: Specific worker ID (optional)
            timeout_sec: Task timeout
            retry: Whether to retry on failure
            
        Returns:
            DispatchResult with execution status and output
        """
        self._total_dispatches += 1
        execution_id = f"exec-{self._total_dispatches}-{int(time.time())}"
        started_at = datetime.now()
        timeout = timeout_sec or self._default_timeout
        
        task_goal = task.get("goal", "Unknown task")[:100]
        
        self._logger.info(f"Dispatching task: {task_goal}")
        
        # Find worker
        worker = self._find_worker(
            required_capability=required_capability,
            worker_id=worker_id,
        )
        
        if not worker:
            self._failed_dispatches += 1
            execution = TaskExecution(
                execution_id=execution_id,
                task_goal=task_goal,
                worker_id=None,
                worker_name=None,
                status=DispatchStatus.NO_WORKER,
                started_at=started_at,
                completed_at=datetime.now(),
                error="No capable worker available",
            )
            self._record_execution(execution)
            
            return DispatchResult(
                status=DispatchStatus.NO_WORKER,
                execution=execution,
                metadata={"required_capability": required_capability.value if required_capability else None},
            )
        
        # Execute with retries
        attempts = 0
        max_attempts = self._max_retries + 1 if retry else 1
        last_error = None
        
        while attempts < max_attempts:
            attempts += 1
            
            self._logger.debug(
                f"Attempt {attempts}/{max_attempts} on worker {worker.name}"
            )
            
            # Record task start
            self._registry.record_task_start(worker.worker_id)
            
            try:
                result = self._execute_on_worker(worker, task, timeout)
                
                if result["success"]:
                    # Success!
                    duration = (datetime.now() - started_at).total_seconds() * 1000
                    
                    self._registry.record_task_complete(
                        worker.worker_id,
                        success=True,
                        duration_ms=duration,
                    )
                    
                    self._successful_dispatches += 1
                    
                    execution = TaskExecution(
                        execution_id=execution_id,
                        task_goal=task_goal,
                        worker_id=worker.worker_id,
                        worker_name=worker.name,
                        status=DispatchStatus.SUCCESS,
                        started_at=started_at,
                        completed_at=datetime.now(),
                        duration_ms=duration,
                        attempts=attempts,
                        result=result,
                    )
                    self._record_execution(execution)
                    
                    self._logger.info(
                        f"Task completed: {task_goal[:50]}... ({duration:.1f}ms)"
                    )
                    
                    return DispatchResult(
                        status=DispatchStatus.SUCCESS,
                        execution=execution,
                        output=result.get("output"),
                    )
                else:
                    # Task failed
                    last_error = result.get("error", "Unknown error")
                    
                    self._registry.record_task_complete(
                        worker.worker_id,
                        success=False,
                    )
                    
                    self._logger.warning(
                        f"Attempt {attempts} failed: {last_error}"
                    )
                    
                    # Retry delay
                    if attempts < max_attempts:
                        time.sleep(self.DEFAULT_RETRY_DELAY_SEC * attempts)
                    
            except Exception as e:
                last_error = str(e)
                
                self._registry.record_task_complete(
                    worker.worker_id,
                    success=False,
                )
                
                self._logger.error(f"Execution error: {e}")
                
                if attempts < max_attempts:
                    time.sleep(self.DEFAULT_RETRY_DELAY_SEC * attempts)
        
        # All attempts failed
        duration = (datetime.now() - started_at).total_seconds() * 1000
        self._failed_dispatches += 1
        
        execution = TaskExecution(
            execution_id=execution_id,
            task_goal=task_goal,
            worker_id=worker.worker_id,
            worker_name=worker.name,
            status=DispatchStatus.FAILED,
            started_at=started_at,
            completed_at=datetime.now(),
            duration_ms=duration,
            attempts=attempts,
            error=last_error,
        )
        self._record_execution(execution)
        
        self._logger.error(
            f"Task failed after {attempts} attempts: {last_error}"
        )
        
        return DispatchResult(
            status=DispatchStatus.FAILED,
            execution=execution,
            metadata={"last_error": last_error},
        )
    
    def dispatch_async(
        self,
        task: Dict[str, Any],
        required_capability: Optional[WorkerCapability] = None,
        callback: Optional[Callable[[DispatchResult], None]] = None,
    ) -> str:
        """
        Dispatch a task asynchronously.
        
        Args:
            task: Task data
            required_capability: Required capability
            callback: Optional callback on completion
            
        Returns:
            Execution ID for tracking
        """
        execution_id = f"async-{self._total_dispatches}-{int(time.time())}"
        
        def run_dispatch():
            result = self.dispatch(
                task=task,
                required_capability=required_capability,
            )
            if callback:
                try:
                    callback(result)
                except Exception as e:
                    self._logger.error(f"Async callback error: {e}")
            return result
        
        future = self._executor_pool.submit(run_dispatch)
        self._active_executions[execution_id] = future
        
        return execution_id
    
    def get_async_result(
        self,
        execution_id: str,
        timeout_sec: int = 30,
    ) -> Optional[DispatchResult]:
        """
        Get result of async dispatch.
        
        Args:
            execution_id: ID from dispatch_async
            timeout_sec: Wait timeout
            
        Returns:
            DispatchResult or None if not found/timeout
        """
        future = self._active_executions.get(execution_id)
        if not future:
            return None
        
        try:
            result = future.result(timeout=timeout_sec)
            del self._active_executions[execution_id]
            return result
        except FutureTimeout:
            return None
        except Exception as e:
            self._logger.error(f"Async result error: {e}")
            return None
    
    def cancel_async(self, execution_id: str) -> bool:
        """Cancel an async dispatch."""
        future = self._active_executions.get(execution_id)
        if future:
            cancelled = future.cancel()
            if cancelled:
                del self._active_executions[execution_id]
            return cancelled
        return False
    
    def _find_worker(
        self,
        required_capability: Optional[WorkerCapability],
        worker_id: Optional[str],
    ) -> Optional[WorkerInfo]:
        """Find appropriate worker for task."""
        # Specific worker requested
        if worker_id:
            worker = self._registry.get(worker_id)
            if worker and worker.is_available:
                return worker
            else:
                self._logger.warning(
                    f"Requested worker {worker_id} not available"
                )
                return None
        
        # Find by capability
        if required_capability:
            worker = self._registry.get_best_worker(
                capability=required_capability,
                prefer_local=True,
            )
            return worker
        
        # No capability specified - get any available worker
        available = self._registry.get_available()
        if available:
            return available[0]
        
        return None
    
    def _execute_on_worker(
        self,
        worker: WorkerInfo,
        task: Dict[str, Any],
        timeout_sec: int,
    ) -> Dict[str, Any]:
        """Execute task on specific worker."""
        executor = self._executors.get(worker.worker_type)
        
        if not executor:
            return {
                "success": False,
                "output": None,
                "error": f"No executor for worker type: {worker.worker_type.value}",
            }
        
        return executor.execute(worker, task, timeout_sec)
    
    def _record_execution(self, execution: TaskExecution) -> None:
        """Record execution in history."""
        with self._history_lock:
            self._execution_history.append(execution)
            
            if len(self._execution_history) > self._max_history:
                self._execution_history = self._execution_history[-self._max_history:]
    
    def get_execution_history(
        self,
        limit: int = 20,
        status: Optional[DispatchStatus] = None,
    ) -> List[TaskExecution]:
        """
        Get execution history.
        
        Args:
            limit: Max entries to return
            status: Filter by status
        """
        with self._history_lock:
            history = self._execution_history[-limit:]
            
            if status:
                history = [e for e in history if e.status == status]
            
            return history
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get dispatcher statistics."""
        return {
            "total_dispatches": self._total_dispatches,
            "successful": self._successful_dispatches,
            "failed": self._failed_dispatches,
            "success_rate": (
                self._successful_dispatches / self._total_dispatches * 100
                if self._total_dispatches > 0 else 0
            ),
            "active_async": len(self._active_executions),
            "history_size": len(self._execution_history),
            "registry_stats": self._registry.get_statistics(),
        }
    
    def shutdown(self, wait: bool = True) -> None:
        """Shutdown the dispatcher."""
        self._logger.info("Shutting down TaskDispatcher...")
        
        # Cancel active executions
        for exec_id in list(self._active_executions.keys()):
            self.cancel_async(exec_id)
        
        # Shutdown thread pool
        self._executor_pool.shutdown(wait=wait)
        
        self._logger.info("TaskDispatcher shutdown complete")
    
    def __repr__(self) -> str:
        return (
            f"TaskDispatcher(dispatches={self._total_dispatches}, "
            f"success_rate={self._successful_dispatches}/{self._total_dispatches})"
        )