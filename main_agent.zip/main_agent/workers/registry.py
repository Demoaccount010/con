"""
Worker Registry
===============
Manages registration, capabilities, and health of workers.

Workers are task executors that:
- Register their capabilities
- Accept tasks matching their skills
- Report execution results
- Maintain health status

Registry Responsibilities:
1. Store worker metadata
2. Track worker health
3. Match tasks to capable workers
4. Handle worker lifecycle

Worker Types:
- LOCAL: Runs in same process
- SUBPROCESS: Runs as child process
- REST_API: Remote worker via HTTP
- DOCKER: Containerized worker
"""

import time
import threading
import uuid
from typing import Dict, Any, Optional, List, Callable, Set
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta
from abc import ABC, abstractmethod

# Import from PART-1A
from main_agent.core.errors import (
    AgentError,
    ErrorCategory,
    ErrorSeverity,
)
from main_agent.utils.logger import Logger, get_logger


class WorkerStatus(Enum):
    """
    Worker health/availability status.
    """
    AVAILABLE = "AVAILABLE"       # Ready to accept tasks
    BUSY = "BUSY"                 # Currently executing
    PAUSED = "PAUSED"             # Temporarily not accepting
    UNHEALTHY = "UNHEALTHY"       # Failing health checks
    OFFLINE = "OFFLINE"           # Not reachable
    UNKNOWN = "UNKNOWN"           # Status not determined


class WorkerType(Enum):
    """
    Types of workers based on execution environment.
    """
    LOCAL = "LOCAL"               # In-process execution
    SUBPROCESS = "SUBPROCESS"     # Child process
    REST_API = "REST_API"         # Remote HTTP worker
    DOCKER = "DOCKER"             # Docker container
    PLUGIN = "PLUGIN"             # Dynamically loaded plugin


class WorkerCapability(Enum):
    """
    Standard worker capabilities.
    
    Workers declare what types of tasks they can handle.
    """
    # File operations
    FILE_READ = "FILE_READ"
    FILE_WRITE = "FILE_WRITE"
    FILE_DELETE = "FILE_DELETE"
    
    # Code operations
    CODE_EXECUTE = "CODE_EXECUTE"
    CODE_ANALYZE = "CODE_ANALYZE"
    
    # System operations
    SYSTEM_COMMAND = "SYSTEM_COMMAND"
    PROCESS_MANAGE = "PROCESS_MANAGE"
    
    # Network operations
    HTTP_REQUEST = "HTTP_REQUEST"
    WEB_SCRAPE = "WEB_SCRAPE"
    API_CALL = "API_CALL"
    
    # Data operations
    DATA_PARSE = "DATA_PARSE"
    DATA_TRANSFORM = "DATA_TRANSFORM"
    DATA_ANALYZE = "DATA_ANALYZE"
    
    # Special
    LLM_QUERY = "LLM_QUERY"
    BROWSER_CONTROL = "BROWSER_CONTROL"
    
    # Generic
    GENERIC = "GENERIC"


@dataclass
class WorkerInfo:
    """
    Complete information about a registered worker.
    """
    worker_id: str                                      # Unique identifier
    name: str                                           # Human-readable name
    worker_type: WorkerType                             # Execution type
    capabilities: Set[WorkerCapability]                 # What it can do
    status: WorkerStatus = WorkerStatus.UNKNOWN         # Current status
    
    # Connection details (for remote workers)
    endpoint: Optional[str] = None                      # REST API URL
    auth_token: Optional[str] = None                    # Authentication
    
    # Health tracking
    last_heartbeat: Optional[datetime] = None
    last_task_time: Optional[datetime] = None
    consecutive_failures: int = 0
    total_tasks_completed: int = 0
    total_tasks_failed: int = 0
    
    # Performance
    avg_response_time_ms: float = 0.0
    max_concurrent_tasks: int = 1
    current_tasks: int = 0
    
    # Metadata
    registered_at: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    
    # Permissions
    allowed_paths: List[str] = field(default_factory=list)      # File paths
    blocked_commands: List[str] = field(default_factory=list)   # Blocked cmds
    requires_approval: bool = False                              # Human approval
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "worker_id": self.worker_id,
            "name": self.name,
            "type": self.worker_type.value,
            "capabilities": [c.value for c in self.capabilities],
            "status": self.status.value,
            "endpoint": self.endpoint,
            "health": {
                "last_heartbeat": self.last_heartbeat.isoformat() if self.last_heartbeat else None,
                "consecutive_failures": self.consecutive_failures,
                "total_completed": self.total_tasks_completed,
                "total_failed": self.total_tasks_failed,
            },
            "performance": {
                "avg_response_ms": round(self.avg_response_time_ms, 2),
                "max_concurrent": self.max_concurrent_tasks,
                "current_tasks": self.current_tasks,
            },
            "registered_at": self.registered_at.isoformat(),
            "tags": self.tags,
        }
    
    @property
    def is_available(self) -> bool:
        """Check if worker can accept tasks."""
        return (
            self.status == WorkerStatus.AVAILABLE and
            self.current_tasks < self.max_concurrent_tasks
        )
    
    @property
    def is_healthy(self) -> bool:
        """Check if worker is healthy."""
        return self.status not in (WorkerStatus.UNHEALTHY, WorkerStatus.OFFLINE)
    
    @property
    def success_rate(self) -> float:
        """Calculate success rate percentage."""
        total = self.total_tasks_completed + self.total_tasks_failed
        if total == 0:
            return 100.0
        return (self.total_tasks_completed / total) * 100
    
    def has_capability(self, capability: WorkerCapability) -> bool:
        """Check if worker has specific capability."""
        return capability in self.capabilities or WorkerCapability.GENERIC in self.capabilities
    
    def has_any_capability(self, capabilities: List[WorkerCapability]) -> bool:
        """Check if worker has any of the given capabilities."""
        return any(self.has_capability(cap) for cap in capabilities)
    
    def __str__(self) -> str:
        caps = ", ".join(c.value for c in list(self.capabilities)[:3])
        if len(self.capabilities) > 3:
            caps += f" +{len(self.capabilities) - 3} more"
        return (
            f"Worker({self.name}, {self.worker_type.value}, "
            f"status={self.status.value}, caps=[{caps}])"
        )


class WorkerRegistryError(AgentError):
    """Raised when worker registry operations fail."""
    default_category = ErrorCategory.RUNTIME
    default_severity = ErrorSeverity.MEDIUM
    default_suggestion = "Check worker configuration and availability"


class WorkerRegistry:
    """
    Worker Registry
    ===============
    
    Central registry for all workers in the system.
    
    Responsibilities:
    1. Register/unregister workers
    2. Track worker health and status
    3. Find workers by capability
    4. Manage worker lifecycle
    
    Usage:
        registry = WorkerRegistry()
        
        # Register a worker
        worker = WorkerInfo(
            worker_id="file-worker-1",
            name="File Operations Worker",
            worker_type=WorkerType.LOCAL,
            capabilities={WorkerCapability.FILE_READ, WorkerCapability.FILE_WRITE},
        )
        registry.register(worker)
        
        # Find workers for a task
        workers = registry.find_by_capability(WorkerCapability.FILE_READ)
        
        # Get best worker
        best = registry.get_best_worker(WorkerCapability.FILE_READ)
    """
    
    # Health check settings
    HEARTBEAT_TIMEOUT_SEC = 60
    HEALTH_CHECK_INTERVAL_SEC = 30
    MAX_FAILURES_BEFORE_UNHEALTHY = 3
    
    def __init__(self, logger: Optional[Logger] = None):
        """
        Initialize the worker registry.
        
        Args:
            logger: Optional logger instance
        """
        self._logger = logger or get_logger("WorkerRegistry")
        
        # Worker storage
        self._workers: Dict[str, WorkerInfo] = {}
        self._lock = threading.RLock()
        
        # Health monitoring
        self._health_check_thread: Optional[threading.Thread] = None
        self._running = False
        
        # Callbacks
        self._on_worker_added: List[Callable[[WorkerInfo], None]] = []
        self._on_worker_removed: List[Callable[[WorkerInfo], None]] = []
        self._on_status_change: List[Callable[[WorkerInfo, WorkerStatus], None]] = []
        
        self._logger.debug("WorkerRegistry initialized")
    
    def register(
        self,
        worker: WorkerInfo,
        replace: bool = False,
    ) -> bool:
        """
        Register a new worker.
        
        Args:
            worker: Worker information
            replace: Replace if worker ID exists
            
        Returns:
            True if registration successful
            
        Raises:
            WorkerRegistryError: If worker already exists and replace=False
        """
        with self._lock:
            if worker.worker_id in self._workers and not replace:
                raise WorkerRegistryError(
                    reason=f"Worker already registered: {worker.worker_id}",
                    detail="Use replace=True to update existing worker",
                    suggestion="Use a different worker_id or set replace=True",
                )
            
            # Set initial status
            if worker.status == WorkerStatus.UNKNOWN:
                worker.status = WorkerStatus.AVAILABLE
            
            worker.last_heartbeat = datetime.now()
            worker.registered_at = datetime.now()
            
            self._workers[worker.worker_id] = worker
            
            self._logger.info(
                f"Worker registered: {worker.name} ({worker.worker_id})"
            )
            
            # Notify callbacks
            for callback in self._on_worker_added:
                try:
                    callback(worker)
                except Exception as e:
                    self._logger.error(f"Worker added callback error: {e}")
            
            return True
    
    def unregister(self, worker_id: str) -> bool:
        """
        Unregister a worker.
        
        Args:
            worker_id: Worker ID to remove
            
        Returns:
            True if worker was removed, False if not found
        """
        with self._lock:
            if worker_id not in self._workers:
                self._logger.warning(f"Worker not found: {worker_id}")
                return False
            
            worker = self._workers.pop(worker_id)
            
            self._logger.info(
                f"Worker unregistered: {worker.name} ({worker_id})"
            )
            
            # Notify callbacks
            for callback in self._on_worker_removed:
                try:
                    callback(worker)
                except Exception as e:
                    self._logger.error(f"Worker removed callback error: {e}")
            
            return True
    
    def get(self, worker_id: str) -> Optional[WorkerInfo]:
        """
        Get worker by ID.
        
        Args:
            worker_id: Worker ID
            
        Returns:
            WorkerInfo or None if not found
        """
        with self._lock:
            return self._workers.get(worker_id)
    
    def get_all(self) -> List[WorkerInfo]:
        """Get all registered workers."""
        with self._lock:
            return list(self._workers.values())
    
    def get_available(self) -> List[WorkerInfo]:
        """Get all available workers."""
        with self._lock:
            return [w for w in self._workers.values() if w.is_available]
    
    def find_by_capability(
        self,
        capability: WorkerCapability,
        only_available: bool = True,
    ) -> List[WorkerInfo]:
        """
        Find workers with a specific capability.
        
        Args:
            capability: Required capability
            only_available: Only return available workers
            
        Returns:
            List of matching workers
        """
        with self._lock:
            workers = [
                w for w in self._workers.values()
                if w.has_capability(capability)
            ]
            
            if only_available:
                workers = [w for w in workers if w.is_available]
            
            return workers
    
    def find_by_capabilities(
        self,
        capabilities: List[WorkerCapability],
        match_all: bool = False,
        only_available: bool = True,
    ) -> List[WorkerInfo]:
        """
        Find workers with specified capabilities.
        
        Args:
            capabilities: Required capabilities
            match_all: If True, worker must have ALL capabilities
            only_available: Only return available workers
            
        Returns:
            List of matching workers
        """
        with self._lock:
            workers = []
            
            for w in self._workers.values():
                if only_available and not w.is_available:
                    continue
                
                if match_all:
                    # Must have all capabilities
                    if all(w.has_capability(cap) for cap in capabilities):
                        workers.append(w)
                else:
                    # Must have at least one
                    if w.has_any_capability(capabilities):
                        workers.append(w)
            
            return workers
    
    def find_by_type(
        self,
        worker_type: WorkerType,
        only_available: bool = True,
    ) -> List[WorkerInfo]:
        """
        Find workers of a specific type.
        
        Args:
            worker_type: Worker type to find
            only_available: Only return available workers
            
        Returns:
            List of matching workers
        """
        with self._lock:
            workers = [
                w for w in self._workers.values()
                if w.worker_type == worker_type
            ]
            
            if only_available:
                workers = [w for w in workers if w.is_available]
            
            return workers
    
    def find_by_tag(
        self,
        tag: str,
        only_available: bool = True,
    ) -> List[WorkerInfo]:
        """
        Find workers with a specific tag.
        
        Args:
            tag: Tag to search for
            only_available: Only return available workers
            
        Returns:
            List of matching workers
        """
        with self._lock:
            workers = [
                w for w in self._workers.values()
                if tag in w.tags
            ]
            
            if only_available:
                workers = [w for w in workers if w.is_available]
            
            return workers
    
    def get_best_worker(
        self,
        capability: WorkerCapability,
        prefer_local: bool = True,
    ) -> Optional[WorkerInfo]:
        """
        Get the best available worker for a capability.
        
        Selection criteria:
        1. Has capability
        2. Is available
        3. Lowest current tasks
        4. Highest success rate
        5. Prefer local if specified
        
        Args:
            capability: Required capability
            prefer_local: Prefer local workers over remote
            
        Returns:
            Best worker or None if none available
        """
        candidates = self.find_by_capability(capability, only_available=True)
        
        if not candidates:
            return None
        
        def score_worker(w: WorkerInfo) -> tuple:
            """Score worker for sorting (lower is better)."""
            type_score = 0 if (prefer_local and w.worker_type == WorkerType.LOCAL) else 1
            load_score = w.current_tasks / max(w.max_concurrent_tasks, 1)
            failure_score = 100 - w.success_rate
            
            return (type_score, load_score, failure_score)
        
        candidates.sort(key=score_worker)
        return candidates[0]
    
    def update_status(
        self,
        worker_id: str,
        status: WorkerStatus,
    ) -> bool:
        """
        Update worker status.
        
        Args:
            worker_id: Worker ID
            status: New status
            
        Returns:
            True if updated, False if worker not found
        """
        with self._lock:
            worker = self._workers.get(worker_id)
            if not worker:
                return False
            
            old_status = worker.status
            worker.status = status
            worker.last_heartbeat = datetime.now()
            
            if old_status != status:
                self._logger.info(
                    f"Worker {worker.name} status: {old_status.value} → {status.value}"
                )
                
                # Notify callbacks
                for callback in self._on_status_change:
                    try:
                        callback(worker, old_status)
                    except Exception as e:
                        self._logger.error(f"Status change callback error: {e}")
            
            return True
    
    def record_heartbeat(self, worker_id: str) -> bool:
        """
        Record a heartbeat from worker.
        
        Args:
            worker_id: Worker ID
            
        Returns:
            True if recorded, False if worker not found
        """
        with self._lock:
            worker = self._workers.get(worker_id)
            if not worker:
                return False
            
            worker.last_heartbeat = datetime.now()
            
            # Reset failures on heartbeat
            if worker.consecutive_failures > 0:
                worker.consecutive_failures = 0
                if worker.status == WorkerStatus.UNHEALTHY:
                    worker.status = WorkerStatus.AVAILABLE
            
            return True
    
    def record_task_start(self, worker_id: str) -> bool:
        """Record that worker started a task."""
        with self._lock:
            worker = self._workers.get(worker_id)
            if not worker:
                return False
            
            worker.current_tasks += 1
            worker.last_task_time = datetime.now()
            
            if worker.current_tasks >= worker.max_concurrent_tasks:
                worker.status = WorkerStatus.BUSY
            
            return True
    
    def record_task_complete(
        self,
        worker_id: str,
        success: bool,
        duration_ms: float = 0,
    ) -> bool:
        """
        Record task completion.
        
        Args:
            worker_id: Worker ID
            success: Whether task succeeded
            duration_ms: Task duration in milliseconds
        """
        with self._lock:
            worker = self._workers.get(worker_id)
            if not worker:
                return False
            
            worker.current_tasks = max(0, worker.current_tasks - 1)
            
            if success:
                worker.total_tasks_completed += 1
                worker.consecutive_failures = 0
            else:
                worker.total_tasks_failed += 1
                worker.consecutive_failures += 1
                
                if worker.consecutive_failures >= self.MAX_FAILURES_BEFORE_UNHEALTHY:
                    worker.status = WorkerStatus.UNHEALTHY
            
            # Update average response time
            if duration_ms > 0:
                total_tasks = worker.total_tasks_completed + worker.total_tasks_failed
                if total_tasks == 1:
                    worker.avg_response_time_ms = duration_ms
                else:
                    # Rolling average
                    worker.avg_response_time_ms = (
                        worker.avg_response_time_ms * 0.9 + duration_ms * 0.1
                    )
            
            # Update status if was busy
            if worker.status == WorkerStatus.BUSY and worker.current_tasks < worker.max_concurrent_tasks:
                worker.status = WorkerStatus.AVAILABLE
            
            return True
    
    def start_health_monitoring(self) -> None:
        """Start background health monitoring."""
        if self._running:
            return
        
        self._running = True
        self._health_check_thread = threading.Thread(
            target=self._health_check_loop,
            name="WorkerHealthCheck",
            daemon=True,
        )
        self._health_check_thread.start()
        self._logger.info("Worker health monitoring started")
    
    def stop_health_monitoring(self) -> None:
        """Stop background health monitoring."""
        self._running = False
        if self._health_check_thread:
            self._health_check_thread.join(timeout=5)
        self._logger.info("Worker health monitoring stopped")
    
    def _health_check_loop(self) -> None:
        """Background health check loop."""
        while self._running:
            try:
                self._check_worker_health()
            except Exception as e:
                self._logger.error(f"Health check error: {e}")
            
            # Sleep in chunks for quick shutdown
            for _ in range(self.HEALTH_CHECK_INTERVAL_SEC):
                if not self._running:
                    return
                time.sleep(1)
    
    def _check_worker_health(self) -> None:
        """Check health of all workers."""
        now = datetime.now()
        timeout = timedelta(seconds=self.HEARTBEAT_TIMEOUT_SEC)
        
        with self._lock:
            for worker in self._workers.values():
                # Skip if no heartbeat recorded yet
                if not worker.last_heartbeat:
                    continue
                
                # Check heartbeat timeout
                if now - worker.last_heartbeat > timeout:
                    if worker.status not in (WorkerStatus.OFFLINE, WorkerStatus.UNHEALTHY):
                        self._logger.warning(
                            f"Worker {worker.name} heartbeat timeout"
                        )
                        old_status = worker.status
                        worker.status = WorkerStatus.OFFLINE
                        
                        for callback in self._on_status_change:
                            try:
                                callback(worker, old_status)
                            except:
                                pass
    
    def add_worker_added_callback(
        self,
        callback: Callable[[WorkerInfo], None],
    ) -> None:
        """Add callback for worker registration."""
        self._on_worker_added.append(callback)
    
    def add_worker_removed_callback(
        self,
        callback: Callable[[WorkerInfo], None],
    ) -> None:
        """Add callback for worker removal."""
        self._on_worker_removed.append(callback)
    
    def add_status_change_callback(
        self,
        callback: Callable[[WorkerInfo, WorkerStatus], None],
    ) -> None:
        """Add callback for status changes."""
        self._on_status_change.append(callback)
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get registry statistics."""
        with self._lock:
            total = len(self._workers)
            available = len([w for w in self._workers.values() if w.is_available])
            busy = len([w for w in self._workers.values() if w.status == WorkerStatus.BUSY])
            unhealthy = len([w for w in self._workers.values() if not w.is_healthy])
            
            # Capability distribution
            cap_counts: Dict[str, int] = {}
            for w in self._workers.values():
                for cap in w.capabilities:
                    cap_counts[cap.value] = cap_counts.get(cap.value, 0) + 1
            
            # Type distribution
            type_counts: Dict[str, int] = {}
            for w in self._workers.values():
                t = w.worker_type.value
                type_counts[t] = type_counts.get(t, 0) + 1
            
            return {
                "total_workers": total,
                "available": available,
                "busy": busy,
                "unhealthy": unhealthy,
                "by_type": type_counts,
                "by_capability": cap_counts,
            }
    
    @property
    def count(self) -> int:
        """Get total worker count."""
        return len(self._workers)
    
    @property
    def available_count(self) -> int:
        """Get available worker count."""
        return len(self.get_available())
    
    def __repr__(self) -> str:
        return f"WorkerRegistry(workers={self.count}, available={self.available_count})"
    
    def __len__(self) -> int:
        return self.count


def generate_worker_id(prefix: str = "worker") -> str:
    """Generate a unique worker ID."""
    return f"{prefix}-{uuid.uuid4().hex[:8]}"