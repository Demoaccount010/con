# Don't Remove Credit Tg - @VJ_Bots
# Subscribe YouTube Channel For Amazing Bot https://youtube.com/@Tech_VJ
# Ask Doubt on telegram @KingVJ01

import os
import asyncio 
import pyrogram
import re

from pyrogram import Client, filters, enums
from pyrogram.errors import FloodWait, UserIsBlocked, InputUserDeactivated, UserAlreadyParticipant, InviteHashExpired, UsernameNotOccupied
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, Message 
from config import API_ID, API_HASH, ERROR_MESSAGE, LOGIN_SYSTEM, STRING_SESSION, CHANNEL_ID, WAITING_TIME
from database.db import db
from TechVJ.strings import HELP_TXT
from bot import TechVJUser

class batch_temp(object):
    IS_BATCH = {}

async def downstatus(client, statusfile, message, chat):
    while True:
        if os.path.exists(statusfile):
            break

        await asyncio.sleep(3)
      
    while os.path.exists(statusfile):
        with open(statusfile, "r") as downread:
            txt = downread.read()
        try:
            await client.edit_message_text(chat, message.id, f"**Downloaded:** **{txt}**")
            await asyncio.sleep(10)
        except:
            await asyncio.sleep(5)


# upload status
async def upstatus(client, statusfile, message, chat):
    while True:
        if os.path.exists(statusfile):
            break

        await asyncio.sleep(3)      
    while os.path.exists(statusfile):
        with open(statusfile, "r") as upread:
            txt = upread.read()
        try:
            await client.edit_message_text(chat, message.id, f"**Uploaded:** **{txt}**")
            await asyncio.sleep(10)
        except:
            await asyncio.sleep(5)


# progress writer
def progress(current, total, message, type):
    with open(f'{message.id}{type}status.txt', "w") as fileup:
        fileup.write(f"{current * 100 / total:.1f}%")

@Client.on_message(filters.command("setthumb") & filters.private)
async def set_thumb(client: Client, message: Message):
    await message.reply_text(
        "📸 **Send me the thumbnail image now**\n\n"
        "• JPG / PNG\n"
        "• Best size: 1280×720"
    )

@Client.on_message(filters.photo & filters.private)
async def save_thumb(client: Client, message: Message):
    user_id = message.from_user.id
    os.makedirs("thumbs", exist_ok=True)

    path = f"thumbs/{user_id}.jpg"
    await message.download(file_name=path)

    await message.reply_text("✅ **Thumbnail saved successfully!**\n\nNow it will be used for all videos.")



# start command
@Client.on_message(filters.command(["start"]))
async def send_start(client: Client, message: Message):
    if not await db.is_user_exist(message.from_user.id):
        await db.add_user(message.from_user.id, message.from_user.first_name)
    buttons = [[
        InlineKeyboardButton("❣️ Developer", url = "https://t.me/kingvj01")
    ],[
        InlineKeyboardButton('🔍 sᴜᴘᴘᴏʀᴛ ɢʀᴏᴜᴘ', url='https://t.me/vj_bot_disscussion'),
        InlineKeyboardButton('🤖 ᴜᴘᴅᴀᴛᴇ ᴄʜᴀɴɴᴇʟ', url='https://t.me/vj_bots')
    ]]
    reply_markup = InlineKeyboardMarkup(buttons)
    await client.send_message(
        chat_id=message.chat.id, 
        text=f"<b>👋 Hi {message.from_user.mention}, I am Save Restricted Content Bot, I can send you restricted content by its post link.\n\nFor downloading restricted content /login first.\n\nKnow how to use bot by - /help</b>", 
        reply_markup=reply_markup, 
        reply_to_message_id=message.id
    )
    return


# help command
@Client.on_message(filters.command(["help"]))
async def send_help(client: Client, message: Message):
    await client.send_message(
        chat_id=message.chat.id, 
        text=f"{HELP_TXT}"
    )

# cancel command
@Client.on_message(filters.command(["cancel"]))
async def send_cancel(client: Client, message: Message):
    batch_temp.IS_BATCH[message.from_user.id] = True
    await client.send_message(
        chat_id=message.chat.id, 
        text="**Batch Successfully Cancelled.**"
    )

@Client.on_message(filters.text & filters.private)
@Client.on_message(filters.text & filters.private)
async def save(client: Client, message: Message):
    # Joining chat
    if ("https://t.me/+" in message.text or "https://t.me/joinchat/" in message.text) and LOGIN_SYSTEM == False:
        if TechVJUser is None:
            await client.send_message(message.chat.id, "String Session is not Set", reply_to_message_id=message.id)
            return
        try:
            await TechVJUser.join_chat(message.text)
            await client.send_message(message.chat.id, "Chat Joined", reply_to_message_id=message.id)
        except UserAlreadyParticipant:
            await client.send_message(message.chat.id, "Chat already Joined", reply_to_message_id=message.id)
        except InviteHashExpired:
            await client.send_message(message.chat.id, "Invalid Link", reply_to_message_id=message.id)
        except Exception as e:
            await client.send_message(message.chat.id, f"Error : {e}", reply_to_message_id=message.id)
        return

    if "https://t.me/" in message.text:
        if batch_temp.IS_BATCH.get(message.from_user.id) == False:
            return await message.reply_text(
                "**One Task Is Already Processing. Wait For Complete It. If You Want To Cancel This Task Then Use - /cancel**"
            )

        datas = message.text.split("/")
        temp = datas[-1].replace("?single", "").split("-")
        fromID = int(temp[0].strip())
        try:
            toID = int(temp[1].strip())
        except:
            toID = fromID

        # login system
        if LOGIN_SYSTEM == True:
            user_data = await db.get_session(message.from_user.id)
            if user_data is None:
                await message.reply("**For Downloading Restricted Content You Have To /login First.**")
                return
            api_id = int(await db.get_api_id(message.from_user.id))
            api_hash = await db.get_api_hash(message.from_user.id)
            acc = Client("saverestricted", session_string=user_data, api_hash=api_hash, api_id=api_id)
            await acc.connect()
        else:
            if TechVJUser is None:
                await client.send_message(message.chat.id, "**String Session is not Set**", reply_to_message_id=message.id)
                return
            acc = TechVJUser

        batch_temp.IS_BATCH[message.from_user.id] = False

        for msgid in range(fromID, toID + 1):
            if batch_temp.IS_BATCH.get(message.from_user.id):
                break

            # private
            if "https://t.me/c/" in message.text:
                chatid = int("-100" + datas[4])
                await handle_private(client, acc, message, chatid, msgid)

            # bot
            elif "https://t.me/b/" in message.text:
                username = datas[4]
                await handle_private(client, acc, message, username, msgid)

            # ================= PUBLIC =================
            else:
                username = datas[3]

                try:
                    msg = await client.get_messages(username, msgid)
                except UsernameNotOccupied:
                    await client.send_message(
                        message.chat.id,
                        "The username is not occupied by anyone",
                        reply_to_message_id=message.id
                    )
                    return

                # -------- SEASON / EPISODE DETECT --------
                season = "01"
                episode = "01"
                text = ""

                if msg.caption:
                    text = msg.caption
                elif msg.document and msg.document.file_name:
                    text = msg.document.file_name
                elif msg.video and msg.video.file_name:
                    text = msg.video.file_name

                if text:
                    m1 = re.search(r"S(\d{1,2})[_\- ]*E(\d{1,3})", text, re.I)
                    m2 = re.search(r"_(\d{1,2})[_\- ](\d{1,3})", text)
                    m3s = re.search(r"Season\s*=?\s*(\d+)", text, re.I)
                    m3e = re.search(r"Episode\s*=?\s*(\d+)", text, re.I)

                    if m1:
                        season = m1.group(1).zfill(2)
                        episode = m1.group(2).zfill(2)
                    elif m2:
                        season = m2.group(1).zfill(2)
                        episode = m2.group(2).zfill(2)
                    else:
                        if m3s:
                            season = m3s.group(1).zfill(2)
                        if m3e:
                            episode = m3e.group(1).zfill(2)

                public_caption = f"""<b>
⚡ Season = {season}
📟 Episode = {episode}
🎧 Language = Hindi

━━━━━━━━━━━━━━━━━━
🔥 @Hindi_Animes_Series 🔥
</b>"""

                try:
                    await client.copy_message(
                        chat_id=int(CHANNEL_ID),   # 👈 DIRECT CHANNEL
                        from_chat_id=msg.chat.id,
                        message_id=msg.id,
                        caption=public_caption,
                        parse_mode=enums.ParseMode.HTML
                    )

                except:
                    await handle_private(client, acc, message, username, msgid)

            await asyncio.sleep(WAITING_TIME)

        if LOGIN_SYSTEM == True:
            try:
                await acc.disconnect()
            except:
                pass

        batch_temp.IS_BATCH[message.from_user.id] = True

@Client.on_message(filters.command("setchannel") & filters.private)
async def set_channel_cmd(client: Client, message: Message):
    if not message.reply_to_message:
        return await message.reply(
            "Reply to a **channel message** or send:\n\n`/setchannel -100xxxxxxxxx`"
        )

    channel_id = message.reply_to_message.forward_from_chat.id
    await db.set_channel(message.from_user.id, channel_id)

    await message.reply(f"✅ **Channel set successfully**\n\nID: `{channel_id}`")

@Client.on_message(filters.command("delchannel") & filters.private)
async def del_channel_cmd(client: Client, message: Message):
    await db.del_channel(message.from_user.id)
    await message.reply("❌ **Channel removed**\n\nNow bot will send in DM.")


# handle private
async def handle_private(client: Client, acc, message: Message, chatid: int, msgid: int):
    msg: Message = await acc.get_messages(chatid, msgid)
    if msg.empty:
        return

    msg_type = get_message_type(msg)
    if not msg_type:
        return

    # target chat
    if CHANNEL_ID:
        try:
            chat = int(CHANNEL_ID)
        except:
            chat = message.chat.id
    else:
        chat = message.chat.id

    if batch_temp.IS_BATCH.get(message.from_user.id):
        return

    # ---------------- TEXT ----------------
    if msg_type == "Text":
        await client.send_message(
            chat,
            msg.text,
            entities=msg.entities,
            reply_to_message_id=message.id,
            parse_mode=enums.ParseMode.HTML
        )
        return

    # ---------------- DOWNLOAD ----------------
    smsg = await client.send_message(
        message.chat.id,
        "**Downloading**",
        reply_to_message_id=message.id
    )

    asyncio.create_task(downstatus(client, f"{message.id}downstatus.txt", smsg, chat))

    try:
        file = await acc.download_media(
            msg,
            progress=progress,
            progress_args=[message, "down"]
        )
        if os.path.exists(f"{message.id}downstatus.txt"):
            os.remove(f"{message.id}downstatus.txt")
    except Exception as e:
        if ERROR_MESSAGE:
            await client.send_message(message.chat.id, f"Error: {e}")
        return await smsg.delete()

    asyncio.create_task(upstatus(client, f"{message.id}upstatus.txt", smsg, chat))

    # user thumbnail (if set)
    thumb_path = f"thumbs/{message.from_user.id}.jpg"
    if not os.path.exists(thumb_path):
        thumb_path = None

    # =========================================================
    # DOCUMENT (VIDEO AS DOCUMENT INCLUDED)
    # =========================================================
    if msg_type == "Document":

        is_video = False
        if msg.document.mime_type and msg.document.mime_type.startswith("video/"):
            is_video = True

        # ---------- DOCUMENT AS VIDEO ----------
        if is_video:
            video_caption = """<b>
⚡ Season = 01
📟 Episode = 01
🎧 Language = Hindi

━━━━━━━━━━━━━━━━━━
🔥 @Hindi_Animes_Series 🔥
</b>"""

            await client.send_video(
                chat,
                file,
                thumb=thumb_path,
                caption=video_caption,
                reply_to_message_id=message.id,
                parse_mode=enums.ParseMode.HTML,
                progress=progress,
                progress_args=[message, "up"]
            )

        # ---------- NORMAL DOCUMENT ----------
        else:
            await client.send_document(
                chat,
                file,
                caption=msg.caption,
                reply_to_message_id=message.id,
                parse_mode=enums.ParseMode.HTML,
                progress=progress,
                progress_args=[message, "up"]
            )

    # =========================================================
    # REAL TELEGRAM VIDEO
    # =========================================================
    elif msg_type == "Video":

        video_caption = """<b>
⚡ Season = 01
📟 Episode = 01
🎧 Language = Hindi

━━━━━━━━━━━━━━━━━━
🔥 @Hindi_Animes_Series 🔥
</b>"""

        await client.send_video(
            chat,
            file,
            duration=msg.video.duration,
            width=msg.video.width,
            height=msg.video.height,
            thumb=thumb_path,
            caption=video_caption,
            reply_to_message_id=message.id,
            parse_mode=enums.ParseMode.HTML,
            progress=progress,
            progress_args=[message, "up"]
        )

    # ---------------- OTHER TYPES ----------------
    elif msg_type == "Animation":
        await client.send_animation(chat, file, reply_to_message_id=message.id)

    elif msg_type == "Sticker":
        await client.send_sticker(chat, file, reply_to_message_id=message.id)

    elif msg_type == "Voice":
        await client.send_voice(
            chat,
            file,
            caption=msg.caption,
            reply_to_message_id=message.id,
            progress=progress,
            progress_args=[message, "up"]
        )

    elif msg_type == "Audio":
        await client.send_audio(
            chat,
            file,
            caption=msg.caption,
            reply_to_message_id=message.id,
            progress=progress,
            progress_args=[message, "up"]
        )

    elif msg_type == "Photo":
        await client.send_photo(
            chat,
            file,
            caption=msg.caption,
            reply_to_message_id=message.id
        )

    # ---------------- CLEANUP ----------------
    if os.path.exists(f"{message.id}upstatus.txt"):
        os.remove(f"{message.id}upstatus.txt")

    if os.path.exists(file):
        os.remove(file)

    await client.delete_messages(message.chat.id, [smsg.id])




# get the type of message
def get_message_type(msg: pyrogram.types.messages_and_media.message.Message):
    try:
        msg.document.file_id
        return "Document"
    except:
        pass

    try:
        msg.video.file_id
        return "Video"
    except:
        pass

    try:
        msg.animation.file_id
        return "Animation"
    except:
        pass

    try:
        msg.sticker.file_id
        return "Sticker"
    except:
        pass

    try:
        msg.voice.file_id
        return "Voice"
    except:
        pass

    try:
        msg.audio.file_id
        return "Audio"
    except:
        pass

    try:
        msg.photo.file_id
        return "Photo"
    except:
        pass

    try:
        msg.text
        return "Text"
    except:
        pass
        

# Don't Remove Credit @VJ_Bots
# Subscribe YouTube Channel For Amazing Bot @Tech_VJ
# Ask Doubt on telegram @KingVJ01
