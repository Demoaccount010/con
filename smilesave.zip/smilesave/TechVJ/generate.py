# Don't Remove Credit Tg - @VJ_Bots
# Subscribe YouTube Channel For Amazing Bot https://youtube.com/@Tech_VJ
# Ask Doubt on telegram @KingVJ01

import traceback
from pyrogram.types import Message
from pyrogram import Client, filters
from asyncio.exceptions import TimeoutError
from pyrogram.errors import (
    PhoneNumberInvalid,
    PhoneCodeInvalid,
    PhoneCodeExpired,
    SessionPasswordNeeded,
    PasswordHashInvalid
)
from config import API_ID, API_HASH
from database.db import db

SESSION_STRING_SIZE = 351


@Client.on_message(filters.private & filters.command("logout"))
async def logout(bot, message: Message):
    user = await db.get_session(message.from_user.id)
    if not user:
        return await message.reply("**You are not logged in.**")
    await db.set_session(message.from_user.id, session=None)
    await message.reply("**Logout Successfully ✅**")


@Client.on_message(filters.private & filters.command("login"))
async def login(bot: Client, message: Message):

    user_id = message.from_user.id

    # ✅ auto create user if not exist
    if not await db.is_user_exist(user_id):
        await db.add_user(user_id, message.from_user.first_name)

    # ✅ already logged in check
    if await db.get_session(user_id):
        return await message.reply(
            "**You are already logged in.\nUse /logout first.**"
        )

    await message.reply(
        "**How To Create Api Id And Api Hash**\n\n"
        "Video ▶ https://youtu.be/LDtgwpI-N7M"
    )

    api_id_msg = await bot.ask(
        user_id,
        "**Send your API ID**\n\n"
        "Send /skip to use default",
        filters=filters.text
    )

    if api_id_msg.text == "/skip":
        api_id = API_ID
        api_hash = API_HASH
    else:
        try:
            api_id = int(api_id_msg.text)
        except ValueError:
            return await api_id_msg.reply(
                "**API ID must be a number. Start again with /login**"
            )

        api_hash_msg = await bot.ask(
            user_id,
            "**Now send your API HASH**",
            filters=filters.text
        )
        api_hash = api_hash_msg.text.strip()

    phone_msg = await bot.ask(
        user_id,
        "**Send your phone number with country code**\n"
        "`+919xxxxxxxxx`",
        filters=filters.text
    )

    if phone_msg.text == "/cancel":
        return await phone_msg.reply("**Process cancelled ❌**")

    phone_number = phone_msg.text.strip()

    # ✅ MEMORY MODE CLIENT (NO SQLITE)
    client = Client(
        name="login_session",
        api_id=api_id,
        api_hash=api_hash,
        in_memory=True
    )

    try:
        await client.start()
        await phone_msg.reply("**Sending OTP...**")

        code = await client.send_code(phone_number)

        otp_msg = await bot.ask(
            user_id,
            "**Send OTP like this:** `1 2 3 4 5`\n\nSend /cancel to cancel",
            filters=filters.text,
            timeout=600
        )

        if otp_msg.text == "/cancel":
            await client.stop()
            return await otp_msg.reply("**Process cancelled ❌**")

        otp = otp_msg.text.replace(" ", "")
        await client.sign_in(phone_number, code.phone_code_hash, otp)

    except PhoneNumberInvalid:
        await client.stop()
        return await phone_msg.reply("**Invalid phone number**")

    except PhoneCodeInvalid:
        await client.stop()
        return await message.reply("**Invalid OTP**")

    except PhoneCodeExpired:
        await client.stop()
        return await message.reply("**OTP expired**")

    except SessionPasswordNeeded:
        pass_msg = await bot.ask(
            user_id,
            "**Two-step verification enabled.\nSend password**",
            filters=filters.text,
            timeout=300
        )
        try:
            await client.check_password(pass_msg.text)
        except PasswordHashInvalid:
            await client.stop()
            return await pass_msg.reply("**Wrong password**")

    except Exception as e:
        await client.stop()
        return await message.reply(f"**Login error:** `{e}`")

    # ✅ EXPORT STRING
    string_session = await client.export_session_string()
    await client.stop()

    if len(string_session) < SESSION_STRING_SIZE:
        return await message.reply("**Invalid session generated**")

    # ✅ SAVE TO MONGODB
    await db.set_session(user_id, string_session)
    await db.set_api_id(user_id, api_id)
    await db.set_api_hash(user_id, api_hash)

    await message.reply(
        "**Login Successful ✅**\n\n"
        "If AUTH error comes, do /logout then /login again"
    )


# Don't Remove Credit Tg - @VJ_Bots
# Subscribe YouTube Channel For Amazing Bot https://youtube.com/@Tech_VJ
# Ask Doubt on telegram @KingVJ01
