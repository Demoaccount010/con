# Don't Remove Credit Tg - @VJ_Bots
# Subscribe YouTube Channel For Amazing Bot https://youtube.com/@Tech_VJ
# Ask Doubt on telegram @KingVJ01

import os

# Login feature, if you want then True , if you don't want then False
LOGIN_SYSTEM = os.environ.get("LOGIN_SYSTEM", "True").lower() == "true"
 # True or False

if LOGIN_SYSTEM == False:
    # if login system is False then fill your tg account session below 
    STRING_SESSION = os.environ.get("STRING_SESSION", "BQIkymoAORzM4aPanjkYv_m7TA068iCpCLQ6hEIjeoT5M8X25w2fN9-qHdnix0C57rA6w0EEE7qwoTtq9-qYeZmqoXZtN8daHh-GJHk1BZqG7BzDLBNpeaUf0wFbVAgYWIvfcYzMmheo-yEn90bdPH8MmYm8MoNHQ5I4xq_TsQjV9r1yCIiblG8bFJATu6LVc2wb2ozx23xtrf6KLXhwKvEhHSAhr44yRdTbkE7RzWkQx9ZmKmKIfwA0H3TnhCioI1OfepzGwI2oGPVlQDPjx3c_xwlAXbXX8aFr0tYzQ7DQeHEz8LrzdDAVeYFm53Z-WCK8k3MfoXlt1b0okJdJjZzwFicQ9AAAAAGp4TT3AA")
else:
    STRING_SESSION = None

# Bot token @Botfather
BOT_TOKEN = os.environ.get("BOT_TOKEN", "8517105545:AAHhHpZBR6Icek_ScKOrjB4cJw2Zip25QtM")

# Your API ID from my.telegram.org
API_ID = int(os.environ.get("API_ID", "27829715"))

# Your API Hash from my.telegram.org
API_HASH = os.environ.get("API_HASH", "72e38250de2b0ae7dd9eb467ffa35c17")

# Your Owner / Admin Id For Broadcast 
ADMINS = int(os.environ.get("ADMINS", "2034253345"))

# Your Channel Id In Which Bot Upload Downloaded Video/File/Message etc.
# And Make Your Bot Admin In this channel with full rights.
# if you don't want to upload in channel then leave it blank don't fill anything.
CHANNEL_ID = os.environ.get("CHANNEL_ID", "-1003522602308")

# Your Mongodb Database Url
# Warning - Give Db uri in deploy server environment variable, don't give in repo.
DB_URI = os.environ.get("DB_URI", "mongodb+srv://smile:S5WLGbU6DQdWGMjJ@cluster0.d7v1xoh.mongodb.net/?appName=Cluster0") # Warning - Give Db uri in deploy server environment variable, don't give in repo.
DB_NAME = os.environ.get("DB_NAME", "vjsavecontentbot")

# Increase time as much as possible to avoid floodwait, spamming and tg account ban issues.
WAITING_TIME = int(os.environ.get("WAITING_TIME", "10")) # time in seconds

# If You Want Error Message In Your Personal Message Then Turn It True Else If You Don't Want Then Flase
ERROR_MESSAGE = bool(os.environ.get('ERROR_MESSAGE', True))
