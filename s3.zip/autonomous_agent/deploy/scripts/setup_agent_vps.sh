#!/bin/bash
# Complete VPS Setup Script - Single VPS (Ollama + Agent on SAME VPS)
# Run this on your VPS to setup everything

set -e

echo "========================================="
echo "  🚀 Complete VPS Setup (One-Click)"
echo "  Ollama + Agent on Same VPS"
echo "========================================="
echo ""

# Configuration
INSTALL_DIR="/opt/autonomous_agent"
OLLAMA_MODEL="llama3"

# Detect if script is already in the agent directory
if [ -f "requirements.txt" ]; then
    INSTALL_DIR=$(pwd)
    echo "📁 Using current directory: $INSTALL_DIR"
else
    echo "📁 Install directory: $INSTALL_DIR"
fi

echo ""
echo "Step 1: System Update & Basic Tools"
echo "-----------------------------------"
sudo apt update
sudo apt install -y python3 python3-pip git curl
echo "✅ System updated"

echo ""
echo "Step 2: Installing Ollama"
echo "-----------------------------------"
if command -v ollama &> /dev/null; then
    echo "✅ Ollama already installed"
else
    echo "📥 Installing Ollama..."
    curl -fsSL https://ollama.ai/install.sh | sh
    echo "✅ Ollama installed"
fi

echo ""
echo "Step 3: Downloading Ollama Model"
echo "-----------------------------------"
read -p "Which model? [llama3/mistral/phi]: " MODEL_INPUT
OLLAMA_MODEL=${MODEL_INPUT:-llama3}

echo "📥 Downloading $OLLAMA_MODEL (this may take a few minutes)..."
ollama pull $OLLAMA_MODEL
echo "✅ Model downloaded"

echo ""
echo "Step 4: Installing Agent Dependencies"
echo "-----------------------------------"
if [ ! -f "$INSTALL_DIR/requirements.txt" ]; then
    echo "⚠️  requirements.txt not found!"
    echo "Please copy agent code to: $INSTALL_DIR"
    exit 1
fi

cd $INSTALL_DIR
pip3 install -r requirements.txt
echo "✅ Dependencies installed"

echo ""
echo "Step 5: Configuration"
echo "-----------------------------------"
# Create .env file
cat > $INSTALL_DIR/.env <<EOF
# Ollama on same VPS (localhost)
OLLAMA_URL=http://localhost:11434
OLLAMA_MODEL=$OLLAMA_MODEL
ENABLE_OLLAMA=true
OLLAMA_TIMEOUT=60

# Disable heavy features for VPS
ENABLE_VECTOR_SEARCH=false
ENABLE_GITHUB_LEARNING=false
ENABLE_BROWSER_CONTROL=false

# Enable basic features
ENABLE_FILE_OPERATIONS=true
ENABLE_PROCESS_CONTROL=true
ENABLE_SYSTEM_COMMANDS=false
EOF

echo "✅ Configuration saved to .env"

echo ""
echo "Step 6: Testing Connection"
echo "-----------------------------------"
cd $INSTALL_DIR
echo "Testing Ollama connection..."
python3 test_remote_ollama.py

echo ""
echo "========================================="
echo "  ✅ Setup Complete!"
echo "========================================="
echo ""
echo "📊 System Info:"
echo "   - Ollama: Running on localhost:11434"
echo "   - Model: $OLLAMA_MODEL"
echo "   - Agent: $INSTALL_DIR"
echo ""
echo "🚀 To start agent:"
echo "   cd $INSTALL_DIR"
echo "   python3 main.py"
echo ""
echo "📝 To auto-start on boot:"
echo "   sudo systemctl enable autonomous-agent"
echo ""
echo "💡 Check RAM usage: free -h"
echo "💡 Monitor logs: tail -f logs/agent.log"
echo ""
