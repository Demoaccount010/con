"""
Advanced Usage Examples for Autonomous Agent
"""
import sys
from pathlib import Path
import time

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from agent import AutonomousAgent
from core.permission_manager import PermissionLevel

def example_advanced_1_custom_skills():
    """Example: Creating and managing custom skills"""
    print("\n" + "="*60)
    print("ADVANCED EXAMPLE 1: Custom Skill Management")
    print("="*60 + "\n")
    
    agent = AutonomousAgent(name="AdvancedAgent")
    
    # Create multiple related skills
    skills = [
        ("Calculate factorial of a number", "factorial"),
        ("Check if a number is prime", "is_prime"),
        ("Generate fibonacci sequence", "fibonacci"),
    ]
    
    print("Creating mathematical skills...\n")
    for description, name in skills:
        skill_info = agent.skill_generator.generate_from_description(
            description, 
            function_name=name
        )
        
        if skill_info:
            func = agent.skill_generator.compile_skill(skill_info)
            if func:
                agent.skill_registry.register_skill(
                    name=skill_info['name'],
                    description=skill_info['description'],
                    code=skill_info['code'],
                    category="mathematics"
                )
                print(f"✓ Created: {name}")
    
    # List skills by category
    math_skills = agent.skill_registry.list_skills(category="mathematics")
    print(f"\n📊 Total mathematical skills: {len(math_skills)}")
    for skill in math_skills:
        print(f"  - {skill['name']}")

def example_advanced_2_memory_consolidation():
    """Example: Memory consolidation and retrieval"""
    print("\n" + "="*60)
    print("ADVANCED EXAMPLE 2: Memory Consolidation")
    print("="*60 + "\n")
    
    agent = AutonomousAgent(name="AdvancedAgent")
    
    # Store various memories
    print("Storing information in short-term memory...\n")
    
    memories = [
        "Python 3.11 was released in October 2022",
        "Machine learning is a subset of artificial intelligence",
        "REST APIs use HTTP methods like GET, POST, PUT, DELETE",
        "SQLite is a serverless, self-contained database",
        "Git is a distributed version control system"
    ]
    
    for memory in memories:
        agent.memory.store_short_term(memory, memory_type="knowledge")
        # Access it multiple times to increase importance
        for _ in range(3):
            agent.memory.recall_short_term(limit=1)
    
    print("✓ Stored 5 memories with multiple accesses\n")
    
    # Consolidate memories
    print("Consolidating memories...")
    promoted = agent.memory.consolidate_memories()
    print(f"✓ Promoted {promoted} memories to long-term storage\n")
    
    # Retrieve from long-term memory
    print("Retrieving from long-term memory...")
    lt_memories = agent.memory.recall_long_term(min_importance=0.3, limit=5)
    print(f"✓ Found {len(lt_memories)} long-term memories")
    
    for mem in lt_memories:
        print(f"  - {mem['content'][:60]}... (importance: {mem['importance']:.2f})")

def example_advanced_3_learning_patterns():
    """Example: Learning from patterns and feedback"""
    print("\n" + "="*60)
    print("ADVANCED EXAMPLE 3: Learning Patterns")
    print("="*60 + "\n")
    
    agent = AutonomousAgent(name="AdvancedAgent")
    
    # Simulate multiple interactions with feedback
    interactions = [
        ("create", "create a function", True, 1.0),
        ("create", "make a new skill", True, 0.9),
        ("read", "show me the data", True, 1.0),
        ("read", "list all items", True, 0.95),
        ("update", "modify the file", False, 0.3),
        ("update", "change the value", False, 0.4),
    ]
    
    print("Recording feedback from interactions...\n")
    for intent, action, success, score in interactions:
        agent.learning_engine.record_feedback(
            intent=intent,
            action=action,
            outcome="success" if success else "failure",
            feedback_score=score
        )
    
    print("✓ Recorded 6 interactions\n")
    
    # Analyze performance by intent
    print("Performance Analysis:\n")
    for intent in ["create", "read", "update"]:
        analysis = agent.learning_engine.analyze_performance(intent=intent)
        print(f"{intent.upper()}:")
        print(f"  Total actions: {analysis['total_actions']}")
        print(f"  Success rate: {analysis['success_rate']:.1%}")
        print(f"  Needs improvement: {analysis['needs_improvement']}\n")
    
    # Identify improvement areas
    improvements = agent.learning_engine.identify_improvement_areas()
    if improvements:
        print("Areas needing improvement:")
        for imp in improvements:
            print(f"  - {imp['intent']}: {imp['success_rate']:.1%} success rate ({imp['priority']} priority)")

def example_advanced_4_permission_management():
    """Example: Permission rules and trusted operations"""
    print("\n" + "="*60)
    print("ADVANCED EXAMPLE 4: Permission Management")
    print("="*60 + "\n")
    
    agent = AutonomousAgent(name="AdvancedAgent")
    
    # Add permission rules
    print("Setting up permission rules...\n")
    
    agent.permission_manager.add_permission_rule(
        rule_type="file",
        pattern="read",
        permission_level=PermissionLevel.SAFE,
        auto_approve=True
    )
    
    agent.permission_manager.add_permission_rule(
        rule_type="file",
        pattern="write",
        permission_level=PermissionLevel.MEDIUM_RISK,
        auto_approve=False
    )
    
    print("✓ Added permission rules\n")
    
    # Mark operations as trusted
    agent.permission_manager.mark_as_trusted(
        "Read configuration file",
        trust_level=1.0
    )
    
    agent.permission_manager.mark_as_trusted(
        "List directory contents",
        trust_level=0.9
    )
    
    print("✓ Marked 2 operations as trusted\n")
    
    # Get permission statistics
    stats = agent.permission_manager.get_statistics()
    print("Permission Statistics:")
    print(f"  Total requests: {stats['total_requests']}")
    print(f"  Approved: {stats['approved']}")
    print(f"  Denied: {stats['denied']}")
    print(f"  Trusted operations: {stats['trusted_operations']}")

def example_advanced_5_self_updating():
    """Example: Self-updating capabilities"""
    print("\n" + "="*60)
    print("ADVANCED EXAMPLE 5: Self-Updating System")
    print("="*60 + "\n")
    
    agent = AutonomousAgent(name="AdvancedAgent")
    
    # Analyze agent code
    print("Analyzing agent code structure...\n")
    
    agent_file = Path(__file__).parent.parent / "agent.py"
    if agent_file.exists():
        structure = agent.self_updater.analyze_code(agent_file)
        
        print(f"File: {structure.get('filepath', 'N/A')}")
        print(f"Lines: {structure.get('lines', 0)}")
        print(f"Classes: {len(structure.get('classes', []))}")
        print(f"Functions: {len(structure.get('functions', []))}")
        print(f"Imports: {len(structure.get('imports', []))}\n")
        
        if structure.get('classes'):
            print("Classes found:")
            for cls in structure['classes'][:3]:
                print(f"  - {cls['name']} (line {cls['lineno']})")
                print(f"    Methods: {', '.join(cls['methods'][:5])}")
    
    # List backups
    print("\n" + "="*60)
    backups = agent.self_updater.list_backups()
    print(f"Available backups: {len(backups)}")

def example_advanced_6_comprehensive_workflow():
    """Example: Complete workflow demonstration"""
    print("\n" + "="*60)
    print("ADVANCED EXAMPLE 6: Comprehensive Workflow")
    print("="*60 + "\n")
    
    agent = AutonomousAgent(name="WorkflowAgent")
    
    # Step 1: Learn domain knowledge
    print("STEP 1: Learning Domain Knowledge")
    print("-" * 40)
    knowledge = [
        "REST APIs follow client-server architecture",
        "HTTP status codes: 2xx success, 4xx client error, 5xx server error",
        "JSON is the most common data format for APIs"
    ]
    
    for item in knowledge:
        agent.memory.store_long_term(item, importance=0.9, tags=["api", "knowledge"])
    print(f"✓ Stored {len(knowledge)} knowledge items\n")
    
    # Step 2: Create related skills
    print("STEP 2: Creating API-related Skills")
    print("-" * 40)
    skill_info = agent.skill_generator.generate_from_description(
        "Parse JSON response from API",
        function_name="parse_api_response"
    )
    if skill_info:
        agent.skill_generator.compile_skill(skill_info)
        agent.skill_registry.register_skill(
            name=skill_info['name'],
            description=skill_info['description'],
            code=skill_info['code'],
            category="api"
        )
        print(f"✓ Created skill: {skill_info['name']}\n")
    
    # Step 3: Simulate usage and learning
    print("STEP 3: Simulating Usage and Learning")
    print("-" * 40)
    for i in range(5):
        agent.learning_engine.record_feedback(
            intent="execute",
            action="parse_api_response",
            outcome="success",
            feedback_score=0.95
        )
    print("✓ Recorded 5 successful executions\n")
    
    # Step 4: Analyze and report
    print("STEP 4: Analysis and Reporting")
    print("-" * 40)
    
    stats = agent.get_statistics()
    print(f"Total conversations: {stats['conversation_length']}")
    print(f"Skills created: {stats['skills']['total_skills']}")
    print(f"Long-term memories: {stats['memory']['long_term_count']}")
    print(f"Overall success rate: {stats['learning']['overall_success_rate']:.1f}%")
    
    print("\n✓ Workflow completed successfully!")

def main():
    """Run all advanced examples"""
    print("\n" + "="*60)
    print("  AUTONOMOUS AGENT - ADVANCED EXAMPLES")
    print("="*60)
    
    try:
        example_advanced_1_custom_skills()
        example_advanced_2_memory_consolidation()
        example_advanced_3_learning_patterns()
        example_advanced_4_permission_management()
        example_advanced_5_self_updating()
        example_advanced_6_comprehensive_workflow()
        
        print("\n" + "="*60)
        print("  All advanced examples completed!")
        print("="*60 + "\n")
        
    except Exception as e:
        print(f"\n❌ Error running examples: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
