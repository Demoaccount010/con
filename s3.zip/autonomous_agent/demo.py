"""
Quick Demo of the Autonomous Agent
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from agent import AutonomousAgent

def main():
    print("\n" + "="*60)
    print("  AUTONOMOUS AI AGENT - QUICK DEMO")
    print("="*60 + "\n")
    
    # Create agent
    print("Creating agent...")
    agent = AutonomousAgent(name="DemoAgent")
    print(f"✓ Agent '{agent.name}' created successfully!\n")
    
    # Test 1: Help command
    print("TEST 1: Help Command")
    print("-" * 40)
    response = agent.process("help")
    print(f"User: help")
    print(f"Agent Response: {response['message'][:100]}...")
    print(f"Status: {'✓ Success' if response['success'] else '✗ Failed'}\n")
    
    # Test 2: Create a skill
    print("TEST 2: Create a Skill")
    print("-" * 40)
    response = agent.process("Create a skill to add two numbers")
    print(f"User: Create a skill to add two numbers")
    print(f"Agent Response: {response['message']}")
    print(f"Status: {'✓ Success' if response['success'] else '✗ Failed'}\n")
    
    # Test 3: List skills
    print("TEST 3: List Skills")
    print("-" * 40)
    response = agent.process("Show me your skills")
    print(f"User: Show me your skills")
    print(f"Agent Response: {response['message']}")
    if response.get('data'):
        print(f"Found {len(response['data'])} skills")
    print(f"Status: {'✓ Success' if response['success'] else '✗ Failed'}\n")
    
    # Test 4: Learn something
    print("TEST 4: Learn Information")
    print("-" * 40)
    response = agent.process("Learn that Python is awesome")
    print(f"User: Learn that Python is awesome")
    print(f"Agent Response: {response['message']}")
    print(f"Status: {'✓ Success' if response['success'] else '✗ Failed'}\n")
    
    # Test 5: Search memory
    print("TEST 5: Search Memory")
    print("-" * 40)
    response = agent.process("Search for Python")
    print(f"User: Search for Python")
    print(f"Agent Response: {response['message']}")
    print(f"Status: {'✓ Success' if response['success'] else '✗ Failed'}\n")
    
    # Show statistics
    print("="*60)
    print("AGENT STATISTICS")
    print("="*60)
    stats = agent.get_statistics()
    print(f"\nAgent Name: {stats['agent_name']}")
    print(f"Total Conversations: {stats['conversation_length']}")
    print(f"\nIntent Detector:")
    print(f"  Total Detections: {stats['intent_detector']['total_detections']}")
    print(f"  Average Confidence: {stats['intent_detector']['average_confidence']}")
    print(f"\nMemory System:")
    print(f"  Short-term: {stats['memory']['short_term_count']}")
    print(f"  Long-term: {stats['memory']['long_term_count']}")
    print(f"  Episodic: {stats['memory']['episodic_count']}")
    print(f"\nSkills:")
    print(f"  Total: {stats['skills']['total_skills']}")
    print(f"  Active: {stats['skills']['active_skills']}")
    print(f"\nLearning:")
    print(f"  Feedback Records: {stats['learning']['total_feedback_records']}")
    print(f"  Overall Success Rate: {stats['learning']['overall_success_rate']:.1f}%")
    
    print("\n" + "="*60)
    print("  DEMO COMPLETED SUCCESSFULLY!")
    print("="*60 + "\n")
    
    print("To run in interactive mode, use: python main.py")
    print("To run full tests, use: python test_agent.py")
    print("To see examples, check: examples/basic_usage.py")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
