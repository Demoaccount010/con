"""
Proactive Assistant - Anticipates user needs and suggests improvements
Monitors patterns, detects repetitive tasks, and offers automation suggestions
"""
import time
from typing import Dict, List, Optional
from collections import defaultdict, Counter
from datetime import datetime, timedelta

try:
    from ..utils import setup_logger, timestamp
    from ..config import (
        PATTERN_RECOGNITION_THRESHOLD,
        SYSTEM_HEALTH_CHECK_INTERVAL,
        PROACTIVE_CHECK_ENABLED
    )
except ImportError:
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from utils import setup_logger, timestamp
    from config import (
        PATTERN_RECOGNITION_THRESHOLD,
        SYSTEM_HEALTH_CHECK_INTERVAL,
        PROACTIVE_CHECK_ENABLED
    )

class ProactiveAssistant:
    """
    Proactively assists users by detecting patterns and suggesting improvements
    """
    
    def __init__(self, memory_system=None, learning_engine=None):
        """Initialize Proactive Assistant"""
        self.logger = setup_logger(self.__class__.__name__)
        self.memory = memory_system
        self.learning = learning_engine
        self.enabled = PROACTIVE_CHECK_ENABLED
        
        # Pattern tracking
        self.command_history = []
        self.pattern_cache = {}
        self.last_health_check = time.time()
        
        self.logger.info("Proactive Assistant initialized")
    
    def analyze_user_patterns(self) -> Dict:
        """
        Analyze user behavior patterns from history
        
        Returns:
            Dict with detected patterns and insights
        """
        if not self.memory:
            return {'success': False, 'error': 'Memory system not available'}
        
        try:
            # Get recent episodes from memory
            episodes = self.memory.recall_episodes(days_back=7, limit=100)
            
            if not episodes:
                return {
                    'success': True,
                    'patterns': [],
                    'message': 'Not enough data to analyze patterns'
                }
            
            # Analyze command frequency
            command_counter = Counter()
            time_patterns = defaultdict(list)
            intent_patterns = Counter()
            
            for episode in episodes:
                user_input = episode.get('user_input', '')
                intent = episode.get('intent', 'unknown')
                timestamp_str = episode.get('timestamp', '')
                
                # Count commands
                if user_input:
                    command_counter[user_input] += 1
                
                # Count intents
                intent_patterns[intent] += 1
                
                # Time-based patterns
                try:
                    dt = datetime.fromisoformat(timestamp_str)
                    hour = dt.hour
                    time_patterns[hour].append(intent)
                except:
                    pass
            
            # Detect repetitive commands
            repetitive = [
                {
                    'command': cmd,
                    'count': count,
                    'suggested_automation': count >= PATTERN_RECOGNITION_THRESHOLD
                }
                for cmd, count in command_counter.most_common(10)
                if count >= 2
            ]
            
            # Find peak activity hours
            peak_hours = sorted(
                [(hour, len(intents)) for hour, intents in time_patterns.items()],
                key=lambda x: x[1],
                reverse=True
            )[:3]
            
            return {
                'success': True,
                'patterns': {
                    'repetitive_commands': repetitive,
                    'most_common_intents': dict(intent_patterns.most_common(5)),
                    'peak_activity_hours': peak_hours,
                    'total_interactions': len(episodes)
                },
                'insights': self._generate_insights(repetitive, intent_patterns, peak_hours)
            }
        
        except Exception as e:
            self.logger.error(f"Error analyzing patterns: {e}")
            return {'success': False, 'error': str(e)}
    
    def predict_next_need(self, current_time: str = None, context: Dict = None) -> Dict:
        """
        Predict user's next need based on time and context
        
        Args:
            current_time: Current timestamp
            context: Current context information
        
        Returns:
            Dict with prediction
        """
        try:
            if not current_time:
                current_time = datetime.now().isoformat()
            
            dt = datetime.fromisoformat(current_time)
            hour = dt.hour
            
            # Get historical data for this time
            if self.memory:
                episodes = self.memory.recall_episodes(days_back=30, limit=200)
                
                # Filter by similar time
                similar_time_episodes = [
                    ep for ep in episodes
                    if abs(datetime.fromisoformat(ep.get('timestamp', current_time)).hour - hour) <= 1
                ]
                
                if similar_time_episodes:
                    # Find most common intent at this time
                    intents = [ep.get('intent') for ep in similar_time_episodes]
                    most_common = Counter(intents).most_common(1)[0]
                    
                    return {
                        'success': True,
                        'predicted_need': most_common[0],
                        'confidence': most_common[1] / len(similar_time_episodes),
                        'based_on': f'{len(similar_time_episodes)} similar interactions',
                        'suggestion': self._generate_suggestion(most_common[0])
                    }
            
            return {
                'success': True,
                'predicted_need': 'unknown',
                'confidence': 0.0,
                'message': 'Not enough historical data'
            }
        
        except Exception as e:
            self.logger.error(f"Error predicting need: {e}")
            return {'success': False, 'error': str(e)}
    
    def suggest_automation(self, task_history: List[Dict]) -> Dict:
        """
        Suggest automation for repetitive tasks
        
        Args:
            task_history: List of task records
        
        Returns:
            Dict with automation suggestions
        """
        try:
            if not task_history:
                return {
                    'success': True,
                    'suggestions': [],
                    'message': 'No task history provided'
                }
            
            # Analyze task patterns
            task_counter = Counter()
            task_sequences = []
            
            for i, task in enumerate(task_history):
                task_type = task.get('type', 'unknown')
                task_counter[task_type] += 1
                
                # Detect sequences
                if i < len(task_history) - 1:
                    next_task = task_history[i + 1].get('type', 'unknown')
                    task_sequences.append((task_type, next_task))
            
            # Find frequent sequences
            sequence_counter = Counter(task_sequences)
            
            suggestions = []
            
            # Suggest automation for frequent tasks
            for task_type, count in task_counter.most_common(5):
                if count >= PATTERN_RECOGNITION_THRESHOLD:
                    suggestions.append({
                        'type': 'frequent_task',
                        'task': task_type,
                        'frequency': count,
                        'suggestion': f'Create a shortcut for "{task_type}" (used {count} times)',
                        'priority': 'high' if count >= 5 else 'medium'
                    })
            
            # Suggest automation for sequences
            for (task1, task2), count in sequence_counter.most_common(3):
                if count >= 2:
                    suggestions.append({
                        'type': 'task_sequence',
                        'sequence': [task1, task2],
                        'frequency': count,
                        'suggestion': f'Automate sequence: {task1} → {task2}',
                        'priority': 'medium'
                    })
            
            return {
                'success': True,
                'suggestions': suggestions,
                'total_tasks_analyzed': len(task_history)
            }
        
        except Exception as e:
            self.logger.error(f"Error suggesting automation: {e}")
            return {'success': False, 'error': str(e)}
    
    def check_system_health(self) -> Dict:
        """
        Check system health and suggest maintenance
        
        Returns:
            Dict with health status and suggestions
        """
        try:
            import psutil
            
            # Get system metrics
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            
            health_status = {
                'cpu': {
                    'usage_percent': cpu_percent,
                    'status': 'good' if cpu_percent < 70 else 'warning' if cpu_percent < 90 else 'critical'
                },
                'memory': {
                    'usage_percent': memory.percent,
                    'available_gb': memory.available / (1024**3),
                    'status': 'good' if memory.percent < 70 else 'warning' if memory.percent < 90 else 'critical'
                },
                'disk': {
                    'usage_percent': disk.percent,
                    'free_gb': disk.free / (1024**3),
                    'status': 'good' if disk.percent < 70 else 'warning' if disk.percent < 90 else 'critical'
                }
            }
            
            # Generate maintenance suggestions
            suggestions = []
            
            if memory.percent > 80:
                suggestions.append({
                    'type': 'memory',
                    'priority': 'high',
                    'message': 'Memory usage is high. Consider closing unused applications.',
                    'action': 'cleanup_memory'
                })
            
            if disk.percent > 85:
                suggestions.append({
                    'type': 'disk',
                    'priority': 'high',
                    'message': f'Disk space is low ({disk.free / (1024**3):.1f} GB free). Clean up old files.',
                    'action': 'cleanup_disk'
                })
            
            if cpu_percent > 85:
                suggestions.append({
                    'type': 'cpu',
                    'priority': 'medium',
                    'message': 'CPU usage is high. Check for resource-intensive processes.',
                    'action': 'check_processes'
                })
            
            self.last_health_check = time.time()
            
            return {
                'success': True,
                'health_status': health_status,
                'maintenance_suggestions': suggestions,
                'overall_status': self._calculate_overall_status(health_status)
            }
        
        except Exception as e:
            self.logger.error(f"Error checking system health: {e}")
            return {'success': False, 'error': str(e)}
    
    def detect_repetitive_tasks(self, history: List[Dict], threshold: int = 3) -> List[Dict]:
        """
        Detect repetitive tasks that could be automated
        
        Args:
            history: Task history
            threshold: Minimum occurrences to consider repetitive
        
        Returns:
            List of detected repetitive tasks
        """
        try:
            task_patterns = defaultdict(list)
            
            for task in history:
                task_key = task.get('type', 'unknown')
                task_patterns[task_key].append(task)
            
            repetitive_tasks = []
            
            for task_type, occurrences in task_patterns.items():
                if len(occurrences) >= threshold:
                    # Calculate average time between occurrences
                    times = [t.get('timestamp') for t in occurrences if t.get('timestamp')]
                    
                    avg_interval = None
                    if len(times) >= 2:
                        try:
                            timestamps = [datetime.fromisoformat(t) for t in times]
                            timestamps.sort()
                            intervals = [(timestamps[i+1] - timestamps[i]).total_seconds() 
                                       for i in range(len(timestamps)-1)]
                            avg_interval = sum(intervals) / len(intervals)
                        except:
                            pass
                    
                    repetitive_tasks.append({
                        'task_type': task_type,
                        'occurrence_count': len(occurrences),
                        'average_interval_seconds': avg_interval,
                        'recommendation': self._generate_automation_recommendation(
                            task_type, len(occurrences), avg_interval
                        )
                    })
            
            return repetitive_tasks
        
        except Exception as e:
            self.logger.error(f"Error detecting repetitive tasks: {e}")
            return []
    
    def _generate_insights(self, repetitive, intent_patterns, peak_hours) -> List[str]:
        """Generate human-readable insights"""
        insights = []
        
        if repetitive:
            most_repeated = repetitive[0]
            insights.append(
                f"You frequently use '{most_repeated['command']}' "
                f"({most_repeated['count']} times). Consider creating a shortcut!"
            )
        
        if intent_patterns:
            top_intent = intent_patterns.most_common(1)[0]
            insights.append(f"Your most common activity is '{top_intent[0]}' operations.")
        
        if peak_hours:
            peak_hour = peak_hours[0][0]
            insights.append(f"You're most active around {peak_hour}:00.")
        
        return insights
    
    def _generate_suggestion(self, intent: str) -> str:
        """Generate suggestion based on intent"""
        suggestions = {
            'create': 'Ready to create something?',
            'read': 'Looking for information?',
            'search': 'Need to search for something?',
            'execute': 'Ready to run a task?',
            'learn': 'Want to teach me something new?'
        }
        return suggestions.get(intent, f'Need help with {intent}?')
    
    def _calculate_overall_status(self, health_status: Dict) -> str:
        """Calculate overall system status"""
        statuses = [
            health_status['cpu']['status'],
            health_status['memory']['status'],
            health_status['disk']['status']
        ]
        
        if 'critical' in statuses:
            return 'critical'
        elif 'warning' in statuses:
            return 'warning'
        else:
            return 'good'
    
    def _generate_automation_recommendation(self, task_type: str, count: int, 
                                          avg_interval: Optional[float]) -> str:
        """Generate automation recommendation for a task"""
        if avg_interval and avg_interval < 3600:  # Less than 1 hour
            return f"Task '{task_type}' occurs frequently ({count} times). Consider creating an automated script."
        elif count >= 5:
            return f"Task '{task_type}' is very common. Create a keyboard shortcut or alias."
        else:
            return f"Task '{task_type}' is moderately repetitive. Monitor for automation potential."
    
    def should_check_health(self) -> bool:
        """Check if it's time for a health check"""
        return (time.time() - self.last_health_check) >= SYSTEM_HEALTH_CHECK_INTERVAL
