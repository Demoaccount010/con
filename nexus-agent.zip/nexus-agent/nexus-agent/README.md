# 🧠 NEXUS - Self-Evolving Autonomous AI Agent

A fully autonomous AI agent system with real system execution capabilities, self-evolution, and persistent memory.

## ⚡ Features

### Core Capabilities
- **Real System Execution** - Execute actual bash commands and system operations
- **Self-Evolution Engine** - Automatically creates new plugins when missing capabilities
- **Persistent Memory** - Remembers owner, learning history, and created tools
- **Reality Verification** - Never claims actions without verifying success
- **Owner Permission System** - Requests approval before executing system actions
- **Plugin System** - Dynamically loadable tools that can be auto-generated

### Intelligence Layers
1. **Meta Brain** - High-level decision making and task orchestration
2. **Thinking Engine** - AI-powered analysis via Cloudflare Worker API
3. **Execution Engine** - Real system command execution
4. **Verification Layer** - Post-execution reality checks
5. **Evolution Engine** - Self-improvement and capability expansion
6. **Memory System** - Persistent storage and learning

## 🚀 Installation

### Prerequisites
- Node.js 18+ (for ES modules support)
- VPS or local machine with bash access
- Cloudflare AI Worker API key

### Setup

1. **Clone or download the project:**
```bash
cd nexus-agent
```

2. **Install dependencies:**
```bash
npm install
```

3. **Configure API key:**

Set your Cloudflare AI Worker API key as an environment variable:

```bash
export AI_API_KEY="your-api-key-here"
```

Or create a `.env` file:
```
AI_API_KEY=your-api-key-here
```

4. **Run NEXUS:**
```bash
npm start
```

## 📖 Usage

### First Run

On first startup, NEXUS will ask you to set up your owner profile:
- Your name
- How you'd like to be addressed
- Any preferences

This creates a permanent relationship between you and the agent.

### Main Menu

NEXUS provides several operation modes:

1. **💬 Conversation Mode** - Natural language interaction
2. **🎯 Task Processing** - Analyze, plan, and execute specific tasks
3. **⚡ Quick Execution** - Direct command execution with approval
4. **📊 System Status** - View current state and capabilities
5. **🔧 Capabilities** - List all available tools and plugins
6. **📚 Evolution History** - See how NEXUS has evolved

### Example Tasks

```
> Make me a directory called "projects"
> Install Python package requests
> Create a simple web scraper
> Start a Node.js server on port 3000
> Clone a GitHub repository
> Find all JavaScript files in current directory
```

## 🧬 Self-Evolution

NEXUS can detect when it lacks a capability and create new plugins automatically:

1. **Task Analysis** - Identifies required capabilities
2. **Gap Detection** - Finds missing tools
3. **Plugin Design** - AI designs the new plugin
4. **Auto-Creation** - Generates and loads the plugin
5. **Task Retry** - Executes original task with new capability

### Plugin Structure

Plugins are stored in `/plugins` and follow this format:

```javascript
export default {
  name: 'plugin-name',
  description: 'What this plugin does',
  version: '1.0.0',

  async init() {
    // Initialize plugin
  },

  async someMethod(params) {
    // Plugin functionality
    return { success: true, result: '...' };
  }
};
```

## 🔒 Safety Features

### Permission System
- **Mandatory Approval** - All system actions require owner confirmation
- **Command Whitelist** - Dangerous commands are blocked
- **Length Limits** - Commands cannot exceed safety limits

### Verification System
- File creation verification
- Command execution verification
- Process status verification
- Package installation verification
- Plugin loading verification

### Blacklisted Commands
```javascript
[
  'rm -rf /',
  'dd if=/dev/zero',
  'chmod -R 777 /',
  'mkfs',
  ':(){ :|:& };:' // fork bomb
]
```

## 📁 Project Structure

```
nexus-agent/
├── core/
│   ├── brain.js           # Meta-brain & orchestration
│   ├── thinking.js        # AI API integration
│   ├── executor.js        # System execution
│   ├── verifier.js        # Reality verification
│   ├── evolution.js       # Self-evolution engine
│   ├── plugin_loader.js   # Dynamic plugin system
│   └── memory.js          # Persistent memory
├── plugins/               # Auto-generated plugins
├── memory/                # Persistent storage
│   ├── owner.json        # Owner profile
│   ├── learning.json     # Learning history
│   ├── tools.json        # Tool registry
│   └── logs/             # Execution logs
├── config/
│   └── config.js         # System configuration
├── utils/
│   └── logger.js         # Logging system
├── index.js              # Main entry
├── package.json
└── README.md
```

## 🔧 Configuration

Edit `config/config.js` to customize:

```javascript
{
  AI_API_URL: 'https://smile-ai.animeplaysindia07.workers.dev/',
  REQUIRE_APPROVAL: true,        // Require owner approval
  AUTO_SAVE_MEMORY: true,        // Auto-save learning
  LOG_LEVEL: 'info',             // debug | info | warn | error
  AUTO_CREATE_PLUGINS: true,     // Auto-create missing plugins
  MAX_RETRIES: 3,
  MAX_COMMAND_LENGTH: 1000
}
```

## 🧠 AI Integration

NEXUS uses a custom Cloudflare Worker API for AI thinking:

**API Endpoint:**
```
POST https://smile-ai.animeplaysindia07.workers.dev/
```

**Headers:**
```
Authorization: Bearer <API_KEY>
Content-Type: application/json
```

**Request:**
```json
{
  "prompt": "Analyze this task...",
  "systemPrompt": "You are NEXUS...",
  "history": [
    { "role": "user", "content": "..." },
    { "role": "assistant", "content": "..." }
  ]
}
```

**Response:**
```json
{
  "response": "AI response text"
}
```

## 📊 Memory System

NEXUS maintains several memory stores:

### Owner Profile (`owner.json`)
```json
{
  "name": "John",
  "relationship": "partner",
  "preferences": "Detailed explanations",
  "createdAt": "2024-01-15T10:30:00Z",
  "lastSeen": "2024-01-15T15:45:00Z"
}
```

### Learning History (`learning.json`)
```json
[
  {
    "action": "install package",
    "result": "success",
    "lesson": "Always verify package installation",
    "timestamp": "2024-01-15T10:35:00Z"
  }
]
```

### Tools Registry (`tools.json`)
```json
[
  {
    "name": "web-scraper",
    "description": "Scrapes web content",
    "filename": "web-scraper.js",
    "methods": ["scrape", "parse"],
    "createdAt": "2024-01-15T11:00:00Z"
  }
]
```

## 🎯 Workflow Example

1. **User:** "Create a Python script to analyze CSV files"

2. **Meta Brain:**
   - Analyzes task
   - Checks for CSV analysis capability
   - Detects missing capability

3. **Evolution Engine:**
   - Designs "csv-analyzer" plugin
   - Generates Python script template
   - Creates plugin file
   - Loads plugin

4. **Execution:**
   - Requests owner approval
   - Executes file creation
   - Verifies file exists
   - Reports success

5. **Learning:**
   - Records successful plugin creation
   - Stores in memory
   - Available for future tasks

## 🚨 Troubleshooting

### API Key Issues
```bash
# Check if API key is set
echo $AI_API_KEY

# Set it if missing
export AI_API_KEY="your-key"
```

### Permission Errors
```bash
# Make sure index.js is executable
chmod +x index.js
```

### Module Not Found
```bash
# Reinstall dependencies
rm -rf node_modules package-lock.json
npm install
```

### Plugin Creation Fails
- Check `plugins/` directory permissions
- Verify AI API is responding
- Review logs in `memory/logs/`

## 📈 Advanced Usage

### Creating Manual Plugins

You can manually create plugins in the `plugins/` directory:

```bash
# Create new plugin
cat > plugins/my-plugin.js << 'EOF'
import logger from '../utils/logger.js';

export default {
  name: 'my-plugin',
  description: 'Custom functionality',
  version: '1.0.0',

  async myFunction(param) {
    logger.info('Executing custom function');
    return { success: true, data: param };
  }
};
EOF
```

### Batch Command Execution

```javascript
// In quick execution mode
npm start && enter: ls -la && pwd && whoami
```

### Custom System Prompts

Edit `core/thinking.js` to customize how NEXUS thinks:

```javascript
buildSystemPrompt(customPrompt = null) {
  // Add your custom instructions here
}
```

## 🔄 Development

### Adding New Core Features

1. Create module in `core/`
2. Import in `index.js`
3. Initialize in `brain.js`
4. Update README

### Debugging

Enable debug logging:

```javascript
// config/config.js
LOG_LEVEL: 'debug'
```

View detailed logs:
```bash
tail -f memory/logs/$(date +%Y-%m-%d).log
```

## 🤝 Contributing

This is a personal autonomous agent system. Feel free to fork and customize for your needs.

## 📜 License

MIT License - See LICENSE file for details

## ⚠️ Disclaimer

This agent has real system execution capabilities. Always:
- Review execution plans before approval
- Use in isolated/test environments first
- Keep backups of important data
- Monitor system resources
- Never share your API keys

## 🎉 Credits

Built with:
- Node.js
- Axios
- Inquirer
- Chalk
- Custom Cloudflare AI Worker

---

**NEXUS** - Your autonomous AI partner for VPS automation and self-evolving capabilities.

For questions or issues, check the logs in `memory/logs/` for detailed execution traces.
