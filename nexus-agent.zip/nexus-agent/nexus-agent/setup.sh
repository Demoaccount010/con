#!/bin/bash

# NEXUS Installation Script
# Automated setup for the NEXUS autonomous agent system

set -e

echo "======================================"
echo "  NEXUS Installation & Setup"
echo "======================================"
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check Node.js version
echo "Checking Node.js version..."
if ! command -v node &> /dev/null; then
    echo -e "${RED}Error: Node.js is not installed${NC}"
    echo "Please install Node.js 18+ from https://nodejs.org/"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo -e "${RED}Error: Node.js version 18 or higher is required${NC}"
    echo "Current version: $(node -v)"
    exit 1
fi

echo -e "${GREEN}✓ Node.js version: $(node -v)${NC}"

# Check npm
echo "Checking npm..."
if ! command -v npm &> /dev/null; then
    echo -e "${RED}Error: npm is not installed${NC}"
    exit 1
fi
echo -e "${GREEN}✓ npm version: $(npm -v)${NC}"

# Install dependencies
echo ""
echo "Installing dependencies..."
npm install

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Dependencies installed successfully${NC}"
else
    echo -e "${RED}✗ Failed to install dependencies${NC}"
    exit 1
fi

# Create necessary directories
echo ""
echo "Creating directories..."
mkdir -p memory/logs
mkdir -p plugins

echo -e "${GREEN}✓ Directories created${NC}"

# Setup .env file
echo ""
if [ ! -f .env ]; then
    echo "Setting up environment variables..."
    cp .env.example .env
    echo -e "${YELLOW}⚠ Please edit .env file and add your AI_API_KEY${NC}"
    echo ""
    echo "Example:"
    echo "  AI_API_KEY=your-cloudflare-worker-api-key"
    echo ""
else
    echo -e "${GREEN}✓ .env file already exists${NC}"
fi

# Make index.js executable
chmod +x index.js

echo ""
echo "======================================"
echo -e "${GREEN}Installation Complete!${NC}"
echo "======================================"
echo ""
echo "Next steps:"
echo ""
echo "1. Edit .env and add your AI_API_KEY:"
echo "   nano .env"
echo ""
echo "2. Start NEXUS:"
echo "   npm start"
echo ""
echo "Or use:"
echo "   node index.js"
echo ""
echo "======================================"
echo ""

# Optional: Ask if user wants to start now
read -p "Would you like to set your API key now? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo ""
    read -p "Enter your Cloudflare AI Worker API key: " api_key
    if [ ! -z "$api_key" ]; then
        echo "AI_API_KEY=$api_key" > .env
        echo -e "${GREEN}✓ API key saved to .env${NC}"
        echo ""
        read -p "Start NEXUS now? (y/n) " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            npm start
        fi
    fi
fi
