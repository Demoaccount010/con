/**
 * Example Plugin: System Monitor
 * 
 * This is an example plugin to demonstrate how NEXUS plugins work.
 * You can use this as a template for creating your own plugins.
 * 
 * To activate: Copy this file to the plugins/ directory
 */

import logger from '../utils/logger.js';
import executor from '../core/executor.js';

export default {
  name: 'system-monitor',
  description: 'Monitor system resources and performance',
  version: '1.0.0',
  author: 'NEXUS',

  /**
   * Initialize the plugin (called when loaded)
   */
  async init() {
    logger.info('System Monitor plugin initialized');
  },

  /**
   * Get CPU usage information
   */
  async getCpuInfo() {
    try {
      const result = await executor.executeCommand('top -bn1 | grep "Cpu(s)"');
      
      if (result.success) {
        return {
          success: true,
          data: result.stdout.trim(),
          timestamp: new Date().toISOString()
        };
      }

      return {
        success: false,
        error: 'Failed to get CPU info'
      };

    } catch (error) {
      logger.error('getCpuInfo failed', error);
      return {
        success: false,
        error: error.message
      };
    }
  },

  /**
   * Get memory usage information
   */
  async getMemoryInfo() {
    try {
      const result = await executor.executeCommand('free -h');
      
      if (result.success) {
        return {
          success: true,
          data: result.stdout,
          timestamp: new Date().toISOString()
        };
      }

      return {
        success: false,
        error: 'Failed to get memory info'
      };

    } catch (error) {
      logger.error('getMemoryInfo failed', error);
      return {
        success: false,
        error: error.message
      };
    }
  },

  /**
   * Get disk usage information
   */
  async getDiskInfo() {
    try {
      const result = await executor.executeCommand('df -h');
      
      if (result.success) {
        return {
          success: true,
          data: result.stdout,
          timestamp: new Date().toISOString()
        };
      }

      return {
        success: false,
        error: 'Failed to get disk info'
      };

    } catch (error) {
      logger.error('getDiskInfo failed', error);
      return {
        success: false,
        error: error.message
      };
    }
  },

  /**
   * Get network information
   */
  async getNetworkInfo() {
    try {
      const result = await executor.executeCommand('ip addr show');
      
      if (result.success) {
        return {
          success: true,
          data: result.stdout,
          timestamp: new Date().toISOString()
        };
      }

      return {
        success: false,
        error: 'Failed to get network info'
      };

    } catch (error) {
      logger.error('getNetworkInfo failed', error);
      return {
        success: false,
        error: error.message
      };
    }
  },

  /**
   * Get comprehensive system health report
   */
  async getHealthReport() {
    try {
      logger.info('Generating system health report...');

      const [cpu, memory, disk, network] = await Promise.all([
        this.getCpuInfo(),
        this.getMemoryInfo(),
        this.getDiskInfo(),
        this.getNetworkInfo()
      ]);

      const report = {
        timestamp: new Date().toISOString(),
        cpu: cpu.success ? cpu.data : 'N/A',
        memory: memory.success ? memory.data : 'N/A',
        disk: disk.success ? disk.data : 'N/A',
        network: network.success ? network.data : 'N/A',
        status: 'healthy'
      };

      // Determine overall status
      if (!cpu.success || !memory.success || !disk.success) {
        report.status = 'degraded';
      }

      return {
        success: true,
        report
      };

    } catch (error) {
      logger.error('getHealthReport failed', error);
      return {
        success: false,
        error: error.message
      };
    }
  },

  /**
   * Monitor system in real-time (for a specified duration)
   */
  async monitor(durationSeconds = 10) {
    try {
      logger.info(`Monitoring system for ${durationSeconds} seconds...`);

      const samples = [];
      const interval = 2000; // 2 seconds
      const iterations = Math.floor((durationSeconds * 1000) / interval);

      for (let i = 0; i < iterations; i++) {
        const sample = await this.getHealthReport();
        samples.push(sample);

        if (i < iterations - 1) {
          await new Promise(resolve => setTimeout(resolve, interval));
        }
      }

      return {
        success: true,
        samples,
        duration: durationSeconds,
        timestamp: new Date().toISOString()
      };

    } catch (error) {
      logger.error('monitor failed', error);
      return {
        success: false,
        error: error.message
      };
    }
  }
};
