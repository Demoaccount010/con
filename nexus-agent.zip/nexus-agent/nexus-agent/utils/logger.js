import chalk from 'chalk';
import fs from 'fs/promises';
import path from 'path';
import config from '../config/config.js';

class Logger {
  constructor() {
    this.logFile = path.join(config.LOGS_DIR, `${new Date().toISOString().split('T')[0]}.log`);
    this.ensureLogDir();
  }

  async ensureLogDir() {
    try {
      await fs.mkdir(config.LOGS_DIR, { recursive: true });
    } catch (error) {
      // Directory exists
    }
  }

  async writeToFile(level, message, data = null) {
    const timestamp = new Date().toISOString();
    const logEntry = {
      timestamp,
      level,
      message,
      data
    };
    
    try {
      const logLine = JSON.stringify(logEntry) + '\n';
      await fs.appendFile(this.logFile, logLine);
    } catch (error) {
      // Silent fail for logging errors
    }
  }

  debug(message, data = null) {
    if (config.LOG_LEVEL === 'debug') {
      console.log(chalk.gray(`[DEBUG] ${message}`));
      if (data) console.log(chalk.gray(JSON.stringify(data, null, 2)));
      this.writeToFile('debug', message, data);
    }
  }

  info(message, data = null) {
    console.log(chalk.blue(`[INFO] ${message}`));
    if (data) console.log(data);
    this.writeToFile('info', message, data);
  }

  success(message, data = null) {
    console.log(chalk.green(`[SUCCESS] ✓ ${message}`));
    if (data) console.log(data);
    this.writeToFile('success', message, data);
  }

  warn(message, data = null) {
    console.log(chalk.yellow(`[WARN] ⚠ ${message}`));
    if (data) console.log(data);
    this.writeToFile('warn', message, data);
  }

  error(message, error = null) {
    console.log(chalk.red(`[ERROR] ✗ ${message}`));
    if (error) {
      console.log(chalk.red(error.stack || error.message || error));
      this.writeToFile('error', message, { error: error.stack || error.message || String(error) });
    } else {
      this.writeToFile('error', message);
    }
  }

  system(message) {
    console.log(chalk.cyan(`[SYSTEM] ${message}`));
    this.writeToFile('system', message);
  }

  brain(message) {
    console.log(chalk.magenta(`[BRAIN] 🧠 ${message}`));
    this.writeToFile('brain', message);
  }

  agent(message) {
    console.log(chalk.greenBright(`[AGENT] 🤖 ${message}`));
    this.writeToFile('agent', message);
  }

  evolution(message) {
    console.log(chalk.yellowBright(`[EVOLUTION] 🔄 ${message}`));
    this.writeToFile('evolution', message);
  }
}

export default new Logger();
