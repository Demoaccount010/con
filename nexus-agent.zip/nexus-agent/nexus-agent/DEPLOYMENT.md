# VPS Deployment Guide for NEXUS

This guide walks you through deploying NEXUS on a VPS (Virtual Private Server).

## Prerequisites

- VPS with Ubuntu 20.04+ / Debian 10+ / CentOS 8+
- SSH access to the VPS
- Root or sudo privileges
- Cloudflare AI Worker API key

## Step-by-Step Deployment

### 1. Connect to Your VPS

```bash
ssh user@your-vps-ip
```

### 2. Install Node.js 18+

#### Ubuntu/Debian:
```bash
# Install Node.js 18.x
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Verify installation
node -v
npm -v
```

#### CentOS/RHEL:
```bash
# Install Node.js 18.x
curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
sudo yum install -y nodejs

# Verify installation
node -v
npm -v
```

### 3. Install Git (if not installed)

```bash
# Ubuntu/Debian
sudo apt-get install git -y

# CentOS/RHEL
sudo yum install git -y
```

### 4. Upload NEXUS to VPS

#### Option A: Using SCP (from your local machine)
```bash
# Zip the project
tar -czf nexus-agent.tar.gz nexus-agent/

# Upload to VPS
scp nexus-agent.tar.gz user@your-vps-ip:~/

# SSH into VPS and extract
ssh user@your-vps-ip
tar -xzf nexus-agent.tar.gz
cd nexus-agent
```

#### Option B: Using Git (if you have a repo)
```bash
git clone https://github.com/yourusername/nexus-agent.git
cd nexus-agent
```

#### Option C: Manual Upload
1. Use FTP/SFTP client (FileZilla, WinSCP)
2. Upload entire nexus-agent folder to VPS
3. SSH into VPS and navigate to folder

### 5. Run Installation Script

```bash
chmod +x setup.sh
./setup.sh
```

This will:
- Check Node.js version
- Install dependencies
- Create necessary directories
- Set up .env file

### 6. Configure API Key

```bash
# Edit .env file
nano .env

# Add your API key:
AI_API_KEY=your-cloudflare-worker-api-key

# Save and exit (Ctrl+X, then Y, then Enter)
```

### 7. Test NEXUS

```bash
npm start
```

You should see the NEXUS banner and initialization sequence.

### 8. Run NEXUS in Background (Production)

#### Option A: Using PM2 (Recommended)

```bash
# Install PM2 globally
sudo npm install -g pm2

# Start NEXUS with PM2
pm2 start index.js --name nexus

# View logs
pm2 logs nexus

# Stop
pm2 stop nexus

# Restart
pm2 restart nexus

# Auto-start on system boot
pm2 startup
pm2 save
```

#### Option B: Using Screen

```bash
# Install screen
sudo apt-get install screen -y

# Start a screen session
screen -S nexus

# Run NEXUS
npm start

# Detach from screen (Ctrl+A, then D)

# Reattach to screen
screen -r nexus

# Kill screen session
screen -X -S nexus quit
```

#### Option C: Using Systemd Service

Create a service file:

```bash
sudo nano /etc/systemd/system/nexus.service
```

Add this content:

```ini
[Unit]
Description=NEXUS Autonomous AI Agent
After=network.target

[Service]
Type=simple
User=your-username
WorkingDirectory=/home/your-username/nexus-agent
Environment="AI_API_KEY=your-api-key"
ExecStart=/usr/bin/node index.js
Restart=on-failure
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Enable and start the service:

```bash
sudo systemctl daemon-reload
sudo systemctl enable nexus
sudo systemctl start nexus

# Check status
sudo systemctl status nexus

# View logs
sudo journalctl -u nexus -f

# Stop
sudo systemctl stop nexus
```

## Security Recommendations

### 1. Firewall Setup

```bash
# Ubuntu/Debian (UFW)
sudo ufw allow 22/tcp  # SSH
sudo ufw enable

# CentOS/RHEL (firewalld)
sudo firewall-cmd --permanent --add-service=ssh
sudo firewall-cmd --reload
```

### 2. SSH Key Authentication

```bash
# On your local machine, generate SSH key
ssh-keygen -t ed25519

# Copy to VPS
ssh-copy-id user@your-vps-ip

# Disable password authentication (on VPS)
sudo nano /etc/ssh/sshd_config
# Set: PasswordAuthentication no
sudo systemctl restart sshd
```

### 3. Create Dedicated User

```bash
# Create user for NEXUS
sudo useradd -m -s /bin/bash nexus

# Set password
sudo passwd nexus

# Add to sudo group (optional)
sudo usermod -aG sudo nexus

# Switch to nexus user
sudo su - nexus

# Deploy NEXUS in /home/nexus/
```

### 4. Limit Command Permissions

Edit `config/config.js` and customize `DANGEROUS_COMMANDS` array to add more restrictions specific to your environment.

### 5. Environment Variables Security

```bash
# Never commit .env to git
echo ".env" >> .gitignore

# Set restrictive permissions on .env
chmod 600 .env
```

## Monitoring

### View Logs

```bash
# Real-time logs
tail -f memory/logs/$(date +%Y-%m-%d).log

# Last 100 lines
tail -n 100 memory/logs/$(date +%Y-%m-%d).log

# Search logs
grep "ERROR" memory/logs/*.log
```

### System Resources

```bash
# Monitor NEXUS process
top -p $(pgrep -f "node index.js")

# Memory usage
ps aux | grep "node index.js"

# Disk usage
du -sh nexus-agent/
```

## Backup Strategy

### Backup Memory and Plugins

```bash
#!/bin/bash
# backup.sh

BACKUP_DIR="/home/nexus/backups"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

# Backup memory and plugins
tar -czf $BACKUP_DIR/nexus-backup-$DATE.tar.gz \
  memory/ \
  plugins/ \
  .env

# Keep only last 7 backups
ls -t $BACKUP_DIR/nexus-backup-*.tar.gz | tail -n +8 | xargs -r rm

echo "Backup completed: nexus-backup-$DATE.tar.gz"
```

Make it executable and run:

```bash
chmod +x backup.sh
./backup.sh
```

Add to cron for daily backups:

```bash
crontab -e

# Add this line (daily at 2 AM):
0 2 * * * /home/nexus/nexus-agent/backup.sh
```

## Troubleshooting

### Port Already in Use
```bash
# Find process using port
sudo lsof -i :3000

# Kill process
sudo kill -9 <PID>
```

### Permission Denied
```bash
# Fix ownership
sudo chown -R nexus:nexus /home/nexus/nexus-agent

# Fix permissions
chmod -R 755 /home/nexus/nexus-agent
chmod 600 /home/nexus/nexus-agent/.env
```

### Out of Memory
```bash
# Check memory
free -h

# Add swap if needed
sudo fallocate -l 2G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile

# Make permanent
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
```

### Module Not Found
```bash
# Clear cache and reinstall
rm -rf node_modules package-lock.json
npm cache clean --force
npm install
```

## Updates

### Update NEXUS

```bash
# Stop NEXUS
pm2 stop nexus

# Backup current version
cp -r nexus-agent nexus-agent.backup

# Pull updates (if using git)
git pull

# Or upload new files
# Then:

# Install new dependencies
npm install

# Restart
pm2 restart nexus
```

## Performance Optimization

### Enable Node.js Cluster Mode

For better CPU utilization:

```javascript
// cluster.js
import cluster from 'cluster';
import os from 'os';
import { fileURLToPath } from 'url';

if (cluster.isPrimary) {
  const numCPUs = os.cpus().length;
  
  for (let i = 0; i < numCPUs; i++) {
    cluster.fork();
  }
  
  cluster.on('exit', (worker) => {
    console.log(`Worker ${worker.process.pid} died, starting new...`);
    cluster.fork();
  });
} else {
  import('./index.js');
}
```

### Increase Memory Limit

```bash
# Start with more memory
node --max-old-space-size=4096 index.js
```

## Production Checklist

- [ ] Node.js 18+ installed
- [ ] Dependencies installed
- [ ] .env configured with API key
- [ ] Firewall configured
- [ ] SSH key authentication enabled
- [ ] Running as non-root user
- [ ] Process manager configured (PM2/systemd)
- [ ] Logs monitored
- [ ] Backups automated
- [ ] Memory limits set
- [ ] Dangerous commands reviewed
- [ ] System resources monitored

## Support

For issues:
1. Check logs in `memory/logs/`
2. Verify API key is correct
3. Check system resources
4. Review execution history
5. Test with simple commands first

---

**VPS Deployment Complete!**

Your NEXUS agent is now running autonomously on your VPS, ready to execute tasks with owner approval.
