import inquirer from 'inquirer';
import thinking from './thinking.js';
import executor from './executor.js';
import verifier from './verifier.js';
import evolution from './evolution.js';
import pluginLoader from './plugin_loader.js';
import memory from './memory.js';
import logger from '../utils/logger.js';
import config from '../config/config.js';

class MetaBrain {
  constructor() {
    this.initialized = false;
    this.processing = false;
  }

  async initialize() {
    logger.system('Initializing NEXUS Meta Brain...');

    try {
      // Initialize all subsystems
      await memory.initialize();
      await pluginLoader.initialize();

      // Check if owner exists
      const owner = memory.getOwner();
      if (!owner) {
        await this.setupOwner();
      } else {
        logger.info(`Welcome back, ${owner.name}!`);
        await memory.updateLastSeen();
      }

      this.initialized = true;
      logger.success('NEXUS Meta Brain initialized successfully');

      // Display system status
      await this.displayStatus();

      return true;

    } catch (error) {
      logger.error('Failed to initialize Meta Brain', error);
      return false;
    }
  }

  /**
   * Setup owner profile on first run
   */
  async setupOwner() {
    logger.system('First time setup - Let me get to know you!');

    const answers = await inquirer.prompt([
      {
        type: 'input',
        name: 'name',
        message: 'What is your name?',
        validate: (input) => input.trim().length > 0 || 'Name cannot be empty'
      },
      {
        type: 'input',
        name: 'relationship',
        message: 'How should I address you? (e.g., boss, partner, friend)',
        default: 'partner'
      },
      {
        type: 'input',
        name: 'preferences',
        message: 'Any preferences I should know? (optional)',
        default: ''
      }
    ]);

    await memory.saveOwner(answers);
    logger.success(`Great to meet you, ${answers.name}! I'm NEXUS, your autonomous AI agent.`);
  }

  /**
   * Display system status
   */
  async displayStatus() {
    const owner = memory.getOwner();
    const tools = memory.getTools();
    const goals = memory.getActiveGoals();
    const plugins = pluginLoader.getAllPlugins();
    const evolutionStats = evolution.getStats();

    console.log('\n' + '='.repeat(60));
    logger.system('NEXUS SYSTEM STATUS');
    console.log('='.repeat(60));
    
    if (owner) {
      logger.info(`Owner: ${owner.name}`);
    }
    logger.info(`Loaded Plugins: ${plugins.length}`);
    logger.info(`Registered Tools: ${tools.length}`);
    logger.info(`Active Goals: ${goals.length}`);
    logger.info(`Total Evolutions: ${evolutionStats.totalEvolutions}`);
    logger.info(`Plugins Created: ${evolutionStats.pluginsCreated}`);
    
    console.log('='.repeat(60) + '\n');
  }

  /**
   * Process a task from start to finish
   */
  async processTask(task) {
    if (this.processing) {
      logger.warn('Already processing a task. Please wait.');
      return;
    }

    this.processing = true;

    try {
      logger.brain(`Processing task: ${task}`);

      // Step 1: Analyze the task
      logger.brain('Step 1: Analyzing task...');
      const analysis = await thinking.analyzeTask(task);
      logger.info('Task Analysis:', analysis);

      // Step 2: Check for missing capabilities and evolve if needed
      logger.brain('Step 2: Checking capabilities...');
      const evolutionResult = await evolution.evolve(task);
      
      if (evolutionResult.evolved) {
        logger.evolution(`New plugin created: ${evolutionResult.plugin}`);
        logger.info('Retrying task with new capabilities...');
      }

      // Step 3: Generate execution plan
      logger.brain('Step 3: Generating execution plan...');
      const planPrompt = `
Based on this task analysis:

${analysis}

Generate a detailed step-by-step execution plan.

Format:
STEP 1: [description]
COMMAND: [command to execute or "NONE" if not applicable]
VERIFICATION: [how to verify success]

STEP 2: ...
`;

      const plan = await thinking.think(planPrompt);
      logger.info('Execution Plan:', plan);

      // Step 4: Request approval
      if (config.REQUIRE_APPROVAL) {
        const approved = await this.requestApproval(plan);
        if (!approved) {
          logger.warn('Task cancelled by owner');
          return {
            success: false,
            cancelled: true
          };
        }
      }

      // Step 5: Execute the plan
      logger.brain('Step 5: Executing plan...');
      const executionResult = await this.executePlan(plan);

      // Step 6: Learn from execution
      logger.brain('Step 6: Learning from execution...');
      await evolution.learnFromExecution(task, executionResult, executionResult.success);

      logger.brain('Task processing completed');

      return executionResult;

    } catch (error) {
      logger.error('Task processing failed', error);
      return {
        success: false,
        error: error.message
      };
    } finally {
      this.processing = false;
    }
  }

  /**
   * Request owner approval for execution
   */
  async requestApproval(plan) {
    console.log('\n' + '='.repeat(60));
    logger.system('APPROVAL REQUIRED');
    console.log('='.repeat(60));
    console.log('\nExecution Plan:');
    console.log(plan);
    console.log('\n' + '='.repeat(60));

    const answer = await inquirer.prompt([
      {
        type: 'confirm',
        name: 'approved',
        message: 'Do you approve this execution plan?',
        default: false
      }
    ]);

    return answer.approved;
  }

  /**
   * Execute a plan with verification
   */
  async executePlan(plan) {
    const steps = this.parsePlan(plan);
    const results = [];
    const verifications = [];

    for (let i = 0; i < steps.length; i++) {
      const step = steps[i];
      logger.info(`Executing Step ${i + 1}: ${step.description}`);

      let stepResult = {
        step: i + 1,
        description: step.description,
        success: false
      };

      try {
        // Execute command if present
        if (step.command && step.command !== 'NONE') {
          const execResult = await executor.executeCommand(step.command);
          stepResult.executionResult = execResult;
          stepResult.success = execResult.success;

          // Verify execution
          if (step.verification && step.verification !== 'NONE') {
            const verification = await this.performVerification(step.verification, execResult);
            verifications.push(verification);
            stepResult.verification = verification;
          }
        } else {
          // No command to execute, mark as successful
          stepResult.success = true;
          stepResult.message = 'No execution required';
        }

        results.push(stepResult);

        if (!stepResult.success) {
          logger.error(`Step ${i + 1} failed`);
          break;
        }

      } catch (error) {
        logger.error(`Step ${i + 1} error`, error);
        stepResult.error = error.message;
        results.push(stepResult);
        break;
      }
    }

    // Generate verification report
    const verificationReport = await verifier.generateVerificationReport(verifications);

    const allSuccess = results.every(r => r.success);
    logger.info(`Execution ${allSuccess ? 'succeeded' : 'failed'}`);

    return {
      success: allSuccess,
      steps: results,
      verificationReport
    };
  }

  /**
   * Parse plan text into structured steps
   */
  parsePlan(plan) {
    const steps = [];
    const lines = plan.split('\n');
    let currentStep = null;

    for (const line of lines) {
      const stepMatch = line.match(/STEP\s+\d+:\s*(.+)/i);
      const commandMatch = line.match(/COMMAND:\s*(.+)/i);
      const verificationMatch = line.match(/VERIFICATION:\s*(.+)/i);

      if (stepMatch) {
        if (currentStep) {
          steps.push(currentStep);
        }
        currentStep = {
          description: stepMatch[1].trim(),
          command: null,
          verification: null
        };
      } else if (commandMatch && currentStep) {
        currentStep.command = commandMatch[1].trim();
      } else if (verificationMatch && currentStep) {
        currentStep.verification = verificationMatch[1].trim();
      }
    }

    if (currentStep) {
      steps.push(currentStep);
    }

    return steps;
  }

  /**
   * Perform verification based on description
   */
  async performVerification(verificationDesc, executionResult) {
    // Determine verification type from description
    if (verificationDesc.toLowerCase().includes('file') && verificationDesc.toLowerCase().includes('exist')) {
      const fileMatch = verificationDesc.match(/['"]([^'"]+)['"]/);
      if (fileMatch) {
        return await verifier.verifyFileCreated(fileMatch[1]);
      }
    }

    if (verificationDesc.toLowerCase().includes('process') && verificationDesc.toLowerCase().includes('running')) {
      const processMatch = verificationDesc.match(/['"]([^'"]+)['"]/);
      if (processMatch) {
        return await verifier.verifyProcessRunning(processMatch[1]);
      }
    }

    // Default: verify command execution
    return await verifier.verifyCommandExecution(executionResult);
  }

  /**
   * Interactive conversation mode
   */
  async converse() {
    logger.agent('Entering conversation mode. Type "exit" to quit.');

    while (true) {
      const answer = await inquirer.prompt([
        {
          type: 'input',
          name: 'message',
          message: '>',
          validate: (input) => input.trim().length > 0 || 'Message cannot be empty'
        }
      ]);

      const message = answer.message.trim();

      if (message.toLowerCase() === 'exit' || message.toLowerCase() === 'quit') {
        logger.agent('Goodbye!');
        break;
      }

      // Check if it's a command or conversation
      if (this.isActionRequest(message)) {
        await this.processTask(message);
      } else {
        const response = await thinking.think(message);
        logger.agent(response);
      }
    }
  }

  /**
   * Determine if message is an action request
   */
  isActionRequest(message) {
    const actionKeywords = [
      'create', 'make', 'build', 'install', 'run', 'execute',
      'start', 'stop', 'delete', 'remove', 'clone', 'deploy',
      'download', 'upload', 'setup', 'configure'
    ];

    const lowerMessage = message.toLowerCase();
    return actionKeywords.some(keyword => lowerMessage.includes(keyword));
  }

  /**
   * Quick command execution
   */
  async quickExecute(command) {
    logger.brain('Quick execution mode');

    if (config.REQUIRE_APPROVAL) {
      const approved = await this.requestApproval(`Execute: ${command}`);
      if (!approved) {
        logger.warn('Execution cancelled');
        return;
      }
    }

    const result = await executor.executeCommand(command);
    logger.info('Result:', result);

    return result;
  }

  /**
   * List available capabilities
   */
  async listCapabilities() {
    const plugins = pluginLoader.listPlugins();
    const tools = memory.getTools();

    console.log('\n' + '='.repeat(60));
    logger.system('AVAILABLE CAPABILITIES');
    console.log('='.repeat(60));

    console.log('\nCore Capabilities:');
    console.log('- Command Execution (bash, shell)');
    console.log('- File Operations (create, read, delete)');
    console.log('- Process Management');
    console.log('- Package Installation');
    console.log('- Git Operations');
    console.log('- System Information');

    if (plugins.length > 0) {
      console.log('\nCustom Plugins:');
      plugins.forEach(plugin => {
        console.log(`\n${plugin.name} (v${plugin.version})`);
        console.log(`  ${plugin.description}`);
        console.log(`  Methods: ${plugin.methods.join(', ')}`);
      });
    }

    console.log('\n' + '='.repeat(60) + '\n');
  }
}

export default new MetaBrain();
