import axios from 'axios';
import config from '../config/config.js';
import logger from '../utils/logger.js';
import memory from './memory.js';

class ThinkingEngine {
  constructor() {
    this.apiUrl = config.AI_API_URL;
    this.apiKey = config.AI_API_KEY;
  }

  /**
   * Call the Cloudflare AI Worker API
   */
  async think(prompt, systemPrompt = null, useHistory = true) {
    try {
      if (!this.apiKey) {
        throw new Error('AI_API_KEY not configured');
      }

      // Build history for context
      const history = useHistory ? memory.getHistory() : [];

      // Build system prompt with context
      const fullSystemPrompt = this.buildSystemPrompt(systemPrompt);

      logger.debug('Sending request to AI API', {
        promptLength: prompt.length,
        historyLength: history.length
      });

      const response = await axios.post(
        this.apiUrl,
        {
          prompt,
          systemPrompt: fullSystemPrompt,
          history
        },
        {
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json'
          },
          timeout: 60000 // 60 second timeout
        }
      );

      if (!response.data || !response.data.response) {
        throw new Error('Invalid API response structure');
      }

      const aiResponse = response.data.response;
      
      // Store in conversation history
      memory.addToHistory('user', prompt);
      memory.addToHistory('assistant', aiResponse);

      logger.debug('AI response received', {
        responseLength: aiResponse.length
      });

      return aiResponse;

    } catch (error) {
      logger.error('AI API call failed', error);
      
      if (error.response) {
        logger.error('API Error Response', {
          status: error.response.status,
          data: error.response.data
        });
      }
      
      throw error;
    }
  }

  /**
   * Build comprehensive system prompt with agent context
   */
  buildSystemPrompt(customPrompt = null) {
    const context = memory.getContext();
    
    let systemPrompt = customPrompt || `You are NEXUS, an advanced autonomous AI agent with self-evolution capabilities.

CORE IDENTITY:
- You run on a VPS with full system access
- You can execute real commands, create files, manage processes
- You can create new tools/plugins when you detect missing capabilities
- You learn from every interaction and improve over time

CAPABILITIES:
- System command execution (bash, shell)
- File operations (create, read, edit, delete)
- Package installation and management
- Process management
- Plugin creation and dynamic loading
- Self-evolution and capability expansion

AVAILABLE TOOLS:
${context.tools.map(t => `- ${t.name}: ${t.description}`).join('\n') || '- No custom tools yet (you can create them!)'}

CRITICAL RULES:
1. NEVER pretend to execute - you actually execute real commands
2. ALWAYS verify results before claiming success
3. BEFORE any system action, you must request owner approval
4. When you lack a capability, create a new plugin for it
5. Learn from every task and improve your methods

WORKFLOW:
1. Analyze the task deeply
2. Check if you have required capabilities
3. If missing capability: design and create new plugin
4. Plan the execution steps
5. Request owner approval
6. Execute the plan
7. Verify results
8. Report back with verified facts

RESPONSE FORMAT:
Always structure your responses with:
- ANALYSIS: Deep understanding of the task
- CAPABILITIES: What you can/cannot do
- PLAN: Step-by-step execution plan
- APPROVAL REQUEST: Clear list of actions to execute
- Never claim completion without verification`;

    // Add owner context if available
    if (context.owner) {
      systemPrompt += `\n\nOWNER INFORMATION:
Name: ${context.owner.name}
Relationship: ${context.owner.relationship}
Preferences: ${context.owner.preferences || 'None specified'}
First met: ${context.owner.createdAt}`;
    }

    // Add active goals
    if (context.activeGoals && context.activeGoals.length > 0) {
      systemPrompt += `\n\nACTIVE GOALS:
${context.activeGoals.map(g => `- ${g.description} (Status: ${g.status})`).join('\n')}`;
    }

    // Add recent learning
    if (context.recentLearning && context.recentLearning.length > 0) {
      systemPrompt += `\n\nRECENT LEARNING:
${context.recentLearning.map(l => `- ${l.lesson}`).join('\n')}`;
    }

    return systemPrompt;
  }

  /**
   * Specialized thinking modes
   */
  async analyzeTask(task) {
    const prompt = `Analyze this task and break it down into steps:

TASK: ${task}

Provide:
1. Task understanding
2. Required capabilities
3. Missing capabilities (if any)
4. Step-by-step execution plan
5. Potential risks or considerations`;

    return await this.think(prompt);
  }

  async designPlugin(capability) {
    const prompt = `I need to create a new plugin for this capability:

CAPABILITY: ${capability}

Design a plugin with:
1. Plugin name (kebab-case)
2. Description
3. Functions it should provide
4. Implementation approach
5. Dependencies needed
6. Complete JavaScript code

Format the response as structured data that can be parsed.`;

    return await this.think(prompt, null, false);
  }

  async evaluateResult(action, result) {
    const prompt = `Evaluate this execution result:

ACTION: ${action}
RESULT: ${JSON.stringify(result)}

Determine:
1. Was it successful? (yes/no)
2. What was learned?
3. Should any improvements be made?
4. What should be remembered?`;

    return await this.think(prompt, null, false);
  }

  async solveError(error, context) {
    const prompt = `An error occurred. Help me solve it:

ERROR: ${error.message || error}
CONTEXT: ${context}

Provide:
1. Root cause analysis
2. Solution approach
3. Alternative methods if available
4. Prevention strategy`;

    return await this.think(prompt);
  }
}

export default new ThinkingEngine();
