import thinking from './thinking.js';
import pluginLoader from './plugin_loader.js';
import memory from './memory.js';
import logger from '../utils/logger.js';
import config from '../config/config.js';

class EvolutionEngine {
  constructor() {
    this.evolutionHistory = [];
  }

  /**
   * Detect if a capability is missing for a task
   */
  async detectMissingCapability(task) {
    logger.evolution('Analyzing task for missing capabilities...');

    // Get current tools
    const currentTools = memory.getTools();
    const toolNames = currentTools.map(t => t.name);

    // Ask AI to analyze
    const analysis = await thinking.think(`
Analyze this task and determine if I have the required capabilities:

TASK: ${task}

CURRENT TOOLS:
${toolNames.length > 0 ? toolNames.join(', ') : 'None yet'}

Respond in this format:
MISSING: <yes/no>
CAPABILITY_NEEDED: <brief description>
REASON: <why it's needed>
`);

    logger.debug('Capability analysis:', analysis);

    // Parse response
    const isMissing = analysis.toLowerCase().includes('missing: yes');
    
    if (isMissing) {
      // Extract capability name
      const capabilityMatch = analysis.match(/CAPABILITY_NEEDED:\s*(.+)/i);
      const capability = capabilityMatch ? capabilityMatch[1].trim() : 'Unknown capability';
      
      logger.evolution(`Missing capability detected: ${capability}`);
      
      return {
        missing: true,
        capability,
        analysis
      };
    }

    logger.info('All required capabilities available');
    return {
      missing: false
    };
  }

  /**
   * Create a new plugin for missing capability
   */
  async createCapabilityPlugin(capability, context = {}) {
    try {
      logger.evolution(`Designing plugin for: ${capability}`);

      // Ask AI to design the plugin
      const design = await thinking.designPlugin(capability);
      
      logger.debug('Plugin design received');

      // Parse the design to extract plugin details
      const pluginInfo = this.parsePluginDesign(design);
      
      if (!pluginInfo.name) {
        throw new Error('Could not extract plugin name from design');
      }

      logger.evolution(`Creating plugin: ${pluginInfo.name}`);

      // Generate plugin code
      const pluginCode = this.generatePluginCode(pluginInfo);

      // Create the plugin file
      const created = await pluginLoader.createPlugin(pluginInfo.name, pluginCode);

      if (!created) {
        throw new Error('Plugin creation failed');
      }

      // Record evolution
      await this.recordEvolution({
        type: 'plugin_created',
        capability,
        pluginName: pluginInfo.name,
        context,
        design: pluginInfo
      });

      logger.evolution(`Successfully created plugin: ${pluginInfo.name}`);

      return {
        success: true,
        pluginName: pluginInfo.name,
        pluginInfo
      };

    } catch (error) {
      logger.error('Failed to create capability plugin', error);
      
      await this.recordEvolution({
        type: 'plugin_creation_failed',
        capability,
        error: error.message
      });

      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Parse AI's plugin design into structured data
   */
  parsePluginDesign(design) {
    const info = {
      name: null,
      description: null,
      functions: [],
      dependencies: [],
      code: null
    };

    try {
      // Extract plugin name
      const nameMatch = design.match(/(?:Plugin Name|Name):\s*([a-z-]+)/i);
      if (nameMatch) {
        info.name = nameMatch[1].trim().toLowerCase().replace(/\s+/g, '-');
      }

      // Extract description
      const descMatch = design.match(/(?:Description):\s*(.+?)(?:\n|$)/i);
      if (descMatch) {
        info.description = descMatch[1].trim();
      }

      // Extract code if present
      const codeMatch = design.match(/```(?:javascript|js)?\s*([\s\S]+?)```/);
      if (codeMatch) {
        info.code = codeMatch[1].trim();
      }

      // Extract functions
      const functionsMatch = design.match(/Functions?:([\s\S]+?)(?:Implementation|Dependencies|$)/i);
      if (functionsMatch) {
        const functionsList = functionsMatch[1].trim().split('\n');
        info.functions = functionsList
          .filter(line => line.trim())
          .map(line => {
            const funcName = line.replace(/^[-*\d.)\s]+/, '').trim().split(/[\s:(]/)[0];
            return {
              name: funcName,
              description: line.trim()
            };
          });
      }

      // Extract dependencies
      const depsMatch = design.match(/Dependencies?:([\s\S]+?)(?:\n\n|$)/i);
      if (depsMatch) {
        info.dependencies = depsMatch[1]
          .trim()
          .split('\n')
          .map(line => line.replace(/^[-*\d.)\s]+/, '').trim())
          .filter(Boolean);
      }

    } catch (error) {
      logger.warn('Error parsing plugin design', error);
    }

    // Fallback defaults
    if (!info.name) {
      info.name = 'custom-plugin-' + Date.now();
    }
    if (!info.description) {
      info.description = 'Auto-generated plugin';
    }

    return info;
  }

  /**
   * Generate plugin code from design
   */
  generatePluginCode(pluginInfo) {
    // If AI provided complete code, use it
    if (pluginInfo.code) {
      return pluginInfo.code;
    }

    // Otherwise generate from template
    const methods = pluginInfo.functions.map(func => ({
      name: func.name,
      description: func.description,
      params: []
    }));

    return pluginLoader.generatePluginTemplate(
      pluginInfo.name,
      pluginInfo.description,
      methods
    );
  }

  /**
   * Self-improvement loop
   */
  async improveCapability(pluginName, feedback) {
    try {
      logger.evolution(`Improving plugin: ${pluginName}`);

      const plugin = pluginLoader.getPlugin(pluginName);
      if (!plugin) {
        throw new Error(`Plugin not found: ${pluginName}`);
      }

      // Ask AI for improvements
      const improvement = await thinking.think(`
I have a plugin called "${pluginName}" that needs improvement.

CURRENT DESCRIPTION: ${plugin.description}

FEEDBACK: ${feedback}

Suggest improvements and provide updated code if necessary.
`);

      logger.info('Improvement suggestions received');
      
      await this.recordEvolution({
        type: 'improvement_suggested',
        pluginName,
        feedback,
        suggestions: improvement
      });

      return {
        success: true,
        suggestions: improvement
      };

    } catch (error) {
      logger.error('Failed to improve capability', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Learn from execution results
   */
  async learnFromExecution(action, result, success) {
    try {
      logger.evolution('Learning from execution...');

      // Ask AI to evaluate
      const evaluation = await thinking.evaluateResult(action, result);

      // Extract learning points
      const learningMatch = evaluation.match(/What was learned[?:]?\s*([\s\S]+?)(?:\n\n|$)/i);
      const learning = learningMatch ? learningMatch[1].trim() : 'Execution completed';

      // Store in memory
      await memory.addLearning({
        action,
        result: success ? 'success' : 'failure',
        lesson: learning,
        evaluation
      });

      logger.success('Learning recorded');

      return {
        success: true,
        learning
      };

    } catch (error) {
      logger.error('Failed to learn from execution', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Record evolution event
   */
  async recordEvolution(event) {
    this.evolutionHistory.push({
      ...event,
      timestamp: new Date().toISOString()
    });

    // Also record in memory as learning
    await memory.addLearning({
      type: 'evolution',
      ...event,
      lesson: `Evolution: ${event.type}`
    });

    logger.debug('Evolution event recorded', event);
  }

  /**
   * Get evolution history
   */
  getEvolutionHistory(limit = 10) {
    return this.evolutionHistory.slice(-limit);
  }

  /**
   * Autonomous evolution - complete cycle
   */
  async evolve(task, context = {}) {
    logger.evolution('Starting evolution cycle...');

    const evolutionSteps = [];

    try {
      // Step 1: Detect missing capability
      const detection = await this.detectMissingCapability(task);
      evolutionSteps.push({ step: 'detection', result: detection });

      if (!detection.missing) {
        logger.info('No evolution needed - capabilities sufficient');
        return {
          success: true,
          evolved: false,
          message: 'Capabilities sufficient',
          steps: evolutionSteps
        };
      }

      // Step 2: Create plugin
      if (config.AUTO_CREATE_PLUGINS) {
        const creation = await this.createCapabilityPlugin(detection.capability, context);
        evolutionSteps.push({ step: 'creation', result: creation });

        if (!creation.success) {
          throw new Error(`Plugin creation failed: ${creation.error}`);
        }

        logger.evolution('Evolution cycle completed successfully');

        return {
          success: true,
          evolved: true,
          capability: detection.capability,
          plugin: creation.pluginName,
          steps: evolutionSteps
        };
      } else {
        logger.warn('Auto-creation disabled - manual plugin creation required');
        return {
          success: false,
          evolved: false,
          message: 'Auto-creation disabled',
          capability: detection.capability,
          steps: evolutionSteps
        };
      }

    } catch (error) {
      logger.error('Evolution cycle failed', error);
      
      return {
        success: false,
        evolved: false,
        error: error.message,
        steps: evolutionSteps
      };
    }
  }

  /**
   * Get evolution statistics
   */
  getStats() {
    const stats = {
      totalEvolutions: this.evolutionHistory.length,
      pluginsCreated: this.evolutionHistory.filter(e => e.type === 'plugin_created').length,
      failures: this.evolutionHistory.filter(e => e.type === 'plugin_creation_failed').length,
      improvements: this.evolutionHistory.filter(e => e.type === 'improvement_suggested').length,
      currentPlugins: pluginLoader.getAllPlugins().length
    };

    return stats;
  }
}

export default new EvolutionEngine();
