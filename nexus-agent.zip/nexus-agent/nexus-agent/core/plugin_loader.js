import fs from 'fs/promises';
import path from 'path';
import { pathToFileURL } from 'url';
import config from '../config/config.js';
import logger from '../utils/logger.js';
import memory from './memory.js';
import verifier from './verifier.js';

class PluginLoader {
  constructor() {
    this.plugins = new Map();
    this.pluginsDir = config.PLUGINS_DIR;
  }

  async initialize() {
    try {
      // Ensure plugins directory exists
      await fs.mkdir(this.pluginsDir, { recursive: true });
      
      // Create .gitkeep
      await fs.writeFile(
        path.join(this.pluginsDir, '.gitkeep'),
        '# Plugins directory\n',
        'utf-8'
      );

      logger.success('Plugin system initialized');
      
      // Load existing plugins
      await this.loadAllPlugins();
      
      return true;
    } catch (error) {
      logger.error('Failed to initialize plugin system', error);
      return false;
    }
  }

  /**
   * Load all plugins from plugins directory
   */
  async loadAllPlugins() {
    try {
      const files = await fs.readdir(this.pluginsDir);
      
      const pluginFiles = files.filter(file => 
        file.endsWith('.js') && file !== '.gitkeep'
      );

      if (pluginFiles.length === 0) {
        logger.info('No plugins found to load');
        return;
      }

      logger.info(`Found ${pluginFiles.length} plugin(s)`);

      for (const file of pluginFiles) {
        await this.loadPlugin(file);
      }

    } catch (error) {
      logger.error('Failed to load plugins', error);
    }
  }

  /**
   * Load a single plugin
   */
  async loadPlugin(filename) {
    try {
      const pluginPath = path.join(this.pluginsDir, filename);
      const absolutePath = path.resolve(pluginPath);
      
      // Verify plugin exists and is valid
      const verification = await verifier.verifyPlugin(absolutePath);
      if (!verification.verified) {
        logger.error(`Plugin verification failed: ${filename}`, verification.reason);
        return false;
      }

      // Import the plugin
      const fileUrl = pathToFileURL(absolutePath).href;
      
      // Add timestamp to bypass cache
      const pluginModule = await import(`${fileUrl}?update=${Date.now()}`);

      if (!pluginModule.default) {
        logger.error(`Plugin ${filename} has no default export`);
        return false;
      }

      const plugin = pluginModule.default;

      // Validate plugin structure
      if (!plugin.name || !plugin.description) {
        logger.error(`Plugin ${filename} missing required fields (name, description)`);
        return false;
      }

      // Initialize plugin if it has init method
      if (typeof plugin.init === 'function') {
        await plugin.init();
      }

      // Store plugin
      this.plugins.set(plugin.name, plugin);
      
      // Register in memory
      await memory.registerTool({
        name: plugin.name,
        description: plugin.description,
        filename: filename,
        methods: Object.keys(plugin).filter(k => typeof plugin[k] === 'function')
      });

      logger.success(`Plugin loaded: ${plugin.name}`);
      return true;

    } catch (error) {
      logger.error(`Failed to load plugin: ${filename}`, error);
      return false;
    }
  }

  /**
   * Create a new plugin from code
   */
  async createPlugin(pluginName, code) {
    try {
      const filename = `${pluginName}.js`;
      const pluginPath = path.join(this.pluginsDir, filename);

      // Write plugin file
      await fs.writeFile(pluginPath, code, 'utf-8');
      logger.success(`Plugin file created: ${filename}`);

      // Verify file was created
      const verification = await verifier.verifyFileCreated(pluginPath);
      if (!verification.verified) {
        throw new Error('Plugin file verification failed');
      }

      // Load the plugin
      const loaded = await this.loadPlugin(filename);
      if (!loaded) {
        throw new Error('Plugin loading failed');
      }

      logger.success(`Plugin created and loaded: ${pluginName}`);
      return true;

    } catch (error) {
      logger.error(`Failed to create plugin: ${pluginName}`, error);
      return false;
    }
  }

  /**
   * Get a loaded plugin
   */
  getPlugin(name) {
    return this.plugins.get(name);
  }

  /**
   * Check if plugin exists
   */
  hasPlugin(name) {
    return this.plugins.has(name);
  }

  /**
   * Get all loaded plugins
   */
  getAllPlugins() {
    return Array.from(this.plugins.values());
  }

  /**
   * Reload a plugin (useful after updates)
   */
  async reloadPlugin(name) {
    const plugin = this.plugins.get(name);
    if (!plugin) {
      logger.error(`Plugin not found: ${name}`);
      return false;
    }

    const filename = `${name}.js`;
    this.plugins.delete(name);
    
    return await this.loadPlugin(filename);
  }

  /**
   * Remove a plugin
   */
  async removePlugin(name) {
    try {
      const plugin = this.plugins.get(name);
      if (!plugin) {
        logger.error(`Plugin not found: ${name}`);
        return false;
      }

      const filename = `${name}.js`;
      const pluginPath = path.join(this.pluginsDir, filename);

      // Delete file
      await fs.unlink(pluginPath);
      
      // Remove from memory
      this.plugins.delete(name);

      logger.success(`Plugin removed: ${name}`);
      return true;

    } catch (error) {
      logger.error(`Failed to remove plugin: ${name}`, error);
      return false;
    }
  }

  /**
   * Execute a plugin method
   */
  async executePluginMethod(pluginName, methodName, ...args) {
    try {
      const plugin = this.getPlugin(pluginName);
      
      if (!plugin) {
        throw new Error(`Plugin not found: ${pluginName}`);
      }

      if (typeof plugin[methodName] !== 'function') {
        throw new Error(`Method ${methodName} not found in plugin ${pluginName}`);
      }

      logger.info(`Executing ${pluginName}.${methodName}()`);
      const result = await plugin[methodName](...args);
      
      logger.success(`Plugin method executed: ${pluginName}.${methodName}()`);
      return {
        success: true,
        result
      };

    } catch (error) {
      logger.error(`Plugin execution failed: ${pluginName}.${methodName}()`, error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * List all available plugins with their methods
   */
  listPlugins() {
    const pluginsList = [];

    for (const [name, plugin] of this.plugins) {
      const methods = Object.keys(plugin)
        .filter(key => typeof plugin[key] === 'function' && key !== 'init');

      pluginsList.push({
        name,
        description: plugin.description,
        methods,
        version: plugin.version || '1.0.0'
      });
    }

    return pluginsList;
  }

  /**
   * Generate plugin template
   */
  generatePluginTemplate(name, description, methods = []) {
    return `/**
 * Plugin: ${name}
 * Description: ${description}
 * Auto-generated by NEXUS Evolution Engine
 */

import logger from '../utils/logger.js';
import executor from '../core/executor.js';

export default {
  name: '${name}',
  description: '${description}',
  version: '1.0.0',

  /**
   * Initialize plugin
   */
  async init() {
    logger.info('${name} plugin initialized');
  },

${methods.map(method => `  /**
   * ${method.description || method.name}
   */
  async ${method.name}(${method.params ? method.params.join(', ') : ''}) {
    try {
      logger.info('Executing ${method.name}');
      
      // TODO: Implement ${method.name}
      
      return {
        success: true,
        message: '${method.name} executed'
      };
    } catch (error) {
      logger.error('${method.name} failed', error);
      return {
        success: false,
        error: error.message
      };
    }
  }`).join(',\n\n')}
};
`;
  }
}

export default new PluginLoader();
