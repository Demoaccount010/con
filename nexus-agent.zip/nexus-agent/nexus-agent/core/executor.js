import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs/promises';
import path from 'path';
import config from '../config/config.js';
import logger from '../utils/logger.js';

const execAsync = promisify(exec);

class Executor {
  constructor() {
    this.executionHistory = [];
  }

  /**
   * Execute a shell command with safety checks
   */
  async executeCommand(command, options = {}) {
    try {
      // Safety checks
      if (!this.isSafeCommand(command)) {
        throw new Error('DANGEROUS COMMAND DETECTED: Execution blocked for safety');
      }

      logger.info(`Executing command: ${command}`);
      
      const startTime = Date.now();
      const result = await execAsync(command, {
        cwd: options.cwd || process.cwd(),
        timeout: options.timeout || 30000, // 30 second timeout
        maxBuffer: 1024 * 1024 * 10 // 10MB buffer
      });

      const executionTime = Date.now() - startTime;

      const executionResult = {
        command,
        success: true,
        stdout: result.stdout,
        stderr: result.stderr,
        executionTime,
        timestamp: new Date().toISOString()
      };

      this.executionHistory.push(executionResult);
      logger.success(`Command executed successfully (${executionTime}ms)`);
      
      if (result.stdout) {
        logger.debug('STDOUT:', result.stdout);
      }
      if (result.stderr) {
        logger.warn('STDERR:', result.stderr);
      }

      return executionResult;

    } catch (error) {
      const executionResult = {
        command,
        success: false,
        error: error.message,
        stdout: error.stdout || '',
        stderr: error.stderr || '',
        timestamp: new Date().toISOString()
      };

      this.executionHistory.push(executionResult);
      logger.error(`Command execution failed: ${command}`, error);

      return executionResult;
    }
  }

  /**
   * Execute multiple commands in sequence
   */
  async executeSequence(commands, stopOnError = true) {
    const results = [];

    for (const cmd of commands) {
      const result = await this.executeCommand(cmd);
      results.push(result);

      if (!result.success && stopOnError) {
        logger.warn('Stopping sequence due to error');
        break;
      }
    }

    return results;
  }

  /**
   * Safety check for dangerous commands
   */
  isSafeCommand(command) {
    // Check against blacklist
    for (const dangerous of config.DANGEROUS_COMMANDS) {
      if (command.includes(dangerous)) {
        logger.error(`Dangerous command detected: ${dangerous}`);
        return false;
      }
    }

    // Length check
    if (command.length > config.MAX_COMMAND_LENGTH) {
      logger.error('Command too long');
      return false;
    }

    return true;
  }

  /**
   * File operations
   */
  async createFile(filePath, content) {
    try {
      // Ensure directory exists
      const dir = path.dirname(filePath);
      await fs.mkdir(dir, { recursive: true });

      await fs.writeFile(filePath, content, 'utf-8');
      logger.success(`File created: ${filePath}`);

      return {
        success: true,
        path: filePath,
        size: content.length
      };
    } catch (error) {
      logger.error(`Failed to create file: ${filePath}`, error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  async readFile(filePath) {
    try {
      const content = await fs.readFile(filePath, 'utf-8');
      logger.success(`File read: ${filePath}`);

      return {
        success: true,
        content,
        size: content.length
      };
    } catch (error) {
      logger.error(`Failed to read file: ${filePath}`, error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  async deleteFile(filePath) {
    try {
      await fs.unlink(filePath);
      logger.success(`File deleted: ${filePath}`);

      return {
        success: true,
        path: filePath
      };
    } catch (error) {
      logger.error(`Failed to delete file: ${filePath}`, error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  async fileExists(filePath) {
    try {
      await fs.access(filePath);
      return true;
    } catch {
      return false;
    }
  }

  async listDirectory(dirPath) {
    try {
      const entries = await fs.readdir(dirPath, { withFileTypes: true });
      
      const items = entries.map(entry => ({
        name: entry.name,
        type: entry.isDirectory() ? 'directory' : 'file',
        path: path.join(dirPath, entry.name)
      }));

      return {
        success: true,
        items
      };
    } catch (error) {
      logger.error(`Failed to list directory: ${dirPath}`, error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Package management
   */
  async installPackage(packageName, options = {}) {
    const manager = options.manager || 'npm';
    const global = options.global ? '-g' : '';
    
    let command;
    switch (manager) {
      case 'npm':
        command = `npm install ${global} ${packageName}`;
        break;
      case 'yarn':
        command = `yarn add ${packageName}`;
        break;
      case 'pnpm':
        command = `pnpm add ${packageName}`;
        break;
      case 'apt':
        command = `sudo apt-get install -y ${packageName}`;
        break;
      case 'pip':
        command = `pip install ${packageName}`;
        break;
      default:
        throw new Error(`Unknown package manager: ${manager}`);
    }

    return await this.executeCommand(command);
  }

  /**
   * Process management
   */
  async startProcess(command, background = false) {
    if (background) {
      command = `nohup ${command} > /dev/null 2>&1 &`;
    }
    return await this.executeCommand(command);
  }

  async killProcess(pid) {
    return await this.executeCommand(`kill ${pid}`);
  }

  async listProcesses(pattern = null) {
    const cmd = pattern ? `ps aux | grep "${pattern}"` : 'ps aux';
    return await this.executeCommand(cmd);
  }

  /**
   * Git operations
   */
  async gitClone(repoUrl, targetDir = null) {
    const cmd = targetDir 
      ? `git clone ${repoUrl} ${targetDir}`
      : `git clone ${repoUrl}`;
    return await this.executeCommand(cmd);
  }

  async gitPull(repoPath) {
    return await this.executeCommand('git pull', { cwd: repoPath });
  }

  /**
   * System information
   */
  async getSystemInfo() {
    const commands = {
      os: 'uname -a',
      memory: 'free -h',
      disk: 'df -h',
      cpu: 'lscpu | head -n 20',
      uptime: 'uptime'
    };

    const info = {};
    for (const [key, cmd] of Object.entries(commands)) {
      const result = await this.executeCommand(cmd);
      info[key] = result.success ? result.stdout : result.error;
    }

    return info;
  }

  /**
   * Get execution history
   */
  getHistory(limit = 10) {
    return this.executionHistory.slice(-limit);
  }

  /**
   * Clear execution history
   */
  clearHistory() {
    this.executionHistory = [];
  }
}

export default new Executor();
