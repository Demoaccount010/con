import fs from 'fs/promises';
import path from 'path';
import config from '../config/config.js';
import logger from '../utils/logger.js';

class MemorySystem {
  constructor() {
    this.memoryDir = config.MEMORY_DIR;
    this.owner = null;
    this.learning = [];
    this.tools = [];
    this.goals = [];
    this.initialized = false;
  }

  async initialize() {
    try {
      // Ensure memory directory exists
      await fs.mkdir(this.memoryDir, { recursive: true });
      await fs.mkdir(config.LOGS_DIR, { recursive: true });
      
      // Load existing memory
      await this.loadOwner();
      await this.loadLearning();
      await this.loadTools();
      await this.loadGoals();
      
      this.initialized = true;
      logger.success('Memory system initialized');
      return true;
    } catch (error) {
      logger.error('Failed to initialize memory system', error);
      return false;
    }
  }

  // Owner Management
  async loadOwner() {
    const ownerPath = path.join(this.memoryDir, 'owner.json');
    try {
      const data = await fs.readFile(ownerPath, 'utf-8');
      this.owner = JSON.parse(data);
      logger.info(`Owner loaded: ${this.owner.name}`);
    } catch (error) {
      this.owner = null;
      logger.info('No owner profile found');
    }
  }

  async saveOwner(ownerData) {
    const ownerPath = path.join(this.memoryDir, 'owner.json');
    this.owner = {
      ...ownerData,
      createdAt: new Date().toISOString(),
      lastSeen: new Date().toISOString()
    };
    await fs.writeFile(ownerPath, JSON.stringify(this.owner, null, 2));
    logger.success(`Owner profile saved: ${this.owner.name}`);
  }

  async updateLastSeen() {
    if (this.owner) {
      this.owner.lastSeen = new Date().toISOString();
      const ownerPath = path.join(this.memoryDir, 'owner.json');
      await fs.writeFile(ownerPath, JSON.stringify(this.owner, null, 2));
    }
  }

  getOwner() {
    return this.owner;
  }

  // Learning History
  async loadLearning() {
    const learningPath = path.join(this.memoryDir, 'learning.json');
    try {
      const data = await fs.readFile(learningPath, 'utf-8');
      this.learning = JSON.parse(data);
      logger.info(`Loaded ${this.learning.length} learning entries`);
    } catch (error) {
      this.learning = [];
    }
  }

  async addLearning(entry) {
    this.learning.push({
      ...entry,
      timestamp: new Date().toISOString()
    });
    
    // Keep only last 1000 entries
    if (this.learning.length > 1000) {
      this.learning = this.learning.slice(-1000);
    }
    
    if (config.AUTO_SAVE_MEMORY) {
      await this.saveLearning();
    }
  }

  async saveLearning() {
    const learningPath = path.join(this.memoryDir, 'learning.json');
    await fs.writeFile(learningPath, JSON.stringify(this.learning, null, 2));
  }

  getLearning(limit = 10) {
    return this.learning.slice(-limit);
  }

  // Tools/Plugins Registry
  async loadTools() {
    const toolsPath = path.join(this.memoryDir, 'tools.json');
    try {
      const data = await fs.readFile(toolsPath, 'utf-8');
      this.tools = JSON.parse(data);
      logger.info(`Loaded ${this.tools.length} tools`);
    } catch (error) {
      this.tools = [];
    }
  }

  async registerTool(tool) {
    const existing = this.tools.findIndex(t => t.name === tool.name);
    
    if (existing >= 0) {
      this.tools[existing] = {
        ...tool,
        updatedAt: new Date().toISOString()
      };
    } else {
      this.tools.push({
        ...tool,
        createdAt: new Date().toISOString()
      });
    }
    
    await this.saveTools();
    logger.success(`Tool registered: ${tool.name}`);
  }

  async saveTools() {
    const toolsPath = path.join(this.memoryDir, 'tools.json');
    await fs.writeFile(toolsPath, JSON.stringify(this.tools, null, 2));
  }

  getTools() {
    return this.tools;
  }

  hasTool(name) {
    return this.tools.some(t => t.name === name);
  }

  // Goals Management
  async loadGoals() {
    const goalsPath = path.join(this.memoryDir, 'goals.json');
    try {
      const data = await fs.readFile(goalsPath, 'utf-8');
      this.goals = JSON.parse(data);
      logger.info(`Loaded ${this.goals.length} goals`);
    } catch (error) {
      this.goals = [];
    }
  }

  async addGoal(goal) {
    this.goals.push({
      ...goal,
      id: Date.now(),
      status: 'pending',
      createdAt: new Date().toISOString()
    });
    await this.saveGoals();
  }

  async updateGoalStatus(goalId, status, result = null) {
    const goal = this.goals.find(g => g.id === goalId);
    if (goal) {
      goal.status = status;
      goal.result = result;
      goal.completedAt = new Date().toISOString();
      await this.saveGoals();
    }
  }

  async saveGoals() {
    const goalsPath = path.join(this.memoryDir, 'goals.json');
    await fs.writeFile(goalsPath, JSON.stringify(this.goals, null, 2));
  }

  getActiveGoals() {
    return this.goals.filter(g => g.status === 'pending' || g.status === 'in_progress');
  }

  // Conversation History (for AI context)
  conversationHistory = [];

  addToHistory(role, content) {
    this.conversationHistory.push({ role, content });
    
    // Keep only last 20 messages
    if (this.conversationHistory.length > 20) {
      this.conversationHistory = this.conversationHistory.slice(-20);
    }
  }

  getHistory() {
    return this.conversationHistory;
  }

  clearHistory() {
    this.conversationHistory = [];
  }

  // Get context for AI
  getContext() {
    return {
      owner: this.owner,
      recentLearning: this.getLearning(5),
      tools: this.tools,
      activeGoals: this.getActiveGoals()
    };
  }
}

export default new MemorySystem();
