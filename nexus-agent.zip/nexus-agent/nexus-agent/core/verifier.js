import executor from './executor.js';
import logger from '../utils/logger.js';

class Verifier {
  /**
   * Verify that a file exists and optionally check its content
   */
  async verifyFileCreated(filePath, expectedContent = null) {
    try {
      const exists = await executor.fileExists(filePath);
      
      if (!exists) {
        logger.error(`Verification failed: File does not exist at ${filePath}`);
        return {
          verified: false,
          reason: 'File not found'
        };
      }

      logger.success(`Verified: File exists at ${filePath}`);

      if (expectedContent) {
        const result = await executor.readFile(filePath);
        if (!result.success) {
          return {
            verified: false,
            reason: 'Could not read file'
          };
        }

        const contentMatch = result.content.includes(expectedContent);
        if (!contentMatch) {
          logger.warn('File content does not match expected content');
          return {
            verified: true,
            warning: 'Content mismatch',
            exists: true,
            contentMatches: false
          };
        }

        logger.success('File content verified');
        return {
          verified: true,
          exists: true,
          contentMatches: true
        };
      }

      return {
        verified: true,
        exists: true
      };

    } catch (error) {
      logger.error('Verification error', error);
      return {
        verified: false,
        reason: error.message
      };
    }
  }

  /**
   * Verify command execution by checking its output
   */
  async verifyCommandExecution(commandResult, expectedPattern = null) {
    if (!commandResult) {
      return {
        verified: false,
        reason: 'No command result provided'
      };
    }

    if (!commandResult.success) {
      logger.error('Command execution failed', commandResult.error);
      return {
        verified: false,
        reason: commandResult.error || 'Command failed'
      };
    }

    if (expectedPattern) {
      const output = commandResult.stdout + commandResult.stderr;
      const regex = new RegExp(expectedPattern);
      
      if (!regex.test(output)) {
        logger.warn(`Expected pattern "${expectedPattern}" not found in output`);
        return {
          verified: true,
          warning: 'Expected pattern not found',
          executionSuccess: true,
          patternMatch: false
        };
      }

      logger.success('Command output verified with expected pattern');
      return {
        verified: true,
        executionSuccess: true,
        patternMatch: true
      };
    }

    logger.success('Command execution verified');
    return {
      verified: true,
      executionSuccess: true
    };
  }

  /**
   * Verify a process is running
   */
  async verifyProcessRunning(processName) {
    const result = await executor.listProcesses(processName);
    
    if (!result.success) {
      return {
        verified: false,
        reason: 'Could not check processes'
      };
    }

    const lines = result.stdout.split('\n').filter(line => 
      line.includes(processName) && !line.includes('grep')
    );

    if (lines.length === 0) {
      logger.warn(`Process ${processName} not found running`);
      return {
        verified: false,
        reason: 'Process not running',
        running: false
      };
    }

    logger.success(`Process ${processName} verified running`);
    return {
      verified: true,
      running: true,
      processCount: lines.length
    };
  }

  /**
   * Verify package installation
   */
  async verifyPackageInstalled(packageName, manager = 'npm') {
    let command;
    
    switch (manager) {
      case 'npm':
        command = `npm list ${packageName}`;
        break;
      case 'pip':
        command = `pip show ${packageName}`;
        break;
      case 'apt':
        command = `dpkg -l | grep ${packageName}`;
        break;
      default:
        command = `which ${packageName}`;
    }

    const result = await executor.executeCommand(command);
    
    if (result.success && result.stdout.includes(packageName)) {
      logger.success(`Package ${packageName} verified installed`);
      return {
        verified: true,
        installed: true
      };
    }

    logger.warn(`Package ${packageName} not found`);
    return {
      verified: false,
      installed: false,
      reason: 'Package not found'
    };
  }

  /**
   * Verify directory exists and optionally check if it contains files
   */
  async verifyDirectoryCreated(dirPath, shouldHaveFiles = false) {
    try {
      const exists = await executor.fileExists(dirPath);
      
      if (!exists) {
        logger.error(`Directory does not exist: ${dirPath}`);
        return {
          verified: false,
          reason: 'Directory not found'
        };
      }

      if (shouldHaveFiles) {
        const listResult = await executor.listDirectory(dirPath);
        
        if (!listResult.success || listResult.items.length === 0) {
          logger.warn('Directory exists but is empty');
          return {
            verified: true,
            warning: 'Directory is empty',
            exists: true,
            hasFiles: false
          };
        }

        logger.success(`Directory verified with ${listResult.items.length} items`);
        return {
          verified: true,
          exists: true,
          hasFiles: true,
          itemCount: listResult.items.length
        };
      }

      logger.success(`Directory verified: ${dirPath}`);
      return {
        verified: true,
        exists: true
      };

    } catch (error) {
      logger.error('Directory verification error', error);
      return {
        verified: false,
        reason: error.message
      };
    }
  }

  /**
   * Verify plugin was created and can be loaded
   */
  async verifyPlugin(pluginPath) {
    // Check file exists
    const fileCheck = await this.verifyFileCreated(pluginPath);
    if (!fileCheck.verified) {
      return {
        verified: false,
        reason: 'Plugin file not found'
      };
    }

    // Try to load the plugin
    try {
      const pluginModule = await import(pluginPath);
      
      if (!pluginModule.default && !pluginModule.init) {
        logger.warn('Plugin has no default export or init function');
        return {
          verified: true,
          warning: 'Plugin may not be properly structured',
          exists: true,
          canLoad: true,
          hasInit: false
        };
      }

      logger.success('Plugin verified and can be loaded');
      return {
        verified: true,
        exists: true,
        canLoad: true,
        hasInit: true
      };

    } catch (error) {
      logger.error('Plugin load error', error);
      return {
        verified: false,
        reason: `Plugin cannot be loaded: ${error.message}`,
        exists: true,
        canLoad: false
      };
    }
  }

  /**
   * Comprehensive verification report
   */
  async generateVerificationReport(verifications) {
    const report = {
      timestamp: new Date().toISOString(),
      totalChecks: verifications.length,
      passed: 0,
      failed: 0,
      warnings: 0,
      details: []
    };

    for (const check of verifications) {
      if (check.verified) {
        report.passed++;
        if (check.warning) {
          report.warnings++;
        }
      } else {
        report.failed++;
      }
      report.details.push(check);
    }

    report.successRate = (report.passed / report.totalChecks * 100).toFixed(2) + '%';

    logger.info('Verification Report', {
      passed: report.passed,
      failed: report.failed,
      warnings: report.warnings,
      successRate: report.successRate
    });

    return report;
  }

  /**
   * Quick verification helpers
   */
  async quickVerify(type, target, options = {}) {
    switch (type) {
      case 'file':
        return await this.verifyFileCreated(target, options.content);
      
      case 'directory':
        return await this.verifyDirectoryCreated(target, options.shouldHaveFiles);
      
      case 'process':
        return await this.verifyProcessRunning(target);
      
      case 'package':
        return await this.verifyPackageInstalled(target, options.manager);
      
      case 'plugin':
        return await this.verifyPlugin(target);
      
      case 'command':
        return await this.verifyCommandExecution(target, options.pattern);
      
      default:
        logger.error(`Unknown verification type: ${type}`);
        return {
          verified: false,
          reason: 'Unknown verification type'
        };
    }
  }
}

export default new Verifier();
