export default {
  // Cloudflare AI Worker API
  AI_API_URL: 'https://smile-ai.animeplaysindia07.workers.dev/',
  AI_API_KEY: process.env.AI_API_KEY || '',
  
  // System settings
  REQUIRE_APPROVAL: true,
  AUTO_SAVE_MEMORY: true,
  LOG_LEVEL: 'info', // 'debug' | 'info' | 'warn' | 'error'
  
  // Paths
  PLUGINS_DIR: './plugins',
  MEMORY_DIR: './memory',
  LOGS_DIR: './memory/logs',
  
  // Evolution settings
  AUTO_CREATE_PLUGINS: true,
  MAX_RETRIES: 3,
  
  // Safety limits
  MAX_COMMAND_LENGTH: 1000,
  DANGEROUS_COMMANDS: [
    'rm -rf /',
    'dd if=/dev/zero',
    'chmod -R 777 /',
    'mkfs',
    ':(){ :|:& };:' // fork bomb
  ]
};
