#!/usr/bin/env node

/**
 * NEXUS System Test
 * Verifies all components are working correctly
 */

import chalk from 'chalk';

console.log(chalk.cyan('\n=== NEXUS System Test ===\n'));

const tests = [];
let passed = 0;
let failed = 0;

async function test(name, fn) {
  try {
    process.stdout.write(`Testing ${name}... `);
    await fn();
    console.log(chalk.green('✓ PASS'));
    passed++;
    tests.push({ name, status: 'pass' });
  } catch (error) {
    console.log(chalk.red('✗ FAIL'));
    console.log(chalk.red(`  Error: ${error.message}`));
    failed++;
    tests.push({ name, status: 'fail', error: error.message });
  }
}

async function runTests() {
  // Test 1: Check Node.js version
  await test('Node.js version', async () => {
    const version = process.version.slice(1).split('.')[0];
    if (parseInt(version) < 18) {
      throw new Error(`Node.js 18+ required, found ${process.version}`);
    }
  });

  // Test 2: Check required modules
  await test('Required modules', async () => {
    const modules = ['axios', 'chalk', 'inquirer'];
    for (const mod of modules) {
      await import(mod);
    }
  });

  // Test 3: Check config file
  await test('Configuration file', async () => {
    const config = await import('./config/config.js');
    if (!config.default) {
      throw new Error('Config export not found');
    }
  });

  // Test 4: Check core modules
  await test('Core modules', async () => {
    const modules = [
      './core/memory.js',
      './core/thinking.js',
      './core/executor.js',
      './core/verifier.js',
      './core/evolution.js',
      './core/plugin_loader.js',
      './core/brain.js'
    ];
    
    for (const mod of modules) {
      const module = await import(mod);
      if (!module.default) {
        throw new Error(`${mod} has no default export`);
      }
    }
  });

  // Test 5: Check utilities
  await test('Logger utility', async () => {
    const logger = await import('./utils/logger.js');
    if (!logger.default) {
      throw new Error('Logger not exported');
    }
    if (typeof logger.default.info !== 'function') {
      throw new Error('Logger.info is not a function');
    }
  });

  // Test 6: Check directories
  await test('Directory structure', async () => {
    const fs = await import('fs/promises');
    const dirs = ['./plugins', './memory', './config', './core', './utils'];
    
    for (const dir of dirs) {
      await fs.access(dir);
    }
  });

  // Test 7: Check API configuration
  await test('API configuration', async () => {
    const config = await import('./config/config.js');
    if (!config.default.AI_API_URL) {
      throw new Error('AI_API_URL not configured');
    }
    
    // Warn but don't fail if API key is missing
    if (!config.default.AI_API_KEY && !process.env.AI_API_KEY) {
      console.log(chalk.yellow('\n  Warning: AI_API_KEY not set'));
    }
  });

  // Test 8: Memory system initialization
  await test('Memory system', async () => {
    const memory = await import('./core/memory.js');
    const initialized = await memory.default.initialize();
    if (!initialized) {
      throw new Error('Memory initialization failed');
    }
  });

  // Test 9: Plugin loader initialization
  await test('Plugin loader', async () => {
    const pluginLoader = await import('./core/plugin_loader.js');
    const initialized = await pluginLoader.default.initialize();
    if (!initialized) {
      throw new Error('Plugin loader initialization failed');
    }
  });

  // Test 10: Executor basic function
  await test('Executor basic operation', async () => {
    const executor = await import('./core/executor.js');
    const result = await executor.default.executeCommand('echo "test"');
    if (!result.success || !result.stdout.includes('test')) {
      throw new Error('Executor test failed');
    }
  });

  // Results
  console.log('\n' + '='.repeat(50));
  console.log(chalk.cyan('Test Results:'));
  console.log('='.repeat(50));
  console.log(chalk.green(`Passed: ${passed}`));
  if (failed > 0) {
    console.log(chalk.red(`Failed: ${failed}`));
  }
  console.log('='.repeat(50));

  // Summary
  if (failed === 0) {
    console.log(chalk.green('\n✓ All tests passed! NEXUS is ready to run.\n'));
    console.log(chalk.cyan('Next steps:'));
    console.log('  1. Set your API key: export AI_API_KEY="your-key"');
    console.log('  2. Start NEXUS: npm start\n');
    process.exit(0);
  } else {
    console.log(chalk.red('\n✗ Some tests failed. Please fix the issues above.\n'));
    process.exit(1);
  }
}

// Run tests
runTests().catch(error => {
  console.error(chalk.red('\nFatal error during testing:'), error);
  process.exit(1);
});
