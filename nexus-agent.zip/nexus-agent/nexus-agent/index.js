#!/usr/bin/env node

import inquirer from 'inquirer';
import chalk from 'chalk';
import brain from './core/brain.js';
import logger from './utils/logger.js';
import config from './config/config.js';

/**
 * NEXUS - Self-Evolving Autonomous AI Agent
 * 
 * A fully autonomous agent system with:
 * - Real system execution capabilities
 * - Self-evolution and plugin creation
 * - Persistent memory and learning
 * - Owner permission system
 * - Reality verification
 */

async function displayBanner() {
  console.clear();
  console.log(chalk.cyan(`
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║   ███╗   ██╗███████╗██╗  ██╗██╗   ██╗███████╗           ║
║   ████╗  ██║██╔════╝╚██╗██╔╝██║   ██║██╔════╝           ║
║   ██╔██╗ ██║█████╗   ╚███╔╝ ██║   ██║███████╗           ║
║   ██║╚██╗██║██╔══╝   ██╔██╗ ██║   ██║╚════██║           ║
║   ██║ ╚████║███████╗██╔╝ ██╗╚██████╔╝███████║           ║
║   ╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝           ║
║                                                           ║
║          Self-Evolving Autonomous AI Agent                ║
║                    Version 1.0.0                          ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
  `));
}

async function checkConfiguration() {
  if (!config.AI_API_KEY) {
    logger.error('AI_API_KEY not configured!');
    console.log(chalk.yellow('\nPlease set your API key:'));
    console.log(chalk.gray('  export AI_API_KEY="your-api-key-here"'));
    console.log(chalk.gray('  Or create a .env file with: AI_API_KEY=your-api-key-here\n'));
    return false;
  }
  return true;
}

async function mainMenu() {
  const choices = [
    { name: '💬 Start Conversation Mode', value: 'converse' },
    { name: '🎯 Process a Specific Task', value: 'task' },
    { name: '⚡ Quick Command Execution', value: 'quick' },
    { name: '📊 View System Status', value: 'status' },
    { name: '🔧 List Capabilities', value: 'capabilities' },
    { name: '📚 View Evolution History', value: 'evolution' },
    { name: '🚪 Exit', value: 'exit' }
  ];

  const answer = await inquirer.prompt([
    {
      type: 'list',
      name: 'action',
      message: 'What would you like to do?',
      choices
    }
  ]);

  return answer.action;
}

async function main() {
  try {
    await displayBanner();

    // Check configuration
    const configured = await checkConfiguration();
    if (!configured) {
      process.exit(1);
    }

    // Initialize the brain
    logger.system('Starting NEXUS...');
    const initialized = await brain.initialize();

    if (!initialized) {
      logger.error('Failed to initialize NEXUS');
      process.exit(1);
    }

    // Main loop
    while (true) {
      const action = await mainMenu();

      switch (action) {
        case 'converse':
          await brain.converse();
          break;

        case 'task':
          const taskAnswer = await inquirer.prompt([
            {
              type: 'input',
              name: 'task',
              message: 'Describe the task:',
              validate: (input) => input.trim().length > 0 || 'Task cannot be empty'
            }
          ]);
          await brain.processTask(taskAnswer.task);
          break;

        case 'quick':
          const cmdAnswer = await inquirer.prompt([
            {
              type: 'input',
              name: 'command',
              message: 'Enter command:',
              validate: (input) => input.trim().length > 0 || 'Command cannot be empty'
            }
          ]);
          await brain.quickExecute(cmdAnswer.command);
          break;

        case 'status':
          await brain.displayStatus();
          break;

        case 'capabilities':
          await brain.listCapabilities();
          break;

        case 'evolution':
          const { default: evolution } = await import('./core/evolution.js');
          const stats = evolution.getStats();
          const history = evolution.getEvolutionHistory(10);
          
          console.log('\n' + chalk.cyan('Evolution Statistics:'));
          console.log(chalk.gray(JSON.stringify(stats, null, 2)));
          
          console.log('\n' + chalk.cyan('Recent Evolution History:'));
          history.forEach((event, i) => {
            console.log(chalk.gray(`${i + 1}. ${event.type} - ${event.timestamp}`));
            if (event.pluginName) {
              console.log(chalk.gray(`   Plugin: ${event.pluginName}`));
            }
          });
          console.log('');
          break;

        case 'exit':
          logger.system('Shutting down NEXUS...');
          console.log(chalk.green('\nGoodbye! 👋\n'));
          process.exit(0);
      }
    }

  } catch (error) {
    logger.error('Fatal error', error);
    process.exit(1);
  }
}

// Handle graceful shutdown
process.on('SIGINT', () => {
  console.log(chalk.yellow('\n\nReceived SIGINT, shutting down gracefully...'));
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log(chalk.yellow('\n\nReceived SIGTERM, shutting down gracefully...'));
  process.exit(0);
});

// Start the application
main();
