# 🚀 NEXUS Quick Start Guide

## Installation (2 minutes)

```bash
cd nexus-agent

# Install dependencies
npm install

# Set your API key
export AI_API_KEY="your-cloudflare-worker-api-key"

# Or create .env file
echo "AI_API_KEY=your-api-key" > .env

# Run tests
npm test

# Start NEXUS
npm start
```

## First Use

1. **Owner Setup** - On first run, NEXUS will ask for your name and preferences
2. **Choose Mode** - Select from the menu:
   - 💬 Conversation Mode - Chat naturally
   - 🎯 Task Processing - Complete complex tasks
   - ⚡ Quick Execution - Run single commands

## Example Tasks

```
> Create a Python script to process CSV files
> Install the 'requests' package
> Show me system information
> Create a directory called 'projects'
> Monitor system resources
```

## Key Features

### ✅ Real Execution
NEXUS actually executes commands - no pretending!

### 🔒 Permission System
You approve every action before execution.

### 🧬 Self-Evolution
NEXUS creates new plugins when it lacks capabilities.

### 📝 Verification
Everything is verified before claiming success.

### 💾 Memory
NEXUS remembers you, your preferences, and learned lessons.

## Safety

- Review execution plans before approval
- Dangerous commands are automatically blocked
- All actions are logged
- Reality verification on every execution

## Troubleshooting

**API Key Error?**
```bash
export AI_API_KEY="your-key"
# Or add to .env file
```

**Module Not Found?**
```bash
npm install
```

**Permission Denied?**
```bash
chmod +x index.js setup.sh test.js
```

## Advanced

**Run in Background (PM2):**
```bash
npm install -g pm2
pm2 start index.js --name nexus
pm2 logs nexus
```

**View Logs:**
```bash
tail -f memory/logs/$(date +%Y-%m-%d).log
```

**Create Custom Plugin:**
```javascript
// plugins/my-plugin.js
export default {
  name: 'my-plugin',
  description: 'Does something cool',
  
  async myMethod() {
    return { success: true };
  }
};
```

## File Structure

```
nexus-agent/
├── core/          # Core engine modules
├── plugins/       # Auto-generated plugins
├── memory/        # Persistent storage
├── config/        # Configuration
├── utils/         # Utilities
└── index.js       # Entry point
```

## Need Help?

1. Check `memory/logs/` for detailed execution traces
2. Run `npm test` to verify system integrity
3. Review README.md for full documentation
4. Check DEPLOYMENT.md for VPS setup

---

**You're ready to go! 🎉**

Start NEXUS with: `npm start`
