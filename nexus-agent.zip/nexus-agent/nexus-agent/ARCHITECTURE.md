# NEXUS System Architecture

## System Overview

```
┌─────────────────────────────────────────────────────────────┐
│                        USER INTERFACE                        │
│                    (CLI + Inquirer Prompts)                  │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                        META BRAIN                            │
│  • High-level decision making                               │
│  • Task orchestration                                        │
│  • Workflow management                                       │
│  • Approval system                                           │
└─┬───────────┬──────────┬──────────┬──────────┬──────────────┘
  │           │          │          │          │
  ▼           ▼          ▼          ▼          ▼
┌───────┐ ┌────────┐ ┌─────────┐ ┌────────┐ ┌──────────┐
│THINKING│ │EXECUTOR│ │VERIFIER │ │EVOLUTION│ │PLUGIN    │
│ENGINE  │ │        │ │         │ │        │ │LOADER    │
└───┬───┘ └────┬───┘ └────┬────┘ └───┬────┘ └─────┬────┘
    │          │          │           │            │
    ▼          ▼          ▼           ▼            ▼
┌─────────────────────────────────────────────────────────────┐
│                     SHARED MEMORY SYSTEM                     │
│  • Owner Profile                                             │
│  • Learning History                                          │
│  • Tool Registry                                             │
│  • Execution Logs                                            │
│  • Conversation History                                      │
└─────────────────────────────────────────────────────────────┘
```

## Core Components

### 1. Meta Brain (`core/brain.js`)
**Purpose:** Central orchestrator and decision maker

**Responsibilities:**
- Initialize all subsystems
- Process user tasks
- Coordinate between components
- Manage approval workflow
- Parse and execute plans
- Handle conversation mode

**Key Methods:**
- `initialize()` - Bootstrap the system
- `processTask(task)` - Complete task workflow
- `requestApproval(plan)` - Get user permission
- `executePlan(plan)` - Run execution steps
- `converse()` - Interactive chat mode

### 2. Thinking Engine (`core/thinking.js`)
**Purpose:** AI-powered reasoning via Cloudflare Worker API

**Responsibilities:**
- Make API calls to Cloudflare Worker
- Build context-aware system prompts
- Maintain conversation history
- Provide specialized thinking modes

**Key Methods:**
- `think(prompt, systemPrompt, useHistory)` - Main AI call
- `analyzeTask(task)` - Break down tasks
- `designPlugin(capability)` - Create plugin designs
- `evaluateResult(action, result)` - Learn from execution
- `solveError(error, context)` - Debug problems

**API Integration:**
```javascript
POST https://smile-ai.animeplaysindia07.workers.dev/
Headers: Authorization: Bearer <API_KEY>
Body: {
  prompt: "...",
  systemPrompt: "...",
  history: [...]
}
Response: { response: "..." }
```

### 3. Executor (`core/executor.js`)
**Purpose:** Real system command execution

**Responsibilities:**
- Execute bash/shell commands
- File operations (CRUD)
- Package management
- Process management
- Git operations
- System information gathering

**Safety Features:**
- Command blacklist check
- Length limits
- Timeout protection
- Error handling

**Key Methods:**
- `executeCommand(command, options)` - Run single command
- `executeSequence(commands)` - Run multiple commands
- `createFile(path, content)` - File creation
- `installPackage(name, options)` - Package installation
- `getSystemInfo()` - System metrics

### 4. Verifier (`core/verifier.js`)
**Purpose:** Reality verification layer

**Responsibilities:**
- Verify file creation
- Verify command execution
- Verify process status
- Verify package installation
- Generate verification reports

**Key Methods:**
- `verifyFileCreated(path, expectedContent)` - File verification
- `verifyCommandExecution(result, pattern)` - Command verification
- `verifyProcessRunning(processName)` - Process verification
- `verifyPackageInstalled(package, manager)` - Package verification
- `generateVerificationReport(verifications)` - Comprehensive report

**Verification Flow:**
```
Action → Execute → Verify → Report
         ↓         ↓        ↓
       Success?  Check?   Log?
```

### 5. Evolution Engine (`core/evolution.js`)
**Purpose:** Self-improvement and capability expansion

**Responsibilities:**
- Detect missing capabilities
- Design new plugins
- Create plugin code
- Register new tools
- Learn from execution

**Evolution Cycle:**
```
Task → Detect Gap → Design Plugin → Create → Test → Activate
                                      ↓
                              Record Learning
```

**Key Methods:**
- `detectMissingCapability(task)` - Analyze requirements
- `createCapabilityPlugin(capability)` - Generate plugin
- `parsePluginDesign(design)` - Extract plugin structure
- `learnFromExecution(action, result)` - Store lessons
- `evolve(task)` - Complete evolution cycle

### 6. Plugin Loader (`core/plugin_loader.js`)
**Purpose:** Dynamic plugin management

**Responsibilities:**
- Load plugins from directory
- Validate plugin structure
- Execute plugin methods
- Hot-reload capabilities
- Plugin lifecycle management

**Plugin Structure:**
```javascript
export default {
  name: 'plugin-name',
  description: 'What it does',
  version: '1.0.0',
  
  async init() { },
  async method1() { },
  async method2() { }
}
```

**Key Methods:**
- `initialize()` - Setup plugin system
- `loadPlugin(filename)` - Load single plugin
- `createPlugin(name, code)` - Generate new plugin
- `executePluginMethod(plugin, method, args)` - Run plugin function
- `listPlugins()` - Get all available plugins

### 7. Memory System (`core/memory.js`)
**Purpose:** Persistent storage and learning

**Responsibilities:**
- Owner profile management
- Learning history storage
- Tool registry maintenance
- Goal tracking
- Conversation history

**Data Structures:**

**Owner Profile:**
```json
{
  "name": "John",
  "relationship": "partner",
  "preferences": "...",
  "createdAt": "2024-01-15T10:30:00Z",
  "lastSeen": "2024-01-15T15:45:00Z"
}
```

**Learning Entry:**
```json
{
  "action": "...",
  "result": "success|failure",
  "lesson": "...",
  "timestamp": "..."
}
```

**Tool Registry:**
```json
{
  "name": "plugin-name",
  "description": "...",
  "filename": "...",
  "methods": ["method1", "method2"],
  "createdAt": "..."
}
```

## Data Flow

### Task Processing Flow

```
1. User Input
   ↓
2. Meta Brain receives task
   ↓
3. Thinking Engine analyzes
   ↓
4. Evolution checks capabilities
   ├─ Has capability → Continue
   └─ Missing → Create plugin → Retry
   ↓
5. Generate execution plan
   ↓
6. Request approval
   ├─ Approved → Continue
   └─ Rejected → Cancel
   ↓
7. Execute steps
   ├─ Run command (Executor)
   ├─ Verify result (Verifier)
   └─ Record in Memory
   ↓
8. Learn from execution (Evolution)
   ↓
9. Report to user
```

### Evolution Flow

```
Task → Missing Capability Detected
         ↓
    Thinking Engine designs plugin
         ↓
    Evolution Engine parses design
         ↓
    Plugin Loader generates code
         ↓
    Save to plugins/ directory
         ↓
    Verify file creation
         ↓
    Load plugin dynamically
         ↓
    Register in Memory
         ↓
    Retry original task
```

## File System

```
nexus-agent/
├── core/
│   ├── brain.js           (Meta orchestrator)
│   ├── thinking.js        (AI reasoning)
│   ├── executor.js        (System execution)
│   ├── verifier.js        (Reality checks)
│   ├── evolution.js       (Self-improvement)
│   ├── plugin_loader.js   (Plugin management)
│   └── memory.js          (Persistence)
│
├── plugins/               (Auto-generated)
│   ├── .gitkeep
│   └── [plugin-name].js
│
├── memory/                (Persistent data)
│   ├── owner.json
│   ├── learning.json
│   ├── tools.json
│   └── logs/
│       └── YYYY-MM-DD.log
│
├── config/
│   └── config.js          (System settings)
│
├── utils/
│   └── logger.js          (Logging system)
│
├── index.js               (Entry point)
├── test.js                (System tests)
└── setup.sh               (Installation)
```

## Security Model

### Permission Layers

1. **Command Blacklist**
   - Dangerous commands blocked
   - Length limits enforced
   - Pattern matching

2. **Approval System**
   - User must approve all actions
   - Clear plan presentation
   - Cancel capability

3. **Verification Layer**
   - Post-execution checks
   - No false claims
   - Reality verification

4. **Logging**
   - All actions logged
   - Audit trail
   - Error tracking

## Scalability

### Horizontal Scaling
- Multiple NEXUS instances per user
- Shared memory optional
- Independent evolution

### Vertical Scaling
- Node.js cluster mode
- Increased memory limits
- Process pooling

## Extension Points

### Adding New Capabilities

1. **Create Plugin:**
   ```javascript
   // plugins/new-capability.js
   export default {
     name: 'new-capability',
     description: 'New functionality',
     async execute() { }
   }
   ```

2. **Or Let NEXUS Create It:**
   - Request task requiring new capability
   - NEXUS detects gap
   - Auto-generates plugin

### Custom Verification

```javascript
// Add to verifier.js
async verifyCustomCondition(params) {
  // Custom verification logic
  return { verified: true/false }
}
```

### External API Integration

```javascript
// New plugin
async callExternalAPI(endpoint) {
  const response = await axios.post(endpoint, data);
  return response.data;
}
```

## Performance Characteristics

- **Initialization:** ~1-2 seconds
- **Task Analysis:** ~2-5 seconds (AI call)
- **Plugin Creation:** ~5-10 seconds (AI + write)
- **Command Execution:** Varies by command
- **Verification:** <1 second per check

## Monitoring

### Logs
- Stored in `memory/logs/`
- Daily log files
- JSON format for parsing

### Metrics
- Execution count
- Success/failure rate
- Plugin creation count
- Evolution statistics

---

**This architecture enables:**
✓ Real autonomous execution
✓ Self-evolution capabilities
✓ Safe operation with verification
✓ Persistent learning
✓ Extensible design
