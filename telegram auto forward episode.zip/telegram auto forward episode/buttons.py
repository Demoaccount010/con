SAFE_BUTTON_KEYWORDS = [
    "episode",
    "ep",
    "download",
    "get",
    "watch",
    "continue"
]

def find_safe_button(message):
    if not message.reply_markup:
        return None

    for row in message.reply_markup.inline_keyboard:
        for btn in row:
            text = (btn.text or "").lower()
            for key in SAFE_BUTTON_KEYWORDS:
                if key in text:
                    return btn
    return None
