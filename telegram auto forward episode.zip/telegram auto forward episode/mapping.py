import json
import os

ROUTES_FILE = "data/routes.json"

def load_routes():
    if not os.path.exists(ROUTES_FILE):
        return {}
    with open(ROUTES_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_routes(routes: dict):
    with open(ROUTES_FILE, "w", encoding="utf-8") as f:
        json.dump(routes, f, indent=4)

def add_route(source_id, destination, replace_from, replace_to):
    routes = load_routes()
    routes[str(source_id)] = {
        "destination": destination,
        "replace_from": replace_from,
        "replace_to": replace_to
    }
    save_routes(routes)

def remove_route(source_id):
    routes = load_routes()
    routes.pop(str(source_id), None)
    save_routes(routes)

def get_route(source_id):
    routes = load_routes()
    return routes.get(str(source_id))
