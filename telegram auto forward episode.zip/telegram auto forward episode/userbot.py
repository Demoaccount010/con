from pyrogram import Client, filters
from pyrogram.errors import FloodWait
from config import API_ID, API_HASH, SESSION_STRING, OWNER_ID, LOG_CHANNEL
from mapping import get_route, load_routes, add_route, remove_route
from episode_check import is_episode_post
from buttons import find_safe_button
import asyncio
import re

app = Client(
    session_name=SESSION_STRING,
    api_id=API_ID,
    api_hash=API_HASH
)

# ================= START =================
def start_userbot():
    app.start()

    app.send_message(
        OWNER_ID,
        "🔥 Guru ho ja shuru ho gaya!\nSession working perfectly ✅"
    )
    if LOG_CHANNEL:
        app.send_message(LOG_CHANNEL, "✅ Bot started successfully")

    app.idle()


# ================= OWNER CHECK =================
def is_owner(_, __, message):
    return message.from_user and message.from_user.id == OWNER_ID


# ================= FORCE-SUB HANDLER =================
async def handle_force_sub(client, message):
    if not message.reply_markup:
        return False

    for row in message.reply_markup.inline_keyboard:
        for btn in row:
            text = (btn.text or "").lower()

            if "join" in text:
                try:
                    await btn.click()
                    await asyncio.sleep(4)
                except:
                    pass

            if "try again" in text or "check" in text:
                try:
                    await btn.click()
                    await asyncio.sleep(3)
                except:
                    pass
    return True


# ================= WATCH SOURCE CHANNELS =================
@app.on_message(filters.channel)
async def watch_sources(client, message):
    route = get_route(message.chat.id)
    if not route:
        return

    if not is_episode_post(message):
        return

    btn = find_safe_button(message)
    if not btn:
        return

    await asyncio.sleep(3)
    try:
        await message.click(btn)
        if LOG_CHANNEL:
            await client.send_message(LOG_CHANNEL, "🔘 Episode button clicked")
    except Exception as e:
        if LOG_CHANNEL:
            await client.send_message(LOG_CHANNEL, f"❌ Button click failed: {e}")


# ================= BOT RESPONSES (FORCE-SUB / FILE) =================
@app.on_message(filters.private)
async def handle_bot_messages(client, message):
    # handle force-sub
    if message.reply_markup:
        await handle_force_sub(client, message)
        return

    # handle file / video
    if not (message.document or message.video):
        return

    # find last active route (simple & safe for your use-case)
    routes = load_routes()
    if not routes:
        return

    # last added source route
    route = list(routes.values())[-1]

    dest = route["destination"]
    old = route["replace_from"]
    new = route["replace_to"]

    caption = message.caption or ""
    if old:
        caption = caption.replace(old, new)

    try:
        await client.copy_message(
            chat_id=dest,
            from_chat_id=message.chat.id,
            message_id=message.id,
            caption=caption
        )

        if LOG_CHANNEL:
            await client.send_message(
                LOG_CHANNEL,
                f"📤 File forwarded to {dest}"
            )
    except FloodWait as e:
        await asyncio.sleep(e.value)
    except Exception as e:
        if LOG_CHANNEL:
            await client.send_message(
                LOG_CHANNEL,
                f"❌ Forward failed: {e}"
            )


# ================= COMMANDS =================

@app.on_message(filters.private & filters.command("addsource") & filters.create(is_owner))
async def add_source_handler(client, message):
    await message.reply("👉 Source channel ka **ID / @username** bhejo")
    src = (await client.listen(message.chat.id)).text.strip()

    src_chat = await client.get_chat(src)

    await message.reply("👉 Destination channel ka **ID / @username** bhejo")
    dest = (await client.listen(message.chat.id)).text.strip()

    await message.reply("👉 Caption me kaunsa **@ replace** karna hai?")
    rf = (await client.listen(message.chat.id)).text.strip()

    await message.reply("👉 Uski jagah kya lagana hai?")
    rt = (await client.listen(message.chat.id)).text.strip()

    add_route(src_chat.id, dest, rf, rt)

    await message.reply(
        f"🔥 **CONNECTED SUCCESSFULLY**\n\n"
        f"Source: `{src_chat.title}`\n"
        f"Destination: `{dest}`\n"
        f"Replace: `{rf}` → `{rt}`"
    )


@app.on_message(filters.private & filters.command("listsource") & filters.create(is_owner))
async def list_sources(client, message):
    routes = load_routes()
    if not routes:
        return await message.reply("📭 Koi source add nahi hai")

    txt = "📌 **Active Sources:**\n\n"
    for sid, d in routes.items():
        txt += f"• `{sid}` ➜ {d['destination']}\n"
    await message.reply(txt)


@app.on_message(filters.private & filters.command("delsource") & filters.create(is_owner))
async def del_source(client, message):
    if len(message.command) < 2:
        return await message.reply("Usage: /delsource SOURCE_ID")

    remove_route(message.command[1])
    await message.reply("🗑️ Source removed successfully")
