import re

# Episode patterns: Episode 12, Ep-12, EP12, E01, etc
EP_REGEX = re.compile(
    r"(episode|ep|e)\s*[-:]?\s*\d{1,4}",
    re.IGNORECASE
)

def is_episode_post(message):
    # 1️⃣ Image hona zaruri hai
    if not message.photo:
        return False

    # 2️⃣ Caption hona chahiye
    caption = message.caption or ""
    if not caption:
        return False

    # 3️⃣ Caption me episode number match hona chahiye
    if not EP_REGEX.search(caption):
        return False

    # 4️⃣ Button hona chahiye
    if not message.reply_markup:
        return False

    return True
