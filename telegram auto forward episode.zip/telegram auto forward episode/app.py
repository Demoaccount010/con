from flask import Flask
import threading
from userbot import start_userbot
from config import PORT

app = Flask(__name__)

@app.route("/")
def home():
    return "🔥 Guru ho ja – bot chal raha hai"

def run_bot():
    start_userbot()

if __name__ == "__main__":
    threading.Thread(target=run_bot).start()
    app.run(host="0.0.0.0", port=PORT)
