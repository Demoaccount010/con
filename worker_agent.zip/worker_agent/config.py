import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    # Worker Identity
    WORKER_ID = os.getenv("WORKER_ID", "vps-worker-01")
    
    # Server Config
    HOST = os.getenv("HOST", "0.0.0.0")
    PORT = int(os.getenv("PORT", 8000))
    
    # Security (Shared Secret between Main Agent and Worker)
    AUTH_TOKEN = os.getenv("WORKER_AUTH_TOKEN", "change_me_to_secure_token")
    
    # Paths
    WORKSPACE_DIR = os.getenv("WORKSPACE_DIR", "/tmp/worker_workspace")
    
    # Browser Settings
    DISPLAY_NUM = os.getenv("DISPLAY_NUM", ":99")
    SCREEN_RES = os.getenv("SCREEN_RES", "1920x1080x24")

    @staticmethod
    def validate():
        if Config.AUTH_TOKEN == "change_me_to_secure_token":
            print("WARNING: Using default insecure auth token!")