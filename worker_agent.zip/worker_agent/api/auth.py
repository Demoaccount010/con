from fastapi import Header, HTTPException, status
from worker_agent.config import Config

async def verify_token(x_auth_token: str = Header(...)):
    if x_auth_token != Config.AUTH_TOKEN:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid Auth Token"
        )
    return x_auth_token