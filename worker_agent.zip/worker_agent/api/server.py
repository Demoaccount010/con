from fastapi import FastAPI, Depends, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any, Optional

from worker_agent.config import Config
from worker_agent.api.auth import verify_token
from worker_agent.executor.dispatcher import StepDispatcher
from worker_agent.utils.logger import logger

app = FastAPI(title="Worker Agent API")
dispatcher = StepDispatcher()

# --- Schema Definition (Matches Main Agent) ---
class TaskRequest(BaseModel):
    task_id: str
    goal: str
    requirements: Dict[str, Any]
    steps: List[str]
    on_error: str = "report"

class TaskResponse(BaseModel):
    status: str
    task_id: str
    results: Dict[str, Any]

class ErrorResponse(BaseModel):
    status: str
    step: str
    reason: str
    detail: str
    suggestion: str

# --- Endpoints ---

@app.get("/health")
def health_check():
    return {"status": "ONLINE", "worker_id": Config.WORKER_ID}

@app.get("/capabilities", dependencies=[Depends(verify_token)])
def get_capabilities():
    """Returns what this worker can do (keys of dispatcher)"""
    return {
        "worker_id": Config.WORKER_ID,
        "capabilities": list(dispatcher.mapping.keys())
    }

@app.post("/execute", response_model=TaskResponse, dependencies=[Depends(verify_token)])
def execute_task(task: TaskRequest):
    logger.info(f"Received Task {task.task_id}: {task.goal}")
    
    results = {}
    
    for step in task.steps:
        try:
            logger.info(f"Executing step: {step}")
            output = dispatcher.execute_step(step)
            results[step] = output
            
        except Exception as e:
            logger.error(f"Step '{step}' failed: {str(e)}")
            
            # Construct strict error response
            error_payload = {
                "status": "FAILED",
                "step": step,
                "reason": "Execution Error",
                "detail": str(e),
                "suggestion": "Check worker logs or VPS permissions"
            }
            
            # If on_error is 'report', we return 200 but with failed status body
            # This allows Main Agent to handle it logic flow
            return {
                "status": "FAILED",
                "task_id": task.task_id,
                "results": results, # Return partial results
                "error": error_payload
            }

    return {
        "status": "SUCCESS",
        "task_id": task.task_id,
        "results": results
    }