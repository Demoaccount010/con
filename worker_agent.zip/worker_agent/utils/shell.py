import subprocess
import shlex
from typing import Tuple, Dict
from worker_agent.utils.logger import logger

def run_command(command: str, timeout: int = 30) -> Dict[str, str]:
    """
    Executes a shell command safely and returns structured output.
    """
    logger.info(f"Executing Shell: {command}")
    
    try:
        # Split command for safety unless it involves pipes/complex syntax
        args = shlex.split(command)
        
        result = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False 
        )
        
        return {
            "status": "SUCCESS" if result.returncode == 0 else "FAILED",
            "stdout": result.stdout.strip(),
            "stderr": result.stderr.strip(),
            "code": str(result.returncode)
        }
        
    except subprocess.TimeoutExpired:
        return {
            "status": "FAILED",
            "stdout": "",
            "stderr": f"Command timed out after {timeout} seconds",
            "code": "TIMEOUT"
        }
    except Exception as e:
        return {
            "status": "FAILED",
            "stdout": "",
            "stderr": str(e),
            "code": "EXCEPTION"
        }