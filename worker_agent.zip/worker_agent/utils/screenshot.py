import os
from worker_agent.utils.shell import run_command
from worker_agent.config import Config

def take_screenshot(filename: str = "screenshot.png") -> dict:
    """
    Takes a screenshot of the virtual display (Xvfb).
    Requires: scrot or import (imagemagick)
    """
    path = os.path.join(Config.WORKSPACE_DIR, filename)
    os.makedirs(Config.WORKSPACE_DIR, exist_ok=True)
    
    # Try using scrot with specific display
    env_cmd = f"DISPLAY={Config.DISPLAY_NUM} scrot {path}"
    
    # Fallback to shell execution with env var
    # Note: running via shell=True for env var expansion, handled carefully
    import subprocess
    env = os.environ.copy()
    env["DISPLAY"] = Config.DISPLAY_NUM
    
    try:
        subprocess.run(["scrot", path], env=env, check=True, timeout=5)
        return {"status": "SUCCESS", "path": path}
    except Exception:
        # Fallback to imagemagick
        try:
            subprocess.run(["import", "-window", "root", path], env=env, check=True, timeout=5)
            return {"status": "SUCCESS", "path": path}
        except Exception as e:
            return {"status": "FAILED", "error": str(e)}