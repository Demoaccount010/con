import uvicorn
from worker_agent.config import Config
from worker_agent.utils.logger import logger

if __name__ == "__main__":
    # Validate Config
    Config.validate()
    
    logger.info(f"Starting Worker Agent ID: {Config.WORKER_ID}")
    logger.info(f"Listening on {Config.HOST}:{Config.PORT}")
    
    # Run Uvicorn
    uvicorn.run(
        "worker_agent.api.server:app",
        host=Config.HOST,
        port=Config.PORT,
        reload=False
    )