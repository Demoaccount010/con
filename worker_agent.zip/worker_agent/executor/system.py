import psutil
import os
import shutil
from worker_agent.utils.shell import run_command
from worker_agent.utils.logger import logger

class SystemExecutor:
    
    @staticmethod
    def check_environment(args: str = None) -> dict:
        """Checks OS, CPU, RAM"""
        cpu = psutil.cpu_percent()
        ram = psutil.virtual_memory().percent
        disk = psutil.disk_usage('/').percent
        return {
            "os": os.uname().sysname,
            "cpu_usage": f"{cpu}%",
            "ram_usage": f"{ram}%",
            "disk_usage": f"{disk}%"
        }

    @staticmethod
    def list_files(path: str) -> dict:
        """Lists files in a directory"""
        target = path if path else "."
        if not os.path.exists(target):
            raise FileNotFoundError(f"Path {target} does not exist")
        return {"files": os.listdir(target)}

    @staticmethod
    def install_package(package_name: str) -> dict:
        """Installs a package using apt-get (Debian/Ubuntu)"""
        # Security: In production, verify package_name against allow-list
        res = run_command(f"apt-get install -y {package_name}", timeout=300)
        if res["status"] == "FAILED":
            raise Exception(res["stderr"])
        return res

    @staticmethod
    def service_control(cmd: str) -> dict:
        """systemctl start/stop/restart <service>"""
        # Expected format: "action:service" e.g., "restart:nginx"
        try:
            action, service = cmd.split(":")
            if action not in ["start", "stop", "restart", "status"]:
                raise ValueError("Invalid service action")
            
            res = run_command(f"systemctl {action} {service}")
            return res
        except ValueError:
            raise ValueError("Format must be action:service")