import os
import subprocess
from worker_agent.config import Config
from worker_agent.utils.shell import run_command
from worker_agent.utils.screenshot import take_screenshot

class BrowserExecutor:
    
    @staticmethod
    def start_gui(args: str = None) -> dict:
        """Starts Xvfb (Virtual Framebuffer)"""
        # Check if already running
        check = run_command(f"pgrep -a Xvfb")
        if Config.DISPLAY_NUM in check["stdout"]:
            return {"status": "Already Running", "display": Config.DISPLAY_NUM}
            
        cmd = f"Xvfb {Config.DISPLAY_NUM} -screen 0 {Config.SCREEN_RES} &"
        subprocess.Popen(cmd, shell=True)
        return {"status": "Started", "display": Config.DISPLAY_NUM}

    @staticmethod
    def launch_firefox(url: str) -> dict:
        """Launches Firefox on the virtual display"""
        if not url:
            url = "about:blank"
            
        env = os.environ.copy()
        env["DISPLAY"] = Config.DISPLAY_NUM
        
        # nohup to keep it running
        cmd = ["firefox", "--new-window", url]
        try:
            subprocess.Popen(cmd, env=env)
            return {"status": "Launched", "url": url}
        except Exception as e:
            raise Exception(f"Failed to launch Firefox: {e}")

    @staticmethod
    def capture_screen(filename: str = None) -> dict:
        fname = filename if filename else f"snap_{os.urandom(4).hex()}.png"
        return take_screenshot(fname)