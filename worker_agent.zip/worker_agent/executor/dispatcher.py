from worker_agent.executor.system import SystemExecutor
from worker_agent.executor.docker import DockerExecutor
from worker_agent.executor.browser import BrowserExecutor
from worker_agent.utils.logger import logger

class StepDispatcher:
    """
    Maps step names (strings) to actual Python functions.
    Parses arguments if the step string contains a separator (e.g., 'install:nginx')
    """
    
    def __init__(self):
        self.mapping = {
            # System
            "check_environment": SystemExecutor.check_environment,
            "list_files": SystemExecutor.list_files,
            "install": SystemExecutor.install_package,
            "service": SystemExecutor.service_control,
            
            # Docker
            "docker_list": DockerExecutor.list_containers,
            "docker_pull": DockerExecutor.pull_image,
            "docker_restart": DockerExecutor.restart_container,
            
            # Browser
            "start_gui": BrowserExecutor.start_gui,
            "open_browser": BrowserExecutor.launch_firefox,
            "screenshot": BrowserExecutor.capture_screen
        }

    def execute_step(self, step_string: str):
        """
        Parses 'action' or 'action:args' and calls the function.
        """
        if ":" in step_string:
            action, args = step_string.split(":", 1)
        else:
            action, args = step_string, None
            
        if action not in self.mapping:
            raise NotImplementedError(f"Step '{action}' is not implemented on this Worker.")
            
        func = self.mapping[action]
        logger.info(f"Dispatching -> {action} with args: {args}")
        
        # Execute
        if args:
            return func(args)
        else:
            return func()