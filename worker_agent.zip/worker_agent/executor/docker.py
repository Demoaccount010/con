from worker_agent.utils.shell import run_command

class DockerExecutor:
    
    @staticmethod
    def list_containers(args: str = None) -> dict:
        res = run_command("docker ps -a --format '{{.Names}} - {{.Status}}'")
        if res["status"] == "FAILED":
            raise Exception("Docker not available or permission denied")
        return {"containers": res["stdout"].split('\n')}

    @staticmethod
    def pull_image(image: str) -> dict:
        res = run_command(f"docker pull {image}", timeout=300)
        return res

    @staticmethod
    def restart_container(container_name: str) -> dict:
        res = run_command(f"docker restart {container_name}")
        return res