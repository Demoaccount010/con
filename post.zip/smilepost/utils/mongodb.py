from pymongo import MongoClient
from config import MONGODB_URI, DB_NAME
from utils.logger import info, error

_client = None
_db = None
_sources = None

def get_db():
    global _client, _db, _sources
    if _db is None:
        try:
            _client = MongoClient(MONGODB_URI)
            _db = _client[DB_NAME]
            _sources = _db["sources"]
            # Test connection
            _client.admin.command('ping')
            info("Connected to MongoDB successfully")
        except Exception as e:
            error(f"Failed to connect to MongoDB: {e}")
            raise e
    return _sources

# ================= SOURCE CHANNEL OPS =================

def add_source_channel(source_id: str, source_data: dict):
    sources = get_db()
    sources.update_one(
        {"_id": source_id},
        {"$set": source_data},
        upsert=True
    )

def get_source(source_id: str):
    sources = get_db()
    return sources.find_one({"_id": source_id})

def get_all_sources():
    sources = get_db()
    # Convert to dictionary format compatible with jsondb
    all_docs = sources.find()
    return {doc["_id"]: doc for doc in all_docs}

def remove_source_channel(source_id: str):
    sources = get_db()
    result = sources.delete_one({"_id": source_id})
    return result.deleted_count > 0

def set_source_enabled(source_id: str, enabled: bool):
    sources = get_db()
    result = sources.update_one(
        {"_id": source_id},
        {"$set": {"enabled": enabled}}
    )
    return result.matched_count > 0

def get_sources_with_status():
    return get_all_sources()

# ================= EPISODE OPS =================

def init_episode(source_id: str, episode: str, qualities: list):
    sources = get_db()
    source = sources.find_one({"_id": source_id})
    if not source:
        return

    episodes = source.get("episodes", {})
    if episode not in episodes:
        episode_data = {"posted": False}
        for q in qualities:
            episode_data[q] = False
        
        sources.update_one(
            {"_id": source_id},
            {"$set": {f"episodes.{episode}": episode_data}}
        )

def mark_quality_done(source_id: str, episode: str, quality: str):
    sources = get_db()
    sources.update_one(
        {"_id": source_id},
        {"$set": {f"episodes.{episode}.{quality}": True}}
    )

def is_episode_complete(source_id: str, episode: str, qualities: list) -> bool:
    sources = get_db()
    source = sources.find_one({"_id": source_id})
    if not source:
        return False
    
    ep = source.get("episodes", {}).get(episode)
    if not ep:
        return False

    for q in qualities:
        if not ep.get(q):
            return False
    return True

def is_episode_posted(source_id: str, episode: str) -> bool:
    sources = get_db()
    source = sources.find_one({"_id": source_id})
    if not source:
        return False
    return source.get("episodes", {}).get(episode, {}).get("posted", False)

def mark_episode_posted(source_id: str, episode: str):
    sources = get_db()
    sources.update_one(
        {"_id": source_id},
        {"$set": {f"episodes.{episode}.posted": True}}
    )
