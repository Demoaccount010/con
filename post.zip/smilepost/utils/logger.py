import logging
import sys
from pyrogram import Client
from config import LOG_CHANNEL_ID

_log_client: Client = None


def set_log_client(client: Client):
    global _log_client
    _log_client = client


async def log_to_channel(text: str):
    if _log_client and LOG_CHANNEL_ID:
        try:
            await _log_client.send_message(LOG_CHANNEL_ID, text)
        except:
            pass


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger("AnimeAutoPoster")


def info(msg: str):
    logger.info(msg)


def warning(msg: str):
    logger.warning(msg)


def error(msg: str):
    logger.error(msg)
