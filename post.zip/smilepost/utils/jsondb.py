import json
import os
import threading

DATA_FILE = "data/data.json"
_LOCK = threading.Lock()


def _ensure_file():
    """Ensure data file exists"""
    if not os.path.exists(DATA_FILE):
        os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump({"sources": {}}, f, indent=4)


def read_db():
    """Read full database"""
    _ensure_file()
    with _LOCK:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)


def write_db(data: dict):
    """Write full database"""
    with _LOCK:
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)


# ================= SOURCE CHANNEL OPS =================

def add_source_channel(source_id: str, source_data: dict):
    db = read_db()
    db["sources"][source_id] = source_data
    write_db(db)


def get_source(source_id: str):
    db = read_db()
    return db["sources"].get(source_id)


def get_all_sources():
    db = read_db()
    return db["sources"]


# ================= EPISODE OPS =================

def init_episode(source_id: str, episode: str, qualities: list):
    db = read_db()

    src = db["sources"].setdefault(source_id, {})
    eps = src.setdefault("episodes", {})

    if episode not in eps:
        eps[episode] = {
            "posted": False
        }
        for q in qualities:
            eps[episode][q] = False

    write_db(db)


def mark_quality_done(source_id: str, episode: str, quality: str):
    db = read_db()
    db["sources"][source_id]["episodes"][episode][quality] = True
    write_db(db)


def is_episode_complete(source_id: str, episode: str, qualities: list) -> bool:
    db = read_db()
    ep = db["sources"][source_id]["episodes"][episode]

    for q in qualities:
        if not ep.get(q):
            return False
    return True


def is_episode_posted(source_id: str, episode: str) -> bool:
    db = read_db()
    return db["sources"][source_id]["episodes"][episode].get("posted", False)


def mark_episode_posted(source_id: str, episode: str):
    db = read_db()
    db["sources"][source_id]["episodes"][episode]["posted"] = True
    write_db(db)

def remove_source_channel(source_id: str):
    db = read_db()
    if source_id in db["sources"]:
        del db["sources"][source_id]
        write_db(db)
        return True
    return False

def set_source_enabled(source_id: str, enabled: bool):
    db = read_db()
    if source_id in db["sources"]:
        db["sources"][source_id]["enabled"] = enabled
        write_db(db)
        return True
    return False


def get_sources_with_status():
    db = read_db()
    return db["sources"]
