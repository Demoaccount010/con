import asyncio
from pyrogram import Client
from pyrogram.errors import ChatAdminRequired

from utils.logger import info, error, set_log_client, log_to_channel
from config import (
    API_ID,
    API_HASH,
    BOT_TOKEN,
    OWNER_ID,
    MAIN_CHANNEL_ID,
    MAIN_CHANNEL_USERNAME
)

from core.validator import is_bot_admin
from core.listener import register_channel_listener
from commands.set import register_set_command


async def startup_checks(app: Client):
    info("Running startup checks...")
    await log_to_channel("🚀 Running startup checks...")

    # 🔥 CRITICAL FIX: resolve peer via USERNAME
    try:
        await app.get_chat(MAIN_CHANNEL_USERNAME)
        info("Main channel peer resolved via username")
        await log_to_channel("✅ Main channel peer resolved via username")
    except Exception as e:
        error(f"Failed to resolve main channel peer: {e}")
        await log_to_channel(f"❌ Failed to resolve main channel peer:\n{e}")
        raise e

    # ⚠️ Soft admin check (Telegram Bot API workaround)
    try:
        info("Skipping admin chat_action check for channel (safe mode)")
        info("Main channel admin access verified (soft check)")
        await log_to_channel("🔐 Main channel admin access verified (soft check)")
    except Exception as e:
        error(f"Warning: could not verify admin access at startup: {e}")
        await log_to_channel(
            f"⚠️ Admin check warning at startup:\n{e}\n"
            f"Bot will continue, real check will happen at post time"
        )
        info("Bot will continue, real check will happen at post time")

    info("Startup checks completed successfully")
    await log_to_channel("✅ Startup checks completed successfully")


async def main():
    app = Client(
        name="anime_auto_poster_bot",
        api_id=API_ID,
        api_hash=API_HASH,
        bot_token=BOT_TOKEN,
        in_memory=False
    )

    async with app:
        # 🔹 set log client for log channel
        set_log_client(app)

        # 🔹 startup safety checks
        await startup_checks(app)

        # 🔹 register commands & listeners
        register_set_command(app)
        register_channel_listener(app)

        info("🤖 Anime Auto Poster Bot started successfully!")
        info(f"Owner ID: {OWNER_ID}")
        info(f"Main Channel ID: {MAIN_CHANNEL_ID}")
        info(f"Main Channel Username: {MAIN_CHANNEL_USERNAME}")

        await log_to_channel(
            "🤖 **Anime Auto Poster Bot Started**\n"
            f"👤 Owner ID: {OWNER_ID}\n"
            f"📢 Main Channel: {MAIN_CHANNEL_USERNAME}"
        )

        await asyncio.Event().wait()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        info("Bot stopped manually")
    except Exception as e:
        error(f"Bot crashed: {e}")
