import json
import os
import sys
from pymongo import MongoClient

# Add project root to path to import config and mongodb
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from config import MONGODB_URI, DB_NAME
from utils.mongodb import add_source_channel

JSON_FILE = "data/data.json"

def migrate():
    if not os.path.exists(JSON_FILE):
        print(f"❌ JSON file not found at {JSON_FILE}")
        return

    print(f"🚀 Starting migration from {JSON_FILE} to MongoDB...")

    try:
        with open(JSON_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print(f"❌ Failed to read JSON file: {e}")
        return

    sources = data.get("sources", {})
    if not sources:
        print("ℹ️ No sources found in JSON to migrate.")
        return

    count = 0
    for source_id, source_data in sources.items():
        print(f"📦 Migrating source: {source_data.get('series_name', source_id)}")
        try:
            add_source_channel(source_id, source_data)
            count += 1
        except Exception as e:
            print(f"❌ Failed to migrate {source_id}: {e}")

    print(f"✅ Migration completed! Migrated {count} sources.")

if __name__ == "__main__":
    migrate()
