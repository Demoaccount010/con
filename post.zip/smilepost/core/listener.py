from pyrogram import filters
from config import REQUIRED_QUALITIES

from utils.logger import log_to_channel
from utils.logger import info, warning
from utils.jsondb import (
    get_all_sources,
    init_episode,
    mark_quality_done,
    is_episode_complete,
    is_episode_posted
)
from core.parser import parse_message
from core.poster import post_episode


def register_channel_listener(app):
    """
    Register channel message listener
    """

    @app.on_message(filters.channel)
    async def channel_watcher(client, message):

        # Ignore empty messages
        if not message:
            return

        sources = get_all_sources()
        if not sources:
            return

        chat_id = str(message.chat.id)

        # Check if this channel is configured
        if chat_id not in sources:
            return

        source = sources[chat_id]

        # 🔴 ENABLE / DISABLE CHECK
        if not source.get("enabled", True):
            return

        # Only care about video / document
        if not (message.video or message.document):
            return

        caption = message.caption or ""
        filename = ""

        if message.video and message.video.file_name:
            filename = message.video.file_name
        elif message.document and message.document.file_name:
            filename = message.document.file_name

        episode, quality = parse_message(caption, filename)

        if not episode or not quality:
            warning(f"Could not detect episode/quality from source {chat_id}")
            await log_to_channel(
                f"⚠️ Episode/Quality detect failed\n"
                f"📺 {source['series_name']}\n"
                f"Source: {chat_id}"
            )
            return

        # Init episode tracking if first time
        init_episode(chat_id, episode, REQUIRED_QUALITIES)

        # Mark detected quality
        mark_quality_done(chat_id, episode, quality)

        info(f"Detected EP {episode} | {quality} from {source['series_name']}")
        await log_to_channel(
            f"🎬 Episode Detected\n"
            f"📺 {source['series_name']}\n"
            f"EP: {episode}\n"
            f"Quality: {quality}"
        )

        # Check if already posted (EARLY EXIT)
        if is_episode_posted(chat_id, episode):
            await log_to_channel(
                f"ℹ️ Episode already posted\n"
                f"📺 {source['series_name']}\n"
                f"EP: {episode}"
            )
            return

        # Check if all qualities completed
        if not is_episode_complete(chat_id, episode, REQUIRED_QUALITIES):
            info(f"Waiting for remaining qualities for EP {episode}")
            await log_to_channel(
                f"⏳ Waiting for qualities\n"
                f"📺 {source['series_name']}\n"
                f"EP: {episode}"
            )
            return

        # 🔥 FINAL SAFETY LOCK (VERY IMPORTANT – ADDED)
        if is_episode_posted(chat_id, episode):
            return

        # All qualities done → POST
        await log_to_channel(
            f"✅ Episode Complete\n"
            f"📺 {source['series_name']}\n"
            f"EP: {episode}\n"
            f"Qualities: 480p | 720p | 1080p\n"
            f"📤 Posting now..."
        )

        await post_episode(
            client=client,
            source_id=chat_id,
            series_name=source["series_name"],
            episode=episode,
            invite_link=source["invite_link"],
            reply_msg_id=source["image_msg_id"]
        )

        await log_to_channel(
            f"🎉 Episode Posted Successfully\n"
            f"📺 {source['series_name']}\n"
            f"EP: {episode}"
        )
