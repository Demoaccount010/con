import re


# ================= REGEX PATTERNS =================

EPISODE_PATTERNS = [
    # Episode keywords
    r"[Ee]pisode[\s\.\-_:]*(\d{1,4})",
    r"\b[Ee]p[\s\.\-_:]*(\d{1,4})",
    r"\b[Ee][\s\.\-_:]*(\d{1,4})",

    # Short forms
    r"\bEP[\s\.\-_:]*(\d{1,4})",
    r"\bE[\s\.\-_:]*(\d{1,4})",

    # Brackets styles
    r"\[(\d{1,4})\]",
    r"\((\d{1,4})\)",

    # Dash / underscore separated
    r"[\-_](\d{1,4})[\-_]",

    # Space separated numbers
    r"\s(\d{1,4})\s",

    # Last fallback (ANY number, very strong)
    r"\b(\d{1,4})\b"
]

QUALITY_PATTERNS = {
    "480p": r"(480p|480|640x480|sd)",
    "720p": r"(720p|720|1280x720|hd)",
    "1080p": r"(1080p|1080|1920x1080|fhd|full\s*hd)"
}


# ================= PARSER FUNCTIONS =================

def extract_episode(text: str):
    """Extract episode number from text"""
    if not text:
        return None

    for pattern in EPISODE_PATTERNS:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            return match.group(1)

    return None


def extract_quality(text: str):
    """Extract video quality from text"""
    if not text:
        return None

    for quality, pattern in QUALITY_PATTERNS.items():
        if re.search(pattern, text, re.IGNORECASE):
            return quality

    return None


def parse_message(caption: str = "", filename: str = ""):
    """
    Try to detect episode + quality
    Priority: caption > filename
    """
    text = f"{caption} {filename}"

    episode = extract_episode(text)
    quality = extract_quality(text)

    return episode, quality
