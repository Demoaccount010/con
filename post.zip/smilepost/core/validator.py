from pyrogram.errors import ChatAdminRequired, ChannelPrivate, UsernameNotOccupied
from utils.logger import info, error


async def validate_channel(client, channel_id: int):
    """
    Check if channel exists and bot can access it
    """
    try:
        chat = await client.get_chat(channel_id)
        return chat
    except UsernameNotOccupied:
        error("Channel username does not exist")
        return None
    except ChannelPrivate:
        error("Channel is private or bot not added")
        return None
    except Exception as e:
        error(f"Channel validation failed: {e}")
        return None


async def is_bot_admin(client, channel):
    try:
        chat = await client.get_chat(channel)
        member = await client.get_chat_member(chat.id, "me")
        return member.status in ("administrator", "creator")
    except Exception as e:
        error(f"Admin check error: {e}")
        return False

