import os
from dotenv import load_dotenv

load_dotenv()

API_ID = int(os.getenv("API_ID"))
API_HASH = os.getenv("API_HASH")
BOT_TOKEN = os.getenv("BOT_TOKEN")

OWNER_ID = int(os.getenv("OWNER_ID"))

MAIN_CHANNEL_ID = int(os.getenv("MAIN_CHANNEL_ID"))
MAIN_CHANNEL_USERNAME = os.getenv("MAIN_CHANNEL_USERNAME")

LOG_CHANNEL_ID = int(os.getenv("LOG_CHANNEL_ID"))

REQUIRED_QUALITIES = ["480p", "720p", "1080p"]
POST_DELAY = 2
