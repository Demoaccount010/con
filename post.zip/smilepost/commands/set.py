from pyrogram import filters
from pyrogram.types import Message
from config import OWNER_ID
from utils.jsondb import (
    add_source_channel,
    get_all_sources,
    remove_source_channel,
    set_source_enabled,
    get_sources_with_status
)
from utils.logger import info, log_to_channel

SET_STATE = {}


def clear_state(chat_id):
    if chat_id in SET_STATE:
        del SET_STATE[chat_id]


def register_set_command(app):

    # ========== /cancel ==========
    @app.on_message(filters.private & filters.command("cancel"))
    async def cancel_cmd(client, message: Message):
        if message.from_user.id != OWNER_ID:
            return
        clear_state(message.chat.id)
        await message.reply_text("❌ Current operation cancelled.")

    # ========== /set ==========
    @app.on_message(filters.private & filters.command("set"))
    async def start_set(client, message: Message):
        if message.from_user.id != OWNER_ID:
            return

        SET_STATE[message.chat.id] = {"step": 1}
        await message.reply_text(
            "📌 **Step 1:** Send source channel ID\n\n"
            "`/cancel` to stop"
        )

    # 🔥 FIXED HANDLER (group=1 so commands work)
    @app.on_message(filters.private & filters.text, group=1)
    async def handle_steps(client, message: Message):
        if message.from_user.id != OWNER_ID:
            return

        chat_id = message.chat.id
        if chat_id not in SET_STATE:
            return

        state = SET_STATE[chat_id]
        text = message.text.strip()

        # STEP 1 — SOURCE ID
        if state["step"] == 1:
            if not text.startswith("-100"):
                await message.reply_text("❌ Send valid channel ID (starts with -100)")
                return

            if text in get_all_sources():
                await message.reply_text("⚠️ Source already exists.")
                clear_state(chat_id)
                return

            state["source_id"] = text
            state["step"] = 2
            await message.reply_text("📌 **Step 2:** Send series name")

        # STEP 2 — SERIES NAME
        elif state["step"] == 2:
            state["series_name"] = text
            state["step"] = 3
            await message.reply_text("📌 **Step 3:** Send image message link")

        # STEP 3 — IMAGE MSG ID
        elif state["step"] == 3:
            try:
                state["image_msg_id"] = int(text.split("/")[-1])
            except:
                await message.reply_text("❌ Invalid message link")
                return

            state["step"] = 4
            await message.reply_text("📌 **Step 4:** Send source invite/public link")

        # STEP 4 — INVITE LINK
        elif state["step"] == 4:
            state["invite_link"] = text

            add_source_channel(
                state["source_id"],
                {
                    "series_name": state["series_name"],
                    "image_msg_id": state["image_msg_id"],
                    "invite_link": state["invite_link"],
                    "enabled": True,
                    "episodes": {}
                }
            )

            info(f"Source added: {state['series_name']}")
            await log_to_channel(f"✅ Source added: {state['series_name']}")
            await message.reply_text("🎉 **Source added & enabled successfully!**")
            clear_state(chat_id)

    # ========== /remove ==========
    @app.on_message(filters.private & filters.command("remove"))
    async def remove_cmd(client, message: Message):
        if message.from_user.id != OWNER_ID:
            return

        parts = message.text.split()
        if len(parts) != 2:
            await message.reply_text("❌ Usage:\n/remove -100xxxxxxxxxx")
            return

        if remove_source_channel(parts[1]):
            await message.reply_text("🗑 Source removed successfully")
            await log_to_channel(f"🗑 Source removed: {parts[1]}")
        else:
            await message.reply_text("⚠️ Source not found")

    # ========== /disable ==========
    @app.on_message(filters.private & filters.command("disable"))
    async def disable_cmd(client, message: Message):
        if message.from_user.id != OWNER_ID:
            return

        parts = message.text.split()
        if len(parts) != 2:
            await message.reply_text("❌ Usage:\n/disable -100xxxxxxxxxx")
            return

        if set_source_enabled(parts[1], False):
            await message.reply_text("🚫 Source disabled")
        else:
            await message.reply_text("⚠️ Source not found")

    # ========== /enable ==========
    @app.on_message(filters.private & filters.command("enable"))
    async def enable_cmd(client, message: Message):
        if message.from_user.id != OWNER_ID:
            return

        parts = message.text.split()
        if len(parts) != 2:
            await message.reply_text("❌ Usage:\n/enable -100xxxxxxxxxx")
            return

        if set_source_enabled(parts[1], True):
            await message.reply_text("✅ Source enabled")
        else:
            await message.reply_text("⚠️ Source not found")

    # ========== /list ==========
    @app.on_message(filters.private & filters.command("list"))
    async def list_cmd(client, message: Message):
        if message.from_user.id != OWNER_ID:
            return

        sources = get_sources_with_status()
        if not sources:
            await message.reply_text("📭 No sources added.")
            return

        text = "📋 **Source List**\n\n"
        i = 1
        for sid, data in sources.items():
            status = "✅ Enabled" if data.get("enabled", True) else "❌ Disabled"
            text += (
                f"{i}. **{data['series_name']}**\n"
                f"ID: `{sid}`\n"
                f"Status: {status}\n\n"
            )
            i += 1

        await message.reply_text(text)
