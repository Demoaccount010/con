import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    API_ID = int(os.getenv("API_ID"))
    API_HASH = os.getenv("API_HASH")
    BOT_TOKEN = os.getenv("BOT_TOKEN")
    WORKERS = int(os.getenv("WORKERS", 4))
    
    ADMIN_ID = int(os.getenv("ADMIN_ID"))
    FORCE_SUB_CHANNEL = os.getenv("FORCE_SUB_CHANNEL")
    DAILY_LIMIT = int(os.getenv("DAILY_LIMIT", 5))
    
    DOWNLOAD_DIR = "downloads"
    MAX_FILE_SIZE = 2000 * 1024 * 1024  # 2GB Limit
    
    COOKIES = {
        "youtube": os.getenv("YT_COOKIES"),
        "instagram": os.getenv("INSTA_COOKIES"),
        "terabox": os.getenv("TERA_COOKIES")
    }