from pyrogram import Client, filters
from bot.database import db

@Client.on_message(filters.command("start"))
async def start(client, message):
    await db.add_user(message.from_user.id, message.from_user.first_name)
    await message.reply_text("👋 **Welcome!**\nSend me a link from YouTube, Instagram, or Terabox.")