import os
import time
from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from pyrogram.errors import UserNotParticipant
from bot.utils.engine import download_media
from bot.utils.progress import progress_bar
from config import Config
from bot.database import db

user_data = {}

async def is_subscribed(client, user_id):
    if not Config.FORCE_SUB_CHANNEL: return True
    try:
        member = await client.get_chat_member(Config.FORCE_SUB_CHANNEL, user_id)
        return member.status not in ["banned", "kicked"]
    except UserNotParticipant: return False
    except: return True

@Client.on_message(filters.text & ~filters.command(["start", "help", "stats", "add_premium", "remove_premium"]))
async def link_handler(client, message):
    url = message.text.strip()
    user_id = message.from_user.id
    await db.add_user(user_id, message.from_user.first_name)

    if not await is_subscribed(client, user_id):
        await message.reply_text("⚠️ **Please Join Channel First!**", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("📢 Join Channel", url=f"https://t.me/{Config.FORCE_SUB_CHANNEL}")]]))
        return

    allowed, reason = await db.check_limit(user_id)
    if not allowed:
        await message.reply_text(f"❌ **{reason}**")
        return

    if not url.startswith("http"): return
    user_data[user_id] = url

    buttons = []
    text = "👇 **Select Option:**"

    if "youtu" in url:
        text = "📹 **YouTube Detected!**"
        buttons = [
            [InlineKeyboardButton("🎥 1080p", callback_data="dl_1080"), InlineKeyboardButton("🎥 720p", callback_data="dl_720")],
            [InlineKeyboardButton("🎥 360p", callback_data="dl_360"), InlineKeyboardButton("🎵 MP3", callback_data="dl_audio")],
            [InlineKeyboardButton("🖼 Thumbnail", callback_data="dl_thumb")]
        ]
    elif "instagram.com" in url:
        text = "📸 **Instagram Detected!**"
        buttons = [[InlineKeyboardButton("⬇️ Download", callback_data="dl_best")]]
    elif any(x in url for x in ["terabox", "nephobox"]):
        text = "☁️ **Terabox Detected!**"
        buttons = [[InlineKeyboardButton("⬇️ Download", callback_data="dl_best")]]
    else: return

    await message.reply_text(text, reply_markup=InlineKeyboardMarkup(buttons), quote=True)

@Client.on_callback_query(filters.regex(r"^dl_"))
async def cb_handler(client, callback):
    user_id = callback.from_user.id
    data = callback.data.split("_")[1]
    
    allowed, _ = await db.check_limit(user_id)
    if not allowed: return await callback.answer("❌ Limit Reached!", show_alert=True)

    url = user_data.get(user_id)
    if not url: return await callback.answer("⚠️ Session Expired", show_alert=True)

    await callback.message.delete()
    msg = await client.send_message(callback.message.chat.id, "⏳ **Downloading...**")

    file_path = None
    try:
        file_path, title = await download_media(url, custom_type=data)
        if not file_path or not os.path.exists(file_path):
            await msg.edit_text("❌ **Download Failed.**")
            return

        file_size = os.path.getsize(file_path)
        if file_size > Config.MAX_FILE_SIZE:
            await msg.edit_text("❌ **File Too Large (Over 2GB).**")
            os.remove(file_path)
            return

        await msg.edit_text("⬆️ **Uploading...**")
        start = time.time()

        if data == "audio":
            await client.send_audio(callback.message.chat.id, audio=file_path, caption=f"🎵 **{title}**", progress=progress_bar, progress_args=(msg, start))
        elif data == "thumb":
            await client.send_photo(callback.message.chat.id, photo=file_path, caption=f"🖼 **{title}**")
        else:
            with open(file_path, 'rb') as f:
                await client.send_video(callback.message.chat.id, video=f, caption=f"🎥 **{title}**", supports_streaming=True, progress=progress_bar, progress_args=(msg, start))
        
        await db.increase_usage(user_id)
        await msg.delete()

    except Exception as e:
        print(e)
        await msg.edit_text("❌ Error.")
    finally:
        if file_path and os.path.exists(file_path):
            os.remove(file_path) # ⚡ Auto Delete