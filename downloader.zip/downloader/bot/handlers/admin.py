from pyrogram import Client, filters
from config import Config
from bot.database import db

@Client.on_message(filters.command("stats") & filters.user(Config.ADMIN_ID))
async def stats(client, message):
    count = await db.total_users()
    await message.reply_text(f"📊 **Total Users:** {count}")

@Client.on_message(filters.command("add_premium") & filters.user(Config.ADMIN_ID))
async def add_prem(client, message):
    try:
        uid = int(message.command[1])
        if await db.set_premium(uid, True): await message.reply_text("✅ Added Premium")
        else: await message.reply_text("❌ User not found")
    except: await message.reply_text("/add_premium user_id")

@Client.on_message(filters.command("remove_premium") & filters.user(Config.ADMIN_ID))
async def rem_prem(client, message):
    try:
        uid = int(message.command[1])
        if await db.set_premium(uid, False): await message.reply_text("✅ Removed Premium")
        else: await message.reply_text("❌ User not found")
    except: await message.reply_text("/remove_premium user_id")