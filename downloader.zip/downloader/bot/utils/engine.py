import os
import asyncio
import requests
import yt_dlp
from config import Config

# ========== TERABOX HELPER ==========
def clean_terabox_url(url: str) -> str:
    if "surl=" in url:
        try:
            share_id = url.split("surl=")[1].split("&")[0]
            if not share_id.startswith("1"): share_id = "1" + share_id
            return f"https://www.terabox.com/s/{share_id}"
        except: pass
    for domain in ["terabox.app", "1024tera.com", "terabox.fun", "nephobox.com", "4funbox.com"]:
        if domain in url: url = url.replace(domain, "terabox.com")
    return url

def get_terabox_direct_link(url):
    url = clean_terabox_url(url)
    apis = [
        "https://terabox-dl-arman.vercel.app/api",
        "https://terabox.udayscriptsx.workers.dev"
    ]
    for api in apis:
        try:
            res = requests.get(api, params={"url": url}, timeout=30)
            if res.status_code == 200:
                data = res.json()
                dl = data.get("downloadLink") or data.get("dlink") or data.get("download") or data.get("link")
                fn = data.get("filename") or data.get("file_name") or "terabox_video.mp4"
                if dl: return dl, fn
        except: pass
    return None, None

# ========== MAIN DOWNLOADER ==========
async def download_media(url: str, custom_type="best"):
    cookie_file = None
    platform_name = "Generic"
    
    if any(x in url for x in ["terabox", "nephobox"]):
        platform_name = "Terabox"
        cookie_file = Config.COOKIES.get("terabox")
    elif "instagram.com" in url:
        cookie_file = Config.COOKIES.get("instagram")
        platform_name = "Instagram"
    elif "youtu" in url: 
        cookie_file = Config.COOKIES.get("youtube")
        platform_name = "YouTube"

    output_path = f"{Config.DOWNLOAD_DIR}/%(title)s.%(ext)s"

    # 1. Basic Format Logic
    # Hum pehle specific quality mangenge, agar fail hua to fallback karenge
    target_format = 'bestvideo+bestaudio/best'
    
    if custom_type == "audio":
        target_format = 'bestaudio/best'
    elif custom_type == "1080":
        target_format = 'bestvideo[height<=1080]+bestaudio/best[height<=1080]/best'
    elif custom_type == "720":
        target_format = 'bestvideo[height<=720]+bestaudio/best[height<=720]/best'

    # 2. Robust Options
    ydl_opts = {
        'outtmpl': output_path,
        'noplaylist': True,
        'quiet': True,
        'no_warnings': True,
        'nocheckcertificate': True,
        'merge_output_format': 'mp4',
        'ignoreerrors': True,
        'socket_timeout': 30,
        
        # ⚡ USE ANDROID CLIENT (Most reliable for blocked IPs) ⚡
        'extractor_args': {
            'youtube': {
                'player_client': ['android', 'web'],
            }
        },
        
        # Cookies check
        'cookiefile': cookie_file if (cookie_file and os.path.exists(cookie_file) and os.path.getsize(cookie_file) > 0) else None,
    }

    # Post Processors
    if custom_type == "audio":
        ydl_opts['postprocessors'] = [{'key': 'FFmpegExtractAudio','preferredcodec': 'mp3','preferredquality': '192'}]
    elif custom_type != "thumb":
        ydl_opts['postprocessors'] = [{'key': 'FFmpegVideoConvertor','preferedformat': 'mp4'}]

    if custom_type == "thumb":
        ydl_opts.update({'writethumbnail': True, 'skip_download': True})

    print(f"📥 Downloading {platform_name} | Type: {custom_type}")

    # 3. HELPER TO RUN DOWNLOAD
    async def run_yt_dlp(options):
        loop = asyncio.get_running_loop()
        try:
            with yt_dlp.YoutubeDL(options) as ydl:
                info = await loop.run_in_executor(None, lambda: ydl.extract_info(url, download=True))
                if not info: return None, None
                
                # Check File Existence
                filename = ydl.prepare_filename(info)
                
                if custom_type == "thumb":
                    base = filename.rsplit('.', 1)[0]
                    for ext in ['.jpg', '.webp', '.png']:
                        if os.path.exists(base + ext): return base + ext, info.get('title')
                    return None, None
                
                if custom_type == "audio":
                    base = filename.rsplit('.', 1)[0]
                    return (base+".mp3", info.get('title')) if os.path.exists(base+".mp3") else (None, None)

                # Video Check (MP4)
                base = filename.rsplit('.', 1)[0]
                mp4 = base + ".mp4"
                if os.path.exists(mp4): return mp4, info.get('title')
                if os.path.exists(filename): return filename, info.get('title')
                return None, None
        except Exception as e:
            return "ERROR", str(e)

    # 4. EXECUTION
    if platform_name == "Terabox":
        direct_url, filename = get_terabox_direct_link(url)
        if not direct_url: return None, None
        safe_fn = "".join(c for c in filename if c.isalnum() or c in (' ', '.', '-', '_')).strip()
        fp = f"{Config.DOWNLOAD_DIR}/{safe_fn}"
        
        def dl_file():
            try:
                r = requests.get(direct_url, stream=True, timeout=600, headers={"User-Agent": "Mozilla/5.0"})
                if r.status_code == 200:
                    with open(fp, 'wb') as f:
                        for c in r.iter_content(1024*1024): 
                            if c: f.write(c)
                    return fp
            except: pass
            return None
        
        loop = asyncio.get_running_loop()
        res = await loop.run_in_executor(None, dl_file)
        return (res, safe_fn) if res else (None, None)

    else:
        # Attempt 1: Targeted Quality
        ydl_opts['format'] = target_format
        path, title = await run_yt_dlp(ydl_opts)
        
        # Attempt 2: Fallback to 'best' if Attempt 1 failed
        if path == "ERROR":
            print("⚠️ Attempt 1 failed. Retrying with 'best' format...")
            ydl_opts['format'] = 'best' # The simplest format available
            path, title = await run_yt_dlp(ydl_opts)
            
        if path == "ERROR":
            print(f"❌ Download Failed: {title}")
            return None, None
            
        return path, title