import os
import asyncio
import yt_dlp
import cloudscraper
import time
import random
from config import Config

# --- HELPER: CLEAN TERABOX URL ---
def clean_terabox_url(url: str) -> str:
    if "surl=" in url:
        try:
            share_id = url.split("surl=")[1].split("&")[0]
            if not share_id.startswith("1"): 
                share_id = "1" + share_id
            return f"https://www.terabox.com/s/{share_id}"
        except: 
            pass
    
    for domain in ["terabox.app", "1024tera.com", "terabox.fun", "nephobox.com", "4funbox.com", "momerybox.com", "1024terabox.com"]:
        if domain in url: 
            url = url.replace(domain, "terabox.com")
            
    return url

# --- HELPER: LOAD COOKIES ---
def load_cookies(cookie_file):
    cookies = {}
    if cookie_file and os.path.exists(cookie_file):
        try:
            with open(cookie_file, 'r') as f:
                for line in f:
                    if not line.startswith("#") and line.strip():
                        parts = line.split('\t')
                        if len(parts) >= 7:
                            cookies[parts[5].strip()] = parts[6].strip()
        except Exception as e:
            print(f"Cookie Read Error: {e}")
    return cookies

# --- TERABOX API WITH CLOUDSCRAPER ---
def get_terabox_direct_link(url, cookie_file):
    try:
        # 1. Clean URL
        url = clean_terabox_url(url)
        
        # 2. Extract Short URL ID
        if "/s/" in url:
            shorturl = url.split("/s/")[1].split("?")[0]
        elif "surl=" in url: 
            shorturl = url.split("surl=")[1].split("&")[0]
        else: 
            shorturl = url.split("/")[-1]
            
        # Remove leading '1' for API
        if shorturl.startswith("1"):
            shorturl_clean = shorturl[1:]
        else:
            shorturl_clean = shorturl

        print(f"🕵️ Terabox ID: {shorturl_clean}")

        # 3. Load Cookies
        cookies = load_cookies(cookie_file)
        
        # 4. Create Cloudscraper Session (Bypasses Anti-Bot)
        scraper = cloudscraper.create_scraper(
            browser={
                'browser': 'chrome',
                'platform': 'windows',
                'desktop': True
            },
            delay=3
        )
        
        # Add cookies to session
        for name, value in cookies.items():
            scraper.cookies.set(name, value, domain='.terabox.com')

        # 5. Headers
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "en-US,en;q=0.9",
            "Referer": f"https://www.terabox.com/s/1{shorturl_clean}",
            "Origin": "https://www.terabox.com"
        }
        
        # ========== STEP 1: VISIT PAGE FIRST (Get Session) ==========
        print("🌐 Step 1: Visiting share page...")
        page_url = f"https://www.terabox.com/s/1{shorturl_clean}"
        
        try:
            page_response = scraper.get(page_url, headers=headers, timeout=30)
            print(f"📄 Page Status: {page_response.status_code}")
            time.sleep(random.uniform(1, 2))  # Human-like delay
        except Exception as e:
            print(f"⚠️ Page visit failed: {e}")
        
        # ========== STEP 2: GET SHARE INFO ==========
        print("📡 Step 2: Getting share info...")
        
        info_url = "https://www.terabox.com/api/shorturlinfo"
        info_params = {
            "app_id": "250528",
            "shorturl": shorturl_clean,
            "root": "1"
        }
        
        info_response = scraper.get(
            info_url, 
            params=info_params,
            headers=headers,
            timeout=30
        )
        
        info_data = info_response.json()
        print(f"📋 Info API Response: errno={info_data.get('errno')}")
        
        if info_data.get("errno") != 0:
            print(f"❌ API Error: {info_data.get('errmsg', 'Unknown')}")
            return None, None
        
        # Extract parameters
        shareid = info_data.get("shareid")
        uk = info_data.get("uk")
        sign = info_data.get("sign")
        timestamp = info_data.get("timestamp")
        
        file_list = info_data.get("list", [])
        if not file_list:
            print("❌ No files found")
            return None, None
            
        first_file = file_list[0]
        fs_id = first_file.get("fs_id")
        filename = first_file.get("server_filename", "terabox_video.mp4")
        
        print(f"📁 File: {filename}")
        print(f"🔑 shareid={shareid}, uk={uk}, fs_id={fs_id}")
        
        time.sleep(random.uniform(1, 2))  # Human-like delay

        # ========== STEP 3: GET DLINK FROM LIST ==========
        print("📡 Step 3: Getting download link...")
        
        list_url = "https://www.terabox.com/share/list"
        list_params = {
            "app_id": "250528",
            "shorturl": shorturl_clean,
            "root": "1",
            "dir": "/",
            "page": "1",
            "num": "20",
            "by": "name",
            "order": "asc"
        }
        
        list_response = scraper.get(
            list_url,
            params=list_params,
            headers=headers,
            timeout=30
        )
        
        list_data = list_response.json()
        
        if list_data.get("errno") == 0:
            files = list_data.get("list", [])
            if files and files[0].get("dlink"):
                dlink = files[0].get("dlink")
                print(f"✅ Got dlink from list!")
                return dlink, filename, scraper, headers

        # ========== STEP 4: FALLBACK - FILEMETAS API ==========
        print("📡 Step 4: Trying filemetas API...")
        
        meta_url = "https://www.terabox.com/share/filemetas"
        meta_params = {
            "app_id": "250528",
            "shorturl": shorturl_clean,
            "root": "1",
            "fsidlist": f"[{fs_id}]",
            "shareid": str(shareid),
            "uk": str(uk),
            "sign": sign,
            "timestamp": str(timestamp)
        }
        
        meta_response = scraper.get(
            meta_url,
            params=meta_params,
            headers=headers,
            timeout=30
        )
        
        meta_data = meta_response.json()
        
        if meta_data.get("errno") == 0:
            meta_list = meta_data.get("list", [])
            if meta_list and meta_list[0].get("dlink"):
                dlink = meta_list[0].get("dlink")
                print(f"✅ Got dlink from filemetas!")
                return dlink, filename, scraper, headers
        
        print("❌ Could not get dlink")
        return None, None, None, None

    except Exception as e:
        print(f"Terabox API Error: {e}")
        import traceback
        traceback.print_exc()
        return None, None, None, None

# --- MAIN DOWNLOADER ---
async def download_media(url: str, custom_type="best"):
    
    cookie_file = None
    platform_name = "Generic"
    direct_filename = None
    direct_url = None
    scraper = None
    dl_headers = None
    
    # Clean URL
    original_url = url
    if any(x in url for x in ["terabox", "nephobox", "4funbox", "1024tera", "momerybox"]):
        url = clean_terabox_url(url)
    
    # Platform Setup
    if any(x in url for x in ["terabox", "nephobox", "4funbox", "1024tera", "momerybox"]):
        platform_name = "Terabox"
        cookie_file = Config.COOKIES["terabox"]
        
        print("⚡ Attempting Terabox Download...")
        result = get_terabox_direct_link(url, cookie_file)
        
        if result[0] and result[1]:
            direct_url = result[0]
            direct_filename = result[1]
            scraper = result[2]
            dl_headers = result[3]
            print(f"✅ Ready to download: {direct_filename}")
        else:
            print("❌ Terabox API failed.")
            return None, None

    elif "instagram.com" in url:
        cookie_file = Config.COOKIES["instagram"]
        platform_name = "Instagram"
        
    elif "youtu" in url: 
        cookie_file = Config.COOKIES["youtube"]
        platform_name = "YouTube"

    output_path = f"{Config.DOWNLOAD_DIR}/%(title)s.%(ext)s"

    # Quality Selection
    format_string = 'bestvideo+bestaudio/best'
    if custom_type == "audio": 
        format_string = 'bestaudio/best'
    elif custom_type in ["1080", "720", "360"]:
        format_string = f'bestvideo[height<={custom_type}]+bestaudio/best[height<={custom_type}]/best'

    # YT-DLP Options
    ydl_opts = {
        'format': format_string,
        'outtmpl': output_path,
        'noplaylist': True,
        'quiet': True,
        'no_warnings': True,
        'nocheckcertificate': True,
        'merge_output_format': 'mp4',
        'http_headers': {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        },
        'cookiefile': cookie_file if (cookie_file and os.path.exists(cookie_file) and platform_name != "Terabox") else None,
    }

    # Post Processors
    if custom_type == "audio":
        ydl_opts['postprocessors'] = [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192'
        }]
    elif custom_type != "thumb":
        ydl_opts['postprocessors'] = [{
            'key': 'FFmpegVideoConvertor',
            'preferedformat': 'mp4'
        }]

    # Thumbnail Mode
    if custom_type == "thumb":
        ydl_opts = {
            'writethumbnail': True, 
            'skip_download': True, 
            'outtmpl': output_path, 
            'quiet': True, 
            'cookiefile': cookie_file
        }

    print(f"📥 Downloading {platform_name} | Type: {custom_type}")

    try:
        loop = asyncio.get_running_loop()
        
        # ========== TERABOX DOWNLOAD ==========
        if platform_name == "Terabox" and direct_url and scraper:
            safe_filename = "".join(c for c in direct_filename if c.isalnum() or c in (' ', '.', '-', '_')).strip()
            filepath = f"{Config.DOWNLOAD_DIR}/{safe_filename}"
            
            print(f"⬇️ Downloading: {safe_filename}")
            
            def download_file():
                try:
                    # Use the same scraper session for download
                    response = scraper.get(
                        direct_url,
                        headers=dl_headers,
                        timeout=600,  # 10 min timeout
                        stream=True
                    )
                    
                    if response.status_code in [200, 206, 302]:
                        total_size = int(response.headers.get('content-length', 0))
                        downloaded = 0
                        
                        with open(filepath, 'wb') as f:
                            for chunk in response.iter_content(chunk_size=1024*1024):  # 1MB chunks
                                if chunk:
                                    f.write(chunk)
                                    downloaded += len(chunk)
                                    if total_size > 0:
                                        progress = (downloaded / total_size) * 100
                                        print(f"\r⬇️ Progress: {progress:.1f}%", end="", flush=True)
                        
                        print()  # New line after progress
                        return filepath
                    else:
                        print(f"❌ Download failed: HTTP {response.status_code}")
                        return None
                        
                except Exception as e:
                    print(f"❌ Download Error: {e}")
                    return None
            
            result_path = await loop.run_in_executor(None, download_file)
            
            if result_path and os.path.exists(result_path):
                file_size = os.path.getsize(result_path)
                print(f"✅ Downloaded: {safe_filename} ({round(file_size/1024/1024, 2)} MB)")
                return result_path, safe_filename
            else:
                return None, None
        
        # ========== YOUTUBE / INSTAGRAM ==========
        else:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = await loop.run_in_executor(None, lambda: ydl.extract_info(url, download=True))
                
                if custom_type == "thumb":
                    base = ydl.prepare_filename(info).rsplit('.', 1)[0]
                    for ext in ['.jpg', '.webp', '.png']:
                        if os.path.exists(base + ext): 
                            return base + ext, info.get('title')
                    return None, None

                filename = ydl.prepare_filename(info)
                
                if custom_type == "audio":
                    base = filename.rsplit('.', 1)[0]
                    mp3_path = base + ".mp3"
                    return (mp3_path, info.get('title')) if os.path.exists(mp3_path) else (None, None)

                base = filename.rsplit('.', 1)[0]
                mp4_path = base + ".mp4"
                
                if os.path.exists(mp4_path):
                    return mp4_path, info.get('title')
                elif os.path.exists(filename):
                    return filename, info.get('title')
                else:
                    return None, None
                
    except Exception as e:
        print(f"Engine Error: {e}")
        import traceback
        traceback.print_exc()
        return None, None