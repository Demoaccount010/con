import json
import os
import asyncio
import datetime
from config import Config

class Database:
    def __init__(self, file_name="users.json"):
        self.file_name = file_name
        self.lock = asyncio.Lock()
        self.data = self.load()

    def load(self):
        if not os.path.exists(self.file_name):
            return {}
        try:
            with open(self.file_name, 'r') as f:
                return json.load(f)
        except:
            return {}

    async def save(self):
        """Save data to JSON file safely"""
        async with self.lock:
            with open(self.file_name, 'w') as f:
                json.dump(self.data, f, indent=4)

    async def add_user(self, user_id, name):
        str_id = str(user_id)
        if str_id not in self.data:
            self.data[str_id] = {
                "name": name,
                "is_premium": False,
                "daily_usage": 0,
                "last_date": str(datetime.date.today())
            }
            await self.save()

    async def check_limit(self, user_id):
        str_id = str(user_id)
        if str_id not in self.data:
            return False, "User not found. Type /start"

        user = self.data[str_id]

        # 1. Check Premium
        if user.get("is_premium", False):
            return True, "Premium"

        # 2. Check Date Reset
        today = str(datetime.date.today())
        if user.get("last_date") != today:
            user["last_date"] = today
            user["daily_usage"] = 0
            await self.save()
            return True, "Reset"

        # 3. Check Usage
        usage = user.get("daily_usage", 0)
        if usage >= Config.DAILY_LIMIT:
            return False, f"Daily Limit Reached ({usage}/{Config.DAILY_LIMIT}). Buy Premium! Contact @yoursmileyt"
        
        return True, "Allowed"

    async def increase_usage(self, user_id):
        str_id = str(user_id)
        if str_id in self.data:
            self.data[str_id]["daily_usage"] += 1
            await self.save()

    async def set_premium(self, user_id, status=True):
        str_id = str(user_id)
        if str_id in self.data:
            self.data[str_id]["is_premium"] = status
            await self.save()
            return True
        return False

    async def total_users(self):
        return len(self.data)

db = Database()