import os
import logging
from pyrogram import Client, idle
from config import Config

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logging.getLogger("pyrogram").setLevel(logging.WARNING)

if not os.path.exists(Config.DOWNLOAD_DIR):
    os.makedirs(Config.DOWNLOAD_DIR)

app = Client(
    "media_bot",
    api_id=Config.API_ID,
    api_hash=Config.API_HASH,
    bot_token=Config.BOT_TOKEN,
    workers=Config.WORKERS,
    plugins=dict(root="bot/handlers"),
    max_concurrent_transmissions=3,
    ipv6=False
)

if __name__ == "__main__":
    print("🤖 Bot Started...")
    app.start()
    idle()
    app.stop()