"""
Web Search Module
=================
Allows the AI to search the internet for knowledge.
"""

from duckduckgo_search import DDGS
from typing import List, Dict

class WebSearch:
    """
    Search Engine Interface.
    """
    
    def __init__(self):
        self.ddgs = DDGS()
    
    def search(self, query: str, max_results: int = 5) -> List[Dict[str, str]]:
        """
        Search the web.
        
        Args:
            query: Search query
            max_results: Number of results
            
        Returns:
            List of {title, href, body}
        """
        try:
            results = list(self.ddgs.text(query, max_results=max_results))
            return results
        except Exception as e:
            return [{"error": str(e)}]