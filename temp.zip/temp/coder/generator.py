"""
Code Generator
==============
Uses LLM to write Python/Bash scripts.
"""

from typing import Optional

class CodeGenerator:
    """
    Generates code based on requirements.
    """
    
    def __init__(self, ollama_client):
        self.client = ollama_client
    
    def generate_script(self, task_description: str, language: str = "python") -> str:
        """
        Write a script for a task.
        """
        prompt = f"""
You are an expert programmer. Write a {language} script for the following task:
"{task_description}"

RULES:
1. Return ONLY the code. No explanations.
2. Use best practices and error handling.
3. If python, import necessary modules.
4. Ensure the code is complete and runnable.

CODE:
"""
        response = self.client.generate(prompt=prompt, temperature=0.2)
        code = response.content.strip()
        
        # Clean markdown
        code = code.replace("```python", "").replace("```bash", "").replace("```", "")
        return code.strip()