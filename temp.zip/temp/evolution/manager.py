"""
Evolution Manager
=================
Manages self-improvement and new skill acquisition.
"""

from main_agent.knowledge.search import WebSearch
from main_agent.knowledge.browser import WebBrowser
from main_agent.coder.generator import CodeGenerator
from main_agent.utils.logger import get_logger

class EvolutionManager:
    """
    The Brain of Self-Improvement.
    """
    
    def __init__(self, agent):
        self.agent = agent
        self.search = WebSearch()
        self.browser = WebBrowser()
        self.coder = CodeGenerator(agent.ollama_client)
        self.logger = get_logger("EvolutionManager")
    
    def learn_skill(self, skill_name: str) -> str:
        """
        Learn a new skill from the internet.
        """
        self.logger.info(f"Learning new skill: {skill_name}")
        
        # 1. Search for info
        results = self.search.search(f"how to {skill_name} in python tutorial")
        if not results:
            return "Could not find information."
            
        # 2. Read best article
        url = results[0]['href']
        content = self.browser.read_page(url)
        
        # 3. Generate Code based on learning
        code = self.coder.generate_script(f"Create a script to {skill_name} based on this info: {content[:1000]}")
        
        # 4. Save to library (Mock for now)
        # In future, this will save to a 'skills' folder
        
        return f"✅ Learned {skill_name}!\n\nSource: {url}\n\nGenerated Code:\n```python\n{code}\n```"
    
    def handle_evolution_request(self, request: str):
        """
        Handle user request to improve or add feature.
        """
        if "learn" in request.lower() or "how to" in request.lower():
            return self.learn_skill(request)
        return "Evolution request not understood."