#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 MODEL MANAGER - LLM MODEL LIFECYCLE
═══════════════════════════════════════════════════════════════════════════════

 Manages Ollama model loading, switching, and optimization.
 
 FEATURES:
 ─────────
 • Auto-detect best model based on system resources
 • Model switching at runtime
 • Model profiles for different tasks
 • Model warm-up (pre-load)
 • Usage statistics
 • Fallback handling
 
 MODEL PROFILES:
 ───────────────
 • thinking     - Low temperature, precise (for reasoning)
 • creative     - Higher temperature (for generation)
 • fast         - Smaller model (for quick responses)
 • code         - Code-specialized model
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
import psutil
from datetime import datetime
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
from enum import Enum

from llm.ollama_client import OllamaClient, ModelInfo


class ModelProfile(Enum):
    """Pre-configured model settings for different tasks."""
    THINKING = "thinking"       # Analytical, precise
    CREATIVE = "creative"       # Creative, varied
    FAST = "fast"              # Quick responses
    CODE = "code"              # Code generation
    CONVERSATION = "conversation"  # Natural dialogue


@dataclass
class ProfileConfig:
    """Configuration for a model profile."""
    name: str
    temperature: float
    top_p: float
    max_tokens: int
    preferred_models: List[str]
    description: str


@dataclass
class ModelUsage:
    """Track model usage statistics."""
    model_name: str
    requests: int = 0
    tokens_in: int = 0
    tokens_out: int = 0
    errors: int = 0
    last_used: Optional[datetime] = None
    total_duration_ms: int = 0


class ModelManager:
    """
    ═══════════════════════════════════════════════════════════════════════════
    MODEL LIFECYCLE MANAGER
    ═══════════════════════════════════════════════════════════════════════════
    
    Manages model selection, profiles, and optimization.
    """
    
    # Profile configurations
    PROFILES: Dict[ModelProfile, ProfileConfig] = {
        ModelProfile.THINKING: ProfileConfig(
            name="thinking",
            temperature=0.3,
            top_p=0.85,
            max_tokens=2048,
            preferred_models=["llama3:8b", "mistral:7b", "neural-chat:7b"],
            description="Precise, analytical responses"
        ),
        ModelProfile.CREATIVE: ProfileConfig(
            name="creative",
            temperature=0.8,
            top_p=0.95,
            max_tokens=4096,
            preferred_models=["llama3:8b", "mistral:7b"],
            description="Creative, varied responses"
        ),
        ModelProfile.FAST: ProfileConfig(
            name="fast",
            temperature=0.5,
            top_p=0.9,
            max_tokens=512,
            preferred_models=["phi3:mini", "tinyllama:1b", "gemma:2b"],
            description="Quick responses, smaller models"
        ),
        ModelProfile.CODE: ProfileConfig(
            name="code",
            temperature=0.2,
            top_p=0.9,
            max_tokens=4096,
            preferred_models=["codellama:7b", "deepseek-coder:6.7b", "llama3:8b"],
            description="Code generation and analysis"
        ),
        ModelProfile.CONVERSATION: ProfileConfig(
            name="conversation",
            temperature=0.7,
            top_p=0.9,
            max_tokens=1024,
            preferred_models=["llama3:8b", "mistral:7b", "neural-chat:7b"],
            description="Natural conversation"
        ),
    }
    
    # Model recommendations based on available RAM (GB)
    RAM_RECOMMENDATIONS = {
        32: ["llama3:70b", "mixtral:8x7b", "llama3:8b"],
        16: ["llama3:8b", "mistral:7b", "codellama:7b"],
        8: ["llama3:8b", "mistral:7b", "phi3:medium"],
        4: ["phi3:mini", "gemma:2b", "tinyllama:1b"],
        2: ["tinyllama:1b", "phi3:mini"],
    }
    
    def __init__(self, ollama: OllamaClient, config: Dict[str, Any] = None):
        """
        Initialize model manager.
        
        Args:
            ollama: Ollama client instance
            config: Configuration dictionary
        """
        self.logger = logging.getLogger("llm.model_manager")
        self.ollama = ollama
        self.config = config or {}
        
        # Current state
        self.current_model: Optional[str] = None
        self.current_profile: ModelProfile = ModelProfile.THINKING
        self.available_models: List[ModelInfo] = []
        
        # Usage tracking
        self.usage: Dict[str, ModelUsage] = {}
        
        # Fallback model
        self.fallback_model: Optional[str] = None
        
    async def initialize(self) -> None:
        """Initialize model manager."""
        self.logger.info("Initializing model manager")
        
        # Get available models from client
        self.available_models = self.ollama.available_models
        
        # Auto-select best model if not configured
        configured_model = self.config.get('model')
        
        if configured_model:
            if self._model_available(configured_model):
                self.current_model = configured_model
            else:
                self.logger.warning(f"Configured model {configured_model} not available")
                self.current_model = await self._auto_select_model()
        else:
            self.current_model = await self._auto_select_model()
            
        # Set on client
        self.ollama.current_model = self.current_model
        
        # Set fallback
        self.fallback_model = await self._select_fallback()
        
        # Initialize usage tracking
        for model in self.available_models:
            self.usage[model.name] = ModelUsage(model_name=model.name)
            
        self.logger.info(f"Model manager ready. Current: {self.current_model}, Fallback: {self.fallback_model}")
        
    async def _auto_select_model(self) -> Optional[str]:
        """
        Auto-select the best model based on system resources.
        
        Returns:
            Name of selected model or None
        """
        if not self.available_models:
            self.logger.warning("No models available for auto-selection")
            return None
            
        available_names = [m.name for m in self.available_models]
        
        # Get system RAM
        ram_gb = psutil.virtual_memory().total / (1024 ** 3)
        self.logger.info(f"System RAM: {ram_gb:.1f} GB")
        
        # Find appropriate tier
        for ram_threshold in sorted(self.RAM_RECOMMENDATIONS.keys(), reverse=True):
            if ram_gb >= ram_threshold:
                recommendations = self.RAM_RECOMMENDATIONS[ram_threshold]
                
                for recommended in recommendations:
                    # Check exact match
                    if recommended in available_names:
                        self.logger.info(f"Auto-selected: {recommended} (exact match)")
                        return recommended
                        
                    # Check partial match (model family)
                    recommended_base = recommended.split(':')[0]
                    for available in available_names:
                        if recommended_base in available:
                            self.logger.info(f"Auto-selected: {available} (family match for {recommended})")
                            return available
                            
                break
                
        # Fallback to first available
        if available_names:
            self.logger.info(f"Auto-selected: {available_names[0]} (first available)")
            return available_names[0]
            
        return None
        
    async def _select_fallback(self) -> Optional[str]:
        """Select a fallback model (smaller/faster)."""
        if not self.available_models:
            return None
            
        available_names = [m.name for m in self.available_models]
        
        # Prefer smaller models for fallback
        fallback_preferences = ["phi3:mini", "tinyllama:1b", "gemma:2b"]
        
        for preferred in fallback_preferences:
            if preferred in available_names and preferred != self.current_model:
                return preferred
            # Partial match
            for available in available_names:
                if preferred.split(':')[0] in available and available != self.current_model:
                    return available
                    
        # Use any model different from current
        for model in available_names:
            if model != self.current_model:
                return model
                
        # Same model as fallback (better than nothing)
        return self.current_model
        
    def _model_available(self, model_name: str) -> bool:
        """Check if a model is available."""
        available_names = [m.name for m in self.available_models]
        return model_name in available_names
        
    async def switch_model(self, model_name: str) -> bool:
        """
        Switch to a different model.
        
        Args:
            model_name: Name of model to switch to
            
        Returns:
            True if switch successful
        """
        if not self._model_available(model_name):
            self.logger.error(f"Model {model_name} not available")
            return False
            
        old_model = self.current_model
        self.current_model = model_name
        self.ollama.current_model = model_name
        
        self.logger.info(f"Switched model: {old_model} → {model_name}")
        return True
        
    async def use_profile(self, profile: ModelProfile) -> Dict[str, Any]:
        """
        Get settings for a model profile.
        
        Args:
            profile: The profile to use
            
        Returns:
            Dictionary with model settings
        """
        config = self.PROFILES[profile]
        self.current_profile = profile
        
        # Check if we should switch models
        available_names = [m.name for m in self.available_models]
        best_model = None
        
        for preferred in config.preferred_models:
            if preferred in available_names:
                best_model = preferred
                break
            # Partial match
            for available in available_names:
                if preferred.split(':')[0] in available:
                    best_model = available
                    break
            if best_model:
                break
                
        return {
            'model': best_model or self.current_model,
            'temperature': config.temperature,
            'top_p': config.top_p,
            'max_tokens': config.max_tokens,
            'profile': profile.value,
        }
        
    async def generate_with_fallback(
        self,
        prompt: str,
        system: Optional[str] = None,
        profile: Optional[ModelProfile] = None,
        **kwargs
    ) -> 'GenerateResponse':
        """
        Generate with automatic fallback on failure.
        
        Args:
            prompt: The prompt
            system: System prompt
            profile: Optional profile to use
            **kwargs: Additional generation parameters
            
        Returns:
            GenerateResponse
        """
        # Apply profile settings
        if profile:
            settings = await self.use_profile(profile)
            kwargs = {**settings, **kwargs}
            model = settings.get('model', self.current_model)
        else:
            model = kwargs.pop('model', self.current_model)
            
        # Try primary model
        response = await self.ollama.generate(
            prompt=prompt,
            model=model,
            system=system,
            **kwargs
        )
        
        # Track usage
        self._track_usage(model, response)
        
        # Check for error
        if response.error and self.fallback_model and self.fallback_model != model:
            self.logger.warning(f"Primary model failed, trying fallback: {self.fallback_model}")
            
            response = await self.ollama.generate(
                prompt=prompt,
                model=self.fallback_model,
                system=system,
                **kwargs
            )
            
            self._track_usage(self.fallback_model, response)
            
        return response
        
    def _track_usage(self, model: str, response: 'GenerateResponse') -> None:
        """Track model usage statistics."""
        if model not in self.usage:
            self.usage[model] = ModelUsage(model_name=model)
            
        usage = self.usage[model]
        usage.requests += 1
        usage.last_used = datetime.utcnow()
        
        if response.error:
            usage.errors += 1
        else:
            if response.prompt_eval_count:
                usage.tokens_in += response.prompt_eval_count
            if response.eval_count:
                usage.tokens_out += response.eval_count
            if response.total_duration:
                usage.total_duration_ms += response.total_duration // 1_000_000
                
    async def warm_up(self, model: Optional[str] = None) -> bool:
        """
        Warm up a model by running a simple generation.
        
        Args:
            model: Model to warm up (defaults to current)
            
        Returns:
            True if warm-up successful
        """
        model = model or self.current_model
        
        if not model:
            return False
            
        self.logger.info(f"Warming up model: {model}")
        
        response = await self.ollama.generate(
            prompt="Hello",
            model=model,
            max_tokens=5,
        )
        
        return response.error is None
        
    def get_model_info(self, model_name: Optional[str] = None) -> Optional[ModelInfo]:
        """Get information about a model."""
        model_name = model_name or self.current_model
        
        for model in self.available_models:
            if model.name == model_name:
                return model
                
        return None
        
    def list_models(self) -> List[Dict[str, Any]]:
        """List all available models with info."""
        result = []
        
        for model in self.available_models:
            usage = self.usage.get(model.name, ModelUsage(model_name=model.name))
            
            result.append({
                'name': model.name,
                'size_gb': round(model.size / (1024 ** 3), 2),
                'family': model.family,
                'parameter_size': model.parameter_size,
                'is_current': model.name == self.current_model,
                'is_fallback': model.name == self.fallback_model,
                'requests': usage.requests,
                'errors': usage.errors,
            })
            
        return result
        
    def get_usage_stats(self) -> Dict[str, Any]:
        """Get usage statistics for all models."""
        total_requests = sum(u.requests for u in self.usage.values())
        total_errors = sum(u.errors for u in self.usage.values())
        total_tokens_in = sum(u.tokens_in for u in self.usage.values())
        total_tokens_out = sum(u.tokens_out for u in self.usage.values())
        
        return {
            'current_model': self.current_model,
            'fallback_model': self.fallback_model,
            'current_profile': self.current_profile.value,
            'models_available': len(self.available_models),
            'total_requests': total_requests,
            'total_errors': total_errors,
            'error_rate': total_errors / total_requests if total_requests > 0 else 0,
            'total_tokens_in': total_tokens_in,
            'total_tokens_out': total_tokens_out,
            'by_model': {
                name: {
                    'requests': usage.requests,
                    'tokens_in': usage.tokens_in,
                    'tokens_out': usage.tokens_out,
                    'errors': usage.errors,
                    'last_used': usage.last_used.isoformat() if usage.last_used else None,
                }
                for name, usage in self.usage.items()
            }
        }
        
    async def pull_recommended(self) -> List[str]:
        """
        Pull recommended models that aren't available.
        
        Returns:
            List of models pulled
        """
        pulled = []
        available_names = [m.name for m in self.available_models]
        
        # Get system RAM
        ram_gb = psutil.virtual_memory().total / (1024 ** 3)
        
        # Find appropriate recommendations
        for ram_threshold in sorted(self.RAM_RECOMMENDATIONS.keys(), reverse=True):
            if ram_gb >= ram_threshold:
                recommendations = self.RAM_RECOMMENDATIONS[ram_threshold]
                
                # Try to pull first recommended that's missing
                for recommended in recommendations[:2]:  # Max 2 models
                    if recommended not in available_names:
                        self.logger.info(f"Pulling recommended model: {recommended}")
                        if await self.ollama.pull_model(recommended):
                            pulled.append(recommended)
                            
                break
                
        # Refresh available models
        await self.ollama.refresh_models()
        self.available_models = self.ollama.available_models
        
        return pulled