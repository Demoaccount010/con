"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                         IDENTITY MANAGER                                      ║
║              Central Manager for Agent and Owner Identity                     ║
╚══════════════════════════════════════════════════════════════════════════════╝

The Identity Manager handles:
- Agent's self-identity and awareness
- Owner profile and preferences
- Relationship between agent and owner
- First-run identity setup
- Personality configuration
"""

import asyncio
import logging
from datetime import datetime
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
import json
import yaml

logger = logging.getLogger(__name__)


class IdentityStatus(Enum):
    """Status of identity setup"""
    NOT_CONFIGURED = "not_configured"
    PARTIAL = "partial"
    CONFIGURED = "configured"
    VERIFIED = "verified"


class RelationshipLevel(Enum):
    """Level of relationship with owner"""
    NEW = "new"                     # Just met
    ACQUAINTANCE = "acquaintance"   # Basic interactions
    FAMILIAR = "familiar"           # Regular interactions
    TRUSTED = "trusted"             # Deep trust established
    PARTNER = "partner"             # Full collaboration


@dataclass
class AgentIdentity:
    """Agent's identity configuration"""
    name: str = "Axiom"
    version: str = "3.0.0"
    description: str = "Autonomous AI Agent"
    
    # Personality
    personality_type: str = "helpful"
    communication_style: str = "balanced"
    
    # Capabilities
    primary_purpose: str = "assist and automate"
    specializations: List[str] = field(default_factory=list)
    
    # Values
    core_values: List[str] = field(default_factory=lambda: [
        "honesty",
        "helpfulness", 
        "accuracy",
        "learning",
        "respect"
    ])
    
    # Metadata
    created_at: Optional[datetime] = None
    last_updated: Optional[datetime] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "personality_type": self.personality_type,
            "communication_style": self.communication_style,
            "primary_purpose": self.primary_purpose,
            "specializations": self.specializations,
            "core_values": self.core_values,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "last_updated": self.last_updated.isoformat() if self.last_updated else None
        }


@dataclass
class OwnerIdentity:
    """Owner's identity and preferences"""
    # Basic info
    name: Optional[str] = None
    preferred_name: Optional[str] = None
    user_id: Optional[str] = None
    
    # Preferences
    communication_style: str = "balanced"
    formality_level: str = "balanced"
    verbosity: str = "normal"
    
    # Settings
    timezone: Optional[str] = None
    language: str = "en"
    
    # Metadata
    first_interaction: Optional[datetime] = None
    last_interaction: Optional[datetime] = None
    total_interactions: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "preferred_name": self.preferred_name,
            "user_id": self.user_id,
            "communication_style": self.communication_style,
            "formality_level": self.formality_level,
            "verbosity": self.verbosity,
            "timezone": self.timezone,
            "language": self.language,
            "first_interaction": self.first_interaction.isoformat() if self.first_interaction else None,
            "last_interaction": self.last_interaction.isoformat() if self.last_interaction else None,
            "total_interactions": self.total_interactions
        }
    
    @property
    def display_name(self) -> str:
        """Get name to use when addressing owner"""
        return self.preferred_name or self.name or "there"


@dataclass
class Relationship:
    """Relationship between agent and owner"""
    level: RelationshipLevel = RelationshipLevel.NEW
    trust_score: float = 0.5
    
    # Interaction history
    positive_interactions: int = 0
    negative_interactions: int = 0
    corrections_received: int = 0
    teachings_received: int = 0
    
    # Milestones
    milestones: List[Dict[str, Any]] = field(default_factory=list)
    
    # Timestamps
    relationship_started: Optional[datetime] = None
    last_interaction: Optional[datetime] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "level": self.level.value,
            "trust_score": self.trust_score,
            "positive_interactions": self.positive_interactions,
            "negative_interactions": self.negative_interactions,
            "corrections_received": self.corrections_received,
            "teachings_received": self.teachings_received,
            "milestones": self.milestones,
            "relationship_started": self.relationship_started.isoformat() if self.relationship_started else None,
            "last_interaction": self.last_interaction.isoformat() if self.last_interaction else None
        }


@dataclass
class IdentityConfig:
    """Configuration for identity manager"""
    # Storage
    data_directory: str = "identity/permanent_data"
    agent_file: str = "agent_identity.yaml"
    owner_file: str = "owner_profile.yaml"
    relationship_file: str = "relationship.yaml"
    
    # First run
    first_run_flag: str = "first_run_complete.flag"
    
    # Defaults
    default_agent_name: str = "Axiom"
    default_communication_style: str = "balanced"
    
    # Relationship thresholds
    familiar_threshold: int = 50      # interactions
    trusted_threshold: int = 200
    partner_threshold: int = 500


class IdentityManager:
    """
    Central manager for agent and owner identity
    
    Features:
    - Agent self-identity management
    - Owner profile management
    - Relationship tracking
    - First-run setup
    - Persistence
    """
    
    def __init__(
        self,
        config: Optional[IdentityConfig] = None,
        memory_manager: Optional[Any] = None
    ):
        self.config = config or IdentityConfig()
        self.memory_manager = memory_manager
        
        # Identity components
        self._agent: Optional[AgentIdentity] = None
        self._owner: Optional[OwnerIdentity] = None
        self._relationship: Optional[Relationship] = None
        
        # Status
        self._status = IdentityStatus.NOT_CONFIGURED
        self._first_run_complete = False
        
        # Data directory
        self._data_dir = Path(self.config.data_directory)
        self._data_dir.mkdir(parents=True, exist_ok=True)
        
        # Statistics
        self._stats = {
            "identity_loads": 0,
            "identity_saves": 0,
            "relationship_updates": 0
        }
        
        logger.info("IdentityManager initialized")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # INITIALIZATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def initialize(self) -> IdentityStatus:
        """Initialize identity system"""
        # Check first run flag
        flag_path = self._data_dir / self.config.first_run_flag
        self._first_run_complete = flag_path.exists()
        
        # Load existing identities
        await self._load_agent_identity()
        await self._load_owner_identity()
        await self._load_relationship()
        
        # Determine status
        self._status = self._determine_status()
        
        logger.info(f"Identity initialized: {self._status.value}")
        return self._status
    
    def _determine_status(self) -> IdentityStatus:
        """Determine current identity status"""
        if not self._agent:
            return IdentityStatus.NOT_CONFIGURED
        
        if not self._owner or not self._owner.name:
            return IdentityStatus.PARTIAL
        
        if self._first_run_complete:
            return IdentityStatus.VERIFIED
        
        return IdentityStatus.CONFIGURED
    
    @property
    def is_first_run(self) -> bool:
        """Check if this is first run"""
        return not self._first_run_complete
    
    @property
    def is_configured(self) -> bool:
        """Check if identity is configured"""
        return self._status in [IdentityStatus.CONFIGURED, IdentityStatus.VERIFIED]
    
    # ═══════════════════════════════════════════════════════════════════════════
    # AGENT IDENTITY
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def get_agent_identity(self) -> AgentIdentity:
        """Get agent's identity"""
        if not self._agent:
            self._agent = AgentIdentity(
                name=self.config.default_agent_name,
                created_at=datetime.now()
            )
        return self._agent
    
    async def set_agent_name(self, name: str) -> None:
        """Set agent's name"""
        agent = await self.get_agent_identity()
        agent.name = name
        agent.last_updated = datetime.now()
        await self._save_agent_identity()
    
    async def set_agent_personality(
        self,
        personality_type: Optional[str] = None,
        communication_style: Optional[str] = None
    ) -> None:
        """Set agent's personality"""
        agent = await self.get_agent_identity()
        
        if personality_type:
            agent.personality_type = personality_type
        if communication_style:
            agent.communication_style = communication_style
        
        agent.last_updated = datetime.now()
        await self._save_agent_identity()
    
    async def add_specialization(self, specialization: str) -> None:
        """Add agent specialization"""
        agent = await self.get_agent_identity()
        if specialization not in agent.specializations:
            agent.specializations.append(specialization)
            agent.last_updated = datetime.now()
            await self._save_agent_identity()
    
    async def get_agent_introduction(self) -> str:
        """Get agent's introduction text"""
        agent = await self.get_agent_identity()
        
        intro = f"I'm {agent.name}, {agent.description}."
        
        if agent.specializations:
            specs = ", ".join(agent.specializations[:3])
            intro += f" I specialize in {specs}."
        
        intro += f" My purpose is to {agent.primary_purpose}."
        
        return intro
    
    # ═══════════════════════════════════════════════════════════════════════════
    # OWNER IDENTITY
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def get_owner_identity(self) -> OwnerIdentity:
        """Get owner's identity"""
        if not self._owner:
            self._owner = OwnerIdentity()
        return self._owner
    
    async def set_owner_name(
        self,
        name: str,
        preferred_name: Optional[str] = None
    ) -> None:
        """Set owner's name"""
        owner = await self.get_owner_identity()
        owner.name = name
        if preferred_name:
            owner.preferred_name = preferred_name
        
        if not owner.first_interaction:
            owner.first_interaction = datetime.now()
        
        await self._save_owner_identity()
        
        # Store in permanent memory
        if self.memory_manager:
            await self.memory_manager.store_memory(
                content={"owner_name": name, "preferred_name": preferred_name},
                memory_type="permanent",
                tags=["owner", "identity"]
            )
    
    async def set_owner_preferences(
        self,
        communication_style: Optional[str] = None,
        formality_level: Optional[str] = None,
        verbosity: Optional[str] = None,
        timezone: Optional[str] = None,
        language: Optional[str] = None
    ) -> None:
        """Set owner preferences"""
        owner = await self.get_owner_identity()
        
        if communication_style:
            owner.communication_style = communication_style
        if formality_level:
            owner.formality_level = formality_level
        if verbosity:
            owner.verbosity = verbosity
        if timezone:
            owner.timezone = timezone
        if language:
            owner.language = language
        
        await self._save_owner_identity()
    
    async def get_owner_name(self) -> str:
        """Get owner's display name"""
        owner = await self.get_owner_identity()
        return owner.display_name
    
    async def record_owner_interaction(self) -> None:
        """Record an interaction with owner"""
        owner = await self.get_owner_identity()
        owner.total_interactions += 1
        owner.last_interaction = datetime.now()
        
        # Update relationship
        await self._update_relationship_level()
        
        # Save periodically (not every interaction)
        if owner.total_interactions % 10 == 0:
            await self._save_owner_identity()
            await self._save_relationship()
    
    # ═══════════════════════════════════════════════════════════════════════════
    # RELATIONSHIP
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def get_relationship(self) -> Relationship:
        """Get relationship status"""
        if not self._relationship:
            self._relationship = Relationship(
                relationship_started=datetime.now()
            )
        return self._relationship
    
    async def record_positive_interaction(self) -> None:
        """Record positive interaction"""
        rel = await self.get_relationship()
        rel.positive_interactions += 1
        rel.last_interaction = datetime.now()
        
        # Increase trust
        rel.trust_score = min(1.0, rel.trust_score + 0.01)
        
        self._stats["relationship_updates"] += 1
        await self._update_relationship_level()
    
    async def record_negative_interaction(self) -> None:
        """Record negative interaction"""
        rel = await self.get_relationship()
        rel.negative_interactions += 1
        rel.last_interaction = datetime.now()
        
        # Decrease trust slightly
        rel.trust_score = max(0.1, rel.trust_score - 0.02)
        
        self._stats["relationship_updates"] += 1
    
    async def record_correction(self) -> None:
        """Record a correction from owner"""
        rel = await self.get_relationship()
        rel.corrections_received += 1
        
        # Corrections are learning opportunities, slight trust increase
        rel.trust_score = min(1.0, rel.trust_score + 0.005)
    
    async def record_teaching(self) -> None:
        """Record teaching from owner"""
        rel = await self.get_relationship()
        rel.teachings_received += 1
        
        # Teaching builds trust
        rel.trust_score = min(1.0, rel.trust_score + 0.02)
        
        # Check for milestone
        if rel.teachings_received in [5, 10, 25, 50, 100]:
            await self._add_milestone(
                f"Received {rel.teachings_received} teachings from owner"
            )
    
    async def _update_relationship_level(self) -> None:
        """Update relationship level based on interactions"""
        rel = await self.get_relationship()
        owner = await self.get_owner_identity()
        
        total = owner.total_interactions
        old_level = rel.level
        
        if total >= self.config.partner_threshold:
            rel.level = RelationshipLevel.PARTNER
        elif total >= self.config.trusted_threshold:
            rel.level = RelationshipLevel.TRUSTED
        elif total >= self.config.familiar_threshold:
            rel.level = RelationshipLevel.FAMILIAR
        elif total >= 10:
            rel.level = RelationshipLevel.ACQUAINTANCE
        else:
            rel.level = RelationshipLevel.NEW
        
        # Record milestone if level changed
        if rel.level != old_level:
            await self._add_milestone(
                f"Relationship upgraded to {rel.level.value}"
            )
    
    async def _add_milestone(self, description: str) -> None:
        """Add a relationship milestone"""
        rel = await self.get_relationship()
        rel.milestones.append({
            "description": description,
            "timestamp": datetime.now().isoformat()
        })
        
        logger.info(f"Relationship milestone: {description}")
    
    async def get_trust_level(self) -> float:
        """Get current trust level (0-1)"""
        rel = await self.get_relationship()
        return rel.trust_score
    
    async def is_trusted(self) -> bool:
        """Check if relationship is trusted"""
        rel = await self.get_relationship()
        return rel.level in [RelationshipLevel.TRUSTED, RelationshipLevel.PARTNER]
    
    # ═══════════════════════════════════════════════════════════════════════════
    # FIRST RUN SETUP
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def get_first_run_questions(self) -> List[Dict[str, Any]]:
        """Get questions for first run setup"""
        questions = []
        
        # Owner name
        if not self._owner or not self._owner.name:
            questions.append({
                "key": "owner_name",
                "question": "What should I call you?",
                "type": "text",
                "required": True,
                "category": "owner"
            })
        
        # Agent name customization
        questions.append({
            "key": "agent_name",
            "question": f"My default name is '{self.config.default_agent_name}'. Would you like to change it?",
            "type": "text",
            "required": False,
            "default": self.config.default_agent_name,
            "category": "agent"
        })
        
        # Communication style
        questions.append({
            "key": "communication_style",
            "question": "How would you like me to communicate?",
            "type": "choice",
            "options": ["Casual & friendly", "Professional & formal", "Balanced"],
            "default": "Balanced",
            "category": "preferences"
        })
        
        # Show reasoning
        questions.append({
            "key": "show_reasoning",
            "question": "Should I explain my reasoning when answering?",
            "type": "choice",
            "options": ["Yes, always", "Only when asked", "No, keep it brief"],
            "default": "Only when asked",
            "category": "preferences"
        })
        
        # Notifications
        questions.append({
            "key": "notify_learnings",
            "question": "Should I notify you when I learn something new?",
            "type": "choice",
            "options": ["Yes", "Only important discoveries", "No"],
            "default": "Only important discoveries",
            "category": "preferences"
        })
        
        return questions
    
    async def process_first_run_answers(
        self,
        answers: Dict[str, Any]
    ) -> None:
        """Process answers from first run questions"""
        # Owner name
        if "owner_name" in answers and answers["owner_name"]:
            await self.set_owner_name(answers["owner_name"])
        
        # Agent name
        if "agent_name" in answers and answers["agent_name"]:
            await self.set_agent_name(answers["agent_name"])
        
        # Communication style
        if "communication_style" in answers:
            style_map = {
                "Casual & friendly": "casual",
                "Professional & formal": "formal",
                "Balanced": "balanced"
            }
            style = style_map.get(answers["communication_style"], "balanced")
            await self.set_owner_preferences(communication_style=style)
            await self.set_agent_personality(communication_style=style)
        
        # Store other preferences
        if self.memory_manager:
            prefs = {
                "show_reasoning": answers.get("show_reasoning", "Only when asked"),
                "notify_learnings": answers.get("notify_learnings", "Only important discoveries")
            }
            await self.memory_manager.store_memory(
                content=prefs,
                memory_type="permanent",
                tags=["preferences", "first_run"]
            )
    
    async def mark_first_run_complete(self) -> None:
        """Mark first run as complete"""
        flag_path = self._data_dir / self.config.first_run_flag
        flag_path.write_text(datetime.now().isoformat())
        
        self._first_run_complete = True
        self._status = IdentityStatus.VERIFIED
        
        # Add milestone
        await self._add_milestone("First run setup completed")
        
        # Save everything
        await self._save_all()
        
        logger.info("First run marked complete")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PERSISTENCE
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _load_agent_identity(self) -> None:
        """Load agent identity from file"""
        path = self._data_dir / self.config.agent_file
        
        if path.exists():
            try:
                with open(path, 'r') as f:
                    data = yaml.safe_load(f)
                
                self._agent = AgentIdentity(
                    name=data.get("name", self.config.default_agent_name),
                    version=data.get("version", "3.0.0"),
                    description=data.get("description", "Autonomous AI Agent"),
                    personality_type=data.get("personality_type", "helpful"),
                    communication_style=data.get("communication_style", "balanced"),
                    primary_purpose=data.get("primary_purpose", "assist and automate"),
                    specializations=data.get("specializations", []),
                    core_values=data.get("core_values", [])
                )
                
                if data.get("created_at"):
                    self._agent.created_at = datetime.fromisoformat(data["created_at"])
                
                self._stats["identity_loads"] += 1
                logger.debug("Agent identity loaded")
                
            except Exception as e:
                logger.error(f"Failed to load agent identity: {e}")
    
    async def _save_agent_identity(self) -> None:
        """Save agent identity to file"""
        if not self._agent:
            return
        
        path = self._data_dir / self.config.agent_file
        
        try:
            with open(path, 'w') as f:
                yaml.dump(self._agent.to_dict(), f, default_flow_style=False)
            
            self._stats["identity_saves"] += 1
            logger.debug("Agent identity saved")
            
        except Exception as e:
            logger.error(f"Failed to save agent identity: {e}")
    
    async def _load_owner_identity(self) -> None:
        """Load owner identity from file"""
        path = self._data_dir / self.config.owner_file
        
        if path.exists():
            try:
                with open(path, 'r') as f:
                    data = yaml.safe_load(f)
                
                self._owner = OwnerIdentity(
                    name=data.get("name"),
                    preferred_name=data.get("preferred_name"),
                    user_id=data.get("user_id"),
                    communication_style=data.get("communication_style", "balanced"),
                    formality_level=data.get("formality_level", "balanced"),
                    verbosity=data.get("verbosity", "normal"),
                    timezone=data.get("timezone"),
                    language=data.get("language", "en"),
                    total_interactions=data.get("total_interactions", 0)
                )
                
                if data.get("first_interaction"):
                    self._owner.first_interaction = datetime.fromisoformat(data["first_interaction"])
                if data.get("last_interaction"):
                    self._owner.last_interaction = datetime.fromisoformat(data["last_interaction"])
                
                self._stats["identity_loads"] += 1
                logger.debug("Owner identity loaded")
                
            except Exception as e:
                logger.error(f"Failed to load owner identity: {e}")
    
    async def _save_owner_identity(self) -> None:
        """Save owner identity to file"""
        if not self._owner:
            return
        
        path = self._data_dir / self.config.owner_file
        
        try:
            with open(path, 'w') as f:
                yaml.dump(self._owner.to_dict(), f, default_flow_style=False)
            
            self._stats["identity_saves"] += 1
            logger.debug("Owner identity saved")
            
        except Exception as e:
            logger.error(f"Failed to save owner identity: {e}")
    
    async def _load_relationship(self) -> None:
        """Load relationship from file"""
        path = self._data_dir / self.config.relationship_file
        
        if path.exists():
            try:
                with open(path, 'r') as f:
                    data = yaml.safe_load(f)
                
                self._relationship = Relationship(
                    level=RelationshipLevel(data.get("level", "new")),
                    trust_score=data.get("trust_score", 0.5),
                    positive_interactions=data.get("positive_interactions", 0),
                    negative_interactions=data.get("negative_interactions", 0),
                    corrections_received=data.get("corrections_received", 0),
                    teachings_received=data.get("teachings_received", 0),
                    milestones=data.get("milestones", [])
                )
                
                if data.get("relationship_started"):
                    self._relationship.relationship_started = datetime.fromisoformat(data["relationship_started"])
                
                logger.debug("Relationship loaded")
                
            except Exception as e:
                logger.error(f"Failed to load relationship: {e}")
    
    async def _save_relationship(self) -> None:
        """Save relationship to file"""
        if not self._relationship:
            return
        
        path = self._data_dir / self.config.relationship_file
        
        try:
            with open(path, 'w') as f:
                yaml.dump(self._relationship.to_dict(), f, default_flow_style=False)
            
            logger.debug("Relationship saved")
            
        except Exception as e:
            logger.error(f"Failed to save relationship: {e}")
    
    async def _save_all(self) -> None:
        """Save all identity data"""
        await self._save_agent_identity()
        await self._save_owner_identity()
        await self._save_relationship()
    
    # ═══════════════════════════════════════════════════════════════════════════
    # UTILITIES
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def get_identity_summary(self) -> Dict[str, Any]:
        """Get summary of all identity information"""
        agent = await self.get_agent_identity()
        owner = await self.get_owner_identity()
        rel = await self.get_relationship()
        
        return {
            "status": self._status.value,
            "first_run_complete": self._first_run_complete,
            "agent": {
                "name": agent.name,
                "personality": agent.personality_type,
                "style": agent.communication_style
            },
            "owner": {
                "name": owner.display_name,
                "style": owner.communication_style,
                "interactions": owner.total_interactions
            },
            "relationship": {
                "level": rel.level.value,
                "trust": rel.trust_score,
                "milestones": len(rel.milestones)
            }
        }
    
    def get_stats(self) -> Dict[str, Any]:
        """Get manager statistics"""
        return {
            **self._stats,
            "status": self._status.value,
            "first_run_complete": self._first_run_complete
        }


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

async def create_identity_manager(
    memory_manager: Optional[Any] = None,
    data_directory: str = "identity/permanent_data",
    **kwargs
) -> IdentityManager:
    """Create and initialize identity manager"""
    config = IdentityConfig(
        data_directory=data_directory,
        **kwargs
    )
    
    manager = IdentityManager(
        config=config,
        memory_manager=memory_manager
    )
    
    await manager.initialize()
    
    return manager