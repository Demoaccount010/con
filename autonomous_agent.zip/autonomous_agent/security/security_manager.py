"""
═══════════════════════════════════════════════════════════════════════════════════════
SECURITY MANAGER - CENTRAL SECURITY CONTROL
═══════════════════════════════════════════════════════════════════════════════════════
Manages all security aspects of the agent:
- Command validation and filtering
- Permission management
- Rate limiting
- Audit logging
- Threat detection
- Secret management

SECURITY PHILOSOPHY:
- Deny by default for dangerous operations
- Always audit sensitive actions
- Never store secrets in plain text
- Limit blast radius of any potential breach
"""

import asyncio
import logging
import hashlib
import hmac
import secrets
import os
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Set, Tuple, Callable
from pathlib import Path
import json
import base64

logger = logging.getLogger(__name__)


class SecurityLevel(Enum):
    """Security levels for operations."""
    PUBLIC = 0       # No restrictions
    INTERNAL = 1     # Basic validation
    SENSITIVE = 2    # Requires confirmation
    CRITICAL = 3     # Requires explicit permission
    FORBIDDEN = 4    # Never allowed


class ThreatLevel(Enum):
    """Threat assessment levels."""
    NONE = 0
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4


class AuditEventType(Enum):
    """Types of audit events."""
    COMMAND_EXECUTED = auto()
    COMMAND_BLOCKED = auto()
    PERMISSION_GRANTED = auto()
    PERMISSION_DENIED = auto()
    AUTHENTICATION = auto()
    SECRET_ACCESS = auto()
    RATE_LIMIT_HIT = auto()
    THREAT_DETECTED = auto()
    CONFIG_CHANGE = auto()
    ERROR = auto()


@dataclass
class SecurityPolicy:
    """A security policy rule."""
    name: str
    description: str
    pattern: str  # Regex pattern
    level: SecurityLevel
    action: str  # "block", "confirm", "log", "allow"
    message: str = ""
    enabled: bool = True


@dataclass
class AuditEvent:
    """An audit log entry."""
    event_type: AuditEventType
    timestamp: datetime
    actor: str  # Who performed the action
    action: str
    target: Optional[str] = None
    result: str = ""
    details: Dict[str, Any] = field(default_factory=dict)
    threat_level: ThreatLevel = ThreatLevel.NONE
    event_id: str = ""
    
    def __post_init__(self):
        if not self.event_id:
            self.event_id = secrets.token_hex(8)


@dataclass
class RateLimitRule:
    """Rate limiting configuration."""
    name: str
    max_requests: int
    window_seconds: int
    current_count: int = 0
    window_start: datetime = field(default_factory=datetime.now)
    
    def check_and_increment(self) -> Tuple[bool, int]:
        """Check rate limit and increment counter."""
        now = datetime.now()
        
        # Reset window if expired
        if (now - self.window_start).total_seconds() >= self.window_seconds:
            self.window_start = now
            self.current_count = 0
        
        # Check limit
        if self.current_count >= self.max_requests:
            remaining = self.window_seconds - (now - self.window_start).total_seconds()
            return False, int(remaining)
        
        self.current_count += 1
        return True, 0


@dataclass
class Permission:
    """A permission grant."""
    name: str
    granted_to: str
    resource: str
    actions: List[str]
    expires_at: Optional[datetime] = None
    conditions: Dict[str, Any] = field(default_factory=dict)
    
    @property
    def is_expired(self) -> bool:
        if self.expires_at is None:
            return False
        return datetime.now() > self.expires_at


class CommandValidator:
    """Validates commands against security policies."""
    
    def __init__(self):
        self._policies: List[SecurityPolicy] = []
        self._setup_default_policies()
    
    def _setup_default_policies(self) -> None:
        """Setup default security policies."""
        self._policies = [
            # Forbidden operations
            SecurityPolicy(
                name="block_rm_rf",
                description="Block recursive force delete",
                pattern=r"rm\s+(-rf|-fr|--recursive\s+--force)",
                level=SecurityLevel.FORBIDDEN,
                action="block",
                message="Recursive force deletion is not allowed"
            ),
            SecurityPolicy(
                name="block_format",
                description="Block disk formatting",
                pattern=r"(mkfs|format)\s+",
                level=SecurityLevel.FORBIDDEN,
                action="block",
                message="Disk formatting is not allowed"
            ),
            SecurityPolicy(
                name="block_dd_danger",
                description="Block dangerous dd commands",
                pattern=r"dd\s+.*of=/dev/(sd|hd|nvme)",
                level=SecurityLevel.FORBIDDEN,
                action="block",
                message="Writing directly to disk devices is not allowed"
            ),
            
            # Critical operations (require explicit permission)
            SecurityPolicy(
                name="critical_sudo",
                description="Sudo commands require confirmation",
                pattern=r"^sudo\s+",
                level=SecurityLevel.CRITICAL,
                action="confirm",
                message="This command requires elevated privileges"
            ),
            SecurityPolicy(
                name="critical_shutdown",
                description="System shutdown requires confirmation",
                pattern=r"(shutdown|reboot|halt|poweroff)",
                level=SecurityLevel.CRITICAL,
                action="confirm",
                message="System shutdown/reboot requires confirmation"
            ),
            
            # Sensitive operations
            SecurityPolicy(
                name="sensitive_delete",
                description="Delete operations need confirmation",
                pattern=r"(rm|del|delete|remove)\s+",
                level=SecurityLevel.SENSITIVE,
                action="confirm",
                message="Delete operation requires confirmation"
            ),
            SecurityPolicy(
                name="sensitive_db_modify",
                description="Database modifications need confirmation",
                pattern=r"(DROP|TRUNCATE|DELETE\s+FROM|UPDATE\s+\w+\s+SET)",
                level=SecurityLevel.SENSITIVE,
                action="confirm",
                message="Database modification requires confirmation"
            ),
            
            # Logging operations
            SecurityPolicy(
                name="log_network",
                description="Log network operations",
                pattern=r"(curl|wget|nc|netcat|ssh|scp)",
                level=SecurityLevel.INTERNAL,
                action="log",
                message=""
            ),
        ]
    
    async def validate(
        self,
        command: str,
        context: Optional[Dict[str, Any]] = None
    ) -> Tuple[bool, SecurityLevel, str]:
        """
        Validate a command against security policies.
        
        Returns:
            Tuple of (allowed, security_level, message)
        """
        context = context or {}
        highest_level = SecurityLevel.PUBLIC
        block_message = ""
        
        for policy in self._policies:
            if not policy.enabled:
                continue
            
            if re.search(policy.pattern, command, re.IGNORECASE):
                if policy.level.value > highest_level.value:
                    highest_level = policy.level
                
                if policy.action == "block":
                    return False, policy.level, policy.message
                
                if policy.action == "confirm" and not context.get("confirmed"):
                    block_message = policy.message
        
        # If we need confirmation
        if highest_level in [SecurityLevel.SENSITIVE, SecurityLevel.CRITICAL]:
            if not context.get("confirmed"):
                return False, highest_level, block_message or "Confirmation required"
        
        return True, highest_level, ""
    
    def add_policy(self, policy: SecurityPolicy) -> None:
        """Add a security policy."""
        self._policies.append(policy)
        logger.info(f"Added security policy: {policy.name}")
    
    def remove_policy(self, name: str) -> bool:
        """Remove a security policy by name."""
        for i, policy in enumerate(self._policies):
            if policy.name == name:
                self._policies.pop(i)
                logger.info(f"Removed security policy: {name}")
                return True
        return False
    
    def get_policies(self) -> List[SecurityPolicy]:
        """Get all policies."""
        return self._policies.copy()


class PathValidator:
    """Validates file system paths."""
    
    def __init__(self):
        # Forbidden paths (absolute)
        self._forbidden_paths: Set[str] = {
            "/etc/shadow",
            "/etc/passwd",
            "/etc/sudoers",
            "/root/.ssh",
            "/proc",
            "/sys",
            "/dev",
        }
        
        # Allowed base paths
        self._allowed_paths: Set[str] = {
            os.path.expanduser("~"),
            "/tmp",
            "/var/tmp",
        }
        
        # Dangerous patterns
        self._dangerous_patterns = [
            r"\.\./",  # Path traversal
            r"^/etc/",
            r"^/boot/",
            r"^/root/",
        ]
    
    def validate(self, path: str) -> Tuple[bool, str]:
        """
        Validate a file path.
        
        Returns:
            Tuple of (allowed, reason)
        """
        # Normalize path
        try:
            normalized = os.path.normpath(os.path.abspath(path))
        except Exception as e:
            return False, f"Invalid path: {e}"
        
        # Check forbidden paths
        for forbidden in self._forbidden_paths:
            if normalized.startswith(forbidden):
                return False, f"Access to {forbidden} is forbidden"
        
        # Check dangerous patterns
        for pattern in self._dangerous_patterns:
            if re.search(pattern, path):
                return False, f"Path contains forbidden pattern"
        
        # Check if within allowed paths (if strict mode)
        # For now, just block obviously dangerous ones
        
        return True, ""
    
    def add_forbidden(self, path: str) -> None:
        """Add a forbidden path."""
        self._forbidden_paths.add(path)
    
    def add_allowed(self, path: str) -> None:
        """Add an allowed path."""
        self._allowed_paths.add(path)


class RateLimiter:
    """Rate limiting for operations."""
    
    def __init__(self):
        self._rules: Dict[str, RateLimitRule] = {}
        self._setup_default_rules()
    
    def _setup_default_rules(self) -> None:
        """Setup default rate limits."""
        self._rules = {
            "llm_requests": RateLimitRule(
                name="llm_requests",
                max_requests=60,
                window_seconds=60  # 60 per minute
            ),
            "tool_executions": RateLimitRule(
                name="tool_executions",
                max_requests=100,
                window_seconds=60  # 100 per minute
            ),
            "file_writes": RateLimitRule(
                name="file_writes",
                max_requests=50,
                window_seconds=60  # 50 per minute
            ),
            "network_requests": RateLimitRule(
                name="network_requests",
                max_requests=30,
                window_seconds=60  # 30 per minute
            ),
            "dangerous_commands": RateLimitRule(
                name="dangerous_commands",
                max_requests=5,
                window_seconds=300  # 5 per 5 minutes
            ),
        }
    
    def check(self, rule_name: str) -> Tuple[bool, int]:
        """
        Check rate limit.
        
        Returns:
            Tuple of (allowed, retry_after_seconds)
        """
        if rule_name not in self._rules:
            return True, 0
        
        return self._rules[rule_name].check_and_increment()
    
    def add_rule(self, rule: RateLimitRule) -> None:
        """Add a rate limit rule."""
        self._rules[rule.name] = rule
    
    def get_status(self) -> Dict[str, Dict[str, Any]]:
        """Get rate limit status for all rules."""
        status = {}
        for name, rule in self._rules.items():
            status[name] = {
                "max": rule.max_requests,
                "current": rule.current_count,
                "window": rule.window_seconds,
                "remaining": rule.max_requests - rule.current_count
            }
        return status


class AuditLogger:
    """Audit logging for security events."""
    
    def __init__(self, log_dir: Optional[Path] = None):
        self.log_dir = log_dir or Path("logs")
        self.log_dir.mkdir(parents=True, exist_ok=True)
        
        self._events: List[AuditEvent] = []
        self._max_memory_events = 10000
        
        # Setup file handler
        self._audit_file = self.log_dir / "security_audit.log"
    
    async def log(self, event: AuditEvent) -> None:
        """Log an audit event."""
        # Store in memory
        self._events.append(event)
        if len(self._events) > self._max_memory_events:
            self._events = self._events[-self._max_memory_events:]
        
        # Write to file
        try:
            log_line = json.dumps({
                "event_id": event.event_id,
                "type": event.event_type.name,
                "timestamp": event.timestamp.isoformat(),
                "actor": event.actor,
                "action": event.action,
                "target": event.target,
                "result": event.result,
                "threat_level": event.threat_level.name,
                "details": event.details
            })
            
            async with asyncio.Lock():
                with open(self._audit_file, "a") as f:
                    f.write(log_line + "\n")
                    
        except Exception as e:
            logger.error(f"Failed to write audit log: {e}")
        
        # Log high threat events to main logger
        if event.threat_level.value >= ThreatLevel.HIGH.value:
            logger.warning(
                f"HIGH THREAT AUDIT: {event.event_type.name} - "
                f"{event.action} by {event.actor}"
            )
    
    def get_events(
        self,
        limit: int = 100,
        event_type: Optional[AuditEventType] = None,
        min_threat: ThreatLevel = ThreatLevel.NONE
    ) -> List[AuditEvent]:
        """Get audit events with filtering."""
        events = self._events
        
        if event_type:
            events = [e for e in events if e.event_type == event_type]
        
        if min_threat.value > 0:
            events = [e for e in events if e.threat_level.value >= min_threat.value]
        
        return list(reversed(events[-limit:]))
    
    def get_stats(self) -> Dict[str, Any]:
        """Get audit statistics."""
        if not self._events:
            return {"total_events": 0}
        
        type_counts = {}
        threat_counts = {}
        
        for event in self._events:
            type_name = event.event_type.name
            type_counts[type_name] = type_counts.get(type_name, 0) + 1
            
            threat_name = event.threat_level.name
            threat_counts[threat_name] = threat_counts.get(threat_name, 0) + 1
        
        return {
            "total_events": len(self._events),
            "by_type": type_counts,
            "by_threat_level": threat_counts,
            "oldest_event": self._events[0].timestamp.isoformat(),
            "newest_event": self._events[-1].timestamp.isoformat()
        }


class SecretManager:
    """Manages secrets securely."""
    
    def __init__(self, secrets_file: Optional[Path] = None):
        self._secrets_file = secrets_file or Path(".secrets.enc")
        self._secrets: Dict[str, str] = {}
        self._encryption_key: Optional[bytes] = None
        
        # Try to load from environment first
        self._load_from_env()
    
    def _load_from_env(self) -> None:
        """Load secrets from environment variables."""
        env_prefixes = ["AGENT_", "SECRET_", "API_", "TOKEN_"]
        
        for key, value in os.environ.items():
            for prefix in env_prefixes:
                if key.startswith(prefix):
                    self._secrets[key] = value
                    break
    
    def get(self, name: str) -> Optional[str]:
        """Get a secret by name."""
        return self._secrets.get(name) or os.environ.get(name)
    
    def set(self, name: str, value: str) -> None:
        """Set a secret (in memory only)."""
        self._secrets[name] = value
    
    def has(self, name: str) -> bool:
        """Check if a secret exists."""
        return name in self._secrets or name in os.environ
    
    def mask(self, value: str) -> str:
        """Mask a secret value for display."""
        if len(value) <= 8:
            return "*" * len(value)
        return value[:4] + "*" * (len(value) - 8) + value[-4:]
    
    def list_names(self) -> List[str]:
        """List secret names (not values)."""
        return list(self._secrets.keys())


class ThreatDetector:
    """Detects potential security threats."""
    
    def __init__(self):
        self._threat_patterns = [
            # Injection attacks
            (r";\s*(rm|cat|wget|curl|nc)\s+", ThreatLevel.HIGH, "command_injection"),
            (r"[`$]\(.*\)", ThreatLevel.HIGH, "command_substitution"),
            (r"&&\s*(rm|cat|wget)", ThreatLevel.HIGH, "chained_command"),
            
            # SQL injection
            (r"('|\")\s*(OR|AND)\s+('|\"|\d)", ThreatLevel.HIGH, "sql_injection"),
            (r"UNION\s+SELECT", ThreatLevel.HIGH, "sql_union"),
            
            # Path traversal
            (r"\.\./\.\./", ThreatLevel.MEDIUM, "path_traversal"),
            (r"%2e%2e%2f", ThreatLevel.MEDIUM, "encoded_traversal"),
            
            # Privilege escalation
            (r"(sudo|su\s+-|chmod\s+[47])", ThreatLevel.MEDIUM, "priv_escalation"),
            
            # Data exfiltration
            (r"(curl|wget).*\|", ThreatLevel.MEDIUM, "potential_exfil"),
            
            # Reconnaissance
            (r"(nmap|nikto|dirb|gobuster)", ThreatLevel.LOW, "recon_tool"),
        ]
    
    def analyze(self, content: str) -> Tuple[ThreatLevel, List[str]]:
        """
        Analyze content for threats.
        
        Returns:
            Tuple of (highest_threat_level, list_of_findings)
        """
        highest_threat = ThreatLevel.NONE
        findings = []
        
        for pattern, level, name in self._threat_patterns:
            if re.search(pattern, content, re.IGNORECASE):
                if level.value > highest_threat.value:
                    highest_threat = level
                findings.append(f"{level.name}: {name}")
        
        return highest_threat, findings
    
    def is_safe(self, content: str) -> bool:
        """Quick check if content appears safe."""
        level, _ = self.analyze(content)
        return level.value < ThreatLevel.MEDIUM.value


class SecurityManager:
    """
    Central security management for the agent.
    
    Coordinates all security subsystems and provides
    a unified interface for security operations.
    """
    
    def __init__(
        self,
        config: Optional[Dict[str, Any]] = None,
        log_dir: Optional[Path] = None
    ):
        self.config = config or {}
        
        # Initialize subsystems
        self.command_validator = CommandValidator()
        self.path_validator = PathValidator()
        self.rate_limiter = RateLimiter()
        self.audit_logger = AuditLogger(log_dir)
        self.secret_manager = SecretManager()
        self.threat_detector = ThreatDetector()
        
        # Permissions
        self._permissions: Dict[str, Permission] = {}
        
        # State
        self._blocked_count = 0
        self._allowed_count = 0
        
        logger.info("SecurityManager initialized")
    
    async def check_command_safety(
        self,
        command: str,
        target: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
        actor: str = "user"
    ) -> Dict[str, Any]:
        """
        Comprehensive command safety check.
        
        Returns:
            Dict with 'allowed', 'reason', 'level', 'requires_confirmation'
        """
        result = {
            "allowed": True,
            "reason": "",
            "level": SecurityLevel.PUBLIC,
            "requires_confirmation": False,
            "threats": []
        }
        
        # Rate limit check
        allowed, retry_after = self.rate_limiter.check("tool_executions")
        if not allowed:
            result["allowed"] = False
            result["reason"] = f"Rate limited. Retry after {retry_after}s"
            await self._log_blocked(actor, command, "rate_limit")
            return result
        
        # Threat detection
        threat_level, threats = self.threat_detector.analyze(command)
        if threats:
            result["threats"] = threats
            
            if threat_level.value >= ThreatLevel.HIGH.value:
                result["allowed"] = False
                result["reason"] = f"Threat detected: {threats[0]}"
                await self._log_blocked(actor, command, "threat", threat_level)
                return result
        
        # Command validation
        allowed, level, message = await self.command_validator.validate(command)
        result["level"] = level
        
        if not allowed:
            result["allowed"] = False
            result["reason"] = message
            await self._log_blocked(actor, command, message)
            return result
        
        # Path validation if target is a path
        if target and "/" in target:
            path_ok, path_reason = self.path_validator.validate(target)
            if not path_ok:
                result["allowed"] = False
                result["reason"] = path_reason
                await self._log_blocked(actor, command, path_reason)
                return result
        
        # Check if confirmation needed
        if level in [SecurityLevel.SENSITIVE, SecurityLevel.CRITICAL]:
            result["requires_confirmation"] = True
        
        self._allowed_count += 1
        return result
    
    async def _log_blocked(
        self,
        actor: str,
        action: str,
        reason: str,
        threat_level: ThreatLevel = ThreatLevel.LOW
    ) -> None:
        """Log a blocked command."""
        self._blocked_count += 1
        
        await self.audit_logger.log(AuditEvent(
            event_type=AuditEventType.COMMAND_BLOCKED,
            timestamp=datetime.now(),
            actor=actor,
            action=action,
            result="blocked",
            details={"reason": reason},
            threat_level=threat_level
        ))
    
    async def audit_action(
        self,
        actor: str,
        action: str,
        target: Optional[str] = None,
        success: bool = True,
        details: Optional[Dict[str, Any]] = None
    ) -> None:
        """Record an action in the audit log."""
        await self.audit_logger.log(AuditEvent(
            event_type=AuditEventType.COMMAND_EXECUTED,
            timestamp=datetime.now(),
            actor=actor,
            action=action,
            target=target,
            result="success" if success else "failed",
            details=details or {}
        ))
    
    def grant_permission(
        self,
        name: str,
        grantee: str,
        resource: str,
        actions: List[str],
        expires_in: Optional[timedelta] = None
    ) -> Permission:
        """Grant a permission."""
        expires_at = None
        if expires_in:
            expires_at = datetime.now() + expires_in
        
        permission = Permission(
            name=name,
            granted_to=grantee,
            resource=resource,
            actions=actions,
            expires_at=expires_at
        )
        
        self._permissions[name] = permission
        logger.info(f"Permission granted: {name} to {grantee}")
        
        return permission
    
    def check_permission(
        self,
        actor: str,
        resource: str,
        action: str
    ) -> bool:
        """Check if actor has permission for action on resource."""
        for perm in self._permissions.values():
            if perm.is_expired:
                continue
            
            if (perm.granted_to == actor and
                perm.resource == resource and
                action in perm.actions):
                return True
        
        return False
    
    def revoke_permission(self, name: str) -> bool:
        """Revoke a permission."""
        if name in self._permissions:
            del self._permissions[name]
            logger.info(f"Permission revoked: {name}")
            return True
        return False
    
    def get_secret(self, name: str) -> Optional[str]:
        """Get a secret value."""
        return self.secret_manager.get(name)
    
    def mask_secrets(self, text: str) -> str:
        """Mask any secrets that appear in text."""
        result = text
        for name in self.secret_manager.list_names():
            value = self.secret_manager.get(name)
            if value and value in result:
                result = result.replace(value, self.secret_manager.mask(value))
        return result
    
    def get_stats(self) -> Dict[str, Any]:
        """Get security statistics."""
        return {
            "commands_allowed": self._allowed_count,
            "commands_blocked": self._blocked_count,
            "block_rate": (
                self._blocked_count / (self._allowed_count + self._blocked_count)
                if (self._allowed_count + self._blocked_count) > 0 else 0
            ),
            "rate_limits": self.rate_limiter.get_status(),
            "audit_stats": self.audit_logger.get_stats(),
            "active_permissions": len([
                p for p in self._permissions.values() if not p.is_expired
            ]),
            "policies": len(self.command_validator.get_policies())
        }
    
    def get_audit_events(
        self,
        limit: int = 50,
        min_threat: ThreatLevel = ThreatLevel.NONE
    ) -> List[AuditEvent]:
        """Get recent audit events."""
        return self.audit_logger.get_events(limit=limit, min_threat=min_threat)
    
    async def emergency_lockdown(self, reason: str) -> None:
        """Emergency security lockdown."""
        logger.critical(f"EMERGENCY LOCKDOWN: {reason}")
        
        # Log the lockdown
        await self.audit_logger.log(AuditEvent(
            event_type=AuditEventType.CONFIG_CHANGE,
            timestamp=datetime.now(),
            actor="system",
            action="emergency_lockdown",
            result="activated",
            details={"reason": reason},
            threat_level=ThreatLevel.CRITICAL
        ))
        
        # Set all rate limits to 0
        for rule in self.rate_limiter._rules.values():
            rule.max_requests = 0
        
        # Add blocking policy for all commands
        self.command_validator.add_policy(SecurityPolicy(
            name="lockdown_block_all",
            description="Emergency lockdown - all commands blocked",
            pattern=r".*",
            level=SecurityLevel.FORBIDDEN,
            action="block",
            message="System is in lockdown mode"
        ))


# Factory function
def create_security_manager(
    config: Optional[Dict[str, Any]] = None,
    log_dir: Optional[Path] = None
) -> SecurityManager:
    """Create a security manager."""
    return SecurityManager(config=config, log_dir=log_dir)