"""
Configuration settings for the Autonomous Agent
"""
import os
from pathlib import Path

# Base paths
BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
SKILLS_DIR = BASE_DIR / "skills"
LOGS_DIR = BASE_DIR / "logs"
GITHUB_CACHE_DIR = DATA_DIR / "github_cache"
VECTOR_DB_PATH = DATA_DIR / "vector_db"

# Create directories if they don't exist
for directory in [DATA_DIR, SKILLS_DIR, LOGS_DIR, GITHUB_CACHE_DIR, VECTOR_DB_PATH]:
    directory.mkdir(exist_ok=True, parents=True)

# Database paths
MEMORY_DB = DATA_DIR / "memory.db"
SKILLS_DB = DATA_DIR / "skills.db"
LEARNING_DB = DATA_DIR / "learning.db"

# Model settings
DEFAULT_MODEL = "gpt-4"
EMBEDDING_MODEL = "text-embedding-ada-002"

# Intent detection settings
INTENT_CONFIDENCE_THRESHOLD = 0.7
MAX_INTENT_HISTORY = 100

# Memory settings
SHORT_TERM_MEMORY_SIZE = 20
LONG_TERM_MEMORY_THRESHOLD = 0.8
EPISODIC_MEMORY_RETENTION_DAYS = 30

# Skill settings
MAX_SKILL_EXECUTION_TIME = 300  # seconds
SKILL_TEST_TIMEOUT = 60
AUTO_APPROVE_SAFE_SKILLS = False

# Learning settings
LEARNING_RATE = 0.01
MIN_FEEDBACK_FOR_LEARNING = 3
SUCCESS_THRESHOLD = 0.8

# Safety settings
REQUIRE_PERMISSION_FOR_FILE_OPS = True
REQUIRE_PERMISSION_FOR_NETWORK = True
REQUIRE_PERMISSION_FOR_SYSTEM = True
REQUIRE_PERMISSION_FOR_SELF_MODIFY = True
MAX_AUTO_RETRIES = 3

# Logging
LOG_LEVEL = "INFO"
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
MAX_LOG_SIZE = 10 * 1024 * 1024  # 10 MB
BACKUP_COUNT = 5

# API Keys (load from environment)
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")

# ============================================================================
# OLLAMA CONFIGURATION (Same VPS - Local Only)
# ============================================================================
# Model runs on SAME VPS on localhost - no remote connection needed
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3")  # or mistral, codellama, phi
OLLAMA_TIMEOUT = 60  # seconds (increased for slower VPS)
ENABLE_OLLAMA = os.getenv("ENABLE_OLLAMA", "true").lower() == "true"

# ============================================================================
# GITHUB INTEGRATION - DISABLED for VPS (saves resources)
# ============================================================================
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", None)  # Optional, for private repos
GITHUB_CACHE_DIR = DATA_DIR / "github_cache"
ENABLE_GITHUB_LEARNING = os.getenv("ENABLE_GITHUB_LEARNING", "false").lower() == "true"
GITHUB_API_URL = "https://api.github.com"
GITHUB_SEARCH_LIMIT = 10  # Number of repos to analyze

# ============================================================================
# SYSTEM CONTROL - Configured for headless VPS
# ============================================================================
ENABLE_BROWSER_CONTROL = os.getenv("ENABLE_BROWSER_CONTROL", "false").lower() == "true"  # Disabled for headless VPS
ENABLE_FILE_OPERATIONS = os.getenv("ENABLE_FILE_OPERATIONS", "true").lower() == "true"
ENABLE_PROCESS_CONTROL = os.getenv("ENABLE_PROCESS_CONTROL", "true").lower() == "true"
ENABLE_SYSTEM_COMMANDS = os.getenv("ENABLE_SYSTEM_COMMANDS", "false").lower() == "true"  # Risky, disabled by default
ALLOWED_FILE_EXTENSIONS = ['.txt', '.py', '.json', '.md', '.csv', '.log']
RESTRICTED_DIRECTORIES = ['C:\\Windows', 'C:\\Program Files', '/etc', '/usr', '/bin']

# ============================================================================
# MEMORY CONFIGURATION (VECTOR SEARCH) - DISABLED for VPS
# ============================================================================
# Vector search is HEAVY on resources - disabled by default for VPS
ENABLE_VECTOR_SEARCH = os.getenv("ENABLE_VECTOR_SEARCH", "false").lower() == "true"
VECTOR_DB_TYPE = "chromadb"  # or "faiss"
VECTOR_DB_PATH = DATA_DIR / "vector_db"
EMBEDDING_MODEL = "all-MiniLM-L6-v2"
VECTOR_SEARCH_TOP_K = 5

# ============================================================================
# NEW: PROACTIVE ASSISTANT
# ============================================================================
ENABLE_PROACTIVE_SUGGESTIONS = True
PATTERN_RECOGNITION_THRESHOLD = 3  # Times before suggesting automation
SYSTEM_HEALTH_CHECK_INTERVAL = 3600  # seconds (1 hour)
PROACTIVE_CHECK_ENABLED = True

# ============================================================================
# NEW: ENHANCED SAFETY
# ============================================================================
REQUIRE_PERMISSION_FOR_SYSTEM_COMMANDS = True
AUTO_ROLLBACK_ON_ERROR = True
MAX_RISK_LEVEL_WITHOUT_PERMISSION = "low"  # safe, low, medium, high, critical
CREATE_UNDO_POINTS = True
MAX_UNDO_HISTORY = 10

# ============================================================================
# NEW: LANGUAGE & CONTEXT
# ============================================================================
SUPPORTED_LANGUAGES = ["english", "hindi", "hinglish"]
ENABLE_LANGUAGE_DETECTION = True
CONVERSATION_CONTEXT_SIZE = 10  # Number of messages to keep in context
ENABLE_SENTIMENT_ANALYSIS = True

# ============================================================================
# NEW: PERFORMANCE OPTIMIZATION
# ============================================================================
CACHE_LLM_RESPONSES = True
CACHE_EXPIRY_HOURS = 24
ENABLE_PARALLEL_PROCESSING = False  # For future optimization
MAX_CONCURRENT_TASKS = 3
