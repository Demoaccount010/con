# 🤖 Autonomous AI Agent - VPS Edition

## Ultra-Lightweight AI Agent for VPS

Yeh agent **single VPS** pe chalega. No remote connections, no heavy packages, no crashes!

---

## 🎯 Key Features

✅ **Lightweight** - Only 3 core dependencies  
✅ **Same VPS** - Ollama + Agent together  
✅ **Low RAM** - Works on 2GB VPS  
✅ **No Crashes** - Heavy features disabled by default  
✅ **Fast Setup** - 5 minutes complete installation  

---

## 📋 Requirements

**Minimum VPS:**
- RAM: 2GB (with phi model)
- CPU: 1 core
- Storage: 10GB
- OS: Ubuntu 20.04+ or Debian 11+

**Recommended VPS:**
- RAM: 4GB (for llama3/mistral)
- CPU: 2 cores
- Storage: 20GB

---

## ⚡ Quick Start (5 Minutes)

### Step 1: Upload Code to VPS

```bash
# From your local machine
scp -r autonomous_agent root@your-vps-ip:/opt/
```

### Step 2: Run Setup Script

```bash
# SSH into your VPS
ssh root@your-vps-ip

# Run setup
cd /opt/autonomous_agent
bash deploy/scripts/setup_agent_vps.sh

# It will:
# - Install Ollama
# - Download model (choose llama3/mistral/phi)
# - Install Python dependencies (lightweight!)
# - Create optimized .env
# - Test everything
```

### Step 3: Start Agent

```bash
python3 main.py
```

**Done! 🎉**

---

## 📚 Documentation

- **[VPS_SETUP_SIMPLE.md](VPS_SETUP_SIMPLE.md)** - Detailed setup guide
- **[SETUP_COMPLETE.txt](SETUP_COMPLETE.txt)** - What changed & why
- **[requirements.txt](requirements.txt)** - Lightweight dependencies

---

## 🔧 Configuration

The `.env` file is auto-created with optimized settings:

```bash
# Ollama on same VPS
OLLAMA_URL=http://localhost:11434
OLLAMA_MODEL=llama3

# Heavy features DISABLED (saves RAM)
ENABLE_VECTOR_SEARCH=false
ENABLE_GITHUB_LEARNING=false
ENABLE_BROWSER_CONTROL=false
```

To enable heavy features (needs 8GB+ RAM):
```bash
ENABLE_VECTOR_SEARCH=true
# Then reinstall: pip3 install chromadb sentence-transformers
```

---

## 💾 Model Selection

Choose based on your VPS RAM:

| Model | RAM Needed | Speed | Quality |
|-------|-----------|-------|---------|
| **phi** | 2GB | Fast | Good |
| **llama3** | 4GB | Medium | Excellent |
| **mistral** | 4GB | Medium | Excellent |
| **codellama** | 4GB | Medium | Best for code |

Change model:
```bash
nano .env
# Change: OLLAMA_MODEL=phi
ollama pull phi
python3 main.py
```

---

## 🐛 Troubleshooting

### VPS Crashing?
```bash
# Check RAM
free -h

# Use lighter model
ollama pull phi
nano .env  # Set OLLAMA_MODEL=phi

# Add swap space
sudo fallocate -l 4G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
```

### Connection Failed?
```bash
# Check if Ollama is running
ps aux | grep ollama

# Start Ollama
ollama serve &

# Test connection
curl http://localhost:11434/api/tags
```

### Dependencies Error?
```bash
# Reinstall lightweight dependencies
pip3 install -r requirements.txt --force-reinstall
```

More troubleshooting: See **[VPS_SETUP_SIMPLE.md](VPS_SETUP_SIMPLE.md)**

---

## 📊 Resource Monitoring

```bash
# Check RAM usage
free -h

# Check CPU usage
top

# Check disk space
df -h

# Monitor agent logs
tail -f logs/agent.log

# Monitor Ollama logs
journalctl -u ollama -f
```

---

## 🚀 Auto-Start on Boot

```bash
# Copy service file
sudo cp deploy/systemd/autonomous-agent.service /etc/systemd/system/

# Edit paths if needed
sudo nano /etc/systemd/system/autonomous-agent.service

# Enable auto-start
sudo systemctl daemon-reload
sudo systemctl enable autonomous-agent
sudo systemctl start autonomous-agent

# Check status
sudo systemctl status autonomous-agent
```

---

## 🎯 What's Removed (for VPS optimization)?

**Heavy packages removed:**
- ❌ chromadb (100MB+)
- ❌ sentence-transformers (500MB+ models)
- ❌ pyautogui, Pillow (GUI tools)
- ❌ beautifulsoup4, GitPython (optional features)

**Only 3 core dependencies:**
- ✅ requests (Ollama API)
- ✅ psutil (system monitoring)
- ✅ colorama (colored output)

**Result:** From 1.5GB to 200MB disk usage! 🎉

---

## 💡 Pro Tips

1. **Monitor RAM:** Run `htop` to watch memory usage
2. **Use swap:** Add swap space if RAM < 4GB
3. **Lighter model:** Use `phi` for 2GB VPS
4. **Log rotation:** Setup logrotate for logs/
5. **Backups:** Backup data/ folder regularly
6. **Security:** Setup firewall (ufw) and fail2ban

---

## 📞 Support

Issues? Check:
1. **[VPS_SETUP_SIMPLE.md](VPS_SETUP_SIMPLE.md)** - Detailed guide
2. **[SETUP_COMPLETE.txt](SETUP_COMPLETE.txt)** - What changed
3. Logs: `tail -f logs/agent.log`

---

## ✅ Checklist

After setup, verify:
- [ ] Ollama running: `ps aux | grep ollama`
- [ ] Model downloaded: `ollama list`
- [ ] Agent starts: `python3 main.py`
- [ ] RAM under control: `free -h` (< 80% used)
- [ ] Test connection: `python3 test_remote_ollama.py`

---

**Happy Coding! 🚀**

Ab VPS crash nahi hoga! Sab optimized hai! 💪
