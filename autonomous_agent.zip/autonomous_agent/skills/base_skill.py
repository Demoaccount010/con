"""
Base Skill class that all skills inherit from
"""
from abc import ABC, abstractmethod
from typing import Dict, Any
import time

class BaseSkill(ABC):
    """Base class for all skills"""
    
    def __init__(self, name: str, description: str, category: str = "general"):
        self.name = name
        self.description = description
        self.category = category
        self.execution_count = 0
        self.success_count = 0
        self.last_execution = None
    
    @abstractmethod
    def execute(self, *args, **kwargs) -> Dict[str, Any]:
        """Execute the skill - must be implemented by subclasses"""
        pass
    
    def run(self, *args, **kwargs) -> Dict[str, Any]:
        """Wrapper to track execution"""
        start_time = time.time()
        self.execution_count += 1
        self.last_execution = time.time()
        
        try:
            result = self.execute(*args, **kwargs)
            self.success_count += 1
            
            return {
                'success': True,
                'result': result,
                'duration_ms': int((time.time() - start_time) * 1000),
                'skill': self.name
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'duration_ms': int((time.time() - start_time) * 1000),
                'skill': self.name
            }
    
    def get_info(self) -> Dict[str, Any]:
        """Get skill information"""
        return {
            'name': self.name,
            'description': self.description,
            'category': self.category,
            'execution_count': self.execution_count,
            'success_count': self.success_count,
            'success_rate': self.success_count / self.execution_count if self.execution_count > 0 else 0,
            'last_execution': self.last_execution
        }
