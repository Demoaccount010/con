"""
Skills package for the Autonomous Agent
Contains various skill modules for different capabilities
"""
