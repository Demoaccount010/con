# 🚀 Simple VPS Setup Guide

## Single VPS Setup (Sab kuch ek hi VPS pe!)

Yeh agent aur Ollama model **same VPS** pe chalenge. No remote connection needed!

---

## 📋 Requirements

- **VPS:** 4GB+ RAM, 2+ CPU cores
- **OS:** Ubuntu 20.04/22.04 or Debian
- **Storage:** 10GB+ free space
- **Root access**

---

## ⚡ Quick Install (5 Minutes)

### Step 1: Install Ollama

```bash
# Login to your VPS
ssh root@your-vps-ip

# Install Ollama
curl -fsSL https://ollama.ai/install.sh | sh

# Download a model (choose one based on your RAM)
ollama pull llama3        # 4GB RAM needed
# OR
ollama pull mistral       # 4GB RAM needed
# OR  
ollama pull phi           # 2GB RAM (lightweight)

# Test it
ollama run llama3 "hello"
```

---

### Step 2: Install Agent

```bash
# Install Python dependencies
apt update && apt install -y python3 python3-pip git

# Clone/Upload your agent code
cd /opt
# If from git: git clone <your-repo> autonomous_agent
# Or upload via SCP/SFTP

cd autonomous_agent

# Install lightweight requirements
pip3 install -r requirements.txt
```

---

### Step 3: Configure

```bash
# Create .env file
nano .env
```

**Paste this:**
```bash
# Ollama on localhost (same VPS)
OLLAMA_URL=http://localhost:11434
OLLAMA_MODEL=llama3
ENABLE_OLLAMA=true

# Disable heavy features for VPS
ENABLE_VECTOR_SEARCH=false
ENABLE_GITHUB_LEARNING=false

# Optional
GITHUB_TOKEN=your_token_here
```

---

### Step 4: Test & Run

```bash
# Test connection
python3 test_remote_ollama.py

# Should show: ✅ Success!

# Run agent
python3 main.py
```

---

## 🔧 Troubleshooting

### Problem: VPS Crash / Out of Memory

```bash
# Check RAM usage
free -h

# Check running processes
top

# Solution 1: Use lighter model
ollama pull phi           # Only 2GB needed

# Solution 2: Add swap space
sudo fallocate -l 4G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
```

### Problem: Ollama Not Responding

```bash
# Check if Ollama is running
ps aux | grep ollama

# Restart Ollama
pkill ollama
ollama serve &

# Check logs
journalctl -u ollama -f
```

### Problem: Port Already in Use

```bash
# Check what's using port 11434
sudo netstat -tlnp | grep 11434

# Kill the process
sudo kill -9 <PID>
```

---

## 🎯 Auto-Start on Boot (Optional)

### Make Agent Auto-start:

```bash
# Create systemd service
nano /etc/systemd/system/autonomous-agent.service
```

**Paste this:**
```ini
[Unit]
Description=Autonomous AI Agent
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/autonomous_agent
ExecStart=/usr/bin/python3 /opt/autonomous_agent/main.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

**Enable it:**
```bash
systemctl daemon-reload
systemctl enable autonomous-agent
systemctl start autonomous-agent
systemctl status autonomous-agent
```

---

## 📊 Monitor Resources

```bash
# Watch RAM/CPU usage
htop

# Watch agent logs
tail -f /opt/autonomous_agent/logs/agent.log

# Watch Ollama logs
journalctl -u ollama -f
```

---

## 💾 Recommended VPS Specs

### Minimum (Budget):
- **RAM:** 4GB
- **CPU:** 2 cores
- **Storage:** 20GB
- **Model:** phi (2GB)
- **Cost:** ~$10-15/month

### Recommended:
- **RAM:** 8GB
- **CPU:** 4 cores
- **Storage:** 40GB
- **Model:** llama3 or mistral
- **Cost:** ~$20-30/month

### Best:
- **RAM:** 16GB+
- **CPU:** 8 cores
- **GPU:** Optional (for faster inference)
- **Storage:** 80GB+
- **Model:** Any (llama3, mistral, codellama)
- **Cost:** ~$50-80/month

---

## 🎯 Quick Commands Reference

```bash
# Start agent
cd /opt/autonomous_agent && python3 main.py

# Stop agent
pkill -f "python3 main.py"

# Restart agent
pkill -f "python3 main.py" && cd /opt/autonomous_agent && python3 main.py &

# Check Ollama models
ollama list

# Delete model to free space
ollama rm llama3

# Update agent code
cd /opt/autonomous_agent && git pull

# Reinstall dependencies
pip3 install -r requirements.txt --upgrade
```

---

## ✅ Final Checklist

- [ ] Ollama installed and running
- [ ] Model downloaded (llama3/mistral/phi)
- [ ] Python dependencies installed
- [ ] .env file configured
- [ ] test_remote_ollama.py passes
- [ ] Agent starts without errors
- [ ] RAM usage under control (check with `free -h`)
- [ ] Auto-start configured (optional)

---

**Done! Ab tumhara agent chal raha hai! 🎉**

Koi problem ho to:
1. Check logs: `tail -f logs/agent.log`
2. Check RAM: `free -h`
3. Restart everything: `systemctl restart ollama && systemctl restart autonomous-agent`
