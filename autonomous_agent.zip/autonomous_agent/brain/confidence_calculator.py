"""
═══════════════════════════════════════════════════════════════════════════════════════
CONFIDENCE CALCULATOR - QUANTIFIED UNCERTAINTY
═══════════════════════════════════════════════════════════════════════════════════════
Calculates confidence scores for decisions, plans, and actions.
Uses multiple factors to determine how certain the agent should be.
Never lets the agent proceed with false confidence.
"""

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Tuple, Callable
import math
import json

logger = logging.getLogger(__name__)


class ConfidenceLevel(Enum):
    """Named confidence levels."""
    VERY_LOW = (0.0, 0.2, "Very uncertain, likely to fail")
    LOW = (0.2, 0.4, "Low confidence, proceed with caution")
    MODERATE = (0.4, 0.6, "Moderate confidence, may need verification")
    HIGH = (0.6, 0.8, "High confidence, likely to succeed")
    VERY_HIGH = (0.8, 1.0, "Very high confidence, expected success")
    
    @property
    def min_value(self) -> float:
        return self.value[0]
    
    @property
    def max_value(self) -> float:
        return self.value[1]
    
    @property
    def description(self) -> str:
        return self.value[2]
    
    @classmethod
    def from_score(cls, score: float) -> "ConfidenceLevel":
        """Get level from numeric score."""
        for level in cls:
            if level.min_value <= score < level.max_value:
                return level
        return cls.VERY_HIGH if score >= 1.0 else cls.VERY_LOW


class ConfidenceFactor(Enum):
    """Factors that influence confidence."""
    VERIFICATION_RESULT = auto()    # Result of verification checks
    MEMORY_SUPPORT = auto()         # Support from memory
    MEMORY_CONFLICT = auto()        # Conflicts in memory
    TASK_COMPLEXITY = auto()        # How complex the task is
    HISTORICAL_SUCCESS = auto()     # Past success with similar tasks
    TOOL_RELIABILITY = auto()       # Reliability of tools involved
    CONTEXT_COMPLETENESS = auto()   # How complete the context is
    ASSUMPTION_COUNT = auto()       # Number of assumptions made
    USER_CONFIRMATION = auto()      # User has confirmed
    TIME_PRESSURE = auto()          # Under time pressure
    DEPENDENCY_STATUS = auto()      # Status of dependencies
    INFORMATION_FRESHNESS = auto()  # How fresh the information is
    AMBIGUITY_LEVEL = auto()        # Level of ambiguity in input


@dataclass
class ConfidenceComponent:
    """A single component contributing to confidence."""
    factor: ConfidenceFactor
    value: float  # -1.0 to 1.0 (negative = reduces confidence)
    weight: float  # 0.0 to 1.0
    reason: str
    evidence: Optional[str] = None
    
    @property
    def contribution(self) -> float:
        """Calculate weighted contribution."""
        return self.value * self.weight


@dataclass
class ConfidenceScore:
    """Complete confidence score with breakdown."""
    overall: float
    level: ConfidenceLevel
    components: List[ConfidenceComponent] = field(default_factory=list)
    reasoning: str = ""
    timestamp: datetime = field(default_factory=datetime.now)
    context: str = ""
    
    # Thresholds
    proceed_threshold: float = 0.6
    warn_threshold: float = 0.4
    
    @property
    def should_proceed(self) -> bool:
        """Check if confidence is high enough to proceed."""
        return self.overall >= self.proceed_threshold
    
    @property
    def needs_warning(self) -> bool:
        """Check if confidence warrants a warning."""
        return self.overall < self.warn_threshold
    
    @property
    def top_factors(self) -> List[ConfidenceComponent]:
        """Get top contributing factors."""
        return sorted(
            self.components,
            key=lambda c: abs(c.contribution),
            reverse=True
        )[:3]
    
    @property
    def limiting_factors(self) -> List[ConfidenceComponent]:
        """Get factors that most reduce confidence."""
        return [c for c in self.components if c.contribution < 0]
    
    def format_breakdown(self) -> str:
        """Format confidence breakdown for display."""
        lines = [
            f"Confidence: {self.overall:.1%} ({self.level.name})",
            f"  {self.level.description}",
            "",
            "Top factors:"
        ]
        
        for comp in self.top_factors:
            sign = "+" if comp.contribution > 0 else ""
            lines.append(
                f"  {sign}{comp.contribution:.2f} {comp.factor.name}: {comp.reason}"
            )
        
        if self.limiting_factors:
            lines.append("")
            lines.append("Limiting factors:")
            for comp in self.limiting_factors[:3]:
                lines.append(f"  • {comp.factor.name}: {comp.reason}")
        
        return "\n".join(lines)


class ConfidenceCalculator:
    """
    Calculates confidence scores for the agent's decisions.
    
    Uses a multi-factor weighted system to determine how confident
    the agent should be about its decisions and actions.
    """
    
    def __init__(
        self,
        memory_manager=None,
        default_weights: Optional[Dict[ConfidenceFactor, float]] = None
    ):
        self.memory_manager = memory_manager
        
        # Default weights for each factor
        self._weights = default_weights or {
            ConfidenceFactor.VERIFICATION_RESULT: 0.25,
            ConfidenceFactor.MEMORY_SUPPORT: 0.15,
            ConfidenceFactor.MEMORY_CONFLICT: 0.20,
            ConfidenceFactor.TASK_COMPLEXITY: 0.10,
            ConfidenceFactor.HISTORICAL_SUCCESS: 0.15,
            ConfidenceFactor.TOOL_RELIABILITY: 0.10,
            ConfidenceFactor.CONTEXT_COMPLETENESS: 0.15,
            ConfidenceFactor.ASSUMPTION_COUNT: 0.15,
            ConfidenceFactor.USER_CONFIRMATION: 0.20,
            ConfidenceFactor.TIME_PRESSURE: 0.05,
            ConfidenceFactor.DEPENDENCY_STATUS: 0.10,
            ConfidenceFactor.INFORMATION_FRESHNESS: 0.10,
            ConfidenceFactor.AMBIGUITY_LEVEL: 0.15,
        }
        
        # Thresholds
        self.proceed_threshold = 0.6
        self.high_confidence_threshold = 0.8
        self.low_confidence_threshold = 0.4
        
        # Historical data for calibration
        self._predictions: List[Dict[str, Any]] = []
        self._outcomes: List[Dict[str, Any]] = []
        
        logger.info("ConfidenceCalculator initialized")
    
    async def calculate(
        self,
        task: str,
        context: Dict[str, Any],
        components: Optional[List[ConfidenceComponent]] = None
    ) -> ConfidenceScore:
        """
        Calculate comprehensive confidence score.
        
        Args:
            task: The task being evaluated
            context: Context including results, memory, etc.
            components: Pre-calculated components (optional)
        
        Returns:
            ConfidenceScore with full breakdown
        """
        start_time = datetime.now()
        
        # Use provided components or calculate new ones
        if components is None:
            components = await self._calculate_all_components(task, context)
        
        # Calculate weighted sum
        total_contribution = sum(c.contribution for c in components)
        total_weight = sum(c.weight for c in components)
        
        if total_weight > 0:
            # Normalize to 0-1 range
            raw_score = (total_contribution / total_weight + 1) / 2
        else:
            raw_score = 0.5  # Default neutral
        
        # Apply bounds and adjustments
        overall = self._apply_adjustments(raw_score, context)
        
        # Determine level
        level = ConfidenceLevel.from_score(overall)
        
        # Generate reasoning
        reasoning = self._generate_reasoning(components, overall, level)
        
        score = ConfidenceScore(
            overall=overall,
            level=level,
            components=components,
            reasoning=reasoning,
            context=task[:200],
            proceed_threshold=self.proceed_threshold,
            warn_threshold=self.low_confidence_threshold
        )
        
        logger.debug(
            f"Confidence calculated: {overall:.2f} ({level.name}) for: {task[:50]}"
        )
        
        return score
    
    async def _calculate_all_components(
        self,
        task: str,
        context: Dict[str, Any]
    ) -> List[ConfidenceComponent]:
        """Calculate all confidence components."""
        components = []
        
        # Verification result
        if "verification_result" in context:
            ver_result = context["verification_result"]
            components.append(ConfidenceComponent(
                factor=ConfidenceFactor.VERIFICATION_RESULT,
                value=ver_result.get("confidence", 0) * 2 - 1,  # Map 0-1 to -1 to 1
                weight=self._weights[ConfidenceFactor.VERIFICATION_RESULT],
                reason=f"Verification: {ver_result.get('status', 'unknown')}",
                evidence=str(ver_result.get("evidence", [])[:2])
            ))
        
        # Memory support
        memory_component = await self._evaluate_memory_support(task, context)
        if memory_component:
            components.append(memory_component)
        
        # Memory conflict
        memory_conflict = await self._check_memory_conflicts(task, context)
        if memory_conflict:
            components.append(memory_conflict)
        
        # Task complexity
        complexity_component = self._evaluate_task_complexity(task, context)
        components.append(complexity_component)
        
        # Historical success
        historical = await self._check_historical_success(task)
        if historical:
            components.append(historical)
        
        # Context completeness
        context_component = self._evaluate_context_completeness(context)
        components.append(context_component)
        
        # Assumption count
        if "assumptions" in context:
            assumptions = context["assumptions"]
            # More assumptions = less confidence
            assumption_penalty = min(len(assumptions) * 0.1, 0.5)
            components.append(ConfidenceComponent(
                factor=ConfidenceFactor.ASSUMPTION_COUNT,
                value=-assumption_penalty,
                weight=self._weights[ConfidenceFactor.ASSUMPTION_COUNT],
                reason=f"{len(assumptions)} assumptions made"
            ))
        
        # User confirmation
        if context.get("user_confirmed"):
            components.append(ConfidenceComponent(
                factor=ConfidenceFactor.USER_CONFIRMATION,
                value=1.0,
                weight=self._weights[ConfidenceFactor.USER_CONFIRMATION],
                reason="User has confirmed action"
            ))
        
        # Ambiguity level
        ambiguity_component = self._evaluate_ambiguity(task, context)
        components.append(ambiguity_component)
        
        # Information freshness
        if "info_age_seconds" in context:
            age = context["info_age_seconds"]
            # Info older than 1 hour reduces confidence
            if age > 3600:
                staleness = min((age - 3600) / 36000, 0.5)  # Max 0.5 reduction
                components.append(ConfidenceComponent(
                    factor=ConfidenceFactor.INFORMATION_FRESHNESS,
                    value=-staleness,
                    weight=self._weights[ConfidenceFactor.INFORMATION_FRESHNESS],
                    reason=f"Information is {age/3600:.1f} hours old"
                ))
        
        return components
    
    async def _evaluate_memory_support(
        self,
        task: str,
        context: Dict[str, Any]
    ) -> Optional[ConfidenceComponent]:
        """Evaluate support from memory."""
        if not self.memory_manager:
            return None
        
        try:
            # Search for relevant memories
            memories = await self.memory_manager.search(
                query=task,
                limit=5,
                memory_types=["fact", "skill", "permanent"]
            )
            
            if not memories:
                return ConfidenceComponent(
                    factor=ConfidenceFactor.MEMORY_SUPPORT,
                    value=-0.1,
                    weight=self._weights[ConfidenceFactor.MEMORY_SUPPORT],
                    reason="No relevant memories found"
                )
            
            # Calculate support score based on relevance
            relevance_sum = sum(m.get("relevance", 0) for m in memories)
            avg_relevance = relevance_sum / len(memories)
            
            return ConfidenceComponent(
                factor=ConfidenceFactor.MEMORY_SUPPORT,
                value=avg_relevance * 2 - 1,
                weight=self._weights[ConfidenceFactor.MEMORY_SUPPORT],
                reason=f"{len(memories)} relevant memories (avg relevance: {avg_relevance:.2f})",
                evidence=str([m.get("type") for m in memories[:3]])
            )
            
        except Exception as e:
            logger.warning(f"Memory support evaluation failed: {e}")
            return None
    
    async def _check_memory_conflicts(
        self,
        task: str,
        context: Dict[str, Any]
    ) -> Optional[ConfidenceComponent]:
        """Check for conflicts in memory."""
        conflicts = context.get("memory_conflicts", [])
        
        if not conflicts:
            return None
        
        # More conflicts = lower confidence
        conflict_penalty = min(len(conflicts) * 0.15, 0.6)
        
        return ConfidenceComponent(
            factor=ConfidenceFactor.MEMORY_CONFLICT,
            value=-conflict_penalty,
            weight=self._weights[ConfidenceFactor.MEMORY_CONFLICT],
            reason=f"{len(conflicts)} memory conflicts detected",
            evidence=str(conflicts[:2])
        )
    
    def _evaluate_task_complexity(
        self,
        task: str,
        context: Dict[str, Any]
    ) -> ConfidenceComponent:
        """Evaluate task complexity impact on confidence."""
        # Heuristics for complexity
        complexity_score = 0.0
        
        # Length of task
        if len(task) > 200:
            complexity_score += 0.2
        if len(task) > 500:
            complexity_score += 0.2
        
        # Number of steps in plan
        plan = context.get("plan", [])
        if len(plan) > 5:
            complexity_score += 0.2
        if len(plan) > 10:
            complexity_score += 0.2
        
        # Keywords indicating complexity
        complex_keywords = [
            "multiple", "complex", "advanced", "recursive", "parallel",
            "distributed", "integrate", "migrate", "transform"
        ]
        task_lower = task.lower()
        for keyword in complex_keywords:
            if keyword in task_lower:
                complexity_score += 0.1
        
        # Cap at 0.8
        complexity_score = min(complexity_score, 0.8)
        
        # Higher complexity = lower confidence
        return ConfidenceComponent(
            factor=ConfidenceFactor.TASK_COMPLEXITY,
            value=-complexity_score,
            weight=self._weights[ConfidenceFactor.TASK_COMPLEXITY],
            reason=f"Task complexity: {complexity_score:.1%}"
        )
    
    async def _check_historical_success(
        self,
        task: str
    ) -> Optional[ConfidenceComponent]:
        """Check historical success rate for similar tasks."""
        if not self.memory_manager:
            return None
        
        try:
            # Search for past outcomes
            past = await self.memory_manager.search(
                query=task,
                limit=10,
                memory_types=["skill", "failure", "episode"]
            )
            
            if not past:
                return None
            
            successes = sum(1 for m in past if m.get("type") == "skill")
            failures = sum(1 for m in past if m.get("type") == "failure")
            total = successes + failures
            
            if total == 0:
                return None
            
            success_rate = successes / total
            
            return ConfidenceComponent(
                factor=ConfidenceFactor.HISTORICAL_SUCCESS,
                value=success_rate * 2 - 1,
                weight=self._weights[ConfidenceFactor.HISTORICAL_SUCCESS],
                reason=f"Historical: {successes}/{total} similar tasks succeeded"
            )
            
        except Exception as e:
            logger.warning(f"Historical check failed: {e}")
            return None
    
    def _evaluate_context_completeness(
        self,
        context: Dict[str, Any]
    ) -> ConfidenceComponent:
        """Evaluate how complete the context is."""
        expected_keys = [
            "task", "plan", "tools", "verification_result",
            "memory_hints", "user_input"
        ]
        
        present = sum(1 for key in expected_keys if key in context)
        completeness = present / len(expected_keys)
        
        # Missing critical info
        missing = [key for key in expected_keys if key not in context]
        critical_missing = [
            m for m in missing if m in ["task", "verification_result"]
        ]
        
        if critical_missing:
            completeness *= 0.5
        
        return ConfidenceComponent(
            factor=ConfidenceFactor.CONTEXT_COMPLETENESS,
            value=completeness * 2 - 1,
            weight=self._weights[ConfidenceFactor.CONTEXT_COMPLETENESS],
            reason=f"Context {completeness:.0%} complete",
            evidence=f"Missing: {missing}" if missing else None
        )
    
    def _evaluate_ambiguity(
        self,
        task: str,
        context: Dict[str, Any]
    ) -> ConfidenceComponent:
        """Evaluate ambiguity in the task."""
        ambiguity_score = 0.0
        
        # Ambiguous pronouns
        ambiguous_words = ["it", "this", "that", "them", "they", "something"]
        task_words = task.lower().split()
        for word in ambiguous_words:
            if word in task_words:
                ambiguity_score += 0.1
        
        # Question marks in task (uncertainty)
        if "?" in task:
            ambiguity_score += 0.15
        
        # Vague terms
        vague_terms = ["maybe", "possibly", "might", "could", "some", "few"]
        for term in vague_terms:
            if term in task.lower():
                ambiguity_score += 0.1
        
        # Cap at 0.6
        ambiguity_score = min(ambiguity_score, 0.6)
        
        return ConfidenceComponent(
            factor=ConfidenceFactor.AMBIGUITY_LEVEL,
            value=-ambiguity_score,
            weight=self._weights[ConfidenceFactor.AMBIGUITY_LEVEL],
            reason=f"Ambiguity level: {ambiguity_score:.0%}"
        )
    
    def _apply_adjustments(
        self,
        raw_score: float,
        context: Dict[str, Any]
    ) -> float:
        """Apply final adjustments to the score."""
        adjusted = raw_score
        
        # Critical failures override
        if context.get("critical_failure"):
            adjusted = min(adjusted, 0.1)
        
        # User confirmation boost
        if context.get("user_confirmed"):
            adjusted = min(adjusted + 0.2, 0.95)
        
        # Safety concerns cap
        if context.get("safety_concerns"):
            adjusted = min(adjusted, 0.5)
        
        # Ensure bounds
        return max(0.0, min(1.0, adjusted))
    
    def _generate_reasoning(
        self,
        components: List[ConfidenceComponent],
        overall: float,
        level: ConfidenceLevel
    ) -> str:
        """Generate human-readable reasoning."""
        parts = []
        
        parts.append(f"Overall confidence: {overall:.1%} ({level.name})")
        
        # Top positive factors
        positive = [c for c in components if c.contribution > 0]
        if positive:
            positive.sort(key=lambda c: c.contribution, reverse=True)
            parts.append("Confidence boosted by:")
            for c in positive[:2]:
                parts.append(f"  + {c.reason}")
        
        # Top negative factors
        negative = [c for c in components if c.contribution < 0]
        if negative:
            negative.sort(key=lambda c: c.contribution)
            parts.append("Confidence reduced by:")
            for c in negative[:2]:
                parts.append(f"  - {c.reason}")
        
        return "\n".join(parts)
    
    async def quick_confidence(
        self,
        task: str,
        context: Optional[Dict[str, Any]] = None
    ) -> Tuple[float, ConfidenceLevel, str]:
        """
        Quick confidence check returning just essentials.
        
        Returns:
            Tuple of (score, level, brief_reason)
        """
        context = context or {}
        score = await self.calculate(task, context)
        
        brief_reason = ""
        if score.limiting_factors:
            brief_reason = score.limiting_factors[0].reason
        elif score.components:
            brief_reason = score.top_factors[0].reason if score.top_factors else ""
        
        return score.overall, score.level, brief_reason
    
    def calculate_combined(
        self,
        scores: List[ConfidenceScore],
        method: str = "weighted_average"
    ) -> ConfidenceScore:
        """
        Combine multiple confidence scores.
        
        Args:
            scores: List of scores to combine
            method: 'weighted_average', 'minimum', 'maximum'
        
        Returns:
            Combined ConfidenceScore
        """
        if not scores:
            return ConfidenceScore(
                overall=0.0,
                level=ConfidenceLevel.VERY_LOW,
                reasoning="No scores to combine"
            )
        
        if len(scores) == 1:
            return scores[0]
        
        if method == "minimum":
            min_score = min(scores, key=lambda s: s.overall)
            return ConfidenceScore(
                overall=min_score.overall,
                level=ConfidenceLevel.from_score(min_score.overall),
                components=min_score.components,
                reasoning=f"Minimum of {len(scores)} scores: {min_score.reasoning}"
            )
        
        elif method == "maximum":
            max_score = max(scores, key=lambda s: s.overall)
            return ConfidenceScore(
                overall=max_score.overall,
                level=ConfidenceLevel.from_score(max_score.overall),
                components=max_score.components,
                reasoning=f"Maximum of {len(scores)} scores: {max_score.reasoning}"
            )
        
        else:  # weighted_average
            # Combine all components
            all_components = []
            for score in scores:
                all_components.extend(score.components)
            
            avg = sum(s.overall for s in scores) / len(scores)
            
            return ConfidenceScore(
                overall=avg,
                level=ConfidenceLevel.from_score(avg),
                components=all_components,
                reasoning=f"Average of {len(scores)} scores"
            )
    
    def requires_confirmation(self, score: ConfidenceScore) -> bool:
        """Check if the score requires user confirmation."""
        return score.overall < self.proceed_threshold
    
    def should_abort(self, score: ConfidenceScore) -> bool:
        """Check if confidence is too low to proceed."""
        return score.overall < 0.2
    
    def update_weights(
        self,
        factor: ConfidenceFactor,
        new_weight: float
    ) -> None:
        """Update weight for a specific factor."""
        if 0.0 <= new_weight <= 1.0:
            self._weights[factor] = new_weight
            logger.info(f"Updated weight for {factor.name}: {new_weight}")
    
    def record_prediction(
        self,
        score: ConfidenceScore,
        task_id: str
    ) -> None:
        """Record a prediction for later calibration."""
        self._predictions.append({
            "task_id": task_id,
            "predicted_confidence": score.overall,
            "level": score.level.name,
            "timestamp": datetime.now().isoformat()
        })
    
    def record_outcome(
        self,
        task_id: str,
        success: bool
    ) -> None:
        """Record actual outcome for calibration."""
        self._outcomes.append({
            "task_id": task_id,
            "success": success,
            "timestamp": datetime.now().isoformat()
        })
    
    def get_calibration_stats(self) -> Dict[str, Any]:
        """Get calibration statistics."""
        if not self._predictions or not self._outcomes:
            return {"status": "insufficient_data"}
        
        # Match predictions with outcomes
        matched = []
        for outcome in self._outcomes:
            pred = next(
                (p for p in self._predictions if p["task_id"] == outcome["task_id"]),
                None
            )
            if pred:
                matched.append({
                    "predicted": pred["predicted_confidence"],
                    "actual": 1.0 if outcome["success"] else 0.0
                })
        
        if not matched:
            return {"status": "no_matched_predictions"}
        
        # Calculate calibration metrics
        avg_predicted = sum(m["predicted"] for m in matched) / len(matched)
        avg_actual = sum(m["actual"] for m in matched) / len(matched)
        
        # Brier score (lower is better)
        brier = sum(
            (m["predicted"] - m["actual"]) ** 2 for m in matched
        ) / len(matched)
        
        return {
            "total_predictions": len(self._predictions),
            "matched_outcomes": len(matched),
            "avg_predicted_confidence": avg_predicted,
            "actual_success_rate": avg_actual,
            "brier_score": brier,
            "calibration_error": abs(avg_predicted - avg_actual),
            "overconfident": avg_predicted > avg_actual
        }


# Singleton pattern for global access
_calculator_instance: Optional[ConfidenceCalculator] = None


def get_confidence_calculator(
    memory_manager=None
) -> ConfidenceCalculator:
    """Get or create the global confidence calculator."""
    global _calculator_instance
    
    if _calculator_instance is None:
        _calculator_instance = ConfidenceCalculator(
            memory_manager=memory_manager
        )
    
    return _calculator_instance


def create_confidence_calculator(
    memory_manager=None,
    custom_weights: Optional[Dict[ConfidenceFactor, float]] = None
) -> ConfidenceCalculator:
    """Create a new confidence calculator with custom settings."""
    return ConfidenceCalculator(
        memory_manager=memory_manager,
        default_weights=custom_weights
    )


# Utility functions for quick access
async def quick_confidence_check(
    task: str,
    context: Optional[Dict[str, Any]] = None,
    memory_manager=None
) -> Tuple[float, bool, str]:
    """
    Quick confidence check utility.
    
    Returns:
        Tuple of (score, should_proceed, reason)
    """
    calc = get_confidence_calculator(memory_manager)
    score, level, reason = await calc.quick_confidence(task, context)
    
    return score, score >= calc.proceed_threshold, reason