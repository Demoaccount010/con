"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                            BASE TOOL                                          ║
║                    Base Class for All Agent Tools                             ║
╚══════════════════════════════════════════════════════════════════════════════╝

All tools inherit from BaseTool to ensure consistent:
- Interface
- Error handling
- Logging
- Validation
- Result formatting
"""

import asyncio
import logging
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Optional, Dict, Any, List, TypeVar, Generic
from dataclasses import dataclass, field
from enum import Enum

from tools.registry import ToolCategory, ToolRisk, ToolParameter

logger = logging.getLogger(__name__)

T = TypeVar('T')


class ResultStatus(Enum):
    """Status of tool execution result"""
    SUCCESS = "success"
    FAILURE = "failure"
    PARTIAL = "partial"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"
    ERROR = "error"


@dataclass
class ToolResult(Generic[T]):
    """Result of tool execution"""
    success: bool
    status: ResultStatus
    data: Optional[T] = None
    message: str = ""
    error: Optional[str] = None
    
    # Execution info
    tool_name: str = ""
    execution_time_ms: float = 0.0
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    
    # Additional info
    warnings: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    @classmethod
    def ok(
        cls,
        data: T = None,
        message: str = "Success"
    ) -> 'ToolResult[T]':
        """Create successful result"""
        return cls(
            success=True,
            status=ResultStatus.SUCCESS,
            data=data,
            message=message
        )
    
    @classmethod
    def fail(
        cls,
        error: str,
        message: str = "Failed"
    ) -> 'ToolResult[T]':
        """Create failed result"""
        return cls(
            success=False,
            status=ResultStatus.FAILURE,
            error=error,
            message=message
        )
    
    @classmethod
    def error(
        cls,
        error: str,
        message: str = "Error occurred"
    ) -> 'ToolResult[T]':
        """Create error result"""
        return cls(
            success=False,
            status=ResultStatus.ERROR,
            error=error,
            message=message
        )
    
    @classmethod
    def partial(
        cls,
        data: T = None,
        message: str = "Partial success",
        warnings: Optional[List[str]] = None
    ) -> 'ToolResult[T]':
        """Create partial success result"""
        return cls(
            success=True,
            status=ResultStatus.PARTIAL,
            data=data,
            message=message,
            warnings=warnings or []
        )
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "success": self.success,
            "status": self.status.value,
            "data": self.data,
            "message": self.message,
            "error": self.error,
            "tool_name": self.tool_name,
            "execution_time_ms": self.execution_time_ms,
            "warnings": self.warnings,
            "metadata": self.metadata
        }


@dataclass
class ToolContext:
    """Context for tool execution"""
    # User context
    user_id: Optional[str] = None
    user_name: Optional[str] = None
    is_owner: bool = False
    
    # Conversation context
    conversation_id: Optional[str] = None
    message_id: Optional[str] = None
    
    # Execution context
    dry_run: bool = False
    timeout_seconds: float = 60.0
    
    # Permission context
    confirmed: bool = False
    permissions: List[str] = field(default_factory=list)
    
    # Additional context
    extra: Dict[str, Any] = field(default_factory=dict)


class BaseTool(ABC):
    """
    Base class for all tools
    
    Features:
    - Consistent interface
    - Built-in validation
    - Error handling
    - Logging
    - Result formatting
    """
    
    # Tool metadata (override in subclasses)
    name: str = "base_tool"
    description: str = "Base tool class"
    category: ToolCategory = ToolCategory.UTILITY
    risk: ToolRisk = ToolRisk.LOW
    version: str = "1.0.0"
    
    # Parameters (override in subclasses)
    parameters: List[ToolParameter] = []
    
    # Behavior
    requires_confirmation: bool = False
    timeout_seconds: float = 60.0
    
    def __init__(self):
        self._logger = logging.getLogger(f"tool.{self.name}")
        self._execution_count = 0
        self._success_count = 0
        self._last_execution: Optional[datetime] = None
    
    # ═══════════════════════════════════════════════════════════════════════════
    # ABSTRACT METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    @abstractmethod
    async def execute(self, **kwargs) -> ToolResult:
        """
        Execute the tool
        
        Must be implemented by subclasses.
        
        Args:
            **kwargs: Tool parameters
        
        Returns:
            ToolResult with execution result
        """
        pass
    
    # ═══════════════════════════════════════════════════════════════════════════
    # VALIDATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    def validate_parameters(self, **kwargs) -> tuple[bool, Optional[str]]:
        """Validate input parameters"""
        for param in self.parameters:
            value = kwargs.get(param.name)
            
            valid, error = param.validate(value)
            if not valid:
                return False, error
        
        return True, None
    
    def get_parameter_value(
        self,
        kwargs: Dict[str, Any],
        name: str,
        default: Any = None
    ) -> Any:
        """Get parameter value with default"""
        value = kwargs.get(name)
        
        if value is None:
            # Check for default in parameter definition
            for param in self.parameters:
                if param.name == name:
                    return param.default if param.default is not None else default
            return default
        
        return value
    
    # ═══════════════════════════════════════════════════════════════════════════
    # EXECUTION WRAPPER
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def run(
        self,
        context: Optional[ToolContext] = None,
        **kwargs
    ) -> ToolResult:
        """
        Run the tool with full handling
        
        Args:
            context: Execution context
            **kwargs: Tool parameters
        
        Returns:
            ToolResult
        """
        context = context or ToolContext()
        start_time = datetime.now()
        
        self._logger.debug(f"Executing {self.name} with {list(kwargs.keys())}")
        
        try:
            # Validate parameters
            valid, error = self.validate_parameters(**kwargs)
            if not valid:
                return ToolResult.fail(
                    error=error or "Invalid parameters",
                    message=f"Parameter validation failed for {self.name}"
                )
            
            # Check confirmation if needed
            if self.requires_confirmation and not context.confirmed:
                return ToolResult(
                    success=False,
                    status=ResultStatus.CANCELLED,
                    message="Confirmation required",
                    error="Tool requires confirmation before execution"
                )
            
            # Handle dry run
            if context.dry_run:
                return ToolResult.ok(
                    message=f"Dry run: {self.name} would execute with {kwargs}"
                )
            
            # Execute with timeout
            try:
                timeout = context.timeout_seconds or self.timeout_seconds
                result = await asyncio.wait_for(
                    self.execute(**kwargs),
                    timeout=timeout
                )
            except asyncio.TimeoutError:
                return ToolResult(
                    success=False,
                    status=ResultStatus.TIMEOUT,
                    error=f"Execution timed out after {timeout}s"
                )
            
            # Update tracking
            self._execution_count += 1
            self._last_execution = datetime.now()
            if result.success:
                self._success_count += 1
            
            # Add execution info
            end_time = datetime.now()
            result.tool_name = self.name
            result.started_at = start_time
            result.completed_at = end_time
            result.execution_time_ms = (end_time - start_time).total_seconds() * 1000
            
            self._logger.debug(
                f"{self.name} completed: {result.status.value} "
                f"({result.execution_time_ms:.1f}ms)"
            )
            
            return result
            
        except Exception as e:
            self._logger.error(f"Error in {self.name}: {e}")
            
            return ToolResult.error(
                error=str(e),
                message=f"Exception in {self.name}"
            )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # HELPER METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def log_info(self, message: str) -> None:
        """Log info message"""
        self._logger.info(message)
    
    def log_warning(self, message: str) -> None:
        """Log warning message"""
        self._logger.warning(message)
    
    def log_error(self, message: str) -> None:
        """Log error message"""
        self._logger.error(message)
    
    def log_debug(self, message: str) -> None:
        """Log debug message"""
        self._logger.debug(message)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # METADATA
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_metadata(self) -> Dict[str, Any]:
        """Get tool metadata"""
        return {
            "name": self.name,
            "description": self.description,
            "category": self.category.value,
            "risk": self.risk.value,
            "version": self.version,
            "requires_confirmation": self.requires_confirmation,
            "parameters": [
                {
                    "name": p.name,
                    "type": p.type,
                    "description": p.description,
                    "required": p.required,
                    "default": p.default
                }
                for p in self.parameters
            ]
        }
    
    def get_help(self) -> str:
        """Get help text for tool"""
        lines = [
            f"🔧 {self.name} (v{self.version})",
            "",
            self.description,
            "",
            f"Category: {self.category.value}",
            f"Risk: {self.risk.value}",
        ]
        
        if self.requires_confirmation:
            lines.append("⚠️ Requires confirmation")
        
        if self.parameters:
            lines.append("")
            lines.append("Parameters:")
            for p in self.parameters:
                req = "required" if p.required else "optional"
                lines.append(f"  • {p.name} ({p.type}, {req}): {p.description}")
        
        return "\n".join(lines)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get execution statistics"""
        return {
            "execution_count": self._execution_count,
            "success_count": self._success_count,
            "success_rate": self._success_count / self._execution_count if self._execution_count > 0 else 0,
            "last_execution": self._last_execution.isoformat() if self._last_execution else None
        }
    
    def __repr__(self) -> str:
        return f"<{self.__class__.__name__}(name='{self.name}', category='{self.category.value}')>"


class ReadOnlyTool(BaseTool):
    """Base class for read-only tools (no modifications)"""
    
    risk = ToolRisk.SAFE
    requires_confirmation = False


class ModifyingTool(BaseTool):
    """Base class for tools that modify data"""
    
    risk = ToolRisk.MEDIUM
    requires_confirmation = False


class DestructiveTool(BaseTool):
    """Base class for destructive tools"""
    
    risk = ToolRisk.HIGH
    requires_confirmation = True


class SystemTool(BaseTool):
    """Base class for system-level tools"""
    
    category = ToolCategory.SYSTEM
    risk = ToolRisk.HIGH
    requires_confirmation = True


# ═══════════════════════════════════════════════════════════════════════════════
# UTILITY FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def create_tool(
    name: str,
    handler: callable,
    description: str = "",
    category: ToolCategory = ToolCategory.UTILITY,
    risk: ToolRisk = ToolRisk.LOW,
    parameters: Optional[List[ToolParameter]] = None
) -> BaseTool:
    """Create a tool from a function"""
    
    class DynamicTool(BaseTool):
        pass
    
    DynamicTool.name = name
    DynamicTool.description = description or handler.__doc__ or ""
    DynamicTool.category = category
    DynamicTool.risk = risk
    DynamicTool.parameters = parameters or []
    
    async def execute(self, **kwargs) -> ToolResult:
        try:
            if asyncio.iscoroutinefunction(handler):
                result = await handler(**kwargs)
            else:
                result = handler(**kwargs)
            
            if isinstance(result, ToolResult):
                return result
            
            return ToolResult.ok(data=result)
            
        except Exception as e:
            return ToolResult.error(str(e))
    
    DynamicTool.execute = execute
    
    return DynamicTool()