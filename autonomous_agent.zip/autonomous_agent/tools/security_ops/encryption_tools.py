"""
═══════════════════════════════════════════════════════════════════════════════════════
ENCRYPTION TOOLS - CRYPTOGRAPHIC ENCRYPTION/DECRYPTION
═══════════════════════════════════════════════════════════════════════════════════════
Provides encryption capabilities:
- Symmetric encryption (AES-GCM, ChaCha20-Poly1305, Fernet)
- Asymmetric encryption (RSA)
- Key generation and management
- File encryption/decryption
- Secure key derivation
- Digital signatures
"""

import asyncio
import logging
import secrets
import base64
import json
import os
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Union, Tuple
from pathlib import Path

logger = logging.getLogger(__name__)

# Try to import cryptography library
try:
    from cryptography.fernet import Fernet, InvalidToken
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM, ChaCha20Poly1305
    from cryptography.hazmat.primitives.asymmetric import rsa, padding
    from cryptography.hazmat.primitives.asymmetric.types import PrivateKeyTypes, PublicKeyTypes
    from cryptography.hazmat.backends import default_backend
    from cryptography.exceptions import InvalidTag
    CRYPTOGRAPHY_AVAILABLE = True
except ImportError:
    CRYPTOGRAPHY_AVAILABLE = False
    logger.warning("cryptography library not available. Install with: pip install cryptography")


class EncryptionAlgorithm(Enum):
    """Supported encryption algorithms."""
    FERNET = "fernet"           # Fernet (AES-128-CBC + HMAC)
    AES_256_GCM = "aes-256-gcm" # AES-256 in GCM mode
    CHACHA20_POLY1305 = "chacha20-poly1305"
    RSA_OAEP = "rsa-oaep"       # RSA with OAEP padding


class KeyDerivationFunction(Enum):
    """Key derivation functions."""
    PBKDF2 = "pbkdf2"
    SCRYPT = "scrypt"


@dataclass
class EncryptionResult:
    """Result of encryption operation."""
    algorithm: str
    ciphertext: bytes
    ciphertext_base64: str
    nonce: Optional[bytes] = None
    tag: Optional[bytes] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
    
    def to_json(self) -> str:
        """Serialize to JSON for storage."""
        return json.dumps({
            "algorithm": self.algorithm,
            "ciphertext": self.ciphertext_base64,
            "nonce": base64.b64encode(self.nonce).decode() if self.nonce else None,
            "tag": base64.b64encode(self.tag).decode() if self.tag else None,
            "metadata": self.metadata,
            "timestamp": self.timestamp.isoformat()
        })
    
    @classmethod
    def from_json(cls, json_str: str) -> "EncryptionResult":
        """Deserialize from JSON."""
        data = json.loads(json_str)
        return cls(
            algorithm=data["algorithm"],
            ciphertext=base64.b64decode(data["ciphertext"]),
            ciphertext_base64=data["ciphertext"],
            nonce=base64.b64decode(data["nonce"]) if data.get("nonce") else None,
            tag=base64.b64decode(data["tag"]) if data.get("tag") else None,
            metadata=data.get("metadata", {}),
            timestamp=datetime.fromisoformat(data["timestamp"])
        )


@dataclass
class KeyPair:
    """Asymmetric key pair."""
    private_key_pem: str
    public_key_pem: str
    algorithm: str
    key_size: int
    created_at: datetime = field(default_factory=datetime.now)
    
    def save(self, private_path: Path, public_path: Path, password: Optional[str] = None) -> None:
        """Save keys to files."""
        private_path.write_text(self.private_key_pem)
        public_path.write_text(self.public_key_pem)
        
        # Set restrictive permissions on private key
        if os.name != 'nt':
            os.chmod(private_path, 0o600)


@dataclass
class DerivedKey:
    """Derived key from password."""
    key: bytes
    key_base64: str
    salt: bytes
    salt_base64: str
    algorithm: str
    iterations: Optional[int] = None
    
    def to_storage(self) -> str:
        """Format for storage (includes salt, not key)."""
        return f"{self.algorithm}${self.salt_base64}"


class EncryptionTools:
    """
    Comprehensive encryption toolkit.
    
    Provides:
    - Symmetric encryption (AES-GCM, ChaCha20, Fernet)
    - Asymmetric encryption (RSA)
    - Key generation and derivation
    - File encryption
    - Digital signatures
    """
    
    def __init__(self):
        if not CRYPTOGRAPHY_AVAILABLE:
            raise RuntimeError(
                "cryptography library required. Install: pip install cryptography"
            )
        
        self.default_algorithm = EncryptionAlgorithm.AES_256_GCM
        self.default_kdf = KeyDerivationFunction.SCRYPT
        self.default_rsa_key_size = 4096
        
        # KDF parameters
        self.pbkdf2_iterations = 100000
        self.scrypt_n = 2**14  # CPU/memory cost
        self.scrypt_r = 8      # Block size
        self.scrypt_p = 1      # Parallelization
        
        logger.info("EncryptionTools initialized")
    
    # ─────────────────────────────────────────────────────────────────────
    # KEY GENERATION
    # ─────────────────────────────────────────────────────────────────────
    
    def generate_key(self, length: int = 32) -> bytes:
        """Generate a random symmetric key."""
        return secrets.token_bytes(length)
    
    def generate_key_base64(self, length: int = 32) -> str:
        """Generate a random key as base64 string."""
        return base64.urlsafe_b64encode(self.generate_key(length)).decode()
    
    def generate_fernet_key(self) -> str:
        """Generate a Fernet-compatible key."""
        return Fernet.generate_key().decode()
    
    async def derive_key(
        self,
        password: str,
        salt: Optional[bytes] = None,
        length: int = 32,
        kdf: KeyDerivationFunction = None
    ) -> DerivedKey:
        """
        Derive a key from a password.
        
        Args:
            password: Password to derive from
            salt: Salt (generated if not provided)
            length: Key length in bytes
            kdf: Key derivation function
        
        Returns:
            DerivedKey with key and salt
        """
        kdf = kdf or self.default_kdf
        
        if salt is None:
            salt = secrets.token_bytes(16)
        
        loop = asyncio.get_event_loop()
        
        if kdf == KeyDerivationFunction.PBKDF2:
            def derive_pbkdf2():
                kdf_instance = PBKDF2HMAC(
                    algorithm=hashes.SHA256(),
                    length=length,
                    salt=salt,
                    iterations=self.pbkdf2_iterations,
                    backend=default_backend()
                )
                return kdf_instance.derive(password.encode())
            
            key = await loop.run_in_executor(None, derive_pbkdf2)
            iterations = self.pbkdf2_iterations
            
        elif kdf == KeyDerivationFunction.SCRYPT:
            def derive_scrypt():
                kdf_instance = Scrypt(
                    salt=salt,
                    length=length,
                    n=self.scrypt_n,
                    r=self.scrypt_r,
                    p=self.scrypt_p,
                    backend=default_backend()
                )
                return kdf_instance.derive(password.encode())
            
            key = await loop.run_in_executor(None, derive_scrypt)
            iterations = None
        
        else:
            raise ValueError(f"Unknown KDF: {kdf}")
        
        return DerivedKey(
            key=key,
            key_base64=base64.urlsafe_b64encode(key).decode(),
            salt=salt,
            salt_base64=base64.urlsafe_b64encode(salt).decode(),
            algorithm=kdf.value,
            iterations=iterations
        )
    
    async def generate_rsa_keypair(
        self,
        key_size: int = None,
        password: Optional[str] = None
    ) -> KeyPair:
        """
        Generate RSA key pair.
        
        Args:
            key_size: Key size in bits (default: 4096)
            password: Optional password to encrypt private key
        
        Returns:
            KeyPair with PEM-encoded keys
        """
        key_size = key_size or self.default_rsa_key_size
        
        loop = asyncio.get_event_loop()
        
        def generate():
            private_key = rsa.generate_private_key(
                public_exponent=65537,
                key_size=key_size,
                backend=default_backend()
            )
            
            # Serialize private key
            if password:
                encryption = serialization.BestAvailableEncryption(
                    password.encode()
                )
            else:
                encryption = serialization.NoEncryption()
            
            private_pem = private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=encryption
            ).decode()
            
            # Serialize public key
            public_pem = private_key.public_key().public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            ).decode()
            
            return private_pem, public_pem
        
        private_pem, public_pem = await loop.run_in_executor(None, generate)
        
        return KeyPair(
            private_key_pem=private_pem,
            public_key_pem=public_pem,
            algorithm="RSA",
            key_size=key_size
        )
    
    # ─────────────────────────────────────────────────────────────────────
    # SYMMETRIC ENCRYPTION
    # ─────────────────────────────────────────────────────────────────────
    
    async def encrypt(
        self,
        plaintext: Union[str, bytes],
        key: Union[str, bytes],
        algorithm: EncryptionAlgorithm = None,
        associated_data: Optional[bytes] = None
    ) -> EncryptionResult:
        """
        Encrypt data with symmetric encryption.
        
        Args:
            plaintext: Data to encrypt
            key: Encryption key
            algorithm: Encryption algorithm
            associated_data: Additional authenticated data (for AEAD)
        
        Returns:
            EncryptionResult with ciphertext
        """
        algorithm = algorithm or self.default_algorithm
        
        # Convert inputs
        if isinstance(plaintext, str):
            plaintext = plaintext.encode('utf-8')
        if isinstance(key, str):
            key = base64.urlsafe_b64decode(key)
        
        loop = asyncio.get_event_loop()
        
        if algorithm == EncryptionAlgorithm.FERNET:
            # Fernet requires 32-byte url-safe base64 key
            if len(key) != 32:
                raise ValueError("Fernet requires a 32-byte key")
            
            fernet_key = base64.urlsafe_b64encode(key)
            
            def encrypt_fernet():
                f = Fernet(fernet_key)
                return f.encrypt(plaintext)
            
            ciphertext = await loop.run_in_executor(None, encrypt_fernet)
            
            return EncryptionResult(
                algorithm=algorithm.value,
                ciphertext=ciphertext,
                ciphertext_base64=ciphertext.decode()
            )
        
        elif algorithm == EncryptionAlgorithm.AES_256_GCM:
            if len(key) != 32:
                raise ValueError("AES-256-GCM requires a 32-byte key")
            
            def encrypt_aes_gcm():
                nonce = secrets.token_bytes(12)  # 96-bit nonce
                aesgcm = AESGCM(key)
                ciphertext = aesgcm.encrypt(nonce, plaintext, associated_data)
                return ciphertext, nonce
            
            ciphertext, nonce = await loop.run_in_executor(None, encrypt_aes_gcm)
            
            # Combine nonce + ciphertext for storage
            combined = nonce + ciphertext
            
            return EncryptionResult(
                algorithm=algorithm.value,
                ciphertext=combined,
                ciphertext_base64=base64.b64encode(combined).decode(),
                nonce=nonce
            )
        
        elif algorithm == EncryptionAlgorithm.CHACHA20_POLY1305:
            if len(key) != 32:
                raise ValueError("ChaCha20-Poly1305 requires a 32-byte key")
            
            def encrypt_chacha():
                nonce = secrets.token_bytes(12)
                chacha = ChaCha20Poly1305(key)
                ciphertext = chacha.encrypt(nonce, plaintext, associated_data)
                return ciphertext, nonce
            
            ciphertext, nonce = await loop.run_in_executor(None, encrypt_chacha)
            
            combined = nonce + ciphertext
            
            return EncryptionResult(
                algorithm=algorithm.value,
                ciphertext=combined,
                ciphertext_base64=base64.b64encode(combined).decode(),
                nonce=nonce
            )
        
        else:
            raise ValueError(f"Unsupported algorithm: {algorithm}")
    
    async def decrypt(
        self,
        ciphertext: Union[str, bytes, EncryptionResult],
        key: Union[str, bytes],
        algorithm: EncryptionAlgorithm = None,
        associated_data: Optional[bytes] = None
    ) -> bytes:
        """
        Decrypt data.
        
        Args:
            ciphertext: Encrypted data or EncryptionResult
            key: Decryption key
            algorithm: Encryption algorithm
            associated_data: Additional authenticated data
        
        Returns:
            Decrypted plaintext as bytes
        """
        # Handle EncryptionResult
        if isinstance(ciphertext, EncryptionResult):
            algorithm = EncryptionAlgorithm(ciphertext.algorithm)
            ciphertext = ciphertext.ciphertext
        
        algorithm = algorithm or self.default_algorithm
        
        # Convert inputs
        if isinstance(ciphertext, str):
            ciphertext = base64.b64decode(ciphertext)
        if isinstance(key, str):
            key = base64.urlsafe_b64decode(key)
        
        loop = asyncio.get_event_loop()
        
        if algorithm == EncryptionAlgorithm.FERNET:
            fernet_key = base64.urlsafe_b64encode(key)
            
            def decrypt_fernet():
                f = Fernet(fernet_key)
                return f.decrypt(ciphertext)
            
            return await loop.run_in_executor(None, decrypt_fernet)
        
        elif algorithm == EncryptionAlgorithm.AES_256_GCM:
            def decrypt_aes_gcm():
                nonce = ciphertext[:12]
                actual_ciphertext = ciphertext[12:]
                aesgcm = AESGCM(key)
                return aesgcm.decrypt(nonce, actual_ciphertext, associated_data)
            
            return await loop.run_in_executor(None, decrypt_aes_gcm)
        
        elif algorithm == EncryptionAlgorithm.CHACHA20_POLY1305:
            def decrypt_chacha():
                nonce = ciphertext[:12]
                actual_ciphertext = ciphertext[12:]
                chacha = ChaCha20Poly1305(key)
                return chacha.decrypt(nonce, actual_ciphertext, associated_data)
            
            return await loop.run_in_executor(None, decrypt_chacha)
        
        else:
            raise ValueError(f"Unsupported algorithm: {algorithm}")
    
    async def decrypt_string(
        self,
        ciphertext: Union[str, bytes, EncryptionResult],
        key: Union[str, bytes],
        algorithm: EncryptionAlgorithm = None,
        encoding: str = "utf-8"
    ) -> str:
        """Decrypt and return as string."""
        plaintext = await self.decrypt(ciphertext, key, algorithm)
        return plaintext.decode(encoding)
    
    # ─────────────────────────────────────────────────────────────────────
    # PASSWORD-BASED ENCRYPTION
    # ─────────────────────────────────────────────────────────────────────
    
    async def encrypt_with_password(
        self,
        plaintext: Union[str, bytes],
        password: str,
        algorithm: EncryptionAlgorithm = None
    ) -> EncryptionResult:
        """
        Encrypt data using a password.
        
        Derives a key from the password using scrypt.
        """
        # Derive key from password
        derived = await self.derive_key(password)
        
        # Encrypt
        result = await self.encrypt(plaintext, derived.key, algorithm)
        
        # Add salt to metadata for decryption
        result.metadata["salt"] = derived.salt_base64
        result.metadata["kdf"] = derived.algorithm
        
        return result
    
    async def decrypt_with_password(
        self,
        ciphertext: Union[str, bytes, EncryptionResult],
        password: str
    ) -> bytes:
        """
        Decrypt data encrypted with a password.
        """
        # Get salt from result or raise error
        if isinstance(ciphertext, EncryptionResult):
            salt_b64 = ciphertext.metadata.get("salt")
            if not salt_b64:
                raise ValueError("Missing salt in encryption result")
            salt = base64.urlsafe_b64decode(salt_b64)
            kdf_name = ciphertext.metadata.get("kdf", "scrypt")
            kdf = KeyDerivationFunction(kdf_name)
        else:
            raise ValueError("Password decryption requires EncryptionResult with salt")
        
        # Derive key
        derived = await self.derive_key(password, salt=salt, kdf=kdf)
        
        # Decrypt
        return await self.decrypt(ciphertext, derived.key)
    
    # ─────────────────────────────────────────────────────────────────────
    # ASYMMETRIC ENCRYPTION (RSA)
    # ─────────────────────────────────────────────────────────────────────
    
    async def encrypt_rsa(
        self,
        plaintext: Union[str, bytes],
        public_key_pem: str
    ) -> EncryptionResult:
        """
        Encrypt with RSA public key.
        
        Note: RSA can only encrypt small amounts of data.
        For large data, use hybrid encryption.
        """
        if isinstance(plaintext, str):
            plaintext = plaintext.encode('utf-8')
        
        loop = asyncio.get_event_loop()
        
        def encrypt():
            public_key = serialization.load_pem_public_key(
                public_key_pem.encode(),
                backend=default_backend()
            )
            
            ciphertext = public_key.encrypt(
                plaintext,
                padding.OAEP(
                    mgf=padding.MGF1(algorithm=hashes.SHA256()),
                    algorithm=hashes.SHA256(),
                    label=None
                )
            )
            return ciphertext
        
        ciphertext = await loop.run_in_executor(None, encrypt)
        
        return EncryptionResult(
            algorithm=EncryptionAlgorithm.RSA_OAEP.value,
            ciphertext=ciphertext,
            ciphertext_base64=base64.b64encode(ciphertext).decode()
        )
    
    async def decrypt_rsa(
        self,
        ciphertext: Union[str, bytes, EncryptionResult],
        private_key_pem: str,
        password: Optional[str] = None
    ) -> bytes:
        """Decrypt with RSA private key."""
        if isinstance(ciphertext, EncryptionResult):
            ciphertext = ciphertext.ciphertext
        if isinstance(ciphertext, str):
            ciphertext = base64.b64decode(ciphertext)
        
        loop = asyncio.get_event_loop()
        
        def decrypt():
            private_key = serialization.load_pem_private_key(
                private_key_pem.encode(),
                password=password.encode() if password else None,
                backend=default_backend()
            )
            
            plaintext = private_key.decrypt(
                ciphertext,
                padding.OAEP(
                    mgf=padding.MGF1(algorithm=hashes.SHA256()),
                    algorithm=hashes.SHA256(),
                    label=None
                )
            )
            return plaintext
        
        return await loop.run_in_executor(None, decrypt)
    
    # ─────────────────────────────────────────────────────────────────────
    # FILE ENCRYPTION
    # ─────────────────────────────────────────────────────────────────────
    
    async def encrypt_file(
        self,
        input_path: Union[str, Path],
        output_path: Union[str, Path],
        key: Union[str, bytes],
        algorithm: EncryptionAlgorithm = None
    ) -> EncryptionResult:
        """
        Encrypt a file.
        
        Args:
            input_path: Path to plaintext file
            output_path: Path for encrypted output
            key: Encryption key
            algorithm: Encryption algorithm
        
        Returns:
            EncryptionResult with metadata
        """
        input_path = Path(input_path)
        output_path = Path(output_path)
        
        # Read file
        plaintext = input_path.read_bytes()
        
        # Encrypt
        result = await self.encrypt(plaintext, key, algorithm)
        
        # Write encrypted data
        output_path.write_bytes(result.ciphertext)
        
        # Add file metadata
        result.metadata["original_filename"] = input_path.name
        result.metadata["original_size"] = len(plaintext)
        
        logger.info(f"Encrypted file: {input_path} -> {output_path}")
        
        return result
    
    async def decrypt_file(
        self,
        input_path: Union[str, Path],
        output_path: Union[str, Path],
        key: Union[str, bytes],
        algorithm: EncryptionAlgorithm = None
    ) -> int:
        """
        Decrypt a file.
        
        Returns:
            Size of decrypted file
        """
        input_path = Path(input_path)
        output_path = Path(output_path)
        
        # Read encrypted data
        ciphertext = input_path.read_bytes()
        
        # Decrypt
        plaintext = await self.decrypt(ciphertext, key, algorithm)
        
        # Write decrypted data
        output_path.write_bytes(plaintext)
        
        logger.info(f"Decrypted file: {input_path} -> {output_path}")
        
        return len(plaintext)
    
    async def encrypt_file_with_password(
        self,
        input_path: Union[str, Path],
        output_path: Union[str, Path],
        password: str
    ) -> EncryptionResult:
        """Encrypt a file with a password."""
        input_path = Path(input_path)
        output_path = Path(output_path)
        
        plaintext = input_path.read_bytes()
        result = await self.encrypt_with_password(plaintext, password)
        
        # Write header + ciphertext
        # Header format: algorithm$kdf$salt$nonce_length$nonce
        header = json.dumps({
            "algorithm": result.algorithm,
            "kdf": result.metadata.get("kdf"),
            "salt": result.metadata.get("salt"),
        }).encode()
        
        header_len = len(header).to_bytes(4, 'big')
        output_path.write_bytes(header_len + header + result.ciphertext)
        
        return result
    
    async def decrypt_file_with_password(
        self,
        input_path: Union[str, Path],
        output_path: Union[str, Path],
        password: str
    ) -> int:
        """Decrypt a file encrypted with a password."""
        input_path = Path(input_path)
        output_path = Path(output_path)
        
        data = input_path.read_bytes()
        
        # Parse header
        header_len = int.from_bytes(data[:4], 'big')
        header = json.loads(data[4:4+header_len])
        ciphertext = data[4+header_len:]
        
        # Recreate EncryptionResult
        result = EncryptionResult(
            algorithm=header["algorithm"],
            ciphertext=ciphertext,
            ciphertext_base64=base64.b64encode(ciphertext).decode(),
            metadata={"salt": header["salt"], "kdf": header["kdf"]}
        )
        
        # Decrypt
        plaintext = await self.decrypt_with_password(result, password)
        output_path.write_bytes(plaintext)
        
        return len(plaintext)
    
    # ─────────────────────────────────────────────────────────────────────
    # DIGITAL SIGNATURES
    # ─────────────────────────────────────────────────────────────────────
    
    async def sign(
        self,
        data: Union[str, bytes],
        private_key_pem: str,
        password: Optional[str] = None
    ) -> str:
        """
        Create digital signature.
        
        Returns:
            Base64-encoded signature
        """
        if isinstance(data, str):
            data = data.encode('utf-8')
        
        loop = asyncio.get_event_loop()
        
        def create_signature():
            private_key = serialization.load_pem_private_key(
                private_key_pem.encode(),
                password=password.encode() if password else None,
                backend=default_backend()
            )
            
            signature = private_key.sign(
                data,
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )
            return signature
        
        signature = await loop.run_in_executor(None, create_signature)
        return base64.b64encode(signature).decode()
    
    async def verify_signature(
        self,
        data: Union[str, bytes],
        signature: str,
        public_key_pem: str
    ) -> bool:
        """
        Verify digital signature.
        
        Returns:
            True if signature is valid
        """
        if isinstance(data, str):
            data = data.encode('utf-8')
        
        signature_bytes = base64.b64decode(signature)
        
        loop = asyncio.get_event_loop()
        
        def verify():
            public_key = serialization.load_pem_public_key(
                public_key_pem.encode(),
                backend=default_backend()
            )
            
            try:
                public_key.verify(
                    signature_bytes,
                    data,
                    padding.PSS(
                        mgf=padding.MGF1(hashes.SHA256()),
                        salt_length=padding.PSS.MAX_LENGTH
                    ),
                    hashes.SHA256()
                )
                return True
            except Exception:
                return False
        
        return await loop.run_in_executor(None, verify)


# Singleton instance
_encryption_tools: Optional[EncryptionTools] = None


def get_encryption_tools() -> EncryptionTools:
    """Get or create encryption tools singleton."""
    global _encryption_tools
    if _encryption_tools is None:
        _encryption_tools = EncryptionTools()
    return _encryption_tools


# Convenience functions
async def quick_encrypt(data: Union[str, bytes], password: str) -> str:
    """Quick encryption with password, returns base64."""
    tools = get_encryption_tools()
    result = await tools.encrypt_with_password(data, password)
    return result.to_json()


async def quick_decrypt(encrypted_json: str, password: str) -> str:
    """Quick decryption from JSON result."""
    tools = get_encryption_tools()
    result = EncryptionResult.from_json(encrypted_json)
    plaintext = await tools.decrypt_with_password(result, password)
    return plaintext.decode('utf-8')