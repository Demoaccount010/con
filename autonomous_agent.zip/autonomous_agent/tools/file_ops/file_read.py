"""
File Read Tool - Comprehensive file reading operations.
Supports text, binary, streaming, and structured file reading.
"""

import asyncio
import aiofiles
import os
import mimetypes
import hashlib
import chardet
from pathlib import Path
from typing import Optional, List, Dict, Any, AsyncIterator, Union
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import json
import logging

# Import from our tool system
import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from tools.base_tool import (
    BaseTool, ToolResult, ToolStatus, ToolCategory, 
    RiskLevel, tool_registry
)
from security.path_validator import PathValidator
from output.output_manager import OutputManager

logger = logging.getLogger(__name__)


class ReadMode(Enum):
    """File reading modes."""
    TEXT = "text"
    BINARY = "binary"
    LINES = "lines"
    CHUNKS = "chunks"
    JSON = "json"
    STREAM = "stream"


class EncodingDetection(Enum):
    """Encoding detection strategy."""
    AUTO = "auto"
    UTF8 = "utf-8"
    LATIN1 = "latin-1"
    ASCII = "ascii"
    SPECIFIED = "specified"


@dataclass
class FileMetadata:
    """Metadata about a file."""
    path: str
    exists: bool
    size: int
    size_human: str
    mime_type: str
    encoding: Optional[str]
    is_text: bool
    is_binary: bool
    created: Optional[datetime]
    modified: Optional[datetime]
    accessed: Optional[datetime]
    permissions: str
    owner: Optional[str]
    checksum_md5: Optional[str] = None
    checksum_sha256: Optional[str] = None
    line_count: Optional[int] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'path': self.path,
            'exists': self.exists,
            'size': self.size,
            'size_human': self.size_human,
            'mime_type': self.mime_type,
            'encoding': self.encoding,
            'is_text': self.is_text,
            'is_binary': self.is_binary,
            'created': self.created.isoformat() if self.created else None,
            'modified': self.modified.isoformat() if self.modified else None,
            'accessed': self.accessed.isoformat() if self.accessed else None,
            'permissions': self.permissions,
            'owner': self.owner,
            'checksum_md5': self.checksum_md5,
            'checksum_sha256': self.checksum_sha256,
            'line_count': self.line_count
        }


@dataclass
class ReadResult:
    """Result of a file read operation."""
    success: bool
    content: Optional[Union[str, bytes, List[str], Dict]] = None
    metadata: Optional[FileMetadata] = None
    error: Optional[str] = None
    encoding_used: Optional[str] = None
    bytes_read: int = 0
    lines_read: int = 0
    read_time_ms: float = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'success': self.success,
            'content': self.content if not isinstance(self.content, bytes) else f"<binary: {len(self.content)} bytes>",
            'metadata': self.metadata.to_dict() if self.metadata else None,
            'error': self.error,
            'encoding_used': self.encoding_used,
            'bytes_read': self.bytes_read,
            'lines_read': self.lines_read,
            'read_time_ms': self.read_time_ms
        }


class FileReadTool(BaseTool):
    """
    Comprehensive file reading tool.
    
    Capabilities:
    - Read text files with encoding detection
    - Read binary files
    - Read files line by line
    - Read files in chunks (for large files)
    - Read JSON files with parsing
    - Stream file content
    - Get file metadata and checksums
    """
    
    def __init__(self, path_validator: Optional[PathValidator] = None):
        super().__init__(
            name="file_read",
            description="Read files with multiple modes (text, binary, lines, chunks, JSON)",
            category=ToolCategory.FILE,
            risk_level=RiskLevel.LOW,
            requires_confirmation=False,
            timeout=60.0,
            version="1.0.0"
        )
        self.path_validator = path_validator or PathValidator()
        self.output = OutputManager()
        
        # Maximum file size for full read (100MB)
        self.max_full_read_size = 100 * 1024 * 1024
        
        # Default chunk size (1MB)
        self.default_chunk_size = 1024 * 1024
        
        # Text file extensions
        self.text_extensions = {
            '.txt', '.md', '.py', '.js', '.ts', '.json', '.yaml', '.yml',
            '.xml', '.html', '.htm', '.css', '.csv', '.log', '.ini', '.cfg',
            '.conf', '.sh', '.bash', '.zsh', '.fish', '.sql', '.go', '.rs',
            '.java', '.c', '.cpp', '.h', '.hpp', '.rb', '.php', '.pl', '.r',
            '.scala', '.kt', '.swift', '.m', '.mm', '.vue', '.svelte', '.jsx',
            '.tsx', '.toml', '.env', '.gitignore', '.dockerignore', '.editorconfig'
        }
    
    def _human_readable_size(self, size: int) -> str:
        """Convert bytes to human readable format."""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size < 1024:
                return f"{size:.2f} {unit}"
            size /= 1024
        return f"{size:.2f} PB"
    
    async def _detect_encoding(self, file_path: Path, sample_size: int = 10000) -> str:
        """Detect file encoding using chardet."""
        try:
            async with aiofiles.open(file_path, 'rb') as f:
                sample = await f.read(sample_size)
            
            if not sample:
                return 'utf-8'
            
            result = chardet.detect(sample)
            encoding = result.get('encoding', 'utf-8')
            confidence = result.get('confidence', 0)
            
            # If confidence is low, default to utf-8
            if confidence < 0.7:
                encoding = 'utf-8'
            
            return encoding or 'utf-8'
        except Exception as e:
            logger.warning(f"Encoding detection failed: {e}, defaulting to utf-8")
            return 'utf-8'
    
    async def _get_file_metadata(
        self, 
        file_path: Path, 
        calculate_checksum: bool = False,
        count_lines: bool = False
    ) -> FileMetadata:
        """Get comprehensive file metadata."""
        stat = file_path.stat()
        
        # Determine MIME type
        mime_type, _ = mimetypes.guess_type(str(file_path))
        mime_type = mime_type or 'application/octet-stream'
        
        # Determine if text or binary
        is_text = (
            file_path.suffix.lower() in self.text_extensions or
            (mime_type and mime_type.startswith('text/'))
        )
        
        # Detect encoding for text files
        encoding = None
        if is_text and stat.st_size > 0:
            encoding = await self._detect_encoding(file_path)
        
        # Get timestamps
        created = datetime.fromtimestamp(stat.st_ctime)
        modified = datetime.fromtimestamp(stat.st_mtime)
        accessed = datetime.fromtimestamp(stat.st_atime)
        
        # Get permissions
        permissions = oct(stat.st_mode)[-3:]
        
        # Get owner (Unix only)
        owner = None
        try:
            import pwd
            owner = pwd.getpwuid(stat.st_uid).pw_name
        except (ImportError, KeyError):
            pass
        
        metadata = FileMetadata(
            path=str(file_path.absolute()),
            exists=True,
            size=stat.st_size,
            size_human=self._human_readable_size(stat.st_size),
            mime_type=mime_type,
            encoding=encoding,
            is_text=is_text,
            is_binary=not is_text,
            created=created,
            modified=modified,
            accessed=accessed,
            permissions=permissions,
            owner=owner
        )
        
        # Calculate checksums if requested
        if calculate_checksum:
            md5_hash = hashlib.md5()
            sha256_hash = hashlib.sha256()
            
            async with aiofiles.open(file_path, 'rb') as f:
                while chunk := await f.read(8192):
                    md5_hash.update(chunk)
                    sha256_hash.update(chunk)
            
            metadata.checksum_md5 = md5_hash.hexdigest()
            metadata.checksum_sha256 = sha256_hash.hexdigest()
        
        # Count lines if requested and is text file
        if count_lines and is_text:
            try:
                line_count = 0
                async with aiofiles.open(file_path, 'r', encoding=encoding or 'utf-8') as f:
                    async for _ in f:
                        line_count += 1
                metadata.line_count = line_count
            except Exception:
                pass
        
        return metadata
    
    async def read_text(
        self,
        file_path: str,
        encoding: str = "auto",
        start_line: Optional[int] = None,
        end_line: Optional[int] = None,
        max_chars: Optional[int] = None
    ) -> ReadResult:
        """
        Read file as text.
        
        Args:
            file_path: Path to file
            encoding: Encoding to use ('auto' for detection)
            start_line: Start reading from this line (1-indexed)
            end_line: Stop reading at this line
            max_chars: Maximum characters to read
            
        Returns:
            ReadResult with text content
        """
        start_time = datetime.now()
        path = Path(file_path).resolve()
        
        try:
            # Validate path
            if not await self.path_validator.validate(path, 'read'):
                return ReadResult(
                    success=False,
                    error=f"Path validation failed: {path}"
                )
            
            if not path.exists():
                return ReadResult(
                    success=False,
                    error=f"File not found: {path}"
                )
            
            if not path.is_file():
                return ReadResult(
                    success=False,
                    error=f"Not a file: {path}"
                )
            
            # Get metadata
            metadata = await self._get_file_metadata(path)
            
            # Check file size
            if metadata.size > self.max_full_read_size:
                return ReadResult(
                    success=False,
                    error=f"File too large for full read: {metadata.size_human}. Use read_chunks() instead.",
                    metadata=metadata
                )
            
            # Determine encoding
            if encoding == "auto":
                encoding = await self._detect_encoding(path)
            
            # Read file
            async with aiofiles.open(path, 'r', encoding=encoding, errors='replace') as f:
                if start_line or end_line:
                    # Read specific lines
                    lines = []
                    line_num = 0
                    async for line in f:
                        line_num += 1
                        if start_line and line_num < start_line:
                            continue
                        if end_line and line_num > end_line:
                            break
                        lines.append(line)
                    content = ''.join(lines)
                    lines_read = len(lines)
                else:
                    content = await f.read()
                    if max_chars and len(content) > max_chars:
                        content = content[:max_chars]
                    lines_read = content.count('\n')
            
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            
            return ReadResult(
                success=True,
                content=content,
                metadata=metadata,
                encoding_used=encoding,
                bytes_read=len(content.encode(encoding)),
                lines_read=lines_read,
                read_time_ms=elapsed
            )
            
        except UnicodeDecodeError as e:
            return ReadResult(
                success=False,
                error=f"Encoding error: {e}. Try specifying a different encoding."
            )
        except PermissionError:
            return ReadResult(
                success=False,
                error=f"Permission denied: {path}"
            )
        except Exception as e:
            logger.error(f"Error reading file {path}: {e}")
            return ReadResult(
                success=False,
                error=str(e)
            )
    
    async def read_binary(
        self,
        file_path: str,
        offset: int = 0,
        length: Optional[int] = None
    ) -> ReadResult:
        """
        Read file as binary.
        
        Args:
            file_path: Path to file
            offset: Start reading from this byte offset
            length: Number of bytes to read (None for all)
            
        Returns:
            ReadResult with binary content
        """
        start_time = datetime.now()
        path = Path(file_path).resolve()
        
        try:
            if not await self.path_validator.validate(path, 'read'):
                return ReadResult(
                    success=False,
                    error=f"Path validation failed: {path}"
                )
            
            if not path.exists():
                return ReadResult(success=False, error=f"File not found: {path}")
            
            metadata = await self._get_file_metadata(path)
            
            # Check size limits
            read_size = length or (metadata.size - offset)
            if read_size > self.max_full_read_size:
                return ReadResult(
                    success=False,
                    error=f"Read size too large: {self._human_readable_size(read_size)}",
                    metadata=metadata
                )
            
            async with aiofiles.open(path, 'rb') as f:
                if offset > 0:
                    await f.seek(offset)
                content = await f.read(length)
            
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            
            return ReadResult(
                success=True,
                content=content,
                metadata=metadata,
                bytes_read=len(content),
                read_time_ms=elapsed
            )
            
        except Exception as e:
            logger.error(f"Error reading binary file {path}: {e}")
            return ReadResult(success=False, error=str(e))
    
    async def read_lines(
        self,
        file_path: str,
        encoding: str = "auto",
        strip: bool = True,
        skip_empty: bool = False,
        start: int = 0,
        count: Optional[int] = None
    ) -> ReadResult:
        """
        Read file as list of lines.
        
        Args:
            file_path: Path to file
            encoding: Encoding to use
            strip: Strip whitespace from lines
            skip_empty: Skip empty lines
            start: Start from this line (0-indexed)
            count: Number of lines to read
            
        Returns:
            ReadResult with list of lines
        """
        start_time = datetime.now()
        path = Path(file_path).resolve()
        
        try:
            if not await self.path_validator.validate(path, 'read'):
                return ReadResult(success=False, error=f"Path validation failed: {path}")
            
            if not path.exists():
                return ReadResult(success=False, error=f"File not found: {path}")
            
            metadata = await self._get_file_metadata(path)
            
            if encoding == "auto":
                encoding = await self._detect_encoding(path)
            
            lines = []
            line_num = 0
            bytes_read = 0
            
            async with aiofiles.open(path, 'r', encoding=encoding, errors='replace') as f:
                async for line in f:
                    if line_num < start:
                        line_num += 1
                        continue
                    
                    if count and len(lines) >= count:
                        break
                    
                    if strip:
                        line = line.strip()
                    else:
                        line = line.rstrip('\n\r')
                    
                    if skip_empty and not line:
                        line_num += 1
                        continue
                    
                    lines.append(line)
                    bytes_read += len(line.encode(encoding))
                    line_num += 1
            
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            
            return ReadResult(
                success=True,
                content=lines,
                metadata=metadata,
                encoding_used=encoding,
                bytes_read=bytes_read,
                lines_read=len(lines),
                read_time_ms=elapsed
            )
            
        except Exception as e:
            logger.error(f"Error reading lines from {path}: {e}")
            return ReadResult(success=False, error=str(e))
    
    async def read_chunks(
        self,
        file_path: str,
        chunk_size: Optional[int] = None
    ) -> AsyncIterator[bytes]:
        """
        Read file in chunks (for large files).
        
        Args:
            file_path: Path to file
            chunk_size: Size of each chunk in bytes
            
        Yields:
            Chunks of file content
        """
        path = Path(file_path).resolve()
        chunk_size = chunk_size or self.default_chunk_size
        
        if not await self.path_validator.validate(path, 'read'):
            raise PermissionError(f"Path validation failed: {path}")
        
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        
        async with aiofiles.open(path, 'rb') as f:
            while True:
                chunk = await f.read(chunk_size)
                if not chunk:
                    break
                yield chunk
    
    async def read_json(
        self,
        file_path: str,
        encoding: str = "utf-8"
    ) -> ReadResult:
        """
        Read and parse JSON file.
        
        Args:
            file_path: Path to JSON file
            encoding: File encoding
            
        Returns:
            ReadResult with parsed JSON data
        """
        start_time = datetime.now()
        path = Path(file_path).resolve()
        
        try:
            if not await self.path_validator.validate(path, 'read'):
                return ReadResult(success=False, error=f"Path validation failed: {path}")
            
            if not path.exists():
                return ReadResult(success=False, error=f"File not found: {path}")
            
            metadata = await self._get_file_metadata(path)
            
            async with aiofiles.open(path, 'r', encoding=encoding) as f:
                content = await f.read()
            
            parsed = json.loads(content)
            
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            
            return ReadResult(
                success=True,
                content=parsed,
                metadata=metadata,
                encoding_used=encoding,
                bytes_read=len(content.encode(encoding)),
                read_time_ms=elapsed
            )
            
        except json.JSONDecodeError as e:
            return ReadResult(
                success=False,
                error=f"JSON parsing error: {e}"
            )
        except Exception as e:
            logger.error(f"Error reading JSON file {path}: {e}")
            return ReadResult(success=False, error=str(e))
    
    async def get_metadata(
        self,
        file_path: str,
        calculate_checksum: bool = False,
        count_lines: bool = False
    ) -> ReadResult:
        """
        Get file metadata without reading content.
        
        Args:
            file_path: Path to file
            calculate_checksum: Calculate MD5 and SHA256 checksums
            count_lines: Count lines (for text files)
            
        Returns:
            ReadResult with metadata only
        """
        start_time = datetime.now()
        path = Path(file_path).resolve()
        
        try:
            if not path.exists():
                return ReadResult(
                    success=False,
                    error=f"File not found: {path}",
                    metadata=FileMetadata(
                        path=str(path),
                        exists=False,
                        size=0,
                        size_human="0 B",
                        mime_type="unknown",
                        encoding=None,
                        is_text=False,
                        is_binary=False,
                        created=None,
                        modified=None,
                        accessed=None,
                        permissions="",
                        owner=None
                    )
                )
            
            metadata = await self._get_file_metadata(
                path, 
                calculate_checksum=calculate_checksum,
                count_lines=count_lines
            )
            
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            
            return ReadResult(
                success=True,
                metadata=metadata,
                read_time_ms=elapsed
            )
            
        except Exception as e:
            logger.error(f"Error getting metadata for {path}: {e}")
            return ReadResult(success=False, error=str(e))
    
    async def head(
        self,
        file_path: str,
        lines: int = 10,
        encoding: str = "auto"
    ) -> ReadResult:
        """
        Read first N lines of file (like Unix head).
        
        Args:
            file_path: Path to file
            lines: Number of lines to read
            encoding: File encoding
            
        Returns:
            ReadResult with first N lines
        """
        return await self.read_lines(
            file_path,
            encoding=encoding,
            start=0,
            count=lines
        )
    
    async def tail(
        self,
        file_path: str,
        lines: int = 10,
        encoding: str = "auto"
    ) -> ReadResult:
        """
        Read last N lines of file (like Unix tail).
        
        Args:
            file_path: Path to file
            lines: Number of lines to read
            encoding: File encoding
            
        Returns:
            ReadResult with last N lines
        """
        start_time = datetime.now()
        path = Path(file_path).resolve()
        
        try:
            if not await self.path_validator.validate(path, 'read'):
                return ReadResult(success=False, error=f"Path validation failed: {path}")
            
            if not path.exists():
                return ReadResult(success=False, error=f"File not found: {path}")
            
            metadata = await self._get_file_metadata(path)
            
            if encoding == "auto":
                encoding = await self._detect_encoding(path)
            
            # Read all lines and take last N
            all_lines = []
            async with aiofiles.open(path, 'r', encoding=encoding, errors='replace') as f:
                async for line in f:
                    all_lines.append(line.rstrip('\n\r'))
            
            result_lines = all_lines[-lines:] if len(all_lines) > lines else all_lines
            
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            
            return ReadResult(
                success=True,
                content=result_lines,
                metadata=metadata,
                encoding_used=encoding,
                lines_read=len(result_lines),
                read_time_ms=elapsed
            )
            
        except Exception as e:
            logger.error(f"Error reading tail of {path}: {e}")
            return ReadResult(success=False, error=str(e))
    
    async def search(
        self,
        file_path: str,
        pattern: str,
        case_sensitive: bool = True,
        max_matches: int = 100,
        encoding: str = "auto"
    ) -> ReadResult:
        """
        Search for pattern in file.
        
        Args:
            file_path: Path to file
            pattern: Pattern to search for
            case_sensitive: Case sensitive search
            max_matches: Maximum matches to return
            encoding: File encoding
            
        Returns:
            ReadResult with matching lines
        """
        import re
        
        start_time = datetime.now()
        path = Path(file_path).resolve()
        
        try:
            if not await self.path_validator.validate(path, 'read'):
                return ReadResult(success=False, error=f"Path validation failed: {path}")
            
            if not path.exists():
                return ReadResult(success=False, error=f"File not found: {path}")
            
            metadata = await self._get_file_metadata(path)
            
            if encoding == "auto":
                encoding = await self._detect_encoding(path)
            
            flags = 0 if case_sensitive else re.IGNORECASE
            regex = re.compile(pattern, flags)
            
            matches = []
            line_num = 0
            
            async with aiofiles.open(path, 'r', encoding=encoding, errors='replace') as f:
                async for line in f:
                    line_num += 1
                    if regex.search(line):
                        matches.append({
                            'line_number': line_num,
                            'content': line.rstrip('\n\r'),
                            'matches': [m.group() for m in regex.finditer(line)]
                        })
                        if len(matches) >= max_matches:
                            break
            
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            
            return ReadResult(
                success=True,
                content={
                    'pattern': pattern,
                    'total_matches': len(matches),
                    'matches': matches
                },
                metadata=metadata,
                encoding_used=encoding,
                lines_read=line_num,
                read_time_ms=elapsed
            )
            
        except re.error as e:
            return ReadResult(success=False, error=f"Invalid regex pattern: {e}")
        except Exception as e:
            logger.error(f"Error searching in {path}: {e}")
            return ReadResult(success=False, error=str(e))
    
    async def execute(self, **kwargs) -> ToolResult:
        """
        Execute file read operation.
        
        Supported operations via 'operation' parameter:
        - text: Read as text
        - binary: Read as binary
        - lines: Read as list of lines
        - json: Read and parse JSON
        - metadata: Get file metadata
        - head: Read first N lines
        - tail: Read last N lines
        - search: Search for pattern
        """
        operation = kwargs.get('operation', 'text')
        file_path = kwargs.get('file_path') or kwargs.get('path')
        
        if not file_path:
            return ToolResult(
                status=ToolStatus.FAILURE,
                error="file_path is required"
            )
        
        start_time = datetime.now()
        
        try:
            if operation == 'text':
                result = await self.read_text(
                    file_path,
                    encoding=kwargs.get('encoding', 'auto'),
                    start_line=kwargs.get('start_line'),
                    end_line=kwargs.get('end_line'),
                    max_chars=kwargs.get('max_chars')
                )
            elif operation == 'binary':
                result = await self.read_binary(
                    file_path,
                    offset=kwargs.get('offset', 0),
                    length=kwargs.get('length')
                )
            elif operation == 'lines':
                result = await self.read_lines(
                    file_path,
                    encoding=kwargs.get('encoding', 'auto'),
                    strip=kwargs.get('strip', True),
                    skip_empty=kwargs.get('skip_empty', False),
                    start=kwargs.get('start', 0),
                    count=kwargs.get('count')
                )
            elif operation == 'json':
                result = await self.read_json(
                    file_path,
                    encoding=kwargs.get('encoding', 'utf-8')
                )
            elif operation == 'metadata':
                result = await self.get_metadata(
                    file_path,
                    calculate_checksum=kwargs.get('checksum', False),
                    count_lines=kwargs.get('count_lines', False)
                )
            elif operation == 'head':
                result = await self.head(
                    file_path,
                    lines=kwargs.get('lines', 10),
                    encoding=kwargs.get('encoding', 'auto')
                )
            elif operation == 'tail':
                result = await self.tail(
                    file_path,
                    lines=kwargs.get('lines', 10),
                    encoding=kwargs.get('encoding', 'auto')
                )
            elif operation == 'search':
                result = await self.search(
                    file_path,
                    pattern=kwargs.get('pattern', ''),
                    case_sensitive=kwargs.get('case_sensitive', True),
                    max_matches=kwargs.get('max_matches', 100),
                    encoding=kwargs.get('encoding', 'auto')
                )
            else:
                return ToolResult(
                    status=ToolStatus.FAILURE,
                    error=f"Unknown operation: {operation}"
                )
            
            elapsed = (datetime.now() - start_time).total_seconds()
            
            if result.success:
                return ToolResult(
                    status=ToolStatus.SUCCESS,
                    data=result.to_dict(),
                    execution_time=elapsed
                )
            else:
                return ToolResult(
                    status=ToolStatus.FAILURE,
                    error=result.error,
                    execution_time=elapsed
                )
                
        except Exception as e:
            logger.error(f"FileReadTool execution error: {e}")
            return ToolResult(
                status=ToolStatus.FAILURE,
                error=str(e)
            )


# Create singleton instance and register
file_read_tool = FileReadTool()


# Register the tool
def register():
    """Register file read tool with the registry."""
    tool_registry.register(file_read_tool)


# Auto-register on import
try:
    register()
except Exception as e:
    logger.warning(f"Could not auto-register file_read tool: {e}")