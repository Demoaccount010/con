"""
Webhook Tools - Send and receive webhooks.
HTTP callbacks for integrations and notifications.
"""

import asyncio
import aiohttp
import json
import hashlib
import hmac
from pathlib import Path
from typing import Optional, Dict, Any, List, Callable, Awaitable
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import logging

import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from tools.base_tool import (
    BaseTool, ToolResult, ToolContext, ResultStatus,
    ToolCategory, ToolRisk
)
from tools.registry import get_registry

logger = logging.getLogger(__name__)


class WebhookMethod(Enum):
    """HTTP methods for webhooks."""
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    PATCH = "PATCH"
    DELETE = "DELETE"


class ContentType(Enum):
    """Content types for webhooks."""
    JSON = "application/json"
    FORM = "application/x-www-form-urlencoded"
    TEXT = "text/plain"
    XML = "application/xml"


@dataclass
class WebhookConfig:
    """Webhook configuration."""
    name: str
    url: str
    method: WebhookMethod = WebhookMethod.POST
    content_type: ContentType = ContentType.JSON
    headers: Dict[str, str] = field(default_factory=dict)
    secret: Optional[str] = None
    timeout: float = 30.0
    retry_count: int = 3
    retry_delay: float = 1.0
    enabled: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'url': self.url,
            'method': self.method.value,
            'content_type': self.content_type.value,
            'headers': {k: '***' if 'auth' in k.lower() or 'token' in k.lower() else v 
                       for k, v in self.headers.items()},
            'has_secret': bool(self.secret),
            'timeout': self.timeout,
            'retry_count': self.retry_count,
            'enabled': self.enabled
        }


@dataclass
class WebhookResult:
    """Result of webhook execution."""
    success: bool
    status_code: Optional[int] = None
    response_body: Optional[str] = None
    response_headers: Dict[str, str] = field(default_factory=dict)
    latency_ms: float = 0
    retries: int = 0
    error: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'success': self.success,
            'status_code': self.status_code,
            'response_body': self.response_body[:1000] if self.response_body else None,
            'response_headers': dict(self.response_headers),
            'latency_ms': self.latency_ms,
            'retries': self.retries,
            'error': self.error
        }


@dataclass
class WebhookEvent:
    """Webhook event record."""
    webhook_name: str
    timestamp: datetime
    payload: Any
    result: WebhookResult
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'webhook_name': self.webhook_name,
            'timestamp': self.timestamp.isoformat(),
            'payload': self.payload,
            'result': self.result.to_dict()
        }


class WebhookTools(BaseTool):
    """
    Webhook sending and management tool.
    
    Features:
    - Send webhooks with various content types
    - Retry logic with exponential backoff
    - HMAC signature generation
    - Webhook registration and management
    - Event history tracking
    - Batch webhook sending
    """
    
    def __init__(self):
        super().__init__(
            name="webhook_tools",
            description="Send and manage webhooks",
            category=ToolCategory.COMMUNICATION,
            risk=ToolRisk.LOW,
            requires_confirmation=False,
            timeout=60.0,
            version="1.0.0"
        )
        
        self._webhooks: Dict[str, WebhookConfig] = {}
        self._event_history: List[WebhookEvent] = []
        self._max_history = 100
        self._session: Optional[aiohttp.ClientSession] = None
    
    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create HTTP session."""
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession()
        return self._session
    
    def _generate_signature(
        self,
        payload: str,
        secret: str,
        algorithm: str = 'sha256'
    ) -> str:
        """Generate HMAC signature for payload."""
        if algorithm == 'sha256':
            signature = hmac.new(
                secret.encode(),
                payload.encode(),
                hashlib.sha256
            ).hexdigest()
        elif algorithm == 'sha1':
            signature = hmac.new(
                secret.encode(),
                payload.encode(),
                hashlib.sha1
            ).hexdigest()
        else:
            signature = hmac.new(
                secret.encode(),
                payload.encode(),
                hashlib.md5
            ).hexdigest()
        
        return f"{algorithm}={signature}"
    
    def register_webhook(self, config: WebhookConfig) -> None:
        """
        Register a webhook configuration.
        
        Args:
            config: Webhook configuration
        """
        self._webhooks[config.name] = config
        logger.info(f"Registered webhook: {config.name}")
    
    def unregister_webhook(self, name: str) -> bool:
        """Unregister a webhook."""
        if name in self._webhooks:
            del self._webhooks[name]
            return True
        return False
    
    def get_webhook(self, name: str) -> Optional[WebhookConfig]:
        """Get webhook configuration by name."""
        return self._webhooks.get(name)
    
    def list_webhooks(self) -> List[Dict[str, Any]]:
        """List all registered webhooks."""
        return [w.to_dict() for w in self._webhooks.values()]
    
    async def send(
        self,
        url: str,
        payload: Any = None,
        method: WebhookMethod = WebhookMethod.POST,
        content_type: ContentType = ContentType.JSON,
        headers: Optional[Dict[str, str]] = None,
        secret: Optional[str] = None,
        timeout: float = 30.0,
        retry_count: int = 3,
        retry_delay: float = 1.0
    ) -> WebhookResult:
        """
        Send a webhook request.
        
        Args:
            url: Webhook URL
            payload: Data to send
            method: HTTP method
            content_type: Content type
            headers: Custom headers
            secret: Secret for HMAC signature
            timeout: Request timeout
            retry_count: Number of retries
            retry_delay: Delay between retries
            
        Returns:
            WebhookResult
        """
        start_time = datetime.now()
        session = await self._get_session()
        
        # Prepare headers
        request_headers = dict(headers or {})
        request_headers['Content-Type'] = content_type.value
        request_headers['User-Agent'] = 'AutonomousAgent-Webhook/1.0'
        
        # Prepare payload
        if content_type == ContentType.JSON:
            body = json.dumps(payload) if payload else '{}'
        elif content_type == ContentType.FORM:
            body = payload  # aiohttp handles dict to form encoding
        else:
            body = str(payload) if payload else ''
        
        # Add signature if secret provided
        if secret and isinstance(body, str):
            signature = self._generate_signature(body, secret)
            request_headers['X-Webhook-Signature'] = signature
            request_headers['X-Hub-Signature-256'] = signature
        
        # Retry loop
        last_error = None
        retries = 0
        
        for attempt in range(retry_count):
            try:
                async with session.request(
                    method.value,
                    url,
                    data=body if content_type != ContentType.FORM else None,
                    json=None,
                    headers=request_headers,
                    timeout=aiohttp.ClientTimeout(total=timeout)
                ) as response:
                    latency = (datetime.now() - start_time).total_seconds() * 1000
                    
                    response_body = await response.text()
                    
                    if response.status < 400:
                        return WebhookResult(
                            success=True,
                            status_code=response.status,
                            response_body=response_body,
                            response_headers=dict(response.headers),
                            latency_ms=latency,
                            retries=retries
                        )
                    else:
                        last_error = f"HTTP {response.status}: {response_body[:200]}"
                        
            except asyncio.TimeoutError:
                last_error = f"Timeout after {timeout}s"
            except aiohttp.ClientError as e:
                last_error = str(e)
            except Exception as e:
                last_error = str(e)
            
            retries += 1
            
            if attempt < retry_count - 1:
                await asyncio.sleep(retry_delay * (attempt + 1))
        
        latency = (datetime.now() - start_time).total_seconds() * 1000
        
        return WebhookResult(
            success=False,
            latency_ms=latency,
            retries=retries,
            error=last_error
        )
    
    async def send_registered(
        self,
        name: str,
        payload: Any = None,
        extra_headers: Optional[Dict[str, str]] = None
    ) -> WebhookResult:
        """
        Send a registered webhook.
        
        Args:
            name: Webhook name
            payload: Data to send
            extra_headers: Additional headers
            
        Returns:
            WebhookResult
        """
        config = self._webhooks.get(name)
        if not config:
            return WebhookResult(
                success=False,
                error=f"Webhook not found: {name}"
            )
        
        if not config.enabled:
            return WebhookResult(
                success=False,
                error=f"Webhook disabled: {name}"
            )
        
        headers = dict(config.headers)
        if extra_headers:
            headers.update(extra_headers)
        
        result = await self.send(
            url=config.url,
            payload=payload,
            method=config.method,
            content_type=config.content_type,
            headers=headers,
            secret=config.secret,
            timeout=config.timeout,
            retry_count=config.retry_count,
            retry_delay=config.retry_delay
        )
        
        # Record event
        event = WebhookEvent(
            webhook_name=name,
            timestamp=datetime.now(),
            payload=payload,
            result=result
        )
        self._event_history.append(event)
        
        if len(self._event_history) > self._max_history:
            self._event_history = self._event_history[-self._max_history:]
        
        return result
    
    async def send_batch(
        self,
        webhooks: List[Dict[str, Any]]
    ) -> Dict[str, WebhookResult]:
        """
        Send multiple webhooks concurrently.
        
        Args:
            webhooks: List of webhook configs with 'url' and 'payload'
            
        Returns:
            Dict mapping url to result
        """
        tasks = []
        urls = []
        
        for webhook in webhooks:
            url = webhook.get('url')
            if not url:
                continue
            
            urls.append(url)
            tasks.append(self.send(
                url=url,
                payload=webhook.get('payload'),
                method=WebhookMethod(webhook.get('method', 'POST')),
                content_type=ContentType(webhook.get('content_type', 'application/json')),
                headers=webhook.get('headers'),
                secret=webhook.get('secret'),
                timeout=webhook.get('timeout', 30.0)
            ))
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        return {
            url: (result if isinstance(result, WebhookResult) 
                  else WebhookResult(success=False, error=str(result)))
            for url, result in zip(urls, results)
        }
    
    async def send_to_slack(
        self,
        webhook_url: str,
        text: str,
        username: Optional[str] = None,
        icon_emoji: Optional[str] = None,
        channel: Optional[str] = None,
        attachments: Optional[List[Dict]] = None
    ) -> WebhookResult:
        """
        Send message to Slack webhook.
        
        Args:
            webhook_url: Slack webhook URL
            text: Message text
            username: Bot username
            icon_emoji: Bot icon emoji
            channel: Target channel
            attachments: Message attachments
            
        Returns:
            WebhookResult
        """
        payload = {'text': text}
        
        if username:
            payload['username'] = username
        if icon_emoji:
            payload['icon_emoji'] = icon_emoji
        if channel:
            payload['channel'] = channel
        if attachments:
            payload['attachments'] = attachments
        
        return await self.send(
            url=webhook_url,
            payload=payload,
            content_type=ContentType.JSON
        )
    
    async def send_to_discord(
        self,
        webhook_url: str,
        content: str,
        username: Optional[str] = None,
        avatar_url: Optional[str] = None,
        embeds: Optional[List[Dict]] = None
    ) -> WebhookResult:
        """
        Send message to Discord webhook.
        
        Args:
            webhook_url: Discord webhook URL
            content: Message content
            username: Override username
            avatar_url: Override avatar
            embeds: Rich embeds
            
        Returns:
            WebhookResult
        """
        payload = {'content': content}
        
        if username:
            payload['username'] = username
        if avatar_url:
            payload['avatar_url'] = avatar_url
        if embeds:
            payload['embeds'] = embeds
        
        return await self.send(
            url=webhook_url,
            payload=payload,
            content_type=ContentType.JSON
        )
    
    async def send_to_teams(
        self,
        webhook_url: str,
        title: str,
        text: str,
        theme_color: str = "0076D7"
    ) -> WebhookResult:
        """
        Send message to Microsoft Teams webhook.
        
        Args:
            webhook_url: Teams webhook URL
            title: Message title
            text: Message text
            theme_color: Card color
            
        Returns:
            WebhookResult
        """
        payload = {
            "@type": "MessageCard",
            "@context": "http://schema.org/extensions",
            "themeColor": theme_color,
            "summary": title,
            "sections": [{
                "activityTitle": title,
                "text": text
            }]
        }
        
        return await self.send(
            url=webhook_url,
            payload=payload,
            content_type=ContentType.JSON
        )
    
    def get_event_history(
        self,
        webhook_name: Optional[str] = None,
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        """Get webhook event history."""
        history = self._event_history
        
        if webhook_name:
            history = [e for e in history if e.webhook_name == webhook_name]
        
        return [e.to_dict() for e in history[-limit:]]
    
    async def run(self, context: ToolContext, **kwargs) -> ToolResult:
        """
        Execute webhook operation.
        
        Supported operations:
        - send: Send webhook to URL
        - send_registered: Send registered webhook
        - send_batch: Send multiple webhooks
        - slack: Send to Slack
        - discord: Send to Discord
        - teams: Send to Teams
        - register: Register webhook
        - unregister: Unregister webhook
        - list: List webhooks
        - history: Get event history
        """
        operation = kwargs.get('operation', 'send')
        
        try:
            if operation == 'send':
                url = kwargs.get('url')
                if not url:
                    return ToolResult.fail(error="url is required")
                
                method_str = kwargs.get('method', 'POST').upper()
                try:
                    method = WebhookMethod[method_str]
                except KeyError:
                    method = WebhookMethod.POST
                
                content_type_str = kwargs.get('content_type', 'application/json')
                try:
                    content_type = ContentType(content_type_str)
                except ValueError:
                    content_type = ContentType.JSON
                
                result = await self.send(
                    url=url,
                    payload=kwargs.get('payload') or kwargs.get('data'),
                    method=method,
                    content_type=content_type,
                    headers=kwargs.get('headers'),
                    secret=kwargs.get('secret'),
                    timeout=kwargs.get('timeout', 30.0),
                    retry_count=kwargs.get('retry_count', 3)
                )
                
                if result.success:
                    return ToolResult.ok(data=result.to_dict())
                else:
                    return ToolResult.fail(error=result.error, data=result.to_dict())
            
            elif operation == 'send_registered':
                name = kwargs.get('name')
                if not name:
                    return ToolResult.fail(error="name is required")
                
                result = await self.send_registered(
                    name=name,
                    payload=kwargs.get('payload') or kwargs.get('data'),
                    extra_headers=kwargs.get('headers')
                )
                
                if result.success:
                    return ToolResult.ok(data=result.to_dict())
                else:
                    return ToolResult.fail(error=result.error, data=result.to_dict())
            
            elif operation == 'send_batch':
                webhooks = kwargs.get('webhooks', [])
                if not webhooks:
                    return ToolResult.fail(error="webhooks list is required")
                
                results = await self.send_batch(webhooks)
                
                success_count = sum(1 for r in results.values() if r.success)
                
                return ToolResult.ok(
                    data={
                        'results': {url: r.to_dict() for url, r in results.items()},
                        'success_count': success_count,
                        'total': len(results)
                    },
                    message=f"Sent {success_count}/{len(results)} webhooks"
                )
            
            elif operation == 'slack':
                url = kwargs.get('url') or kwargs.get('webhook_url')
                text = kwargs.get('text') or kwargs.get('message')
                
                if not url or not text:
                    return ToolResult.fail(error="url and text are required")
                
                result = await self.send_to_slack(
                    webhook_url=url,
                    text=text,
                    username=kwargs.get('username'),
                    icon_emoji=kwargs.get('icon_emoji'),
                    channel=kwargs.get('channel'),
                    attachments=kwargs.get('attachments')
                )
                
                if result.success:
                    return ToolResult.ok(data=result.to_dict())
                else:
                    return ToolResult.fail(error=result.error)
            
            elif operation == 'discord':
                url = kwargs.get('url') or kwargs.get('webhook_url')
                content = kwargs.get('content') or kwargs.get('message')
                
                if not url or not content:
                    return ToolResult.fail(error="url and content are required")
                
                result = await self.send_to_discord(
                    webhook_url=url,
                    content=content,
                    username=kwargs.get('username'),
                    avatar_url=kwargs.get('avatar_url'),
                    embeds=kwargs.get('embeds')
                )
                
                if result.success:
                    return ToolResult.ok(data=result.to_dict())
                else:
                    return ToolResult.fail(error=result.error)
            
            elif operation == 'teams':
                url = kwargs.get('url') or kwargs.get('webhook_url')
                title = kwargs.get('title')
                text = kwargs.get('text') or kwargs.get('message')
                
                if not url or not text:
                    return ToolResult.fail(error="url and text are required")
                
                result = await self.send_to_teams(
                    webhook_url=url,
                    title=title or "Notification",
                    text=text,
                    theme_color=kwargs.get('color', '0076D7')
                )
                
                if result.success:
                    return ToolResult.ok(data=result.to_dict())
                else:
                    return ToolResult.fail(error=result.error)
            
            elif operation == 'register':
                name = kwargs.get('name')
                url = kwargs.get('url')
                
                if not name or not url:
                    return ToolResult.fail(error="name and url are required")
                
                method_str = kwargs.get('method', 'POST').upper()
                try:
                    method = WebhookMethod[method_str]
                except KeyError:
                    method = WebhookMethod.POST
                
                config = WebhookConfig(
                    name=name,
                    url=url,
                    method=method,
                    headers=kwargs.get('headers', {}),
                    secret=kwargs.get('secret'),
                    timeout=kwargs.get('timeout', 30.0),
                    retry_count=kwargs.get('retry_count', 3),
                    enabled=kwargs.get('enabled', True)
                )
                
                self.register_webhook(config)
                
                return ToolResult.ok(
                    data=config.to_dict(),
                    message=f"Webhook '{name}' registered"
                )
            
            elif operation == 'unregister':
                name = kwargs.get('name')
                if not name:
                    return ToolResult.fail(error="name is required")
                
                if self.unregister_webhook(name):
                    return ToolResult.ok(message=f"Webhook '{name}' unregistered")
                else:
                    return ToolResult.fail(error=f"Webhook '{name}' not found")
            
            elif operation == 'list':
                webhooks = self.list_webhooks()
                
                return ToolResult.ok(
                    data={
                        'webhooks': webhooks,
                        'count': len(webhooks)
                    }
                )
            
            elif operation == 'history':
                history = self.get_event_history(
                    webhook_name=kwargs.get('name'),
                    limit=kwargs.get('limit', 50)
                )
                
                return ToolResult.ok(
                    data={
                        'history': history,
                        'count': len(history)
                    }
                )
            
            else:
                return ToolResult.fail(error=f"Unknown operation: {operation}")
            
        except Exception as e:
            logger.error(f"WebhookTools error: {e}")
            return ToolResult.error(error=str(e))
    
    async def cleanup(self) -> None:
        """Close HTTP session."""
        if self._session and not self._session.closed:
            await self._session.close()


# Create singleton
webhook_tools = WebhookTools()


def register():
    """Register webhook tools."""
    registry = get_registry()
    registry.register_tool(webhook_tools)