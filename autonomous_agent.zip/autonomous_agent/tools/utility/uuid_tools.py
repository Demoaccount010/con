"""
═══════════════════════════════════════════════════════════════════════════════════════
UUID TOOLS - UNIVERSAL UNIQUE IDENTIFIER UTILITIES
═══════════════════════════════════════════════════════════════════════════════════════
Comprehensive UUID generation and manipulation:
- UUID versions 1, 3, 4, 5
- ULID generation
- Short ID generation
- Nano ID generation
- UUID validation and parsing
- Batch generation
- UUID to timestamp extraction
"""

import asyncio
import logging
import uuid
import time
import random
import string
import re
import hashlib
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Union, Tuple
import base64
import struct

logger = logging.getLogger(__name__)


class UUIDVersion(Enum):
    """UUID versions."""
    V1 = 1  # Time-based
    V3 = 3  # Name-based (MD5)
    V4 = 4  # Random
    V5 = 5  # Name-based (SHA1)


class IDFormat(Enum):
    """Output format for IDs."""
    STANDARD = "standard"      # 8-4-4-4-12 with hyphens
    HEX = "hex"                # 32 hex chars, no hyphens
    BASE64 = "base64"          # Base64 encoded
    BASE64_URL = "base64url"   # URL-safe Base64
    INTEGER = "integer"        # 128-bit integer
    URN = "urn"                # urn:uuid:...


@dataclass
class UUIDInfo:
    """Information about a UUID."""
    uuid_string: str
    version: int
    variant: str
    is_valid: bool
    timestamp: Optional[datetime] = None
    clock_seq: Optional[int] = None
    node: Optional[str] = None
    
    def __str__(self) -> str:
        return self.uuid_string


@dataclass
class GeneratedID:
    """A generated ID with multiple format representations."""
    id_type: str
    value: str
    hex_value: str
    int_value: Optional[int] = None
    base64_value: Optional[str] = None
    timestamp: datetime = field(default_factory=datetime.now)
    
    def __str__(self) -> str:
        return self.value


# Standard UUID namespaces
NAMESPACE_DNS = uuid.NAMESPACE_DNS
NAMESPACE_URL = uuid.NAMESPACE_URL
NAMESPACE_OID = uuid.NAMESPACE_OID
NAMESPACE_X500 = uuid.NAMESPACE_X500


class ULIDGenerator:
    """
    ULID (Universally Unique Lexicographically Sortable Identifier) generator.
    
    Format: 01ARZ3NDEKTSV4RRFFQ69G5FAV
    - 48-bit timestamp (first 10 chars)
    - 80-bit randomness (last 16 chars)
    """
    
    # Crockford's Base32 alphabet
    ENCODING = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"
    DECODING = {c: i for i, c in enumerate(ENCODING)}
    
    def __init__(self):
        self._last_time = 0
        self._last_random = None
    
    def generate(self, timestamp: Optional[datetime] = None) -> str:
        """Generate a ULID."""
        if timestamp:
            ms = int(timestamp.timestamp() * 1000)
        else:
            ms = int(time.time() * 1000)
        
        # Encode timestamp (48 bits = 10 chars)
        time_part = self._encode_time(ms)
        
        # Generate randomness (80 bits = 16 chars)
        # If same millisecond, increment last random to maintain ordering
        if ms == self._last_time and self._last_random is not None:
            self._last_random = self._increment_random(self._last_random)
            random_part = self._last_random
        else:
            random_part = self._generate_random()
            self._last_random = random_part
        
        self._last_time = ms
        
        return time_part + random_part
    
    def _encode_time(self, ms: int) -> str:
        """Encode timestamp to 10 characters."""
        result = []
        for _ in range(10):
            result.append(self.ENCODING[ms & 0x1F])
            ms >>= 5
        return ''.join(reversed(result))
    
    def _generate_random(self) -> str:
        """Generate 16 random characters."""
        return ''.join(random.choice(self.ENCODING) for _ in range(16))
    
    def _increment_random(self, random_part: str) -> str:
        """Increment random part by 1."""
        chars = list(random_part)
        for i in range(len(chars) - 1, -1, -1):
            val = self.DECODING[chars[i]] + 1
            if val < 32:
                chars[i] = self.ENCODING[val]
                break
            chars[i] = self.ENCODING[0]
        return ''.join(chars)
    
    def decode_time(self, ulid: str) -> datetime:
        """Decode timestamp from ULID."""
        time_part = ulid[:10].upper()
        ms = 0
        for char in time_part:
            ms = (ms << 5) | self.DECODING[char]
        return datetime.fromtimestamp(ms / 1000, tz=timezone.utc)
    
    def is_valid(self, ulid: str) -> bool:
        """Check if string is a valid ULID."""
        if len(ulid) != 26:
            return False
        try:
            for char in ulid.upper():
                if char not in self.DECODING:
                    return False
            return True
        except Exception:
            return False


class NanoIDGenerator:
    """
    Nano ID generator - compact, URL-friendly unique IDs.
    
    Default: 21 characters, ~1 million years to have 1% collision probability
    """
    
    # URL-safe alphabet
    DEFAULT_ALPHABET = '_-0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    
    def __init__(self, alphabet: str = None, size: int = 21):
        self.alphabet = alphabet or self.DEFAULT_ALPHABET
        self.size = size
        self._mask = (2 << int(len(self.alphabet) - 1).bit_length() - 1) - 1
        self._step = int(1.6 * self._mask * size / len(self.alphabet))
    
    def generate(self, size: int = None) -> str:
        """Generate a Nano ID."""
        size = size or self.size
        id_chars = []
        
        while len(id_chars) < size:
            random_bytes = random.getrandbits(self._step * 8).to_bytes(self._step, 'big')
            for byte in random_bytes:
                idx = byte & self._mask
                if idx < len(self.alphabet):
                    id_chars.append(self.alphabet[idx])
                    if len(id_chars) >= size:
                        break
        
        return ''.join(id_chars)
    
    def generate_custom(self, alphabet: str, size: int) -> str:
        """Generate with custom alphabet and size."""
        return ''.join(random.choice(alphabet) for _ in range(size))


class UUIDTools:
    """
    Comprehensive UUID and unique ID toolkit.
    
    Supports:
    - UUID v1, v3, v4, v5
    - ULID
    - Nano ID
    - Short IDs
    - Snowflake-like IDs
    """
    
    def __init__(self):
        self.ulid_generator = ULIDGenerator()
        self.nanoid_generator = NanoIDGenerator()
        
        # For snowflake-like IDs
        self._machine_id = random.randint(0, 1023)
        self._sequence = 0
        self._last_timestamp = 0
        self._epoch = 1609459200000  # 2021-01-01 00:00:00 UTC
        
        logger.info("UUIDTools initialized")
    
    # ─────────────────────────────────────────────────────────────────────
    # UUID GENERATION
    # ─────────────────────────────────────────────────────────────────────
    
    async def generate_uuid(
        self,
        version: UUIDVersion = UUIDVersion.V4,
        namespace: Optional[uuid.UUID] = None,
        name: Optional[str] = None,
        format: IDFormat = IDFormat.STANDARD
    ) -> GeneratedID:
        """
        Generate a UUID.
        
        Args:
            version: UUID version (1, 3, 4, or 5)
            namespace: Namespace for v3/v5
            name: Name for v3/v5
            format: Output format
        
        Returns:
            GeneratedID with multiple representations
        """
        if version == UUIDVersion.V1:
            new_uuid = uuid.uuid1()
        elif version == UUIDVersion.V3:
            if not namespace or not name:
                raise ValueError("V3 requires namespace and name")
            new_uuid = uuid.uuid3(namespace, name)
        elif version == UUIDVersion.V4:
            new_uuid = uuid.uuid4()
        elif version == UUIDVersion.V5:
            if not namespace or not name:
                raise ValueError("V5 requires namespace and name")
            new_uuid = uuid.uuid5(namespace, name)
        else:
            raise ValueError(f"Unsupported version: {version}")
        
        return self._format_uuid(new_uuid, f"UUID v{version.value}", format)
    
    def _format_uuid(
        self,
        u: uuid.UUID,
        id_type: str,
        format: IDFormat
    ) -> GeneratedID:
        """Format UUID according to specified format."""
        if format == IDFormat.STANDARD:
            value = str(u)
        elif format == IDFormat.HEX:
            value = u.hex
        elif format == IDFormat.BASE64:
            value = base64.b64encode(u.bytes).decode()
        elif format == IDFormat.BASE64_URL:
            value = base64.urlsafe_b64encode(u.bytes).decode().rstrip('=')
        elif format == IDFormat.INTEGER:
            value = str(u.int)
        elif format == IDFormat.URN:
            value = u.urn
        else:
            value = str(u)
        
        return GeneratedID(
            id_type=id_type,
            value=value,
            hex_value=u.hex,
            int_value=u.int,
            base64_value=base64.urlsafe_b64encode(u.bytes).decode().rstrip('=')
        )
    
    async def uuid1(self, format: IDFormat = IDFormat.STANDARD) -> GeneratedID:
        """Generate UUID v1 (time-based)."""
        return await self.generate_uuid(UUIDVersion.V1, format=format)
    
    async def uuid3(
        self,
        namespace: Union[uuid.UUID, str],
        name: str,
        format: IDFormat = IDFormat.STANDARD
    ) -> GeneratedID:
        """Generate UUID v3 (MD5 name-based)."""
        if isinstance(namespace, str):
            namespace = self._get_namespace(namespace)
        return await self.generate_uuid(UUIDVersion.V3, namespace, name, format)
    
    async def uuid4(self, format: IDFormat = IDFormat.STANDARD) -> GeneratedID:
        """Generate UUID v4 (random)."""
        return await self.generate_uuid(UUIDVersion.V4, format=format)
    
    async def uuid5(
        self,
        namespace: Union[uuid.UUID, str],
        name: str,
        format: IDFormat = IDFormat.STANDARD
    ) -> GeneratedID:
        """Generate UUID v5 (SHA1 name-based)."""
        if isinstance(namespace, str):
            namespace = self._get_namespace(namespace)
        return await self.generate_uuid(UUIDVersion.V5, namespace, name, format)
    
    def _get_namespace(self, name: str) -> uuid.UUID:
        """Get namespace UUID from name."""
        namespaces = {
            'dns': NAMESPACE_DNS,
            'url': NAMESPACE_URL,
            'oid': NAMESPACE_OID,
            'x500': NAMESPACE_X500,
        }
        return namespaces.get(name.lower(), NAMESPACE_DNS)
    
    # ─────────────────────────────────────────────────────────────────────
    # ULID GENERATION
    # ─────────────────────────────────────────────────────────────────────
    
    async def generate_ulid(
        self,
        timestamp: Optional[datetime] = None
    ) -> GeneratedID:
        """
        Generate a ULID.
        
        ULIDs are:
        - Lexicographically sortable
        - Compatible with UUID format
        - 26 characters (Crockford Base32)
        """
        ulid = self.ulid_generator.generate(timestamp)
        
        return GeneratedID(
            id_type="ULID",
            value=ulid,
            hex_value=self._ulid_to_hex(ulid),
            timestamp=self.ulid_generator.decode_time(ulid)
        )
    
    def _ulid_to_hex(self, ulid: str) -> str:
        """Convert ULID to hex string."""
        # Decode ULID to 128-bit integer then to hex
        val = 0
        for char in ulid.upper():
            val = (val << 5) | ULIDGenerator.DECODING[char]
        return format(val, '032x')
    
    async def decode_ulid(self, ulid: str) -> Dict[str, Any]:
        """Decode ULID and extract components."""
        if not self.ulid_generator.is_valid(ulid):
            raise ValueError(f"Invalid ULID: {ulid}")
        
        timestamp = self.ulid_generator.decode_time(ulid)
        
        return {
            "ulid": ulid,
            "timestamp": timestamp.isoformat(),
            "timestamp_ms": int(timestamp.timestamp() * 1000),
            "random_part": ulid[10:],
            "hex": self._ulid_to_hex(ulid),
            "is_valid": True
        }
    
    # ─────────────────────────────────────────────────────────────────────
    # NANO ID GENERATION
    # ─────────────────────────────────────────────────────────────────────
    
    async def generate_nanoid(
        self,
        size: int = 21,
        alphabet: Optional[str] = None
    ) -> GeneratedID:
        """
        Generate a Nano ID.
        
        Args:
            size: Length of ID (default: 21)
            alphabet: Custom alphabet (default: URL-safe)
        
        Returns:
            GeneratedID
        """
        if alphabet:
            nanoid = self.nanoid_generator.generate_custom(alphabet, size)
        else:
            nanoid = self.nanoid_generator.generate(size)
        
        return GeneratedID(
            id_type="NanoID",
            value=nanoid,
            hex_value=nanoid.encode().hex()
        )
    
    # ─────────────────────────────────────────────────────────────────────
    # SHORT ID GENERATION
    # ─────────────────────────────────────────────────────────────────────
    
    async def generate_short_id(
        self,
        length: int = 8,
        prefix: Optional[str] = None,
        alphabet: str = "alphanumeric"
    ) -> GeneratedID:
        """
        Generate a short, human-friendly ID.
        
        Args:
            length: ID length
            prefix: Optional prefix
            alphabet: 'alphanumeric', 'alpha', 'numeric', 'hex', or custom
        """
        alphabets = {
            'alphanumeric': string.ascii_letters + string.digits,
            'alpha': string.ascii_letters,
            'numeric': string.digits,
            'hex': string.hexdigits[:16],
            'lowercase': string.ascii_lowercase + string.digits,
            'uppercase': string.ascii_uppercase + string.digits,
        }
        
        chars = alphabets.get(alphabet, alphabet)
        short_id = ''.join(random.choice(chars) for _ in range(length))
        
        if prefix:
            short_id = f"{prefix}{short_id}"
        
        return GeneratedID(
            id_type="ShortID",
            value=short_id,
            hex_value=short_id.encode().hex()
        )
    
    # ─────────────────────────────────────────────────────────────────────
    # SNOWFLAKE-LIKE ID
    # ─────────────────────────────────────────────────────────────────────
    
    async def generate_snowflake(self) -> GeneratedID:
        """
        Generate a Twitter Snowflake-like ID.
        
        Format (64 bits):
        - 41 bits: timestamp (milliseconds since epoch)
        - 10 bits: machine ID
        - 12 bits: sequence number
        """
        timestamp = int(time.time() * 1000) - self._epoch
        
        if timestamp == self._last_timestamp:
            self._sequence = (self._sequence + 1) & 0xFFF  # 12 bits
            if self._sequence == 0:
                # Wait for next millisecond
                while timestamp <= self._last_timestamp:
                    timestamp = int(time.time() * 1000) - self._epoch
        else:
            self._sequence = 0
        
        self._last_timestamp = timestamp
        
        snowflake = (
            (timestamp << 22) |
            (self._machine_id << 12) |
            self._sequence
        )
        
        return GeneratedID(
            id_type="Snowflake",
            value=str(snowflake),
            hex_value=format(snowflake, '016x'),
            int_value=snowflake,
            timestamp=datetime.fromtimestamp(
                (snowflake >> 22) + self._epoch / 1000,
                tz=timezone.utc
            )
        )
    
    async def decode_snowflake(self, snowflake: Union[int, str]) -> Dict[str, Any]:
        """Decode a snowflake ID."""
        if isinstance(snowflake, str):
            snowflake = int(snowflake)
        
        timestamp_ms = (snowflake >> 22) + self._epoch
        machine_id = (snowflake >> 12) & 0x3FF
        sequence = snowflake & 0xFFF
        
        return {
            "snowflake": snowflake,
            "timestamp": datetime.fromtimestamp(
                timestamp_ms / 1000, tz=timezone.utc
            ).isoformat(),
            "timestamp_ms": timestamp_ms,
            "machine_id": machine_id,
            "sequence": sequence
        }
    
    # ─────────────────────────────────────────────────────────────────────
    # UUID VALIDATION AND PARSING
    # ─────────────────────────────────────────────────────────────────────
    
    async def parse_uuid(self, uuid_string: str) -> UUIDInfo:
        """Parse and analyze a UUID string."""
        uuid_string = uuid_string.strip()
        
        # Remove URN prefix if present
        if uuid_string.lower().startswith('urn:uuid:'):
            uuid_string = uuid_string[9:]
        
        # Validate format
        uuid_pattern = re.compile(
            r'^[0-9a-f]{8}-?[0-9a-f]{4}-?[0-9a-f]{4}-?[0-9a-f]{4}-?[0-9a-f]{12}$',
            re.IGNORECASE
        )
        
        if not uuid_pattern.match(uuid_string):
            return UUIDInfo(
                uuid_string=uuid_string,
                version=0,
                variant="unknown",
                is_valid=False
            )
        
        try:
            parsed = uuid.UUID(uuid_string)
            
            # Determine variant
            if parsed.variant == uuid.RFC_4122:
                variant = "RFC 4122"
            elif parsed.variant == uuid.RESERVED_NCS:
                variant = "NCS"
            elif parsed.variant == uuid.RESERVED_MICROSOFT:
                variant = "Microsoft"
            elif parsed.variant == uuid.RESERVED_FUTURE:
                variant = "Future"
            else:
                variant = "Unknown"
            
            # Extract timestamp for v1
            timestamp = None
            clock_seq = None
            node = None
            
            if parsed.version == 1:
                # V1 UUID contains timestamp
                timestamp = datetime.fromtimestamp(
                    (parsed.time - 0x01b21dd213814000) / 1e7,
                    tz=timezone.utc
                )
                clock_seq = parsed.clock_seq
                node = format(parsed.node, '012x')
                # Format as MAC address
                node = ':'.join(node[i:i+2] for i in range(0, 12, 2))
            
            return UUIDInfo(
                uuid_string=str(parsed),
                version=parsed.version,
                variant=variant,
                is_valid=True,
                timestamp=timestamp,
                clock_seq=clock_seq,
                node=node
            )
            
        except ValueError:
            return UUIDInfo(
                uuid_string=uuid_string,
                version=0,
                variant="unknown",
                is_valid=False
            )
    
    async def is_valid_uuid(self, uuid_string: str) -> bool:
        """Check if string is a valid UUID."""
        info = await self.parse_uuid(uuid_string)
        return info.is_valid
    
    # ─────────────────────────────────────────────────────────────────────
    # BATCH GENERATION
    # ─────────────────────────────────────────────────────────────────────
    
    async def generate_batch(
        self,
        count: int,
        id_type: str = "uuid4",
        **kwargs
    ) -> List[GeneratedID]:
        """
        Generate multiple IDs.
        
        Args:
            count: Number of IDs to generate
            id_type: Type of ID ('uuid1', 'uuid4', 'ulid', 'nanoid', 'short', 'snowflake')
            **kwargs: Additional arguments for the generator
        
        Returns:
            List of GeneratedIDs
        """
        generators = {
            'uuid1': lambda: self.uuid1(**kwargs),
            'uuid4': lambda: self.uuid4(**kwargs),
            'uuid3': lambda: self.uuid3(**kwargs),
            'uuid5': lambda: self.uuid5(**kwargs),
            'ulid': lambda: self.generate_ulid(**kwargs),
            'nanoid': lambda: self.generate_nanoid(**kwargs),
            'short': lambda: self.generate_short_id(**kwargs),
            'snowflake': lambda: self.generate_snowflake(),
        }
        
        generator = generators.get(id_type.lower())
        if not generator:
            raise ValueError(f"Unknown ID type: {id_type}")
        
        results = []
        for _ in range(count):
            result = await generator()
            results.append(result)
        
        return results
    
    # ─────────────────────────────────────────────────────────────────────
    # CONVERSION UTILITIES
    # ─────────────────────────────────────────────────────────────────────
    
    async def convert_format(
        self,
        uuid_string: str,
        target_format: IDFormat
    ) -> str:
        """Convert UUID to different format."""
        info = await self.parse_uuid(uuid_string)
        if not info.is_valid:
            raise ValueError(f"Invalid UUID: {uuid_string}")
        
        parsed = uuid.UUID(uuid_string)
        result = self._format_uuid(parsed, "UUID", target_format)
        return result.value
    
    async def uuid_to_ulid(self, uuid_string: str) -> str:
        """Convert UUID to ULID format."""
        parsed = uuid.UUID(uuid_string)
        # Use UUID bytes to create ULID-like string
        val = parsed.int
        chars = []
        for _ in range(26):
            chars.append(ULIDGenerator.ENCODING[val & 0x1F])
            val >>= 5
        return ''.join(reversed(chars))
    
    async def ulid_to_uuid(self, ulid: str) -> str:
        """Convert ULID to UUID format."""
        if not self.ulid_generator.is_valid(ulid):
            raise ValueError(f"Invalid ULID: {ulid}")
        
        hex_str = self._ulid_to_hex(ulid)
        return str(uuid.UUID(hex_str))


# Singleton instance
_uuid_tools: Optional[UUIDTools] = None


def get_uuid_tools() -> UUIDTools:
    """Get or create UUID tools singleton."""
    global _uuid_tools
    if _uuid_tools is None:
        _uuid_tools = UUIDTools()
    return _uuid_tools


# Convenience functions
async def new_uuid() -> str:
    """Generate a new UUID v4."""
    tools = get_uuid_tools()
    result = await tools.uuid4()
    return result.value


async def new_ulid() -> str:
    """Generate a new ULID."""
    tools = get_uuid_tools()
    result = await tools.generate_ulid()
    return result.value


async def new_nanoid(size: int = 21) -> str:
    """Generate a new Nano ID."""
    tools = get_uuid_tools()
    result = await tools.generate_nanoid(size)
    return result.value


async def new_short_id(length: int = 8) -> str:
    """Generate a new short ID."""
    tools = get_uuid_tools()
    result = await tools.generate_short_id(length)
    return result.value


async def is_valid_uuid(uuid_string: str) -> bool:
    """Check if string is valid UUID."""
    tools = get_uuid_tools()
    return await tools.is_valid_uuid(uuid_string)