"""
CSV Tools - CSV parsing, manipulation, and analysis.
Read, write, transform, and analyze CSV data.
"""

import asyncio
import csv
import io
from pathlib import Path
from typing import Optional, Dict, Any, List, Union, Callable
from dataclasses import dataclass, field
from datetime import datetime
import logging
import re

import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from tools.base_tool import (
    BaseTool, ToolResult, ToolContext, ResultStatus,
    ToolCategory, ToolRisk
)
from tools.registry import get_registry

logger = logging.getLogger(__name__)


@dataclass
class CsvDialect:
    """CSV dialect configuration."""
    delimiter: str = ','
    quotechar: str = '"'
    escapechar: Optional[str] = None
    doublequote: bool = True
    skipinitialspace: bool = False
    lineterminator: str = '\n'
    quoting: int = csv.QUOTE_MINIMAL
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'delimiter': self.delimiter,
            'quotechar': self.quotechar,
            'escapechar': self.escapechar,
            'doublequote': self.doublequote,
            'skipinitialspace': self.skipinitialspace,
            'lineterminator': repr(self.lineterminator),
            'quoting': self.quoting
        }


@dataclass
class CsvStats:
    """Statistics about CSV data."""
    row_count: int
    column_count: int
    columns: List[str]
    column_types: Dict[str, str]
    null_counts: Dict[str, int]
    unique_counts: Dict[str, int]
    sample_values: Dict[str, List[Any]]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'row_count': self.row_count,
            'column_count': self.column_count,
            'columns': self.columns,
            'column_types': self.column_types,
            'null_counts': self.null_counts,
            'unique_counts': self.unique_counts,
            'sample_values': self.sample_values
        }


class CsvTools(BaseTool):
    """
    CSV manipulation tool.
    
    Features:
    - Parse CSV with auto dialect detection
    - Convert to/from JSON, dict, lists
    - Filter and query rows
    - Transform columns
    - Aggregate and group data
    - Merge multiple CSVs
    - Export with formatting
    - Statistical analysis
    """
    
    def __init__(self):
        super().__init__(
            name="csv_tools",
            description="CSV parsing, manipulation, and analysis",
            category=ToolCategory.DATA,
            risk=ToolRisk.NONE,
            requires_confirmation=False,
            timeout=120.0,
            version="1.0.0"
        )
    
    async def detect_dialect(self, data: str) -> CsvDialect:
        """
        Auto-detect CSV dialect.
        
        Args:
            data: CSV string (first few KB)
            
        Returns:
            Detected dialect
        """
        sample = data[:8192]
        
        try:
            sniffer = csv.Sniffer()
            detected = sniffer.sniff(sample)
            
            return CsvDialect(
                delimiter=detected.delimiter,
                quotechar=detected.quotechar or '"',
                doublequote=detected.doublequote,
                skipinitialspace=detected.skipinitialspace
            )
        except:
            return CsvDialect()
    
    async def parse(
        self,
        data: str,
        has_header: bool = True,
        dialect: Optional[CsvDialect] = None,
        columns: Optional[List[str]] = None,
        skip_rows: int = 0,
        max_rows: Optional[int] = None,
        strip_whitespace: bool = True
    ) -> Dict[str, Any]:
        """
        Parse CSV string to list of dictionaries.
        
        Args:
            data: CSV string
            has_header: First row is header
            dialect: CSV dialect
            columns: Column names (if no header)
            skip_rows: Rows to skip at start
            max_rows: Maximum rows to read
            strip_whitespace: Strip whitespace from values
            
        Returns:
            Parsed data with metadata
        """
        try:
            if dialect is None:
                dialect = await self.detect_dialect(data)
            
            reader = csv.reader(
                io.StringIO(data),
                delimiter=dialect.delimiter,
                quotechar=dialect.quotechar,
                doublequote=dialect.doublequote,
                skipinitialspace=dialect.skipinitialspace
            )
            
            rows = list(reader)
            
            if skip_rows > 0:
                rows = rows[skip_rows:]
            
            if not rows:
                return {
                    'success': True,
                    'data': [],
                    'columns': [],
                    'row_count': 0
                }
            
            if has_header:
                headers = rows[0]
                data_rows = rows[1:]
            else:
                if columns:
                    headers = columns
                else:
                    headers = [f'column_{i}' for i in range(len(rows[0]))]
                data_rows = rows
            
            if max_rows:
                data_rows = data_rows[:max_rows]
            
            result = []
            for row in data_rows:
                while len(row) < len(headers):
                    row.append('')
                
                record = {}
                for i, header in enumerate(headers):
                    value = row[i] if i < len(row) else ''
                    if strip_whitespace and isinstance(value, str):
                        value = value.strip()
                    record[header] = value
                
                result.append(record)
            
            return {
                'success': True,
                'data': result,
                'columns': headers,
                'row_count': len(result),
                'dialect': dialect.to_dict()
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    async def parse_to_rows(
        self,
        data: str,
        has_header: bool = True,
        dialect: Optional[CsvDialect] = None
    ) -> Dict[str, Any]:
        """
        Parse CSV to list of lists (rows).
        
        Args:
            data: CSV string
            has_header: First row is header
            dialect: CSV dialect
            
        Returns:
            Headers and rows
        """
        if dialect is None:
            dialect = await self.detect_dialect(data)
        
        reader = csv.reader(
            io.StringIO(data),
            delimiter=dialect.delimiter,
            quotechar=dialect.quotechar
        )
        
        rows = list(reader)
        
        if has_header and rows:
            return {
                'success': True,
                'headers': rows[0],
                'rows': rows[1:],
                'row_count': len(rows) - 1
            }
        else:
            return {
                'success': True,
                'headers': None,
                'rows': rows,
                'row_count': len(rows)
            }
    
    async def to_csv(
        self,
        data: Union[List[Dict], List[List]],
        columns: Optional[List[str]] = None,
        include_header: bool = True,
        dialect: Optional[CsvDialect] = None
    ) -> str:
        """
        Convert data to CSV string.
        
        Args:
            data: List of dicts or list of lists
            columns: Column order (for dicts)
            include_header: Include header row
            dialect: CSV dialect
            
        Returns:
            CSV string
        """
        if not data:
            return ''
        
        dialect = dialect or CsvDialect()
        output = io.StringIO()
        
        if isinstance(data[0], dict):
            if columns is None:
                columns = list(data[0].keys())
            
            writer = csv.DictWriter(
                output,
                fieldnames=columns,
                delimiter=dialect.delimiter,
                quotechar=dialect.quotechar,
                quoting=dialect.quoting
            )
            
            if include_header:
                writer.writeheader()
            
            for row in data:
                writer.writerow(row)
        else:
            writer = csv.writer(
                output,
                delimiter=dialect.delimiter,
                quotechar=dialect.quotechar,
                quoting=dialect.quoting
            )
            
            if include_header and columns:
                writer.writerow(columns)
            
            for row in data:
                writer.writerow(row)
        
        return output.getvalue()
    
    async def filter_rows(
        self,
        data: List[Dict],
        conditions: Dict[str, Any]
    ) -> List[Dict]:
        """
        Filter rows based on conditions.
        
        Conditions format:
        - {"column": value} - exact match
        - {"column": {"$gt": value}} - greater than
        - {"column": {"$lt": value}} - less than
        - {"column": {"$contains": value}} - string contains
        - {"column": {"$regex": pattern}} - regex match
        - {"column": {"$in": [values]}} - value in list
        
        Args:
            data: List of row dictionaries
            conditions: Filter conditions
            
        Returns:
            Filtered rows
        """
        def matches_condition(row: Dict, col: str, cond: Any) -> bool:
            value = row.get(col)
            
            if isinstance(cond, dict):
                for op, expected in cond.items():
                    if op == '$gt':
                        try:
                            if float(value) <= float(expected):
                                return False
                        except:
                            return False
                    elif op == '$gte':
                        try:
                            if float(value) < float(expected):
                                return False
                        except:
                            return False
                    elif op == '$lt':
                        try:
                            if float(value) >= float(expected):
                                return False
                        except:
                            return False
                    elif op == '$lte':
                        try:
                            if float(value) > float(expected):
                                return False
                        except:
                            return False
                    elif op == '$eq':
                        if value != expected:
                            return False
                    elif op == '$ne':
                        if value == expected:
                            return False
                    elif op == '$contains':
                        if expected not in str(value):
                            return False
                    elif op == '$regex':
                        if not re.search(expected, str(value)):
                            return False
                    elif op == '$in':
                        if value not in expected:
                            return False
                    elif op == '$nin':
                        if value in expected:
                            return False
                return True
            else:
                return value == cond
        
        result = []
        for row in data:
            match = True
            for col, cond in conditions.items():
                if not matches_condition(row, col, cond):
                    match = False
                    break
            if match:
                result.append(row)
        
        return result
    
    async def select_columns(
        self,
        data: List[Dict],
        columns: List[str],
        rename: Optional[Dict[str, str]] = None
    ) -> List[Dict]:
        """
        Select specific columns from data.
        
        Args:
            data: List of row dictionaries
            columns: Columns to select
            rename: Column rename mapping
            
        Returns:
            Data with selected columns only
        """
        rename = rename or {}
        result = []
        
        for row in data:
            new_row = {}
            for col in columns:
                new_name = rename.get(col, col)
                new_row[new_name] = row.get(col)
            result.append(new_row)
        
        return result
    
    async def transform_column(
        self,
        data: List[Dict],
        column: str,
        transform: str,
        new_column: Optional[str] = None
    ) -> List[Dict]:
        """
        Transform a column's values.
        
        Transforms:
        - upper, lower, title, strip
        - int, float, str
        - date (parse as date)
        - split:delimiter (split string)
        
        Args:
            data: List of row dictionaries
            column: Column to transform
            transform: Transform type
            new_column: New column name (optional)
            
        Returns:
            Transformed data
        """
        target_col = new_column or column
        
        for row in data:
            value = row.get(column, '')
            
            if transform == 'upper':
                row[target_col] = str(value).upper()
            elif transform == 'lower':
                row[target_col] = str(value).lower()
            elif transform == 'title':
                row[target_col] = str(value).title()
            elif transform == 'strip':
                row[target_col] = str(value).strip()
            elif transform == 'int':
                try:
                    row[target_col] = int(float(value))
                except:
                    row[target_col] = None
            elif transform == 'float':
                try:
                    row[target_col] = float(value)
                except:
                    row[target_col] = None
            elif transform == 'str':
                row[target_col] = str(value)
            elif transform.startswith('split:'):
                delimiter = transform[6:]
                row[target_col] = str(value).split(delimiter)
            else:
                row[target_col] = value
        
        return data
    
    async def sort_rows(
        self,
        data: List[Dict],
        by: Union[str, List[str]],
        reverse: bool = False,
        numeric: bool = False
    ) -> List[Dict]:
        """
        Sort rows by column(s).
        
        Args:
            data: List of row dictionaries
            by: Column(s) to sort by
            reverse: Sort descending
            numeric: Sort as numbers
            
        Returns:
            Sorted data
        """
        if isinstance(by, str):
            by = [by]
        
        def sort_key(row):
            values = []
            for col in by:
                val = row.get(col, '')
                if numeric:
                    try:
                        val = float(val)
                    except:
                        val = 0
                values.append(val)
            return tuple(values)
        
        return sorted(data, key=sort_key, reverse=reverse)
    
    async def group_by(
        self,
        data: List[Dict],
        column: str,
        aggregations: Optional[Dict[str, str]] = None
    ) -> List[Dict]:
        """
        Group data by column with aggregations.
        
        Aggregations:
        - count, sum, avg, min, max
        - first, last
        - list (collect all values)
        
        Args:
            data: List of row dictionaries
            column: Column to group by
            aggregations: {column: aggregation_type}
            
        Returns:
            Grouped and aggregated data
        """
        from collections import defaultdict
        
        groups = defaultdict(list)
        
        for row in data:
            key = row.get(column)
            groups[key].append(row)
        
        result = []
        
        for key, rows in groups.items():
            group_result = {column: key, '_count': len(rows)}
            
            if aggregations:
                for agg_col, agg_type in aggregations.items():
                    values = [r.get(agg_col) for r in rows if r.get(agg_col) is not None]
                    
                    if agg_type == 'count':
                        group_result[f'{agg_col}_count'] = len(values)
                    elif agg_type == 'sum':
                        try:
                            group_result[f'{agg_col}_sum'] = sum(float(v) for v in values)
                        except:
                            group_result[f'{agg_col}_sum'] = None
                    elif agg_type == 'avg':
                        try:
                            nums = [float(v) for v in values]
                            group_result[f'{agg_col}_avg'] = sum(nums) / len(nums) if nums else None
                        except:
                            group_result[f'{agg_col}_avg'] = None
                    elif agg_type == 'min':
                        try:
                            group_result[f'{agg_col}_min'] = min(float(v) for v in values)
                        except:
                            group_result[f'{agg_col}_min'] = min(values) if values else None
                    elif agg_type == 'max':
                        try:
                            group_result[f'{agg_col}_max'] = max(float(v) for v in values)
                        except:
                            group_result[f'{agg_col}_max'] = max(values) if values else None
                    elif agg_type == 'first':
                        group_result[f'{agg_col}_first'] = values[0] if values else None
                    elif agg_type == 'last':
                        group_result[f'{agg_col}_last'] = values[-1] if values else None
                    elif agg_type == 'list':
                        group_result[f'{agg_col}_list'] = values
            
            result.append(group_result)
        
        return result
    
    async def get_stats(
        self,
        data: List[Dict],
        sample_size: int = 5
    ) -> CsvStats:
        """
        Get statistics about CSV data.
        
        Args:
            data: List of row dictionaries
            sample_size: Number of sample values per column
            
        Returns:
            CSV statistics
        """
        if not data:
            return CsvStats(
                row_count=0,
                column_count=0,
                columns=[],
                column_types={},
                null_counts={},
                unique_counts={},
                sample_values={}
            )
        
        columns = list(data[0].keys())
        column_types = {}
        null_counts = {}
        unique_values = {col: set() for col in columns}
        sample_values = {col: [] for col in columns}
        
        for row in data:
            for col in columns:
                value = row.get(col)
                
                if value is None or value == '':
                    null_counts[col] = null_counts.get(col, 0) + 1
                else:
                    unique_values[col].add(str(value))
                    
                    if len(sample_values[col]) < sample_size:
                        sample_values[col].append(value)
                    
                    if col not in column_types:
                        if isinstance(value, (int, float)):
                            column_types[col] = 'number'
                        else:
                            try:
                                float(value)
                                column_types[col] = 'number'
                            except:
                                column_types[col] = 'string'
        
        return CsvStats(
            row_count=len(data),
            column_count=len(columns),
            columns=columns,
            column_types=column_types,
            null_counts=null_counts,
            unique_counts={col: len(vals) for col, vals in unique_values.items()},
            sample_values=sample_values
        )
    
    async def merge(
        self,
        csv1: List[Dict],
        csv2: List[Dict],
        on: Optional[str] = None,
        how: str = 'inner'
    ) -> List[Dict]:
        """
        Merge two CSV datasets.
        
        Args:
            csv1: First dataset
            csv2: Second dataset
            on: Column to join on
            how: Join type (inner, left, right, outer)
            
        Returns:
            Merged dataset
        """
        if on is None:
            # Simple concatenation
            return csv1 + csv2
        
        # Build lookup for csv2
        lookup = {}
        for row in csv2:
            key = row.get(on)
            if key not in lookup:
                lookup[key] = []
            lookup[key].append(row)
        
        result = []
        matched_keys = set()
        
        for row1 in csv1:
            key = row1.get(on)
            matches = lookup.get(key, [])
            
            if matches:
                matched_keys.add(key)
                for row2 in matches:
                    merged = {**row1}
                    for k, v in row2.items():
                        if k != on:
                            merged[f'{k}_2'] = v
                    result.append(merged)
            elif how in ('left', 'outer'):
                result.append(row1)
        
        if how in ('right', 'outer'):
            for row2 in csv2:
                key = row2.get(on)
                if key not in matched_keys:
                    result.append(row2)
        
        return result
    
    async def deduplicate(
        self,
        data: List[Dict],
        columns: Optional[List[str]] = None,
        keep: str = 'first'
    ) -> List[Dict]:
        """
        Remove duplicate rows.
        
        Args:
            data: Dataset
            columns: Columns to check for duplicates
            keep: Which duplicate to keep (first, last)
            
        Returns:
            Deduplicated data
        """
        if columns is None:
            columns = list(data[0].keys()) if data else []
        
        seen = set()
        result = []
        
        items = data if keep == 'first' else reversed(data)
        
        for row in items:
            key = tuple(row.get(col) for col in columns)
            if key not in seen:
                seen.add(key)
                result.append(row)
        
        if keep == 'last':
            result.reverse()
        
        return result
    
    async def to_json(
        self,
        data: List[Dict],
        orient: str = 'records'
    ) -> Any:
        """
        Convert CSV data to JSON format.
        
        Orientations:
        - records: [{col: val}, ...]
        - columns: {col: [values], ...}
        - values: [[val, ...], ...]
        
        Args:
            data: CSV data
            orient: Output orientation
            
        Returns:
            JSON-compatible data
        """
        if orient == 'records':
            return data
        elif orient == 'columns':
            if not data:
                return {}
            columns = list(data[0].keys())
            result = {col: [] for col in columns}
            for row in data:
                for col in columns:
                    result[col].append(row.get(col))
            return result
        elif orient == 'values':
            if not data:
                return []
            columns = list(data[0].keys())
            return [[row.get(col) for col in columns] for row in data]
        else:
            return data
    
    async def run(self, context: ToolContext, **kwargs) -> ToolResult:
        """
        Execute CSV operation.
        
        Supported operations:
        - parse: Parse CSV string
        - parse_rows: Parse to rows
        - to_csv: Convert to CSV
        - filter: Filter rows
        - select: Select columns
        - transform: Transform column
        - sort: Sort rows
        - group: Group by column
        - stats: Get statistics
        - merge: Merge datasets
        - deduplicate: Remove duplicates
        - to_json: Convert to JSON
        """
        operation = kwargs.get('operation', 'parse')
        
        try:
            if operation == 'parse':
                data = kwargs.get('data') or kwargs.get('csv')
                if not data:
                    return ToolResult.fail(error="data is required")
                
                dialect = None
                if kwargs.get('delimiter'):
                    dialect = CsvDialect(delimiter=kwargs['delimiter'])
                
                result = await self.parse(
                    data,
                    has_header=kwargs.get('has_header', True),
                    dialect=dialect,
                    columns=kwargs.get('columns'),
                    skip_rows=kwargs.get('skip_rows', 0),
                    max_rows=kwargs.get('max_rows'),
                    strip_whitespace=kwargs.get('strip', True)
                )
                
                if result['success']:
                    return ToolResult.ok(
                        data=result,
                        message=f"Parsed {result['row_count']} rows"
                    )
                else:
                    return ToolResult.fail(error=result.get('error'))
            
            elif operation == 'parse_rows':
                data = kwargs.get('data') or kwargs.get('csv')
                if not data:
                    return ToolResult.fail(error="data is required")
                
                result = await self.parse_to_rows(
                    data,
                    has_header=kwargs.get('has_header', True)
                )
                
                return ToolResult.ok(data=result)
            
            elif operation == 'to_csv':
                data = kwargs.get('data')
                if not data:
                    return ToolResult.fail(error="data is required")
                
                result = await self.to_csv(
                    data,
                    columns=kwargs.get('columns'),
                    include_header=kwargs.get('include_header', True)
                )
                
                return ToolResult.ok(data={'csv': result})
            
            elif operation == 'filter':
                data = kwargs.get('data')
                conditions = kwargs.get('conditions', {})
                
                if not data:
                    return ToolResult.fail(error="data is required")
                
                result = await self.filter_rows(data, conditions)
                
                return ToolResult.ok(
                    data={'data': result, 'row_count': len(result)},
                    message=f"Filtered to {len(result)} rows"
                )
            
            elif operation == 'select':
                data = kwargs.get('data')
                columns = kwargs.get('columns', [])
                
                if not data:
                    return ToolResult.fail(error="data is required")
                
                result = await self.select_columns(
                    data, columns,
                    rename=kwargs.get('rename')
                )
                
                return ToolResult.ok(data={'data': result})
            
            elif operation == 'transform':
                data = kwargs.get('data')
                column = kwargs.get('column')
                transform = kwargs.get('transform')
                
                if not data or not column or not transform:
                    return ToolResult.fail(
                        error="data, column, and transform are required"
                    )
                
                result = await self.transform_column(
                    data, column, transform,
                    new_column=kwargs.get('new_column')
                )
                
                return ToolResult.ok(data={'data': result})
            
            elif operation == 'sort':
                data = kwargs.get('data')
                by = kwargs.get('by')
                
                if not data or not by:
                    return ToolResult.fail(error="data and by are required")
                
                result = await self.sort_rows(
                    data, by,
                    reverse=kwargs.get('reverse', False),
                    numeric=kwargs.get('numeric', False)
                )
                
                return ToolResult.ok(data={'data': result})
            
            elif operation == 'group':
                data = kwargs.get('data')
                column = kwargs.get('column') or kwargs.get('by')
                
                if not data or not column:
                    return ToolResult.fail(error="data and column are required")
                
                result = await self.group_by(
                    data, column,
                    aggregations=kwargs.get('aggregations')
                )
                
                return ToolResult.ok(
                    data={'data': result, 'group_count': len(result)},
                    message=f"Created {len(result)} groups"
                )
            
            elif operation == 'stats':
                data = kwargs.get('data')
                
                if not data:
                    return ToolResult.fail(error="data is required")
                
                result = await self.get_stats(
                    data,
                    sample_size=kwargs.get('sample_size', 5)
                )
                
                return ToolResult.ok(data=result.to_dict())
            
            elif operation == 'merge':
                csv1 = kwargs.get('csv1') or kwargs.get('data1')
                csv2 = kwargs.get('csv2') or kwargs.get('data2')
                
                if not csv1 or not csv2:
                    return ToolResult.fail(error="csv1 and csv2 are required")
                
                result = await self.merge(
                    csv1, csv2,
                    on=kwargs.get('on'),
                    how=kwargs.get('how', 'inner')
                )
                
                return ToolResult.ok(
                    data={'data': result, 'row_count': len(result)},
                    message=f"Merged to {len(result)} rows"
                )
            
            elif operation == 'deduplicate':
                data = kwargs.get('data')
                
                if not data:
                    return ToolResult.fail(error="data is required")
                
                result = await self.deduplicate(
                    data,
                    columns=kwargs.get('columns'),
                    keep=kwargs.get('keep', 'first')
                )
                
                removed = len(data) - len(result)
                return ToolResult.ok(
                    data={'data': result, 'row_count': len(result), 'removed': removed},
                    message=f"Removed {removed} duplicates"
                )
            
            elif operation == 'to_json':
                data = kwargs.get('data')
                
                if not data:
                    return ToolResult.fail(error="data is required")
                
                result = await self.to_json(
                    data,
                    orient=kwargs.get('orient', 'records')
                )
                
                return ToolResult.ok(data=result)
            
            else:
                return ToolResult.fail(error=f"Unknown operation: {operation}")
            
        except Exception as e:
            logger.error(f"CsvTools error: {e}")
            return ToolResult.error(error=str(e))


# Create singleton
csv_tools = CsvTools()


def register():
    """Register CSV tools."""
    registry = get_registry()
    registry.register_tool(csv_tools)