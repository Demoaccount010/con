"""
JSON Tools - Comprehensive JSON manipulation.
Parse, query, transform, validate, and format JSON data.
"""

import asyncio
import json
import re
from pathlib import Path
from typing import Optional, Dict, Any, List, Union
from dataclasses import dataclass, field
from datetime import datetime
from copy import deepcopy
import logging

import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from tools.base_tool import (
    BaseTool, ToolResult, ToolContext, ResultStatus,
    ToolCategory, ToolRisk
)
from tools.registry import get_registry

logger = logging.getLogger(__name__)


@dataclass
class JsonValidationResult:
    """Result of JSON validation."""
    valid: bool
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'valid': self.valid,
            'errors': self.errors,
            'warnings': self.warnings
        }


@dataclass
class JsonDiff:
    """Difference between two JSON objects."""
    added: Dict[str, Any] = field(default_factory=dict)
    removed: Dict[str, Any] = field(default_factory=dict)
    modified: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    unchanged_count: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'added': self.added,
            'removed': self.removed,
            'modified': self.modified,
            'unchanged_count': self.unchanged_count,
            'has_changes': bool(self.added or self.removed or self.modified)
        }


class JsonTools(BaseTool):
    """
    JSON manipulation tool.
    
    Features:
    - Parse and validate JSON
    - Query with JSONPath-like syntax
    - Transform and modify
    - Merge and diff
    - Format and minify
    - Schema validation
    - Type conversion
    """
    
    def __init__(self):
        super().__init__(
            name="json_tools",
            description="JSON parsing, querying, and manipulation",
            category=ToolCategory.DATA,
            risk=ToolRisk.NONE,
            requires_confirmation=False,
            timeout=60.0,
            version="1.0.0"
        )
    
    async def parse(
        self,
        data: Union[str, bytes],
        strict: bool = True
    ) -> Dict[str, Any]:
        """
        Parse JSON string to Python object.
        
        Args:
            data: JSON string or bytes
            strict: Use strict parsing
            
        Returns:
            Parsed data with metadata
        """
        try:
            if isinstance(data, bytes):
                data = data.decode('utf-8')
            
            # Remove BOM if present
            if data.startswith('\ufeff'):
                data = data[1:]
            
            parsed = json.loads(data, strict=strict)
            
            return {
                'success': True,
                'data': parsed,
                'type': type(parsed).__name__,
                'size': len(data)
            }
            
        except json.JSONDecodeError as e:
            return {
                'success': False,
                'error': str(e),
                'line': e.lineno,
                'column': e.colno,
                'position': e.pos
            }
    
    async def stringify(
        self,
        data: Any,
        indent: Optional[int] = 2,
        sort_keys: bool = False,
        ensure_ascii: bool = False,
        compact: bool = False
    ) -> str:
        """
        Convert Python object to JSON string.
        
        Args:
            data: Data to convert
            indent: Indentation level (None for compact)
            sort_keys: Sort object keys
            ensure_ascii: Escape non-ASCII characters
            compact: Use compact format
            
        Returns:
            JSON string
        """
        if compact:
            indent = None
            separators = (',', ':')
        else:
            separators = None
        
        return json.dumps(
            data,
            indent=indent,
            sort_keys=sort_keys,
            ensure_ascii=ensure_ascii,
            separators=separators,
            default=str  # Handle non-serializable types
        )
    
    async def validate(
        self,
        data: Union[str, Dict, List],
        schema: Optional[Dict] = None
    ) -> JsonValidationResult:
        """
        Validate JSON data.
        
        Args:
            data: JSON data (string or parsed)
            schema: Optional JSON Schema for validation
            
        Returns:
            Validation result
        """
        errors = []
        warnings = []
        
        # Parse if string
        if isinstance(data, str):
            try:
                data = json.loads(data)
            except json.JSONDecodeError as e:
                return JsonValidationResult(
                    valid=False,
                    errors=[f"Invalid JSON: {e}"]
                )
        
        # Basic validation passed
        if schema is None:
            return JsonValidationResult(valid=True)
        
        # Schema validation
        try:
            import jsonschema
            
            validator = jsonschema.Draft7Validator(schema)
            schema_errors = list(validator.iter_errors(data))
            
            for error in schema_errors:
                path = '.'.join(str(p) for p in error.absolute_path)
                errors.append(f"{path}: {error.message}" if path else error.message)
            
            return JsonValidationResult(
                valid=len(errors) == 0,
                errors=errors,
                warnings=warnings
            )
            
        except ImportError:
            # No jsonschema, do basic type checking
            warnings.append("jsonschema not installed, schema validation skipped")
            return JsonValidationResult(
                valid=True,
                warnings=warnings
            )
        except Exception as e:
            return JsonValidationResult(
                valid=False,
                errors=[f"Schema validation error: {e}"]
            )
    
    async def query(
        self,
        data: Union[str, Dict, List],
        path: str
    ) -> Any:
        """
        Query JSON data using path syntax.
        
        Supports:
        - Dot notation: data.users.0.name
        - Bracket notation: data['users'][0]['name']
        - Array indexing: data.users[0]
        - Wildcards: data.users[*].name
        
        Args:
            data: JSON data
            path: Query path
            
        Returns:
            Queried value(s)
        """
        # Parse if string
        if isinstance(data, str):
            data = json.loads(data)
        
        # Handle empty path
        if not path or path == '$':
            return data
        
        # Remove leading $ if present
        if path.startswith('$.'):
            path = path[2:]
        elif path.startswith('$'):
            path = path[1:]
        
        # Split path into parts
        parts = self._parse_path(path)
        
        return self._query_recursive(data, parts)
    
    def _parse_path(self, path: str) -> List[Union[str, int]]:
        """Parse query path into parts."""
        parts = []
        current = ''
        i = 0
        
        while i < len(path):
            char = path[i]
            
            if char == '.':
                if current:
                    parts.append(current)
                    current = ''
            elif char == '[':
                if current:
                    parts.append(current)
                    current = ''
                # Find closing bracket
                j = i + 1
                while j < len(path) and path[j] != ']':
                    j += 1
                key = path[i+1:j]
                # Handle quotes
                if key.startswith("'") and key.endswith("'"):
                    key = key[1:-1]
                elif key.startswith('"') and key.endswith('"'):
                    key = key[1:-1]
                elif key.isdigit():
                    key = int(key)
                elif key == '*':
                    key = '*'
                parts.append(key)
                i = j
            else:
                current += char
            
            i += 1
        
        if current:
            parts.append(current)
        
        return parts
    
    def _query_recursive(
        self,
        data: Any,
        parts: List[Union[str, int]]
    ) -> Any:
        """Recursively query data."""
        if not parts:
            return data
        
        if data is None:
            return None
        
        part = parts[0]
        remaining = parts[1:]
        
        # Wildcard
        if part == '*':
            if isinstance(data, list):
                return [self._query_recursive(item, remaining) for item in data]
            elif isinstance(data, dict):
                return [self._query_recursive(v, remaining) for v in data.values()]
            return None
        
        # Array index
        if isinstance(part, int):
            if isinstance(data, list) and -len(data) <= part < len(data):
                return self._query_recursive(data[part], remaining)
            return None
        
        # Object key
        if isinstance(data, dict) and part in data:
            return self._query_recursive(data[part], remaining)
        
        # Array with string index (try to convert)
        if isinstance(data, list):
            try:
                idx = int(part)
                if -len(data) <= idx < len(data):
                    return self._query_recursive(data[idx], remaining)
            except ValueError:
                pass
        
        return None
    
    async def set_value(
        self,
        data: Union[str, Dict, List],
        path: str,
        value: Any
    ) -> Dict[str, Any]:
        """
        Set a value at the specified path.
        
        Args:
            data: JSON data
            path: Path to set
            value: Value to set
            
        Returns:
            Modified data
        """
        if isinstance(data, str):
            data = json.loads(data)
        
        data = deepcopy(data)
        parts = self._parse_path(path)
        
        if not parts:
            return {'success': True, 'data': value}
        
        # Navigate to parent
        current = data
        for i, part in enumerate(parts[:-1]):
            if isinstance(part, int):
                if not isinstance(current, list):
                    return {'success': False, 'error': f'Cannot index into non-array at {part}'}
                while len(current) <= part:
                    current.append(None)
                if current[part] is None:
                    # Determine next type
                    next_part = parts[i + 1]
                    current[part] = [] if isinstance(next_part, int) else {}
                current = current[part]
            else:
                if not isinstance(current, dict):
                    return {'success': False, 'error': f'Cannot access key on non-object at {part}'}
                if part not in current:
                    next_part = parts[i + 1]
                    current[part] = [] if isinstance(next_part, int) else {}
                current = current[part]
        
        # Set final value
        final_key = parts[-1]
        if isinstance(final_key, int):
            if not isinstance(current, list):
                return {'success': False, 'error': 'Cannot set index on non-array'}
            while len(current) <= final_key:
                current.append(None)
            current[final_key] = value
        else:
            if not isinstance(current, dict):
                return {'success': False, 'error': 'Cannot set key on non-object'}
            current[final_key] = value
        
        return {'success': True, 'data': data}
    
    async def delete_value(
        self,
        data: Union[str, Dict, List],
        path: str
    ) -> Dict[str, Any]:
        """
        Delete a value at the specified path.
        
        Args:
            data: JSON data
            path: Path to delete
            
        Returns:
            Modified data
        """
        if isinstance(data, str):
            data = json.loads(data)
        
        data = deepcopy(data)
        parts = self._parse_path(path)
        
        if not parts:
            return {'success': False, 'error': 'Cannot delete root'}
        
        # Navigate to parent
        current = data
        for part in parts[:-1]:
            if isinstance(part, int):
                if not isinstance(current, list) or part >= len(current):
                    return {'success': False, 'error': f'Path not found at {part}'}
                current = current[part]
            else:
                if not isinstance(current, dict) or part not in current:
                    return {'success': False, 'error': f'Path not found at {part}'}
                current = current[part]
        
        # Delete
        final_key = parts[-1]
        if isinstance(final_key, int):
            if isinstance(current, list) and final_key < len(current):
                del current[final_key]
            else:
                return {'success': False, 'error': 'Index out of range'}
        else:
            if isinstance(current, dict) and final_key in current:
                del current[final_key]
            else:
                return {'success': False, 'error': 'Key not found'}
        
        return {'success': True, 'data': data}
    
    async def merge(
        self,
        base: Union[str, Dict],
        overlay: Union[str, Dict],
        deep: bool = True,
        array_strategy: str = 'replace'  # replace, append, merge
    ) -> Dict[str, Any]:
        """
        Merge two JSON objects.
        
        Args:
            base: Base object
            overlay: Object to merge on top
            deep: Deep merge nested objects
            array_strategy: How to handle arrays
            
        Returns:
            Merged object
        """
        if isinstance(base, str):
            base = json.loads(base)
        if isinstance(overlay, str):
            overlay = json.loads(overlay)
        
        base = deepcopy(base)
        overlay = deepcopy(overlay)
        
        def merge_recursive(b: Any, o: Any) -> Any:
            if not deep:
                return o
            
            if isinstance(b, dict) and isinstance(o, dict):
                result = dict(b)
                for key, value in o.items():
                    if key in result:
                        result[key] = merge_recursive(result[key], value)
                    else:
                        result[key] = value
                return result
            
            if isinstance(b, list) and isinstance(o, list):
                if array_strategy == 'append':
                    return b + o
                elif array_strategy == 'merge':
                    # Merge by index
                    result = list(b)
                    for i, item in enumerate(o):
                        if i < len(result):
                            result[i] = merge_recursive(result[i], item)
                        else:
                            result.append(item)
                    return result
                else:  # replace
                    return o
            
            return o
        
        return {
            'success': True,
            'data': merge_recursive(base, overlay)
        }
    
    async def diff(
        self,
        obj1: Union[str, Dict, List],
        obj2: Union[str, Dict, List],
        ignore_order: bool = False
    ) -> JsonDiff:
        """
        Find differences between two JSON objects.
        
        Args:
            obj1: First object
            obj2: Second object
            ignore_order: Ignore array order
            
        Returns:
            JsonDiff with changes
        """
        if isinstance(obj1, str):
            obj1 = json.loads(obj1)
        if isinstance(obj2, str):
            obj2 = json.loads(obj2)
        
        diff = JsonDiff()
        
        def compare(path: str, o1: Any, o2: Any):
            if type(o1) != type(o2):
                diff.modified[path] = {'old': o1, 'new': o2}
                return
            
            if isinstance(o1, dict):
                all_keys = set(o1.keys()) | set(o2.keys())
                for key in all_keys:
                    child_path = f"{path}.{key}" if path else key
                    if key not in o1:
                        diff.added[child_path] = o2[key]
                    elif key not in o2:
                        diff.removed[child_path] = o1[key]
                    else:
                        compare(child_path, o1[key], o2[key])
            
            elif isinstance(o1, list):
                if ignore_order:
                    # Compare as sets (for hashable items)
                    try:
                        s1 = set(json.dumps(x, sort_keys=True) for x in o1)
                        s2 = set(json.dumps(x, sort_keys=True) for x in o2)
                        if s1 != s2:
                            diff.modified[path] = {'old': o1, 'new': o2}
                        else:
                            diff.unchanged_count += 1
                        return
                    except:
                        pass
                
                # Compare by index
                for i in range(max(len(o1), len(o2))):
                    child_path = f"{path}[{i}]"
                    if i >= len(o1):
                        diff.added[child_path] = o2[i]
                    elif i >= len(o2):
                        diff.removed[child_path] = o1[i]
                    else:
                        compare(child_path, o1[i], o2[i])
            
            elif o1 != o2:
                diff.modified[path] = {'old': o1, 'new': o2}
            else:
                diff.unchanged_count += 1
        
        compare('', obj1, obj2)
        return diff
    
    async def flatten(
        self,
        data: Union[str, Dict],
        separator: str = '.',
        prefix: str = ''
    ) -> Dict[str, Any]:
        """
        Flatten nested JSON to single level.
        
        Args:
            data: Nested JSON
            separator: Key separator
            prefix: Key prefix
            
        Returns:
            Flattened dictionary
        """
        if isinstance(data, str):
            data = json.loads(data)
        
        result = {}
        
        def flatten_recursive(obj: Any, path: str):
            if isinstance(obj, dict):
                for key, value in obj.items():
                    new_path = f"{path}{separator}{key}" if path else key
                    flatten_recursive(value, new_path)
            elif isinstance(obj, list):
                for i, value in enumerate(obj):
                    new_path = f"{path}[{i}]"
                    flatten_recursive(value, new_path)
            else:
                result[path] = obj
        
        flatten_recursive(data, prefix)
        return result
    
    async def unflatten(
        self,
        data: Dict[str, Any],
        separator: str = '.'
    ) -> Dict[str, Any]:
        """
        Unflatten a flat dictionary to nested structure.
        
        Args:
            data: Flat dictionary
            separator: Key separator
            
        Returns:
            Nested dictionary
        """
        result = {}
        
        for key, value in data.items():
            parts = self._parse_path(key.replace(separator, '.'))
            
            current = result
            for i, part in enumerate(parts[:-1]):
                if isinstance(part, int):
                    while len(current) <= part:
                        current.append(None)
                    if current[part] is None:
                        next_part = parts[i + 1]
                        current[part] = [] if isinstance(next_part, int) else {}
                    current = current[part]
                else:
                    if part not in current:
                        next_part = parts[i + 1]
                        current[part] = [] if isinstance(next_part, int) else {}
                    current = current[part]
            
            final = parts[-1]
            if isinstance(final, int):
                while len(current) <= final:
                    current.append(None)
                current[final] = value
            else:
                current[final] = value
        
        return result
    
    async def transform(
        self,
        data: Union[str, Dict, List],
        transformations: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Apply transformations to JSON data.
        
        Transformations:
        - {"rename": {"old_key": "new_key"}}
        - {"delete": ["key1", "key2"]}
        - {"set": {"path": value}}
        - {"map": {"path": "function"}}
        
        Args:
            data: JSON data
            transformations: List of transformations
            
        Returns:
            Transformed data
        """
        if isinstance(data, str):
            data = json.loads(data)
        
        data = deepcopy(data)
        
        for transform in transformations:
            if 'rename' in transform:
                for old_key, new_key in transform['rename'].items():
                    if isinstance(data, dict) and old_key in data:
                        data[new_key] = data.pop(old_key)
            
            if 'delete' in transform:
                for key in transform['delete']:
                    if isinstance(data, dict) and key in data:
                        del data[key]
            
            if 'set' in transform:
                for path, value in transform['set'].items():
                    result = await self.set_value(data, path, value)
                    if result['success']:
                        data = result['data']
            
            if 'filter' in transform:
                filter_config = transform['filter']
                if isinstance(data, list):
                    path = filter_config.get('path', '')
                    value = filter_config.get('value')
                    data = [
                        item for item in data
                        if await self.query(item, path) == value
                    ]
        
        return {'success': True, 'data': data}
    
    async def format_json(
        self,
        data: Union[str, Dict, List],
        indent: int = 2,
        sort_keys: bool = False
    ) -> str:
        """Format JSON with pretty printing."""
        if isinstance(data, str):
            data = json.loads(data)
        
        return json.dumps(data, indent=indent, sort_keys=sort_keys, ensure_ascii=False)
    
    async def minify(self, data: Union[str, Dict, List]) -> str:
        """Minify JSON by removing whitespace."""
        if isinstance(data, str):
            data = json.loads(data)
        
        return json.dumps(data, separators=(',', ':'), ensure_ascii=False)
    
    async def run(self, context: ToolContext, **kwargs) -> ToolResult:
        """
        Execute JSON operation.
        
        Supported operations:
        - parse: Parse JSON string
        - stringify: Convert to JSON string
        - validate: Validate JSON
        - query: Query with path
        - set: Set value at path
        - delete: Delete value at path
        - merge: Merge two objects
        - diff: Compare two objects
        - flatten: Flatten nested structure
        - unflatten: Unflatten to nested
        - transform: Apply transformations
        - format: Pretty print
        - minify: Compact format
        """
        operation = kwargs.get('operation', 'parse')
        
        try:
            if operation == 'parse':
                data = kwargs.get('data') or kwargs.get('json')
                if not data:
                    return ToolResult.fail(error="data is required")
                
                result = await self.parse(data, strict=kwargs.get('strict', True))
                
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('error'))
            
            elif operation == 'stringify':
                data = kwargs.get('data')
                if data is None:
                    return ToolResult.fail(error="data is required")
                
                result = await self.stringify(
                    data,
                    indent=kwargs.get('indent', 2),
                    sort_keys=kwargs.get('sort_keys', False),
                    compact=kwargs.get('compact', False)
                )
                
                return ToolResult.ok(data={'json': result})
            
            elif operation == 'validate':
                data = kwargs.get('data')
                schema = kwargs.get('schema')
                
                if data is None:
                    return ToolResult.fail(error="data is required")
                
                result = await self.validate(data, schema)
                
                return ToolResult.ok(
                    data=result.to_dict(),
                    message="Valid JSON" if result.valid else "Invalid JSON"
                )
            
            elif operation == 'query':
                data = kwargs.get('data')
                path = kwargs.get('path')
                
                if data is None or not path:
                    return ToolResult.fail(error="data and path are required")
                
                result = await self.query(data, path)
                
                return ToolResult.ok(
                    data={'path': path, 'value': result}
                )
            
            elif operation == 'set':
                data = kwargs.get('data')
                path = kwargs.get('path')
                value = kwargs.get('value')
                
                if data is None or not path:
                    return ToolResult.fail(error="data and path are required")
                
                result = await self.set_value(data, path, value)
                
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('error'))
            
            elif operation == 'delete':
                data = kwargs.get('data')
                path = kwargs.get('path')
                
                if data is None or not path:
                    return ToolResult.fail(error="data and path are required")
                
                result = await self.delete_value(data, path)
                
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('error'))
            
            elif operation == 'merge':
                base = kwargs.get('base')
                overlay = kwargs.get('overlay')
                
                if base is None or overlay is None:
                    return ToolResult.fail(error="base and overlay are required")
                
                result = await self.merge(
                    base, overlay,
                    deep=kwargs.get('deep', True),
                    array_strategy=kwargs.get('array_strategy', 'replace')
                )
                
                return ToolResult.ok(data=result)
            
            elif operation == 'diff':
                obj1 = kwargs.get('obj1') or kwargs.get('first')
                obj2 = kwargs.get('obj2') or kwargs.get('second')
                
                if obj1 is None or obj2 is None:
                    return ToolResult.fail(error="obj1 and obj2 are required")
                
                result = await self.diff(
                    obj1, obj2,
                    ignore_order=kwargs.get('ignore_order', False)
                )
                
                return ToolResult.ok(data=result.to_dict())
            
            elif operation == 'flatten':
                data = kwargs.get('data')
                if data is None:
                    return ToolResult.fail(error="data is required")
                
                result = await self.flatten(
                    data,
                    separator=kwargs.get('separator', '.'),
                    prefix=kwargs.get('prefix', '')
                )
                
                return ToolResult.ok(data=result)
            
            elif operation == 'unflatten':
                data = kwargs.get('data')
                if data is None:
                    return ToolResult.fail(error="data is required")
                
                result = await self.unflatten(
                    data,
                    separator=kwargs.get('separator', '.')
                )
                
                return ToolResult.ok(data=result)
            
            elif operation == 'transform':
                data = kwargs.get('data')
                transformations = kwargs.get('transformations', [])
                
                if data is None:
                    return ToolResult.fail(error="data is required")
                
                result = await self.transform(data, transformations)
                
                return ToolResult.ok(data=result)
            
            elif operation == 'format':
                data = kwargs.get('data')
                if data is None:
                    return ToolResult.fail(error="data is required")
                
                result = await self.format_json(
                    data,
                    indent=kwargs.get('indent', 2),
                    sort_keys=kwargs.get('sort_keys', False)
                )
                
                return ToolResult.ok(data={'formatted': result})
            
            elif operation == 'minify':
                data = kwargs.get('data')
                if data is None:
                    return ToolResult.fail(error="data is required")
                
                result = await self.minify(data)
                
                return ToolResult.ok(data={'minified': result})
            
            else:
                return ToolResult.fail(error=f"Unknown operation: {operation}")
            
        except json.JSONDecodeError as e:
            return ToolResult.fail(error=f"JSON decode error: {e}")
        except Exception as e:
            logger.error(f"JsonTools error: {e}")
            return ToolResult.error(error=str(e))


# Create singleton
json_tools = JsonTools()


def register():
    """Register JSON tools."""
    registry = get_registry()
    registry.register_tool(json_tools)