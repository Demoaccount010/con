"""
Query Executor - Safe SQL query execution with validation.
Build and execute queries with safety checks.
"""

import asyncio
import re
from pathlib import Path
from typing import Optional, Dict, Any, List, Union, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import logging

import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from tools.base_tool import (
    BaseTool, ToolResult, ToolContext, ResultStatus,
    ToolCategory, ToolRisk
)
from tools.registry import get_registry
from tools.database_ops.sqlite_tools import sqlite_tools, QueryResult

logger = logging.getLogger(__name__)


class QueryType(Enum):
    """Types of SQL queries."""
    SELECT = "select"
    INSERT = "insert"
    UPDATE = "update"
    DELETE = "delete"
    CREATE = "create"
    ALTER = "alter"
    DROP = "drop"
    OTHER = "other"


class RiskLevel(Enum):
    """Query risk levels."""
    SAFE = "safe"           # SELECT queries
    LOW = "low"             # INSERT queries
    MEDIUM = "medium"       # UPDATE with WHERE
    HIGH = "high"           # DELETE, ALTER
    CRITICAL = "critical"   # DROP, TRUNCATE


@dataclass
class QueryAnalysis:
    """Analysis of a SQL query."""
    query_type: QueryType
    risk_level: RiskLevel
    tables_affected: List[str]
    has_where_clause: bool
    has_limit: bool
    is_parameterized: bool
    potential_issues: List[str]
    estimated_rows_affected: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'query_type': self.query_type.value,
            'risk_level': self.risk_level.value,
            'tables_affected': self.tables_affected,
            'has_where_clause': self.has_where_clause,
            'has_limit': self.has_limit,
            'is_parameterized': self.is_parameterized,
            'potential_issues': self.potential_issues,
            'estimated_rows_affected': self.estimated_rows_affected
        }


@dataclass
class QueryBuilder:
    """Builder for SQL queries."""
    _operation: str = "SELECT"
    _table: str = ""
    _columns: List[str] = field(default_factory=list)
    _values: Dict[str, Any] = field(default_factory=dict)
    _where_conditions: List[str] = field(default_factory=list)
    _where_params: List[Any] = field(default_factory=list)
    _order_by: List[str] = field(default_factory=list)
    _group_by: List[str] = field(default_factory=list)
    _having: Optional[str] = None
    _limit: Optional[int] = None
    _offset: Optional[int] = None
    _joins: List[str] = field(default_factory=list)
    
    def select(self, *columns) -> 'QueryBuilder':
        """Set SELECT columns."""
        self._operation = "SELECT"
        self._columns = list(columns) if columns else ['*']
        return self
    
    def insert_into(self, table: str) -> 'QueryBuilder':
        """Set INSERT table."""
        self._operation = "INSERT"
        self._table = table
        return self
    
    def update(self, table: str) -> 'QueryBuilder':
        """Set UPDATE table."""
        self._operation = "UPDATE"
        self._table = table
        return self
    
    def delete_from(self, table: str) -> 'QueryBuilder':
        """Set DELETE table."""
        self._operation = "DELETE"
        self._table = table
        return self
    
    def from_table(self, table: str) -> 'QueryBuilder':
        """Set FROM table."""
        self._table = table
        return self
    
    def values(self, **kwargs) -> 'QueryBuilder':
        """Set values for INSERT/UPDATE."""
        self._values.update(kwargs)
        return self
    
    def set(self, **kwargs) -> 'QueryBuilder':
        """Alias for values()."""
        return self.values(**kwargs)
    
    def where(self, condition: str, *params) -> 'QueryBuilder':
        """Add WHERE condition."""
        self._where_conditions.append(condition)
        self._where_params.extend(params)
        return self
    
    def where_eq(self, column: str, value: Any) -> 'QueryBuilder':
        """Add WHERE column = value."""
        self._where_conditions.append(f"{column} = ?")
        self._where_params.append(value)
        return self
    
    def where_in(self, column: str, values: List[Any]) -> 'QueryBuilder':
        """Add WHERE column IN (...)."""
        placeholders = ', '.join(['?' for _ in values])
        self._where_conditions.append(f"{column} IN ({placeholders})")
        self._where_params.extend(values)
        return self
    
    def where_like(self, column: str, pattern: str) -> 'QueryBuilder':
        """Add WHERE column LIKE pattern."""
        self._where_conditions.append(f"{column} LIKE ?")
        self._where_params.append(pattern)
        return self
    
    def where_between(self, column: str, start: Any, end: Any) -> 'QueryBuilder':
        """Add WHERE column BETWEEN start AND end."""
        self._where_conditions.append(f"{column} BETWEEN ? AND ?")
        self._where_params.extend([start, end])
        return self
    
    def and_where(self, condition: str, *params) -> 'QueryBuilder':
        """Alias for where() - for readability."""
        return self.where(condition, *params)
    
    def or_where(self, condition: str, *params) -> 'QueryBuilder':
        """Add OR WHERE condition."""
        if self._where_conditions:
            self._where_conditions[-1] = f"({self._where_conditions[-1]}) OR ({condition})"
        else:
            self._where_conditions.append(condition)
        self._where_params.extend(params)
        return self
    
    def join(self, table: str, on: str) -> 'QueryBuilder':
        """Add JOIN."""
        self._joins.append(f"JOIN {table} ON {on}")
        return self
    
    def left_join(self, table: str, on: str) -> 'QueryBuilder':
        """Add LEFT JOIN."""
        self._joins.append(f"LEFT JOIN {table} ON {on}")
        return self
    
    def order_by(self, *columns, desc: bool = False) -> 'QueryBuilder':
        """Add ORDER BY."""
        direction = "DESC" if desc else "ASC"
        for col in columns:
            self._order_by.append(f"{col} {direction}")
        return self
    
    def group_by(self, *columns) -> 'QueryBuilder':
        """Add GROUP BY."""
        self._group_by.extend(columns)
        return self
    
    def having(self, condition: str) -> 'QueryBuilder':
        """Add HAVING clause."""
        self._having = condition
        return self
    
    def limit(self, count: int) -> 'QueryBuilder':
        """Add LIMIT."""
        self._limit = count
        return self
    
    def offset(self, count: int) -> 'QueryBuilder':
        """Add OFFSET."""
        self._offset = count
        return self
    
    def build(self) -> Tuple[str, Tuple]:
        """Build the SQL query and parameters."""
        if self._operation == "SELECT":
            return self._build_select()
        elif self._operation == "INSERT":
            return self._build_insert()
        elif self._operation == "UPDATE":
            return self._build_update()
        elif self._operation == "DELETE":
            return self._build_delete()
        else:
            raise ValueError(f"Unknown operation: {self._operation}")
    
    def _build_select(self) -> Tuple[str, Tuple]:
        """Build SELECT query."""
        columns = ', '.join(self._columns) if self._columns else '*'
        sql = f"SELECT {columns} FROM {self._table}"
        
        # Joins
        if self._joins:
            sql += ' ' + ' '.join(self._joins)
        
        # Where
        if self._where_conditions:
            sql += " WHERE " + " AND ".join(self._where_conditions)
        
        # Group by
        if self._group_by:
            sql += " GROUP BY " + ', '.join(self._group_by)
        
        # Having
        if self._having:
            sql += f" HAVING {self._having}"
        
        # Order by
        if self._order_by:
            sql += " ORDER BY " + ', '.join(self._order_by)
        
        # Limit
        if self._limit is not None:
            sql += f" LIMIT {self._limit}"
        
        # Offset
        if self._offset is not None:
            sql += f" OFFSET {self._offset}"
        
        return sql, tuple(self._where_params)
    
    def _build_insert(self) -> Tuple[str, Tuple]:
        """Build INSERT query."""
        columns = ', '.join(self._values.keys())
        placeholders = ', '.join(['?' for _ in self._values])
        sql = f"INSERT INTO {self._table} ({columns}) VALUES ({placeholders})"
        return sql, tuple(self._values.values())
    
    def _build_update(self) -> Tuple[str, Tuple]:
        """Build UPDATE query."""
        set_parts = [f"{col} = ?" for col in self._values.keys()]
        sql = f"UPDATE {self._table} SET {', '.join(set_parts)}"
        
        params = list(self._values.values())
        
        if self._where_conditions:
            sql += " WHERE " + " AND ".join(self._where_conditions)
            params.extend(self._where_params)
        
        return sql, tuple(params)
    
    def _build_delete(self) -> Tuple[str, Tuple]:
        """Build DELETE query."""
        sql = f"DELETE FROM {self._table}"
        
        if self._where_conditions:
            sql += " WHERE " + " AND ".join(self._where_conditions)
        
        return sql, tuple(self._where_params)
    
    def reset(self) -> 'QueryBuilder':
        """Reset builder state."""
        self._operation = "SELECT"
        self._table = ""
        self._columns = []
        self._values = {}
        self._where_conditions = []
        self._where_params = []
        self._order_by = []
        self._group_by = []
        self._having = None
        self._limit = None
        self._offset = None
        self._joins = []
        return self


class QueryExecutor(BaseTool):
    """
    Safe SQL query executor with validation.
    
    Features:
    - Query analysis and risk assessment
    - Parameterized query building
    - SQL injection prevention
    - Query validation
    - Execution with safety checks
    - Query history
    """
    
    # Patterns for SQL injection detection
    INJECTION_PATTERNS = [
        r";\s*--",
        r"'\s*OR\s+'?1'?\s*=\s*'?1",
        r"'\s*OR\s+''='",
        r"UNION\s+SELECT",
        r"INTO\s+OUTFILE",
        r"INTO\s+DUMPFILE",
        r"LOAD_FILE",
        r"BENCHMARK\s*\(",
        r"SLEEP\s*\(",
        r"WAITFOR\s+DELAY",
    ]
    
    def __init__(self):
        super().__init__(
            name="query_executor",
            description="Safe SQL query execution with validation",
            category=ToolCategory.DATABASE,
            risk=ToolRisk.MEDIUM,
            requires_confirmation=False,
            timeout=120.0,
            version="1.0.0"
        )
        
        self._injection_patterns = [
            re.compile(p, re.IGNORECASE) for p in self.INJECTION_PATTERNS
        ]
        self._query_history: List[Dict[str, Any]] = []
        self._max_history = 100
    
    def _detect_query_type(self, sql: str) -> QueryType:
        """Detect the type of SQL query."""
        sql_upper = sql.strip().upper()
        
        if sql_upper.startswith('SELECT'):
            return QueryType.SELECT
        elif sql_upper.startswith('INSERT'):
            return QueryType.INSERT
        elif sql_upper.startswith('UPDATE'):
            return QueryType.UPDATE
        elif sql_upper.startswith('DELETE'):
            return QueryType.DELETE
        elif sql_upper.startswith('CREATE'):
            return QueryType.CREATE
        elif sql_upper.startswith('ALTER'):
            return QueryType.ALTER
        elif sql_upper.startswith('DROP'):
            return QueryType.DROP
        else:
            return QueryType.OTHER
    
    def _assess_risk(self, sql: str, query_type: QueryType) -> RiskLevel:
        """Assess the risk level of a query."""
        sql_upper = sql.upper()
        
        if query_type == QueryType.SELECT:
            return RiskLevel.SAFE
        elif query_type == QueryType.INSERT:
            return RiskLevel.LOW
        elif query_type == QueryType.UPDATE:
            if 'WHERE' in sql_upper:
                return RiskLevel.MEDIUM
            else:
                return RiskLevel.HIGH
        elif query_type == QueryType.DELETE:
            if 'WHERE' in sql_upper:
                return RiskLevel.HIGH
            else:
                return RiskLevel.CRITICAL
        elif query_type in [QueryType.DROP, QueryType.ALTER]:
            return RiskLevel.CRITICAL
        else:
            return RiskLevel.MEDIUM
    
    def _extract_tables(self, sql: str) -> List[str]:
        """Extract table names from SQL."""
        tables = []
        sql_upper = sql.upper()
        
        # FROM clause
        from_match = re.search(r'FROM\s+([a-zA-Z_][a-zA-Z0-9_]*)', sql, re.IGNORECASE)
        if from_match:
            tables.append(from_match.group(1))
        
        # JOIN clauses
        join_matches = re.findall(r'JOIN\s+([a-zA-Z_][a-zA-Z0-9_]*)', sql, re.IGNORECASE)
        tables.extend(join_matches)
        
        # INSERT INTO
        insert_match = re.search(r'INSERT\s+INTO\s+([a-zA-Z_][a-zA-Z0-9_]*)', sql, re.IGNORECASE)
        if insert_match:
            tables.append(insert_match.group(1))
        
        # UPDATE
        update_match = re.search(r'UPDATE\s+([a-zA-Z_][a-zA-Z0-9_]*)', sql, re.IGNORECASE)
        if update_match:
            tables.append(update_match.group(1))
        
        # DELETE FROM
        delete_match = re.search(r'DELETE\s+FROM\s+([a-zA-Z_][a-zA-Z0-9_]*)', sql, re.IGNORECASE)
        if delete_match:
            tables.append(delete_match.group(1))
        
        return list(set(tables))
    
    def _check_injection(self, sql: str) -> List[str]:
        """Check for SQL injection patterns."""
        issues = []
        
        for pattern in self._injection_patterns:
            if pattern.search(sql):
                issues.append(f"Potential SQL injection detected: {pattern.pattern}")
        
        return issues
    
    async def analyze(self, sql: str) -> QueryAnalysis:
        """
        Analyze a SQL query.
        
        Args:
            sql: SQL query to analyze
            
        Returns:
            QueryAnalysis with details
        """
        sql_upper = sql.upper()
        
        query_type = self._detect_query_type(sql)
        risk_level = self._assess_risk(sql, query_type)
        tables = self._extract_tables(sql)
        
        has_where = 'WHERE' in sql_upper
        has_limit = 'LIMIT' in sql_upper
        is_parameterized = '?' in sql or '%s' in sql
        
        issues = self._check_injection(sql)
        
        # Additional checks
        if query_type in [QueryType.UPDATE, QueryType.DELETE] and not has_where:
            issues.append(f"{query_type.value.upper()} without WHERE clause affects all rows")
        
        if query_type == QueryType.SELECT and not has_limit:
            issues.append("SELECT without LIMIT may return large result sets")
        
        return QueryAnalysis(
            query_type=query_type,
            risk_level=risk_level,
            tables_affected=tables,
            has_where_clause=has_where,
            has_limit=has_limit,
            is_parameterized=is_parameterized,
            potential_issues=issues
        )
    
    async def validate(
        self,
        sql: str,
        max_risk: RiskLevel = RiskLevel.HIGH,
        require_where: bool = True,
        allow_multiple_statements: bool = False
    ) -> Tuple[bool, List[str]]:
        """
        Validate a SQL query.
        
        Args:
            sql: SQL query
            max_risk: Maximum allowed risk level
            require_where: Require WHERE for UPDATE/DELETE
            allow_multiple_statements: Allow semicolon-separated statements
            
        Returns:
            Tuple of (is_valid, list of issues)
        """
        issues = []
        
        # Check for multiple statements
        if not allow_multiple_statements and ';' in sql.strip()[:-1]:
            issues.append("Multiple statements not allowed")
        
        # Analyze query
        analysis = await self.analyze(sql)
        
        # Check risk level
        risk_order = [RiskLevel.SAFE, RiskLevel.LOW, RiskLevel.MEDIUM, RiskLevel.HIGH, RiskLevel.CRITICAL]
        if risk_order.index(analysis.risk_level) > risk_order.index(max_risk):
            issues.append(f"Query risk level {analysis.risk_level.value} exceeds maximum {max_risk.value}")
        
        # Check WHERE requirement
        if require_where and analysis.query_type in [QueryType.UPDATE, QueryType.DELETE]:
            if not analysis.has_where_clause:
                issues.append(f"{analysis.query_type.value.upper()} requires WHERE clause")
        
        # Add analysis issues
        issues.extend(analysis.potential_issues)
        
        return len(issues) == 0, issues
    
    async def execute(
        self,
        db_path: str,
        sql: str,
        params: Optional[Tuple] = None,
        validate: bool = True,
        max_risk: RiskLevel = RiskLevel.HIGH
    ) -> QueryResult:
        """
        Execute a validated SQL query.
        
        Args:
            db_path: Path to database
            sql: SQL query
            params: Query parameters
            validate: Validate before execution
            max_risk: Maximum risk level
            
        Returns:
            QueryResult
        """
        start_time = datetime.now()
        
        # Validate if requested
        if validate:
            is_valid, issues = await self.validate(sql, max_risk=max_risk)
            if not is_valid:
                return QueryResult(
                    success=False,
                    error=f"Validation failed: {'; '.join(issues)}"
                )
        
        # Execute query
        result = await sqlite_tools.execute(
            db_path, sql, params,
            check_dangerous=True
        )
        
        # Record in history
        self._add_to_history(sql, params, result)
        
        return result
    
    async def execute_builder(
        self,
        db_path: str,
        builder: QueryBuilder,
        validate: bool = True
    ) -> QueryResult:
        """
        Execute query from builder.
        
        Args:
            db_path: Path to database
            builder: QueryBuilder instance
            validate: Validate before execution
            
        Returns:
            QueryResult
        """
        sql, params = builder.build()
        return await self.execute(db_path, sql, params, validate=validate)
    
    def _add_to_history(
        self,
        sql: str,
        params: Optional[Tuple],
        result: QueryResult
    ) -> None:
        """Add query to history."""
        self._query_history.append({
            'sql': sql,
            'params': params,
            'success': result.success,
            'rows_affected': result.rows_affected,
            'execution_time_ms': result.execution_time_ms,
            'timestamp': datetime.now().isoformat()
        })
        
        # Trim history
        if len(self._query_history) > self._max_history:
            self._query_history = self._query_history[-self._max_history:]
    
    def get_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get query history."""
        return self._query_history[-limit:]
    
    def clear_history(self) -> None:
        """Clear query history."""
        self._query_history.clear()
    
    def create_builder(self) -> QueryBuilder:
        """Create a new query builder."""
        return QueryBuilder()
    
    async def run(self, context: ToolContext, **kwargs) -> ToolResult:
        """
        Execute query executor operation.
        
        Supported operations:
        - analyze: Analyze query
        - validate: Validate query
        - execute: Execute query
        - build: Build and optionally execute query
        - history: Get query history
        """
        operation = kwargs.get('operation', 'execute')
        
        try:
            if operation == 'analyze':
                sql = kwargs.get('sql') or kwargs.get('query')
                if not sql:
                    return ToolResult.fail(error="sql is required")
                
                analysis = await self.analyze(sql)
                return ToolResult.ok(data=analysis.to_dict())
            
            elif operation == 'validate':
                sql = kwargs.get('sql') or kwargs.get('query')
                if not sql:
                    return ToolResult.fail(error="sql is required")
                
                max_risk_str = kwargs.get('max_risk', 'high')
                try:
                    max_risk = RiskLevel(max_risk_str)
                except ValueError:
                    max_risk = RiskLevel.HIGH
                
                is_valid, issues = await self.validate(
                    sql,
                    max_risk=max_risk,
                    require_where=kwargs.get('require_where', True)
                )
                
                return ToolResult.ok(
                    data={'valid': is_valid, 'issues': issues},
                    message="Query is valid" if is_valid else "Query has issues"
                )
            
            elif operation == 'execute':
                db_path = kwargs.get('db_path') or kwargs.get('database')
                sql = kwargs.get('sql') or kwargs.get('query')
                
                if not db_path or not sql:
                    return ToolResult.fail(error="db_path and sql are required")
                
                max_risk_str = kwargs.get('max_risk', 'high')
                try:
                    max_risk = RiskLevel(max_risk_str)
                except ValueError:
                    max_risk = RiskLevel.HIGH
                
                result = await self.execute(
                    db_path, sql,
                    params=kwargs.get('params'),
                    validate=kwargs.get('validate', True),
                    max_risk=max_risk
                )
                
                if result.success:
                    return ToolResult.ok(
                        data=result.to_dict(),
                        message=f"Query executed: {result.row_count} rows"
                    )
                else:
                    return ToolResult.fail(error=result.error)
            
            elif operation == 'build':
                # Build query from specification
                spec = kwargs.get('spec', {})
                
                builder = self.create_builder()
                
                # Select
                if 'select' in spec:
                    columns = spec['select']
                    if isinstance(columns, str):
                        columns = [columns]
                    builder.select(*columns)
                
                # From
                if 'from' in spec:
                    builder.from_table(spec['from'])
                
                # Insert
                if 'insert_into' in spec:
                    builder.insert_into(spec['insert_into'])
                    if 'values' in spec:
                        builder.values(**spec['values'])
                
                # Update
                if 'update' in spec:
                    builder.update(spec['update'])
                    if 'set' in spec:
                        builder.set(**spec['set'])
                
                # Delete
                if 'delete_from' in spec:
                    builder.delete_from(spec['delete_from'])
                
                # Where
                if 'where' in spec:
                    for cond in spec['where']:
                        if isinstance(cond, dict):
                            for col, val in cond.items():
                                builder.where_eq(col, val)
                        else:
                            builder.where(cond)
                
                # Order by
                if 'order_by' in spec:
                    order = spec['order_by']
                    if isinstance(order, str):
                        builder.order_by(order)
                    elif isinstance(order, dict):
                        builder.order_by(order.get('column'), desc=order.get('desc', False))
                
                # Limit
                if 'limit' in spec:
                    builder.limit(spec['limit'])
                
                # Offset
                if 'offset' in spec:
                    builder.offset(spec['offset'])
                
                sql, params = builder.build()
                
                # Execute if db_path provided
                db_path = kwargs.get('db_path')
                if db_path:
                    result = await self.execute(db_path, sql, params)
                    
                    return ToolResult.ok(
                        data={
                            'sql': sql,
                            'params': params,
                            'result': result.to_dict()
                        }
                    )
                else:
                    return ToolResult.ok(
                        data={'sql': sql, 'params': params}
                    )
            
            elif operation == 'history':
                limit = kwargs.get('limit', 50)
                history = self.get_history(limit)
                
                return ToolResult.ok(
                    data={'history': history, 'count': len(history)}
                )
            
            else:
                return ToolResult.fail(error=f"Unknown operation: {operation}")
            
        except Exception as e:
            logger.error(f"QueryExecutor error: {e}")
            return ToolResult.error(error=str(e))


# Create singleton
query_executor = QueryExecutor()


def register():
    """Register query executor."""
    registry = get_registry()
    registry.register_tool(query_executor)