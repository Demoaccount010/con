"""
SQLite Tools - SQLite database operations.
Create, query, and manage SQLite databases.
"""

import asyncio
import aiosqlite
from pathlib import Path
from typing import Optional, Dict, Any, List, Union, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from contextlib import asynccontextmanager
import logging
import re

import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from tools.base_tool import (
    BaseTool, ToolResult, ToolContext, ResultStatus,
    ToolCategory, ToolRisk
)
from tools.registry import get_registry

logger = logging.getLogger(__name__)


@dataclass
class QueryResult:
    """Result of a database query."""
    success: bool
    rows: List[Dict[str, Any]] = field(default_factory=list)
    row_count: int = 0
    columns: List[str] = field(default_factory=list)
    last_row_id: Optional[int] = None
    rows_affected: int = 0
    execution_time_ms: float = 0
    error: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'success': self.success,
            'rows': self.rows,
            'row_count': self.row_count,
            'columns': self.columns,
            'last_row_id': self.last_row_id,
            'rows_affected': self.rows_affected,
            'execution_time_ms': self.execution_time_ms,
            'error': self.error
        }


@dataclass
class TableInfo:
    """Information about a database table."""
    name: str
    columns: List[Dict[str, Any]]
    row_count: int
    indexes: List[str]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'columns': self.columns,
            'row_count': self.row_count,
            'indexes': self.indexes
        }


@dataclass
class DatabaseInfo:
    """Information about a database."""
    path: str
    size_bytes: int
    tables: List[str]
    table_count: int
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'path': self.path,
            'size_bytes': self.size_bytes,
            'size_human': self._human_size(self.size_bytes),
            'tables': self.tables,
            'table_count': self.table_count
        }
    
    @staticmethod
    def _human_size(size: int) -> str:
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024:
                return f"{size:.1f} {unit}"
            size /= 1024
        return f"{size:.1f} TB"


class SqliteTools(BaseTool):
    """
    SQLite database tool.
    
    Features:
    - Execute SQL queries
    - Create and manage tables
    - CRUD operations
    - Transactions
    - Database info and schema
    - Data export/import
    - Query building helpers
    """
    
    # Dangerous SQL patterns to block
    BLOCKED_PATTERNS = [
        r';\s*DROP\s+',
        r';\s*DELETE\s+FROM\s+\w+\s*;?\s*$',  # DELETE without WHERE
        r';\s*TRUNCATE\s+',
        r';\s*ALTER\s+TABLE\s+\w+\s+DROP\s+',
    ]
    
    def __init__(self):
        super().__init__(
            name="sqlite_tools",
            description="SQLite database operations",
            category=ToolCategory.DATABASE,
            risk=ToolRisk.MEDIUM,
            requires_confirmation=False,
            timeout=120.0,
            version="1.0.0"
        )
        
        self._connections: Dict[str, aiosqlite.Connection] = {}
        self._compiled_patterns = [re.compile(p, re.IGNORECASE) for p in self.BLOCKED_PATTERNS]
    
    def _is_dangerous_query(self, sql: str) -> Tuple[bool, str]:
        """Check if query is potentially dangerous."""
        for pattern in self._compiled_patterns:
            if pattern.search(sql):
                return True, f"Blocked dangerous pattern in query"
        return False, ""
    
    @asynccontextmanager
    async def get_connection(self, db_path: str):
        """Get or create database connection."""
        db_path = str(Path(db_path).resolve())
        
        if db_path not in self._connections:
            self._connections[db_path] = await aiosqlite.connect(db_path)
            self._connections[db_path].row_factory = aiosqlite.Row
        
        try:
            yield self._connections[db_path]
        except Exception:
            # On error, close and remove connection
            if db_path in self._connections:
                try:
                    await self._connections[db_path].close()
                except:
                    pass
                del self._connections[db_path]
            raise
    
    async def close_connection(self, db_path: str) -> bool:
        """Close a database connection."""
        db_path = str(Path(db_path).resolve())
        
        if db_path in self._connections:
            try:
                await self._connections[db_path].close()
                del self._connections[db_path]
                return True
            except Exception as e:
                logger.error(f"Error closing connection: {e}")
        return False
    
    async def close_all(self) -> None:
        """Close all connections."""
        for path, conn in list(self._connections.items()):
            try:
                await conn.close()
            except:
                pass
        self._connections.clear()
    
    async def execute(
        self,
        db_path: str,
        sql: str,
        params: Optional[Union[Tuple, Dict]] = None,
        fetch: bool = True,
        commit: bool = True,
        check_dangerous: bool = True
    ) -> QueryResult:
        """
        Execute SQL query.
        
        Args:
            db_path: Path to database
            sql: SQL query
            params: Query parameters
            fetch: Fetch results
            commit: Commit transaction
            check_dangerous: Check for dangerous queries
            
        Returns:
            QueryResult with data
        """
        start_time = datetime.now()
        
        # Security check
        if check_dangerous:
            is_dangerous, reason = self._is_dangerous_query(sql)
            if is_dangerous:
                return QueryResult(
                    success=False,
                    error=reason
                )
        
        try:
            async with self.get_connection(db_path) as conn:
                cursor = await conn.execute(sql, params or ())
                
                rows = []
                columns = []
                
                if fetch and cursor.description:
                    columns = [col[0] for col in cursor.description]
                    raw_rows = await cursor.fetchall()
                    rows = [dict(row) for row in raw_rows]
                
                if commit:
                    await conn.commit()
                
                elapsed = (datetime.now() - start_time).total_seconds() * 1000
                
                return QueryResult(
                    success=True,
                    rows=rows,
                    row_count=len(rows),
                    columns=columns,
                    last_row_id=cursor.lastrowid,
                    rows_affected=cursor.rowcount,
                    execution_time_ms=elapsed
                )
                
        except Exception as e:
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            logger.error(f"Query error: {e}")
            return QueryResult(
                success=False,
                error=str(e),
                execution_time_ms=elapsed
            )
    
    async def execute_many(
        self,
        db_path: str,
        sql: str,
        params_list: List[Union[Tuple, Dict]],
        commit: bool = True
    ) -> QueryResult:
        """
        Execute SQL with multiple parameter sets.
        
        Args:
            db_path: Path to database
            sql: SQL query
            params_list: List of parameter sets
            commit: Commit transaction
            
        Returns:
            QueryResult with affected row count
        """
        start_time = datetime.now()
        
        try:
            async with self.get_connection(db_path) as conn:
                await conn.executemany(sql, params_list)
                
                if commit:
                    await conn.commit()
                
                elapsed = (datetime.now() - start_time).total_seconds() * 1000
                
                return QueryResult(
                    success=True,
                    rows_affected=len(params_list),
                    execution_time_ms=elapsed
                )
                
        except Exception as e:
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            return QueryResult(
                success=False,
                error=str(e),
                execution_time_ms=elapsed
            )
    
    async def execute_script(
        self,
        db_path: str,
        script: str
    ) -> QueryResult:
        """
        Execute SQL script (multiple statements).
        
        Args:
            db_path: Path to database
            script: SQL script
            
        Returns:
            QueryResult
        """
        start_time = datetime.now()
        
        try:
            async with self.get_connection(db_path) as conn:
                await conn.executescript(script)
                await conn.commit()
                
                elapsed = (datetime.now() - start_time).total_seconds() * 1000
                
                return QueryResult(
                    success=True,
                    execution_time_ms=elapsed
                )
                
        except Exception as e:
            elapsed = (datetime.now() - start_time).total_seconds() * 1000
            return QueryResult(
                success=False,
                error=str(e),
                execution_time_ms=elapsed
            )
    
    async def get_tables(self, db_path: str) -> List[str]:
        """Get list of tables in database."""
        result = await self.execute(
            db_path,
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name",
            fetch=True,
            commit=False
        )
        
        if result.success:
            return [row['name'] for row in result.rows]
        return []
    
    async def get_table_info(self, db_path: str, table: str) -> Optional[TableInfo]:
        """Get information about a table."""
        # Get columns
        result = await self.execute(
            db_path,
            f"PRAGMA table_info({table})",
            fetch=True,
            commit=False
        )
        
        if not result.success:
            return None
        
        columns = [
            {
                'name': row['name'],
                'type': row['type'],
                'notnull': bool(row['notnull']),
                'default': row['dflt_value'],
                'pk': bool(row['pk'])
            }
            for row in result.rows
        ]
        
        # Get row count
        count_result = await self.execute(
            db_path,
            f"SELECT COUNT(*) as count FROM {table}",
            fetch=True,
            commit=False
        )
        row_count = count_result.rows[0]['count'] if count_result.success else 0
        
        # Get indexes
        index_result = await self.execute(
            db_path,
            f"PRAGMA index_list({table})",
            fetch=True,
            commit=False
        )
        indexes = [row['name'] for row in index_result.rows] if index_result.success else []
        
        return TableInfo(
            name=table,
            columns=columns,
            row_count=row_count,
            indexes=indexes
        )
    
    async def get_database_info(self, db_path: str) -> DatabaseInfo:
        """Get database information."""
        path = Path(db_path).resolve()
        size = path.stat().st_size if path.exists() else 0
        tables = await self.get_tables(db_path)
        
        return DatabaseInfo(
            path=str(path),
            size_bytes=size,
            tables=tables,
            table_count=len(tables)
        )
    
    async def create_table(
        self,
        db_path: str,
        table: str,
        columns: Dict[str, str],
        primary_key: Optional[str] = None,
        if_not_exists: bool = True
    ) -> QueryResult:
        """
        Create a table.
        
        Args:
            db_path: Path to database
            table: Table name
            columns: {column_name: type}
            primary_key: Primary key column
            if_not_exists: Add IF NOT EXISTS clause
            
        Returns:
            QueryResult
        """
        col_defs = []
        for col_name, col_type in columns.items():
            definition = f"{col_name} {col_type}"
            if col_name == primary_key:
                definition += " PRIMARY KEY"
            col_defs.append(definition)
        
        exists_clause = "IF NOT EXISTS " if if_not_exists else ""
        sql = f"CREATE TABLE {exists_clause}{table} ({', '.join(col_defs)})"
        
        return await self.execute(db_path, sql)
    
    async def drop_table(
        self,
        db_path: str,
        table: str,
        if_exists: bool = True
    ) -> QueryResult:
        """Drop a table."""
        exists_clause = "IF EXISTS " if if_exists else ""
        sql = f"DROP TABLE {exists_clause}{table}"
        
        return await self.execute(db_path, sql, check_dangerous=False)
    
    async def insert(
        self,
        db_path: str,
        table: str,
        data: Union[Dict[str, Any], List[Dict[str, Any]]],
        or_replace: bool = False
    ) -> QueryResult:
        """
        Insert data into table.
        
        Args:
            db_path: Path to database
            table: Table name
            data: Row or rows to insert
            or_replace: Use INSERT OR REPLACE
            
        Returns:
            QueryResult
        """
        if isinstance(data, dict):
            data = [data]
        
        if not data:
            return QueryResult(success=True, rows_affected=0)
        
        columns = list(data[0].keys())
        placeholders = ', '.join(['?' for _ in columns])
        col_names = ', '.join(columns)
        
        action = "INSERT OR REPLACE" if or_replace else "INSERT"
        sql = f"{action} INTO {table} ({col_names}) VALUES ({placeholders})"
        
        params_list = [tuple(row.get(col) for col in columns) for row in data]
        
        if len(params_list) == 1:
            return await self.execute(db_path, sql, params_list[0])
        else:
            return await self.execute_many(db_path, sql, params_list)
    
    async def select(
        self,
        db_path: str,
        table: str,
        columns: Optional[List[str]] = None,
        where: Optional[str] = None,
        params: Optional[Tuple] = None,
        order_by: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None
    ) -> QueryResult:
        """
        Select data from table.
        
        Args:
            db_path: Path to database
            table: Table name
            columns: Columns to select
            where: WHERE clause
            params: Query parameters
            order_by: ORDER BY clause
            limit: LIMIT value
            offset: OFFSET value
            
        Returns:
            QueryResult with rows
        """
        col_str = ', '.join(columns) if columns else '*'
        sql = f"SELECT {col_str} FROM {table}"
        
        if where:
            sql += f" WHERE {where}"
        if order_by:
            sql += f" ORDER BY {order_by}"
        if limit:
            sql += f" LIMIT {limit}"
        if offset:
            sql += f" OFFSET {offset}"
        
        return await self.execute(db_path, sql, params)
    
    async def update(
        self,
        db_path: str,
        table: str,
        data: Dict[str, Any],
        where: str,
        params: Optional[Tuple] = None
    ) -> QueryResult:
        """
        Update rows in table.
        
        Args:
            db_path: Path to database
            table: Table name
            data: {column: new_value}
            where: WHERE clause (required)
            params: Additional parameters for WHERE
            
        Returns:
            QueryResult
        """
        if not where:
            return QueryResult(
                success=False,
                error="WHERE clause is required for UPDATE"
            )
        
        set_parts = [f"{col} = ?" for col in data.keys()]
        values = list(data.values())
        
        if params:
            values.extend(params)
        
        sql = f"UPDATE {table} SET {', '.join(set_parts)} WHERE {where}"
        
        return await self.execute(db_path, sql, tuple(values))
    
    async def delete(
        self,
        db_path: str,
        table: str,
        where: str,
        params: Optional[Tuple] = None
    ) -> QueryResult:
        """
        Delete rows from table.
        
        Args:
            db_path: Path to database
            table: Table name
            where: WHERE clause (required)
            params: Query parameters
            
        Returns:
            QueryResult
        """
        if not where:
            return QueryResult(
                success=False,
                error="WHERE clause is required for DELETE"
            )
        
        sql = f"DELETE FROM {table} WHERE {where}"
        
        return await self.execute(db_path, sql, params, check_dangerous=False)
    
    async def count(
        self,
        db_path: str,
        table: str,
        where: Optional[str] = None,
        params: Optional[Tuple] = None
    ) -> int:
        """Count rows in table."""
        sql = f"SELECT COUNT(*) as count FROM {table}"
        if where:
            sql += f" WHERE {where}"
        
        result = await self.execute(db_path, sql, params)
        
        if result.success and result.rows:
            return result.rows[0]['count']
        return 0
    
    async def run(self, context: ToolContext, **kwargs) -> ToolResult:
        """
        Execute SQLite operation.
        
        Supported operations:
        - execute: Execute SQL query
        - execute_many: Execute with multiple params
        - execute_script: Execute SQL script
        - tables: List tables
        - table_info: Get table info
        - db_info: Get database info
        - create_table: Create table
        - drop_table: Drop table
        - insert: Insert data
        - select: Select data
        - update: Update data
        - delete: Delete data
        - count: Count rows
        """
        operation = kwargs.get('operation', 'execute')
        db_path = kwargs.get('db_path') or kwargs.get('database') or kwargs.get('db')
        
        if not db_path:
            return ToolResult.fail(error="db_path is required")
        
        try:
            if operation == 'execute':
                sql = kwargs.get('sql') or kwargs.get('query')
                if not sql:
                    return ToolResult.fail(error="sql is required")
                
                result = await self.execute(
                    db_path, sql,
                    params=kwargs.get('params'),
                    fetch=kwargs.get('fetch', True),
                    commit=kwargs.get('commit', True)
                )
                
                if result.success:
                    return ToolResult.ok(
                        data=result.to_dict(),
                        message=f"Query returned {result.row_count} rows"
                    )
                else:
                    return ToolResult.fail(error=result.error)
            
            elif operation == 'execute_many':
                sql = kwargs.get('sql')
                params_list = kwargs.get('params_list', [])
                
                if not sql:
                    return ToolResult.fail(error="sql is required")
                
                result = await self.execute_many(db_path, sql, params_list)
                
                if result.success:
                    return ToolResult.ok(
                        data=result.to_dict(),
                        message=f"Affected {result.rows_affected} rows"
                    )
                else:
                    return ToolResult.fail(error=result.error)
            
            elif operation == 'execute_script':
                script = kwargs.get('script')
                if not script:
                    return ToolResult.fail(error="script is required")
                
                result = await self.execute_script(db_path, script)
                
                if result.success:
                    return ToolResult.ok(message="Script executed successfully")
                else:
                    return ToolResult.fail(error=result.error)
            
            elif operation == 'tables':
                tables = await self.get_tables(db_path)
                return ToolResult.ok(
                    data={'tables': tables, 'count': len(tables)}
                )
            
            elif operation == 'table_info':
                table = kwargs.get('table')
                if not table:
                    return ToolResult.fail(error="table is required")
                
                info = await self.get_table_info(db_path, table)
                
                if info:
                    return ToolResult.ok(data=info.to_dict())
                else:
                    return ToolResult.fail(error=f"Table not found: {table}")
            
            elif operation == 'db_info':
                info = await self.get_database_info(db_path)
                return ToolResult.ok(data=info.to_dict())
            
            elif operation == 'create_table':
                table = kwargs.get('table')
                columns = kwargs.get('columns')
                
                if not table or not columns:
                    return ToolResult.fail(error="table and columns are required")
                
                result = await self.create_table(
                    db_path, table, columns,
                    primary_key=kwargs.get('primary_key'),
                    if_not_exists=kwargs.get('if_not_exists', True)
                )
                
                if result.success:
                    return ToolResult.ok(message=f"Table {table} created")
                else:
                    return ToolResult.fail(error=result.error)
            
            elif operation == 'drop_table':
                table = kwargs.get('table')
                if not table:
                    return ToolResult.fail(error="table is required")
                
                result = await self.drop_table(
                    db_path, table,
                    if_exists=kwargs.get('if_exists', True)
                )
                
                if result.success:
                    return ToolResult.ok(message=f"Table {table} dropped")
                else:
                    return ToolResult.fail(error=result.error)
            
            elif operation == 'insert':
                table = kwargs.get('table')
                data = kwargs.get('data')
                
                if not table or not data:
                    return ToolResult.fail(error="table and data are required")
                
                result = await self.insert(
                    db_path, table, data,
                    or_replace=kwargs.get('or_replace', False)
                )
                
                if result.success:
                    return ToolResult.ok(
                        data=result.to_dict(),
                        message=f"Inserted {result.rows_affected} rows"
                    )
                else:
                    return ToolResult.fail(error=result.error)
            
            elif operation == 'select':
                table = kwargs.get('table')
                if not table:
                    return ToolResult.fail(error="table is required")
                
                result = await self.select(
                    db_path, table,
                    columns=kwargs.get('columns'),
                    where=kwargs.get('where'),
                    params=kwargs.get('params'),
                    order_by=kwargs.get('order_by'),
                    limit=kwargs.get('limit'),
                    offset=kwargs.get('offset')
                )
                
                if result.success:
                    return ToolResult.ok(data=result.to_dict())
                else:
                    return ToolResult.fail(error=result.error)
            
            elif operation == 'update':
                table = kwargs.get('table')
                data = kwargs.get('data')
                where = kwargs.get('where')
                
                if not table or not data or not where:
                    return ToolResult.fail(
                        error="table, data, and where are required"
                    )
                
                result = await self.update(
                    db_path, table, data, where,
                    params=kwargs.get('params')
                )
                
                if result.success:
                    return ToolResult.ok(
                        data=result.to_dict(),
                        message=f"Updated {result.rows_affected} rows"
                    )
                else:
                    return ToolResult.fail(error=result.error)
            
            elif operation == 'delete':
                table = kwargs.get('table')
                where = kwargs.get('where')
                
                if not table or not where:
                    return ToolResult.fail(error="table and where are required")
                
                result = await self.delete(
                    db_path, table, where,
                    params=kwargs.get('params')
                )
                
                if result.success:
                    return ToolResult.ok(
                        data=result.to_dict(),
                        message=f"Deleted {result.rows_affected} rows"
                    )
                else:
                    return ToolResult.fail(error=result.error)
            
            elif operation == 'count':
                table = kwargs.get('table')
                if not table:
                    return ToolResult.fail(error="table is required")
                
                count = await self.count(
                    db_path, table,
                    where=kwargs.get('where'),
                    params=kwargs.get('params')
                )
                
                return ToolResult.ok(data={'count': count})
            
            else:
                return ToolResult.fail(error=f"Unknown operation: {operation}")
            
        except Exception as e:
            logger.error(f"SqliteTools error: {e}")
            return ToolResult.error(error=str(e))
    
    async def cleanup(self) -> None:
        """Close all connections."""
        await self.close_all()


# Create singleton
sqlite_tools = SqliteTools()


def register():
    """Register SQLite tools."""
    registry = get_registry()
    registry.register_tool(sqlite_tools)