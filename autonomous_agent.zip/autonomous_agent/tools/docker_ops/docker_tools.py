"""
Docker Tools - Docker container and image management.
Manage containers, images, volumes, and networks.
"""

import asyncio
import json
from pathlib import Path
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import logging

import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from tools.base_tool import (
    BaseTool, ToolResult, ToolContext, ResultStatus,
    ToolCategory, ToolRisk
)
from tools.registry import get_registry
from tools.system_ops.shell_executor import shell_executor

logger = logging.getLogger(__name__)


class ContainerState(Enum):
    """Container states."""
    RUNNING = "running"
    EXITED = "exited"
    PAUSED = "paused"
    RESTARTING = "restarting"
    DEAD = "dead"
    CREATED = "created"
    REMOVING = "removing"


@dataclass
class Container:
    """Docker container information."""
    id: str
    name: str
    image: str
    state: ContainerState
    status: str
    ports: Dict[str, Any]
    created: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'short_id': self.id[:12] if self.id else '',
            'name': self.name,
            'image': self.image,
            'state': self.state.value,
            'status': self.status,
            'ports': self.ports,
            'created': self.created
        }


@dataclass
class Image:
    """Docker image information."""
    id: str
    tags: List[str]
    size: int
    created: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'short_id': self.id[:12] if self.id else '',
            'tags': self.tags,
            'size': self.size,
            'size_human': self._human_size(self.size),
            'created': self.created
        }
    
    @staticmethod
    def _human_size(size: int) -> str:
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024:
                return f"{size:.1f} {unit}"
            size /= 1024
        return f"{size:.1f} TB"


@dataclass
class Volume:
    """Docker volume information."""
    name: str
    driver: str
    mountpoint: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'driver': self.driver,
            'mountpoint': self.mountpoint
        }


@dataclass
class Network:
    """Docker network information."""
    id: str
    name: str
    driver: str
    scope: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'short_id': self.id[:12] if self.id else '',
            'name': self.name,
            'driver': self.driver,
            'scope': self.scope
        }


class DockerTools(BaseTool):
    """
    Docker management tool.
    
    Features:
    - List, start, stop, restart containers
    - Build, pull, push images
    - Manage volumes and networks
    - Execute commands in containers
    - View container logs
    - Docker Compose support
    - Container stats and inspection
    """
    
    def __init__(self):
        super().__init__(
            name="docker_tools",
            description="Docker container and image management",
            category=ToolCategory.DOCKER,
            risk=ToolRisk.HIGH,
            requires_confirmation=False,
            timeout=300.0,
            version="1.0.0"
        )
        
        self._docker_available = None
    
    async def _run_docker(
        self,
        command: str,
        timeout: float = 60.0
    ) -> Tuple[bool, str, str]:
        """Run docker command."""
        result = await shell_executor.execute_command(
            f"docker {command}",
            timeout=timeout
        )
        return result.success, result.stdout, result.stderr
    
    async def is_available(self) -> bool:
        """Check if Docker is available."""
        if self._docker_available is None:
            success, _, _ = await self._run_docker("version", timeout=10.0)
            self._docker_available = success
        return self._docker_available
    
    async def version(self) -> Dict[str, Any]:
        """Get Docker version info."""
        success, stdout, stderr = await self._run_docker("version --format json")
        
        if success:
            try:
                return {'success': True, 'data': json.loads(stdout)}
            except json.JSONDecodeError:
                return {'success': True, 'raw': stdout}
        return {'success': False, 'error': stderr}
    
    async def info(self) -> Dict[str, Any]:
        """Get Docker system info."""
        success, stdout, stderr = await self._run_docker("info --format json")
        
        if success:
            try:
                return {'success': True, 'data': json.loads(stdout)}
            except json.JSONDecodeError:
                return {'success': True, 'raw': stdout}
        return {'success': False, 'error': stderr}
    
    # =========================================================================
    # Container Operations
    # =========================================================================
    
    async def list_containers(
        self,
        all_containers: bool = False,
        filters: Optional[Dict[str, str]] = None
    ) -> List[Container]:
        """
        List Docker containers.
        
        Args:
            all_containers: Include stopped containers
            filters: Filter containers
            
        Returns:
            List of Container objects
        """
        cmd = 'ps --format "{{json .}}"'
        if all_containers:
            cmd = 'ps -a --format "{{json .}}"'
        
        if filters:
            for key, value in filters.items():
                cmd += f' --filter "{key}={value}"'
        
        success, stdout, _ = await self._run_docker(cmd)
        
        containers = []
        if success:
            for line in stdout.strip().split('\n'):
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    
                    state_str = data.get('State', 'unknown').lower()
                    try:
                        state = ContainerState(state_str)
                    except ValueError:
                        state = ContainerState.CREATED
                    
                    containers.append(Container(
                        id=data.get('ID', ''),
                        name=data.get('Names', ''),
                        image=data.get('Image', ''),
                        state=state,
                        status=data.get('Status', ''),
                        ports=data.get('Ports', {}),
                        created=data.get('CreatedAt', '')
                    ))
                except json.JSONDecodeError:
                    continue
        
        return containers
    
    async def run_container(
        self,
        image: str,
        name: Optional[str] = None,
        detach: bool = True,
        ports: Optional[Dict[str, int]] = None,
        volumes: Optional[Dict[str, str]] = None,
        env: Optional[Dict[str, str]] = None,
        command: Optional[str] = None,
        network: Optional[str] = None,
        restart: Optional[str] = None,
        remove: bool = False,
        workdir: Optional[str] = None,
        user: Optional[str] = None,
        memory: Optional[str] = None,
        cpus: Optional[float] = None
    ) -> Dict[str, Any]:
        """
        Run a Docker container.
        
        Args:
            image: Image to run
            name: Container name
            detach: Run in background
            ports: Port mappings {host: container}
            volumes: Volume mappings {host: container}
            env: Environment variables
            command: Command to run
            network: Network to connect
            restart: Restart policy (no, always, on-failure, unless-stopped)
            remove: Remove container when stopped
            workdir: Working directory
            user: User to run as
            memory: Memory limit (e.g., "512m")
            cpus: CPU limit
            
        Returns:
            Result dict
        """
        cmd = "run"
        
        if detach:
            cmd += " -d"
        if name:
            cmd += f" --name {name}"
        if remove:
            cmd += " --rm"
        if network:
            cmd += f" --network {network}"
        if restart:
            cmd += f" --restart {restart}"
        if workdir:
            cmd += f" -w {workdir}"
        if user:
            cmd += f" -u {user}"
        if memory:
            cmd += f" --memory {memory}"
        if cpus:
            cmd += f" --cpus {cpus}"
        
        if ports:
            for host_port, container_port in ports.items():
                cmd += f" -p {host_port}:{container_port}"
        
        if volumes:
            for host_path, container_path in volumes.items():
                cmd += f" -v {host_path}:{container_path}"
        
        if env:
            for key, value in env.items():
                cmd += f' -e "{key}={value}"'
        
        cmd += f" {image}"
        
        if command:
            cmd += f" {command}"
        
        success, stdout, stderr = await self._run_docker(cmd, timeout=120.0)
        
        container_id = stdout.strip()[:12] if success and stdout.strip() else None
        
        return {
            'success': success,
            'container_id': container_id,
            'image': image,
            'name': name,
            'message': stderr if not success else f"Container {container_id} started"
        }
    
    async def start(self, container: str) -> Dict[str, Any]:
        """Start a stopped container."""
        success, stdout, stderr = await self._run_docker(f"start {container}")
        
        return {
            'success': success,
            'container': container,
            'message': stdout.strip() if success else stderr
        }
    
    async def stop(
        self,
        container: str,
        timeout: int = 10
    ) -> Dict[str, Any]:
        """Stop a running container."""
        success, stdout, stderr = await self._run_docker(
            f"stop -t {timeout} {container}"
        )
        
        return {
            'success': success,
            'container': container,
            'message': stdout.strip() if success else stderr
        }
    
    async def restart(self, container: str) -> Dict[str, Any]:
        """Restart a container."""
        success, stdout, stderr = await self._run_docker(f"restart {container}")
        
        return {
            'success': success,
            'container': container,
            'message': stdout.strip() if success else stderr
        }
    
    async def pause(self, container: str) -> Dict[str, Any]:
        """Pause a container."""
        success, stdout, stderr = await self._run_docker(f"pause {container}")
        
        return {
            'success': success,
            'container': container,
            'message': stdout.strip() if success else stderr
        }
    
    async def unpause(self, container: str) -> Dict[str, Any]:
        """Unpause a container."""
        success, stdout, stderr = await self._run_docker(f"unpause {container}")
        
        return {
            'success': success,
            'container': container,
            'message': stdout.strip() if success else stderr
        }
    
    async def remove_container(
        self,
        container: str,
        force: bool = False,
        volumes: bool = False
    ) -> Dict[str, Any]:
        """Remove a container."""
        cmd = f"rm {container}"
        if force:
            cmd += " -f"
        if volumes:
            cmd += " -v"
        
        success, stdout, stderr = await self._run_docker(cmd)
        
        return {
            'success': success,
            'container': container,
            'message': stdout.strip() if success else stderr
        }
    
    async def logs(
        self,
        container: str,
        tail: Optional[int] = None,
        since: Optional[str] = None,
        until: Optional[str] = None,
        timestamps: bool = False
    ) -> str:
        """
        Get container logs.
        
        Args:
            container: Container name or ID
            tail: Number of lines from end
            since: Show logs since timestamp
            until: Show logs until timestamp
            timestamps: Show timestamps
            
        Returns:
            Log output
        """
        cmd = f"logs {container}"
        
        if tail:
            cmd += f" --tail {tail}"
        if since:
            cmd += f" --since {since}"
        if until:
            cmd += f" --until {until}"
        if timestamps:
            cmd += " --timestamps"
        
        success, stdout, stderr = await self._run_docker(cmd, timeout=30.0)
        
        return stdout if success else stderr
    
    async def exec_command(
        self,
        container: str,
        command: str,
        interactive: bool = False,
        tty: bool = False,
        user: Optional[str] = None,
        workdir: Optional[str] = None,
        env: Optional[Dict[str, str]] = None
    ) -> Dict[str, Any]:
        """
        Execute command in container.
        
        Args:
            container: Container name or ID
            command: Command to execute
            interactive: Keep STDIN open
            tty: Allocate pseudo-TTY
            user: User to run as
            workdir: Working directory
            env: Environment variables
            
        Returns:
            Result dict with output
        """
        cmd = f"exec"
        
        if interactive:
            cmd += " -i"
        if tty:
            cmd += " -t"
        if user:
            cmd += f" -u {user}"
        if workdir:
            cmd += f" -w {workdir}"
        if env:
            for key, value in env.items():
                cmd += f' -e "{key}={value}"'
        
        cmd += f" {container} {command}"
        
        success, stdout, stderr = await self._run_docker(cmd, timeout=60.0)
        
        return {
            'success': success,
            'output': stdout,
            'error': stderr if not success else None,
            'exit_code': 0 if success else 1
        }
    
    async def inspect(self, container: str) -> Dict[str, Any]:
        """Inspect a container."""
        success, stdout, stderr = await self._run_docker(f"inspect {container}")
        
        if success:
            try:
                data = json.loads(stdout)
                return {'success': True, 'data': data[0] if data else {}}
            except json.JSONDecodeError:
                return {'success': True, 'raw': stdout}
        return {'success': False, 'error': stderr}
    
    async def stats(
        self,
        container: Optional[str] = None,
        no_stream: bool = True
    ) -> Dict[str, Any]:
        """
        Get container resource usage statistics.
        
        Args:
            container: Specific container (None for all)
            no_stream: Don't stream, just get current stats
            
        Returns:
            Stats dict
        """
        cmd = 'stats --format "{{json .}}"'
        if no_stream:
            cmd += " --no-stream"
        if container:
            cmd += f" {container}"
        
        success, stdout, stderr = await self._run_docker(cmd, timeout=15.0)
        
        if success:
            stats = []
            for line in stdout.strip().split('\n'):
                if line:
                    try:
                        stats.append(json.loads(line))
                    except:
                        continue
            return {'success': True, 'stats': stats}
        return {'success': False, 'error': stderr}
    
    async def top(self, container: str) -> Dict[str, Any]:
        """Get running processes in container."""
        success, stdout, stderr = await self._run_docker(f"top {container}")
        
        return {
            'success': success,
            'output': stdout if success else None,
            'error': stderr if not success else None
        }
    
    async def copy_to(
        self,
        container: str,
        src: str,
        dest: str
    ) -> Dict[str, Any]:
        """Copy files to container."""
        success, stdout, stderr = await self._run_docker(
            f"cp {src} {container}:{dest}"
        )
        
        return {
            'success': success,
            'message': "Copied successfully" if success else stderr
        }
    
    async def copy_from(
        self,
        container: str,
        src: str,
        dest: str
    ) -> Dict[str, Any]:
        """Copy files from container."""
        success, stdout, stderr = await self._run_docker(
            f"cp {container}:{src} {dest}"
        )
        
        return {
            'success': success,
            'message': "Copied successfully" if success else stderr
        }
    
    # =========================================================================
    # Image Operations
    # =========================================================================
    
    async def list_images(
        self,
        all_images: bool = False
    ) -> List[Image]:
        """List Docker images."""
        cmd = 'images --format "{{json .}}"'
        if all_images:
            cmd += " -a"
        
        success, stdout, _ = await self._run_docker(cmd)
        
        images = []
        if success:
            for line in stdout.strip().split('\n'):
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    
                    tag = data.get('Tag', 'latest')
                    repo = data.get('Repository', '')
                    full_tag = f"{repo}:{tag}" if repo != '<none>' else None
                    
                    size_str = data.get('Size', '0')
                    size = self._parse_size(size_str)
                    
                    images.append(Image(
                        id=data.get('ID', ''),
                        tags=[full_tag] if full_tag else [],
                        size=size,
                        created=data.get('CreatedAt', '')
                    ))
                except json.JSONDecodeError:
                    continue
        
        return images
    
    def _parse_size(self, size_str: str) -> int:
        """Parse size string to bytes."""
        try:
            size_str = size_str.upper().strip()
            if 'GB' in size_str:
                return int(float(size_str.replace('GB', '').strip()) * 1024 * 1024 * 1024)
            elif 'MB' in size_str:
                return int(float(size_str.replace('MB', '').strip()) * 1024 * 1024)
            elif 'KB' in size_str:
                return int(float(size_str.replace('KB', '').strip()) * 1024)
            else:
                return int(float(size_str.replace('B', '').strip()))
        except (ValueError, AttributeError):
            return 0
    
    async def pull(
        self,
        image: str,
        tag: Optional[str] = None
    ) -> Dict[str, Any]:
        """Pull an image from registry."""
        full_image = f"{image}:{tag}" if tag else image
        success, stdout, stderr = await self._run_docker(
            f"pull {full_image}", timeout=300.0
        )
        
        return {
            'success': success,
            'image': full_image,
            'message': stdout if success else stderr
        }
    
    async def push(
        self,
        image: str,
        tag: Optional[str] = None
    ) -> Dict[str, Any]:
        """Push an image to registry."""
        full_image = f"{image}:{tag}" if tag else image
        success, stdout, stderr = await self._run_docker(
            f"push {full_image}", timeout=300.0
        )
        
        return {
            'success': success,
            'image': full_image,
            'message': stdout if success else stderr
        }
    
    async def build(
        self,
        path: str = ".",
        tag: Optional[str] = None,
        dockerfile: Optional[str] = None,
        no_cache: bool = False,
        pull: bool = False,
        build_args: Optional[Dict[str, str]] = None
    ) -> Dict[str, Any]:
        """
        Build an image from Dockerfile.
        
        Args:
            path: Build context path
            tag: Image tag
            dockerfile: Dockerfile path
            no_cache: Don't use cache
            pull: Always pull base image
            build_args: Build arguments
            
        Returns:
            Result dict
        """
        cmd = f"build {path}"
        
        if tag:
            cmd += f" -t {tag}"
        if dockerfile:
            cmd += f" -f {dockerfile}"
        if no_cache:
            cmd += " --no-cache"
        if pull:
            cmd += " --pull"
        if build_args:
            for key, value in build_args.items():
                cmd += f' --build-arg "{key}={value}"'
        
        success, stdout, stderr = await self._run_docker(cmd, timeout=600.0)
        
        return {
            'success': success,
            'tag': tag,
            'output': stdout,
            'error': stderr if not success else None
        }
    
    async def tag(
        self,
        source: str,
        target: str
    ) -> Dict[str, Any]:
        """Tag an image."""
        success, stdout, stderr = await self._run_docker(f"tag {source} {target}")
        
        return {
            'success': success,
            'source': source,
            'target': target,
            'message': "Tagged successfully" if success else stderr
        }
    
    async def remove_image(
        self,
        image: str,
        force: bool = False,
        no_prune: bool = False
    ) -> Dict[str, Any]:
        """Remove an image."""
        cmd = f"rmi {image}"
        if force:
            cmd += " -f"
        if no_prune:
            cmd += " --no-prune"
        
        success, stdout, stderr = await self._run_docker(cmd)
        
        return {
            'success': success,
            'image': image,
            'message': stdout.strip() if success else stderr
        }
    
    async def prune_images(
        self,
        all_images: bool = False,
        force: bool = True
    ) -> Dict[str, Any]:
        """Remove unused images."""
        cmd = "image prune"
        if all_images:
            cmd += " -a"
        if force:
            cmd += " -f"
        
        success, stdout, stderr = await self._run_docker(cmd)
        
        return {
            'success': success,
            'message': stdout if success else stderr
        }
    
    # =========================================================================
    # Volume Operations
    # =========================================================================
    
    async def list_volumes(self) -> List[Volume]:
        """List Docker volumes."""
        success, stdout, _ = await self._run_docker('volume ls --format "{{json .}}"')
        
        volumes = []
        if success:
            for line in stdout.strip().split('\n'):
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    volumes.append(Volume(
                        name=data.get('Name', ''),
                        driver=data.get('Driver', ''),
                        mountpoint=data.get('Mountpoint', '')
                    ))
                except json.JSONDecodeError:
                    continue
        
        return volumes
    
    async def create_volume(
        self,
        name: str,
        driver: Optional[str] = None,
        labels: Optional[Dict[str, str]] = None
    ) -> Dict[str, Any]:
        """Create a volume."""
        cmd = f"volume create {name}"
        if driver:
            cmd += f" --driver {driver}"
        if labels:
            for key, value in labels.items():
                cmd += f' --label "{key}={value}"'
        
        success, stdout, stderr = await self._run_docker(cmd)
        
        return {
            'success': success,
            'name': name,
            'message': stdout.strip() if success else stderr
        }
    
    async def remove_volume(
        self,
        name: str,
        force: bool = False
    ) -> Dict[str, Any]:
        """Remove a volume."""
        cmd = f"volume rm {name}"
        if force:
            cmd += " -f"
        
        success, stdout, stderr = await self._run_docker(cmd)
        
        return {
            'success': success,
            'name': name,
            'message': stdout.strip() if success else stderr
        }
    
    async def prune_volumes(self, force: bool = True) -> Dict[str, Any]:
        """Remove unused volumes."""
        cmd = "volume prune"
        if force:
            cmd += " -f"
        
        success, stdout, stderr = await self._run_docker(cmd)
        
        return {
            'success': success,
            'message': stdout if success else stderr
        }
    
    # =========================================================================
    # Network Operations
    # =========================================================================
    
    async def list_networks(self) -> List[Network]:
        """List Docker networks."""
        success, stdout, _ = await self._run_docker('network ls --format "{{json .}}"')
        
        networks = []
        if success:
            for line in stdout.strip().split('\n'):
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    networks.append(Network(
                        id=data.get('ID', ''),
                        name=data.get('Name', ''),
                        driver=data.get('Driver', ''),
                        scope=data.get('Scope', '')
                    ))
                except json.JSONDecodeError:
                    continue
        
        return networks
    
    async def create_network(
        self,
        name: str,
        driver: str = "bridge",
        subnet: Optional[str] = None,
        gateway: Optional[str] = None
    ) -> Dict[str, Any]:
        """Create a network."""
        cmd = f"network create --driver {driver} {name}"
        if subnet:
            cmd += f" --subnet {subnet}"
        if gateway:
            cmd += f" --gateway {gateway}"
        
        success, stdout, stderr = await self._run_docker(cmd)
        
        return {
            'success': success,
            'name': name,
            'id': stdout.strip()[:12] if success else None,
            'message': stderr if not success else "Network created"
        }
    
    async def remove_network(self, name: str) -> Dict[str, Any]:
        """Remove a network."""
        success, stdout, stderr = await self._run_docker(f"network rm {name}")
        
        return {
            'success': success,
            'name': name,
            'message': stdout.strip() if success else stderr
        }
    
    async def connect_network(
        self,
        network: str,
        container: str
    ) -> Dict[str, Any]:
        """Connect container to network."""
        success, stdout, stderr = await self._run_docker(
            f"network connect {network} {container}"
        )
        
        return {
            'success': success,
            'network': network,
            'container': container,
            'message': "Connected" if success else stderr
        }
    
    async def disconnect_network(
        self,
        network: str,
        container: str
    ) -> Dict[str, Any]:
        """Disconnect container from network."""
        success, stdout, stderr = await self._run_docker(
            f"network disconnect {network} {container}"
        )
        
        return {
            'success': success,
            'network': network,
            'container': container,
            'message': "Disconnected" if success else stderr
        }
    
    # =========================================================================
    # Docker Compose Operations
    # =========================================================================
    
    async def compose_up(
        self,
        path: str = "docker-compose.yml",
        detach: bool = True,
        build: bool = False,
        force_recreate: bool = False,
        services: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Run docker-compose up.
        
        Args:
            path: Compose file path
            detach: Run in background
            build: Build images before starting
            force_recreate: Force recreate containers
            services: Specific services to start
            
        Returns:
            Result dict
        """
        cmd = f"-f {path} up"
        if detach:
            cmd += " -d"
        if build:
            cmd += " --build"
        if force_recreate:
            cmd += " --force-recreate"
        if services:
            cmd += " " + " ".join(services)
        
        result = await shell_executor.execute_command(
            f"docker-compose {cmd}",
            timeout=300.0
        )
        
        return {
            'success': result.success,
            'output': result.stdout,
            'error': result.stderr if not result.success else None
        }
    
    async def compose_down(
        self,
        path: str = "docker-compose.yml",
        volumes: bool = False,
        remove_orphans: bool = False,
        rmi: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Run docker-compose down.
        
        Args:
            path: Compose file path
            volumes: Remove volumes
            remove_orphans: Remove orphan containers
            rmi: Remove images (all, local)
            
        Returns:
            Result dict
        """
        cmd = f"-f {path} down"
        if volumes:
            cmd += " -v"
        if remove_orphans:
            cmd += " --remove-orphans"
        if rmi:
            cmd += f" --rmi {rmi}"
        
        result = await shell_executor.execute_command(
            f"docker-compose {cmd}",
            timeout=60.0
        )
        
        return {
            'success': result.success,
            'output': result.stdout,
            'error': result.stderr if not result.success else None
        }
    
    async def compose_ps(
        self,
        path: str = "docker-compose.yml"
    ) -> Dict[str, Any]:
        """Get compose project status."""
        result = await shell_executor.execute_command(
            f"docker-compose -f {path} ps",
            timeout=30.0
        )
        
        return {
            'success': result.success,
            'output': result.stdout,
            'error': result.stderr if not result.success else None
        }
    
    async def compose_logs(
        self,
        path: str = "docker-compose.yml",
        service: Optional[str] = None,
        tail: Optional[int] = None
    ) -> str:
        """Get compose logs."""
        cmd = f"-f {path} logs"
        if tail:
            cmd += f" --tail {tail}"
        if service:
            cmd += f" {service}"
        
        result = await shell_executor.execute_command(
            f"docker-compose {cmd}",
            timeout=30.0
        )
        
        return result.stdout if result.success else result.stderr
    
    # =========================================================================
    # System Operations
    # =========================================================================
    
    async def system_prune(
        self,
        all_unused: bool = False,
        volumes: bool = False,
        force: bool = True
    ) -> Dict[str, Any]:
        """Remove unused Docker data."""
        cmd = "system prune"
        if all_unused:
            cmd += " -a"
        if volumes:
            cmd += " --volumes"
        if force:
            cmd += " -f"
        
        success, stdout, stderr = await self._run_docker(cmd, timeout=120.0)
        
        return {
            'success': success,
            'message': stdout if success else stderr
        }
    
    async def disk_usage(self) -> Dict[str, Any]:
        """Get Docker disk usage."""
        success, stdout, stderr = await self._run_docker("system df")
        
        return {
            'success': success,
            'output': stdout if success else None,
            'error': stderr if not success else None
        }
    
    # =========================================================================
    # Main Run Method
    # =========================================================================
    
    async def run(self, context: ToolContext, **kwargs) -> ToolResult:
        """
        Execute Docker operation.
        
        Supported operations:
        
        Containers:
        - containers: List containers
        - run: Run new container
        - start/stop/restart/pause/unpause: Manage container
        - remove: Remove container
        - logs: Get container logs
        - exec: Execute command in container
        - inspect: Inspect container
        - stats: Get container stats
        - top: Get container processes
        - cp_to/cp_from: Copy files
        
        Images:
        - images: List images
        - pull: Pull image
        - push: Push image
        - build: Build image
        - tag: Tag image
        - rmi: Remove image
        - prune_images: Remove unused images
        
        Volumes:
        - volumes: List volumes
        - create_volume: Create volume
        - remove_volume: Remove volume
        - prune_volumes: Remove unused volumes
        
        Networks:
        - networks: List networks
        - create_network: Create network
        - remove_network: Remove network
        - connect: Connect container to network
        - disconnect: Disconnect from network
        
        Compose:
        - compose_up: docker-compose up
        - compose_down: docker-compose down
        - compose_ps: docker-compose ps
        - compose_logs: docker-compose logs
        
        System:
        - version: Docker version
        - info: Docker info
        - prune: System prune
        - df: Disk usage
        """
        operation = kwargs.get('operation', 'containers')
        
        # Check Docker availability
        if not await self.is_available():
            return ToolResult.fail(error="Docker is not available or not running")
        
        try:
            # Container operations
            if operation == 'containers':
                containers = await self.list_containers(
                    all_containers=kwargs.get('all', False),
                    filters=kwargs.get('filters')
                )
                return ToolResult.ok(
                    data={
                        'containers': [c.to_dict() for c in containers],
                        'count': len(containers)
                    }
                )
            
            elif operation == 'run':
                image = kwargs.get('image')
                if not image:
                    return ToolResult.fail(error="image is required")
                
                result = await self.run_container(
                    image,
                    name=kwargs.get('name'),
                    detach=kwargs.get('detach', True),
                    ports=kwargs.get('ports'),
                    volumes=kwargs.get('volumes'),
                    env=kwargs.get('env'),
                    command=kwargs.get('command'),
                    network=kwargs.get('network'),
                    restart=kwargs.get('restart'),
                    remove=kwargs.get('remove', False),
                    workdir=kwargs.get('workdir'),
                    user=kwargs.get('user'),
                    memory=kwargs.get('memory'),
                    cpus=kwargs.get('cpus')
                )
                
                if result['success']:
                    return ToolResult.ok(data=result, message=result.get('message'))
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            elif operation in ['start', 'stop', 'restart', 'pause', 'unpause']:
                container = kwargs.get('container')
                if not container:
                    return ToolResult.fail(error="container is required")
                
                method = getattr(self, operation)
                if operation == 'stop':
                    result = await method(container, timeout=kwargs.get('timeout', 10))
                else:
                    result = await method(container)
                
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            elif operation == 'remove':
                container = kwargs.get('container')
                if not container:
                    return ToolResult.fail(error="container is required")
                
                result = await self.remove_container(
                    container,
                    force=kwargs.get('force', False),
                    volumes=kwargs.get('volumes', False)
                )
                
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            elif operation == 'logs':
                container = kwargs.get('container')
                if not container:
                    return ToolResult.fail(error="container is required")
                
                logs = await self.logs(
                    container,
                    tail=kwargs.get('tail'),
                    since=kwargs.get('since'),
                    timestamps=kwargs.get('timestamps', False)
                )
                return ToolResult.ok(data={'logs': logs})
            
            elif operation == 'exec':
                container = kwargs.get('container')
                command = kwargs.get('command')
                if not container or not command:
                    return ToolResult.fail(error="container and command are required")
                
                result = await self.exec_command(
                    container, command,
                    user=kwargs.get('user'),
                    workdir=kwargs.get('workdir'),
                    env=kwargs.get('env')
                )
                
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('error'))
            
            elif operation == 'inspect':
                container = kwargs.get('container')
                if not container:
                    return ToolResult.fail(error="container is required")
                
                result = await self.inspect(container)
                if result['success']:
                    return ToolResult.ok(data=result.get('data'))
                else:
                    return ToolResult.fail(error=result.get('error'))
            
            elif operation == 'stats':
                result = await self.stats(
                    container=kwargs.get('container'),
                    no_stream=kwargs.get('no_stream', True)
                )
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('error'))
            
            elif operation == 'top':
                container = kwargs.get('container')
                if not container:
                    return ToolResult.fail(error="container is required")
                
                result = await self.top(container)
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('error'))
            
            # Image operations
            elif operation == 'images':
                images = await self.list_images(
                    all_images=kwargs.get('all', False)
                )
                return ToolResult.ok(
                    data={
                        'images': [i.to_dict() for i in images],
                        'count': len(images)
                    }
                )
            
            elif operation == 'pull':
                image = kwargs.get('image')
                if not image:
                    return ToolResult.fail(error="image is required")
                
                result = await self.pull(image, tag=kwargs.get('tag'))
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            elif operation == 'push':
                image = kwargs.get('image')
                if not image:
                    return ToolResult.fail(error="image is required")
                
                result = await self.push(image, tag=kwargs.get('tag'))
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            elif operation == 'build':
                result = await self.build(
                    path=kwargs.get('path', '.'),
                    tag=kwargs.get('tag'),
                    dockerfile=kwargs.get('dockerfile'),
                    no_cache=kwargs.get('no_cache', False),
                    pull=kwargs.get('pull', False),
                    build_args=kwargs.get('build_args')
                )
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('error'))
            
            elif operation == 'tag':
                source = kwargs.get('source')
                target = kwargs.get('target')
                if not source or not target:
                    return ToolResult.fail(error="source and target are required")
                
                result = await self.tag(source, target)
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            elif operation == 'rmi':
                image = kwargs.get('image')
                if not image:
                    return ToolResult.fail(error="image is required")
                
                result = await self.remove_image(
                    image,
                    force=kwargs.get('force', False)
                )
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            elif operation == 'prune_images':
                result = await self.prune_images(
                    all_images=kwargs.get('all', False)
                )
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            # Volume operations
            elif operation == 'volumes':
                volumes = await self.list_volumes()
                return ToolResult.ok(
                    data={
                        'volumes': [v.to_dict() for v in volumes],
                        'count': len(volumes)
                    }
                )
            
            elif operation == 'create_volume':
                name = kwargs.get('name')
                if not name:
                    return ToolResult.fail(error="name is required")
                
                result = await self.create_volume(
                    name,
                    driver=kwargs.get('driver'),
                    labels=kwargs.get('labels')
                )
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            elif operation == 'remove_volume':
                name = kwargs.get('name')
                if not name:
                    return ToolResult.fail(error="name is required")
                
                result = await self.remove_volume(name, force=kwargs.get('force', False))
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            elif operation == 'prune_volumes':
                result = await self.prune_volumes()
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            # Network operations
            elif operation == 'networks':
                networks = await self.list_networks()
                return ToolResult.ok(
                    data={
                        'networks': [n.to_dict() for n in networks],
                        'count': len(networks)
                    }
                )
            
            elif operation == 'create_network':
                name = kwargs.get('name')
                if not name:
                    return ToolResult.fail(error="name is required")
                
                result = await self.create_network(
                    name,
                    driver=kwargs.get('driver', 'bridge'),
                    subnet=kwargs.get('subnet'),
                    gateway=kwargs.get('gateway')
                )
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            elif operation == 'remove_network':
                name = kwargs.get('name')
                if not name:
                    return ToolResult.fail(error="name is required")
                
                result = await self.remove_network(name)
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            elif operation == 'connect':
                network = kwargs.get('network')
                container = kwargs.get('container')
                if not network or not container:
                    return ToolResult.fail(error="network and container are required")
                
                result = await self.connect_network(network, container)
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            elif operation == 'disconnect':
                network = kwargs.get('network')
                container = kwargs.get('container')
                if not network or not container:
                    return ToolResult.fail(error="network and container are required")
                
                result = await self.disconnect_network(network, container)
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            # Compose operations
            elif operation == 'compose_up':
                result = await self.compose_up(
                    path=kwargs.get('path', 'docker-compose.yml'),
                    detach=kwargs.get('detach', True),
                    build=kwargs.get('build', False),
                    force_recreate=kwargs.get('force_recreate', False),
                    services=kwargs.get('services')
                )
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('error'))
            
            elif operation == 'compose_down':
                result = await self.compose_down(
                    path=kwargs.get('path', 'docker-compose.yml'),
                    volumes=kwargs.get('volumes', False),
                    remove_orphans=kwargs.get('remove_orphans', False),
                    rmi=kwargs.get('rmi')
                )
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('error'))
            
            elif operation == 'compose_ps':
                result = await self.compose_ps(
                    path=kwargs.get('path', 'docker-compose.yml')
                )
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('error'))
            
            elif operation == 'compose_logs':
                logs = await self.compose_logs(
                    path=kwargs.get('path', 'docker-compose.yml'),
                    service=kwargs.get('service'),
                    tail=kwargs.get('tail')
                )
                return ToolResult.ok(data={'logs': logs})
            
            # System operations
            elif operation == 'version':
                result = await self.version()
                if result.get('success', True):
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('error'))
            
            elif operation == 'info':
                result = await self.info()
                if result.get('success', True):
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('error'))
            
            elif operation == 'prune':
                result = await self.system_prune(
                    all_unused=kwargs.get('all', False),
                    volumes=kwargs.get('volumes', False)
                )
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('message'))
            
            elif operation == 'df':
                result = await self.disk_usage()
                if result['success']:
                    return ToolResult.ok(data=result)
                else:
                    return ToolResult.fail(error=result.get('error'))
            
            else:
                return ToolResult.fail(error=f"Unknown operation: {operation}")
            
        except Exception as e:
            logger.error(f"DockerTools error: {e}")
            return ToolResult.error(error=str(e))


# Create singleton
docker_tools = DockerTools()


def register():
    """Register Docker tools."""
    registry = get_registry()
    registry.register_tool(docker_tools)