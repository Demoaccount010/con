#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════
#  OLLAMA SETUP SCRIPT
# ═══════════════════════════════════════════════════════════════════════════════
#
#  This script sets up Ollama for the autonomous agent:
#  • Installs Ollama (if not present)
#  • Starts Ollama service
#  • Downloads recommended models based on system RAM
#  • Verifies installation
#
#  Usage:
#    ./setup_ollama.sh              # Interactive setup
#    ./setup_ollama.sh --install    # Just install Ollama
#    ./setup_ollama.sh --models     # Just download models
#    ./setup_ollama.sh --start      # Just start service
#
#  Author: System Engineer
#  Version: 3.0.0
#
# ═══════════════════════════════════════════════════════════════════════════════

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m'

# Configuration
OLLAMA_URL="http://localhost:11434"

# ═══════════════════════════════════════════════════════════════════════════════
#                          HELPER FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

print_banner() {
    echo -e "${CYAN}"
    echo "═══════════════════════════════════════════════════════════════════════════════"
    echo "                           OLLAMA SETUP SCRIPT                                  "
    echo "═══════════════════════════════════════════════════════════════════════════════"
    echo -e "${NC}"
}

print_step() {
    echo -e "\n${BLUE}▶ ${WHITE}$1${NC}"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_info() {
    echo -e "${CYAN}ℹ $1${NC}"
}

check_command() {
    command -v "$1" &> /dev/null
}

get_os() {
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        echo "linux"
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        echo "macos"
    elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "cygwin" ]]; then
        echo "windows"
    else
        echo "unknown"
    fi
}

get_ram_gb() {
    OS=$(get_os)
    if [ "$OS" = "linux" ]; then
        free -g | awk '/^Mem:/{print $2}'
    elif [ "$OS" = "macos" ]; then
        echo $(($(sysctl -n hw.memsize) / 1024 / 1024 / 1024))
    else
        echo 8  # Default assumption
    fi
}

# ═══════════════════════════════════════════════════════════════════════════════
#                          OLLAMA INSTALLATION
# ═══════════════════════════════════════════════════════════════════════════════

install_ollama() {
    print_step "Installing Ollama..."
    
    OS=$(get_os)
    
    case $OS in
        linux)
            print_info "Downloading Ollama installer..."
            curl -fsSL https://ollama.com/install.sh | sh
            ;;
        macos)
            if check_command brew; then
                print_info "Installing via Homebrew..."
                brew install ollama
            else
                print_info "Downloading Ollama installer..."
                curl -fsSL https://ollama.com/install.sh | sh
            fi
            ;;
        windows)
            print_error "Please download Ollama from https://ollama.com/download/windows"
            print_info "After installation, run this script again with --models"
            exit 1
            ;;
        *)
            print_error "Unsupported operating system"
            exit 1
            ;;
    esac
    
    if check_command ollama; then
        print_success "Ollama installed successfully"
    else
        print_error "Ollama installation failed"
        exit 1
    fi
}

# ═══════════════════════════════════════════════════════════════════════════════
#                          OLLAMA SERVICE
# ═══════════════════════════════════════════════════════════════════════════════

start_ollama() {
    print_step "Starting Ollama service..."
    
    # Check if already running
    if curl -s "$OLLAMA_URL/api/tags" &>/dev/null; then
        print_success "Ollama is already running"
        return 0
    fi
    
    OS=$(get_os)
    
    case $OS in
        linux)
            # Try systemd first
            if check_command systemctl; then
                if systemctl is-active --quiet ollama 2>/dev/null; then
                    print_success "Ollama service is running"
                    return 0
                fi
                
                print_info "Starting Ollama via systemd..."
                sudo systemctl start ollama 2>/dev/null || {
                    print_info "Starting Ollama in background..."
                    nohup ollama serve > /tmp/ollama.log 2>&1 &
                }
            else
                print_info "Starting Ollama in background..."
                nohup ollama serve > /tmp/ollama.log 2>&1 &
            fi
            ;;
        macos)
            print_info "Starting Ollama..."
            # On macOS, Ollama usually runs as a desktop app
            # Try starting the serve command
            nohup ollama serve > /tmp/ollama.log 2>&1 &
            ;;
        *)
            print_warning "Please start Ollama manually"
            ;;
    esac
    
    # Wait for service to start
    print_info "Waiting for Ollama to start..."
    for i in {1..30}; do
        if curl -s "$OLLAMA_URL/api/tags" &>/dev/null; then
            print_success "Ollama is running"
            return 0
        fi
        sleep 1
    done
    
    print_error "Ollama failed to start. Check /tmp/ollama.log for details."
    return 1
}

stop_ollama() {
    print_step "Stopping Ollama service..."
    
    OS=$(get_os)
    
    case $OS in
        linux)
            if check_command systemctl; then
                sudo systemctl stop ollama 2>/dev/null || true
            fi
            pkill -f "ollama serve" 2>/dev/null || true
            ;;
        macos)
            pkill -f "ollama serve" 2>/dev/null || true
            ;;
    esac
    
    print_success "Ollama stopped"
}

# ═══════════════════════════════════════════════════════════════════════════════
#                          MODEL MANAGEMENT
# ═══════════════════════════════════════════════════════════════════════════════

get_recommended_models() {
    RAM=$(get_ram_gb)
    
    echo ""
    print_info "Detected RAM: ${RAM}GB"
    echo ""
    
    if [ "$RAM" -lt 4 ]; then
        echo "tinyllama"
    elif [ "$RAM" -lt 8 ]; then
        echo "tinyllama phi"
    elif [ "$RAM" -lt 16 ]; then
        echo "llama3.2 mistral gemma2"
    elif [ "$RAM" -lt 32 ]; then
        echo "llama3.1 llama3.2 codellama mistral"
    else
        echo "llama3.1 llama3.1:70b codellama:34b mixtral"
    fi
}

list_models() {
    print_step "Available models:"
    
    if ! curl -s "$OLLAMA_URL/api/tags" &>/dev/null; then
        print_error "Ollama is not running"
        return 1
    fi
    
    response=$(curl -s "$OLLAMA_URL/api/tags")
    
    python3 << EOF
import json
import sys

try:
    data = json.loads('''$response''')
    models = data.get('models', [])
    
    if not models:
        print("  No models installed")
        sys.exit(0)
    
    print("")
    for model in models:
        name = model.get('name', 'unknown')
        size = model.get('size', 0) / (1024**3)  # Convert to GB
        print(f"  • {name} ({size:.1f}GB)")
    print("")
    
except Exception as e:
    print(f"  Error: {e}")
    sys.exit(1)
EOF
}

download_model() {
    model="$1"
    
    print_step "Downloading model: $model"
    print_info "This may take a while depending on your connection..."
    echo ""
    
    ollama pull "$model"
    
    if [ $? -eq 0 ]; then
        print_success "Model $model downloaded successfully"
    else
        print_error "Failed to download model $model"
        return 1
    fi
}

download_recommended_models() {
    print_step "Setting up recommended models..."
    
    recommended=$(get_recommended_models)
    
    echo "Recommended models for your system:"
    for model in $recommended; do
        echo "  • $model"
    done
    echo ""
    
    read -p "Download these models? (y/n): " -n 1 -r
    echo ""
    
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        for model in $recommended; do
            download_model "$model"
        done
    else
        print_info "Model download skipped"
        echo ""
        print_info "Download models later with: ollama pull <model_name>"
        echo ""
        echo "Popular models:"
        echo "  • llama3.2      - Fast, efficient (3B parameters)"
        echo "  • llama3.1      - More capable (8B parameters)"
        echo "  • mistral       - Good balance of speed/quality"
        echo "  • codellama     - Optimized for code"
        echo "  • deepseek-coder - Great for coding tasks"
    fi
}

# ═══════════════════════════════════════════════════════════════════════════════
#                          VERIFICATION
# ═══════════════════════════════════════════════════════════════════════════════

verify_ollama() {
    print_step "Verifying Ollama installation..."
    
    # Check command
    if ! check_command ollama; then
        print_error "Ollama command not found"
        return 1
    fi
    print_success "Ollama command available"
    
    # Check service
    if ! curl -s "$OLLAMA_URL/api/tags" &>/dev/null; then
        print_warning "Ollama service not running"
        return 1
    fi
    print_success "Ollama service running"
    
    # Check for models
    response=$(curl -s "$OLLAMA_URL/api/tags")
    model_count=$(echo "$response" | python3 -c "import json,sys; print(len(json.load(sys.stdin).get('models',[])))" 2>/dev/null || echo 0)
    
    if [ "$model_count" -gt 0 ]; then
        print_success "$model_count model(s) available"
    else
        print_warning "No models installed"
    fi
    
    return 0
}

test_model() {
    model="$1"
    
    print_step "Testing model: $model"
    
    response=$(curl -s "$OLLAMA_URL/api/generate" \
        -H "Content-Type: application/json" \
        -d "{\"model\": \"$model\", \"prompt\": \"Say hello in one word.\", \"stream\": false}")
    
    result=$(echo "$response" | python3 -c "import json,sys; print(json.load(sys.stdin).get('response','')[:100])" 2>/dev/null)
    
    if [ -n "$result" ]; then
        print_success "Model response: $result"
    else
        print_error "Model did not respond"
        return 1
    fi
}

# ═══════════════════════════════════════════════════════════════════════════════
#                          MAIN
# ═══════════════════════════════════════════════════════════════════════════════

show_help() {
    echo "Usage: ./setup_ollama.sh [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  --install       Install Ollama only"
    echo "  --start         Start Ollama service only"
    echo "  --stop          Stop Ollama service"
    echo "  --models        Download recommended models only"
    echo "  --list          List installed models"
    echo "  --pull MODEL    Download a specific model"
    echo "  --test MODEL    Test a specific model"
    echo "  --verify        Verify installation"
    echo "  --help          Show this help"
    echo ""
    echo "Without options, runs full interactive setup."
}

main() {
    print_banner
    
    # Parse arguments
    case "${1:-}" in
        --install)
            install_ollama
            ;;
        --start)
            start_ollama
            ;;
        --stop)
            stop_ollama
            ;;
        --models)
            start_ollama
            download_recommended_models
            ;;
        --list)
            list_models
            ;;
        --pull)
            if [ -z "${2:-}" ]; then
                print_error "Please specify a model name"
                exit 1
            fi
            start_ollama
            download_model "$2"
            ;;
        --test)
            if [ -z "${2:-}" ]; then
                print_error "Please specify a model name"
                exit 1
            fi
            test_model "$2"
            ;;
        --verify)
            verify_ollama
            ;;
        --help|-h)
            show_help
            exit 0
            ;;
        "")
            # Full interactive setup
            
            # Check if Ollama is installed
            if ! check_command ollama; then
                install_ollama
            else
                print_success "Ollama is already installed"
            fi
            
            # Start service
            start_ollama
            
            # List current models
            list_models
            
            # Download recommended models
            download_recommended_models
            
            # Verify
            echo ""
            verify_ollama
            
            echo ""
            print_success "Ollama setup complete!"
            echo ""
            print_info "Ollama is ready at: $OLLAMA_URL"
            ;;
        *)
            print_error "Unknown option: $1"
            show_help
            exit 1
            ;;
    esac
}

main "$@"