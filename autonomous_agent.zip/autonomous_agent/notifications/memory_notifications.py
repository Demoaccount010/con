#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 MEMORY NOTIFICATIONS - NOTIFICATIONS FOR MEMORY CHANGES
═══════════════════════════════════════════════════════════════════════════════

 Specialized notification handling for all memory operations.
 
 TRIGGERS NOTIFICATIONS FOR:
 ───────────────────────────
 • Memory saved         → [MEMORY SAVED]
 • Memory updated       → [MEMORY UPDATED]
 • Memory overwritten   → [MEMORY OVERWRITTEN]
 • Memory conflict      → [MEMORY CONFLICT]
 • Memory verified      → [MEMORY VERIFIED]
 • Memory archived      → [MEMORY ARCHIVED]
 • Memory permanent     → [MEMORY PERMANENT]
 • Memory learned       → [MEMORY LEARNED]
 • Memory deleted       → [MEMORY DELETED]
 • Memory hint used     → [MEMORY HINT]
 
 CONNECTS TO:
 ────────────
 • NotificationManager  - For delivery
 • MemoryTagger        - For tag generation
 • MemoryManager       - Listens to memory events
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import logging
from datetime import datetime
from typing import Optional, Dict, Any, List, Callable, Awaitable
from dataclasses import dataclass, field
from enum import Enum

# Import from notification manager
from notifications.notification_manager import (
    NotificationManager,
    NotificationType,
    NotificationPriority,
    Notification
)


class MemoryChangeType(Enum):
    """Types of memory changes."""
    SAVED = "saved"
    UPDATED = "updated"
    OVERWRITTEN = "overwritten"
    CONFLICT = "conflict"
    VERIFIED = "verified"
    ARCHIVED = "archived"
    PERMANENT = "permanent"
    LEARNED = "learned"
    DELETED = "deleted"
    HINT_USED = "hint_used"


@dataclass
class MemoryChangeEvent:
    """Event representing a memory change."""
    change_type: MemoryChangeType
    key: str
    memory_type: str  # fact, skill, failure, preference, etc.
    
    # Values
    old_value: Optional[Any] = None
    new_value: Optional[Any] = None
    
    # Metadata
    reason: str = ""
    source: str = ""  # user, agent, system, research
    confidence: float = 1.0
    version: int = 1
    
    # Conflict details (for CONFLICT type)
    memory_value: Optional[Any] = None
    reality_value: Optional[Any] = None
    
    # Timing
    timestamp: datetime = field(default_factory=datetime.utcnow)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'change_type': self.change_type.value,
            'key': self.key,
            'memory_type': self.memory_type,
            'old_value': str(self.old_value) if self.old_value else None,
            'new_value': str(self.new_value) if self.new_value else None,
            'reason': self.reason,
            'source': self.source,
            'confidence': self.confidence,
            'version': self.version,
            'timestamp': self.timestamp.isoformat(),
        }


class MemoryNotifications:
    """
    ═══════════════════════════════════════════════════════════════════════════
    MEMORY NOTIFICATION HANDLER
    ═══════════════════════════════════════════════════════════════════════════
    
    Handles all memory-related notifications.
    Generates visible tags for all memory operations.
    Sends notifications through the central NotificationManager.
    """
    
    # Mapping from change type to notification type
    CHANGE_TO_NOTIFICATION = {
        MemoryChangeType.SAVED: NotificationType.MEMORY_SAVED,
        MemoryChangeType.UPDATED: NotificationType.MEMORY_UPDATED,
        MemoryChangeType.OVERWRITTEN: NotificationType.MEMORY_OVERWRITTEN,
        MemoryChangeType.CONFLICT: NotificationType.MEMORY_CONFLICT,
        MemoryChangeType.VERIFIED: NotificationType.MEMORY_VERIFIED,
        MemoryChangeType.PERMANENT: NotificationType.MEMORY_PERMANENT,
        MemoryChangeType.LEARNED: NotificationType.MEMORY_LEARNED,
        MemoryChangeType.DELETED: NotificationType.MEMORY_DELETED,
    }
    
    # Tag formats for display
    TAG_FORMATS = {
        MemoryChangeType.SAVED: "🏷️ [MEMORY SAVED]",
        MemoryChangeType.UPDATED: "🔄 [MEMORY UPDATED]",
        MemoryChangeType.OVERWRITTEN: "♻️ [MEMORY OVERWRITTEN]",
        MemoryChangeType.CONFLICT: "⚠️ [MEMORY CONFLICT]",
        MemoryChangeType.VERIFIED: "✅ [MEMORY VERIFIED]",
        MemoryChangeType.ARCHIVED: "🗑️ [MEMORY ARCHIVED]",
        MemoryChangeType.PERMANENT: "📍 [MEMORY PERMANENT]",
        MemoryChangeType.LEARNED: "📚 [MEMORY LEARNED]",
        MemoryChangeType.DELETED: "❌ [MEMORY DELETED]",
        MemoryChangeType.HINT_USED: "💡 [MEMORY HINT]",
    }
    
    def __init__(
        self,
        notification_manager: NotificationManager,
        config: Dict[str, Any] = None
    ):
        """
        Initialize memory notifications.
        
        Args:
            notification_manager: Central notification manager
            config: Configuration dictionary
        """
        self.logger = logging.getLogger("notifications.memory")
        self.notification_manager = notification_manager
        self.config = config or {}
        
        # History of memory changes
        self.change_history: List[MemoryChangeEvent] = []
        self.max_history = self.config.get('max_history', 1000)
        
        # Settings
        self.notify_on_save = self.config.get('notify_on_save', True)
        self.notify_on_update = self.config.get('notify_on_update', True)
        self.notify_on_overwrite = self.config.get('notify_on_overwrite', True)
        self.notify_on_conflict = self.config.get('notify_on_conflict', True)
        self.notify_on_permanent = self.config.get('notify_on_permanent', True)
        self.notify_on_learned = self.config.get('notify_on_learned', True)
        
        # Telegram notifications for important changes
        self.telegram_for_overwrite = self.config.get('telegram_for_overwrite', True)
        self.telegram_for_conflict = self.config.get('telegram_for_conflict', True)
        self.telegram_for_permanent = self.config.get('telegram_for_permanent', True)
        self.telegram_for_learned = self.config.get('telegram_for_learned', True)
        
        # Listeners (for external components)
        self._listeners: List[Callable[[MemoryChangeEvent], Awaitable[None]]] = []
        
    async def on_memory_change(self, event: MemoryChangeEvent) -> str:
        """
        Handle a memory change event.
        
        This is the main entry point for memory change notifications.
        
        Args:
            event: The memory change event
            
        Returns:
            The formatted tag string for display
        """
        self.logger.debug(f"Memory change: {event.change_type.value} - {event.key}")
        
        # Add to history
        self._add_to_history(event)
        
        # Generate tag
        tag = self.format_tag(event)
        
        # Send notification if enabled
        await self._send_notification(event)
        
        # Notify listeners
        await self._notify_listeners(event)
        
        return tag
        
    def format_tag(self, event: MemoryChangeEvent) -> str:
        """
        Format a memory change event as a visible tag.
        
        Args:
            event: The memory change event
            
        Returns:
            Formatted tag string
        """
        base_tag = self.TAG_FORMATS.get(
            event.change_type,
            f"🔹 [MEMORY {event.change_type.value.upper()}]"
        )
        
        # Add details based on change type
        if event.change_type == MemoryChangeType.SAVED:
            return f"{base_tag} {event.memory_type}: {event.key}"
            
        elif event.change_type == MemoryChangeType.UPDATED:
            return f"{base_tag} {event.key}: '{self._truncate(event.old_value)}' → '{self._truncate(event.new_value)}'"
            
        elif event.change_type == MemoryChangeType.OVERWRITTEN:
            return f"{base_tag} {event.key} (reason: {event.reason})"
            
        elif event.change_type == MemoryChangeType.CONFLICT:
            return f"{base_tag} {event.key}: Memory='{self._truncate(event.memory_value)}' vs Reality='{self._truncate(event.reality_value)}' → Reality wins!"
            
        elif event.change_type == MemoryChangeType.VERIFIED:
            return f"{base_tag} {event.key} confirmed against reality"
            
        elif event.change_type == MemoryChangeType.PERMANENT:
            return f"{base_tag} {event.key} stored permanently (never forgotten)"
            
        elif event.change_type == MemoryChangeType.LEARNED:
            return f"{base_tag} Learned: {event.key}"
            
        elif event.change_type == MemoryChangeType.DELETED:
            return f"{base_tag} Removed: {event.key}"
            
        elif event.change_type == MemoryChangeType.HINT_USED:
            return f"{base_tag} Using hint: {event.key} (will verify, not trust blindly)"
            
        else:
            return f"{base_tag} {event.key}"
            
    async def _send_notification(self, event: MemoryChangeEvent) -> None:
        """Send notification for memory change."""
        # Check if notification is enabled for this type
        should_notify = False
        priority = NotificationPriority.NORMAL
        
        if event.change_type == MemoryChangeType.SAVED and self.notify_on_save:
            should_notify = True
        elif event.change_type == MemoryChangeType.UPDATED and self.notify_on_update:
            should_notify = True
        elif event.change_type == MemoryChangeType.OVERWRITTEN and self.notify_on_overwrite:
            should_notify = True
            priority = NotificationPriority.HIGH
        elif event.change_type == MemoryChangeType.CONFLICT and self.notify_on_conflict:
            should_notify = True
            priority = NotificationPriority.HIGH
        elif event.change_type == MemoryChangeType.PERMANENT and self.notify_on_permanent:
            should_notify = True
            priority = NotificationPriority.HIGH
        elif event.change_type == MemoryChangeType.LEARNED and self.notify_on_learned:
            should_notify = True
            
        if not should_notify:
            return
            
        # Get notification type
        notif_type = self.CHANGE_TO_NOTIFICATION.get(
            event.change_type,
            NotificationType.MEMORY_SAVED
        )
        
        # Create title and message
        title = self._get_title(event)
        message = self._get_message(event)
        
        # Send through notification manager
        await self.notification_manager.notify(
            type=notif_type,
            title=title,
            message=message,
            priority=priority,
            details=event.to_dict()
        )
        
    def _get_title(self, event: MemoryChangeEvent) -> str:
        """Get notification title for event."""
        titles = {
            MemoryChangeType.SAVED: "Memory Saved",
            MemoryChangeType.UPDATED: "Memory Updated",
            MemoryChangeType.OVERWRITTEN: "Memory Overwritten",
            MemoryChangeType.CONFLICT: "Memory Conflict!",
            MemoryChangeType.VERIFIED: "Memory Verified",
            MemoryChangeType.ARCHIVED: "Memory Archived",
            MemoryChangeType.PERMANENT: "Permanent Memory",
            MemoryChangeType.LEARNED: "New Learning",
            MemoryChangeType.DELETED: "Memory Deleted",
        }
        return titles.get(event.change_type, "Memory Change")
        
    def _get_message(self, event: MemoryChangeEvent) -> str:
        """Get notification message for event."""
        if event.change_type == MemoryChangeType.CONFLICT:
            return f"Conflict for '{event.key}': Memory said '{self._truncate(event.memory_value)}' but reality shows '{self._truncate(event.reality_value)}'. Updated to match reality."
            
        elif event.change_type == MemoryChangeType.OVERWRITTEN:
            return f"Rewrote '{event.key}': {event.reason}"
            
        elif event.change_type == MemoryChangeType.LEARNED:
            return f"Learned about {event.key}: {self._truncate(event.new_value, 100)}"
            
        elif event.change_type == MemoryChangeType.PERMANENT:
            return f"Stored permanently: {event.key} = {self._truncate(event.new_value)}"
            
        else:
            return f"{event.memory_type.title()}: {event.key}"
            
    def _truncate(self, value: Any, max_len: int = 50) -> str:
        """Truncate a value for display."""
        if value is None:
            return "None"
        text = str(value)
        if len(text) > max_len:
            return text[:max_len - 3] + "..."
        return text
        
    def _add_to_history(self, event: MemoryChangeEvent) -> None:
        """Add event to history."""
        self.change_history.append(event)
        
        # Trim history if needed
        if len(self.change_history) > self.max_history:
            self.change_history = self.change_history[-self.max_history:]
            
    def add_listener(
        self,
        listener: Callable[[MemoryChangeEvent], Awaitable[None]]
    ) -> None:
        """Add a listener for memory changes."""
        self._listeners.append(listener)
        
    async def _notify_listeners(self, event: MemoryChangeEvent) -> None:
        """Notify all listeners of memory change."""
        for listener in self._listeners:
            try:
                await listener(event)
            except Exception as e:
                self.logger.error(f"Listener error: {e}")
                
    # ═══════════════════════════════════════════════════════════════════════════
    # CONVENIENCE METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def notify_saved(
        self,
        key: str,
        value: Any,
        memory_type: str = "fact",
        source: str = "agent"
    ) -> str:
        """Notify of memory save."""
        event = MemoryChangeEvent(
            change_type=MemoryChangeType.SAVED,
            key=key,
            memory_type=memory_type,
            new_value=value,
            source=source
        )
        return await self.on_memory_change(event)
        
    async def notify_updated(
        self,
        key: str,
        old_value: Any,
        new_value: Any,
        memory_type: str = "fact"
    ) -> str:
        """Notify of memory update."""
        event = MemoryChangeEvent(
            change_type=MemoryChangeType.UPDATED,
            key=key,
            memory_type=memory_type,
            old_value=old_value,
            new_value=new_value
        )
        return await self.on_memory_change(event)
        
    async def notify_overwritten(
        self,
        key: str,
        old_value: Any,
        new_value: Any,
        reason: str,
        memory_type: str = "fact"
    ) -> str:
        """Notify of memory overwrite (agent decision)."""
        event = MemoryChangeEvent(
            change_type=MemoryChangeType.OVERWRITTEN,
            key=key,
            memory_type=memory_type,
            old_value=old_value,
            new_value=new_value,
            reason=reason,
            source="agent"
        )
        return await self.on_memory_change(event)
        
    async def notify_conflict(
        self,
        key: str,
        memory_value: Any,
        reality_value: Any,
        memory_type: str = "fact"
    ) -> str:
        """Notify of memory vs reality conflict."""
        event = MemoryChangeEvent(
            change_type=MemoryChangeType.CONFLICT,
            key=key,
            memory_type=memory_type,
            memory_value=memory_value,
            reality_value=reality_value,
            old_value=memory_value,
            new_value=reality_value,
            reason="Reality wins over memory"
        )
        return await self.on_memory_change(event)
        
    async def notify_verified(
        self,
        key: str,
        value: Any,
        memory_type: str = "fact"
    ) -> str:
        """Notify of memory verification."""
        event = MemoryChangeEvent(
            change_type=MemoryChangeType.VERIFIED,
            key=key,
            memory_type=memory_type,
            new_value=value,
            source="verification"
        )
        return await self.on_memory_change(event)
        
    async def notify_permanent(
        self,
        key: str,
        value: Any,
        memory_type: str = "permanent"
    ) -> str:
        """Notify of permanent memory storage."""
        event = MemoryChangeEvent(
            change_type=MemoryChangeType.PERMANENT,
            key=key,
            memory_type=memory_type,
            new_value=value,
            source="system"
        )
        return await self.on_memory_change(event)
        
    async def notify_learned(
        self,
        topic: str,
        knowledge: Any,
        source: str = "research"
    ) -> str:
        """Notify of new learning."""
        event = MemoryChangeEvent(
            change_type=MemoryChangeType.LEARNED,
            key=topic,
            memory_type="research",
            new_value=knowledge,
            source=source
        )
        return await self.on_memory_change(event)
        
    async def notify_deleted(
        self,
        key: str,
        old_value: Any,
        memory_type: str = "fact"
    ) -> str:
        """Notify of memory deletion."""
        event = MemoryChangeEvent(
            change_type=MemoryChangeType.DELETED,
            key=key,
            memory_type=memory_type,
            old_value=old_value
        )
        return await self.on_memory_change(event)
        
    async def notify_hint_used(
        self,
        key: str,
        hint_value: Any
    ) -> str:
        """Notify when using memory as hint."""
        event = MemoryChangeEvent(
            change_type=MemoryChangeType.HINT_USED,
            key=key,
            memory_type="hint",
            new_value=hint_value,
            reason="Used as HINT, not trusted as answer"
        )
        return await self.on_memory_change(event)
        
    # ═══════════════════════════════════════════════════════════════════════════
    # HISTORY & STATS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_history(
        self,
        change_type: MemoryChangeType = None,
        memory_type: str = None,
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        """Get change history."""
        history = self.change_history
        
        if change_type:
            history = [e for e in history if e.change_type == change_type]
            
        if memory_type:
            history = [e for e in history if e.memory_type == memory_type]
            
        return [e.to_dict() for e in history[-limit:]]
        
    def get_stats(self) -> Dict[str, Any]:
        """Get memory notification statistics."""
        type_counts = {}
        for event in self.change_history:
            type_name = event.change_type.value
            type_counts[type_name] = type_counts.get(type_name, 0) + 1
            
        return {
            'total_changes': len(self.change_history),
            'by_type': type_counts,
            'settings': {
                'notify_on_save': self.notify_on_save,
                'notify_on_update': self.notify_on_update,
                'notify_on_overwrite': self.notify_on_overwrite,
                'notify_on_conflict': self.notify_on_conflict,
            }
        }
        
    def format_all_tags(self, events: List[MemoryChangeEvent]) -> List[str]:
        """Format all events as tags."""
        return [self.format_tag(event) for event in events]