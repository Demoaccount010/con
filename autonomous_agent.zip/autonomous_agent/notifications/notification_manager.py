#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 NOTIFICATION MANAGER - CENTRAL NOTIFICATION HUB
═══════════════════════════════════════════════════════════════════════════════

 The central hub for ALL notifications in the autonomous agent.
 
 NOTIFICATION TYPES:
 ───────────────────
 • Memory changes    - When memory is saved/updated/overwritten
 • Learning updates  - When agent learns something new
 • Research findings - When autonomous research discovers something
 • Error alerts      - When critical errors occur
 • Status updates    - System status changes
 • Achievements      - When agent completes milestones
 
 DELIVERY CHANNELS:
 ──────────────────
 • Telegram          - Primary notification channel
 • Console           - Immediate display
 • Log files         - Persistent record
 • Queue             - For batch/delayed delivery
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Callable, Awaitable
from dataclasses import dataclass, field
from enum import Enum
from uuid import uuid4
import json
from collections import deque


class NotificationType(Enum):
    """Types of notifications."""
    MEMORY_SAVED = "memory_saved"
    MEMORY_UPDATED = "memory_updated"
    MEMORY_OVERWRITTEN = "memory_overwritten"
    MEMORY_CONFLICT = "memory_conflict"
    MEMORY_VERIFIED = "memory_verified"
    MEMORY_DELETED = "memory_deleted"
    MEMORY_PERMANENT = "memory_permanent"
    MEMORY_LEARNED = "memory_learned"
    
    LEARNING_NEW = "learning_new"
    LEARNING_SKILL = "learning_skill"
    LEARNING_CORRECTION = "learning_correction"
    LEARNING_PATTERN = "learning_pattern"
    
    RESEARCH_STARTED = "research_started"
    RESEARCH_FINDING = "research_finding"
    RESEARCH_COMPLETE = "research_complete"
    
    ERROR_CRITICAL = "error_critical"
    ERROR_WARNING = "error_warning"
    ERROR_TOOL = "error_tool"
    
    STATUS_ONLINE = "status_online"
    STATUS_IDLE = "status_idle"
    STATUS_BUSY = "status_busy"
    STATUS_SHUTDOWN = "status_shutdown"
    
    ACHIEVEMENT = "achievement"
    MILESTONE = "milestone"
    
    SYSTEM_INFO = "system_info"
    DEBUG = "debug"


class NotificationPriority(Enum):
    """Priority levels for notifications."""
    CRITICAL = 1    # Immediate delivery, no batching
    HIGH = 2        # Quick delivery
    NORMAL = 3      # Standard batching
    LOW = 4         # Can be delayed/batched heavily
    DEBUG = 5       # Only shown in debug mode


class DeliveryChannel(Enum):
    """Channels for notification delivery."""
    TELEGRAM = "telegram"
    CONSOLE = "console"
    LOG = "log"
    QUEUE = "queue"
    ALL = "all"


@dataclass
class Notification:
    """A single notification."""
    id: str
    type: NotificationType
    priority: NotificationPriority
    title: str
    message: str
    timestamp: datetime
    
    # Optional details
    details: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    
    # Delivery tracking
    channels: List[DeliveryChannel] = field(default_factory=lambda: [DeliveryChannel.ALL])
    delivered_to: List[str] = field(default_factory=list)
    delivery_attempts: int = 0
    max_attempts: int = 3
    
    # Display options
    show_timestamp: bool = True
    show_icon: bool = True
    silent: bool = False  # Silent = no sound/vibration on Telegram
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'id': self.id,
            'type': self.type.value,
            'priority': self.priority.value,
            'title': self.title,
            'message': self.message,
            'timestamp': self.timestamp.isoformat(),
            'details': self.details,
            'tags': self.tags,
        }
        
    def format_for_telegram(self) -> str:
        """Format for Telegram delivery."""
        lines = []
        
        # Icon based on type
        icons = {
            NotificationType.MEMORY_SAVED: "🏷️",
            NotificationType.MEMORY_UPDATED: "🔄",
            NotificationType.MEMORY_OVERWRITTEN: "♻️",
            NotificationType.MEMORY_CONFLICT: "⚠️",
            NotificationType.MEMORY_VERIFIED: "✅",
            NotificationType.MEMORY_DELETED: "❌",
            NotificationType.MEMORY_PERMANENT: "📍",
            NotificationType.MEMORY_LEARNED: "📚",
            NotificationType.LEARNING_NEW: "🎓",
            NotificationType.LEARNING_SKILL: "⚡",
            NotificationType.LEARNING_CORRECTION: "📝",
            NotificationType.RESEARCH_FINDING: "🔍",
            NotificationType.RESEARCH_COMPLETE: "🎯",
            NotificationType.ERROR_CRITICAL: "🚨",
            NotificationType.ERROR_WARNING: "⚠️",
            NotificationType.ACHIEVEMENT: "🏆",
            NotificationType.STATUS_ONLINE: "🟢",
            NotificationType.STATUS_IDLE: "😴",
        }
        
        icon = icons.get(self.type, "📌")
        
        if self.show_icon:
            lines.append(f"{icon} **{self.title}**")
        else:
            lines.append(f"**{self.title}**")
            
        lines.append(self.message)
        
        if self.show_timestamp:
            lines.append(f"\n_🕐 {self.timestamp.strftime('%H:%M:%S')}_")
            
        return "\n".join(lines)
        
    def format_for_console(self) -> str:
        """Format for console output."""
        icons = {
            NotificationType.MEMORY_SAVED: "🏷️",
            NotificationType.MEMORY_UPDATED: "🔄",
            NotificationType.MEMORY_OVERWRITTEN: "♻️",
            NotificationType.MEMORY_CONFLICT: "⚠️",
            NotificationType.MEMORY_VERIFIED: "✅",
            NotificationType.MEMORY_DELETED: "❌",
            NotificationType.MEMORY_PERMANENT: "📍",
            NotificationType.MEMORY_LEARNED: "📚",
            NotificationType.LEARNING_NEW: "🎓",
            NotificationType.ERROR_CRITICAL: "🚨",
            NotificationType.ACHIEVEMENT: "🏆",
        }
        
        icon = icons.get(self.type, "📌")
        return f"{icon} [{self.type.value.upper()}] {self.title}: {self.message}"


@dataclass
class NotificationBatch:
    """A batch of notifications for grouped delivery."""
    id: str
    notifications: List[Notification]
    created_at: datetime
    channel: DeliveryChannel
    
    def combine_message(self) -> str:
        """Combine all notifications into one message."""
        lines = [f"📋 **{len(self.notifications)} Notifications**\n"]
        
        for notif in self.notifications:
            lines.append(f"• {notif.title}: {notif.message[:50]}...")
            
        return "\n".join(lines)


class NotificationQueue:
    """Queue for managing notification delivery."""
    
    def __init__(self, max_size: int = 1000):
        self.queue: deque = deque(maxlen=max_size)
        self.failed: deque = deque(maxlen=100)
        self.lock = asyncio.Lock()
        
    async def add(self, notification: Notification) -> None:
        """Add notification to queue."""
        async with self.lock:
            self.queue.append(notification)
            
    async def get_batch(
        self,
        max_count: int = 10,
        priority: NotificationPriority = None
    ) -> List[Notification]:
        """Get a batch of notifications."""
        async with self.lock:
            batch = []
            remaining = deque()
            
            while self.queue and len(batch) < max_count:
                notif = self.queue.popleft()
                if priority is None or notif.priority == priority:
                    batch.append(notif)
                else:
                    remaining.append(notif)
                    
            # Put back remaining
            self.queue.extendleft(remaining)
            
            return batch
            
    async def add_failed(self, notification: Notification) -> None:
        """Add to failed queue for retry."""
        async with self.lock:
            notification.delivery_attempts += 1
            if notification.delivery_attempts < notification.max_attempts:
                self.failed.append(notification)
                
    async def get_failed(self) -> List[Notification]:
        """Get failed notifications for retry."""
        async with self.lock:
            failed_list = list(self.failed)
            self.failed.clear()
            return failed_list
            
    def size(self) -> int:
        """Get queue size."""
        return len(self.queue)
        
    def failed_size(self) -> int:
        """Get failed queue size."""
        return len(self.failed)


class NotificationManager:
    """
    ═══════════════════════════════════════════════════════════════════════════
    CENTRAL NOTIFICATION MANAGER
    ═══════════════════════════════════════════════════════════════════════════
    
    Manages all notifications across the agent system.
    Coordinates delivery through multiple channels.
    Handles batching, retries, and priority.
    """
    
    # Batch settings
    BATCH_INTERVAL = 5  # seconds between batch processing
    MAX_BATCH_SIZE = 10
    
    # Rate limiting
    MAX_NOTIFICATIONS_PER_MINUTE = 30
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize notification manager.
        
        Args:
            config: Configuration dictionary
        """
        self.logger = logging.getLogger("notifications.manager")
        self.config = config or {}
        
        # Notification queue
        self.queue = NotificationQueue()
        
        # Delivery handlers (registered by channel)
        self._handlers: Dict[DeliveryChannel, Callable] = {}
        
        # History
        self.history: deque = deque(maxlen=500)
        
        # Rate limiting
        self._notification_times: deque = deque(maxlen=self.MAX_NOTIFICATIONS_PER_MINUTE)
        
        # Settings
        self.enabled = self.config.get('enabled', True)
        self.debug_mode = self.config.get('debug_mode', False)
        self.telegram_enabled = self.config.get('telegram_enabled', True)
        self.console_enabled = self.config.get('console_enabled', True)
        self.batch_mode = self.config.get('batch_mode', True)
        self.owner_notifications = self.config.get('owner_notifications', True)
        
        # Filters
        self.blocked_types: List[NotificationType] = []
        self.min_priority = NotificationPriority.NORMAL
        
        # Background task
        self._batch_task: Optional[asyncio.Task] = None
        self._running = False
        
        # Subscribers (for internal notification handling)
        self._subscribers: Dict[NotificationType, List[Callable]] = {}
        
    async def initialize(self) -> None:
        """Initialize the notification manager."""
        self.logger.info("Initializing notification manager...")
        
        # Register default handlers
        self._register_default_handlers()
        
        # Start batch processor
        if self.batch_mode:
            self._running = True
            self._batch_task = asyncio.create_task(self._batch_processor())
            
        self.logger.info("Notification manager initialized")
        
    def _register_default_handlers(self) -> None:
        """Register default delivery handlers."""
        # Console handler
        async def console_handler(notification: Notification) -> bool:
            if self.console_enabled:
                print(notification.format_for_console())
            return True
            
        self._handlers[DeliveryChannel.CONSOLE] = console_handler
        
        # Log handler
        async def log_handler(notification: Notification) -> bool:
            log_level = logging.INFO
            if notification.priority == NotificationPriority.CRITICAL:
                log_level = logging.ERROR
            elif notification.priority == NotificationPriority.DEBUG:
                log_level = logging.DEBUG
                
            self.logger.log(log_level, f"[{notification.type.value}] {notification.message}")
            return True
            
        self._handlers[DeliveryChannel.LOG] = log_handler
        
        # Queue handler (stores for later)
        async def queue_handler(notification: Notification) -> bool:
            await self.queue.add(notification)
            return True
            
        self._handlers[DeliveryChannel.QUEUE] = queue_handler
        
    def register_telegram_handler(
        self,
        handler: Callable[[Notification], Awaitable[bool]]
    ) -> None:
        """
        Register the Telegram delivery handler.
        
        Args:
            handler: Async function that sends to Telegram
        """
        self._handlers[DeliveryChannel.TELEGRAM] = handler
        self.logger.info("Telegram handler registered")
        
    async def notify(
        self,
        type: NotificationType,
        title: str,
        message: str,
        priority: NotificationPriority = NotificationPriority.NORMAL,
        details: Dict[str, Any] = None,
        channels: List[DeliveryChannel] = None,
        silent: bool = False
    ) -> str:
        """
        Send a notification.
        
        Args:
            type: Notification type
            title: Short title
            message: Notification message
            priority: Priority level
            details: Additional details
            channels: Delivery channels (None = ALL)
            silent: Silent delivery (no sound)
            
        Returns:
            Notification ID
        """
        if not self.enabled:
            return ""
            
        # Check filters
        if type in self.blocked_types:
            return ""
            
        if priority.value > self.min_priority.value:
            if not self.debug_mode:
                return ""
                
        # Rate limiting
        if not self._check_rate_limit():
            self.logger.warning("Rate limit exceeded, queueing notification")
            channels = [DeliveryChannel.QUEUE]
            
        # Create notification
        notification = Notification(
            id=str(uuid4())[:8],
            type=type,
            priority=priority,
            title=title,
            message=message,
            timestamp=datetime.utcnow(),
            details=details or {},
            channels=channels or [DeliveryChannel.ALL],
            silent=silent
        )
        
        # Deliver
        await self._deliver(notification)
        
        # Add to history
        self.history.append(notification)
        
        # Notify internal subscribers
        await self._notify_subscribers(notification)
        
        return notification.id
        
    async def _deliver(self, notification: Notification) -> None:
        """Deliver notification through specified channels."""
        channels = notification.channels
        
        if DeliveryChannel.ALL in channels:
            # Deliver to all registered handlers
            channels = list(self._handlers.keys())
            
        for channel in channels:
            if channel in self._handlers:
                try:
                    handler = self._handlers[channel]
                    success = await handler(notification)
                    
                    if success:
                        notification.delivered_to.append(channel.value)
                    else:
                        await self.queue.add_failed(notification)
                        
                except Exception as e:
                    self.logger.error(f"Delivery failed for {channel.value}: {e}")
                    await self.queue.add_failed(notification)
                    
    def _check_rate_limit(self) -> bool:
        """Check if within rate limit."""
        now = datetime.utcnow()
        
        # Remove old entries
        while self._notification_times and (now - self._notification_times[0]) > timedelta(minutes=1):
            self._notification_times.popleft()
            
        if len(self._notification_times) >= self.MAX_NOTIFICATIONS_PER_MINUTE:
            return False
            
        self._notification_times.append(now)
        return True
        
    async def _batch_processor(self) -> None:
        """Background task to process queued notifications."""
        while self._running:
            try:
                await asyncio.sleep(self.BATCH_INTERVAL)
                
                # Get batch from queue
                batch = await self.queue.get_batch(self.MAX_BATCH_SIZE)
                
                if batch:
                    # Create combined notification for Telegram
                    if DeliveryChannel.TELEGRAM in self._handlers and len(batch) > 3:
                        combined = NotificationBatch(
                            id=str(uuid4())[:8],
                            notifications=batch,
                            created_at=datetime.utcnow(),
                            channel=DeliveryChannel.TELEGRAM
                        )
                        # Send combined
                        await self._send_batch(combined)
                    else:
                        # Send individually
                        for notif in batch:
                            await self._deliver(notif)
                            
                # Process failed
                failed = await self.queue.get_failed()
                for notif in failed:
                    await self._deliver(notif)
                    
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Batch processor error: {e}")
                
    async def _send_batch(self, batch: NotificationBatch) -> None:
        """Send a batch of notifications as one message."""
        if DeliveryChannel.TELEGRAM in self._handlers:
            try:
                combined_notif = Notification(
                    id=batch.id,
                    type=NotificationType.SYSTEM_INFO,
                    priority=NotificationPriority.NORMAL,
                    title=f"📋 {len(batch.notifications)} Updates",
                    message=batch.combine_message(),
                    timestamp=batch.created_at,
                    channels=[DeliveryChannel.TELEGRAM],
                    silent=True
                )
                await self._handlers[DeliveryChannel.TELEGRAM](combined_notif)
            except Exception as e:
                self.logger.error(f"Batch send failed: {e}")
                
    def subscribe(
        self,
        type: NotificationType,
        callback: Callable[[Notification], Awaitable[None]]
    ) -> None:
        """
        Subscribe to notification type.
        
        Args:
            type: Notification type to subscribe to
            callback: Async callback function
        """
        if type not in self._subscribers:
            self._subscribers[type] = []
        self._subscribers[type].append(callback)
        
    async def _notify_subscribers(self, notification: Notification) -> None:
        """Notify internal subscribers."""
        if notification.type in self._subscribers:
            for callback in self._subscribers[notification.type]:
                try:
                    await callback(notification)
                except Exception as e:
                    self.logger.error(f"Subscriber callback error: {e}")
                    
    # ═══════════════════════════════════════════════════════════════════════════
    # CONVENIENCE METHODS FOR COMMON NOTIFICATIONS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def notify_memory_saved(
        self,
        key: str,
        value: Any,
        memory_type: str = "fact"
    ) -> str:
        """Notify of memory save."""
        return await self.notify(
            type=NotificationType.MEMORY_SAVED,
            title="Memory Saved",
            message=f"Saved {memory_type}: {key}",
            details={'key': key, 'value': str(value)[:100], 'type': memory_type}
        )
        
    async def notify_memory_updated(
        self,
        key: str,
        old_value: Any,
        new_value: Any
    ) -> str:
        """Notify of memory update."""
        return await self.notify(
            type=NotificationType.MEMORY_UPDATED,
            title="Memory Updated",
            message=f"Updated: {key}",
            details={'key': key, 'old': str(old_value)[:50], 'new': str(new_value)[:50]}
        )
        
    async def notify_memory_overwritten(
        self,
        key: str,
        reason: str
    ) -> str:
        """Notify of memory overwrite (agent decision)."""
        return await self.notify(
            type=NotificationType.MEMORY_OVERWRITTEN,
            title="Memory Overwritten",
            message=f"Agent rewrote: {key} - {reason}",
            priority=NotificationPriority.HIGH,
            details={'key': key, 'reason': reason}
        )
        
    async def notify_memory_conflict(
        self,
        key: str,
        memory_value: Any,
        reality_value: Any
    ) -> str:
        """Notify of memory vs reality conflict."""
        return await self.notify(
            type=NotificationType.MEMORY_CONFLICT,
            title="Memory Conflict Detected",
            message=f"Conflict for {key}: Memory says '{memory_value}' but reality shows '{reality_value}'. Reality wins!",
            priority=NotificationPriority.HIGH,
            details={'key': key, 'memory': str(memory_value), 'reality': str(reality_value)}
        )
        
    async def notify_learning(
        self,
        topic: str,
        summary: str
    ) -> str:
        """Notify of new learning."""
        return await self.notify(
            type=NotificationType.LEARNING_NEW,
            title="New Learning",
            message=f"Learned about {topic}: {summary}",
            details={'topic': topic, 'summary': summary}
        )
        
    async def notify_research_finding(
        self,
        topic: str,
        finding: str
    ) -> str:
        """Notify of research finding."""
        return await self.notify(
            type=NotificationType.RESEARCH_FINDING,
            title="Research Finding",
            message=f"Discovered about {topic}: {finding}",
            priority=NotificationPriority.HIGH,
            details={'topic': topic, 'finding': finding}
        )
        
    async def notify_error(
        self,
        error: str,
        critical: bool = False
    ) -> str:
        """Notify of error."""
        return await self.notify(
            type=NotificationType.ERROR_CRITICAL if critical else NotificationType.ERROR_WARNING,
            title="Error" if not critical else "Critical Error",
            message=error,
            priority=NotificationPriority.CRITICAL if critical else NotificationPriority.HIGH
        )
        
    async def notify_achievement(
        self,
        achievement: str,
        description: str
    ) -> str:
        """Notify of achievement."""
        return await self.notify(
            type=NotificationType.ACHIEVEMENT,
            title=f"🏆 Achievement: {achievement}",
            message=description,
            priority=NotificationPriority.HIGH
        )
        
    # ═══════════════════════════════════════════════════════════════════════════
    # MANAGEMENT METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def block_type(self, type: NotificationType) -> None:
        """Block a notification type."""
        if type not in self.blocked_types:
            self.blocked_types.append(type)
            
    def unblock_type(self, type: NotificationType) -> None:
        """Unblock a notification type."""
        if type in self.blocked_types:
            self.blocked_types.remove(type)
            
    def set_min_priority(self, priority: NotificationPriority) -> None:
        """Set minimum priority for notifications."""
        self.min_priority = priority
        
    def enable(self) -> None:
        """Enable notifications."""
        self.enabled = True
        
    def disable(self) -> None:
        """Disable notifications."""
        self.enabled = False
        
    def get_history(
        self,
        type: NotificationType = None,
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        """Get notification history."""
        history = list(self.history)
        
        if type:
            history = [n for n in history if n.type == type]
            
        return [n.to_dict() for n in history[-limit:]]
        
    def get_stats(self) -> Dict[str, Any]:
        """Get notification statistics."""
        type_counts = {}
        for notif in self.history:
            type_name = notif.type.value
            type_counts[type_name] = type_counts.get(type_name, 0) + 1
            
        return {
            'total_sent': len(self.history),
            'queue_size': self.queue.size(),
            'failed_size': self.queue.failed_size(),
            'by_type': type_counts,
            'enabled': self.enabled,
            'telegram_enabled': self.telegram_enabled,
            'batch_mode': self.batch_mode,
        }
        
    async def shutdown(self) -> None:
        """Shutdown the notification manager."""
        self.logger.info("Shutting down notification manager...")
        
        self._running = False
        
        if self._batch_task:
            self._batch_task.cancel()
            try:
                await self._batch_task
            except asyncio.CancelledError:
                pass
                
        # Final flush of queue
        remaining = await self.queue.get_batch(100)
        for notif in remaining:
            try:
                await self._deliver(notif)
            except:
                pass
                
        self.logger.info("Notification manager shutdown complete")