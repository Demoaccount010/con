#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 PERMANENT MEMORY - NEVER FORGOTTEN STORAGE
═══════════════════════════════════════════════════════════════════════════════

 Stores information that should NEVER be forgotten or expired.
 
 WHAT GOES IN PERMANENT MEMORY:
 ──────────────────────────────
 • Owner details (name, preferences, identity)
 • Agent identity (name, personality, values)
 • Core configuration
 • Critical system paths
 • First-run answers (asked once, saved forever)
 • Important learned facts explicitly marked permanent
 
 CHARACTERISTICS:
 ────────────────
 • Never expires
 • Never decays
 • Survives cleanup
 • Separate database for safety
 • Highly trusted (is_hint_only = False)
 • Can only be explicitly deleted
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import aiosqlite
import logging
import json
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass, field
from enum import Enum

# Import tagger for visible tags
import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from memory.core_memory.memory_tagger import MemoryTagger, MemoryTag, TaggedMemory


class PermanentCategory(Enum):
    """Categories for permanent memories."""
    OWNER = "owner"           # Owner information
    AGENT = "agent"           # Agent identity
    SYSTEM = "system"         # System configuration
    RELATIONSHIP = "relationship"  # Owner-agent relationship
    CRITICAL = "critical"     # Critical facts
    CONFIG = "config"         # Configuration values


@dataclass
class PermanentEntry:
    """A permanent memory entry."""
    id: str
    key: str
    value: Any
    category: PermanentCategory
    
    # Metadata
    source: str                   # Who stored this
    description: str              # What this is for
    
    # Timestamps
    created_at: datetime
    updated_at: datetime
    
    # Flags
    is_from_first_run: bool = False   # Set during initial setup
    is_protected: bool = True          # Extra protection
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'id': self.id,
            'key': self.key,
            'value': self.value,
            'category': self.category.value,
            'source': self.source,
            'description': self.description,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'is_from_first_run': self.is_from_first_run,
            'is_protected': self.is_protected,
        }


class PermanentMemory:
    """
    ═══════════════════════════════════════════════════════════════════════════
    PERMANENT MEMORY STORAGE
    ═══════════════════════════════════════════════════════════════════════════
    
    Manages never-expiring memories in a dedicated storage.
    """
    
    def __init__(
        self,
        db_path: Path,
        tagger: MemoryTagger = None
    ):
        """
        Initialize permanent memory.
        
        Args:
            db_path: Path to permanent database
            tagger: Memory tagger for visible tags
        """
        self.logger = logging.getLogger("memory.permanent")
        self.db_path = db_path
        self.tagger = tagger or MemoryTagger()
        
        # Database connection
        self._conn: Optional[aiosqlite.Connection] = None
        
        # Cache for fast access
        self._cache: Dict[str, PermanentEntry] = {}
        self._cache_loaded = False
        
        # Statistics
        self.stats = {
            'reads': 0,
            'writes': 0,
            'updates': 0,
            'cache_hits': 0,
        }
        
    async def initialize(self) -> None:
        """Initialize permanent memory storage."""
        self.logger.info("Initializing permanent memory storage")
        
        # Ensure directory exists
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Connect to database
        self._conn = await aiosqlite.connect(str(self.db_path))
        
        # Enable safety features
        await self._conn.execute("PRAGMA foreign_keys = ON")
        await self._conn.execute("PRAGMA journal_mode = WAL")
        
        # Create table
        await self._conn.execute("""
            CREATE TABLE IF NOT EXISTS permanent (
                id TEXT PRIMARY KEY,
                key TEXT NOT NULL UNIQUE,
                value TEXT NOT NULL,
                category TEXT NOT NULL,
                source TEXT DEFAULT 'system',
                description TEXT DEFAULT '',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                is_from_first_run INTEGER DEFAULT 0,
                is_protected INTEGER DEFAULT 1,
                metadata TEXT DEFAULT '{}'
            )
        """)
        
        # Create index
        await self._conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_permanent_category 
            ON permanent(category)
        """)
        
        await self._conn.commit()
        
        # Load cache
        await self._load_cache()
        
        self.logger.info(f"Permanent memory initialized ({len(self._cache)} entries)")
        
    async def _load_cache(self) -> None:
        """Load all permanent memories into cache."""
        cursor = await self._conn.execute("SELECT * FROM permanent")
        rows = await cursor.fetchall()
        
        self._cache.clear()
        for row in rows:
            entry = self._row_to_entry(row)
            self._cache[entry.key] = entry
            
        self._cache_loaded = True
        
    async def store(
        self,
        key: str,
        value: Any,
        category: PermanentCategory,
        source: str = "system",
        description: str = "",
        is_from_first_run: bool = False
    ) -> Tuple[PermanentEntry, TaggedMemory]:
        """
        Store a permanent memory.
        
        Args:
            key: Unique key
            value: Value to store
            category: Category
            source: Who stored this
            description: What this is for
            is_from_first_run: Is this from initial setup
            
        Returns:
            Tuple of (PermanentEntry, TaggedMemory)
        """
        self.stats['writes'] += 1
        
        now = datetime.utcnow()
        
        # Check if exists
        existing = await self.get(key)
        
        if existing:
            # Update existing
            return await self.update(key, value, f"Updated: {description}")
            
        # Generate ID
        import hashlib
        entry_id = hashlib.sha256(f"{key}:{now.isoformat()}".encode()).hexdigest()[:16]
        
        # Serialize value
        value_json = json.dumps(value, default=str)
        
        # Insert
        await self._conn.execute("""
            INSERT INTO permanent 
            (id, key, value, category, source, description, created_at, updated_at, is_from_first_run)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            entry_id, key, value_json, category.value,
            source, description, now.isoformat(), now.isoformat(),
            int(is_from_first_run)
        ))
        
        await self._conn.commit()
        
        # Create entry
        entry = PermanentEntry(
            id=entry_id,
            key=key,
            value=value,
            category=category,
            source=source,
            description=description,
            created_at=now,
            updated_at=now,
            is_from_first_run=is_from_first_run,
            is_protected=True
        )
        
        # Update cache
        self._cache[key] = entry
        
        # Generate tag
        tag = self.tagger.create_tag(
            MemoryTag.PERMANENT,
            key,
            new_value=value
        )
        
        self.logger.info(f"Permanent memory stored: {key}")
        
        return entry, tag
        
    async def get(self, key: str) -> Optional[PermanentEntry]:
        """
        Get a permanent memory by key.
        
        Args:
            key: Memory key
            
        Returns:
            PermanentEntry or None
        """
        self.stats['reads'] += 1
        
        # Check cache first
        if key in self._cache:
            self.stats['cache_hits'] += 1
            return self._cache[key]
            
        # Query database
        cursor = await self._conn.execute(
            "SELECT * FROM permanent WHERE key = ?", (key,)
        )
        row = await cursor.fetchone()
        
        if row:
            entry = self._row_to_entry(row)
            self._cache[key] = entry
            return entry
            
        return None
        
    async def get_value(self, key: str, default: Any = None) -> Any:
        """
        Get just the value of a permanent memory.
        
        Args:
            key: Memory key
            default: Default value if not found
            
        Returns:
            The value or default
        """
        entry = await self.get(key)
        return entry.value if entry else default
        
    async def update(
        self,
        key: str,
        value: Any,
        reason: str = ""
    ) -> Tuple[Optional[PermanentEntry], Optional[TaggedMemory]]:
        """
        Update a permanent memory.
        
        Args:
            key: Memory key
            value: New value
            reason: Reason for update
            
        Returns:
            Tuple of (PermanentEntry, TaggedMemory) or (None, None)
        """
        existing = await self.get(key)
        
        if not existing:
            self.logger.warning(f"Cannot update non-existent permanent memory: {key}")
            return None, None
            
        self.stats['updates'] += 1
        
        old_value = existing.value
        now = datetime.utcnow()
        
        # Update
        value_json = json.dumps(value, default=str)
        
        await self._conn.execute("""
            UPDATE permanent SET value = ?, updated_at = ? WHERE key = ?
        """, (value_json, now.isoformat(), key))
        
        await self._conn.commit()
        
        # Update entry
        existing.value = value
        existing.updated_at = now
        
        # Update cache
        self._cache[key] = existing
        
        # Generate tag
        tag = self.tagger.create_tag(
            MemoryTag.PERMANENT,
            key,
            new_value=value,
            old_value=old_value,
            reason=reason
        )
        
        self.logger.info(f"Permanent memory updated: {key}")
        
        return existing, tag
        
    async def delete(
        self,
        key: str,
        force: bool = False
    ) -> bool:
        """
        Delete a permanent memory.
        
        Requires force=True for protected entries.
        
        Args:
            key: Memory key
            force: Force delete protected entries
            
        Returns:
            True if deleted
        """
        existing = await self.get(key)
        
        if not existing:
            return False
            
        if existing.is_protected and not force:
            self.logger.warning(f"Cannot delete protected permanent memory: {key}")
            return False
            
        await self._conn.execute(
            "DELETE FROM permanent WHERE key = ?", (key,)
        )
        await self._conn.commit()
        
        # Remove from cache
        if key in self._cache:
            del self._cache[key]
            
        self.logger.info(f"Permanent memory deleted: {key}")
        
        return True
        
    async def get_by_category(
        self,
        category: PermanentCategory
    ) -> List[PermanentEntry]:
        """
        Get all entries in a category.
        
        Args:
            category: Category to filter
            
        Returns:
            List of entries
        """
        cursor = await self._conn.execute(
            "SELECT * FROM permanent WHERE category = ?",
            (category.value,)
        )
        rows = await cursor.fetchall()
        
        return [self._row_to_entry(row) for row in rows]
        
    async def get_all(self) -> List[PermanentEntry]:
        """Get all permanent memories."""
        return list(self._cache.values())
        
    async def get_owner_info(self) -> Dict[str, Any]:
        """
        Get all owner-related permanent memories.
        
        Returns:
            Dictionary of owner information
        """
        entries = await self.get_by_category(PermanentCategory.OWNER)
        return {e.key: e.value for e in entries}
        
    async def get_agent_identity(self) -> Dict[str, Any]:
        """
        Get agent identity information.
        
        Returns:
            Dictionary of agent identity
        """
        entries = await self.get_by_category(PermanentCategory.AGENT)
        return {e.key: e.value for e in entries}
        
    async def exists(self, key: str) -> bool:
        """Check if a permanent memory exists."""
        return key in self._cache or await self.get(key) is not None
        
    async def store_owner_detail(
        self,
        key: str,
        value: Any,
        description: str = ""
    ) -> Tuple[PermanentEntry, TaggedMemory]:
        """
        Convenience method to store owner details.
        
        Args:
            key: Detail key (e.g., "name", "timezone")
            value: Detail value
            description: What this is
        """
        full_key = f"owner_{key}" if not key.startswith("owner_") else key
        
        return await self.store(
            key=full_key,
            value=value,
            category=PermanentCategory.OWNER,
            source="owner",
            description=description or f"Owner's {key}",
            is_from_first_run=True
        )
        
    async def store_agent_detail(
        self,
        key: str,
        value: Any,
        description: str = ""
    ) -> Tuple[PermanentEntry, TaggedMemory]:
        """
        Convenience method to store agent identity details.
        
        Args:
            key: Detail key (e.g., "name", "personality")
            value: Detail value
            description: What this is
        """
        full_key = f"agent_{key}" if not key.startswith("agent_") else key
        
        return await self.store(
            key=full_key,
            value=value,
            category=PermanentCategory.AGENT,
            source="system",
            description=description or f"Agent's {key}",
            is_from_first_run=True
        )
        
    async def store_first_run_answer(
        self,
        key: str,
        value: Any,
        category: PermanentCategory = PermanentCategory.CONFIG
    ) -> Tuple[PermanentEntry, TaggedMemory]:
        """
        Store an answer from first-run wizard.
        
        These are asked ONCE and saved FOREVER.
        
        Args:
            key: Answer key
            value: Answer value
            category: Category
        """
        return await self.store(
            key=key,
            value=value,
            category=category,
            source="first_run_wizard",
            description="Answer from initial setup (never ask again)",
            is_from_first_run=True
        )
        
    async def get_first_run_answers(self) -> Dict[str, Any]:
        """Get all answers from first run."""
        result = {}
        
        for entry in self._cache.values():
            if entry.is_from_first_run:
                result[entry.key] = entry.value
                
        return result
        
    def _row_to_entry(self, row: tuple) -> PermanentEntry:
        """Convert database row to PermanentEntry."""
        return PermanentEntry(
            id=row[0],
            key=row[1],
            value=json.loads(row[2]) if row[2] else None,
            category=PermanentCategory(row[3]) if row[3] else PermanentCategory.CONFIG,
            source=row[4] or "system",
            description=row[5] or "",
            created_at=datetime.fromisoformat(row[6]) if row[6] else datetime.utcnow(),
            updated_at=datetime.fromisoformat(row[7]) if row[7] else datetime.utcnow(),
            is_from_first_run=bool(row[8]) if len(row) > 8 else False,
            is_protected=bool(row[9]) if len(row) > 9 else True
        )
        
    async def close(self) -> None:
        """Close database connection."""
        if self._conn:
            await self._conn.close()
            self._conn = None
        self.logger.info("Permanent memory closed")
        
    async def get_stats(self) -> Dict[str, Any]:
        """Get permanent memory statistics."""
        # Count by category
        by_category = {}
        for entry in self._cache.values():
            cat = entry.category.value
            by_category[cat] = by_category.get(cat, 0) + 1
            
        return {
            **self.stats,
            'total_entries': len(self._cache),
            'by_category': by_category,
            'first_run_entries': sum(1 for e in self._cache.values() if e.is_from_first_run),
        }
        
    async def export_all(self) -> Dict[str, Any]:
        """
        Export all permanent memories for backup.
        
        Returns:
            Dictionary with all entries
        """
        return {
            'exported_at': datetime.utcnow().isoformat(),
            'entries': [e.to_dict() for e in self._cache.values()]
        }
        
    async def import_backup(
        self,
        backup_data: Dict[str, Any],
        overwrite: bool = False
    ) -> int:
        """
        Import from backup.
        
        Args:
            backup_data: Exported backup data
            overwrite: Overwrite existing entries
            
        Returns:
            Number of entries imported
        """
        imported = 0
        
        for entry_dict in backup_data.get('entries', []):
            key = entry_dict.get('key')
            
            if not key:
                continue
                
            existing = await self.get(key)
            
            if existing and not overwrite:
                continue
                
            await self.store(
                key=key,
                value=entry_dict.get('value'),
                category=PermanentCategory(entry_dict.get('category', 'config')),
                source=entry_dict.get('source', 'import'),
                description=entry_dict.get('description', 'Imported from backup'),
                is_from_first_run=entry_dict.get('is_from_first_run', False)
            )
            
            imported += 1
            
        self.logger.info(f"Imported {imported} permanent memories from backup")
        
        return imported