"""
Main Agent Orchestrator - Coordinates all agent components
"""
import os
import time
from typing import Dict, List, Optional, Any
from pathlib import Path

try:
    from .core import (
        IntentDetector,
        MemorySystem,
        SkillGenerator,
        SelfUpdater,
        LearningEngine,
        PermissionManager,
        SkillRegistry
    )
    from .utils import setup_logger, timestamp
    from .config import LOGS_DIR
except ImportError:
    from core import (
        IntentDetector,
        MemorySystem,
        SkillGenerator,
        SelfUpdater,
        LearningEngine,
        PermissionManager,
        SkillRegistry
    )
    from utils import setup_logger, timestamp
    from config import LOGS_DIR

class AutonomousAgent:
    """
    Main autonomous agent that coordinates all components
    """
    
    def __init__(self, name: str = "Agent"):
        """Initialize the Autonomous Agent"""
        self.name = name
        self.logger = setup_logger(
            self.__class__.__name__,
            log_file=str(LOGS_DIR / "agent.log")
        )
        
        # Initialize all core components
        self.logger.info("Initializing agent components...")
        
        # Initialize Ollama Brain first (other components may use it)
        try:
            from core.ollama_brain import OllamaBrain
            self.ollama_brain = OllamaBrain()
            self.logger.info("Ollama Brain initialized")
        except Exception as e:
            self.logger.warning(f"Ollama Brain not available: {e}")
            self.ollama_brain = None
        
        # Initialize core components with brain integration
        self.intent_detector = IntentDetector(ollama_brain=self.ollama_brain)
        self.memory = MemorySystem()
        self.skill_generator = SkillGenerator(
            ollama_brain=self.ollama_brain,
            github_token=os.getenv('GITHUB_TOKEN')
        )
        self.self_updater = SelfUpdater()
        self.learning_engine = LearningEngine()
        self.permission_manager = PermissionManager()
        self.skill_registry = SkillRegistry()
        
        # Initialize proactive assistant
        try:
            from core.proactive_assistant import ProactiveAssistant
            self.proactive_assistant = ProactiveAssistant(
                memory_system=self.memory,
                learning_engine=self.learning_engine
            )
            self.logger.info("Proactive Assistant initialized")
        except Exception as e:
            self.logger.warning(f"Proactive Assistant not available: {e}")
            self.proactive_assistant = None
        
        # Initialize system control skills
        try:
            from skills.system_control import (
                BrowserSkill, FileSkill, ProcessSkill, 
                SystemSkill, AutomationSkill
            )
            self.browser_skill = BrowserSkill()
            self.file_skill = FileSkill()
            self.process_skill = ProcessSkill()
            self.system_skill = SystemSkill()
            self.automation_skill = AutomationSkill()
            self.logger.info("System control skills initialized")
        except Exception as e:
            self.logger.warning(f"System control skills not available: {e}")
            self.browser_skill = None
            self.file_skill = None
            self.process_skill = None
            self.system_skill = None
            self.automation_skill = None
        
        self.conversation_history = []
        self.is_running = False
        
        self.logger.info(f"Agent '{name}' initialized successfully")
    
    def process(self, user_input: str) -> Dict:
        """
        Process user input and generate response
        
        Args:
            user_input: Natural language input from user
        
        Returns:
            Dict with response and metadata
        """
        start_time = time.time()
        self.logger.info(f"Processing input: {user_input[:100]}...")
        
        try:
            # Step 1: Detect intent
            intent_result = self.intent_detector.detect(
                user_input,
                context=self._get_context()
            )
            
            # Step 2: Check if permission is needed
            if intent_result['requires_permission']:
                permission = self.permission_manager.request_permission(
                    operation_type=intent_result['intent'],
                    description=user_input,
                    risk_level=self._assess_risk_level(intent_result)
                )
                
                if not permission['approved']:
                    return self._create_response(
                        success=False,
                        message="Permission denied by user",
                        intent=intent_result,
                        duration_ms=int((time.time() - start_time) * 1000)
                    )
            
            # Step 3: Retrieve relevant memories
            relevant_memories = self.memory.search_similar(user_input, top_k=3)
            
            # Step 4: Execute action based on intent
            action_result = self._execute_intent(intent_result, user_input)
            
            # Step 5: Store in memory
            self.memory.store_short_term(
                content=user_input,
                memory_type="user_input"
            )
            
            self.memory.store_episode(
                user_input=user_input,
                agent_response=action_result.get('message', ''),
                intent=intent_result['intent'],
                outcome='success' if action_result['success'] else 'failure',
                duration_ms=int((time.time() - start_time) * 1000)
            )
            
            # Step 6: Record feedback for learning
            self.learning_engine.record_feedback(
                intent=intent_result['intent'],
                action=action_result.get('action', 'unknown'),
                outcome='success' if action_result['success'] else 'failure',
                feedback_score=action_result.get('score', 0.5)
            )
            
            # Step 7: Update conversation history
            self.conversation_history.append({
                'timestamp': timestamp(),
                'user_input': user_input,
                'intent': intent_result['intent'],
                'response': action_result.get('message', '')
            })
            
            duration_ms = int((time.time() - start_time) * 1000)
            
            self.logger.info(f"Processed successfully in {duration_ms}ms")
            
            return self._create_response(
                success=action_result['success'],
                message=action_result.get('message', ''),
                intent=intent_result,
                data=action_result.get('data'),
                duration_ms=duration_ms
            )
            
        except Exception as e:
            self.logger.error(f"Error processing input: {e}", exc_info=True)
            return self._create_response(
                success=False,
                message=f"Error: {str(e)}",
                intent=None,
                duration_ms=int((time.time() - start_time) * 1000)
            )
    
    def _execute_intent(self, intent_result: Dict, user_input: str) -> Dict:
        """Execute the detected intent"""
        intent = intent_result['intent']
        entities = intent_result['entities']
        
        self.logger.debug(f"Executing intent: {intent}")
        
        # Route to appropriate handler
        if intent == 'create':
            return self._handle_create(entities, user_input)
        elif intent == 'read':
            return self._handle_read(entities, user_input)
        elif intent == 'update':
            return self._handle_update(entities, user_input)
        elif intent == 'delete':
            return self._handle_delete(entities, user_input)
        elif intent == 'execute':
            return self._handle_execute(entities, user_input)
        elif intent == 'learn':
            return self._handle_learn(entities, user_input)
        elif intent == 'search':
            return self._handle_search(entities, user_input)
        elif intent == 'analyze':
            return self._handle_analyze(entities, user_input)
        elif intent == 'help':
            return self._handle_help(entities, user_input)
        else:
            return {
                'success': False,
                'message': f"Unknown intent: {intent}",
                'action': 'unknown'
            }
    
    def _handle_create(self, entities: Dict, user_input: str) -> Dict:
        """Handle create/generation requests"""
        # Check if user wants to create a new skill
        if 'skill' in entities or 'function' in user_input.lower():
            # Try generating with Ollama if available
            if self.ollama_brain and self.ollama_brain.enabled:
                skill_info = self.skill_generator.generate_with_ollama(user_input)
            else:
                skill_info = self.skill_generator.generate_from_description(user_input)
            
            if skill_info:
                # Compile the skill
                func = self.skill_generator.compile_skill(skill_info)
                
                if func:
                    # Register the skill
                    self.skill_registry.register_skill(
                        name=skill_info['name'],
                        description=skill_info['description'],
                        code=skill_info['code'],
                        parameters=skill_info['parameters']
                    )
                    
                    return {
                        'success': True,
                        'message': f"Created skill: {skill_info['name']}",
                        'action': 'create_skill',
                        'data': skill_info,
                        'score': 1.0
                    }
        
        # Check if user wants to learn from GitHub
        if 'github' in user_input.lower() and ('repo' in user_input.lower() or 'repository' in user_input.lower()):
            # Extract URL if present
            import re
            url_match = re.search(r'https://github\.com/[\w-]+/[\w-]+', user_input)
            if url_match:
                repo_url = url_match.group(0)
                skill_name = entities.get('skill', ['github_skill'])[0] if entities.get('skill') else 'github_skill'
                
                return {
                    'success': True,
                    'message': f"Learning from GitHub repository...",
                    'action': 'learn_from_github',
                    'data': {'repo_url': repo_url, 'skill_name': skill_name},
                    'score': 0.9
                }
        
        return {
            'success': True,
            'message': "I can help you create something. What would you like to create?",
            'action': 'create_prompt',
            'score': 0.5
        }
    
    def _handle_read(self, entities: Dict, user_input: str) -> Dict:
        """Handle read/retrieval requests"""
        # Check what to read
        if 'skill' in user_input.lower():
            skills = self.skill_registry.list_skills()
            return {
                'success': True,
                'message': f"Found {len(skills)} skills",
                'action': 'list_skills',
                'data': skills,
                'score': 1.0
            }
        elif 'memory' in user_input.lower() or 'remember' in user_input.lower():
            memories = self.memory.recall_short_term(limit=5)
            return {
                'success': True,
                'message': f"Retrieved {len(memories)} recent memories",
                'action': 'recall_memory',
                'data': memories,
                'score': 1.0
            }
        elif 'statistic' in user_input.lower() or 'stats' in user_input.lower():
            stats = self.get_statistics()
            return {
                'success': True,
                'message': "Agent statistics",
                'action': 'get_stats',
                'data': stats,
                'score': 1.0
            }
        
        return {
            'success': True,
            'message': "What would you like to read or retrieve?",
            'action': 'read_prompt',
            'score': 0.5
        }
    
    def _handle_update(self, entities: Dict, user_input: str) -> Dict:
        """Handle update/modification requests"""
        return {
            'success': True,
            'message': "Update functionality - specify what to update",
            'action': 'update_prompt',
            'score': 0.5
        }
    
    def _handle_delete(self, entities: Dict, user_input: str) -> Dict:
        """Handle delete/removal requests"""
        return {
            'success': True,
            'message': "Delete functionality - specify what to delete",
            'action': 'delete_prompt',
            'score': 0.5
        }
    
    def _handle_execute(self, entities: Dict, user_input: str) -> Dict:
        """Handle execution requests"""
        # Check if a skill name is mentioned
        for skill_name in self.skill_generator.generated_skills.keys():
            if skill_name in user_input.lower():
                func = self.skill_generator.get_skill(skill_name)
                if func:
                    try:
                        result = func()
                        return {
                            'success': True,
                            'message': f"Executed {skill_name}",
                            'action': 'execute_skill',
                            'data': result,
                            'score': 1.0
                        }
                    except Exception as e:
                        return {
                            'success': False,
                            'message': f"Error executing {skill_name}: {e}",
                            'action': 'execute_skill',
                            'score': 0.0
                        }
        
        return {
            'success': True,
            'message': "Specify what to execute",
            'action': 'execute_prompt',
            'score': 0.5
        }
    
    def _handle_learn(self, entities: Dict, user_input: str) -> Dict:
        """Handle learning requests"""
        # Store as long-term memory
        self.memory.store_long_term(
            content=user_input,
            importance=0.8,
            memory_type="learned_info",
            tags=['user_taught']
        )
        
        return {
            'success': True,
            'message': "I've learned and stored that information",
            'action': 'learn',
            'score': 1.0
        }
    
    def _handle_search(self, entities: Dict, user_input: str) -> Dict:
        """Handle search requests"""
        # Search in memories
        results = self.memory.search_similar(user_input, top_k=5)
        
        return {
            'success': True,
            'message': f"Found {len(results)} relevant results",
            'action': 'search',
            'data': results,
            'score': 1.0
        }
    
    def _handle_analyze(self, entities: Dict, user_input: str) -> Dict:
        """Handle analysis requests"""
        # Analyze performance
        analysis = self.learning_engine.analyze_performance(days_back=7)
        
        return {
            'success': True,
            'message': "Performance analysis",
            'action': 'analyze',
            'data': analysis,
            'score': 1.0
        }
    
    def _handle_help(self, entities: Dict, user_input: str) -> Dict:
        """Handle help requests"""
        help_text = """
I'm an autonomous AI agent with self-learning capabilities. I can:
- Create new skills and functions
- Learn from your feedback
- Remember information
- Execute tasks
- Analyze my own performance
- Improve over time

Try asking me to:
- "Create a skill to..."
- "Learn this information..."
- "Show me your skills"
- "Analyze your performance"
- "Remember that..."
"""
        return {
            'success': True,
            'message': help_text,
            'action': 'help',
            'score': 1.0
        }
    
    def _get_context(self) -> Dict:
        """Get current conversation context"""
        context = {
            'conversation_active': len(self.conversation_history) > 0,
            'previous_intent': None,
            'entities': {},
            'conversation_history': []
        }
        
        if self.conversation_history:
            last_interaction = self.conversation_history[-1]
            context['previous_intent'] = last_interaction['intent']
            
            # Add recent conversation history
            context['conversation_history'] = [
                {
                    'user': msg.get('user_input', ''),
                    'agent': msg.get('response', ''),
                    'intent': msg.get('intent', '')
                }
                for msg in self.conversation_history[-5:]  # Last 5 messages
            ]
        
        return context
    
    def _assess_risk_level(self, intent_result: Dict):
        """Assess risk level of an intent"""
        try:
            from .core.permission_manager import PermissionLevel
        except ImportError:
            from core.permission_manager import PermissionLevel
        
        intent = intent_result['intent']
        
        if intent in ['delete', 'update']:
            return PermissionLevel.MEDIUM_RISK
        elif intent == 'execute':
            return PermissionLevel.HIGH_RISK
        else:
            return PermissionLevel.LOW_RISK
    
    def _create_response(self, success: bool, message: str, intent: Dict = None,
                        data: Any = None, duration_ms: int = 0) -> Dict:
        """Create a standardized response"""
        return {
            'success': success,
            'message': message,
            'intent': intent,
            'data': data,
            'duration_ms': duration_ms,
            'timestamp': timestamp()
        }
    
    def get_statistics(self) -> Dict:
        """Get comprehensive agent statistics"""
        try:
            intent_stats = self.intent_detector.get_statistics()
        except Exception as e:
            self.logger.error(f"Error getting intent stats: {e}")
            intent_stats = {}
        
        try:
            memory_stats = self.memory.get_statistics()
        except Exception as e:
            self.logger.error(f"Error getting memory stats: {e}")
            memory_stats = {}
        
        try:
            learning_stats = self.learning_engine.get_learning_statistics()
        except Exception as e:
            self.logger.error(f"Error getting learning stats: {e}")
            learning_stats = {}
        
        try:
            permission_stats = self.permission_manager.get_statistics()
        except Exception as e:
            self.logger.error(f"Error getting permission stats: {e}")
            permission_stats = {}
        
        try:
            skill_stats = self.skill_registry.get_statistics()
        except Exception as e:
            self.logger.error(f"Error getting skill stats: {e}")
            skill_stats = {}
        
        return {
            'agent_name': self.name,
            'intent_detector': intent_stats,
            'memory': memory_stats,
            'learning': learning_stats,
            'permissions': permission_stats,
            'skills': skill_stats,
            'conversation_length': len(self.conversation_history)
        }
    
    def start(self):
        """Start the agent (for interactive mode)"""
        self.is_running = True
        self.logger.info(f"Agent '{self.name}' started")
        print(f"\n🤖 {self.name} is ready! Type 'exit' to quit.\n")
        
        while self.is_running:
            try:
                user_input = input("You: ").strip()
                
                if user_input.lower() in ['exit', 'quit', 'bye']:
                    self.stop()
                    break
                
                if not user_input:
                    continue
                
                response = self.process(user_input)
                print(f"\n{self.name}: {response['message']}\n")
                
                if response.get('data'):
                    print(f"[Data: {response['data']}]\n")
                
            except KeyboardInterrupt:
                self.stop()
                break
            except Exception as e:
                print(f"\nError: {e}\n")
                self.logger.error(f"Interactive mode error: {e}", exc_info=True)
    
    def stop(self):
        """Stop the agent"""
        self.is_running = False
        
        # Consolidate memories
        promoted = self.memory.consolidate_memories()
        self.logger.info(f"Consolidated {promoted} memories")
        
        # Cleanup old data
        cleaned = self.memory.cleanup_old_memories()
        self.logger.info(f"Cleaned up {cleaned} old memories")
        
        self.logger.info(f"Agent '{self.name}' stopped")
        print(f"\n👋 {self.name} signing off. Goodbye!\n")
