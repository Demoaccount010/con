#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 HEALTH MONITOR - SYSTEM HEALTH & DIAGNOSTICS
═══════════════════════════════════════════════════════════════════════════════

 Monitors the health of all agent components and system resources.
 
 MONITORS:
 ─────────
 • Component health   - Brain, Memory, Tools, LLM, Telegram
 • System resources   - CPU, RAM, Disk, Network
 • Service status     - Ollama, Database, External APIs
 • Performance metrics - Response times, error rates
 • Self-diagnostics   - Internal consistency checks
 
 ACTIONS:
 ────────
 • Health checks      - Periodic and on-demand
 • Alerts             - Notify on critical issues
 • Auto-recovery      - Attempt to fix issues
 • Reporting          - Generate health reports
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
import psutil
import time
import platform
import socket
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Callable, Awaitable, Tuple
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
import aiohttp
import aiosqlite


class HealthStatus(Enum):
    """Health status levels."""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    CRITICAL = "critical"
    UNKNOWN = "unknown"


class ComponentType(Enum):
    """Types of components to monitor."""
    BRAIN = "brain"
    MEMORY = "memory"
    TOOLS = "tools"
    LLM = "llm"
    TELEGRAM = "telegram"
    DATABASE = "database"
    NETWORK = "network"
    FILESYSTEM = "filesystem"
    AGENT_LOOP = "agent_loop"
    NOTIFICATIONS = "notifications"
    CACHE = "cache"


@dataclass
class ComponentHealth:
    """Health status of a single component."""
    component: ComponentType
    status: HealthStatus
    message: str
    last_check: datetime
    
    # Metrics
    response_time_ms: Optional[float] = None
    error_count: int = 0
    success_rate: float = 1.0
    
    # Details
    details: Dict[str, Any] = field(default_factory=dict)
    issues: List[str] = field(default_factory=list)
    
    def is_healthy(self) -> bool:
        """Check if component is healthy."""
        return self.status in [HealthStatus.HEALTHY, HealthStatus.DEGRADED]
        
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'component': self.component.value,
            'status': self.status.value,
            'message': self.message,
            'last_check': self.last_check.isoformat(),
            'response_time_ms': self.response_time_ms,
            'error_count': self.error_count,
            'success_rate': self.success_rate,
            'details': self.details,
            'issues': self.issues,
        }


@dataclass
class SystemResources:
    """Current system resource usage."""
    cpu_percent: float
    memory_percent: float
    memory_used_gb: float
    memory_total_gb: float
    disk_percent: float
    disk_used_gb: float
    disk_total_gb: float
    
    # Network (optional)
    network_bytes_sent: int = 0
    network_bytes_recv: int = 0
    
    # Process-specific
    process_cpu: float = 0.0
    process_memory_mb: float = 0.0
    process_threads: int = 0
    
    # Limits
    cpu_limit: float = 80.0
    memory_limit: float = 80.0
    disk_limit: float = 90.0
    
    def is_healthy(self) -> bool:
        """Check if resources are within limits."""
        return (
            self.cpu_percent < self.cpu_limit and
            self.memory_percent < self.memory_limit and
            self.disk_percent < self.disk_limit
        )
        
    def get_issues(self) -> List[str]:
        """Get list of resource issues."""
        issues = []
        if self.cpu_percent >= self.cpu_limit:
            issues.append(f"High CPU usage: {self.cpu_percent:.1f}%")
        if self.memory_percent >= self.memory_limit:
            issues.append(f"High memory usage: {self.memory_percent:.1f}%")
        if self.disk_percent >= self.disk_limit:
            issues.append(f"Low disk space: {100 - self.disk_percent:.1f}% free")
        return issues
        
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'cpu_percent': self.cpu_percent,
            'memory_percent': self.memory_percent,
            'memory_used_gb': self.memory_used_gb,
            'memory_total_gb': self.memory_total_gb,
            'disk_percent': self.disk_percent,
            'disk_used_gb': self.disk_used_gb,
            'disk_total_gb': self.disk_total_gb,
            'process_cpu': self.process_cpu,
            'process_memory_mb': self.process_memory_mb,
            'healthy': self.is_healthy(),
            'issues': self.get_issues(),
        }


@dataclass
class HealthReport:
    """Complete health report."""
    timestamp: datetime
    overall_status: HealthStatus
    
    # Components
    components: Dict[str, ComponentHealth]
    
    # Resources
    resources: SystemResources
    
    # Summary
    healthy_count: int = 0
    degraded_count: int = 0
    unhealthy_count: int = 0
    critical_count: int = 0
    
    # Issues and recommendations
    all_issues: List[str] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'timestamp': self.timestamp.isoformat(),
            'overall_status': self.overall_status.value,
            'components': {k: v.to_dict() for k, v in self.components.items()},
            'resources': self.resources.to_dict(),
            'summary': {
                'healthy': self.healthy_count,
                'degraded': self.degraded_count,
                'unhealthy': self.unhealthy_count,
                'critical': self.critical_count,
            },
            'issues': self.all_issues,
            'recommendations': self.recommendations,
        }
        
    def format_summary(self) -> str:
        """Format as readable summary."""
        status_icons = {
            HealthStatus.HEALTHY: "🟢",
            HealthStatus.DEGRADED: "🟡",
            HealthStatus.UNHEALTHY: "🔴",
            HealthStatus.CRITICAL: "⛔",
            HealthStatus.UNKNOWN: "⚪",
        }
        
        lines = [
            f"═══ Health Report ═══",
            f"Status: {status_icons.get(self.overall_status, '❓')} {self.overall_status.value.upper()}",
            f"Time: {self.timestamp.strftime('%Y-%m-%d %H:%M:%S')}",
            "",
            "Components:",
        ]
        
        for name, health in self.components.items():
            icon = status_icons.get(health.status, "❓")
            lines.append(f"  {icon} {name}: {health.status.value}")
            
        lines.extend([
            "",
            "Resources:",
            f"  CPU: {self.resources.cpu_percent:.1f}%",
            f"  Memory: {self.resources.memory_percent:.1f}%",
            f"  Disk: {self.resources.disk_percent:.1f}%",
        ])
        
        if self.all_issues:
            lines.extend(["", "Issues:"])
            for issue in self.all_issues[:5]:
                lines.append(f"  ⚠️ {issue}")
                
        if self.recommendations:
            lines.extend(["", "Recommendations:"])
            for rec in self.recommendations[:3]:
                lines.append(f"  💡 {rec}")
                
        return "\n".join(lines)


class HealthMonitor:
    """
    ═══════════════════════════════════════════════════════════════════════════
    SYSTEM HEALTH MONITOR
    ═══════════════════════════════════════════════════════════════════════════
    
    Monitors all aspects of the autonomous agent system.
    Provides health checks, alerts, and recovery actions.
    """
    
    # Check intervals
    DEFAULT_CHECK_INTERVAL = 60  # seconds
    RESOURCE_CHECK_INTERVAL = 30  # seconds
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize health monitor.
        
        Args:
            config: Configuration dictionary
        """
        self.logger = logging.getLogger("health.monitor")
        self.config = config or {}
        
        # Component health checkers
        self._checkers: Dict[ComponentType, Callable] = {}
        
        # Health history
        self._health_history: List[HealthReport] = []
        self._max_history = self.config.get('max_history', 100)
        
        # Current status
        self._component_health: Dict[str, ComponentHealth] = {}
        self._last_check: Optional[datetime] = None
        
        # External services to check
        self._ollama_url = self.config.get('ollama_url', 'http://localhost:11434')
        self._database_path = self.config.get('database_path', 'memory/data/memory.db')
        
        # Alert callbacks
        self._alert_callbacks: List[Callable] = []
        
        # Background task
        self._monitor_task: Optional[asyncio.Task] = None
        self._running = False
        
        # Thresholds
        self._thresholds = {
            'cpu_warning': self.config.get('cpu_warning', 70),
            'cpu_critical': self.config.get('cpu_critical', 90),
            'memory_warning': self.config.get('memory_warning', 70),
            'memory_critical': self.config.get('memory_critical', 90),
            'disk_warning': self.config.get('disk_warning', 80),
            'disk_critical': self.config.get('disk_critical', 95),
            'response_time_warning': self.config.get('response_time_warning', 5000),  # ms
            'error_rate_warning': self.config.get('error_rate_warning', 0.1),  # 10%
        }
        
        # Stats
        self._stats = {
            'total_checks': 0,
            'alerts_sent': 0,
            'recoveries_attempted': 0,
            'recoveries_successful': 0,
        }
        
    async def initialize(self) -> None:
        """Initialize the health monitor."""
        self.logger.info("Initializing health monitor...")
        
        # Register default checkers
        self._register_default_checkers()
        
        # Run initial check
        await self.check_all()
        
        self.logger.info("Health monitor initialized")
        
    def _register_default_checkers(self) -> None:
        """Register default health checkers."""
        self._checkers[ComponentType.LLM] = self._check_llm
        self._checkers[ComponentType.DATABASE] = self._check_database
        self._checkers[ComponentType.NETWORK] = self._check_network
        self._checkers[ComponentType.FILESYSTEM] = self._check_filesystem
        
    def register_checker(
        self,
        component: ComponentType,
        checker: Callable[[], Awaitable[ComponentHealth]]
    ) -> None:
        """
        Register a custom health checker.
        
        Args:
            component: Component type
            checker: Async function that returns ComponentHealth
        """
        self._checkers[component] = checker
        self.logger.debug(f"Registered checker for {component.value}")
        
    def register_alert_callback(
        self,
        callback: Callable[[HealthReport], Awaitable[None]]
    ) -> None:
        """Register callback for health alerts."""
        self._alert_callbacks.append(callback)
        
    async def start_monitoring(self) -> None:
        """Start background health monitoring."""
        if self._running:
            return
            
        self._running = True
        self._monitor_task = asyncio.create_task(self._monitoring_loop())
        self.logger.info("Health monitoring started")
        
    async def stop_monitoring(self) -> None:
        """Stop background monitoring."""
        self._running = False
        if self._monitor_task:
            self._monitor_task.cancel()
            try:
                await self._monitor_task
            except asyncio.CancelledError:
                pass
        self.logger.info("Health monitoring stopped")
        
    async def _monitoring_loop(self) -> None:
        """Background monitoring loop."""
        while self._running:
            try:
                await asyncio.sleep(self.DEFAULT_CHECK_INTERVAL)
                report = await self.check_all()
                
                # Alert if issues found
                if report.overall_status in [HealthStatus.UNHEALTHY, HealthStatus.CRITICAL]:
                    await self._send_alerts(report)
                    
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Monitoring loop error: {e}")
                
    async def check_all(self) -> HealthReport:
        """
        Run all health checks and generate report.
        
        Returns:
            Complete health report
        """
        self._stats['total_checks'] += 1
        timestamp = datetime.utcnow()
        
        # Check all components
        component_results: Dict[str, ComponentHealth] = {}
        
        for component_type, checker in self._checkers.items():
            try:
                health = await checker()
                component_results[component_type.value] = health
                self._component_health[component_type.value] = health
            except Exception as e:
                self.logger.error(f"Health check failed for {component_type.value}: {e}")
                component_results[component_type.value] = ComponentHealth(
                    component=component_type,
                    status=HealthStatus.UNKNOWN,
                    message=f"Check failed: {str(e)}",
                    last_check=timestamp,
                    issues=[str(e)]
                )
                
        # Get system resources
        resources = await self._get_system_resources()
        
        # Calculate overall status
        overall_status = self._calculate_overall_status(component_results, resources)
        
        # Count by status
        status_counts = {
            'healthy': 0,
            'degraded': 0,
            'unhealthy': 0,
            'critical': 0,
        }
        
        for health in component_results.values():
            if health.status == HealthStatus.HEALTHY:
                status_counts['healthy'] += 1
            elif health.status == HealthStatus.DEGRADED:
                status_counts['degraded'] += 1
            elif health.status == HealthStatus.UNHEALTHY:
                status_counts['unhealthy'] += 1
            elif health.status == HealthStatus.CRITICAL:
                status_counts['critical'] += 1
                
        # Collect all issues
        all_issues = []
        for health in component_results.values():
            all_issues.extend(health.issues)
        all_issues.extend(resources.get_issues())
        
        # Generate recommendations
        recommendations = self._generate_recommendations(component_results, resources)
        
        # Create report
        report = HealthReport(
            timestamp=timestamp,
            overall_status=overall_status,
            components=component_results,
            resources=resources,
            healthy_count=status_counts['healthy'],
            degraded_count=status_counts['degraded'],
            unhealthy_count=status_counts['unhealthy'],
            critical_count=status_counts['critical'],
            all_issues=all_issues,
            recommendations=recommendations,
        )
        
        # Add to history
        self._health_history.append(report)
        if len(self._health_history) > self._max_history:
            self._health_history = self._health_history[-self._max_history:]
            
        self._last_check = timestamp
        
        return report
        
    async def check_component(self, component: ComponentType) -> ComponentHealth:
        """Check a specific component."""
        if component not in self._checkers:
            return ComponentHealth(
                component=component,
                status=HealthStatus.UNKNOWN,
                message="No checker registered",
                last_check=datetime.utcnow()
            )
            
        try:
            return await self._checkers[component]()
        except Exception as e:
            return ComponentHealth(
                component=component,
                status=HealthStatus.UNKNOWN,
                message=f"Check failed: {str(e)}",
                last_check=datetime.utcnow(),
                issues=[str(e)]
            )
            
    # ═══════════════════════════════════════════════════════════════════════════
    # DEFAULT HEALTH CHECKERS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _check_llm(self) -> ComponentHealth:
        """Check Ollama LLM health."""
        start_time = time.perf_counter()
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{self._ollama_url}/api/tags",
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as response:
                    response_time = (time.perf_counter() - start_time) * 1000
                    
                    if response.status == 200:
                        data = await response.json()
                        models = data.get('models', [])
                        
                        return ComponentHealth(
                            component=ComponentType.LLM,
                            status=HealthStatus.HEALTHY,
                            message=f"Ollama running with {len(models)} models",
                            last_check=datetime.utcnow(),
                            response_time_ms=response_time,
                            details={'models': len(models), 'url': self._ollama_url}
                        )
                    else:
                        return ComponentHealth(
                            component=ComponentType.LLM,
                            status=HealthStatus.DEGRADED,
                            message=f"Ollama returned status {response.status}",
                            last_check=datetime.utcnow(),
                            response_time_ms=response_time,
                            issues=[f"HTTP {response.status}"]
                        )
                        
        except asyncio.TimeoutError:
            return ComponentHealth(
                component=ComponentType.LLM,
                status=HealthStatus.UNHEALTHY,
                message="Ollama connection timeout",
                last_check=datetime.utcnow(),
                issues=["Connection timeout"]
            )
        except Exception as e:
            return ComponentHealth(
                component=ComponentType.LLM,
                status=HealthStatus.CRITICAL,
                message=f"Ollama not accessible: {str(e)}",
                last_check=datetime.utcnow(),
                issues=[str(e)]
            )
            
    async def _check_database(self) -> ComponentHealth:
        """Check database health."""
        start_time = time.perf_counter()
        db_path = Path(self._database_path)
        
        try:
            if not db_path.exists():
                return ComponentHealth(
                    component=ComponentType.DATABASE,
                    status=HealthStatus.UNHEALTHY,
                    message="Database file not found",
                    last_check=datetime.utcnow(),
                    issues=["Database file missing"]
                )
                
            async with aiosqlite.connect(str(db_path)) as db:
                # Simple query to check connection
                cursor = await db.execute("SELECT 1")
                await cursor.fetchone()
                
                # Get database size
                db_size = db_path.stat().st_size / (1024 * 1024)  # MB
                
                response_time = (time.perf_counter() - start_time) * 1000
                
                return ComponentHealth(
                    component=ComponentType.DATABASE,
                    status=HealthStatus.HEALTHY,
                    message=f"Database accessible ({db_size:.1f} MB)",
                    last_check=datetime.utcnow(),
                    response_time_ms=response_time,
                    details={'size_mb': db_size, 'path': str(db_path)}
                )
                
        except Exception as e:
            return ComponentHealth(
                component=ComponentType.DATABASE,
                status=HealthStatus.CRITICAL,
                message=f"Database error: {str(e)}",
                last_check=datetime.utcnow(),
                issues=[str(e)]
            )
            
    async def _check_network(self) -> ComponentHealth:
        """Check network connectivity."""
        start_time = time.perf_counter()
        
        try:
            # Check DNS resolution
            await asyncio.get_event_loop().run_in_executor(
                None, socket.gethostbyname, "google.com"
            )
            
            # Quick HTTP check
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    "https://httpbin.org/ip",
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as response:
                    response_time = (time.perf_counter() - start_time) * 1000
                    
                    if response.status == 200:
                        return ComponentHealth(
                            component=ComponentType.NETWORK,
                            status=HealthStatus.HEALTHY,
                            message="Network connectivity OK",
                            last_check=datetime.utcnow(),
                            response_time_ms=response_time
                        )
                        
        except Exception as e:
            return ComponentHealth(
                component=ComponentType.NETWORK,
                status=HealthStatus.DEGRADED,
                message=f"Network issues: {str(e)}",
                last_check=datetime.utcnow(),
                issues=["Internet connectivity issues"]
            )
            
        return ComponentHealth(
            component=ComponentType.NETWORK,
            status=HealthStatus.UNKNOWN,
            message="Network check incomplete",
            last_check=datetime.utcnow()
        )
        
    async def _check_filesystem(self) -> ComponentHealth:
        """Check filesystem health."""
        try:
            # Check important directories
            required_dirs = ['memory', 'logs', 'config']
            missing_dirs = []
            
            for dir_name in required_dirs:
                if not Path(dir_name).exists():
                    missing_dirs.append(dir_name)
                    
            if missing_dirs:
                return ComponentHealth(
                    component=ComponentType.FILESYSTEM,
                    status=HealthStatus.DEGRADED,
                    message=f"Missing directories: {missing_dirs}",
                    last_check=datetime.utcnow(),
                    issues=[f"Missing: {d}" for d in missing_dirs]
                )
                
            # Check write permissions
            test_file = Path('logs/.health_check_test')
            try:
                test_file.touch()
                test_file.unlink()
            except Exception:
                return ComponentHealth(
                    component=ComponentType.FILESYSTEM,
                    status=HealthStatus.UNHEALTHY,
                    message="Cannot write to logs directory",
                    last_check=datetime.utcnow(),
                    issues=["Write permission denied"]
                )
                
            return ComponentHealth(
                component=ComponentType.FILESYSTEM,
                status=HealthStatus.HEALTHY,
                message="Filesystem OK",
                last_check=datetime.utcnow()
            )
            
        except Exception as e:
            return ComponentHealth(
                component=ComponentType.FILESYSTEM,
                status=HealthStatus.UNKNOWN,
                message=f"Filesystem check error: {str(e)}",
                last_check=datetime.utcnow(),
                issues=[str(e)]
            )
            
    # ═══════════════════════════════════════════════════════════════════════════
    # SYSTEM RESOURCES
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _get_system_resources(self) -> SystemResources:
        """Get current system resource usage."""
        try:
            # CPU
            cpu_percent = psutil.cpu_percent(interval=0.1)
            
            # Memory
            memory = psutil.virtual_memory()
            memory_percent = memory.percent
            memory_used_gb = memory.used / (1024 ** 3)
            memory_total_gb = memory.total / (1024 ** 3)
            
            # Disk
            disk = psutil.disk_usage('/')
            disk_percent = disk.percent
            disk_used_gb = disk.used / (1024 ** 3)
            disk_total_gb = disk.total / (1024 ** 3)
            
            # Network
            net = psutil.net_io_counters()
            
            # Process-specific
            process = psutil.Process()
            process_cpu = process.cpu_percent()
            process_memory = process.memory_info().rss / (1024 ** 2)  # MB
            process_threads = process.num_threads()
            
            return SystemResources(
                cpu_percent=cpu_percent,
                memory_percent=memory_percent,
                memory_used_gb=memory_used_gb,
                memory_total_gb=memory_total_gb,
                disk_percent=disk_percent,
                disk_used_gb=disk_used_gb,
                disk_total_gb=disk_total_gb,
                network_bytes_sent=net.bytes_sent,
                network_bytes_recv=net.bytes_recv,
                process_cpu=process_cpu,
                process_memory_mb=process_memory,
                process_threads=process_threads,
            )
            
        except Exception as e:
            self.logger.error(f"Failed to get system resources: {e}")
            return SystemResources(
                cpu_percent=0,
                memory_percent=0,
                memory_used_gb=0,
                memory_total_gb=0,
                disk_percent=0,
                disk_used_gb=0,
                disk_total_gb=0,
            )
            
    def _calculate_overall_status(
        self,
        components: Dict[str, ComponentHealth],
        resources: SystemResources
    ) -> HealthStatus:
        """Calculate overall system health status."""
        # Check for critical components
        critical_components = [ComponentType.LLM.value, ComponentType.DATABASE.value]
        
        for comp_name in critical_components:
            if comp_name in components:
                if components[comp_name].status == HealthStatus.CRITICAL:
                    return HealthStatus.CRITICAL
                    
        # Count statuses
        unhealthy_count = sum(
            1 for h in components.values()
            if h.status in [HealthStatus.UNHEALTHY, HealthStatus.CRITICAL]
        )
        
        degraded_count = sum(
            1 for h in components.values()
            if h.status == HealthStatus.DEGRADED
        )
        
        # Check resources
        resource_issues = resources.get_issues()
        
        if unhealthy_count > 0 or len(resource_issues) >= 2:
            return HealthStatus.UNHEALTHY
        elif degraded_count > 0 or len(resource_issues) >= 1:
            return HealthStatus.DEGRADED
        else:
            return HealthStatus.HEALTHY
            
    def _generate_recommendations(
        self,
        components: Dict[str, ComponentHealth],
        resources: SystemResources
    ) -> List[str]:
        """Generate recommendations based on health status."""
        recommendations = []
        
        # Resource recommendations
        if resources.memory_percent > 80:
            recommendations.append("Consider increasing system memory or reducing memory usage")
        if resources.disk_percent > 85:
            recommendations.append("Clean up disk space - less than 15% remaining")
        if resources.cpu_percent > 90:
            recommendations.append("High CPU usage detected - check for runaway processes")
            
        # Component recommendations
        for name, health in components.items():
            if health.status == HealthStatus.CRITICAL:
                recommendations.append(f"Critical: Fix {name} immediately")
            elif health.status == HealthStatus.UNHEALTHY:
                recommendations.append(f"Investigate issues with {name}")
                
        return recommendations
        
    async def _send_alerts(self, report: HealthReport) -> None:
        """Send alerts for health issues."""
        self._stats['alerts_sent'] += 1
        
        for callback in self._alert_callbacks:
            try:
                await callback(report)
            except Exception as e:
                self.logger.error(f"Alert callback failed: {e}")
                
    # ═══════════════════════════════════════════════════════════════════════════
    # PUBLIC API
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_status(self) -> Dict[str, Any]:
        """Get current health status."""
        return {
            'last_check': self._last_check.isoformat() if self._last_check else None,
            'components': {k: v.to_dict() for k, v in self._component_health.items()},
            'stats': self._stats.copy(),
        }
        
    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get health check history."""
        return [r.to_dict() for r in self._health_history[-limit:]]
        
    async def get_quick_status(self) -> Tuple[HealthStatus, str]:
        """Get quick status summary."""
        if not self._last_check or (datetime.utcnow() - self._last_check) > timedelta(minutes=5):
            report = await self.check_all()
        else:
            # Use cached status
            statuses = [h.status for h in self._component_health.values()]
            if HealthStatus.CRITICAL in statuses:
                return HealthStatus.CRITICAL, "Critical issues detected"
            elif HealthStatus.UNHEALTHY in statuses:
                return HealthStatus.UNHEALTHY, "Some components unhealthy"
            elif HealthStatus.DEGRADED in statuses:
                return HealthStatus.DEGRADED, "System degraded"
            else:
                return HealthStatus.HEALTHY, "All systems operational"
                
        return report.overall_status, report.format_summary()
        
    async def shutdown(self) -> None:
        """Shutdown health monitor."""
        await self.stop_monitoring()
        self.logger.info("Health monitor shutdown complete")