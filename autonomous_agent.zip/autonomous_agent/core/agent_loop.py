#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 AGENT LOOP - MANDATORY THINK→PLAN→ACT→OBSERVE→RETHINK CYCLE
═══════════════════════════════════════════════════════════════════════════════

 This is the HEART of the autonomous agent.
 
 EVERY user input MUST go through this loop. NO EXCEPTIONS.
 
 LOOP PHASES:
 ────────────
 1. THINK      - Understand, classify, get memory hints
 2. PLAN       - Break into steps, identify tools
 3. VERIFY     - Check for guessing, validate
 4. EXECUTE    - Run tools one at a time
 5. OBSERVE    - Analyze results
 6. RETHINK    - Re-evaluate, can change decision
 7. RESPOND    - Generate output with memory tags
 
 CRITICAL RULES:
 ───────────────
 • NO phase can be skipped
 • NEVER guess - always verify
 • Memory is HINT, not answer
 • Reality WINS over memory
 • Show ALL memory tags
 • Follow ALL user commands
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
import time
from datetime import datetime
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass, field
from enum import Enum
from uuid import uuid4

# Core imports
from core.planner import Planner, Plan, PlanStep
from core.executor import Executor, ExecutionResult
from core.observer import Observer, ObservationResult
from core.auditor import Auditor
from core.state_manager import StateManager
from core.command_obedience import CommandObedience

# Brain imports
from brain.brain_controller import BrainController, BrainInput, BrainOutput, ThinkingMode

# Memory imports
from memory.memory_manager import MemoryManager, MemoryType, MemoryChange

# Tool imports
from tools.registry import ToolRegistry

# Security imports
from security.security_manager import SecurityManager

# Output imports
from output.output_manager import OutputManager, MemoryTag

# Notification imports
from notifications.notification_manager import NotificationManager


class LoopPhase(Enum):
    """Current phase of the agent loop."""
    IDLE = "idle"
    RECEIVING = "receiving"
    THINKING = "thinking"
    PLANNING = "planning"
    VERIFYING = "verifying"
    EXECUTING = "executing"
    OBSERVING = "observing"
    RETHINKING = "rethinking"
    RESPONDING = "responding"
    COMPLETE = "complete"
    ERROR = "error"


class TaskType(Enum):
    """Classification of incoming tasks."""
    CHAT = "chat"                    # Simple conversation
    SYSTEM = "system"                # System operations
    CODE = "code"                    # Code generation/execution
    DATA = "data"                    # Data processing
    AUTOMATION = "automation"        # Automated workflows
    QUERY = "query"                  # Information retrieval
    FILE = "file"                    # File operations
    NETWORK = "network"              # Network operations
    COMMAND = "command"              # Direct command execution
    LEARNING = "learning"            # Learning/teaching
    UNKNOWN = "unknown"              # Cannot classify


@dataclass
class LoopContext:
    """Context maintained throughout a single loop execution."""
    loop_id: str
    user_input: str
    start_time: datetime
    
    # Current state
    phase: LoopPhase = LoopPhase.IDLE
    task_type: TaskType = TaskType.UNKNOWN
    
    # Results from each phase
    brain_output: Optional[BrainOutput] = None
    plan: Optional[Plan] = None
    execution_results: List[ExecutionResult] = field(default_factory=list)
    observations: List[ObservationResult] = field(default_factory=list)
    
    # Memory interactions
    memory_hints: Dict[str, Any] = field(default_factory=dict)
    memory_changes: List[MemoryChange] = field(default_factory=list)
    
    # Rethinking
    rethink_count: int = 0
    rethink_reasons: List[str] = field(default_factory=list)
    
    # Final output
    response: str = ""
    success: bool = False
    
    # Errors and warnings
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    
    # Timing
    phase_timings: Dict[str, int] = field(default_factory=dict)
    
    def add_error(self, error: str) -> None:
        """Add an error."""
        self.errors.append(error)
        
    def add_warning(self, warning: str) -> None:
        """Add a warning."""
        self.warnings.append(warning)
        
    def record_phase_time(self, phase: str, duration_ms: int) -> None:
        """Record timing for a phase."""
        self.phase_timings[phase] = duration_ms


@dataclass
class LoopResult:
    """Final result of a loop execution."""
    loop_id: str
    success: bool
    response: str
    
    # Details
    task_type: str
    phases_completed: List[str]
    
    # Memory changes for display
    memory_changes: List[Dict[str, Any]]
    
    # Reasoning
    thinking_summary: str
    confidence: float
    
    # Errors
    errors: List[str]
    warnings: List[str]
    
    # Performance
    total_duration_ms: int
    phase_timings: Dict[str, int]
    
    # For output formatting
    def to_output_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for output manager."""
        return {
            'success': self.success,
            'response': self.response,
            'task_type': self.task_type,
            'memory_changes': self.memory_changes,
            'thinking_summary': self.thinking_summary,
            'confidence': self.confidence,
            'errors': self.errors,
            'warnings': self.warnings,
            'duration_ms': self.total_duration_ms,
        }


class AgentLoop:
    """
    ═══════════════════════════════════════════════════════════════════════════
    MAIN AGENT EXECUTION LOOP
    ═══════════════════════════════════════════════════════════════════════════
    
    Processes all user input through the mandatory loop.
    Coordinates between brain, memory, tools, and output.
    """
    
    # Configuration
    MAX_RETHINK_ITERATIONS = 3
    MAX_EXECUTION_STEPS = 20
    DEFAULT_TIMEOUT = 120  # seconds
    
    def __init__(
        self,
        brain: BrainController,
        memory: MemoryManager,
        tools: ToolRegistry,
        security: SecurityManager,
        state: StateManager,
        notifications: NotificationManager,
        obedience: CommandObedience,
        output: OutputManager,
        config: Dict[str, Any] = None
    ):
        """
        Initialize the agent loop.
        
        Args:
            brain: Brain controller for thinking
            memory: Memory manager
            tools: Tool registry
            security: Security manager
            state: State manager
            notifications: Notification manager
            obedience: Command obedience handler
            output: Output manager
            config: Configuration
        """
        self.logger = logging.getLogger("core.agent_loop")
        
        # Core components
        self.brain = brain
        self.memory = memory
        self.tools = tools
        self.security = security
        self.state = state
        self.notifications = notifications
        self.obedience = obedience
        self.output = output
        self.config = config or {}
        
        # Sub-components (initialized in initialize())
        self.planner: Optional[Planner] = None
        self.executor: Optional[Executor] = None
        self.observer: Optional[Observer] = None
        self.auditor: Optional[Auditor] = None
        
        # Current context
        self.current_context: Optional[LoopContext] = None
        
        # Lock for single execution
        self._execution_lock = asyncio.Lock()
        
        # Statistics
        self.stats = {
            'total_loops': 0,
            'successful_loops': 0,
            'failed_loops': 0,
            'total_rethinks': 0,
            'avg_duration_ms': 0,
        }
        
    async def initialize(self) -> None:
        """Initialize all loop components."""
        self.logger.info("Initializing agent loop...")
        
        # Initialize planner
        self.planner = Planner(
            memory=self.memory,
            tools=self.tools,
            config=self.config.get('planner', {})
        )
        await self.planner.initialize()
        
        # Initialize executor
        self.executor = Executor(
            tools=self.tools,
            security=self.security,
            memory=self.memory,
            config=self.config.get('executor', {})
        )
        await self.executor.initialize()
        
        # Initialize observer
        self.observer = Observer(
            memory=self.memory,
            config=self.config.get('observer', {})
        )
        await self.observer.initialize()
        
        # Initialize auditor
        self.auditor = Auditor(
            security=self.security,
            memory=self.memory,
            config=self.config.get('auditor', {})
        )
        await self.auditor.initialize()
        
        self.logger.info("Agent loop initialized")
        
    async def process(self, user_input: str) -> LoopResult:
        """
        Process user input through the complete loop.
        
        THIS IS THE MAIN ENTRY POINT.
        
        Args:
            user_input: Raw user input string
            
        Returns:
            LoopResult with response and metadata
        """
        async with self._execution_lock:
            return await self._process_internal(user_input)
            
    async def _process_internal(self, user_input: str) -> LoopResult:
        """Internal processing implementation."""
        loop_id = str(uuid4())[:8]
        start_time = datetime.utcnow()
        start_perf = time.perf_counter()
        
        self.logger.info(f"[{loop_id}] Processing: {user_input[:50]}...")
        self.stats['total_loops'] += 1
        
        # Create context
        context = LoopContext(
            loop_id=loop_id,
            user_input=user_input,
            start_time=start_time,
            phase=LoopPhase.RECEIVING
        )
        self.current_context = context
        
        # Update state
        await self.state.set_current_task(loop_id, user_input)
        
        try:
            # ═══════════════════════════════════════════════════════════════
            # PHASE 1: THINK
            # ═══════════════════════════════════════════════════════════════
            phase_start = time.perf_counter()
            self.logger.debug(f"[{loop_id}] PHASE 1: THINK")
            context.phase = LoopPhase.THINKING
            
            # Check for direct commands first
            is_command, command_result = await self.obedience.check_command(user_input)
            if is_command and command_result.execute_directly:
                # Direct command - skip normal processing
                context.response = command_result.response
                context.success = command_result.success
                context.phase = LoopPhase.COMPLETE
                return self._create_result(context, start_perf)
                
            # Get memory hints (NOT answers!)
            context.memory_hints = await self._get_memory_hints(user_input)
            
            # Think with brain
            brain_input = BrainInput(
                text=user_input,
                context={
                    'memory_hints': context.memory_hints,
                    'available_tools': self.tools.list_all_names(),
                },
                require_verification=True,
                allow_rethink=True,
                thinking_mode=ThinkingMode.ANALYTICAL
            )
            
            context.brain_output = await self.brain.process(brain_input)
            context.task_type = self._classify_task(user_input, context.brain_output)
            
            context.record_phase_time('thinking', int((time.perf_counter() - phase_start) * 1000))
            
            # Check if brain needs clarification
            if not context.brain_output.success and context.brain_output.errors:
                if 'clarification' in str(context.brain_output.errors).lower():
                    context.response = context.brain_output.response
                    context.phase = LoopPhase.COMPLETE
                    return self._create_result(context, start_perf)
                    
            # ═══════════════════════════════════════════════════════════════
            # PHASE 2: PLAN
            # ═══════════════════════════════════════════════════════════════
            phase_start = time.perf_counter()
            self.logger.debug(f"[{loop_id}] PHASE 2: PLAN")
            context.phase = LoopPhase.PLANNING
            
            context.plan = await self.planner.create_plan(
                task=user_input,
                task_type=context.task_type,
                brain_output=context.brain_output,
                memory_hints=context.memory_hints
            )
            
            context.record_phase_time('planning', int((time.perf_counter() - phase_start) * 1000))
            
            # Check if plan is empty (chat/simple response)
            if not context.plan.steps or context.plan.is_chat_only:
                context.response = context.brain_output.response
                context.success = True
                context.phase = LoopPhase.COMPLETE
                return self._create_result(context, start_perf)
                
            # ═══════════════════════════════════════════════════════════════
            # PHASE 3: VERIFY (No Guessing!)
            # ═══════════════════════════════════════════════════════════════
            phase_start = time.perf_counter()
            self.logger.debug(f"[{loop_id}] PHASE 3: VERIFY")
            context.phase = LoopPhase.VERIFYING
            
            verification = await self.auditor.verify_plan(context.plan)
            
            if not verification.passed:
                if verification.needs_clarification:
                    context.response = self._format_clarification(verification.questions)
                    context.add_warning("Clarification needed before execution")
                    context.phase = LoopPhase.COMPLETE
                    return self._create_result(context, start_perf)
                elif verification.blocked:
                    context.add_error(f"Plan blocked: {verification.reason}")
                    context.response = f"⛔ Cannot proceed: {verification.reason}"
                    context.phase = LoopPhase.ERROR
                    return self._create_result(context, start_perf)
                    
            context.record_phase_time('verifying', int((time.perf_counter() - phase_start) * 1000))
            
            # ═══════════════════════════════════════════════════════════════
            # PHASE 4 & 5: EXECUTE + OBSERVE (Loop)
            # ═══════════════════════════════════════════════════════════════
            phase_start = time.perf_counter()
            self.logger.debug(f"[{loop_id}] PHASE 4/5: EXECUTE + OBSERVE")
            context.phase = LoopPhase.EXECUTING
            
            step_index = 0
            while step_index < len(context.plan.steps) and step_index < self.MAX_EXECUTION_STEPS:
                current_step = context.plan.steps[step_index]
                
                # Execute step
                self.logger.debug(f"[{loop_id}] Executing step {step_index + 1}: {current_step.description}")
                
                exec_result = await self.executor.execute_step(
                    step=current_step,
                    context={
                        'loop_id': loop_id,
                        'previous_results': context.execution_results,
                    }
                )
                context.execution_results.append(exec_result)
                
                # Observe result
                context.phase = LoopPhase.OBSERVING
                observation = await self.observer.observe(
                    step=current_step,
                    result=exec_result,
                    memory_hints=context.memory_hints
                )
                context.observations.append(observation)
                
                # Check for memory updates from tool output
                if observation.memory_updates:
                    for update in observation.memory_updates:
                        context.memory_changes.append(update)
                        
                # Handle observation result
                if observation.success:
                    step_index += 1
                elif observation.should_retry and context.rethink_count < self.MAX_RETHINK_ITERATIONS:
                    # Retry same step
                    self.logger.debug(f"[{loop_id}] Retrying step {step_index + 1}")
                    context.rethink_count += 1
                elif observation.should_stop:
                    self.logger.debug(f"[{loop_id}] Stopping execution: {observation.stop_reason}")
                    context.add_warning(f"Stopped: {observation.stop_reason}")
                    break
                else:
                    # Move to next step despite failure
                    step_index += 1
                    
                context.phase = LoopPhase.EXECUTING
                
            context.record_phase_time('executing', int((time.perf_counter() - phase_start) * 1000))
            
            # ═══════════════════════════════════════════════════════════════
            # PHASE 6: RETHINK
            # ═══════════════════════════════════════════════════════════════
            phase_start = time.perf_counter()
            self.logger.debug(f"[{loop_id}] PHASE 6: RETHINK")
            context.phase = LoopPhase.RETHINKING
            
            rethink_result = await self._rethink(context)
            
            if rethink_result.changed:
                context.rethink_count += 1
                context.rethink_reasons.append(rethink_result.reason)
                self.stats['total_rethinks'] += 1
                
            context.record_phase_time('rethinking', int((time.perf_counter() - phase_start) * 1000))
            
            # ═══════════════════════════════════════════════════════════════
            # PHASE 7: RESPOND
            # ═══════════════════════════════════════════════════════════════
            phase_start = time.perf_counter()
            self.logger.debug(f"[{loop_id}] PHASE 7: RESPOND")
            context.phase = LoopPhase.RESPONDING
            
            context.response = await self._generate_response(context)
            context.success = len(context.errors) == 0
            
            context.record_phase_time('responding', int((time.perf_counter() - phase_start) * 1000))
            
            # ═══════════════════════════════════════════════════════════════
            # COMPLETE
            # ═══════════════════════════════════════════════════════════════
            context.phase = LoopPhase.COMPLETE
            
            # Collect memory changes from memory manager
            pending_changes = self.memory.get_pending_changes()
            for change in pending_changes:
                context.memory_changes.append(MemoryChange(
                    change_type=change.get('type', 'SAVED'),
                    key=change.get('key', ''),
                    old_value=change.get('old_value'),
                    new_value=change.get('new_value'),
                    reason=change.get('reason', '')
                ))
            self.memory.clear_pending_changes()
            
            # Update stats
            if context.success:
                self.stats['successful_loops'] += 1
            else:
                self.stats['failed_loops'] += 1
                
            return self._create_result(context, start_perf)
            
        except asyncio.TimeoutError:
            context.phase = LoopPhase.ERROR
            context.add_error("Operation timed out")
            self.stats['failed_loops'] += 1
            return self._create_result(context, start_perf)
            
        except Exception as e:
            self.logger.error(f"[{loop_id}] Error: {e}", exc_info=True)
            context.phase = LoopPhase.ERROR
            context.add_error(str(e))
            self.stats['failed_loops'] += 1
            return self._create_result(context, start_perf)
            
        finally:
            self.current_context = None
            await self.state.clear_current_task()
            
    async def _get_memory_hints(self, user_input: str) -> Dict[str, Any]:
        """
        Get memory hints for the input.
        
        IMPORTANT: These are HINTS, not answers!
        """
        hints = await self.memory.get_hints(
            query=user_input,
            include_facts=True,
            include_skills=True,
            include_failures=True,
            limit=10
        )
        
        # Add the critical warning
        hints['_warning'] = 'USE AS HINTS ONLY - THINK FRESH - VERIFY BEFORE TRUSTING'
        
        return hints
        
    def _classify_task(
        self,
        user_input: str,
        brain_output: BrainOutput
    ) -> TaskType:
        """Classify the task type."""
        text_lower = user_input.lower()
        
        # Keywords for each type
        type_keywords = {
            TaskType.SYSTEM: ['restart', 'status', 'service', 'process', 'disk', 'memory', 'cpu', 'install'],
            TaskType.FILE: ['file', 'read', 'write', 'create', 'delete', 'move', 'copy', 'folder', 'directory'],
            TaskType.CODE: ['code', 'script', 'function', 'program', 'debug', 'run', 'execute'],
            TaskType.DATA: ['parse', 'json', 'yaml', 'csv', 'data', 'convert'],
            TaskType.NETWORK: ['http', 'request', 'api', 'download', 'ping', 'dns'],
            TaskType.AUTOMATION: ['schedule', 'cron', 'automate', 'every', 'daily'],
            TaskType.QUERY: ['what', 'how', 'why', 'explain', 'show', 'list', 'tell me'],
            TaskType.CHAT: ['hello', 'hi', 'thanks', 'help', 'who are you'],
            TaskType.COMMAND: ['do', 'run', 'execute', 'make'],
            TaskType.LEARNING: ['remember', 'learn', 'note', 'save'],
        }
        
        # Score each type
        scores = {t: 0 for t in TaskType}
        for task_type, keywords in type_keywords.items():
            for keyword in keywords:
                if keyword in text_lower:
                    scores[task_type] += 1
                    
        # Get highest scoring type
        best_type = max(scores, key=scores.get)
        
        if scores[best_type] == 0:
            return TaskType.UNKNOWN
            
        return best_type
        
    async def _rethink(self, context: LoopContext) -> 'RethinkResult':
        """
        Rethink phase - re-evaluate and potentially change approach.
        """
        @dataclass
        class RethinkResult:
            changed: bool
            reason: str
            new_plan: Optional[Plan] = None
            
        # Check if we should rethink
        if not context.execution_results:
            return RethinkResult(changed=False, reason="No execution to rethink")
            
        # Analyze execution results
        failures = [r for r in context.execution_results if not r.success]
        
        if not failures:
            return RethinkResult(changed=False, reason="All executions successful")
            
        if context.rethink_count >= self.MAX_RETHINK_ITERATIONS:
            return RethinkResult(changed=False, reason="Max rethink iterations reached")
            
        # We have failures - analyze and decide
        failure_reasons = [f.error for f in failures if f.error]
        
        # Check if failures are fixable
        fixable_patterns = ['permission', 'not found', 'timeout', 'retry']
        is_fixable = any(
            pattern in str(failure_reasons).lower()
            for pattern in fixable_patterns
        )
        
        if not is_fixable:
            return RethinkResult(changed=False, reason="Failures not fixable by rethinking")
            
        # Try to create alternative plan
        self.logger.info(f"Rethinking due to failures: {failure_reasons}")
        
        # For now, just mark that we rethought
        return RethinkResult(
            changed=True,
            reason=f"Reconsidered approach due to: {failure_reasons[0][:50]}"
        )
        
    async def _generate_response(self, context: LoopContext) -> str:
        """Generate the final response."""
        parts = []
        
        # Add brain response if available
        if context.brain_output and context.brain_output.response:
            parts.append(context.brain_output.response)
            
        # Add execution results summary
        if context.execution_results:
            successful = sum(1 for r in context.execution_results if r.success)
            total = len(context.execution_results)
            
            if total > 0:
                parts.append(f"\n**Execution:** {successful}/{total} steps completed")
                
                for i, result in enumerate(context.execution_results):
                    status = "✓" if result.success else "✗"
                    summary = result.summary or result.output[:100] if result.output else "No output"
                    parts.append(f"  {status} Step {i+1}: {summary}")
                    
        # Add observations insights
        for obs in context.observations:
            if obs.insights:
                parts.append(f"\n**Insight:** {obs.insights}")
                
        # Add errors
        if context.errors:
            parts.append("\n**Errors:**")
            for error in context.errors:
                parts.append(f"  ❌ {error}")
                
        # Fallback if nothing to say
        if not parts:
            parts.append("Task processed.")
            
        return "\n".join(parts)
        
    def _format_clarification(self, questions: List[str]) -> str:
        """Format clarification questions."""
        lines = ["I need clarification before proceeding:\n"]
        for q in questions:
            lines.append(f"  ❓ {q}")
        return "\n".join(lines)
        
    def _create_result(
        self,
        context: LoopContext,
        start_perf: float
    ) -> LoopResult:
        """Create the final loop result."""
        total_duration = int((time.perf_counter() - start_perf) * 1000)
        
        # Update average duration
        n = self.stats['total_loops']
        if n == 1:
            self.stats['avg_duration_ms'] = total_duration
        else:
            self.stats['avg_duration_ms'] = (
                (self.stats['avg_duration_ms'] * (n - 1) + total_duration) / n
            )
            
        # Build phases completed list
        phases_completed = []
        for phase in LoopPhase:
            if phase.value in context.phase_timings:
                phases_completed.append(phase.value)
                
        # Format memory changes
        memory_changes = []
        for change in context.memory_changes:
            memory_changes.append({
                'type': change.change_type,
                'key': change.key,
                'old_value': change.old_value,
                'new_value': change.new_value,
                'reason': change.reason,
            })
            
        return LoopResult(
            loop_id=context.loop_id,
            success=context.success,
            response=context.response,
            task_type=context.task_type.value,
            phases_completed=phases_completed,
            memory_changes=memory_changes,
            thinking_summary=context.brain_output.thinking_summary if context.brain_output else "",
            confidence=context.brain_output.confidence if context.brain_output else 0.0,
            errors=context.errors,
            warnings=context.warnings,
            total_duration_ms=total_duration,
            phase_timings=context.phase_timings
        )
        
    def get_stats(self) -> Dict[str, Any]:
        """Get loop statistics."""
        return self.stats.copy()
        
    async def shutdown(self) -> None:
        """Shutdown the loop."""
        self.logger.info("Shutting down agent loop")
        
        if self.executor:
            await self.executor.shutdown()