"""
Learning Engine - Learns from feedback and improves performance
"""
import json
import sqlite3
from typing import Dict, List, Optional
from datetime import datetime, timedelta
from pathlib import Path
from collections import defaultdict

try:
    from ..utils import setup_logger, timestamp
    from ..config import DATA_DIR, LEARNING_RATE, MIN_FEEDBACK_FOR_LEARNING, SUCCESS_THRESHOLD
except ImportError:
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from utils import setup_logger, timestamp
    from config import DATA_DIR, LEARNING_RATE, MIN_FEEDBACK_FOR_LEARNING, SUCCESS_THRESHOLD

class LearningEngine:
    """
    Learns from user feedback and agent performance to improve over time
    """
    
    def __init__(self, db_path: Path = None):
        """Initialize Learning Engine"""
        self.logger = setup_logger(self.__class__.__name__)
        self.db_path = db_path or DATA_DIR / "learning.db"
        self._initialize_db()
        self.learning_metrics = defaultdict(lambda: {'successes': 0, 'failures': 0})
        
        # NEW: Initialize advanced learning
        try:
            from .advanced_learning import AdvancedLearning
            self.advanced_learning = AdvancedLearning()
            self.logger.info("Advanced learning enabled")
        except Exception as e:
            self.logger.warning(f"Advanced learning not available: {e}")
            self.advanced_learning = None
        
        self.logger.info("Learning Engine initialized")
    
    def _initialize_db(self):
        """Initialize database for learning data"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Feedback table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                intent TEXT NOT NULL,
                action TEXT NOT NULL,
                outcome TEXT NOT NULL,
                feedback_score REAL,
                user_feedback TEXT,
                context TEXT,
                metadata TEXT
            )
        ''')
        
        # Performance metrics table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS performance_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                metric_type TEXT NOT NULL,
                metric_name TEXT NOT NULL,
                value REAL NOT NULL,
                context TEXT
            )
        ''')
        
        # Learning patterns table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS learning_patterns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                pattern_type TEXT NOT NULL,
                pattern_data TEXT NOT NULL,
                confidence REAL NOT NULL,
                usage_count INTEGER DEFAULT 0,
                success_rate REAL DEFAULT 0.0,
                last_updated TEXT NOT NULL
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def record_feedback(self, intent: str, action: str, outcome: str,
                       feedback_score: float = None, user_feedback: str = None,
                       context: Dict = None) -> int:
        """
        Record feedback for a performed action
        
        Args:
            intent: The intent that was executed
            action: The action taken
            outcome: The outcome (success, failure, partial)
            feedback_score: Numeric score (0.0 to 1.0)
            user_feedback: Optional text feedback from user
            context: Additional context
        
        Returns:
            Feedback ID
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO feedback 
            (timestamp, intent, action, outcome, feedback_score, user_feedback, context, metadata)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            timestamp(),
            intent,
            action,
            outcome,
            feedback_score,
            user_feedback,
            json.dumps(context or {}),
            json.dumps({})
        ))
        
        feedback_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        # Update in-memory metrics
        if outcome == 'success':
            self.learning_metrics[intent]['successes'] += 1
        else:
            self.learning_metrics[intent]['failures'] += 1
        
        self.logger.debug(f"Recorded feedback: {intent} -> {outcome}")
        return feedback_id
    
    def analyze_performance(self, intent: str = None, days_back: int = 7) -> Dict:
        """
        Analyze performance for an intent or overall
        
        Args:
            intent: Optional specific intent to analyze
            days_back: How many days of data to analyze
        
        Returns:
            Dict with performance analysis
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cutoff_date = (datetime.now() - timedelta(days=days_back)).isoformat()
        
        if intent:
            cursor.execute('''
                SELECT outcome, COUNT(*) as count, AVG(feedback_score) as avg_score
                FROM feedback
                WHERE intent = ? AND timestamp >= ?
                GROUP BY outcome
            ''', (intent, cutoff_date))
        else:
            cursor.execute('''
                SELECT outcome, COUNT(*) as count, AVG(feedback_score) as avg_score
                FROM feedback
                WHERE timestamp >= ?
                GROUP BY outcome
            ''', (cutoff_date,))
        
        outcomes = {}
        total = 0
        total_score = 0
        score_count = 0
        
        for row in cursor.fetchall():
            outcome, count, avg_score = row
            outcomes[outcome] = count
            total += count
            if avg_score:
                total_score += avg_score * count
                score_count += count
        
        conn.close()
        
        success_rate = outcomes.get('success', 0) / total if total > 0 else 0.0
        avg_feedback = total_score / score_count if score_count > 0 else 0.0
        
        analysis = {
            'intent': intent or 'overall',
            'total_actions': total,
            'outcomes': outcomes,
            'success_rate': round(success_rate, 3),
            'average_feedback_score': round(avg_feedback, 3),
            'needs_improvement': success_rate < SUCCESS_THRESHOLD
        }
        
        self.logger.info(f"Performance analysis: {analysis}")
        return analysis
    
    def identify_improvement_areas(self) -> List[Dict]:
        """
        Identify areas that need improvement
        
        Returns:
            List of improvement suggestions
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get performance by intent
        cursor.execute('''
            SELECT intent, 
                   SUM(CASE WHEN outcome = 'success' THEN 1 ELSE 0 END) as successes,
                   SUM(CASE WHEN outcome != 'success' THEN 1 ELSE 0 END) as failures,
                   COUNT(*) as total
            FROM feedback
            WHERE timestamp >= datetime('now', '-7 days')
            GROUP BY intent
            HAVING total >= ?
        ''', (MIN_FEEDBACK_FOR_LEARNING,))
        
        improvements = []
        
        for row in cursor.fetchall():
            intent, successes, failures, total = row
            success_rate = successes / total if total > 0 else 0
            
            if success_rate < SUCCESS_THRESHOLD:
                improvements.append({
                    'intent': intent,
                    'success_rate': round(success_rate, 3),
                    'total_attempts': total,
                    'priority': 'high' if success_rate < 0.5 else 'medium',
                    'suggestion': f"Success rate is {success_rate:.1%}, needs improvement"
                })
        
        conn.close()
        
        # Sort by priority and success rate
        improvements.sort(key=lambda x: (x['priority'] == 'high', x['success_rate']))
        
        return improvements
    
    def learn_pattern(self, pattern_type: str, pattern_data: Dict, 
                     confidence: float = 0.5) -> int:
        """
        Learn a new pattern
        
        Args:
            pattern_type: Type of pattern (intent, action, response, etc.)
            pattern_data: Pattern data
            confidence: Initial confidence level
        
        Returns:
            Pattern ID
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO learning_patterns 
            (pattern_type, pattern_data, confidence, last_updated)
            VALUES (?, ?, ?, ?)
        ''', (
            pattern_type,
            json.dumps(pattern_data),
            confidence,
            timestamp()
        ))
        
        pattern_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        self.logger.info(f"Learned new pattern: {pattern_type}")
        return pattern_id
    
    def update_pattern(self, pattern_id: int, success: bool):
        """
        Update a pattern based on success/failure
        
        Args:
            pattern_id: Pattern ID to update
            success: Whether the pattern was successful
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get current pattern
        cursor.execute('''
            SELECT confidence, usage_count, success_rate
            FROM learning_patterns
            WHERE id = ?
        ''', (pattern_id,))
        
        result = cursor.fetchone()
        if not result:
            conn.close()
            return
        
        confidence, usage_count, success_rate = result
        
        # Update metrics
        new_usage_count = usage_count + 1
        new_success_rate = ((success_rate * usage_count) + (1 if success else 0)) / new_usage_count
        
        # Adjust confidence based on success
        if success:
            new_confidence = min(1.0, confidence + LEARNING_RATE)
        else:
            new_confidence = max(0.0, confidence - LEARNING_RATE)
        
        cursor.execute('''
            UPDATE learning_patterns
            SET confidence = ?,
                usage_count = ?,
                success_rate = ?,
                last_updated = ?
            WHERE id = ?
        ''', (new_confidence, new_usage_count, new_success_rate, timestamp(), pattern_id))
        
        conn.commit()
        conn.close()
        
        self.logger.debug(f"Updated pattern {pattern_id}: confidence={new_confidence:.2f}")
    
    def get_best_patterns(self, pattern_type: str = None, limit: int = 10) -> List[Dict]:
        """
        Get best performing patterns
        
        Args:
            pattern_type: Optional filter by pattern type
            limit: Maximum number of results
        
        Returns:
            List of top patterns
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        if pattern_type:
            cursor.execute('''
                SELECT id, pattern_type, pattern_data, confidence, usage_count, success_rate
                FROM learning_patterns
                WHERE pattern_type = ?
                ORDER BY confidence DESC, success_rate DESC
                LIMIT ?
            ''', (pattern_type, limit))
        else:
            cursor.execute('''
                SELECT id, pattern_type, pattern_data, confidence, usage_count, success_rate
                FROM learning_patterns
                ORDER BY confidence DESC, success_rate DESC
                LIMIT ?
            ''', (limit,))
        
        patterns = []
        for row in cursor.fetchall():
            patterns.append({
                'id': row[0],
                'type': row[1],
                'data': json.loads(row[2]),
                'confidence': row[3],
                'usage_count': row[4],
                'success_rate': row[5]
            })
        
        conn.close()
        return patterns
    
    def get_learning_statistics(self) -> Dict:
        """Get overall learning statistics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Total feedback
        cursor.execute('SELECT COUNT(*) FROM feedback')
        total_feedback = cursor.fetchone()[0]
        
        # Success rate
        cursor.execute('''
            SELECT 
                SUM(CASE WHEN outcome = 'success' THEN 1 ELSE 0 END) * 100.0 / COUNT(*)
            FROM feedback
        ''')
        overall_success_rate = cursor.fetchone()[0] or 0.0
        
        # Learned patterns
        cursor.execute('SELECT COUNT(*) FROM learning_patterns')
        total_patterns = cursor.fetchone()[0]
        
        # Average pattern confidence
        cursor.execute('SELECT AVG(confidence) FROM learning_patterns')
        avg_confidence = cursor.fetchone()[0] or 0.0
        
        conn.close()
        
        return {
            'total_feedback_records': total_feedback,
            'overall_success_rate': round(overall_success_rate, 2),
            'learned_patterns': total_patterns,
            'average_pattern_confidence': round(avg_confidence, 3)
        }
