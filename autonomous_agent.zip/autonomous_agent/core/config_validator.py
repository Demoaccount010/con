#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 CONFIGURATION VALIDATOR
═══════════════════════════════════════════════════════════════════════════════

 Validates all system configuration before startup.
 
 VALIDATION CHECKS:
 ──────────────────
 • Required files exist
 • YAML syntax is valid
 • Required values are present
 • Ollama is reachable
 • Model is available
 • Telegram token is valid (if configured)
 • Directories have write permission
 • Memory database is accessible
 
 If validation fails:
 • Report what's missing
 • Attempt auto-fix if possible
 • Ask user for missing values
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import os
import sys
import asyncio
import aiohttp
import yaml
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime

PROJECT_ROOT = Path(__file__).parent.parent.absolute()
sys.path.insert(0, str(PROJECT_ROOT))

from output.output_manager import OutputManager


@dataclass
class ValidationIssue:
    """Represents a single validation issue."""
    category: str          # config, connection, permission, etc.
    severity: str          # critical, warning, info
    message: str           # Human-readable description
    fixable: bool          # Can be auto-fixed?
    fix_action: str = ""   # What to do to fix
    key: str = ""          # Config key involved
    

@dataclass
class ValidationResult:
    """Result of validation."""
    valid: bool
    issues: List[ValidationIssue] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    fixable: bool = False
    

@dataclass
class FixResult:
    """Result of fix attempt."""
    success: bool
    fixed_issues: List[str] = field(default_factory=list)
    remaining_issues: List[str] = field(default_factory=list)


class ConfigValidator:
    """
    ═══════════════════════════════════════════════════════════════════════════
    CONFIGURATION VALIDATOR
    ═══════════════════════════════════════════════════════════════════════════
    
    Validates and optionally fixes configuration issues.
    """
    
    # Required configuration files
    REQUIRED_FILES = [
        'config/required/system.yaml',
        'config/required/ollama.yaml',
    ]
    
    # Required directories (must be writable)
    REQUIRED_DIRECTORIES = [
        'logs',
        'memory/data',
        'temp',
    ]
    
    # Required configuration keys
    REQUIRED_CONFIG = {
        'ollama': ['base_url'],
        'agent': ['name'],
        'owner': ['nickname'],
    }
    
    def __init__(self, output: OutputManager):
        """Initialize validator."""
        self.output = output
        self.config: Dict[str, Any] = {}
        self.issues: List[ValidationIssue] = []
        
    async def validate_all(self) -> ValidationResult:
        """
        Run all validation checks.
        
        Returns ValidationResult with all issues found.
        """
        self.issues = []
        
        # ═══════════════════════════════════════════════════════════════════
        # CHECK 1: Required files exist
        # ═══════════════════════════════════════════════════════════════════
        await self._validate_files()
        
        # ═══════════════════════════════════════════════════════════════════
        # CHECK 2: Load and validate YAML syntax
        # ═══════════════════════════════════════════════════════════════════
        if not any(i.severity == 'critical' for i in self.issues):
            await self._validate_yaml_syntax()
            
        # ═══════════════════════════════════════════════════════════════════
        # CHECK 3: Required keys present
        # ═══════════════════════════════════════════════════════════════════
        if not any(i.severity == 'critical' for i in self.issues):
            await self._validate_required_keys()
            
        # ═══════════════════════════════════════════════════════════════════
        # CHECK 4: Directory permissions
        # ═══════════════════════════════════════════════════════════════════
        await self._validate_directories()
        
        # ═══════════════════════════════════════════════════════════════════
        # CHECK 5: Ollama connectivity
        # ═══════════════════════════════════════════════════════════════════
        await self._validate_ollama()
        
        # ═══════════════════════════════════════════════════════════════════
        # CHECK 6: Model availability
        # ═══════════════════════════════════════════════════════════════════
        await self._validate_model()
        
        # ═══════════════════════════════════════════════════════════════════
        # CHECK 7: Telegram token (if configured)
        # ═══════════════════════════════════════════════════════════════════
        await self._validate_telegram()
        
        # ═══════════════════════════════════════════════════════════════════
        # CHECK 8: Memory database
        # ═══════════════════════════════════════════════════════════════════
        await self._validate_memory_db()
        
        # Build result
        critical_issues = [i for i in self.issues if i.severity == 'critical']
        warnings = [i for i in self.issues if i.severity == 'warning']
        
        return ValidationResult(
            valid=len(critical_issues) == 0,
            issues=self.issues,
            errors=[i.message for i in critical_issues],
            warnings=[i.message for i in warnings],
            fixable=any(i.fixable for i in self.issues)
        )
        
    async def _validate_files(self) -> None:
        """Check that required files exist."""
        for file_path in self.REQUIRED_FILES:
            full_path = PROJECT_ROOT / file_path
            
            if not full_path.exists():
                self.issues.append(ValidationIssue(
                    category="file",
                    severity="critical",
                    message=f"Required file missing: {file_path}",
                    fixable=False,  # Need to run wizard
                    key=file_path
                ))
                
    async def _validate_yaml_syntax(self) -> None:
        """Validate YAML syntax of all config files."""
        config_dirs = [
            PROJECT_ROOT / 'config' / 'required',
            PROJECT_ROOT / 'config' / 'optional',
        ]
        
        for config_dir in config_dirs:
            if not config_dir.exists():
                continue
                
            for yaml_file in config_dir.glob('*.yaml'):
                try:
                    with open(yaml_file, 'r') as f:
                        data = yaml.safe_load(f)
                        
                    # Merge into main config
                    if data:
                        self.config.update(data)
                        
                except yaml.YAMLError as e:
                    self.issues.append(ValidationIssue(
                        category="yaml",
                        severity="critical",
                        message=f"Invalid YAML in {yaml_file.name}: {e}",
                        fixable=False,
                        key=str(yaml_file)
                    ))
                    
    async def _validate_required_keys(self) -> None:
        """Check that required configuration keys are present."""
        for section, keys in self.REQUIRED_CONFIG.items():
            section_data = self.config.get(section, {})
            
            for key in keys:
                if key not in section_data or not section_data[key]:
                    self.issues.append(ValidationIssue(
                        category="config",
                        severity="critical",
                        message=f"Missing required config: {section}.{key}",
                        fixable=True,
                        fix_action="ask_user",
                        key=f"{section}.{key}"
                    ))
                    
    async def _validate_directories(self) -> None:
        """Check that required directories exist and are writable."""
        for dir_path in self.REQUIRED_DIRECTORIES:
            full_path = PROJECT_ROOT / dir_path
            
            # Create if doesn't exist
            if not full_path.exists():
                try:
                    full_path.mkdir(parents=True, exist_ok=True)
                except Exception as e:
                    self.issues.append(ValidationIssue(
                        category="permission",
                        severity="critical",
                        message=f"Cannot create directory: {dir_path} ({e})",
                        fixable=False,
                        key=dir_path
                    ))
                    continue
                    
            # Check write permission
            test_file = full_path / '.write_test'
            try:
                test_file.touch()
                test_file.unlink()
            except Exception as e:
                self.issues.append(ValidationIssue(
                    category="permission",
                    severity="critical",
                    message=f"No write permission: {dir_path}",
                    fixable=False,
                    key=dir_path
                ))
                
    async def _validate_ollama(self) -> None:
        """Validate Ollama connectivity."""
        ollama_config = self.config.get('ollama', {})
        base_url = ollama_config.get('base_url', 'http://localhost:11434')
        
        try:
            async with aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=5)
            ) as session:
                async with session.get(f"{base_url}/api/version") as response:
                    if response.status != 200:
                        raise Exception(f"HTTP {response.status}")
                        
                    data = await response.json()
                    version = data.get('version', 'unknown')
                    
        except asyncio.TimeoutError:
            self.issues.append(ValidationIssue(
                category="connection",
                severity="critical",
                message=f"Ollama connection timeout: {base_url}",
                fixable=True,
                fix_action="check_ollama",
                key="ollama.base_url"
            ))
        except Exception as e:
            self.issues.append(ValidationIssue(
                category="connection",
                severity="critical",
                message=f"Cannot connect to Ollama at {base_url}: {e}",
                fixable=True,
                fix_action="check_ollama",
                key="ollama.base_url"
            ))
            
    async def _validate_model(self) -> None:
        """Validate that configured model is available."""
        ollama_config = self.config.get('ollama', {})
        base_url = ollama_config.get('base_url', 'http://localhost:11434')
        model = ollama_config.get('model')
        
        if not model:
            # No model configured - will be auto-selected
            return
            
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"{base_url}/api/tags") as response:
                    if response.status != 200:
                        return  # Will be caught by connection check
                        
                    data = await response.json()
                    available = [m['name'] for m in data.get('models', [])]
                    
                    if model not in available:
                        # Check partial match
                        matches = [m for m in available if model.split(':')[0] in m]
                        
                        if not matches:
                            self.issues.append(ValidationIssue(
                                category="model",
                                severity="warning",
                                message=f"Model '{model}' not found. Available: {available[:5]}",
                                fixable=True,
                                fix_action="select_model",
                                key="ollama.model"
                            ))
        except:
            pass  # Connection issues handled elsewhere
            
    async def _validate_telegram(self) -> None:
        """Validate Telegram token if configured."""
        telegram_config = self.config.get('telegram', {})
        token = telegram_config.get('token')
        
        if not token or not telegram_config.get('enabled', False):
            return  # Telegram is optional
            
        # Validate token format
        if not token or ':' not in token:
            self.issues.append(ValidationIssue(
                category="telegram",
                severity="warning",
                message="Invalid Telegram token format",
                fixable=True,
                fix_action="ask_token",
                key="telegram.token"
            ))
            return
            
        # Test with Telegram API
        try:
            async with aiohttp.ClientSession() as session:
                url = f"https://api.telegram.org/bot{token}/getMe"
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as response:
                    if response.status != 200:
                        data = await response.json()
                        self.issues.append(ValidationIssue(
                            category="telegram",
                            severity="warning",
                            message=f"Telegram token invalid: {data.get('description', 'Unknown error')}",
                            fixable=True,
                            fix_action="ask_token",
                            key="telegram.token"
                        ))
        except Exception as e:
            self.issues.append(ValidationIssue(
                category="telegram",
                severity="warning",
                message=f"Cannot verify Telegram token: {e}",
                fixable=False,
                key="telegram.token"
            ))
            
    async def _validate_memory_db(self) -> None:
        """Validate memory database accessibility."""
        db_dir = PROJECT_ROOT / 'memory' / 'data'
        db_path = db_dir / 'permanent.db'
        
        # Directory should already be validated
        if not db_dir.exists():
            return
            
        # Check if we can create/access database
        try:
            import sqlite3
            conn = sqlite3.connect(str(db_path))
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
            conn.close()
        except Exception as e:
            self.issues.append(ValidationIssue(
                category="database",
                severity="critical",
                message=f"Cannot access memory database: {e}",
                fixable=False,
                key="memory.database"
            ))
            
    async def fix_issues(self, issues: List[ValidationIssue]) -> FixResult:
        """
        Attempt to fix identified issues.
        
        Returns FixResult with what was fixed and what remains.
        """
        fixed = []
        remaining = []
        
        for issue in issues:
            if not issue.fixable:
                remaining.append(issue.message)
                continue
                
            try:
                if issue.fix_action == "ask_user":
                    # Ask user for missing value
                    value = await self._ask_for_value(issue.key)
                    if value:
                        await self._set_config_value(issue.key, value)
                        fixed.append(f"Set {issue.key}")
                    else:
                        remaining.append(issue.message)
                        
                elif issue.fix_action == "check_ollama":
                    # Help user fix Ollama
                    self.output.print_warning("Ollama is not running or not reachable.")
                    self.output.print_info("Please ensure Ollama is running:")
                    self.output.print_bullet("Start Ollama: ollama serve")
                    self.output.print_bullet("Or with Docker: docker run -p 11434:11434 ollama/ollama")
                    
                    retry = await self._ask("Press Enter when Ollama is running (or 'skip' to skip): ")
                    
                    if retry.lower() != 'skip':
                        # Re-validate
                        self.issues = []
                        await self._validate_ollama()
                        
                        if not any(i.category == 'connection' for i in self.issues):
                            fixed.append("Ollama connection established")
                        else:
                            remaining.append(issue.message)
                    else:
                        remaining.append(issue.message)
                        
                elif issue.fix_action == "select_model":
                    # Help user select a model
                    self.output.print_info("Available models:")
                    models = self.config.get('ollama', {}).get('available_models', [])
                    for i, model in enumerate(models[:10], 1):
                        self.output.print_bullet(f"{i}. {model}")
                        
                    choice = await self._ask("Select model number (or Enter for first): ")
                    
                    if choice.isdigit() and 1 <= int(choice) <= len(models):
                        model = models[int(choice) - 1]
                    elif models:
                        model = models[0]
                    else:
                        remaining.append("No models available")
                        continue
                        
                    await self._set_config_value('ollama.model', model)
                    fixed.append(f"Selected model: {model}")
                    
                elif issue.fix_action == "ask_token":
                    # Ask for Telegram token
                    self.output.print_info("Get a Telegram bot token from @BotFather")
                    token = await self._ask("Telegram Bot Token (or 'skip'): ")
                    
                    if token.lower() != 'skip' and token:
                        await self._set_config_value('telegram.token', token)
                        fixed.append("Telegram token set")
                    else:
                        await self._set_config_value('telegram.enabled', False)
                        fixed.append("Telegram disabled")
                        
            except Exception as e:
                remaining.append(f"{issue.message} (fix failed: {e})")
                
        return FixResult(
            success=len(remaining) == 0,
            fixed_issues=fixed,
            remaining_issues=remaining
        )
        
    async def _ask_for_value(self, key: str) -> Optional[str]:
        """Ask user for a configuration value."""
        prompts = {
            'ollama.base_url': 'Ollama server URL [http://localhost:11434]: ',
            'agent.name': 'Agent name [Axiom]: ',
            'owner.nickname': 'Your nickname: ',
        }
        
        defaults = {
            'ollama.base_url': 'http://localhost:11434',
            'agent.name': 'Axiom',
        }
        
        prompt = prompts.get(key, f"Enter value for {key}: ")
        default = defaults.get(key, "")
        
        value = await self._ask(prompt)
        return value if value else default
        
    async def _ask(self, prompt: str) -> str:
        """Ask user for input."""
        return await asyncio.get_event_loop().run_in_executor(
            None,
            lambda: input(prompt).strip()
        )
        
    async def _set_config_value(self, key: str, value: Any) -> None:
        """Set a configuration value and save to file."""
        parts = key.split('.')
        
        if len(parts) != 2:
            return
            
        section, setting = parts
        
        # Update in-memory config
        if section not in self.config:
            self.config[section] = {}
        self.config[section][setting] = value
        
        # Determine file to update
        file_map = {
            'ollama': 'config/required/ollama.yaml',
            'agent': 'config/required/system.yaml',
            'owner': 'config/required/owner.yaml',
            'telegram': 'config/required/telegram.yaml',
        }
        
        file_path = PROJECT_ROOT / file_map.get(section, f'config/required/{section}.yaml')
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Load existing file or create new
        existing = {}
        if file_path.exists():
            with open(file_path, 'r') as f:
                existing = yaml.safe_load(f) or {}
                
        # Update
        if section not in existing:
            existing[section] = {}
        existing[section][setting] = value
        
        # Save
        with open(file_path, 'w') as f:
            yaml.dump(existing, f, default_flow_style=False)
            
    async def load_config(self) -> Dict[str, Any]:
        """Load all configuration files into a single dict."""
        config = {}
        
        config_dirs = [
            PROJECT_ROOT / 'config' / 'required',
            PROJECT_ROOT / 'config' / 'optional',
            PROJECT_ROOT / 'identity' / 'permanent_data',
        ]
        
        for config_dir in config_dirs:
            if not config_dir.exists():
                continue
                
            for yaml_file in config_dir.glob('*.yaml'):
                try:
                    with open(yaml_file, 'r') as f:
                        data = yaml.safe_load(f)
                        
                    if data:
                        # Deep merge
                        for key, value in data.items():
                            if key in config and isinstance(config[key], dict) and isinstance(value, dict):
                                config[key].update(value)
                            else:
                                config[key] = value
                                
                except yaml.YAMLError:
                    pass  # Already reported in validation
                    
        return config