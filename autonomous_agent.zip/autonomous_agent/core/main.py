#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 AUTONOMOUS AGENT - MAIN ENTRYPOINT
═══════════════════════════════════════════════════════════════════════════════

 This is the PRIMARY entrypoint for the Autonomous Agent System.
 
 RESPONSIBILITIES:
 ─────────────────
 1. Initialize all subsystems in correct order
 2. Run startup wizard if first run
 3. Validate all configurations
 4. Start the agent loop
 5. Handle graceful shutdown
 
 STARTUP SEQUENCE:
 ─────────────────
 1. Check first_run_complete.flag
 2. If first run → Run Startup Wizard
 3. Validate all configurations
 4. Initialize components
 5. Start interfaces (CLI, Telegram, API)
 6. Enter main loop
 
 Author: System Engineer
 Version: 3.0.0
 License: Production Use
 
═══════════════════════════════════════════════════════════════════════════════
"""

import os
import sys
import signal
import asyncio
import logging
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any, List

# ═══════════════════════════════════════════════════════════════════════════════
# PATH SETUP - Ensure all modules are importable
# ═══════════════════════════════════════════════════════════════════════════════

PROJECT_ROOT = Path(__file__).parent.parent.absolute()
sys.path.insert(0, str(PROJECT_ROOT))

# ═══════════════════════════════════════════════════════════════════════════════
# IMPORTS - Core modules (imported after path setup)
# ═══════════════════════════════════════════════════════════════════════════════

from core.startup_wizard import StartupWizard
from core.config_validator import ConfigValidator
from core.agent import Agent
from core.agent_loop import AgentLoop
from core.state_manager import StateManager
from core.command_obedience import CommandObedience

from brain.brain_controller import BrainController
from memory.memory_manager import MemoryManager
from llm.ollama_client import OllamaClient
from llm.model_manager import ModelManager
from tools.registry import ToolRegistry
from security.security_manager import SecurityManager
from autonomous.autonomous_controller import AutonomousController
from telegram_bot.telegram_bot import TelegramBot
from notifications.notification_manager import NotificationManager
from output.output_manager import OutputManager
from health.health_monitor import HealthMonitor
from performance.performance_manager import PerformanceManager

# ═══════════════════════════════════════════════════════════════════════════════
# CONSTANTS
# ═══════════════════════════════════════════════════════════════════════════════

VERSION = "3.0.0"
CODENAME = "Axiom"
FIRST_RUN_FLAG = PROJECT_ROOT / "identity" / "permanent_data" / "first_run_complete.flag"
LOG_DIR = PROJECT_ROOT / "logs"
CONFIG_DIR = PROJECT_ROOT / "config"


class AutonomousAgentSystem:
    """
    ═══════════════════════════════════════════════════════════════════════════
    MAIN AGENT SYSTEM CONTROLLER
    ═══════════════════════════════════════════════════════════════════════════
    
    This class orchestrates the entire autonomous agent system.
    
    LIFECYCLE:
    ──────────
    1. __init__     → Basic setup, no heavy initialization
    2. startup()    → Full initialization sequence
    3. run()        → Main execution loop
    4. shutdown()   → Graceful shutdown
    
    COMPONENTS MANAGED:
    ───────────────────
    • Brain Controller      - Thinking engine
    • Memory Manager        - Persistent memory
    • Ollama Client         - LLM interface
    • Tool Registry         - Available tools
    • Security Manager      - Safety & permissions
    • Telegram Bot          - Telegram interface
    • Autonomous Controller - Background research
    • Health Monitor        - System health
    """
    
    def __init__(self):
        """
        Initialize basic properties.
        Heavy initialization happens in startup().
        """
        # ═══════════════════════════════════════════════════════════════════
        # TIMING
        # ═══════════════════════════════════════════════════════════════════
        self.init_time = datetime.utcnow()
        self.start_time: Optional[datetime] = None
        
        # ═══════════════════════════════════════════════════════════════════
        # STATE FLAGS
        # ═══════════════════════════════════════════════════════════════════
        self.is_first_run: bool = not FIRST_RUN_FLAG.exists()
        self.is_initialized: bool = False
        self.is_running: bool = False
        self.shutdown_requested: bool = False
        
        # ═══════════════════════════════════════════════════════════════════
        # CONFIGURATION
        # ═══════════════════════════════════════════════════════════════════
        self.config: Dict[str, Any] = {}
        self.owner_config: Dict[str, Any] = {}
        self.agent_config: Dict[str, Any] = {}
        
        # ═══════════════════════════════════════════════════════════════════
        # COMPONENTS (initialized in startup)
        # ═══════════════════════════════════════════════════════════════════
        self.logger: Optional[logging.Logger] = None
        self.output: Optional[OutputManager] = None
        self.brain: Optional[BrainController] = None
        self.memory: Optional[MemoryManager] = None
        self.ollama: Optional[OllamaClient] = None
        self.model_manager: Optional[ModelManager] = None
        self.tools: Optional[ToolRegistry] = None
        self.security: Optional[SecurityManager] = None
        self.state: Optional[StateManager] = None
        self.agent_loop: Optional[AgentLoop] = None
        self.telegram: Optional[TelegramBot] = None
        self.autonomous: Optional[AutonomousController] = None
        self.notifications: Optional[NotificationManager] = None
        self.health: Optional[HealthMonitor] = None
        self.performance: Optional[PerformanceManager] = None
        self.obedience: Optional[CommandObedience] = None
        
    def _setup_logging(self) -> None:
        """
        Configure comprehensive logging system.
        
        LOG FILES:
        ──────────
        • agent.log       - Main agent activity
        • thinking.log    - Brain/thinking logs
        • memory.log      - Memory operations
        • tool.log        - Tool executions
        • error.log       - Errors only
        • security.log    - Security events
        • telegram.log    - Telegram activity
        • research.log    - Autonomous research
        • performance.log - Performance metrics
        """
        # Create log directory
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        
        # ═══════════════════════════════════════════════════════════════════
        # LOG FORMATTERS
        # ═══════════════════════════════════════════════════════════════════
        
        detailed_format = logging.Formatter(
            fmt='%(asctime)s │ %(levelname)-8s │ %(name)-25s │ %(funcName)-20s │ %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        simple_format = logging.Formatter(
            fmt='%(asctime)s │ %(levelname)-8s │ %(message)s',
            datefmt='%H:%M:%S'
        )
        
        # ═══════════════════════════════════════════════════════════════════
        # ROOT LOGGER
        # ═══════════════════════════════════════════════════════════════════
        
        root_logger = logging.getLogger()
        root_logger.setLevel(logging.DEBUG)
        
        # Clear existing handlers
        root_logger.handlers = []
        
        # ═══════════════════════════════════════════════════════════════════
        # FILE HANDLERS
        # ═══════════════════════════════════════════════════════════════════
        
        # Main agent log (all levels)
        agent_handler = logging.FileHandler(
            LOG_DIR / "agent.log",
            encoding='utf-8',
            mode='a'
        )
        agent_handler.setLevel(logging.DEBUG)
        agent_handler.setFormatter(detailed_format)
        root_logger.addHandler(agent_handler)
        
        # Error log (errors and above)
        error_handler = logging.FileHandler(
            LOG_DIR / "error.log",
            encoding='utf-8',
            mode='a'
        )
        error_handler.setLevel(logging.ERROR)
        error_handler.setFormatter(detailed_format)
        root_logger.addHandler(error_handler)
        
        # Console handler (info and above)
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(simple_format)
        root_logger.addHandler(console_handler)
        
        # ═══════════════════════════════════════════════════════════════════
        # COMPONENT-SPECIFIC LOGGERS
        # ═══════════════════════════════════════════════════════════════════
        
        component_logs = [
            ("brain", "thinking.log"),
            ("memory", "memory.log"),
            ("tools", "tool.log"),
            ("security", "security.log"),
            ("telegram", "telegram.log"),
            ("autonomous", "research.log"),
            ("performance", "performance.log"),
        ]
        
        for component_name, log_file in component_logs:
            component_logger = logging.getLogger(component_name)
            handler = logging.FileHandler(
                LOG_DIR / log_file,
                encoding='utf-8',
                mode='a'
            )
            handler.setLevel(logging.DEBUG)
            handler.setFormatter(detailed_format)
            component_logger.addHandler(handler)
        
        # Create main logger
        self.logger = logging.getLogger("AutonomousAgent")
        self.logger.info("═" * 70)
        self.logger.info(f"  AUTONOMOUS AGENT SYSTEM v{VERSION} ({CODENAME})")
        self.logger.info("═" * 70)
        self.logger.info("Logging system initialized")
        
    def _setup_signal_handlers(self) -> None:
        """
        Configure signal handlers for graceful shutdown.
        
        SIGNALS HANDLED:
        ────────────────
        • SIGINT  (Ctrl+C)
        • SIGTERM (kill command)
        • SIGHUP  (terminal hangup) - Unix only
        """
        def handle_shutdown(signum: int, frame) -> None:
            signal_name = signal.Signals(signum).name
            self.logger.warning(f"Received {signal_name} - initiating graceful shutdown")
            self.shutdown_requested = True
            
        signal.signal(signal.SIGINT, handle_shutdown)
        signal.signal(signal.SIGTERM, handle_shutdown)
        
        # SIGHUP only on Unix
        if hasattr(signal, 'SIGHUP'):
            signal.signal(signal.SIGHUP, handle_shutdown)
            
        self.logger.info("Signal handlers configured")
        
    async def startup(self) -> bool:
        """
        ═══════════════════════════════════════════════════════════════════════
        FULL STARTUP SEQUENCE
        ═══════════════════════════════════════════════════════════════════════
        
        ORDER IS CRITICAL - Each step depends on previous ones.
        
        RETURNS:
        ────────
        True if startup successful, False otherwise
        """
        try:
            # ═══════════════════════════════════════════════════════════════
            # PHASE 1: BASIC INFRASTRUCTURE
            # ═══════════════════════════════════════════════════════════════
            
            print("\n" + "═" * 60)
            print("  🚀 AUTONOMOUS AGENT SYSTEM")
            print(f"  Version: {VERSION} | Codename: {CODENAME}")
            print("═" * 60 + "\n")
            
            # Step 1.1: Logging
            self._setup_logging()
            
            # Step 1.2: Signal handlers
            self._setup_signal_handlers()
            
            # Step 1.3: Create required directories
            await self._ensure_directories()
            
            # Step 1.4: Output manager (for beautiful output)
            self.output = OutputManager()
            await self.output.initialize()
            
            # ═══════════════════════════════════════════════════════════════
            # PHASE 2: FIRST RUN CHECK & WIZARD
            # ═══════════════════════════════════════════════════════════════
            
            if self.is_first_run:
                self.logger.info("First run detected - starting setup wizard")
                self.output.print_header("FIRST TIME SETUP", icon="🎉")
                
                wizard = StartupWizard(self.output)
                wizard_result = await wizard.run()
                
                if not wizard_result.success:
                    self.logger.error("Setup wizard failed or was cancelled")
                    self.output.print_error("Setup cancelled. Cannot proceed.")
                    return False
                    
                # Store wizard results
                self.config = wizard_result.config
                self.owner_config = wizard_result.owner_config
                self.agent_config = wizard_result.agent_config
                
                # Create first run flag
                FIRST_RUN_FLAG.parent.mkdir(parents=True, exist_ok=True)
                FIRST_RUN_FLAG.write_text(datetime.utcnow().isoformat())
                
                self.logger.info("First run setup completed successfully")
            else:
                self.logger.info("Existing installation detected - loading configuration")
                
            # ═══════════════════════════════════════════════════════════════
            # PHASE 3: CONFIGURATION VALIDATION
            # ═══════════════════════════════════════════════════════════════
            
            self.output.print_status("Validating configuration...")
            
            validator = ConfigValidator(self.output)
            validation_result = await validator.validate_all()
            
            if not validation_result.valid:
                self.logger.error("Configuration validation failed")
                self.output.print_error("Configuration problems detected:")
                
                for error in validation_result.errors:
                    self.output.print_bullet(error, icon="❌")
                    
                # Try to fix issues
                if validation_result.fixable:
                    self.output.print_info("Attempting to fix issues...")
                    fix_result = await validator.fix_issues(validation_result.issues)
                    
                    if not fix_result.success:
                        return False
                else:
                    return False
                    
            self.output.print_success("Configuration validated")
            
            # Load validated configuration
            self.config = await validator.load_config()
            self.owner_config = self.config.get('owner', {})
            self.agent_config = self.config.get('agent', {})
            
            # ═══════════════════════════════════════════════════════════════
            # PHASE 4: CORE COMPONENT INITIALIZATION
            # Order: Security → Memory → LLM → Brain → Tools
            # ═══════════════════════════════════════════════════════════════
            
            self.output.print_header("INITIALIZING COMPONENTS", icon="⚙️")
            
            # Step 4.1: Performance Manager (for optimizations)
            self.output.print_status("Starting performance optimizer...")
            self.performance = PerformanceManager(self.config.get('performance', {}))
            await self.performance.initialize()
            self.output.print_success("Performance optimizer ready")
            
            # Step 4.2: Security Manager
            self.output.print_status("Initializing security sandbox...")
            self.security = SecurityManager(self.config.get('security', {}))
            await self.security.initialize()
            self.output.print_success("Security sandbox active")
            
            # Step 4.3: Memory Manager
            self.output.print_status("Initializing memory system...")
            self.memory = MemoryManager(
                db_path=PROJECT_ROOT / "memory" / "data",
                config=self.config.get('memory', {})
            )
            await self.memory.initialize()
            memory_stats = await self.memory.get_stats()
            self.output.print_success(
                f"Memory system ready ({memory_stats['total_entries']} entries)"
            )
            
            # Step 4.4: Ollama Client
            self.output.print_status("Connecting to Ollama...")
            self.ollama = OllamaClient(self.config.get('ollama', {}))
            await self.ollama.initialize()
            
            if not self.ollama.is_connected:
                self.output.print_error("Cannot connect to Ollama!")
                return False
                
            self.output.print_success(f"Ollama connected ({self.ollama.base_url})")
            
            # Step 4.5: Model Manager
            self.output.print_status("Loading LLM model...")
            self.model_manager = ModelManager(self.ollama, self.config.get('ollama', {}))
            await self.model_manager.initialize()
            current_model = self.model_manager.current_model
            self.output.print_success(f"Model loaded: {current_model}")
            
            # Step 4.6: Brain Controller
            self.output.print_status("Initializing brain (thinking engine)...")
            self.brain = BrainController(
                ollama=self.ollama,
                model_manager=self.model_manager,
                memory=self.memory,
                config=self.config.get('brain', {})
            )
            await self.brain.initialize()
            self.output.print_success("Brain initialized (ultra-fast mode)")
            
            # Step 4.7: Tool Registry
            self.output.print_status("Loading tools...")
            self.tools = ToolRegistry(
                security=self.security,
                config=self.config.get('tools', {})
            )
            await self.tools.initialize()
            tool_count = len(self.tools.list_all())
            self.output.print_success(f"Tools loaded: {tool_count} tools available")
            
            # Step 4.8: State Manager
            self.output.print_status("Initializing state manager...")
            self.state = StateManager(self.memory)
            await self.state.initialize()
            self.output.print_success("State manager ready")
            
            # Step 4.9: Command Obedience
            self.output.print_status("Initializing command processor...")
            self.obedience = CommandObedience(
                security=self.security,
                memory=self.memory
            )
            await self.obedience.initialize()
            self.output.print_success("Command processor ready (full obedience mode)")
            
            # Step 4.10: Notification Manager
            self.output.print_status("Initializing notification system...")
            self.notifications = NotificationManager(
                memory=self.memory,
                config=self.config.get('notifications', {})
            )
            await self.notifications.initialize()
            self.output.print_success("Notification system ready")
            
            # ═══════════════════════════════════════════════════════════════
            # PHASE 5: AGENT LOOP & INTERFACES
            # ═══════════════════════════════════════════════════════════════
            
            # Step 5.1: Agent Loop
            self.output.print_status("Initializing agent loop...")
            self.agent_loop = AgentLoop(
                brain=self.brain,
                memory=self.memory,
                tools=self.tools,
                security=self.security,
                state=self.state,
                notifications=self.notifications,
                obedience=self.obedience,
                output=self.output,
                config=self.config
            )
            await self.agent_loop.initialize()
            self.output.print_success("Agent loop ready")
            
            # Step 5.2: Health Monitor
            self.output.print_status("Starting health monitor...")
            self.health = HealthMonitor(
                components={
                    'brain': self.brain,
                    'memory': self.memory,
                    'ollama': self.ollama,
                    'tools': self.tools,
                },
                config=self.config.get('health', {})
            )
            await self.health.initialize()
            self.output.print_success("Health monitor active")
            
            # Step 5.3: Telegram Bot (if configured)
            telegram_config = self.config.get('telegram', {})
            if telegram_config.get('token'):
                self.output.print_status("Initializing Telegram bot...")
                self.telegram = TelegramBot(
                    agent_loop=self.agent_loop,
                    notifications=self.notifications,
                    output=self.output,
                    config=telegram_config
                )
                await self.telegram.initialize()
                bot_username = await self.telegram.get_username()
                self.output.print_success(f"Telegram bot ready: @{bot_username}")
            else:
                self.output.print_info("Telegram not configured (skipping)")
                
            # Step 5.4: Autonomous Controller
            self.output.print_status("Initializing autonomous research...")
            self.autonomous = AutonomousController(
                brain=self.brain,
                memory=self.memory,
                notifications=self.notifications,
                config=self.config.get('autonomous', {})
            )
            await self.autonomous.initialize()
            self.output.print_success("Autonomous research ready (idle mode)")
            
            # ═══════════════════════════════════════════════════════════════
            # PHASE 6: FINAL CHECKS & STARTUP COMPLETE
            # ═══════════════════════════════════════════════════════════════
            
            # Run health check
            self.output.print_status("Running health check...")
            health_result = await self.health.full_check()
            
            if not health_result.healthy:
                self.output.print_warning("Some health checks failed:")
                for issue in health_result.issues:
                    self.output.print_bullet(issue, icon="⚠️")
            else:
                self.output.print_success("All health checks passed")
                
            # Store startup info in memory
            await self.memory.store_permanent(
                key="last_startup",
                value={
                    "timestamp": datetime.utcnow().isoformat(),
                    "version": VERSION,
                    "model": current_model,
                    "tools_count": tool_count
                },
                category="system"
            )
            
            # Mark as initialized
            self.is_initialized = True
            self.start_time = datetime.utcnow()
            
            # Print startup summary
            self._print_startup_summary()
            
            self.logger.info("═" * 70)
            self.logger.info("  STARTUP COMPLETE - AGENT IS READY")
            self.logger.info("═" * 70)
            
            return True
            
        except Exception as e:
            self.logger.critical(f"Startup failed: {e}", exc_info=True)
            if self.output:
                self.output.print_error(f"Startup failed: {e}")
            else:
                print(f"\n❌ STARTUP FAILED: {e}\n")
            return False
            
    async def _ensure_directories(self) -> None:
        """Create all required directories."""
        directories = [
            PROJECT_ROOT / "logs",
            PROJECT_ROOT / "memory" / "data",
            PROJECT_ROOT / "config" / "required",
            PROJECT_ROOT / "config" / "optional",
            PROJECT_ROOT / "identity" / "permanent_data",
            PROJECT_ROOT / "plugins" / "installed",
            PROJECT_ROOT / "temp",
        ]
        
        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)
            
    def _print_startup_summary(self) -> None:
        """Print beautiful startup summary."""
        owner_name = self.owner_config.get('nickname', 'User')
        agent_name = self.agent_config.get('name', 'Axiom')
        
        self.output.print_divider()
        self.output.print_header("SYSTEM READY", icon="✅")
        
        print(f"""
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   👤 Owner: {owner_name:<46} │
│   🤖 Agent: {agent_name:<46} │
│   📊 Version: {VERSION:<44} │
│   🧠 Model: {self.model_manager.current_model:<46} │
│   🔧 Tools: {len(self.tools.list_all()):<46} │
│   💾 Memory: {self.memory.total_entries} entries{' ' * (40 - len(str(self.memory.total_entries)))} │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│   INTERFACES:                                               │
│   • CLI: Ready                                              │
│   • Telegram: {'Active (@' + self.telegram.username + ')' if self.telegram else 'Not configured':<42} │
│   • Research: Idle mode (waiting for inactivity)            │
│                                                             │
└─────────────────────────────────────────────────────────────┘
        """)
        
        self.output.print_info(f"Hello {owner_name}! I'm {agent_name}. How can I help you?")
        self.output.print_divider()
        
    async def run(self) -> None:
        """
        ═══════════════════════════════════════════════════════════════════════
        MAIN EXECUTION LOOP
        ═══════════════════════════════════════════════════════════════════════
        
        This runs until shutdown is requested.
        Handles CLI input while other interfaces run in background.
        """
        if not self.is_initialized:
            self.logger.error("Cannot run - not initialized")
            return
            
        self.is_running = True
        self.logger.info("Entering main execution loop")
        
        # Start background tasks
        background_tasks = []
        
        # Telegram bot polling (if configured)
        if self.telegram:
            background_tasks.append(
                asyncio.create_task(self.telegram.start_polling())
            )
            
        # Autonomous research
        background_tasks.append(
            asyncio.create_task(self.autonomous.start())
        )
        
        # Health monitoring
        background_tasks.append(
            asyncio.create_task(self.health.start_monitoring())
        )
        
        try:
            while not self.shutdown_requested:
                try:
                    # Get user input (non-blocking with asyncio)
                    self.output.print_prompt()
                    
                    # Use run_in_executor for blocking input()
                    user_input = await asyncio.get_event_loop().run_in_executor(
                        None,
                        lambda: input().strip()
                    )
                    
                    # Skip empty input
                    if not user_input:
                        continue
                        
                    # Check for exit commands
                    if user_input.lower() in ('exit', 'quit', 'bye', 'shutdown'):
                        self.output.print_info("Goodbye! Shutting down...")
                        self.shutdown_requested = True
                        continue
                        
                    # Check for system commands
                    if user_input.startswith('/'):
                        await self._handle_system_command(user_input)
                        continue
                        
                    # Process through agent loop
                    self.logger.info(f"Processing: {user_input[:50]}...")
                    
                    # Notify autonomous controller of activity
                    self.autonomous.user_active()
                    
                    # Process input
                    result = await self.agent_loop.process(user_input)
                    
                    # Display result
                    self.output.print_response(result)
                    
                except asyncio.CancelledError:
                    self.logger.info("Main loop cancelled")
                    break
                    
                except KeyboardInterrupt:
                    self.shutdown_requested = True
                    
                except Exception as e:
                    self.logger.error(f"Error in main loop: {e}", exc_info=True)
                    self.output.print_error(f"Error: {e}")
                    
        finally:
            # Cancel background tasks
            for task in background_tasks:
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
                    
            self.is_running = False
            
    async def _handle_system_command(self, command: str) -> None:
        """Handle system commands starting with /."""
        parts = command.split()
        cmd = parts[0].lower()
        args = parts[1:] if len(parts) > 1 else []
        
        commands = {
            '/help': self._cmd_help,
            '/status': self._cmd_status,
            '/health': self._cmd_health,
            '/memory': self._cmd_memory,
            '/tools': self._cmd_tools,
            '/research': self._cmd_research,
            '/config': self._cmd_config,
            '/about': self._cmd_about,
        }
        
        handler = commands.get(cmd)
        if handler:
            await handler(args)
        else:
            self.output.print_error(f"Unknown command: {cmd}")
            self.output.print_info("Type /help for available commands")
            
    async def _cmd_help(self, args: List[str]) -> None:
        """Show help."""
        self.output.print_header("AVAILABLE COMMANDS", icon="📖")
        commands = [
            ("/help", "Show this help message"),
            ("/status", "Show system status"),
            ("/health", "Run health check"),
            ("/memory", "Show memory statistics"),
            ("/tools", "List available tools"),
            ("/research", "Manual research trigger"),
            ("/config", "Show configuration"),
            ("/about", "About this agent"),
            ("exit", "Shutdown the agent"),
        ]
        for cmd, desc in commands:
            print(f"  {cmd:<15} - {desc}")
        print()
        
    async def _cmd_status(self, args: List[str]) -> None:
        """Show system status."""
        uptime = datetime.utcnow() - self.start_time if self.start_time else None
        
        self.output.print_header("SYSTEM STATUS", icon="📊")
        print(f"  Uptime: {uptime}")
        print(f"  Model: {self.model_manager.current_model}")
        print(f"  Memory entries: {await self.memory.get_entry_count()}")
        print(f"  Tools available: {len(self.tools.list_all())}")
        print(f"  Telegram: {'Active' if self.telegram else 'Not configured'}")
        print(f"  Research mode: {self.autonomous.current_state}")
        print()
        
    async def _cmd_health(self, args: List[str]) -> None:
        """Run health check."""
        self.output.print_status("Running health check...")
        result = await self.health.full_check()
        
        if result.healthy:
            self.output.print_success("All systems healthy!")
        else:
            self.output.print_warning("Issues detected:")
            for issue in result.issues:
                self.output.print_bullet(issue, icon="⚠️")
                
    async def _cmd_memory(self, args: List[str]) -> None:
        """Show memory statistics."""
        stats = await self.memory.get_stats()
        self.output.print_header("MEMORY STATISTICS", icon="💾")
        for key, value in stats.items():
            print(f"  {key}: {value}")
        print()
        
    async def _cmd_tools(self, args: List[str]) -> None:
        """List available tools."""
        tools = self.tools.list_all()
        self.output.print_header(f"AVAILABLE TOOLS ({len(tools)})", icon="🔧")
        
        # Group by category
        categories = {}
        for tool in tools:
            cat = tool.get('category', 'other')
            if cat not in categories:
                categories[cat] = []
            categories[cat].append(tool['name'])
            
        for category, tool_names in sorted(categories.items()):
            print(f"\n  {category.upper()} ({len(tool_names)}):")
            for name in sorted(tool_names)[:10]:  # Show first 10
                print(f"    • {name}")
            if len(tool_names) > 10:
                print(f"    ... and {len(tool_names) - 10} more")
        print()
        
    async def _cmd_research(self, args: List[str]) -> None:
        """Trigger manual research."""
        if args:
            topic = " ".join(args)
            self.output.print_status(f"Starting research on: {topic}")
            await self.autonomous.research_topic(topic)
        else:
            self.output.print_info("Usage: /research <topic>")
            
    async def _cmd_config(self, args: List[str]) -> None:
        """Show configuration."""
        self.output.print_header("CONFIGURATION", icon="⚙️")
        print(f"  Owner: {self.owner_config.get('nickname', 'Unknown')}")
        print(f"  Agent name: {self.agent_config.get('name', 'Axiom')}")
        print(f"  Ollama URL: {self.config.get('ollama', {}).get('base_url', 'Not set')}")
        print(f"  Model: {self.model_manager.current_model}")
        print()
        
    async def _cmd_about(self, args: List[str]) -> None:
        """Show about info."""
        agent_name = self.agent_config.get('name', 'Axiom')
        self.output.print_header(f"ABOUT {agent_name.upper()}", icon="🤖")
        print(f"""
  Name: {agent_name}
  Version: {VERSION}
  Codename: {CODENAME}
  
  I am an autonomous AI agent designed to:
  • Execute system tasks
  • Learn from interactions
  • Research topics independently
  • Always be honest and helpful
  
  I NEVER guess. I always verify.
  I follow all owner commands.
  I explain my reasoning.
        """)
        
    async def shutdown(self) -> None:
        """
        ═══════════════════════════════════════════════════════════════════════
        GRACEFUL SHUTDOWN
        ═══════════════════════════════════════════════════════════════════════
        
        Shutdown order (reverse of startup):
        1. Stop autonomous research
        2. Stop Telegram bot
        3. Stop health monitoring
        4. Persist state
        5. Close memory
        6. Close LLM connection
        """
        self.logger.info("═" * 70)
        self.logger.info("  GRACEFUL SHUTDOWN INITIATED")
        self.logger.info("═" * 70)
        
        if self.output:
            self.output.print_header("SHUTTING DOWN", icon="🔄")
            
        try:
            # Stop autonomous
            if self.autonomous:
                self.output.print_status("Stopping autonomous research...")
                await self.autonomous.stop()
                
            # Stop Telegram
            if self.telegram:
                self.output.print_status("Stopping Telegram bot...")
                await self.telegram.stop()
                
            # Stop health monitoring
            if self.health:
                self.output.print_status("Stopping health monitor...")
                await self.health.stop()
                
            # Persist state
            if self.state:
                self.output.print_status("Persisting state...")
                await self.state.persist()
                
            # Store shutdown info
            if self.memory:
                await self.memory.store_permanent(
                    key="last_shutdown",
                    value={
                        "timestamp": datetime.utcnow().isoformat(),
                        "uptime_seconds": (datetime.utcnow() - self.start_time).total_seconds() if self.start_time else 0
                    },
                    category="system"
                )
                
                self.output.print_status("Closing memory...")
                await self.memory.close()
                
            # Close Ollama
            if self.ollama:
                self.output.print_status("Closing Ollama connection...")
                await self.ollama.close()
                
            if self.output:
                self.output.print_success("Shutdown complete. Goodbye!")
                
            self.logger.info("═" * 70)
            self.logger.info("  SHUTDOWN COMPLETE")
            self.logger.info("═" * 70)
            
        except Exception as e:
            self.logger.error(f"Error during shutdown: {e}", exc_info=True)


# ═══════════════════════════════════════════════════════════════════════════════
# ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════════

async def main():
    """Application entry point."""
    agent = AutonomousAgentSystem()
    
    try:
        # Startup
        if not await agent.startup():
            print("\n❌ Startup failed. Check logs for details.\n")
            sys.exit(1)
            
        # Run
        await agent.run()
        
    except Exception as e:
        print(f"\n❌ Fatal error: {e}\n")
        sys.exit(1)
        
    finally:
        # Always attempt shutdown
        await agent.shutdown()


if __name__ == "__main__":
    asyncio.run(main())