#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 EXECUTOR - TOOL EXECUTION ENGINE
═══════════════════════════════════════════════════════════════════════════════

 Executes plan steps by running the appropriate tools.
 
 EXECUTION PHILOSOPHY:
 ─────────────────────
 • Execute ONE tool at a time
 • Capture COMPLETE output
 • Handle ALL errors gracefully
 • Respect timeouts
 • Enforce security constraints
 • Update memory with results
 
 EXECUTION FLOW:
 ───────────────
 1. Validate step and tool
 2. Check permissions
 3. Prepare parameters
 4. Execute with timeout
 5. Capture output
 6. Analyze result
 7. Update memory if needed
 
 CRITICAL RULES:
 ───────────────
 • NEVER execute without validation
 • NEVER skip security checks
 • ALWAYS respect timeouts
 • ALWAYS capture errors
 • Update memory when tool output differs from memory
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
import time
import traceback
from datetime import datetime
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass, field
from enum import Enum

from core.planner import PlanStep, StepStatus, StepPriority
from tools.registry import ToolRegistry
from security.security_manager import SecurityManager
from memory.memory_manager import MemoryManager, MemoryType


class ExecutionStatus(Enum):
    """Status of execution."""
    SUCCESS = "success"
    FAILED = "failed"
    TIMEOUT = "timeout"
    PERMISSION_DENIED = "permission_denied"
    TOOL_NOT_FOUND = "tool_not_found"
    CANCELLED = "cancelled"
    SKIPPED = "skipped"


@dataclass
class ExecutionResult:
    """Result of executing a plan step."""
    step_id: str
    step_number: int
    
    # Status
    success: bool
    status: ExecutionStatus
    
    # Output
    output: Any = None
    output_type: str = "text"  # text, json, binary, etc.
    summary: str = ""
    
    # Error info
    error: Optional[str] = None
    error_type: Optional[str] = None
    traceback: Optional[str] = None
    
    # Timing
    start_time: datetime = None
    end_time: datetime = None
    duration_ms: int = 0
    
    # Tool info
    tool_name: Optional[str] = None
    tool_params: Dict[str, Any] = field(default_factory=dict)
    
    # Memory updates triggered
    memory_updates: List[Dict[str, Any]] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'step_id': self.step_id,
            'step_number': self.step_number,
            'success': self.success,
            'status': self.status.value,
            'output': str(self.output)[:500] if self.output else None,
            'summary': self.summary,
            'error': self.error,
            'duration_ms': self.duration_ms,
            'tool_name': self.tool_name,
        }


class Executor:
    """
    ═══════════════════════════════════════════════════════════════════════════
    TOOL EXECUTION ENGINE
    ═══════════════════════════════════════════════════════════════════════════
    
    Executes plan steps safely with proper error handling.
    """
    
    # Default timeout for tool execution
    DEFAULT_TIMEOUT = 60  # seconds
    
    # Maximum output size to store
    MAX_OUTPUT_SIZE = 10000  # characters
    
    def __init__(
        self,
        tools: ToolRegistry,
        security: SecurityManager,
        memory: MemoryManager,
        config: Dict[str, Any] = None
    ):
        """
        Initialize executor.
        
        Args:
            tools: Tool registry
            security: Security manager
            memory: Memory manager
            config: Configuration
        """
        self.logger = logging.getLogger("core.executor")
        self.tools = tools
        self.security = security
        self.memory = memory
        self.config = config or {}
        
        # Configuration
        self.default_timeout = self.config.get('default_timeout', self.DEFAULT_TIMEOUT)
        self.max_output_size = self.config.get('max_output_size', self.MAX_OUTPUT_SIZE)
        
        # Active executions (for cancellation)
        self._active_tasks: Dict[str, asyncio.Task] = {}
        
        # Statistics
        self.stats = {
            'total_executions': 0,
            'successful': 0,
            'failed': 0,
            'timeouts': 0,
            'permission_denied': 0,
            'avg_duration_ms': 0,
        }
        
    async def initialize(self) -> None:
        """Initialize executor."""
        self.logger.info("Initializing executor...")
        self.logger.info("Executor initialized")
        
    async def execute_step(
        self,
        step: PlanStep,
        context: Dict[str, Any] = None
    ) -> ExecutionResult:
        """
        Execute a single plan step.
        
        Args:
            step: The plan step to execute
            context: Execution context (loop_id, previous results, etc.)
            
        Returns:
            ExecutionResult with output and status
        """
        context = context or {}
        loop_id = context.get('loop_id', 'unknown')
        
        self.logger.info(f"[{loop_id}] Executing step {step.step_number}: {step.description}")
        self.stats['total_executions'] += 1
        
        start_time = datetime.utcnow()
        start_perf = time.perf_counter()
        
        # Initialize result
        result = ExecutionResult(
            step_id=step.step_id,
            step_number=step.step_number,
            success=False,
            status=ExecutionStatus.FAILED,
            start_time=start_time,
            tool_name=step.tool_name,
            tool_params=step.tool_params.copy()
        )
        
        try:
            # ═══════════════════════════════════════════════════════════════
            # STEP 1: Validate step
            # ═══════════════════════════════════════════════════════════════
            if not step.tool_name:
                # No tool needed - this is an info step
                result.success = True
                result.status = ExecutionStatus.SUCCESS
                result.output = step.description
                result.summary = "Information step (no tool execution)"
                return self._finalize_result(result, start_perf)
                
            # ═══════════════════════════════════════════════════════════════
            # STEP 2: Check if tool exists
            # ═══════════════════════════════════════════════════════════════
            if not self.tools.has_tool(step.tool_name):
                self.logger.error(f"Tool not found: {step.tool_name}")
                result.status = ExecutionStatus.TOOL_NOT_FOUND
                result.error = f"Tool '{step.tool_name}' not found in registry"
                return self._finalize_result(result, start_perf)
                
            # ═══════════════════════════════════════════════════════════════
            # STEP 3: Check permissions
            # ═══════════════════════════════════════════════════════════════
            permission = await self.security.check_tool_permission(
                tool_name=step.tool_name,
                params=step.tool_params
            )
            
            if not permission.allowed:
                self.logger.warning(f"Permission denied for {step.tool_name}: {permission.reason}")
                self.stats['permission_denied'] += 1
                result.status = ExecutionStatus.PERMISSION_DENIED
                result.error = f"Permission denied: {permission.reason}"
                return self._finalize_result(result, start_perf)
                
            # ═══════════════════════════════════════════════════════════════
            # STEP 4: Prepare parameters
            # ═══════════════════════════════════════════════════════════════
            params = await self._prepare_params(step, context)
            
            # ═══════════════════════════════════════════════════════════════
            # STEP 5: Execute tool with timeout
            # ═══════════════════════════════════════════════════════════════
            timeout = step.timeout_seconds or self.default_timeout
            
            try:
                tool_result = await asyncio.wait_for(
                    self._execute_tool(step.tool_name, params),
                    timeout=timeout
                )
                
                result.success = tool_result.success
                result.status = ExecutionStatus.SUCCESS if tool_result.success else ExecutionStatus.FAILED
                result.output = self._truncate_output(tool_result.output)
                result.output_type = tool_result.output_type
                result.error = tool_result.error
                
            except asyncio.TimeoutError:
                self.logger.warning(f"Timeout executing {step.tool_name} after {timeout}s")
                self.stats['timeouts'] += 1
                result.status = ExecutionStatus.TIMEOUT
                result.error = f"Execution timed out after {timeout} seconds"
                
            except asyncio.CancelledError:
                result.status = ExecutionStatus.CANCELLED
                result.error = "Execution was cancelled"
                
            # ═══════════════════════════════════════════════════════════════
            # STEP 6: Generate summary
            # ═══════════════════════════════════════════════════════════════
            result.summary = self._generate_summary(result)
            
            # ═══════════════════════════════════════════════════════════════
            # STEP 7: Check for memory updates
            # ═══════════════════════════════════════════════════════════════
            if result.success:
                memory_updates = await self._check_memory_updates(step, result)
                result.memory_updates = memory_updates
                
            # Update stats
            if result.success:
                self.stats['successful'] += 1
            else:
                self.stats['failed'] += 1
                
            return self._finalize_result(result, start_perf)
            
        except Exception as e:
            self.logger.error(f"Execution error: {e}", exc_info=True)
            self.stats['failed'] += 1
            result.error = str(e)
            result.error_type = type(e).__name__
            result.traceback = traceback.format_exc()
            return self._finalize_result(result, start_perf)
            
    async def _execute_tool(
        self,
        tool_name: str,
        params: Dict[str, Any]
    ) -> 'ToolResult':
        """
        Execute a tool and return result.
        
        Args:
            tool_name: Name of tool to execute
            params: Parameters for the tool
            
        Returns:
            ToolResult from the tool
        """
        tool = self.tools.get_tool(tool_name)
        
        if not tool:
            raise ValueError(f"Tool '{tool_name}' not found")
            
        self.logger.debug(f"Executing tool {tool_name} with params: {list(params.keys())}")
        
        # Execute the tool
        result = await tool.execute(**params)
        
        return result
        
    async def _prepare_params(
        self,
        step: PlanStep,
        context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Prepare parameters for tool execution.
        
        Handles:
        - Variable substitution from previous results
        - Path sanitization
        - Default values
        """
        params = step.tool_params.copy()
        previous_results = context.get('previous_results', [])
        
        # Substitute variables like {{step_1_output}}
        for key, value in params.items():
            if isinstance(value, str) and '{{' in value:
                params[key] = self._substitute_variables(value, previous_results)
                
        # Sanitize paths
        if 'path' in params:
            params['path'] = await self.security.sanitize_path(params['path'])
            
        if 'command' in params:
            params['command'] = await self.security.sanitize_command(params['command'])
            
        return params
        
    def _substitute_variables(
        self,
        template: str,
        previous_results: List[ExecutionResult]
    ) -> str:
        """Substitute variables in template."""
        import re
        
        def replace_var(match):
            var_name = match.group(1)
            
            # Parse step reference
            if var_name.startswith('step_'):
                parts = var_name.split('_')
                if len(parts) >= 3:
                    step_num = int(parts[1])
                    field = '_'.join(parts[2:])
                    
                    # Find the result
                    for result in previous_results:
                        if result.step_number == step_num:
                            if field == 'output':
                                return str(result.output or '')
                            elif hasattr(result, field):
                                return str(getattr(result, field, ''))
                                
            return match.group(0)  # Keep original if not found
            
        return re.sub(r'\{\{(\w+)\}\}', replace_var, template)
        
    def _truncate_output(self, output: Any) -> Any:
        """Truncate output if too large."""
        if output is None:
            return None
            
        if isinstance(output, str):
            if len(output) > self.max_output_size:
                return output[:self.max_output_size] + f"\n... (truncated, {len(output)} total chars)"
                
        return output
        
    def _generate_summary(self, result: ExecutionResult) -> str:
        """Generate a human-readable summary of the result."""
        if result.success:
            if result.output:
                output_str = str(result.output)
                if len(output_str) > 100:
                    return f"Completed successfully: {output_str[:100]}..."
                return f"Completed: {output_str}"
            return "Completed successfully"
        else:
            if result.error:
                return f"Failed: {result.error[:100]}"
            return f"Failed with status: {result.status.value}"
            
    async def _check_memory_updates(
        self,
        step: PlanStep,
        result: ExecutionResult
    ) -> List[Dict[str, Any]]:
        """
        Check if tool output should update memory.
        
        If tool output contradicts memory, REALITY WINS.
        """
        updates = []
        
        # Skip if no output
        if not result.output:
            return updates
            
        # Check specific tool types that might update memory
        memory_tools = {
            'system_info': 'system',
            'disk_usage': 'system.disk',
            'memory_usage': 'system.memory',
            'service_status': 'services',
        }
        
        if result.tool_name in memory_tools:
            category = memory_tools[result.tool_name]
            
            # Get existing memory
            existing = await self.memory.get(category)
            
            if existing and existing.value != result.output:
                # Reality differs from memory - update memory
                verified, tag = await self.memory.verify_against_reality(
                    key=category,
                    actual_value=result.output,
                    category='system'
                )
                
                if not verified:
                    updates.append({
                        'type': 'UPDATED',
                        'key': category,
                        'old_value': existing.value,
                        'new_value': result.output,
                        'reason': f'Tool output ({result.tool_name}) differs from memory'
                    })
                    
        return updates
        
    def _finalize_result(
        self,
        result: ExecutionResult,
        start_perf: float
    ) -> ExecutionResult:
        """Finalize the execution result."""
        result.end_time = datetime.utcnow()
        result.duration_ms = int((time.perf_counter() - start_perf) * 1000)
        
        # Update step status
        if result.success:
            # Update average duration
            n = self.stats['successful']
            if n == 1:
                self.stats['avg_duration_ms'] = result.duration_ms
            else:
                self.stats['avg_duration_ms'] = (
                    (self.stats['avg_duration_ms'] * (n - 1) + result.duration_ms) / n
                )
                
        self.logger.info(
            f"Step {result.step_number} completed: "
            f"{'success' if result.success else 'failed'} in {result.duration_ms}ms"
        )
        
        return result
        
    async def execute_multiple(
        self,
        steps: List[PlanStep],
        context: Dict[str, Any] = None,
        stop_on_failure: bool = True
    ) -> List[ExecutionResult]:
        """
        Execute multiple steps in sequence.
        
        Args:
            steps: Steps to execute
            context: Execution context
            stop_on_failure: Stop if any step fails
            
        Returns:
            List of execution results
        """
        results = []
        context = context or {}
        context['previous_results'] = results
        
        for step in steps:
            result = await self.execute_step(step, context)
            results.append(result)
            
            if not result.success and stop_on_failure:
                self.logger.info(f"Stopping execution due to failure at step {step.step_number}")
                break
                
        return results
        
    async def cancel_step(self, step_id: str) -> bool:
        """Cancel a running step."""
        if step_id in self._active_tasks:
            task = self._active_tasks[step_id]
            task.cancel()
            del self._active_tasks[step_id]
            return True
        return False
        
    async def cancel_all(self) -> int:
        """Cancel all running steps."""
        count = len(self._active_tasks)
        for task in self._active_tasks.values():
            task.cancel()
        self._active_tasks.clear()
        return count
        
    def get_stats(self) -> Dict[str, Any]:
        """Get executor statistics."""
        return {
            **self.stats,
            'active_executions': len(self._active_tasks),
        }
        
    async def shutdown(self) -> None:
        """Shutdown executor."""
        await self.cancel_all()
        self.logger.info("Executor shutdown complete")