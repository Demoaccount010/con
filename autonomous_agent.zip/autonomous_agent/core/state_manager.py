#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 STATE MANAGER - RUNTIME STATE TRACKING
═══════════════════════════════════════════════════════════════════════════════

 Manages the runtime state of the agent.
 
 STATE MANAGEMENT PHILOSOPHY:
 ────────────────────────────
 • Track current operation state
 • Maintain conversation context
 • Persist state for recovery
 • Enable state inspection
 • Support graceful shutdown
 
 TRACKED STATE:
 ──────────────
 • Current task (if any)
 • Conversation history
 • Active operations
 • User session info
 • System health status
 
 PERSISTENCE:
 ────────────
 • Critical state persisted to memory
 • Session state cached
 • Recovery data stored
 
 Author: System Engineer
 Version: 3.0.0
 
═══════════════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
from enum import Enum
from collections import deque

from memory.memory_manager import MemoryManager, MemoryType


class AgentState(Enum):
    """Overall agent state."""
    STARTING = "starting"
    READY = "ready"
    PROCESSING = "processing"
    IDLE = "idle"
    RESEARCHING = "researching"
    ERROR = "error"
    SHUTTING_DOWN = "shutting_down"


class TaskState(Enum):
    """State of current task."""
    NONE = "none"
    RECEIVING = "receiving"
    THINKING = "thinking"
    PLANNING = "planning"
    EXECUTING = "executing"
    OBSERVING = "observing"
    RESPONDING = "responding"
    COMPLETE = "complete"
    FAILED = "failed"


@dataclass
class CurrentTask:
    """Information about current task."""
    task_id: str
    input_text: str
    state: TaskState
    started_at: datetime
    phase_times: Dict[str, int] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'task_id': self.task_id,
            'input_text': self.input_text[:100],
            'state': self.state.value,
            'started_at': self.started_at.isoformat(),
            'duration_seconds': (datetime.utcnow() - self.started_at).total_seconds(),
        }


@dataclass
class ConversationTurn:
    """A single turn in conversation."""
    turn_id: str
    role: str  # user or agent
    content: str
    timestamp: datetime
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SessionInfo:
    """Session information."""
    session_id: str
    started_at: datetime
    last_activity: datetime
    user_id: Optional[str] = None
    interface: str = "cli"  # cli, telegram, api, etc.
    
    @property
    def duration(self) -> timedelta:
        """Get session duration."""
        return datetime.utcnow() - self.started_at
        
    @property
    def idle_time(self) -> timedelta:
        """Get time since last activity."""
        return datetime.utcnow() - self.last_activity


class StateManager:
    """
    ═══════════════════════════════════════════════════════════════════════════
    RUNTIME STATE MANAGER
    ═══════════════════════════════════════════════════════════════════════════
    
    Tracks and manages all runtime state of the agent.
    """
    
    # Configuration
    MAX_CONVERSATION_HISTORY = 100
    MAX_TASK_HISTORY = 50
    IDLE_TIMEOUT_MINUTES = 5
    
    def __init__(self, memory: MemoryManager):
        """
        Initialize state manager.
        
        Args:
            memory: Memory manager for persistence
        """
        self.logger = logging.getLogger("core.state_manager")
        self.memory = memory
        
        # Agent state
        self._agent_state = AgentState.STARTING
        
        # Current task
        self._current_task: Optional[CurrentTask] = None
        
        # Task history
        self._task_history: deque = deque(maxlen=self.MAX_TASK_HISTORY)
        
        # Conversation history
        self._conversation: deque = deque(maxlen=self.MAX_CONVERSATION_HISTORY)
        
        # Session info
        self._session: Optional[SessionInfo] = None
        
        # Active operations
        self._active_operations: Dict[str, Dict[str, Any]] = {}
        
        # Custom state storage
        self._custom_state: Dict[str, Any] = {}
        
        # Lock for state modifications
        self._lock = asyncio.Lock()
        
        # Statistics
        self.stats = {
            'tasks_processed': 0,
            'errors_encountered': 0,
            'state_persists': 0,
            'state_restores': 0,
        }
        
    async def initialize(self) -> None:
        """Initialize state manager and restore any persisted state."""
        self.logger.info("Initializing state manager...")
        
        # Create session
        self._session = SessionInfo(
            session_id=self._generate_id(),
            started_at=datetime.utcnow(),
            last_activity=datetime.utcnow()
        )
        
        # Try to restore previous state
        await self._restore_state()
        
        # Set to ready
        self._agent_state = AgentState.READY
        
        self.logger.info(f"State manager initialized (session: {self._session.session_id})")
        
    async def _restore_state(self) -> None:
        """Restore state from memory if available."""
        try:
            saved_state = await self.memory.get('agent_state_backup', 'system')
            
            if saved_state:
                self.logger.info("Restoring state from backup...")
                
                # Restore conversation if recent
                if saved_state.value.get('conversation'):
                    last_save = datetime.fromisoformat(
                        saved_state.value.get('saved_at', datetime.utcnow().isoformat())
                    )
                    
                    # Only restore if within last hour
                    if datetime.utcnow() - last_save < timedelta(hours=1):
                        for turn in saved_state.value.get('conversation', [])[-10:]:
                            self._conversation.append(ConversationTurn(
                                turn_id=turn.get('turn_id', ''),
                                role=turn.get('role', 'user'),
                                content=turn.get('content', ''),
                                timestamp=datetime.fromisoformat(turn.get('timestamp', datetime.utcnow().isoformat())),
                                metadata=turn.get('metadata', {})
                            ))
                            
                self.stats['state_restores'] += 1
                self.logger.info("State restored successfully")
                
        except Exception as e:
            self.logger.warning(f"Could not restore state: {e}")
            
    # ═══════════════════════════════════════════════════════════════════════════
    # AGENT STATE
    # ═══════════════════════════════════════════════════════════════════════════
    
    @property
    def agent_state(self) -> AgentState:
        """Get current agent state."""
        return self._agent_state
        
    async def set_agent_state(self, state: AgentState) -> None:
        """Set agent state."""
        async with self._lock:
            old_state = self._agent_state
            self._agent_state = state
            
            self.logger.debug(f"Agent state: {old_state.value} → {state.value}")
            
            # Update session activity
            if self._session:
                self._session.last_activity = datetime.utcnow()
                
    def is_idle(self) -> bool:
        """Check if agent is idle."""
        if self._current_task:
            return False
            
        if self._session:
            return self._session.idle_time > timedelta(minutes=self.IDLE_TIMEOUT_MINUTES)
            
        return True
        
    def is_processing(self) -> bool:
        """Check if agent is processing a task."""
        return self._current_task is not None
        
    # ═══════════════════════════════════════════════════════════════════════════
    # TASK STATE
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def set_current_task(
        self,
        task_id: str,
        input_text: str
    ) -> CurrentTask:
        """Set the current task being processed."""
        async with self._lock:
            self._current_task = CurrentTask(
                task_id=task_id,
                input_text=input_text,
                state=TaskState.RECEIVING,
                started_at=datetime.utcnow()
            )
            
            self._agent_state = AgentState.PROCESSING
            
            # Update session
            if self._session:
                self._session.last_activity = datetime.utcnow()
                
            self.logger.debug(f"New task: {task_id}")
            
            return self._current_task
            
    async def update_task_state(self, state: TaskState) -> None:
        """Update current task state."""
        async with self._lock:
            if self._current_task:
                old_state = self._current_task.state
                self._current_task.state = state
                
                # Record phase timing
                self._current_task.phase_times[old_state.value] = \
                    int((datetime.utcnow() - self._current_task.started_at).total_seconds() * 1000)
                    
                self.logger.debug(f"Task state: {old_state.value} → {state.value}")
                
    async def clear_current_task(self) -> Optional[CurrentTask]:
        """Clear current task and add to history."""
        async with self._lock:
            if self._current_task:
                # Add to history
                self._task_history.append({
                    'task_id': self._current_task.task_id,
                    'input_text': self._current_task.input_text[:100],
                    'state': self._current_task.state.value,
                    'duration_ms': int((datetime.utcnow() - self._current_task.started_at).total_seconds() * 1000),
                    'completed_at': datetime.utcnow().isoformat()
                })
                
                self.stats['tasks_processed'] += 1
                
                completed_task = self._current_task
                self._current_task = None
                self._agent_state = AgentState.IDLE
                
                return completed_task
                
            return None
            
    def get_current_task(self) -> Optional[CurrentTask]:
        """Get current task info."""
        return self._current_task
        
    def get_task_history(self, limit: int = 20) -> List[Dict[str, Any]]:
        """Get recent task history."""
        return list(self._task_history)[-limit:]
        
    # ═══════════════════════════════════════════════════════════════════════════
    # CONVERSATION STATE
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def add_conversation_turn(
        self,
        role: str,
        content: str,
        metadata: Dict[str, Any] = None
    ) -> ConversationTurn:
        """Add a turn to conversation history."""
        async with self._lock:
            turn = ConversationTurn(
                turn_id=self._generate_id(),
                role=role,
                content=content,
                timestamp=datetime.utcnow(),
                metadata=metadata or {}
            )
            
            self._conversation.append(turn)
            
            # Update session
            if self._session:
                self._session.last_activity = datetime.utcnow()
                
            return turn
            
    def get_conversation_history(self, limit: int = 20) -> List[ConversationTurn]:
        """Get recent conversation history."""
        return list(self._conversation)[-limit:]
        
    def get_conversation_context(self, max_turns: int = 5) -> str:
        """Get conversation as context string for LLM."""
        recent = list(self._conversation)[-max_turns:]
        
        lines = []
        for turn in recent:
            role = "User" if turn.role == "user" else "Agent"
            lines.append(f"{role}: {turn.content}")
            
        return "\n".join(lines)
        
    async def clear_conversation(self) -> int:
        """Clear conversation history."""
        async with self._lock:
            count = len(self._conversation)
            self._conversation.clear()
            return count
            
    # ═══════════════════════════════════════════════════════════════════════════
    # SESSION STATE
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_session_info(self) -> Optional[SessionInfo]:
        """Get current session info."""
        return self._session
        
    async def set_session_user(self, user_id: str) -> None:
        """Set the user for this session."""
        if self._session:
            self._session.user_id = user_id
            
    async def set_session_interface(self, interface: str) -> None:
        """Set the interface for this session."""
        if self._session:
            self._session.interface = interface
            
    # ═══════════════════════════════════════════════════════════════════════════
    # ACTIVE OPERATIONS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def register_operation(
        self,
        operation_id: str,
        operation_type: str,
        details: Dict[str, Any] = None
    ) -> None:
        """Register an active operation."""
        async with self._lock:
            self._active_operations[operation_id] = {
                'type': operation_type,
                'started_at': datetime.utcnow().isoformat(),
                'details': details or {}
            }
            
    async def complete_operation(self, operation_id: str) -> bool:
        """Mark an operation as complete."""
        async with self._lock:
            if operation_id in self._active_operations:
                del self._active_operations[operation_id]
                return True
            return False
            
    def get_active_operations(self) -> Dict[str, Dict[str, Any]]:
        """Get all active operations."""
        return self._active_operations.copy()
        
    # ═══════════════════════════════════════════════════════════════════════════
    # CUSTOM STATE
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def set_state(self, key: str, value: Any) -> None:
        """Set a custom state value."""
        async with self._lock:
            self._custom_state[key] = value
            
    def get_state(self, key: str, default: Any = None) -> Any:
        """Get a custom state value."""
        return self._custom_state.get(key, default)
        
    async def delete_state(self, key: str) -> bool:
        """Delete a custom state value."""
        async with self._lock:
            if key in self._custom_state:
                del self._custom_state[key]
                return True
            return False
            
    # ═══════════════════════════════════════════════════════════════════════════
    # PERSISTENCE
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def persist(self) -> None:
        """Persist current state to memory for recovery."""
        self.logger.info("Persisting state...")
        
        state_backup = {
            'saved_at': datetime.utcnow().isoformat(),
            'session_id': self._session.session_id if self._session else None,
            'agent_state': self._agent_state.value,
            'conversation': [
                {
                    'turn_id': t.turn_id,
                    'role': t.role,
                    'content': t.content,
                    'timestamp': t.timestamp.isoformat(),
                    'metadata': t.metadata
                }
                for t in list(self._conversation)[-20:]  # Last 20 turns
            ],
            'task_history': list(self._task_history)[-10:],
            'custom_state': self._custom_state,
            'stats': self.stats
        }
        
        await self.memory.store(
            key='agent_state_backup',
            value=state_backup,
            memory_type=MemoryType.SYSTEM,
            category='system'
        )
        
        self.stats['state_persists'] += 1
        self.logger.info("State persisted successfully")
        
    # ═══════════════════════════════════════════════════════════════════════════
    # STATUS AND STATS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_status(self) -> Dict[str, Any]:
        """Get complete status snapshot."""
        return {
            'agent_state': self._agent_state.value,
            'is_idle': self.is_idle(),
            'is_processing': self.is_processing(),
            'current_task': self._current_task.to_dict() if self._current_task else None,
            'session': {
                'id': self._session.session_id if self._session else None,
                'duration_seconds': self._session.duration.total_seconds() if self._session else 0,
                'idle_seconds': self._session.idle_time.total_seconds() if self._session else 0,
                'interface': self._session.interface if self._session else None,
            },
            'conversation_length': len(self._conversation),
            'active_operations': len(self._active_operations),
            'stats': self.stats
        }
        
    def get_stats(self) -> Dict[str, Any]:
        """Get state manager statistics."""
        return {
            **self.stats,
            'conversation_length': len(self._conversation),
            'task_history_length': len(self._task_history),
            'active_operations': len(self._active_operations),
            'custom_state_keys': len(self._custom_state),
        }
        
    def _generate_id(self) -> str:
        """Generate a unique ID."""
        import uuid
        return str(uuid.uuid4())[:8]
        
    async def shutdown(self) -> None:
        """Shutdown state manager."""
        self.logger.info("Shutting down state manager...")
        
        # Persist final state
        await self.persist()
        
        # Update state
        self._agent_state = AgentState.SHUTTING_DOWN
        
        self.logger.info("State manager shutdown complete")