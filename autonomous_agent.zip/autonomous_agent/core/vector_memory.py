"""
Vector-based semantic memory system using ChromaDB
Enables intelligent memory recall based on meaning
"""

import json
from datetime import datetime
from typing import List, Dict, Optional
import os

try:
    import chromadb
    from chromadb.config import Settings
    CHROMADB_AVAILABLE = True
except ImportError:
    CHROMADB_AVAILABLE = False

try:
    from sentence_transformers import SentenceTransformer
    SENTENCE_TRANSFORMERS_AVAILABLE = True
except ImportError:
    SENTENCE_TRANSFORMERS_AVAILABLE = False

try:
    from ..utils import setup_logger
    from ..config import VECTOR_DB_PATH, EMBEDDING_MODEL
except ImportError:
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from utils import setup_logger
    from config import VECTOR_DB_PATH, EMBEDDING_MODEL

class VectorMemory:
    """
    Semantic memory using vector embeddings
    """
    
    def __init__(self, persist_directory: str = None):
        """
        Initialize ChromaDB and embedding model
        
        Args:
            persist_directory: Where to store vector database
        """
        self.logger = setup_logger(self.__class__.__name__)
        
        # Check if dependencies are available
        if not CHROMADB_AVAILABLE:
            self.logger.warning("ChromaDB not available. Install: pip install chromadb")
            self.available = False
            return
        
        if not SENTENCE_TRANSFORMERS_AVAILABLE:
            self.logger.warning("sentence-transformers not available. Install: pip install sentence-transformers")
            self.available = False
            return
        
        self.available = True
        
        # Create directory if not exists
        if persist_directory is None:
            persist_directory = str(VECTOR_DB_PATH)
        
        os.makedirs(persist_directory, exist_ok=True)
        
        try:
            # Initialize ChromaDB client
            self.client = chromadb.Client(Settings(
                chroma_db_impl="duckdb+parquet",
                persist_directory=persist_directory
            ))
            
            # Initialize embedding model
            self.embedding_model = SentenceTransformer(EMBEDDING_MODEL)
            
            # Get or create collections
            self.conversations_collection = self._get_or_create_collection("conversations")
            self.concepts_collection = self._get_or_create_collection("concepts")
            self.experiences_collection = self._get_or_create_collection("experiences")
            
            self.logger.info("Vector Memory initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize Vector Memory: {e}")
            self.available = False
    
    def _get_or_create_collection(self, name: str):
        """Get existing collection or create new one"""
        try:
            return self.client.get_collection(name)
        except:
            return self.client.create_collection(name)
    
    def create_embedding(self, text: str) -> List[float]:
        """
        Convert text to embedding vector
        
        Args:
            text: Text to embed
            
        Returns:
            List of floats representing the embedding
        """
        if not self.available:
            return []
        
        embedding = self.embedding_model.encode(text)
        return embedding.tolist()
    
    def store_conversation(self, user_input: str, agent_response: str, 
                          metadata: Dict = None) -> str:
        """
        Store conversation with semantic embedding
        
        Args:
            user_input: What user said
            agent_response: What agent replied
            metadata: Additional context
            
        Returns:
            Document ID
        """
        if not self.available:
            return ""
        
        # Combine for better semantic search
        combined_text = f"User: {user_input}\nAgent: {agent_response}"
        
        # Create embedding
        embedding = self.create_embedding(combined_text)
        
        # Prepare metadata
        if metadata is None:
            metadata = {}
        metadata.update({
            "timestamp": datetime.now().isoformat(),
            "user_input": user_input,
            "agent_response": agent_response
        })
        
        # Generate unique ID
        doc_id = f"conv_{datetime.now().timestamp()}"
        
        # Store in ChromaDB
        self.conversations_collection.add(
            embeddings=[embedding],
            documents=[combined_text],
            metadatas=[metadata],
            ids=[doc_id]
        )
        
        return doc_id
    
    def store_concept(self, concept_name: str, concept_data: Dict) -> str:
        """
        Store learned concept with semantic embedding
        
        Args:
            concept_name: Name of the concept
            concept_data: {
                "description": str,
                "category": str,
                "examples": list,
                "related_concepts": list
            }
            
        Returns:
            Document ID
        """
        if not self.available:
            return ""
        
        # Create text representation
        text = f"{concept_name}: {concept_data.get('description', '')}"
        if 'examples' in concept_data:
            text += f" Examples: {', '.join(concept_data['examples'])}"
        
        # Create embedding
        embedding = self.create_embedding(text)
        
        # Prepare metadata
        metadata = {
            "concept_name": concept_name,
            "category": concept_data.get("category", "general"),
            "timestamp": datetime.now().isoformat(),
            "data": json.dumps(concept_data)
        }
        
        # Generate ID
        doc_id = f"concept_{concept_name}_{datetime.now().timestamp()}"
        
        # Store
        self.concepts_collection.add(
            embeddings=[embedding],
            documents=[text],
            metadatas=[metadata],
            ids=[doc_id]
        )
        
        return doc_id
    
    def store_experience(self, task: str, approach: List[str], 
                        outcome: Dict) -> str:
        """
        Store task experience for learning
        
        Args:
            task: What was attempted
            approach: Steps taken
            outcome: Result details
            
        Returns:
            Document ID
        """
        if not self.available:
            return ""
        
        # Create text
        text = f"Task: {task}\nApproach: {' -> '.join(approach)}\n"
        text += f"Success: {outcome.get('success', False)}"
        
        # Create embedding
        embedding = self.create_embedding(text)
        
        # Metadata
        metadata = {
            "task": task,
            "success": outcome.get('success', False),
            "timestamp": datetime.now().isoformat(),
            "approach": json.dumps(approach),
            "outcome": json.dumps(outcome)
        }
        
        # Generate ID
        doc_id = f"exp_{datetime.now().timestamp()}"
        
        # Store
        self.experiences_collection.add(
            embeddings=[embedding],
            documents=[text],
            metadatas=[metadata],
            ids=[doc_id]
        )
        
        return doc_id
    
    def semantic_search(self, query: str, collection_type: str = "all", 
                       top_k: int = 5) -> List[Dict]:
        """
        Search memories semantically
        
        Args:
            query: Search query
            collection_type: "conversations", "concepts", "experiences", "all"
            top_k: Number of results
            
        Returns:
            List of relevant memories with scores
        """
        if not self.available:
            return []
        
        # Create query embedding
        query_embedding = self.create_embedding(query)
        
        results = []
        
        # Determine which collections to search
        collections = []
        if collection_type == "all":
            collections = [
                ("conversations", self.conversations_collection),
                ("concepts", self.concepts_collection),
                ("experiences", self.experiences_collection)
            ]
        elif collection_type == "conversations":
            collections = [("conversations", self.conversations_collection)]
        elif collection_type == "concepts":
            collections = [("concepts", self.concepts_collection)]
        elif collection_type == "experiences":
            collections = [("experiences", self.experiences_collection)]
        
        # Search each collection
        for coll_name, collection in collections:
            try:
                search_results = collection.query(
                    query_embeddings=[query_embedding],
                    n_results=top_k
                )
                
                # Format results
                if search_results['ids'] and len(search_results['ids'][0]) > 0:
                    for i in range(len(search_results['ids'][0])):
                        results.append({
                            "collection": coll_name,
                            "id": search_results['ids'][0][i],
                            "text": search_results['documents'][0][i],
                            "metadata": search_results['metadatas'][0][i],
                            "distance": search_results['distances'][0][i],
                            "relevance": 1 - search_results['distances'][0][i]  # Convert distance to relevance
                        })
            except Exception as e:
                self.logger.error(f"Error searching {coll_name}: {e}")
        
        # Sort by relevance
        results.sort(key=lambda x: x['relevance'], reverse=True)
        
        return results[:top_k]
    
    def find_similar_experiences(self, current_task: str, top_k: int = 3) -> List[Dict]:
        """
        Find similar past experiences for current task
        
        Args:
            current_task: Current task description
            top_k: Number of similar experiences
            
        Returns:
            List of similar experiences with success info
        """
        return self.semantic_search(current_task, "experiences", top_k)
    
    def get_related_concepts(self, topic: str, top_k: int = 5) -> List[Dict]:
        """
        Get concepts related to a topic
        
        Args:
            topic: Topic to find related concepts for
            top_k: Number of concepts
            
        Returns:
            List of related concepts
        """
        return self.semantic_search(topic, "concepts", top_k)
    
    def get_conversation_context(self, current_input: str, top_k: int = 3) -> List[Dict]:
        """
        Get relevant past conversations for context
        
        Args:
            current_input: Current user input
            top_k: Number of conversations
            
        Returns:
            List of relevant past conversations
        """
        return self.semantic_search(current_input, "conversations", top_k)
    
    def build_knowledge_graph(self) -> Dict:
        """
        Build a knowledge graph from all concepts
        
        Returns:
            Dict representing concept relationships
        """
        if not self.available:
            return {"nodes": [], "edges": []}
        
        # Get all concepts
        all_concepts = self.concepts_collection.get()
        
        if not all_concepts['ids']:
            return {"nodes": [], "edges": []}
        
        # Build graph
        nodes = []
        edges = []
        
        for i, concept_id in enumerate(all_concepts['ids']):
            metadata = all_concepts['metadatas'][i]
            concept_name = metadata.get('concept_name', 'Unknown')
            
            # Add node
            nodes.append({
                "id": concept_id,
                "name": concept_name,
                "category": metadata.get('category', 'general')
            })
            
            # Parse data for related concepts
            try:
                data = json.loads(metadata.get('data', '{}'))
                related = data.get('related_concepts', [])
                
                for related_concept in related:
                    edges.append({
                        "from": concept_id,
                        "to": related_concept,
                        "type": "related"
                    })
            except:
                pass
        
        return {
            "nodes": nodes,
            "edges": edges,
            "total_concepts": len(nodes),
            "total_relationships": len(edges)
        }
    
    def consolidate_knowledge(self) -> Dict:
        """
        Consolidate and clean up knowledge base
        
        Returns:
            Stats about consolidation
        """
        if not self.available:
            return {}
        
        stats = {
            "before": {
                "conversations": len(self.conversations_collection.get()['ids'] or []),
                "concepts": len(self.concepts_collection.get()['ids'] or []),
                "experiences": len(self.experiences_collection.get()['ids'] or [])
            },
            "duplicates_removed": 0,
            "old_items_archived": 0
        }
        
        stats["after"] = stats["before"].copy()
        
        return stats
    
    def get_statistics(self) -> Dict:
        """
        Get memory system statistics
        
        Returns:
            Dict with stats
        """
        if not self.available:
            return {
                "available": False,
                "error": "Vector memory dependencies not installed"
            }
        
        return {
            "available": True,
            "total_conversations": len(self.conversations_collection.get()['ids'] or []),
            "total_concepts": len(self.concepts_collection.get()['ids'] or []),
            "total_experiences": len(self.experiences_collection.get()['ids'] or []),
            "embedding_model": EMBEDDING_MODEL,
            "vector_db": "ChromaDB"
        }
