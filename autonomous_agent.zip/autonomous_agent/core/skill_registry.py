"""
Skill Registry - Manages and tracks all agent skills
"""
import json
import sqlite3
from typing import Dict, List, Optional, Callable
from pathlib import Path
from datetime import datetime

try:
    from ..utils import setup_logger, timestamp, hash_content
    from ..config import DATA_DIR, SKILLS_DIR
except ImportError:
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from utils import setup_logger, timestamp, hash_content
    from config import DATA_DIR, SKILLS_DIR

class SkillRegistry:
    """
    Central registry for all agent skills
    """
    
    def __init__(self, db_path: Path = None):
        """Initialize Skill Registry"""
        self.logger = setup_logger(self.__class__.__name__)
        self.db_path = db_path or DATA_DIR / "skills.db"
        self._initialize_db()
        self.active_skills = {}
        self.logger.info("Skill Registry initialized")
    
    def _initialize_db(self):
        """Initialize database for skill registry"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Skills table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS skills (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                description TEXT NOT NULL,
                category TEXT,
                version TEXT DEFAULT '1.0.0',
                code_hash TEXT,
                parameters TEXT,
                return_type TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                status TEXT DEFAULT 'active',
                metadata TEXT
            )
        ''')
        
        # Skill executions table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS skill_executions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                skill_id INTEGER NOT NULL,
                timestamp TEXT NOT NULL,
                duration_ms INTEGER,
                success BOOLEAN NOT NULL,
                error_message TEXT,
                input_params TEXT,
                output_result TEXT,
                FOREIGN KEY (skill_id) REFERENCES skills(id)
            )
        ''')
        
        # Skill dependencies table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS skill_dependencies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                skill_id INTEGER NOT NULL,
                dependency_type TEXT NOT NULL,
                dependency_name TEXT NOT NULL,
                FOREIGN KEY (skill_id) REFERENCES skills(id)
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def register_skill(self, name: str, description: str, code: str = None,
                      category: str = "general", parameters: List[str] = None,
                      return_type: str = "any", metadata: Dict = None) -> int:
        """
        Register a new skill
        
        Args:
            name: Skill name
            description: Skill description
            code: Optional skill code
            category: Skill category
            parameters: List of parameter names
            return_type: Expected return type
            metadata: Additional metadata
        
        Returns:
            Skill ID
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        code_hash = hash_content(code) if code else None
        
        try:
            cursor.execute('''
                INSERT INTO skills
                (name, description, category, code_hash, parameters, return_type,
                 created_at, updated_at, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                name,
                description,
                category,
                code_hash,
                json.dumps(parameters or []),
                return_type,
                timestamp(),
                timestamp(),
                json.dumps(metadata or {})
            ))
            
            skill_id = cursor.lastrowid
            conn.commit()
            
            self.logger.info(f"Registered skill: {name}")
            return skill_id
            
        except sqlite3.IntegrityError:
            self.logger.warning(f"Skill {name} already exists, updating...")
            cursor.execute('''
                UPDATE skills
                SET description = ?,
                    category = ?,
                    code_hash = ?,
                    parameters = ?,
                    return_type = ?,
                    updated_at = ?,
                    metadata = ?
                WHERE name = ?
            ''', (
                description,
                category,
                code_hash,
                json.dumps(parameters or []),
                return_type,
                timestamp(),
                json.dumps(metadata or {}),
                name
            ))
            
            cursor.execute('SELECT id FROM skills WHERE name = ?', (name,))
            skill_id = cursor.fetchone()[0]
            conn.commit()
            
            return skill_id
        finally:
            conn.close()
    
    def get_skill(self, name: str) -> Optional[Dict]:
        """Get skill information by name"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, name, description, category, version, parameters,
                   return_type, created_at, updated_at, status, metadata
            FROM skills
            WHERE name = ?
        ''', (name,))
        
        result = cursor.fetchone()
        conn.close()
        
        if not result:
            return None
        
        return {
            'id': result[0],
            'name': result[1],
            'description': result[2],
            'category': result[3],
            'version': result[4],
            'parameters': json.loads(result[5]) if result[5] else [],
            'return_type': result[6],
            'created_at': result[7],
            'updated_at': result[8],
            'status': result[9],
            'metadata': json.loads(result[10]) if result[10] else {}
        }
    
    def list_skills(self, category: str = None, status: str = 'active') -> List[Dict]:
        """List all registered skills"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        if category:
            cursor.execute('''
                SELECT id, name, description, category, version, status
                FROM skills
                WHERE status = ? AND category = ?
                ORDER BY name
            ''', (status, category))
        else:
            cursor.execute('''
                SELECT id, name, description, category, version, status
                FROM skills
                WHERE status = ?
                ORDER BY name
            ''', (status,))
        
        skills = []
        for row in cursor.fetchall():
            skills.append({
                'id': row[0],
                'name': row[1],
                'description': row[2],
                'category': row[3],
                'version': row[4],
                'status': row[5]
            })
        
        conn.close()
        return skills
    
    def record_execution(self, skill_name: str, duration_ms: int, success: bool,
                        error_message: str = None, input_params: Dict = None,
                        output_result: any = None) -> int:
        """Record a skill execution"""
        skill = self.get_skill(skill_name)
        if not skill:
            self.logger.error(f"Skill {skill_name} not found")
            return -1
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO skill_executions
            (skill_id, timestamp, duration_ms, success, error_message, 
             input_params, output_result)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            skill['id'],
            timestamp(),
            duration_ms,
            1 if success else 0,
            error_message,
            json.dumps(input_params or {}),
            str(output_result) if output_result else None
        ))
        
        execution_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return execution_id
    
    def get_skill_statistics(self, skill_name: str) -> Dict:
        """Get statistics for a specific skill"""
        skill = self.get_skill(skill_name)
        if not skill:
            return {}
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Total executions
        cursor.execute('''
            SELECT COUNT(*), AVG(duration_ms), 
                   SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END)
            FROM skill_executions
            WHERE skill_id = ?
        ''', (skill['id'],))
        
        result = cursor.fetchone()
        total, avg_duration, successes = result
        
        # Recent errors
        cursor.execute('''
            SELECT error_message, COUNT(*) as count
            FROM skill_executions
            WHERE skill_id = ? AND success = 0
            GROUP BY error_message
            ORDER BY count DESC
            LIMIT 5
        ''', (skill['id'],))
        
        errors = dict(cursor.fetchall())
        
        conn.close()
        
        success_rate = (successes / total) if total > 0 else 0.0
        
        return {
            'skill_name': skill_name,
            'total_executions': total,
            'success_rate': round(success_rate, 3),
            'average_duration_ms': round(avg_duration, 2) if avg_duration else 0,
            'common_errors': errors
        }
    
    def deactivate_skill(self, skill_name: str) -> bool:
        """Deactivate a skill"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            UPDATE skills
            SET status = 'inactive', updated_at = ?
            WHERE name = ?
        ''', (timestamp(), skill_name))
        
        success = cursor.rowcount > 0
        conn.commit()
        conn.close()
        
        if success:
            self.logger.info(f"Deactivated skill: {skill_name}")
        
        return success
    
    def activate_skill(self, skill_name: str) -> bool:
        """Activate a skill"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            UPDATE skills
            SET status = 'active', updated_at = ?
            WHERE name = ?
        ''', (timestamp(), skill_name))
        
        success = cursor.rowcount > 0
        conn.commit()
        conn.close()
        
        if success:
            self.logger.info(f"Activated skill: {skill_name}")
        
        return success
    
    def get_statistics(self) -> Dict:
        """Get overall registry statistics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Total skills by status
        cursor.execute('SELECT status, COUNT(*) FROM skills GROUP BY status')
        status_counts = dict(cursor.fetchall())
        
        # Skills by category
        cursor.execute('SELECT category, COUNT(*) FROM skills GROUP BY category')
        category_counts = dict(cursor.fetchall())
        
        # Total executions
        cursor.execute('SELECT COUNT(*) FROM skill_executions')
        total_executions = cursor.fetchone()[0]
        
        # Most used skill
        cursor.execute('''
            SELECT s.name, COUNT(e.id) as count
            FROM skills s
            JOIN skill_executions e ON s.id = e.skill_id
            GROUP BY s.name
            ORDER BY count DESC
            LIMIT 1
        ''')
        most_used = cursor.fetchone()
        
        conn.close()
        
        return {
            'total_skills': sum(status_counts.values()),
            'active_skills': status_counts.get('active', 0),
            'inactive_skills': status_counts.get('inactive', 0),
            'by_category': category_counts,
            'total_executions': total_executions,
            'most_used_skill': {
                'name': most_used[0] if most_used else None,
                'count': most_used[1] if most_used else 0
            }
        }
