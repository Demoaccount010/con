"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                         TELEGRAM BOT - MAIN CONTROLLER                        ║
║                    Full-featured Telegram Bot Integration                      ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import asyncio
import logging
from datetime import datetime
from typing import Optional, Dict, Any, List, Callable, Awaitable
from dataclasses import dataclass, field
from enum import Enum
import aiohttp
import json
from pathlib import Path

# Configure logging
logger = logging.getLogger(__name__)


class BotState(Enum):
    """Telegram bot states"""
    STOPPED = "stopped"
    STARTING = "starting"
    RUNNING = "running"
    STOPPING = "stopping"
    ERROR = "error"
    RECONNECTING = "reconnecting"


class UpdateType(Enum):
    """Types of Telegram updates"""
    MESSAGE = "message"
    EDITED_MESSAGE = "edited_message"
    CALLBACK_QUERY = "callback_query"
    INLINE_QUERY = "inline_query"
    COMMAND = "command"
    PHOTO = "photo"
    DOCUMENT = "document"
    VOICE = "voice"
    VIDEO = "video"
    STICKER = "sticker"
    UNKNOWN = "unknown"


@dataclass
class TelegramUser:
    """Telegram user information"""
    id: int
    first_name: str
    last_name: Optional[str] = None
    username: Optional[str] = None
    is_bot: bool = False
    language_code: Optional[str] = None
    is_owner: bool = False
    
    @property
    def full_name(self) -> str:
        if self.last_name:
            return f"{self.first_name} {self.last_name}"
        return self.first_name
    
    @property
    def mention(self) -> str:
        if self.username:
            return f"@{self.username}"
        return self.full_name


@dataclass
class TelegramChat:
    """Telegram chat information"""
    id: int
    type: str  # private, group, supergroup, channel
    title: Optional[str] = None
    username: Optional[str] = None
    
    @property
    def is_private(self) -> bool:
        return self.type == "private"
    
    @property
    def is_group(self) -> bool:
        return self.type in ("group", "supergroup")


@dataclass
class TelegramMessage:
    """Telegram message"""
    message_id: int
    chat: TelegramChat
    date: datetime
    text: Optional[str] = None
    from_user: Optional[TelegramUser] = None
    reply_to_message: Optional['TelegramMessage'] = None
    entities: List[Dict] = field(default_factory=list)
    photo: Optional[List[Dict]] = None
    document: Optional[Dict] = None
    voice: Optional[Dict] = None
    caption: Optional[str] = None
    
    @property
    def is_command(self) -> bool:
        if not self.text:
            return False
        return self.text.startswith('/')
    
    @property
    def command(self) -> Optional[str]:
        if not self.is_command:
            return None
        parts = self.text.split()
        cmd = parts[0][1:]  # Remove /
        if '@' in cmd:
            cmd = cmd.split('@')[0]
        return cmd.lower()
    
    @property
    def command_args(self) -> List[str]:
        if not self.is_command:
            return []
        parts = self.text.split()
        return parts[1:] if len(parts) > 1 else []


@dataclass
class CallbackQuery:
    """Telegram callback query"""
    id: str
    from_user: TelegramUser
    chat: Optional[TelegramChat] = None
    message: Optional[TelegramMessage] = None
    data: Optional[str] = None


@dataclass
class BotConfig:
    """Telegram bot configuration"""
    token: str
    owner_id: Optional[int] = None
    allowed_users: List[int] = field(default_factory=list)
    command_prefix: str = "/"
    polling_timeout: int = 30
    max_retries: int = 5
    retry_delay: float = 5.0
    rate_limit_messages: int = 30
    rate_limit_window: int = 60
    parse_mode: str = "HTML"
    disable_web_preview: bool = True


class RateLimiter:
    """Rate limiter for Telegram API"""
    
    def __init__(self, max_requests: int = 30, window_seconds: int = 60):
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self.requests: List[datetime] = []
        self._lock = asyncio.Lock()
    
    async def acquire(self) -> bool:
        """Acquire permission to make request"""
        async with self._lock:
            now = datetime.now()
            # Remove old requests
            self.requests = [
                t for t in self.requests 
                if (now - t).total_seconds() < self.window_seconds
            ]
            
            if len(self.requests) >= self.max_requests:
                return False
            
            self.requests.append(now)
            return True
    
    async def wait_and_acquire(self) -> None:
        """Wait until we can make a request"""
        while not await self.acquire():
            await asyncio.sleep(0.5)


class TelegramBot:
    """
    Main Telegram Bot class - Full-featured bot with all capabilities
    
    Features:
    - Long polling with auto-reconnect
    - Command and message handling
    - Inline keyboards
    - Media handling
    - Rate limiting
    - Owner authentication
    - Integration with agent loop
    """
    
    def __init__(
        self,
        config: BotConfig,
        agent_loop: Optional[Any] = None,
        memory_manager: Optional[Any] = None,
        output_manager: Optional[Any] = None
    ):
        self.config = config
        self.agent_loop = agent_loop
        self.memory_manager = memory_manager
        self.output_manager = output_manager
        
        # State
        self.state = BotState.STOPPED
        self._session: Optional[aiohttp.ClientSession] = None
        self._offset: int = 0
        self._running = False
        
        # Bot info
        self.bot_info: Optional[TelegramUser] = None
        
        # Handlers
        self._command_handlers: Dict[str, Callable] = {}
        self._message_handler: Optional[Callable] = None
        self._callback_handlers: Dict[str, Callable] = {}
        self._error_handler: Optional[Callable] = None
        
        # Rate limiting
        self._rate_limiter = RateLimiter(
            max_requests=config.rate_limit_messages,
            window_seconds=config.rate_limit_window
        )
        
        # Statistics
        self._stats = {
            "messages_received": 0,
            "messages_sent": 0,
            "commands_processed": 0,
            "errors": 0,
            "started_at": None
        }
        
        # API base URL
        self._api_url = f"https://api.telegram.org/bot{config.token}"
        
        logger.info("TelegramBot initialized")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # LIFECYCLE METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def start(self) -> bool:
        """Start the bot"""
        if self.state == BotState.RUNNING:
            logger.warning("Bot is already running")
            return True
        
        self.state = BotState.STARTING
        logger.info("Starting Telegram bot...")
        
        try:
            # Create session
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=60)
            )
            
            # Test connection and get bot info
            me = await self._api_call("getMe")
            if not me:
                raise Exception("Failed to get bot info")
            
            self.bot_info = TelegramUser(
                id=me["id"],
                first_name=me["first_name"],
                username=me.get("username"),
                is_bot=me.get("is_bot", True)
            )
            
            # Register default commands
            await self._register_default_commands()
            
            # Set commands menu
            await self._set_bot_commands()
            
            self.state = BotState.RUNNING
            self._running = True
            self._stats["started_at"] = datetime.now()
            
            logger.info(f"✅ Bot started: @{self.bot_info.username}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to start bot: {e}")
            self.state = BotState.ERROR
            if self._session:
                await self._session.close()
            return False
    
    async def stop(self) -> None:
        """Stop the bot"""
        if self.state == BotState.STOPPED:
            return
        
        self.state = BotState.STOPPING
        self._running = False
        logger.info("Stopping Telegram bot...")
        
        if self._session:
            await self._session.close()
            self._session = None
        
        self.state = BotState.STOPPED
        logger.info("Bot stopped")
    
    async def run_polling(self) -> None:
        """Run the bot with long polling"""
        if not await self.start():
            return
        
        logger.info("Starting polling loop...")
        retry_count = 0
        
        while self._running:
            try:
                updates = await self._get_updates()
                retry_count = 0  # Reset on success
                
                for update in updates:
                    asyncio.create_task(self._process_update(update))
                    
            except aiohttp.ClientError as e:
                retry_count += 1
                logger.error(f"Connection error: {e}")
                
                if retry_count > self.config.max_retries:
                    logger.error("Max retries exceeded, stopping")
                    break
                
                self.state = BotState.RECONNECTING
                await asyncio.sleep(self.config.retry_delay * retry_count)
                self.state = BotState.RUNNING
                
            except asyncio.CancelledError:
                break
                
            except Exception as e:
                logger.error(f"Polling error: {e}")
                self._stats["errors"] += 1
                await asyncio.sleep(1)
        
        await self.stop()
    
    # ═══════════════════════════════════════════════════════════════════════════
    # API METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _api_call(
        self,
        method: str,
        data: Optional[Dict] = None,
        files: Optional[Dict] = None
    ) -> Optional[Any]:
        """Make Telegram API call"""
        if not self._session:
            raise Exception("Session not initialized")
        
        url = f"{self._api_url}/{method}"
        
        try:
            await self._rate_limiter.wait_and_acquire()
            
            if files:
                # Multipart form data for file uploads
                form = aiohttp.FormData()
                if data:
                    for key, value in data.items():
                        if isinstance(value, dict):
                            form.add_field(key, json.dumps(value))
                        else:
                            form.add_field(key, str(value))
                for key, file_data in files.items():
                    form.add_field(key, file_data[0], filename=file_data[1])
                
                async with self._session.post(url, data=form) as resp:
                    result = await resp.json()
            else:
                async with self._session.post(url, json=data or {}) as resp:
                    result = await resp.json()
            
            if result.get("ok"):
                return result.get("result")
            else:
                error = result.get("description", "Unknown error")
                logger.error(f"API error: {error}")
                return None
                
        except Exception as e:
            logger.error(f"API call failed: {e}")
            return None
    
    async def _get_updates(self) -> List[Dict]:
        """Get updates from Telegram"""
        result = await self._api_call("getUpdates", {
            "offset": self._offset,
            "timeout": self.config.polling_timeout,
            "allowed_updates": [
                "message", "edited_message", "callback_query", "inline_query"
            ]
        })
        
        if not result:
            return []
        
        if result:
            # Update offset to last update + 1
            self._offset = max(u["update_id"] for u in result) + 1
        
        return result
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MESSAGE SENDING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def send_message(
        self,
        chat_id: int,
        text: str,
        parse_mode: Optional[str] = None,
        reply_to_message_id: Optional[int] = None,
        reply_markup: Optional[Dict] = None,
        disable_web_preview: Optional[bool] = None
    ) -> Optional[TelegramMessage]:
        """Send text message"""
        data = {
            "chat_id": chat_id,
            "text": text[:4096],  # Telegram limit
            "parse_mode": parse_mode or self.config.parse_mode,
            "disable_web_page_preview": (
                disable_web_preview if disable_web_preview is not None 
                else self.config.disable_web_preview
            )
        }
        
        if reply_to_message_id:
            data["reply_to_message_id"] = reply_to_message_id
        if reply_markup:
            data["reply_markup"] = reply_markup
        
        result = await self._api_call("sendMessage", data)
        
        if result:
            self._stats["messages_sent"] += 1
            return self._parse_message(result)
        return None
    
    async def send_long_message(
        self,
        chat_id: int,
        text: str,
        **kwargs
    ) -> List[TelegramMessage]:
        """Send message that might be longer than 4096 chars"""
        messages = []
        
        # Split into chunks
        chunks = []
        while text:
            if len(text) <= 4096:
                chunks.append(text)
                break
            
            # Find good split point
            split_point = text.rfind('\n', 0, 4096)
            if split_point == -1:
                split_point = text.rfind(' ', 0, 4096)
            if split_point == -1:
                split_point = 4096
            
            chunks.append(text[:split_point])
            text = text[split_point:].lstrip()
        
        for chunk in chunks:
            msg = await self.send_message(chat_id, chunk, **kwargs)
            if msg:
                messages.append(msg)
        
        return messages
    
    async def edit_message(
        self,
        chat_id: int,
        message_id: int,
        text: str,
        parse_mode: Optional[str] = None,
        reply_markup: Optional[Dict] = None
    ) -> Optional[TelegramMessage]:
        """Edit message text"""
        data = {
            "chat_id": chat_id,
            "message_id": message_id,
            "text": text[:4096],
            "parse_mode": parse_mode or self.config.parse_mode
        }
        
        if reply_markup:
            data["reply_markup"] = reply_markup
        
        result = await self._api_call("editMessageText", data)
        
        if result and isinstance(result, dict):
            return self._parse_message(result)
        return None
    
    async def delete_message(
        self,
        chat_id: int,
        message_id: int
    ) -> bool:
        """Delete a message"""
        result = await self._api_call("deleteMessage", {
            "chat_id": chat_id,
            "message_id": message_id
        })
        return bool(result)
    
    async def send_typing(self, chat_id: int) -> bool:
        """Send typing action"""
        result = await self._api_call("sendChatAction", {
            "chat_id": chat_id,
            "action": "typing"
        })
        return bool(result)
    
    async def answer_callback_query(
        self,
        callback_query_id: str,
        text: Optional[str] = None,
        show_alert: bool = False
    ) -> bool:
        """Answer callback query"""
        data = {"callback_query_id": callback_query_id}
        if text:
            data["text"] = text
            data["show_alert"] = show_alert
        
        result = await self._api_call("answerCallbackQuery", data)
        return bool(result)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # KEYBOARD BUILDERS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def build_inline_keyboard(
        self,
        buttons: List[List[Dict[str, str]]]
    ) -> Dict:
        """
        Build inline keyboard
        
        Args:
            buttons: List of rows, each row is list of buttons
                     Each button: {"text": "...", "callback_data": "..."}
                     or {"text": "...", "url": "..."}
        """
        keyboard = []
        for row in buttons:
            keyboard_row = []
            for btn in row:
                keyboard_row.append(btn)
            keyboard.append(keyboard_row)
        
        return {"inline_keyboard": keyboard}
    
    def build_reply_keyboard(
        self,
        buttons: List[List[str]],
        resize: bool = True,
        one_time: bool = False
    ) -> Dict:
        """Build reply keyboard"""
        keyboard = []
        for row in buttons:
            keyboard.append([{"text": btn} for btn in row])
        
        return {
            "keyboard": keyboard,
            "resize_keyboard": resize,
            "one_time_keyboard": one_time
        }
    
    def remove_keyboard(self) -> Dict:
        """Remove reply keyboard"""
        return {"remove_keyboard": True}
    
    # ═══════════════════════════════════════════════════════════════════════════
    # UPDATE PROCESSING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _process_update(self, update: Dict) -> None:
        """Process a single update"""
        try:
            if "message" in update:
                message = self._parse_message(update["message"])
                await self._handle_message(message)
                
            elif "edited_message" in update:
                message = self._parse_message(update["edited_message"])
                # Handle as regular message or separately
                await self._handle_message(message)
                
            elif "callback_query" in update:
                callback = self._parse_callback(update["callback_query"])
                await self._handle_callback(callback)
                
        except Exception as e:
            logger.error(f"Error processing update: {e}")
            self._stats["errors"] += 1
            if self._error_handler:
                await self._error_handler(update, e)
    
    async def _handle_message(self, message: TelegramMessage) -> None:
        """Handle incoming message"""
        self._stats["messages_received"] += 1
        
        # Check if user is allowed
        if not await self._is_user_allowed(message.from_user):
            logger.warning(f"Unauthorized user: {message.from_user.id}")
            await self.send_message(
                message.chat.id,
                "⛔ Sorry, you are not authorized to use this bot."
            )
            return
        
        # Mark owner
        if message.from_user and message.from_user.id == self.config.owner_id:
            message.from_user.is_owner = True
        
        # Handle command
        if message.is_command:
            await self._handle_command(message)
            return
        
        # Handle regular message
        if self._message_handler:
            await self._message_handler(message)
        elif self.agent_loop:
            # Process through agent
            await self._process_with_agent(message)
    
    async def _handle_command(self, message: TelegramMessage) -> None:
        """Handle command message"""
        command = message.command
        self._stats["commands_processed"] += 1
        
        if command in self._command_handlers:
            handler = self._command_handlers[command]
            await handler(message)
        else:
            await self.send_message(
                message.chat.id,
                f"❓ Unknown command: /{command}\n"
                f"Use /help to see available commands."
            )
    
    async def _handle_callback(self, callback: CallbackQuery) -> None:
        """Handle callback query"""
        if not callback.data:
            await self.answer_callback_query(callback.id)
            return
        
        # Find matching handler
        for prefix, handler in self._callback_handlers.items():
            if callback.data.startswith(prefix):
                await handler(callback)
                return
        
        # Default: acknowledge
        await self.answer_callback_query(callback.id, "✓")
    
    async def _process_with_agent(self, message: TelegramMessage) -> None:
        """Process message with agent loop"""
        if not self.agent_loop:
            await self.send_message(
                message.chat.id,
                "⚠️ Agent is not configured."
            )
            return
        
        # Send typing indicator
        await self.send_typing(message.chat.id)
        
        try:
            # Process through agent
            context = {
                "user_id": message.from_user.id if message.from_user else None,
                "username": message.from_user.username if message.from_user else None,
                "chat_id": message.chat.id,
                "message_id": message.message_id,
                "is_owner": message.from_user.is_owner if message.from_user else False,
                "platform": "telegram"
            }
            
            response = await self.agent_loop.process_input(
                message.text or message.caption or "",
                context=context
            )
            
            # Format and send response
            if self.output_manager:
                formatted = await self.output_manager.format_for_telegram(response)
            else:
                formatted = str(response)
            
            await self.send_long_message(
                message.chat.id,
                formatted,
                reply_to_message_id=message.message_id
            )
            
        except Exception as e:
            logger.error(f"Agent processing error: {e}")
            await self.send_message(
                message.chat.id,
                f"❌ Error processing your request: {str(e)}"
            )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # HANDLER REGISTRATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    def command(self, name: str):
        """Decorator to register command handler"""
        def decorator(func: Callable[[TelegramMessage], Awaitable[None]]):
            self._command_handlers[name.lower()] = func
            return func
        return decorator
    
    def on_message(self, func: Callable[[TelegramMessage], Awaitable[None]]):
        """Decorator to register message handler"""
        self._message_handler = func
        return func
    
    def callback(self, prefix: str):
        """Decorator to register callback handler"""
        def decorator(func: Callable[[CallbackQuery], Awaitable[None]]):
            self._callback_handlers[prefix] = func
            return func
        return decorator
    
    def on_error(self, func: Callable[[Dict, Exception], Awaitable[None]]):
        """Decorator to register error handler"""
        self._error_handler = func
        return func
    
    # ═══════════════════════════════════════════════════════════════════════════
    # DEFAULT COMMANDS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _register_default_commands(self) -> None:
        """Register default command handlers"""
        
        @self.command("start")
        async def cmd_start(message: TelegramMessage):
            user_name = message.from_user.first_name if message.from_user else "there"
            bot_name = self.bot_info.first_name if self.bot_info else "Agent"
            
            welcome = f"""
🤖 <b>Welcome to {bot_name}!</b>

Hello {user_name}! I'm an autonomous AI agent ready to help you.

<b>What I can do:</b>
• 🧠 Think and reason about complex tasks
• 💾 Remember our conversations
• 🔧 Execute system commands
• 📚 Research and learn new things
• 🔄 Work autonomously

<b>Quick Commands:</b>
/help - Show all commands
/status - Check my status
/memory - View memory info

Just send me any message to get started!
            """
            
            keyboard = self.build_inline_keyboard([
                [
                    {"text": "📋 Help", "callback_data": "help"},
                    {"text": "📊 Status", "callback_data": "status"}
                ],
                [
                    {"text": "🧠 Memory", "callback_data": "memory"},
                    {"text": "⚙️ Config", "callback_data": "config"}
                ]
            ])
            
            await self.send_message(
                message.chat.id,
                welcome.strip(),
                reply_markup=keyboard
            )
        
        @self.command("help")
        async def cmd_help(message: TelegramMessage):
            help_text = """
📚 <b>Available Commands</b>

<b>General:</b>
/start - Start the bot
/help - Show this help
/status - System status
/about - About the agent

<b>Memory:</b>
/memory - Memory statistics
/search [query] - Search memory
/forget [topic] - Remove memory

<b>Learning:</b>
/learn [topic] - Learn about topic
/research [topic] - Research online
/teach [info] - Teach me something

<b>Tools:</b>
/tools - List available tools
/exec [command] - Execute tool

<b>Configuration:</b>
/config - View configuration
/set [key] [value] - Change setting

<b>Admin (Owner only):</b>
/restart - Restart agent
/reload - Reload configuration
/logs - View recent logs

Just send any message to chat normally!
            """
            await self.send_message(message.chat.id, help_text.strip())
        
        @self.command("status")
        async def cmd_status(message: TelegramMessage):
            uptime = "Unknown"
            if self._stats["started_at"]:
                delta = datetime.now() - self._stats["started_at"]
                hours, remainder = divmod(int(delta.total_seconds()), 3600)
                minutes, seconds = divmod(remainder, 60)
                uptime = f"{hours}h {minutes}m {seconds}s"
            
            status = f"""
📊 <b>System Status</b>

🤖 <b>Bot:</b> @{self.bot_info.username if self.bot_info else 'Unknown'}
📍 <b>State:</b> {self.state.value}
⏱️ <b>Uptime:</b> {uptime}

📈 <b>Statistics:</b>
• Messages received: {self._stats['messages_received']}
• Messages sent: {self._stats['messages_sent']}
• Commands processed: {self._stats['commands_processed']}
• Errors: {self._stats['errors']}

💾 <b>Memory:</b> {'Connected' if self.memory_manager else 'Not configured'}
🧠 <b>Agent:</b> {'Active' if self.agent_loop else 'Not configured'}
            """
            await self.send_message(message.chat.id, status.strip())
        
        @self.command("memory")
        async def cmd_memory(message: TelegramMessage):
            if not self.memory_manager:
                await self.send_message(
                    message.chat.id,
                    "⚠️ Memory system not configured."
                )
                return
            
            stats = await self.memory_manager.get_statistics()
            
            memory_info = f"""
💾 <b>Memory Statistics</b>

📊 <b>Total Memories:</b> {stats.get('total', 0)}

<b>By Type:</b>
• 📍 Permanent: {stats.get('permanent', 0)}
• 📝 Facts: {stats.get('facts', 0)}
• 🔧 Skills: {stats.get('skills', 0)}
• ❌ Failures: {stats.get('failures', 0)}
• ⭐ Preferences: {stats.get('preferences', 0)}
• 📚 Research: {stats.get('research', 0)}

💽 <b>Database Size:</b> {stats.get('size', 'Unknown')}
🕐 <b>Last Updated:</b> {stats.get('last_updated', 'Never')}
            """
            await self.send_message(message.chat.id, memory_info.strip())
        
        @self.command("about")
        async def cmd_about(message: TelegramMessage):
            about = """
🤖 <b>About Axiom Agent</b>

<b>Version:</b> 3.0.0
<b>Type:</b> Autonomous AI Agent

<b>Capabilities:</b>
• 🧠 Advanced reasoning engine
• 💾 Long-term memory system
• 🔧 250+ integrated tools
• 🌐 Internet access for research
• 📱 Telegram integration
• 🔄 Autonomous operation

<b>Philosophy:</b>
• Memory is HINT, not ANSWER
• Reality ALWAYS wins
• NEVER guess - always verify
• Learn from every interaction

<i>Built with ❤️ for intelligent automation</i>
            """
            await self.send_message(message.chat.id, about.strip())
        
        # Callback handlers
        @self.callback("help")
        async def callback_help(query: CallbackQuery):
            await self.answer_callback_query(query.id)
            # Trigger help command
            if query.message:
                query.message.text = "/help"
                await cmd_help(query.message)
        
        @self.callback("status")
        async def callback_status(query: CallbackQuery):
            await self.answer_callback_query(query.id)
            if query.message:
                query.message.text = "/status"
                await cmd_status(query.message)
        
        @self.callback("memory")
        async def callback_memory(query: CallbackQuery):
            await self.answer_callback_query(query.id)
            if query.message:
                query.message.text = "/memory"
                await cmd_memory(query.message)
    
    async def _set_bot_commands(self) -> None:
        """Set bot command menu"""
        commands = [
            {"command": "start", "description": "Start the bot"},
            {"command": "help", "description": "Show help"},
            {"command": "status", "description": "System status"},
            {"command": "memory", "description": "Memory info"},
            {"command": "tools", "description": "List tools"},
            {"command": "learn", "description": "Learn about topic"},
            {"command": "research", "description": "Research topic"},
            {"command": "config", "description": "Configuration"},
            {"command": "about", "description": "About the agent"}
        ]
        
        await self._api_call("setMyCommands", {"commands": commands})
    
    # ═══════════════════════════════════════════════════════════════════════════
    # UTILITY METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _is_user_allowed(self, user: Optional[TelegramUser]) -> bool:
        """Check if user is allowed to use the bot"""
        if not user:
            return False
        
        # Owner is always allowed
        if user.id == self.config.owner_id:
            return True
        
        # Check allowed users list
        if self.config.allowed_users:
            return user.id in self.config.allowed_users
        
        # If no allowed list, allow all (for public bots)
        return True
    
    def _parse_message(self, data: Dict) -> TelegramMessage:
        """Parse message from API response"""
        chat_data = data["chat"]
        chat = TelegramChat(
            id=chat_data["id"],
            type=chat_data["type"],
            title=chat_data.get("title"),
            username=chat_data.get("username")
        )
        
        from_user = None
        if "from" in data:
            user_data = data["from"]
            from_user = TelegramUser(
                id=user_data["id"],
                first_name=user_data["first_name"],
                last_name=user_data.get("last_name"),
                username=user_data.get("username"),
                is_bot=user_data.get("is_bot", False),
                language_code=user_data.get("language_code")
            )
        
        return TelegramMessage(
            message_id=data["message_id"],
            chat=chat,
            date=datetime.fromtimestamp(data["date"]),
            text=data.get("text"),
            from_user=from_user,
            entities=data.get("entities", []),
            photo=data.get("photo"),
            document=data.get("document"),
            voice=data.get("voice"),
            caption=data.get("caption")
        )
    
    def _parse_callback(self, data: Dict) -> CallbackQuery:
        """Parse callback query from API response"""
        user_data = data["from"]
        from_user = TelegramUser(
            id=user_data["id"],
            first_name=user_data["first_name"],
            last_name=user_data.get("last_name"),
            username=user_data.get("username")
        )
        
        message = None
        chat = None
        if "message" in data:
            message = self._parse_message(data["message"])
            chat = message.chat
        
        return CallbackQuery(
            id=data["id"],
            from_user=from_user,
            chat=chat,
            message=message,
            data=data.get("data")
        )
    
    def get_stats(self) -> Dict[str, Any]:
        """Get bot statistics"""
        return {
            **self._stats,
            "state": self.state.value,
            "bot_username": self.bot_info.username if self.bot_info else None
        }


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

async def create_telegram_bot(
    token: str,
    owner_id: Optional[int] = None,
    agent_loop: Optional[Any] = None,
    memory_manager: Optional[Any] = None,
    output_manager: Optional[Any] = None,
    **kwargs
) -> TelegramBot:
    """Create and configure Telegram bot"""
    config = BotConfig(
        token=token,
        owner_id=owner_id,
        **kwargs
    )
    
    bot = TelegramBot(
        config=config,
        agent_loop=agent_loop,
        memory_manager=memory_manager,
        output_manager=output_manager
    )
    
    return bot