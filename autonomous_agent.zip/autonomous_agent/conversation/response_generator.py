"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                        RESPONSE GENERATOR                                     ║
║              Generate Natural, Context-Aware Responses                        ║
╚══════════════════════════════════════════════════════════════════════════════╝

The Response Generator creates:
- Natural language responses
- Context-aware answers
- Appropriate tone and style
- Formatted output
- Error-friendly messages
"""

import asyncio
import logging
from datetime import datetime
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass, field
from enum import Enum
import re
import random

logger = logging.getLogger(__name__)


class ResponseTone(Enum):
    """Tone of response"""
    CASUAL = "casual"
    BALANCED = "balanced"
    FORMAL = "formal"
    FRIENDLY = "friendly"
    PROFESSIONAL = "professional"
    EMPATHETIC = "empathetic"


class ResponseType(Enum):
    """Types of responses"""
    ANSWER = "answer"
    CONFIRMATION = "confirmation"
    CLARIFICATION = "clarification"
    ERROR = "error"
    GREETING = "greeting"
    FAREWELL = "farewell"
    ACKNOWLEDGMENT = "acknowledgment"
    PROGRESS = "progress"
    RESULT = "result"
    QUESTION = "question"
    TEACHING = "teaching"


class EmotionalState(Enum):
    """Emotional undertone"""
    NEUTRAL = "neutral"
    HAPPY = "happy"
    CONCERNED = "concerned"
    APOLOGETIC = "apologetic"
    ENTHUSIASTIC = "enthusiastic"
    THOUGHTFUL = "thoughtful"


@dataclass
class ResponseTemplate:
    """A response template"""
    id: str
    type: ResponseType
    template: str
    tone: ResponseTone = ResponseTone.BALANCED
    variables: List[str] = field(default_factory=list)
    conditions: Dict[str, Any] = field(default_factory=dict)


@dataclass
class GeneratedResponse:
    """A generated response"""
    content: str
    type: ResponseType
    tone: ResponseTone
    
    # Metadata
    template_used: Optional[str] = None
    variables_filled: Dict[str, str] = field(default_factory=dict)
    generation_time_ms: float = 0.0
    
    # Context
    context_used: bool = False
    memory_used: bool = False
    
    # Formatting
    has_formatting: bool = False
    raw_content: Optional[str] = None


@dataclass
class GeneratorConfig:
    """Configuration for response generator"""
    # Tone settings
    default_tone: ResponseTone = ResponseTone.BALANCED
    adapt_tone_to_user: bool = True
    
    # Personalization
    use_user_name: bool = True
    remember_preferences: bool = True
    
    # Content
    max_response_length: int = 2000
    include_reasoning: bool = False
    show_confidence: bool = False
    
    # Style
    use_emojis: bool = True
    use_markdown: bool = True
    bullet_points_for_lists: bool = True
    
    # Variety
    vary_responses: bool = True
    avoid_repetition: bool = True


class TemplateLibrary:
    """Library of response templates"""
    
    def __init__(self):
        self._templates: Dict[str, ResponseTemplate] = {}
        self._by_type: Dict[ResponseType, List[str]] = {}
        self._load_default_templates()
    
    def _load_default_templates(self) -> None:
        """Load default templates"""
        defaults = [
            # Greetings
            ResponseTemplate(
                id="greeting_casual",
                type=ResponseType.GREETING,
                template="Hey {user_name}! 👋 What can I do for you?",
                tone=ResponseTone.CASUAL,
                variables=["user_name"]
            ),
            ResponseTemplate(
                id="greeting_formal",
                type=ResponseType.GREETING,
                template="Hello {user_name}. How may I assist you today?",
                tone=ResponseTone.FORMAL,
                variables=["user_name"]
            ),
            ResponseTemplate(
                id="greeting_balanced",
                type=ResponseType.GREETING,
                template="Hello {user_name}! How can I help you today?",
                tone=ResponseTone.BALANCED,
                variables=["user_name"]
            ),
            ResponseTemplate(
                id="greeting_return",
                type=ResponseType.GREETING,
                template="Welcome back, {user_name}! It's been {time_away}. What would you like to do?",
                tone=ResponseTone.FRIENDLY,
                variables=["user_name", "time_away"]
            ),
            
            # Farewells
            ResponseTemplate(
                id="farewell_casual",
                type=ResponseType.FAREWELL,
                template="See you later! 👋",
                tone=ResponseTone.CASUAL
            ),
            ResponseTemplate(
                id="farewell_formal",
                type=ResponseType.FAREWELL,
                template="Goodbye. Feel free to return if you need assistance.",
                tone=ResponseTone.FORMAL
            ),
            ResponseTemplate(
                id="farewell_balanced",
                type=ResponseType.FAREWELL,
                template="Goodbye! Let me know if you need anything else.",
                tone=ResponseTone.BALANCED
            ),
            
            # Acknowledgments
            ResponseTemplate(
                id="ack_understood",
                type=ResponseType.ACKNOWLEDGMENT,
                template="Got it! {action}",
                tone=ResponseTone.CASUAL,
                variables=["action"]
            ),
            ResponseTemplate(
                id="ack_working",
                type=ResponseType.ACKNOWLEDGMENT,
                template="Working on it... {action}",
                tone=ResponseTone.BALANCED,
                variables=["action"]
            ),
            ResponseTemplate(
                id="ack_sure",
                type=ResponseType.ACKNOWLEDGMENT,
                template="Sure! I'll {action} right away.",
                tone=ResponseTone.FRIENDLY,
                variables=["action"]
            ),
            
            # Confirmations
            ResponseTemplate(
                id="confirm_success",
                type=ResponseType.CONFIRMATION,
                template="✅ Done! {result}",
                tone=ResponseTone.BALANCED,
                variables=["result"]
            ),
            ResponseTemplate(
                id="confirm_complete",
                type=ResponseType.CONFIRMATION,
                template="✅ {action} completed successfully.",
                tone=ResponseTone.BALANCED,
                variables=["action"]
            ),
            
            # Errors
            ResponseTemplate(
                id="error_generic",
                type=ResponseType.ERROR,
                template="❌ Sorry, something went wrong: {error}",
                tone=ResponseTone.APOLOGETIC,
                variables=["error"]
            ),
            ResponseTemplate(
                id="error_permission",
                type=ResponseType.ERROR,
                template="🚫 I don't have permission to {action}. {suggestion}",
                tone=ResponseTone.APOLOGETIC,
                variables=["action", "suggestion"]
            ),
            ResponseTemplate(
                id="error_not_found",
                type=ResponseType.ERROR,
                template="🔍 I couldn't find {item}. {suggestion}",
                tone=ResponseTone.APOLOGETIC,
                variables=["item", "suggestion"]
            ),
            
            # Clarifications
            ResponseTemplate(
                id="clarify_ambiguous",
                type=ResponseType.CLARIFICATION,
                template="I'm not sure what you mean by '{ambiguous}'. Did you mean:\n{options}",
                tone=ResponseTone.BALANCED,
                variables=["ambiguous", "options"]
            ),
            ResponseTemplate(
                id="clarify_missing",
                type=ResponseType.CLARIFICATION,
                template="I need more information. {question}",
                tone=ResponseTone.BALANCED,
                variables=["question"]
            ),
            
            # Questions
            ResponseTemplate(
                id="question_confirm",
                type=ResponseType.QUESTION,
                template="⚠️ {action}\n\nAre you sure you want to proceed?",
                tone=ResponseTone.BALANCED,
                variables=["action"]
            ),
            ResponseTemplate(
                id="question_preference",
                type=ResponseType.QUESTION,
                template="{question}\n\nOptions:\n{options}",
                tone=ResponseTone.BALANCED,
                variables=["question", "options"]
            ),
            
            # Progress
            ResponseTemplate(
                id="progress_starting",
                type=ResponseType.PROGRESS,
                template="🔄 Starting: {task}...",
                tone=ResponseTone.BALANCED,
                variables=["task"]
            ),
            ResponseTemplate(
                id="progress_update",
                type=ResponseType.PROGRESS,
                template="⏳ {progress}% - {status}",
                tone=ResponseTone.BALANCED,
                variables=["progress", "status"]
            ),
            
            # Results
            ResponseTemplate(
                id="result_found",
                type=ResponseType.RESULT,
                template="Found {count} results:\n{results}",
                tone=ResponseTone.BALANCED,
                variables=["count", "results"]
            ),
            ResponseTemplate(
                id="result_info",
                type=ResponseType.RESULT,
                template="📊 {title}\n\n{content}",
                tone=ResponseTone.BALANCED,
                variables=["title", "content"]
            ),
            
            # Teaching/Learning
            ResponseTemplate(
                id="teaching_learned",
                type=ResponseType.TEACHING,
                template="📚 Got it! I've learned that {fact}. Thanks for teaching me!",
                tone=ResponseTone.FRIENDLY,
                variables=["fact"]
            ),
            ResponseTemplate(
                id="teaching_updated",
                type=ResponseType.TEACHING,
                template="🔄 Updated! I now know that {fact} (previously: {old_value}).",
                tone=ResponseTone.BALANCED,
                variables=["fact", "old_value"]
            ),
        ]
        
        for template in defaults:
            self.add(template)
    
    def add(self, template: ResponseTemplate) -> None:
        """Add a template"""
        self._templates[template.id] = template
        
        if template.type not in self._by_type:
            self._by_type[template.type] = []
        self._by_type[template.type].append(template.id)
    
    def get(self, template_id: str) -> Optional[ResponseTemplate]:
        """Get template by ID"""
        return self._templates.get(template_id)
    
    def get_by_type(
        self,
        response_type: ResponseType,
        tone: Optional[ResponseTone] = None
    ) -> List[ResponseTemplate]:
        """Get templates by type"""
        ids = self._by_type.get(response_type, [])
        templates = [self._templates[id] for id in ids if id in self._templates]
        
        if tone:
            templates = [t for t in templates if t.tone == tone]
        
        return templates
    
    def find_best(
        self,
        response_type: ResponseType,
        tone: ResponseTone,
        variables: Dict[str, str]
    ) -> Optional[ResponseTemplate]:
        """Find best matching template"""
        templates = self.get_by_type(response_type, tone)
        
        if not templates:
            # Try without tone filter
            templates = self.get_by_type(response_type)
        
        if not templates:
            return None
        
        # Filter by required variables
        matching = []
        for template in templates:
            has_all_vars = True
            for var in template.variables:
                if var not in variables:
                    has_all_vars = False
                    break
            if has_all_vars:
                matching.append(template)
        
        if matching:
            return random.choice(matching)
        
        return templates[0] if templates else None


class ToneAdapter:
    """Adapt response tone"""
    
    # Tone modifiers
    CASUAL_WORDS = {
        "I will": "I'll",
        "I am": "I'm",
        "do not": "don't",
        "cannot": "can't",
        "will not": "won't",
        "Hello": "Hey",
        "Goodbye": "Bye",
        "Please": "",
        "certainly": "sure",
        "however": "but",
        "Additionally": "Also",
        "Therefore": "So",
        "Furthermore": "Plus"
    }
    
    FORMAL_WORDS = {
        "I'll": "I will",
        "I'm": "I am",
        "don't": "do not",
        "can't": "cannot",
        "won't": "will not",
        "Hey": "Hello",
        "Bye": "Goodbye",
        "sure": "certainly",
        "but": "however",
        "Also": "Additionally",
        "So": "Therefore",
        "Plus": "Furthermore"
    }
    
    FRIENDLY_ADDITIONS = [
        "😊", "!", "👍", "✨"
    ]
    
    def adapt(self, text: str, target_tone: ResponseTone) -> str:
        """Adapt text to target tone"""
        if target_tone == ResponseTone.CASUAL:
            for formal, casual in self.CASUAL_WORDS.items():
                text = text.replace(formal, casual)
            # Add casual touches
            if not any(e in text for e in ['!', '👋', '😊', '✅']):
                if text.endswith('.'):
                    text = text[:-1] + '!'
        
        elif target_tone == ResponseTone.FORMAL:
            for casual, formal in self.FORMAL_WORDS.items():
                text = text.replace(casual, formal)
            # Remove emojis
            text = re.sub(r'[\U0001F300-\U0001F9FF]', '', text)
            # Remove multiple exclamation marks
            text = re.sub(r'!+', '.', text)
        
        elif target_tone == ResponseTone.FRIENDLY:
            # Add friendly touches if not present
            if not any(e in text for e in self.FRIENDLY_ADDITIONS):
                if text.endswith('.'):
                    text = text[:-1] + '! 😊'
        
        elif target_tone == ResponseTone.EMPATHETIC:
            # Add empathetic phrases
            empathetic_starters = [
                "I understand. ",
                "I see. ",
                "That makes sense. "
            ]
            if not any(text.startswith(s) for s in empathetic_starters):
                text = random.choice(empathetic_starters) + text
        
        return text.strip()


class ResponseFormatter:
    """Format responses for output"""
    
    def __init__(self, config: GeneratorConfig):
        self.config = config
    
    def format_list(self, items: List[str], numbered: bool = False) -> str:
        """Format a list"""
        if not items:
            return ""
        
        if self.config.bullet_points_for_lists:
            if numbered:
                return "\n".join(f"{i+1}. {item}" for i, item in enumerate(items))
            else:
                return "\n".join(f"• {item}" for item in items)
        else:
            return "\n".join(items)
    
    def format_code(self, code: str, language: str = "") -> str:
        """Format code block"""
        if self.config.use_markdown:
            return f"```{language}\n{code}\n```"
        return code
    
    def format_bold(self, text: str) -> str:
        """Format bold text"""
        if self.config.use_markdown:
            return f"**{text}**"
        return text.upper()
    
    def format_italic(self, text: str) -> str:
        """Format italic text"""
        if self.config.use_markdown:
            return f"*{text}*"
        return f"_{text}_"
    
    def format_header(self, text: str, level: int = 1) -> str:
        """Format header"""
        if self.config.use_markdown:
            return f"{'#' * level} {text}"
        return f"\n{text}\n{'=' * len(text)}"
    
    def format_quote(self, text: str) -> str:
        """Format quote"""
        if self.config.use_markdown:
            lines = text.split('\n')
            return '\n'.join(f"> {line}" for line in lines)
        return f'"{text}"'
    
    def format_link(self, text: str, url: str) -> str:
        """Format link"""
        if self.config.use_markdown:
            return f"[{text}]({url})"
        return f"{text} ({url})"
    
    def format_table(self, headers: List[str], rows: List[List[str]]) -> str:
        """Format table"""
        if not headers or not rows:
            return ""
        
        if self.config.use_markdown:
            # Markdown table
            header_row = "| " + " | ".join(headers) + " |"
            separator = "| " + " | ".join(["---"] * len(headers)) + " |"
            data_rows = [
                "| " + " | ".join(row) + " |"
                for row in rows
            ]
            return "\n".join([header_row, separator] + data_rows)
        else:
            # Simple text table
            lines = ["\t".join(headers)]
            lines.append("-" * 40)
            for row in rows:
                lines.append("\t".join(row))
            return "\n".join(lines)


class ResponseGenerator:
    """
    Generate natural, context-aware responses
    
    Features:
    - Template-based generation
    - Tone adaptation
    - Context integration
    - Personalization
    - Variety and avoiding repetition
    """
    
    def __init__(
        self,
        config: Optional[GeneratorConfig] = None,
        brain_controller: Optional[Any] = None,
        memory_manager: Optional[Any] = None
    ):
        self.config = config or GeneratorConfig()
        self.brain_controller = brain_controller
        self.memory_manager = memory_manager
        
        # Components
        self._templates = TemplateLibrary()
        self._tone_adapter = ToneAdapter()
        self._formatter = ResponseFormatter(self.config)
        
        # History (for avoiding repetition)
        self._recent_responses: List[str] = []
        self._max_recent = 10
        
        # User tone preferences
        self._user_tones: Dict[str, ResponseTone] = {}
        
        # Statistics
        self._stats = {
            "responses_generated": 0,
            "templates_used": 0,
            "llm_generated": 0
        }
        
        logger.info("ResponseGenerator initialized")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MAIN GENERATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def generate(
        self,
        content: str,
        response_type: ResponseType = ResponseType.ANSWER,
        tone: Optional[ResponseTone] = None,
        variables: Optional[Dict[str, str]] = None,
        context: Optional[Dict[str, Any]] = None,
        user_id: Optional[str] = None
    ) -> GeneratedResponse:
        """
        Generate a response
        
        Args:
            content: Main content to include
            response_type: Type of response
            tone: Desired tone (or None for default/user preference)
            variables: Variables for templates
            context: Conversation context
            user_id: User ID for personalization
        
        Returns:
            GeneratedResponse
        """
        start_time = datetime.now()
        self._stats["responses_generated"] += 1
        
        # Determine tone
        effective_tone = tone or self._get_user_tone(user_id) or self.config.default_tone
        
        # Prepare variables
        vars_dict = variables or {}
        
        # Add user name if available
        if self.config.use_user_name and context:
            user_name = context.get("user_name")
            if user_name:
                vars_dict["user_name"] = user_name
            else:
                vars_dict["user_name"] = "there"
        
        # Try template-based generation
        response = await self._generate_from_template(
            content=content,
            response_type=response_type,
            tone=effective_tone,
            variables=vars_dict
        )
        
        if not response:
            # Fall back to direct content with formatting
            response = self._format_content(content, response_type, effective_tone)
        
        # Adapt tone
        response.content = self._tone_adapter.adapt(response.content, effective_tone)
        
        # Apply formatting
        if self.config.use_markdown:
            response.content = self._apply_markdown(response.content)
        
        # Check length
        if len(response.content) > self.config.max_response_length:
            response.content = self._truncate(response.content)
        
        # Avoid repetition
        if self.config.avoid_repetition:
            response.content = self._avoid_repetition(response.content)
        
        # Record
        self._recent_responses.append(response.content[:100])
        if len(self._recent_responses) > self._max_recent:
            self._recent_responses = self._recent_responses[-self._max_recent:]
        
        # Calculate generation time
        elapsed = (datetime.now() - start_time).total_seconds() * 1000
        response.generation_time_ms = elapsed
        
        return response
    
    async def _generate_from_template(
        self,
        content: str,
        response_type: ResponseType,
        tone: ResponseTone,
        variables: Dict[str, str]
    ) -> Optional[GeneratedResponse]:
        """Generate from template"""
        template = self._templates.find_best(response_type, tone, variables)
        
        if not template:
            return None
        
        # Fill template
        try:
            filled = template.template
            for var, value in variables.items():
                filled = filled.replace(f"{{{var}}}", str(value))
            
            # Check for unfilled variables
            if re.search(r'\{[a-z_]+\}', filled):
                # Template has unfilled variables, fall back
                return None
            
            self._stats["templates_used"] += 1
            
            return GeneratedResponse(
                content=filled,
                type=response_type,
                tone=tone,
                template_used=template.id,
                variables_filled=variables
            )
        
        except Exception as e:
            logger.error(f"Template filling error: {e}")
            return None
    
    def _format_content(
        self,
        content: str,
        response_type: ResponseType,
        tone: ResponseTone
    ) -> GeneratedResponse:
        """Format raw content into response"""
        formatted = content
        
        # Add type-specific formatting
        if response_type == ResponseType.ERROR:
            if not formatted.startswith("❌"):
                formatted = f"❌ {formatted}"
        
        elif response_type == ResponseType.CONFIRMATION:
            if not formatted.startswith("✅"):
                formatted = f"✅ {formatted}"
        
        elif response_type == ResponseType.PROGRESS:
            if not formatted.startswith(("🔄", "⏳")):
                formatted = f"🔄 {formatted}"
        
        elif response_type == ResponseType.QUESTION:
            if not formatted.endswith("?"):
                formatted = f"{formatted}?"
        
        return GeneratedResponse(
            content=formatted,
            type=response_type,
            tone=tone,
            raw_content=content
        )
    
    def _apply_markdown(self, text: str) -> str:
        """Apply markdown formatting"""
        # Already has markdown, return as-is
        if re.search(r'```|\*\*|__|##', text):
            return text
        
        # Detect and format code blocks
        text = re.sub(
            r'`([^`]+)`',
            r'`\1`',
            text
        )
        
        return text
    
    def _truncate(self, text: str) -> str:
        """Truncate long response"""
        max_len = self.config.max_response_length
        
        if len(text) <= max_len:
            return text
        
        # Try to truncate at sentence boundary
        truncated = text[:max_len]
        last_period = truncated.rfind('.')
        last_newline = truncated.rfind('\n')
        
        cut_point = max(last_period, last_newline)
        if cut_point > max_len * 0.7:
            truncated = truncated[:cut_point + 1]
        
        return truncated + "\n\n*[Response truncated]*"
    
    def _avoid_repetition(self, text: str) -> str:
        """Avoid repeating recent responses"""
        if not self._recent_responses:
            return text
        
        # Check if too similar to recent
        text_start = text[:100].lower()
        
        for recent in self._recent_responses:
            if text_start == recent.lower():
                # Add variety
                starters = [
                    "Additionally, ",
                    "Also, ",
                    "Furthermore, ",
                    "To add to that, "
                ]
                return random.choice(starters) + text
        
        return text
    
    # ═══════════════════════════════════════════════════════════════════════════
    # SPECIALIZED GENERATORS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def generate_greeting(
        self,
        user_name: Optional[str] = None,
        is_return: bool = False,
        time_away: Optional[str] = None,
        user_id: Optional[str] = None
    ) -> GeneratedResponse:
        """Generate greeting response"""
        variables = {"user_name": user_name or "there"}
        
        if is_return and time_away:
            variables["time_away"] = time_away
            return await self.generate(
                content="",
                response_type=ResponseType.GREETING,
                variables=variables,
                user_id=user_id
            )
        
        return await self.generate(
            content="",
            response_type=ResponseType.GREETING,
            variables=variables,
            user_id=user_id
        )
    
    async def generate_farewell(
        self,
        user_id: Optional[str] = None
    ) -> GeneratedResponse:
        """Generate farewell response"""
        return await self.generate(
            content="",
            response_type=ResponseType.FAREWELL,
            user_id=user_id
        )
    
    async def generate_error(
        self,
        error: str,
        suggestion: Optional[str] = None,
        user_id: Optional[str] = None
    ) -> GeneratedResponse:
        """Generate error response"""
        variables = {"error": error}
        if suggestion:
            variables["suggestion"] = suggestion
        
        return await self.generate(
            content=error,
            response_type=ResponseType.ERROR,
            variables=variables,
            tone=ResponseTone.EMPATHETIC,
            user_id=user_id
        )
    
    async def generate_confirmation(
        self,
        action: str,
        result: Optional[str] = None,
        user_id: Optional[str] = None
    ) -> GeneratedResponse:
        """Generate confirmation response"""
        variables = {"action": action}
        if result:
            variables["result"] = result
        
        return await self.generate(
            content=result or action,
            response_type=ResponseType.CONFIRMATION,
            variables=variables,
            user_id=user_id
        )
    
    async def generate_clarification(
        self,
        question: str,
        options: Optional[List[str]] = None,
        user_id: Optional[str] = None
    ) -> GeneratedResponse:
        """Generate clarification request"""
        variables = {"question": question}
        
        if options:
            formatted_options = self._formatter.format_list(options, numbered=True)
            variables["options"] = formatted_options
        
        return await self.generate(
            content=question,
            response_type=ResponseType.CLARIFICATION,
            variables=variables,
            user_id=user_id
        )
    
    async def generate_confirmation_request(
        self,
        action: str,
        details: Optional[str] = None,
        is_destructive: bool = False,
        user_id: Optional[str] = None
    ) -> GeneratedResponse:
        """Generate confirmation request"""
        full_action = action
        if details:
            full_action = f"{action}\n{details}"
        
        if is_destructive:
            full_action = f"⚠️ DESTRUCTIVE ACTION: {full_action}"
        
        return await self.generate(
            content=full_action,
            response_type=ResponseType.QUESTION,
            variables={"action": full_action},
            user_id=user_id
        )
    
    async def generate_result(
        self,
        title: str,
        content: str,
        user_id: Optional[str] = None
    ) -> GeneratedResponse:
        """Generate result response"""
        return await self.generate(
            content=content,
            response_type=ResponseType.RESULT,
            variables={"title": title, "content": content},
            user_id=user_id
        )
    
    async def generate_list_result(
        self,
        items: List[str],
        title: Optional[str] = None,
        numbered: bool = False,
        user_id: Optional[str] = None
    ) -> GeneratedResponse:
        """Generate list result"""
        formatted_list = self._formatter.format_list(items, numbered)
        
        content = formatted_list
        if title:
            content = f"{title}\n\n{formatted_list}"
        
        return await self.generate(
            content=content,
            response_type=ResponseType.RESULT,
            variables={
                "count": str(len(items)),
                "results": formatted_list
            },
            user_id=user_id
        )
    
    async def generate_progress(
        self,
        task: str,
        progress: Optional[int] = None,
        status: Optional[str] = None,
        user_id: Optional[str] = None
    ) -> GeneratedResponse:
        """Generate progress update"""
        variables = {"task": task}
        
        if progress is not None:
            variables["progress"] = str(progress)
        if status:
            variables["status"] = status
        
        content = task
        if progress is not None:
            content = f"{progress}% - {task}"
        
        return await self.generate(
            content=content,
            response_type=ResponseType.PROGRESS,
            variables=variables,
            user_id=user_id
        )
    
    async def generate_teaching_ack(
        self,
        fact: str,
        old_value: Optional[str] = None,
        user_id: Optional[str] = None
    ) -> GeneratedResponse:
        """Generate teaching acknowledgment"""
        variables = {"fact": fact}
        
        if old_value:
            variables["old_value"] = old_value
        
        return await self.generate(
            content=fact,
            response_type=ResponseType.TEACHING,
            variables=variables,
            user_id=user_id
        )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # LLM-BASED GENERATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def generate_with_llm(
        self,
        prompt: str,
        context: Optional[Dict[str, Any]] = None,
        tone: Optional[ResponseTone] = None,
        user_id: Optional[str] = None
    ) -> GeneratedResponse:
        """Generate response using LLM"""
        if not self.brain_controller:
            return GeneratedResponse(
                content=prompt,
                type=ResponseType.ANSWER,
                tone=tone or self.config.default_tone
            )
        
        effective_tone = tone or self._get_user_tone(user_id) or self.config.default_tone
        
        # Build system prompt for tone
        tone_instruction = self._get_tone_instruction(effective_tone)
        
        try:
            result = await self.brain_controller.think(
                prompt,
                context={
                    **(context or {}),
                    "tone_instruction": tone_instruction,
                    "mode": "response_generation"
                }
            )
            
            if result.get("success"):
                self._stats["llm_generated"] += 1
                
                response_text = result.get("response", "")
                response_text = self._tone_adapter.adapt(response_text, effective_tone)
                
                return GeneratedResponse(
                    content=response_text,
                    type=ResponseType.ANSWER,
                    tone=effective_tone,
                    context_used=True
                )
        
        except Exception as e:
            logger.error(f"LLM generation error: {e}")
        
        return GeneratedResponse(
            content=prompt,
            type=ResponseType.ANSWER,
            tone=effective_tone
        )
    
    def _get_tone_instruction(self, tone: ResponseTone) -> str:
        """Get instruction for tone"""
        instructions = {
            ResponseTone.CASUAL: "Respond in a casual, friendly manner. Use contractions and informal language.",
            ResponseTone.FORMAL: "Respond in a formal, professional manner. Avoid contractions and slang.",
            ResponseTone.BALANCED: "Respond in a balanced, clear manner. Be helpful and approachable.",
            ResponseTone.FRIENDLY: "Respond in a warm, friendly manner. Be encouraging and positive.",
            ResponseTone.PROFESSIONAL: "Respond in a professional, expert manner. Be precise and authoritative.",
            ResponseTone.EMPATHETIC: "Respond with empathy and understanding. Acknowledge feelings and concerns."
        }
        return instructions.get(tone, instructions[ResponseTone.BALANCED])
    
    # ═══════════════════════════════════════════════════════════════════════════
    # USER PREFERENCES
    # ═══════════════════════════════════════════════════════════════════════════
    
    def set_user_tone(self, user_id: str, tone: ResponseTone) -> None:
        """Set preferred tone for user"""
        self._user_tones[user_id] = tone
    
    def _get_user_tone(self, user_id: Optional[str]) -> Optional[ResponseTone]:
        """Get user's preferred tone"""
        if not user_id or not self.config.adapt_tone_to_user:
            return None
        return self._user_tones.get(user_id)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # TEMPLATE MANAGEMENT
    # ═══════════════════════════════════════════════════════════════════════════
    
    def add_template(self, template: ResponseTemplate) -> None:
        """Add a custom template"""
        self._templates.add(template)
    
    def get_template(self, template_id: str) -> Optional[ResponseTemplate]:
        """Get a template by ID"""
        return self._templates.get(template_id)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # UTILITIES
    # ═══════════════════════════════════════════════════════════════════════════
    
    @property
    def formatter(self) -> ResponseFormatter:
        """Get the formatter"""
        return self._formatter
    
    def get_stats(self) -> Dict[str, Any]:
        """Get generator statistics"""
        return {
            **self._stats,
            "recent_responses": len(self._recent_responses),
            "user_tones_set": len(self._user_tones)
        }


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

async def create_response_generator(
    brain_controller: Optional[Any] = None,
    memory_manager: Optional[Any] = None,
    default_tone: ResponseTone = ResponseTone.BALANCED,
    **kwargs
) -> ResponseGenerator:
    """Create configured response generator"""
    config = GeneratorConfig(
        default_tone=default_tone,
        **kwargs
    )
    
    generator = ResponseGenerator(
        config=config,
        brain_controller=brain_controller,
        memory_manager=memory_manager
    )
    
    return generator