"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                           WEB SCRAPER                                         ║
║              Extract and Parse Content from Web Pages                         ║
╚══════════════════════════════════════════════════════════════════════════════╝

The Web Scraper provides:
- HTML parsing and content extraction
- Text cleaning and normalization
- Link extraction
- Structured data extraction
- Article/content detection
"""

import asyncio
import logging
import re
from datetime import datetime
from typing import Optional, Dict, Any, List, Set, Tuple
from dataclasses import dataclass, field
from enum import Enum
from urllib.parse import urljoin, urlparse
from html.parser import HTMLParser
from html import unescape

logger = logging.getLogger(__name__)


class ContentFormat(Enum):
    """Output content formats"""
    TEXT = "text"
    MARKDOWN = "markdown"
    HTML = "html"
    STRUCTURED = "structured"


@dataclass
class ExtractedLink:
    """Extracted link from page"""
    url: str
    text: str
    title: Optional[str] = None
    is_external: bool = False
    rel: Optional[str] = None


@dataclass
class ExtractedImage:
    """Extracted image from page"""
    src: str
    alt: Optional[str] = None
    title: Optional[str] = None
    width: Optional[int] = None
    height: Optional[int] = None


@dataclass
class ExtractedMetadata:
    """Page metadata"""
    title: Optional[str] = None
    description: Optional[str] = None
    keywords: List[str] = field(default_factory=list)
    author: Optional[str] = None
    published_date: Optional[str] = None
    modified_date: Optional[str] = None
    language: Optional[str] = None
    canonical_url: Optional[str] = None
    og_title: Optional[str] = None
    og_description: Optional[str] = None
    og_image: Optional[str] = None
    twitter_title: Optional[str] = None
    twitter_description: Optional[str] = None


@dataclass
class ScrapedContent:
    """Result of web scraping"""
    url: str
    title: Optional[str] = None
    text: str = ""
    html: str = ""
    markdown: str = ""
    metadata: ExtractedMetadata = field(default_factory=ExtractedMetadata)
    links: List[ExtractedLink] = field(default_factory=list)
    images: List[ExtractedImage] = field(default_factory=list)
    headings: List[Tuple[int, str]] = field(default_factory=list)
    word_count: int = 0
    reading_time_minutes: int = 0
    scraped_at: datetime = field(default_factory=datetime.now)
    error: Optional[str] = None
    
    @property
    def has_content(self) -> bool:
        return bool(self.text.strip())


@dataclass
class ScraperConfig:
    """Web scraper configuration"""
    # Content extraction
    extract_links: bool = True
    extract_images: bool = True
    extract_metadata: bool = True
    extract_headings: bool = True
    
    # Content cleaning
    remove_scripts: bool = True
    remove_styles: bool = True
    remove_comments: bool = True
    remove_forms: bool = True
    remove_navigation: bool = True
    remove_footer: bool = True
    remove_ads: bool = True
    
    # Text processing
    normalize_whitespace: bool = True
    decode_entities: bool = True
    max_text_length: int = 100000
    
    # Link filtering
    include_external_links: bool = True
    include_internal_links: bool = True
    max_links: int = 100
    
    # Output
    default_format: ContentFormat = ContentFormat.TEXT
    include_link_text: bool = True


class HTMLTextExtractor(HTMLParser):
    """Extract text from HTML"""
    
    # Tags to skip content
    SKIP_TAGS = {
        'script', 'style', 'noscript', 'iframe', 'svg', 'canvas',
        'template', 'head', 'meta', 'link'
    }
    
    # Block-level tags (add newlines)
    BLOCK_TAGS = {
        'p', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
        'ul', 'ol', 'li', 'table', 'tr', 'td', 'th',
        'blockquote', 'pre', 'article', 'section', 'header',
        'footer', 'nav', 'aside', 'main', 'figure', 'figcaption',
        'address', 'form', 'fieldset', 'br', 'hr'
    }
    
    # Navigation/footer tags to potentially skip
    NAV_TAGS = {'nav', 'footer', 'header', 'aside'}
    
    def __init__(
        self,
        remove_nav: bool = False,
        remove_footer: bool = False
    ):
        super().__init__()
        self.remove_nav = remove_nav
        self.remove_footer = remove_footer
        
        self.text_parts: List[str] = []
        self._skip_depth = 0
        self._nav_depth = 0
        self._current_tag = None
        
        # Extraction results
        self.links: List[ExtractedLink] = []
        self.images: List[ExtractedImage] = []
        self.headings: List[Tuple[int, str]] = []
        self.metadata = ExtractedMetadata()
        
        # State
        self._in_heading = False
        self._heading_level = 0
        self._heading_text = []
        self._link_href = None
        self._link_text = []
    
    def handle_starttag(self, tag: str, attrs: List[Tuple[str, Optional[str]]]) -> None:
        tag = tag.lower()
        self._current_tag = tag
        attrs_dict = dict(attrs)
        
        # Skip content in certain tags
        if tag in self.SKIP_TAGS:
            self._skip_depth += 1
            return
        
        # Handle navigation/footer removal
        if self.remove_nav and tag in self.NAV_TAGS:
            self._nav_depth += 1
            return
        
        # Add newlines for block elements
        if tag in self.BLOCK_TAGS and self.text_parts:
            self.text_parts.append('\n')
        
        # Handle headings
        if tag in ('h1', 'h2', 'h3', 'h4', 'h5', 'h6'):
            self._in_heading = True
            self._heading_level = int(tag[1])
            self._heading_text = []
        
        # Handle links
        if tag == 'a':
            self._link_href = attrs_dict.get('href')
            self._link_text = []
        
        # Handle images
        if tag == 'img':
            src = attrs_dict.get('src', '')
            if src:
                self.images.append(ExtractedImage(
                    src=src,
                    alt=attrs_dict.get('alt'),
                    title=attrs_dict.get('title')
                ))
        
        # Handle metadata
        if tag == 'title':
            self._skip_depth += 1  # We'll get title separately
        
        if tag == 'meta':
            self._handle_meta(attrs_dict)
    
    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        
        if tag in self.SKIP_TAGS:
            self._skip_depth = max(0, self._skip_depth - 1)
            return
        
        if self.remove_nav and tag in self.NAV_TAGS:
            self._nav_depth = max(0, self._nav_depth - 1)
            return
        
        # End heading
        if tag in ('h1', 'h2', 'h3', 'h4', 'h5', 'h6') and self._in_heading:
            heading_text = ''.join(self._heading_text).strip()
            if heading_text:
                self.headings.append((self._heading_level, heading_text))
            self._in_heading = False
            self._heading_text = []
        
        # End link
        if tag == 'a' and self._link_href:
            link_text = ''.join(self._link_text).strip()
            self.links.append(ExtractedLink(
                url=self._link_href,
                text=link_text
            ))
            self._link_href = None
            self._link_text = []
        
        if tag == 'title':
            self._skip_depth = max(0, self._skip_depth - 1)
        
        # Add newline after block elements
        if tag in self.BLOCK_TAGS:
            self.text_parts.append('\n')
    
    def handle_data(self, data: str) -> None:
        if self._skip_depth > 0:
            return
        
        if self._nav_depth > 0:
            return
        
        text = data.strip()
        if not text:
            return
        
        self.text_parts.append(text)
        
        # Collect heading text
        if self._in_heading:
            self._heading_text.append(text)
        
        # Collect link text
        if self._link_href is not None:
            self._link_text.append(text)
    
    def _handle_meta(self, attrs: Dict[str, Optional[str]]) -> None:
        """Handle meta tag for metadata extraction"""
        name = attrs.get('name', '').lower()
        property_ = attrs.get('property', '').lower()
        content = attrs.get('content', '')
        
        if not content:
            return
        
        # Standard meta tags
        if name == 'description':
            self.metadata.description = content
        elif name == 'keywords':
            self.metadata.keywords = [k.strip() for k in content.split(',')]
        elif name == 'author':
            self.metadata.author = content
        elif name == 'language':
            self.metadata.language = content
        
        # Open Graph
        elif property_ == 'og:title':
            self.metadata.og_title = content
        elif property_ == 'og:description':
            self.metadata.og_description = content
        elif property_ == 'og:image':
            self.metadata.og_image = content
        
        # Twitter
        elif name == 'twitter:title':
            self.metadata.twitter_title = content
        elif name == 'twitter:description':
            self.metadata.twitter_description = content
    
    def get_text(self) -> str:
        """Get extracted text"""
        text = ' '.join(self.text_parts)
        # Normalize whitespace
        text = re.sub(r'\s+', ' ', text)
        text = re.sub(r'\n\s*\n', '\n\n', text)
        return text.strip()


class WebScraper:
    """
    Web content scraper and extractor
    
    Features:
    - HTML content extraction
    - Text cleaning
    - Link extraction
    - Image extraction
    - Metadata extraction
    - Markdown conversion
    """
    
    def __init__(
        self,
        config: Optional[ScraperConfig] = None,
        internet_manager: Optional[Any] = None
    ):
        self.config = config or ScraperConfig()
        self.internet_manager = internet_manager
        
        # Statistics
        self._stats = {
            "pages_scraped": 0,
            "successful_scrapes": 0,
            "failed_scrapes": 0,
            "total_text_extracted": 0
        }
        
        logger.info("WebScraper initialized")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MAIN SCRAPING API
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def scrape(
        self,
        url: str,
        format_: ContentFormat = ContentFormat.TEXT
    ) -> ScrapedContent:
        """
        Scrape a web page
        
        Args:
            url: URL to scrape
            format_: Output format (text, markdown, html, structured)
        
        Returns:
            ScrapedContent with extracted data
        """
        self._stats["pages_scraped"] += 1
        
        result = ScrapedContent(url=url)
        
        try:
            # Fetch page
            html = await self._fetch_page(url)
            
            if not html:
                result.error = "Failed to fetch page"
                self._stats["failed_scrapes"] += 1
                return result
            
            result.html = html
            
            # Extract content
            result = await self._extract_content(url, html, result)
            
            # Convert to requested format
            if format_ == ContentFormat.MARKDOWN:
                result.markdown = self._to_markdown(result)
            
            # Calculate stats
            result.word_count = len(result.text.split())
            result.reading_time_minutes = max(1, result.word_count // 200)
            
            self._stats["successful_scrapes"] += 1
            self._stats["total_text_extracted"] += len(result.text)
            
        except Exception as e:
            logger.error(f"Scrape error for {url}: {e}")
            result.error = str(e)
            self._stats["failed_scrapes"] += 1
        
        return result
    
    async def scrape_text(self, url: str) -> Optional[str]:
        """Scrape and return only text content"""
        result = await self.scrape(url, ContentFormat.TEXT)
        return result.text if result.has_content else None
    
    async def scrape_article(self, url: str) -> ScrapedContent:
        """Scrape article content (optimized for articles)"""
        # Use stricter content extraction for articles
        old_remove_nav = self.config.remove_navigation
        old_remove_footer = self.config.remove_footer
        
        self.config.remove_navigation = True
        self.config.remove_footer = True
        
        result = await self.scrape(url)
        
        self.config.remove_navigation = old_remove_nav
        self.config.remove_footer = old_remove_footer
        
        return result
    
    async def extract_links(self, url: str) -> List[ExtractedLink]:
        """Extract all links from page"""
        result = await self.scrape(url)
        return result.links
    
    async def extract_metadata(self, url: str) -> ExtractedMetadata:
        """Extract page metadata"""
        result = await self.scrape(url)
        return result.metadata
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CONTENT EXTRACTION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _fetch_page(self, url: str) -> Optional[str]:
        """Fetch page HTML"""
        if self.internet_manager:
            return await self.internet_manager.fetch_page(url)
        
        # Fallback if no internet manager
        import aiohttp
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=30) as response:
                    if response.status == 200:
                        return await response.text()
        except Exception as e:
            logger.error(f"Fetch error: {e}")
        
        return None
    
    async def _extract_content(
        self,
        url: str,
        html: str,
        result: ScrapedContent
    ) -> ScrapedContent:
        """Extract content from HTML"""
        # Pre-process HTML
        html = self._preprocess_html(html)
        
        # Parse HTML
        parser = HTMLTextExtractor(
            remove_nav=self.config.remove_navigation,
            remove_footer=self.config.remove_footer
        )
        
        try:
            parser.feed(html)
        except Exception as e:
            logger.warning(f"HTML parse error: {e}")
        
        # Get extracted text
        result.text = parser.get_text()
        
        # Limit text length
        if len(result.text) > self.config.max_text_length:
            result.text = result.text[:self.config.max_text_length]
        
        # Get extracted elements
        if self.config.extract_links:
            result.links = self._process_links(url, parser.links)
        
        if self.config.extract_images:
            result.images = self._process_images(url, parser.images)
        
        if self.config.extract_headings:
            result.headings = parser.headings
        
        if self.config.extract_metadata:
            result.metadata = parser.metadata
            # Extract title from HTML if not in meta
            if not result.metadata.title:
                result.metadata.title = self._extract_title(html)
            result.title = result.metadata.title
        
        return result
    
    def _preprocess_html(self, html: str) -> str:
        """Preprocess HTML before parsing"""
        # Remove script tags
        if self.config.remove_scripts:
            html = re.sub(
                r'<script[^>]*>.*?</script>',
                '',
                html,
                flags=re.DOTALL | re.IGNORECASE
            )
        
        # Remove style tags
        if self.config.remove_styles:
            html = re.sub(
                r'<style[^>]*>.*?</style>',
                '',
                html,
                flags=re.DOTALL | re.IGNORECASE
            )
        
        # Remove comments
        if self.config.remove_comments:
            html = re.sub(r'<!--.*?-->', '', html, flags=re.DOTALL)
        
        # Remove forms
        if self.config.remove_forms:
            html = re.sub(
                r'<form[^>]*>.*?</form>',
                '',
                html,
                flags=re.DOTALL | re.IGNORECASE
            )
        
        return html
    
    def _extract_title(self, html: str) -> Optional[str]:
        """Extract title from HTML"""
        match = re.search(
            r'<title[^>]*>([^<]+)</title>',
            html,
            re.IGNORECASE
        )
        if match:
            return unescape(match.group(1).strip())
        return None
    
    def _process_links(
        self,
        base_url: str,
        links: List[ExtractedLink]
    ) -> List[ExtractedLink]:
        """Process and filter links"""
        processed = []
        seen_urls: Set[str] = set()
        base_domain = urlparse(base_url).netloc.lower()
        
        for link in links:
            # Skip empty or javascript links
            if not link.url or link.url.startswith(('javascript:', '#', 'mailto:')):
                continue
            
            # Make absolute URL
            absolute_url = urljoin(base_url, link.url)
            
            # Skip duplicates
            if absolute_url in seen_urls:
                continue
            seen_urls.add(absolute_url)
            
            # Determine if external
            link_domain = urlparse(absolute_url).netloc.lower()
            link.is_external = link_domain != base_domain
            link.url = absolute_url
            
            # Filter based on config
            if link.is_external and not self.config.include_external_links:
                continue
            if not link.is_external and not self.config.include_internal_links:
                continue
            
            processed.append(link)
            
            if len(processed) >= self.config.max_links:
                break
        
        return processed
    
    def _process_images(
        self,
        base_url: str,
        images: List[ExtractedImage]
    ) -> List[ExtractedImage]:
        """Process images"""
        for image in images:
            # Make absolute URL
            image.src = urljoin(base_url, image.src)
        return images
    
    # ═══════════════════════════════════════════════════════════════════════════
    # FORMAT CONVERSION
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _to_markdown(self, result: ScrapedContent) -> str:
        """Convert content to Markdown"""
        lines = []
        
        # Title
        if result.title:
            lines.append(f"# {result.title}")
            lines.append("")
        
        # Main text
        lines.append(result.text)
        
        # Links section
        if result.links and self.config.include_link_text:
            lines.append("")
            lines.append("## Links")
            lines.append("")
            for link in result.links[:20]:
                lines.append(f"- [{link.text or link.url}]({link.url})")
        
        return "\n".join(lines)
    
    def text_to_markdown(self, text: str, title: Optional[str] = None) -> str:
        """Convert plain text to Markdown"""
        lines = []
        
        if title:
            lines.append(f"# {title}")
            lines.append("")
        
        # Split into paragraphs
        paragraphs = text.split('\n\n')
        for para in paragraphs:
            para = para.strip()
            if para:
                lines.append(para)
                lines.append("")
        
        return "\n".join(lines)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # TEXT CLEANING
    # ═══════════════════════════════════════════════════════════════════════════
    
    def clean_text(self, text: str) -> str:
        """Clean and normalize text"""
        # Decode HTML entities
        if self.config.decode_entities:
            text = unescape(text)
        
        # Normalize whitespace
        if self.config.normalize_whitespace:
            text = re.sub(r'[ \t]+', ' ', text)
            text = re.sub(r'\n{3,}', '\n\n', text)
        
        # Remove control characters
        text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', text)
        
        return text.strip()
    
    def extract_sentences(self, text: str) -> List[str]:
        """Extract sentences from text"""
        # Simple sentence splitting
        sentences = re.split(r'(?<=[.!?])\s+', text)
        return [s.strip() for s in sentences if s.strip()]
    
    def extract_paragraphs(self, text: str) -> List[str]:
        """Extract paragraphs from text"""
        paragraphs = text.split('\n\n')
        return [p.strip() for p in paragraphs if p.strip()]
    
    def summarize_text(self, text: str, max_sentences: int = 3) -> str:
        """Simple extractive summary"""
        sentences = self.extract_sentences(text)
        return ' '.join(sentences[:max_sentences])
    
    # ═══════════════════════════════════════════════════════════════════════════
    # UTILITIES
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_stats(self) -> Dict[str, Any]:
        """Get scraper statistics"""
        return {
            **self._stats,
            "config": {
                "extract_links": self.config.extract_links,
                "extract_images": self.config.extract_images,
                "max_links": self.config.max_links
            }
        }


# ═══════════════════════════════════════════════════════════════════════════════
# SPECIALIZED SCRAPERS
# ═══════════════════════════════════════════════════════════════════════════════

class ArticleScraper(WebScraper):
    """Scraper optimized for article extraction"""
    
    def __init__(self, **kwargs):
        config = ScraperConfig(
            remove_navigation=True,
            remove_footer=True,
            remove_ads=True,
            extract_links=False,
            extract_images=True,
            max_text_length=50000
        )
        super().__init__(config=config, **kwargs)
    
    async def scrape(self, url: str, **kwargs) -> ScrapedContent:
        result = await super().scrape(url, **kwargs)
        
        # Try to find main article content
        if result.has_content:
            result.text = self._extract_article_content(result.text)
        
        return result
    
    def _extract_article_content(self, text: str) -> str:
        """Try to extract main article content"""
        paragraphs = self.extract_paragraphs(text)
        
        # Filter short paragraphs (likely navigation, etc.)
        content_paragraphs = [
            p for p in paragraphs
            if len(p) > 100 or p.endswith(('.', '!', '?'))
        ]
        
        return '\n\n'.join(content_paragraphs)


class DocumentationScraper(WebScraper):
    """Scraper optimized for technical documentation"""
    
    def __init__(self, **kwargs):
        config = ScraperConfig(
            remove_navigation=True,
            remove_footer=True,
            extract_links=True,
            extract_images=False,
            include_external_links=False,
            max_links=50
        )
        super().__init__(config=config, **kwargs)


# ═══════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

async def create_web_scraper(
    internet_manager: Optional[Any] = None,
    scraper_type: str = "default",
    **kwargs
) -> WebScraper:
    """Create configured web scraper"""
    if scraper_type == "article":
        return ArticleScraper(internet_manager=internet_manager, **kwargs)
    elif scraper_type == "documentation":
        return DocumentationScraper(internet_manager=internet_manager, **kwargs)
    else:
        config = ScraperConfig(**kwargs)
        return WebScraper(config=config, internet_manager=internet_manager)