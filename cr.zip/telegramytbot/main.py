import os
import math
from fastapi import FastAPI, Request, Response, HTTPException
from fastapi.responses import StreamingResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pyrogram import Client
from dotenv import load_dotenv
from db import init_db, add_anime, search_anime, get_meta

load_dotenv()

# --- CONFIG ---
API_ID = int(os.getenv("API_ID"))
API_HASH = os.getenv("API_HASH")
BOT_TOKEN = os.getenv("BOT_TOKEN")
CHANNEL_ID = int(os.getenv("CHANNEL_ID")) # e.g., -100123456789
ADMIN_KEY = os.getenv("ADMIN_KEY")

app = FastAPI()

# Allow Cloudflare Pages
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # In strict prod, replace * with https://site.yourdomain.com
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pyrogram Client
client = Client("bot_session", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)

@app.on_event("startup")
async def startup():
    init_db()
    await client.start()
    print("✅ Bot Started & DB Initialized")

@app.on_event("shutdown")
async def shutdown():
    await client.stop()

# --- ROUTES ---

@app.get("/")
def home():
    return {"status": "Online", "mode": "Restricted VPS"}

@app.get("/scan")
async def scan_channel(key: str):
    """Index channel videos. Pass ?key=YOUR_SECRET"""
    if key != ADMIN_KEY:
        raise HTTPException(status_code=403, detail="Unauthorized")
    
    count = 0
    async for msg in client.get_chat_history(CHANNEL_ID):
        if msg.video:
            title = msg.caption or msg.video.file_name or f"Video {msg.id}"
            add_anime(msg.id, title, msg.video.file_size, msg.video.duration or 0)
            count += 1
    return {"status": "scanned", "added": count}

@app.get("/search")
def search(q: str):
    return {"results": search_anime(q)}

# --- STREAMING CORE ---
@app.get("/stream/{message_id}")
async def stream(message_id: int, request: Request):
    meta = get_meta(message_id)
    if not meta:
        raise HTTPException(status_code=404, detail="Video not found in DB")
    
    file_name, file_size = meta
    
    # Range Header parsing (Crucial for video seeking)
    range_header = request.headers.get("Range")
    start = 0
    end = file_size - 1
    
    if range_header:
        bytes_prefix = "bytes="
        if range_header.startswith(bytes_prefix):
            bytes_range = range_header[len(bytes_prefix):]
            parts = bytes_range.split("-")
            if parts[0]: start = int(parts[0])
            if len(parts) > 1 and parts[1]: end = int(parts[1])

    chunk_size = 1024 * 1024 # 1MB chunks
    content_length = end - start + 1

    # Generator for Telegram Chunks
    async def iterfile():
        current = start
        while current <= end:
            limit = min(chunk_size, end - current + 1)
            async for chunk in client.stream_media(
                message_id=message_id,
                chat_id=CHANNEL_ID,
                offset=current,
                limit=limit
            ):
                yield chunk
                current += len(chunk)
                if current > end: break

    headers = {
        "Content-Range": f"bytes {start}-{end}/{file_size}",
        "Accept-Ranges": "bytes",
        "Content-Length": str(content_length),
        "Content-Type": "video/mp4",
        "Content-Disposition": f'inline; filename="{file_name}"',
    }
    
    return StreamingResponse(iterfile(), status_code=206, headers=headers)

if __name__ == "__main__":
    # We use 0.0.0.0 to bind to all interfaces
    # Port 8080 is Cloudflare compatible
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)