import sqlite3

DB_NAME = "anime.db"

def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS anime (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            message_id INTEGER UNIQUE,
            title TEXT,
            file_size INTEGER,
            duration INTEGER
        )
    ''')
    conn.commit()
    conn.close()

def add_anime(msg_id, title, size, duration):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    try:
        c.execute("INSERT INTO anime (message_id, title, file_size, duration) VALUES (?, ?, ?, ?)",
                  (msg_id, title, size, duration))
        conn.commit()
    except sqlite3.IntegrityError:
        pass
    conn.close()

def search_anime(query):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT message_id, title, file_size, duration FROM anime WHERE title LIKE ? LIMIT 50", (f'%{query}%',))
    rows = c.fetchall()
    conn.close()
    return [{"id": r[0], "title": r[1], "size": r[2], "duration": r[3]} for r in rows]

def get_meta(msg_id):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT title, file_size FROM anime WHERE message_id=?", (msg_id,))
    row = c.fetchone()
    conn.close()
    return row