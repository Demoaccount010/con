// Point to your VPS via Cloudflare
// Since we used Port 8080 on VPS, we must add it here unless using CF Origin Rules
const API_BASE = "https://api.example.com:8080"; 

async function doSearch() {
    const q = document.getElementById("query").value;
    const res = await fetch(`${API_BASE}/search?q=${encodeURIComponent(q)}`);
    const data = await res.json();
    
    const grid = document.getElementById("results");
    grid.innerHTML = "";
    
    data.results.forEach(vid => {
        const div = document.createElement("div");
        div.className = "card";
        div.innerHTML = `
            <h3>${vid.title}</h3>
            <p>⏱ ${(vid.duration/60).toFixed(1)} min | 💾 ${(vid.size/1024/1024).toFixed(1)} MB</p>
        `;
        div.onclick = () => playVideo(vid.id, vid.title);
        grid.appendChild(div);
    });
}

let currentStreamUrl = "";

function playVideo(id, title) {
    const modal = document.getElementById("modal");
    const player = document.getElementById("player");
    
    currentStreamUrl = `${API_BASE}/stream/${id}`;
    
    document.getElementById("vidTitle").innerText = title;
    player.src = currentStreamUrl;
    modal.style.display = "flex";
}

function closeModal() {
    const player = document.getElementById("player");
    player.pause();
    player.src = "";
    document.getElementById("modal").style.display = "none";
}

function openVLC() {
    if(currentStreamUrl) {
        window.location.href = `vlc://${currentStreamUrl}`;
    }
}