import asyncio
import logging
from pyrogram import Client, filters
from aiohttp import web
import aiohttp_jinja2
import jinja2
from motor.motor_asyncio import AsyncIOMotorClient

# --- CONFIGURATION (Yaha apni details bharo) ---
API_ID = 35163791  # my.telegram.org se lo
API_HASH = "9ca25c5054cdb8ab4aec8f7041fd7757"
BOT_TOKEN = "8451562169:AAFvbMmdGSRfN7aJMr9Ht7Ta0nw-AYCsrA4" # BotFather se lo
MONGO_URL = "mongodb+srv://rdx27652:nancyrawat@cluster0.d7v1xoh.mongodb.net/?appName=Cluster0" # MongoDB Atlas connection string
CHANNEL_ID = -1002682603345 # Wo channel jaha anime upload karoge (Bot ko admin bana dena)
PORT = 8080

# --- SETUP ---
logging.basicConfig(level=logging.INFO)
bot = Client("StreamBot", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)

# Database
mongo = AsyncIOMotorClient(MONGO_URL)
db = mongo.anime_db
col = db.files

# --- BOT LOGIC (File Save Karna) ---
@bot.on_message(filters.chat(CHANNEL_ID) & (filters.video | filters.document))
async def save_file(client, message):
    """Channel me file aate hi DB me save karega"""
    file_name = message.caption or message.video.file_name or "Unknown Anime"
    file_id = message.video.file_id if message.video else message.document.file_id
    msg_id = message.id
    
    # Check if already exists
    exist = await col.find_one({"msg_id": msg_id})
    if not exist:
        await col.insert_one({
            "title": file_name,
            "file_id": file_id,
            "msg_id": msg_id
        })
        print(f"Saved: {file_name}")

# --- WEB SERVER LOGIC ---
routes = web.RouteTableDef()

@routes.get("/")
@aiohttp_jinja2.template('index.html')
async def home(request):
    """Home Page Load karega"""
    # Latest 10 anime dikhayega
    cursor = col.find().sort('_id', -1).limit(10)
    latest_anime = await cursor.to_list(length=10)
    return {'anime_list': latest_anime}

@routes.get("/api/search")
async def search(request):
    """Frontend ke liye search API"""
    query = request.query.get("q", "")
    if not query:
        return web.json_response([])
    
    cursor = col.find({"title": {"$regex": query, "$options": "i"}}).limit(20)
    results = []
    async for doc in cursor:
        results.append({"title": doc['title'], "msg_id": doc['msg_id']})
    return web.json_response(results)

@routes.get("/stream/{msg_id}")
async def stream(request):
    """Video Stream Logic (Important)"""
    try:
        msg_id = int(request.match_info['msg_id'])
        msg = await bot.get_messages(CHANNEL_ID, msg_id)
        if not msg: return web.Response(status=404)

        file = msg.video or msg.document
        file_size = file.file_size
        file_id = file.file_id

        # Range Header (Seeking ke liye)
        range_header = request.headers.get('Range', 0)
        from_bytes, until_bytes = 0, file_size - 1
        if range_header:
            from_bytes, until_bytes = range_header.replace('bytes=', '').split('-')
            from_bytes = int(from_bytes)
            until_bytes = int(until_bytes) if until_bytes else file_size - 1

        headers = {
            'Content-Type': file.mime_type or 'video/mp4',
            'Accept-Ranges': 'bytes',
            'Content-Range': f'bytes {from_bytes}-{until_bytes}/{file_size}',
            'Content-Length': str(until_bytes - from_bytes + 1),
            'Content-Disposition': f'inline; filename="{file.file_name}"'
        }
        
        resp = web.StreamResponse(status=206 if range_header else 200, headers=headers)
        await resp.prepare(request)

        async for chunk in bot.stream_media(file_id, offset=from_bytes, limit=until_bytes - from_bytes + 1):
            await resp.write(chunk)
        return resp
    except Exception as e:
        print(e)
        return web.Response(status=500)

async def start_services():
    await bot.start()
    print("Bot Started!")
    app = web.Application()
    aiohttp_jinja2.setup(app, loader=jinja2.FileSystemLoader('templates'))
    app.add_routes(routes)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, '127.0.0.1', PORT)
    await site.start()
    print(f"Website running on Port {PORT}")
    await asyncio.Event().wait()

if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    loop.run_until_complete(start_services())