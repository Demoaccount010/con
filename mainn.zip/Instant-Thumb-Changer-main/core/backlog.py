from utils.logger import log_update
from core.forwarder import forward_video

async def backlog_scan(user, DATA, limit=6):
    """
    Scan only latest `limit` messages of each source channel
    Forward ONLY missed videos
    """
    for src, tgts in DATA["maps"].items():
        src_id = int(src)

        try:
            async for m in user.get_chat_history(src_id, limit=limit):
                if not m.video:
                    continue

                # 🔒 simple dedup (message id based)
                key = f"{src}:{m.id}"
                posted = DATA.setdefault("_posted", [])

                if key in posted:
                    continue

                # 🔥 forward missed video
                await forward_video(m, tgts)
                posted.append(key)

                # keep memory small
                DATA["_posted"] = posted[-1000:]

                await log_update(src_id, m.chat.title, "video")

        except Exception as e:
            print(f"[BACKLOG] Failed for {src_id}: {e}")
