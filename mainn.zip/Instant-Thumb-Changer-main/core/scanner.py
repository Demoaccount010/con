import asyncio
from core.forwarder import forward_video
from utils.logger import log_scan
from utils.episode import extract_episode, is_episode_done, mark_episode_done

SCAN_LIMIT = 6
SCAN_INTERVAL = 1800  # 30 min

async def background_scanner(user, bot, DATA):
    await asyncio.sleep(15)  # let clients fully start

    while True:
        if not DATA.get("enabled"):
            await asyncio.sleep(SCAN_INTERVAL)
            continue

        for src, targets in DATA["maps"].items():
            src_id = int(src)
            scanned = forwarded = ignored = 0
            forwarded_eps = []
            ignored_eps = []

            # 🔒 HARD SAFETY CHECK
            try:
                await user.get_chat(src_id)
            except Exception as e:
                await log_scan(
                    bot,
                    src_id,
                    "NO ACCESS",
                    0, 0, 0,
                    error="Userbot not joined / invalid channel"
                )
                continue

            try:
                async for m in user.get_chat_history(src_id, limit=SCAN_LIMIT):
                    scanned += 1

                    if not m.video:
                        ignored += 1
                        continue

                    ep = extract_episode(m.caption or m.text or "")
                    if ep == "NA" or is_episode_done(src, ep):
                        ignored += 1
                        ignored_eps.append(ep)
                        continue

                    await forward_video(m, targets)
                    mark_episode_done(src, ep)

                    forwarded += 1
                    forwarded_eps.append(ep)

            except Exception as e:
                await log_scan(
                    bot,
                    src_id,
                    "ERROR",
                    scanned,
                    forwarded,
                    ignored,
                    error=str(e)
                )
                continue

            await log_scan(
                bot,
                src_id,
                "SCAN",
                scanned,
                forwarded,
                ignored,
                forwarded_eps,
                ignored_eps
            )

        await asyncio.sleep(SCAN_INTERVAL)
