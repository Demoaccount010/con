from utils.caption import build_caption

async def forward_video(message, targets):
    caption = build_caption(message.text or message.caption or "")
    for tgt in targets:
        await message.copy(int(tgt), caption=caption)
