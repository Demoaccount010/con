import json
import os
import re

EP_DB = "episodes.json"

# ===============================
# INTERNAL LOAD / SAVE
# ===============================
def _load():
    if not os.path.exists(EP_DB):
        return {}
    try:
        with open(EP_DB, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _save(data):
    try:
        with open(EP_DB, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except Exception:
        pass


# ===============================
# CHECK IF EPISODE ALREADY DONE
# ===============================
def is_episode_done(source_id: str, episode: str) -> bool:
    if not episode or episode == "NA":
        return False
    data = _load()
    return episode in data.get(str(source_id), [])


# ===============================
# MARK EPISODE AS DONE
# ===============================
def mark_episode_done(source_id: str, episode: str):
    if not episode or episode == "NA":
        return

    source_id = str(source_id)
    data = _load()

    eps = data.setdefault(source_id, [])
    if episode not in eps:
        eps.append(episode)

        # 🔒 safety: max 1000 eps per channel
        if len(eps) > 1000:
            data[source_id] = eps[-1000:]

        _save(data)


# ===============================
# BASIC EPISODE EXTRACTOR (LEGACY)
# ===============================
def extract_episode(text: str) -> str:
    """
    Legacy extractor (kept for backward compatibility)
    """
    if not text:
        return "NA"

    t = text.lower()

    patterns = [
        r'\[(\d{1,4})\]',                     # [345]
        r's\d{1,2}\s*e(\d{1,4})',              # S15E25
        r'episode\s*[:\-]?\s*(\d{1,4})',       # Episode: 25
        r'\bep\s*(\d{1,4})',                   # EP25
        r'\be(\d{1,4})\b',                     # E25
    ]

    for p in patterns:
        m = re.search(p, t, re.I)
        if m:
            ep = int(m.group(1))
            if 1 <= ep <= 5000:
                return str(ep)

    return "NA"


# ===============================
# ADVANCED SEASON + EPISODE EXTRACTOR
# ===============================
def extract_season_episode(text: str):
    """
    Returns:
        (season, episode)

    season -> str | None
    episode -> str | "NA"

    ✅ Handles:
    - Season: 15
    - Episode: 25 [345]
    - S15E25
    - EP25
    - E25
    """

    if not text:
        return None, "NA"

    t = text.lower()

    # ------------------ SEASON ------------------
    season = None
    m = re.search(r'season\s*[:\-]?\s*(\d{1,2})', t)
    if m:
        season = m.group(1)

    # ------------------ EPISODE ------------------
    # 🔥 HIGHEST PRIORITY → [345]
    m = re.search(r'\[(\d{1,4})\]', t)
    if m:
        return season, m.group(1)

    patterns = [
        r's\d{1,2}\s*e(\d{1,4})',        # S15E25
        r'episode\s*[:\-]?\s*(\d{1,4})', # Episode: 25
        r'\bep\s*(\d{1,4})',             # EP25
        r'\be(\d{1,4})\b',               # E25
    ]

    for p in patterns:
        m = re.search(p, t, re.I)
        if m:
            ep = int(m.group(1))
            if 1 <= ep <= 5000:
                return season, str(ep)

    return season, "NA"
