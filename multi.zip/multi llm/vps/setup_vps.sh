#!/bin/bash

# =================================================================
# NEXUS AGENT - VPS SETUP SCRIPT
# Role: Automates Ollama installation and secure remote access setup.
# Usage: bash setup_vps.sh <model_name>
# =================================================================

echo "--- Starting VPS Configuration for NEXUS AGENT ---"

# 1. CONFIGURE OLLAMA FOR REMOTE ACCESS
echo "[1/4] Configuring Ollama for remote access..."
# Ensure the directory exists
mkdir -p /etc/systemd/system/ollama.service.d
cat <<EOF > /etc/systemd/system/ollama.service.d/override.conf
[Service]
Environment="OLLAMA_HOST=0.0.0.0:11434"
Environment="OLLAMA_NUM_PARALLEL=4"
EOF

# Reload and restart
systemctl daemon-reload
systemctl restart ollama

# 2. CONFIGURE FIREWALL
echo "[2/4] Exposing ports 11434 and 8080..."
if command -v ufw > /dev/null; then
    ufw allow 11434/tcp
    ufw allow 8080/tcp
    echo "UFW rules added (11434, 8080)."
elif command -v firewall-cmd > /dev/null; then
    firewall-cmd --permanent --add-port=11434/tcp
    firewall-cmd --permanent --add-port=8080/tcp
    firewall-cmd --reload
    echo "Firewall-cmd rules added (11434, 8080)."
else
    echo "Warning: No UFW or Firewall-cmd found. Please ensure ports 11434 and 8080 are open manually."
fi

# 3. OPTIONAL: NGINX REVERSE PROXY WITH API KEY AUTH
echo "[3/4] Setting up Nginx Reverse Proxy with API Key authentication..."
apt-get update && apt-get install -y nginx apache2-utils

API_KEY=$(openssl rand -hex 32)
echo "$API_KEY" > ~/ollama_api_key.txt

cat <<EOF > /etc/nginx/sites-available/ollama
server {
    listen 8080;

    location / {
        if (\$http_x_api_key != "$API_KEY") {
            return 401 "Unauthorized - Invalid API Key\n";
        }

        proxy_pass http://localhost:11434;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;

        # Streaming support
        proxy_buffering off;
        proxy_cache off;
        proxy_read_timeout 600s;
        proxy_send_timeout 600s;
    }
}
EOF

ln -sf /etc/nginx/sites-available/ollama /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
systemctl restart nginx

# 4. WARMUP
echo "[4/4] Running health check..."
sleep 5
# Simple tag check to see if Ollama is up
RESPONSE=$(curl -s http://localhost:11434/api/tags)

if echo "$RESPONSE" | grep -q "models"; then
    echo "SUCCESS: Ollama is reachable."
else
    echo "WARNING: Connection test failed. Check settings with 'systemctl status ollama'."
fi

# 7. PRINT FINAL SUMMARY
IP_ADDR=$(curl -s https://ifconfig.me)
echo "---------------------------------------------------------"
echo "VPS CONFIGURATION COMPLETE"
echo "---------------------------------------------------------"
echo "Public IP:  $IP_ADDR"
echo "API Key:    $API_KEY (Shared in config.yaml)"
echo "Endpoint:   http://$IP_ADDR:8080"
echo "---------------------------------------------------------"
echo "What to add to config.yaml:"
echo "vps_url: \"http://$IP_ADDR:8080\""
echo "api_key: \"$API_KEY\""
echo "---------------------------------------------------------"
