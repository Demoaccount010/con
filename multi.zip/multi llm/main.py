"""
NEXUS AGENT - Main
The primary entry point and CLI loop.
"""

import asyncio
import os
import sys
import yaml
import argparse
import logging
from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from ui.display import UIDisplay, console
from ui.commands import CommandHandler
from core.brain import Brain

# Set up logging to file, not console (to keep UI clean)
os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    filename="logs/nexus.log",
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

async def main():
    """Main CLI execution loop."""
    parser = argparse.ArgumentParser(description="NEXUS AGENT - Multi-LLM Orchestration")
    parser.add_argument("-w", "--workspace", required=True, help="Path to your workspace")
    parser.add_argument("-c", "--config", default="config.yaml", help="Path to config.yaml")
    args = parser.parse_args()

    # 1. Load Config
    if not os.path.exists(args.config):
        console.print(f"[red]Error: Configuration file not found at {args.config}[/red]")
        return

    with open(args.config, 'r') as f:
        config = yaml.safe_load(f)

    # 2. Setup UI & Banner
    UIDisplay.show_banner()
    
    # 3. Initialize Brain
    brain = Brain(config)
    
    # Initialize Engines & Tools (Normally done inside Brain)
    # For completion, we manually link them here for this complete snippet
    from memory.context import ContextBuilder
    from memory.store import MemoryStore
    from tools.terminal import TerminalExecutor
    from thinking.engine import ThinkingEngine
    from planning.planner import PlanningEngine
    from generation.generator import GenerationEngine
    
    brain.context_builder = ContextBuilder(args.workspace)
    brain.memory_store = MemoryStore(config['memory']['memory_file'])
    brain.terminal = TerminalExecutor(
        args.workspace, 
        config['terminal']['allowed_commands'],
        config['terminal']['blocked_patterns']
    )
    brain.thinking_engine = ThinkingEngine(brain.model_pool, config)
    brain.planning_engine = PlanningEngine(brain.model_pool)
    brain.generation_engine = GenerationEngine(brain.model_pool, args.workspace)

    health = await brain.initialize()
    UIDisplay.show_status(health)

    # 4. Interactive Mode Selection
    if config.get('telegram', {}).get('enabled'):
        from ui.telegram_bot import NexusTelegramBot
        console.print(f"[bold cyan]TELEGRAM MODE ACTIVE:[/bold cyan] Monitoring Owner ID {config['telegram']['owner_id']}...")
        
        bot = NexusTelegramBot(
            config['telegram']['token'],
            config['telegram']['owner_id'],
            brain
        )
        
        try:
            await bot.start()
        except Exception as e:
            console.print(f"[red]Telegram Bot error: {e}[/red]")
    else:
        # CLI Loop fallback
        session = PromptSession(history=FileHistory('.nexus/history'))
        cmd_handler = CommandHandler(brain, args.workspace)

        console.print("\n[bold cyan]NEXUS AGENT READY (CLI).[/bold cyan] Type a request or /help.")

        while True:
            try:
                user_input = await session.prompt_async("\n>>> ")
                
                if not user_input.strip():
                    continue

                if user_input.startswith("/"):
                    should_continue = await cmd_handler.handle(user_input)
                    if not should_continue:
                        break
                    continue

                with console.status("[bold green]Agent is thinking...", spinner="dots"):
                    response = await brain.process_task(user_input, args.workspace)
                    UIDisplay.print_message("NEXUS", response)

            except (KeyboardInterrupt, EOFError):
                break
            except Exception as e:
                console.print(f"[red]ERROR: {str(e)}[/red]")

    await brain.shutdown()

if __name__ == "__main__":
    asyncio.run(main())
