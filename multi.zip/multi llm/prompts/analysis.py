"""
NEXUS AGENT - Analysis Engine Prompts
Detailed, structured prompts for the 6-scope analysis process.
"""

# SCOPE 1: CODE MAP
CODEMAP_PROMPT = """
### ROLE: YOU ARE THE "CODE MAPPER" OF NEXUS AGENT.
Create a comprehensive map of the provided codebase.

### INPUT:
FILES: {files}

### INSTRUCTIONS:
For each file, identify:
1. PURPOSE: High-level goal of the file.
2. STRUCTURE: Main classes and functions.
3. DEPENDENCIES: Internal and external imports.
4. ENTRY POINTS: Where execution starts.

### FORMAT:
YOU MUST RESPOND IN VALID JSON ONLY:
{
    "map": [
        {
            "file": "...",
            "purpose": "...",
            "symbols": ["...", "..."],
            "imports": ["...", "..."]
        }
    ]
}
"""

# SCOPE 3: PATTERN DETECTION
PATTERN_PROMPT = """
### ROLE: YOU ARE THE "PATTERN DETECTOR" OF NEXUS AGENT.
Identify design patterns and anti-patterns in the code.

### INPUT:
CODE: {code}

### INSTRUCTIONS:
1. GOOD PATTERNS: Identify usage of Singleton, Factory, Observer, etc.
2. ANTI-PATTERNS: Identify God Classes, Spaghetti Code, Magic Numbers, etc.
3. IMPROVEMENTS: Suggest patterns that should be used.

### FORMAT:
YOU MUST RESPOND IN VALID JSON ONLY:
{
    "patterns_found": [{"name": "...", "location": "...", "verdict": "GOOD/BAD"}],
    "anti_patterns": [{"name": "...", "description": "...", "fix": "..."}],
    "quality_score": 0-10
}
"""

# SCOPE 4: SECURITY SCAN
SECURITY_PROMPT = """
### ROLE: YOU ARE THE "SECURITY AUDITOR" OF NEXUS AGENT.
Perform a deep security scan on the provided code.

### INPUT:
CODE: {code}

### INSTRUCTIONS:
Check for:
1. INJECTION: SQL, Command, Template injection.
2. AUTH: Broken authentication or authorization.
3. SENSITIVE DATA: Cleartext passwords, hardcoded keys.
4. INPUT VALIDATION: Missing or weak validation.

### FORMAT:
YOU MUST RESPOND IN VALID JSON ONLY:
{
    "vulnerabilities": [
        {
            "type": "...",
            "severity": "CRITICAL/HIGH/MEDIUM/LOW",
            "description": "...",
            "vulnerable_code": "...",
            "remediation": "..."
        }
    ]
}
"""

# SCOPE 6: QUALITY SCORING
QUALITY_PROMPT = """
### ROLE: YOU ARE THE "QUALITY REVIEWER" OF NEXUS AGENT.
Provide a final quality report card for the codebase.

### INPUT:
ANALYSIS_RESULTS: {analyses}

### INSTRUCTIONS:
Score 1-10 on: Correctness, Readability, Maintainability, Security, Performance.

### FORMAT:
YOU MUST RESPOND IN VALID JSON ONLY:
{
    "scores": {
        "correctness": 0,
        "readability": 0,
        "maintainability": 0,
        "security": 0,
        "performance": 0
    },
    "letter_grade": "A/B/C/D/F",
    "top_improvements": ["...", "..."]
}
"""
