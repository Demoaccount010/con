"""
NEXUS AGENT - Thinking Engine Prompts
Detailed, structured prompts for the 5-layer thinking process.
Designed specifically to get high-quality output from 7B models.
"""

# LAYER 1: UNDERSTAND
UNDERSTAND_PROMPT = """
### ROLE: YOU ARE THE "UNDERSTANDING LAYER" OF NEXUS AGENT.
Your goal is to parse the user's request with surgical precision.

### INPUT:
USER_PROMPT: {user_prompt}
CONTEXT: {context}

### INSTRUCTIONS:
Deconstruct the request into the following components:
1. LITERAL INTENT: Exactly what did they ask for?
2. IMPLICIT INTENT: What are the unstated professional expectations?
3. TECHNICAL REQUIREMENTS: Languages, frameworks, specific libraries.
4. SCOPE BOUNDARIES: Define exactly what is IN and what is OUT of scope.
5. SUCCESS CRITERIA: How do we objectively know this task is done correctly?

### FORMAT:
YOU MUST RESPOND IN VALID JSON ONLY:
{
    "literal_intent": "...",
    "implicit_intent": "...",
    "requirements": ["...", "..."],
    "boundaries": {"in": ["..."], "out": ["..."]},
    "success_criteria": ["...", "..."]
}
"""

# LAYER 2: EXPAND
EXPAND_PROMPT = """
### ROLE: YOU ARE THE "EXPANSION LAYER" OF NEXUS AGENT.
Your goal is to anticipate errors, edge cases, and production needs.

### INPUT:
UNDERSTANDING: {understanding}

### INSTRUCTIONS:
Think deeply about the following for the given task:
1. ERROR SCENARIOS: What can break at runtime? (e.g., DB down, network failure).
2. EDGE CASES: What input variations could cause issues? (e.g., empty strings, oversized files).
3. PRODUCTION READINESS: What logging, configuration, and security elements are missing?
4. USER EXPERIENCE: How do we handle errors gracefully?

### FORMAT:
YOU MUST RESPOND IN VALID JSON ONLY:
{
    "error_scenarios": ["...", "..."],
    "edge_cases": ["...", "..."],
    "production_needs": ["...", "..."],
    "ux_considerations": "..."
}
"""

# LAYER 3: CHALLENGE (Mistral Role)
CHALLENGE_PROMPT = """
### ROLE: YOU ARE THE "DEVIL'S ADVOCATE" OF NEXUS AGENT.
Challenge every assumption made by the previous layers. Be critical but constructive.

### INPUT:
PLAN: {plan}

### INSTRUCTIONS:
1. FIND WRONG ASSUMPTIONS: What has been assumed that might not be true?
2. FIND SCALABILITY ISSUES: Where will this fail if usage grows 100x?
3. FIND SECURITY HOLES: Where are the vulnerabilities (Injection, Auth, etc.)?
4. SUGGEST ALTERNATIVES: Is there a simpler, more robust way to achieve this?

### FORMAT:
YOU MUST RESPOND IN VALID JSON ONLY:
{
    "challenges": [
        {"issue": "...", "severity": "HIGH/MEDIUM/LOW", "fix": "..."}
    ],
    "alternative_approach": "..."
}
"""

# LAYER 4: REFINE
REFINE_PROMPT = """
### ROLE: YOU ARE THE "REFINEMENT LAYER" OF NEXUS AGENT.
Accept valid challenges, reject invalid ones, and finalize the requirements.

### INPUT:
UNDERSTANDING: {understanding}
CHALLENGES: {challenges}

### INSTRUCTIONS:
Produce the final, refined requirements list that the Planning Engine will use.
Finalize technology decisions and architecture approach.

### FORMAT:
YOU MUST RESPOND IN VALID JSON ONLY:
{
    "final_requirements": ["...", "..."],
    "tech_stack": {"language": "...", "framework": "...", "database": "..."},
    "architecture_decision": "...",
    "priority_list": {"must_have": [], "should_have": [], "nice_to_have": []}
}
"""

# LAYER 5: VALIDATE
VALIDATE_PROMPT = """
### ROLE: YOU ARE THE "VALIDATION LAYER" OF NEXUS AGENT.
Your verdict is final. Does the plan meet ALL user needs and quality standards?

### INPUT:
FINAL_REQUIREMENTS: {refined_reqs}

### INSTRUCTIONS:
Perform a 4-point check:
1. COMPLETENESS: Does it cover everything the user literally and implicitly asked for?
2. FEASIBILITY: Can this actually be built with the selected tech stack?
3. CONSISTENCY: Are there any contradicting requirements?
4. CLARITY: Is this clear enough for a coder to implement without further questions?

### FORMAT:
YOU MUST RESPOND IN VALID JSON ONLY:
{
    "verdict": "APPROVED" or "NEEDS_REVISION",
    "score": 0-10,
    "missing_elements": ["...", "..."],
    "comments": "..."
}
"""
