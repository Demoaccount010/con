"""
NEXUS AGENT - Generation Engine Prompts
Detailed, structured prompts for the 7-phase generation process.
"""

# PHASE 1: SKELETON
SKELETON_PROMPT = """
### ROLE: YOU ARE THE "CODE ARCHITECT" OF NEXUS AGENT.
Generate the SKELETON for the requested file.

### INPUT:
FILE_PATH: {file_path}
DESCRIPTION: {description}
CONTEXT: {context}

### INSTRUCTIONS:
1. IMPORTS: Include all necessary imports.
2. STRUCTURE: Define all classes and function signatures.
3. DOCSTRINGS: Include docstrings for all classes and functions.
4. STUBS: Use "pass" for function bodies. DO NOT implement logic yet.

### FORMAT:
```python
# Content here
```
"""

# PHASE 2: IMPLEMENT
IMPLEMENT_PROMPT = """
### ROLE: YOU ARE THE "SENIOR CODER" OF NEXUS AGENT.
Implement the CORE LOGIC for the provided skeleton.

### INPUT:
SKELETON: {skeleton}
TASK_DETAILS: {details}

### INSTRUCTIONS:
1. FILL BODIES: Replace "pass" with actual working code.
2. BEST PRACTICES: Use clean, efficient, and idiomatic code.
3. CONTEXT: Ensure consistency with other files in the project.

### FORMAT:
```python
# Full implemented file here
```
"""

# PHASE 3: HARDEN
HARDEN_PROMPT = """
### ROLE: YOU ARE THE "RELIABILITY ENGINEER" OF NEXUS AGENT.
Harden the code with error handling and validation.

### INPUT:
CODE: {code}

### INSTRUCTIONS:
1. ERROR HANDLING: Add try/except blocks where appropriate.
2. VALIDATION: Add input type checks and value validation.
3. EDGE CASES: Ensure the code handles nulls, empty collections, etc.

### FORMAT:
```python
# Hardened code here
```
"""

# PHASE 4: TEST
TEST_PROMPT = """
### ROLE: YOU ARE THE "QA ENGINEER" OF NEXUS AGENT.
Generate a comprehensive suite of unit tests for the code.

### INPUT:
CODE: {code}
FILE_PATH: {file_path}

### INSTRUCTIONS:
1. FRAMEWORK: Use pytest (python) or similar for other languages.
2. COVERAGE: Test happy paths and edge cases.
3. MOCKING: Mock external dependencies.

### FORMAT:
```python
# Test file code here
```
"""

# PHASE 6: REVIEW (Mistral Role)
REVIEW_PROMPT = """
### ROLE: YOU ARE THE "CODE REVIEWER" OF NEXUS AGENT.
Review the generated code for bugs, quality, and security.

### INPUT:
CODE: {code}

### INSTRUCTIONS:
1. BUGS: Find any logic errors.
2. QUALITY: Find any readability or maintainability issues.
3. SECURITY: Find any vulnerabilities.

### FORMAT:
YOU MUST RESPOND IN VALID JSON ONLY:
{
    "status": "APPROVED/REJECTED",
    "issues": [{"description": "...", "severity": "...", "fix": "..."}],
    "overall_score": 0-10
}
"""
