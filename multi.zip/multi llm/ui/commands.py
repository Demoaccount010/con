"""
NEXUS AGENT - Slash Commands
Handles all user-input slash commands (e.g. /help, /tree, /run).
"""

import os
import sys
import logging
from ui.display import console, UIDisplay

logger = logging.getLogger("commands")

class CommandHandler:
    """Logic for executing agent slash commands."""

    def __init__(self, brain: 'Brain', workspace_path: str):
        self.brain = brain
        self.workspace_path = workspace_path

    async def handle(self, input_str: str) -> bool:
        """
        Parses and executes a command. Returns False if the loop should exit.
        """
        parts = input_str.strip().split()
        if not parts:
            return True
            
        cmd = parts[0].lower()
        args = parts[1:]

        if cmd == "/help":
            self._show_help()
        elif cmd == "/tree":
            self._show_tree()
        elif cmd in ["/quit", "/exit"]:
            console.print("[yellow]Shutting down NEXUS AGENT...[/yellow]")
            return False
        elif cmd == "/status":
            health = await self.brain.initialize()
            UIDisplay.show_status(health)
        elif cmd == "/run":
            await self._run_command(" ".join(args))
        elif cmd == "/clear":
            os.system('cls' if os.name == 'nt' else 'clear')
        else:
            console.print(f"[red]Unknown command: {cmd}. Type /help for assistance.[/red]")
            
        return True

    def _show_help(self):
        """Displays command help."""
        help_text = """
### AVAILABLE COMMANDS:
- **/help**: Show this help message.
- **/tree**: Show workspace file structure.
- **/status**: Show model health and stats.
- **/run <cmd>**: Execute a terminal command safely.
- **/clear**: Clear the terminal screen.
- **/quit**: Exit the application.

*To start a task, simply type your natural language prompt without a slash.*
        """
        UIDisplay.print_message("SYSTEM", help_text)

    def _show_tree(self):
        """Shows the workspace tree from the context builder."""
        tree = self.brain.context_builder._get_file_tree()
        UIDisplay.print_message("WORKSPACE", f"```text\n{tree}\n```")

    async def _run_command(self, command_str: str):
        """Executes a command via the terminal executor."""
        if not command_str:
            console.print("[red]Usage: /run <command>[/red]")
            return
            
        executor = self.brain.terminal
        result = await executor.execute(command_str)
        
        if result.success:
            console.print(f"[green]Command executed successfully.[/green]")
            if result.stdout:
                UIDisplay.print_code(result.stdout, "text")
        else:
            console.print(f"[red]Command failed (Exit {result.exit_code})[/red]")
            if result.stderr:
                console.print(f"[red]{result.stderr}[/red]")
