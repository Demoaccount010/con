"""
NEXUS AGENT - Telegram Interface
Autonomous, owner-only control system.
"""

import logging
import asyncio
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from typing import Dict, Any

logger = logging.getLogger("telegram_bot")

class NexusTelegramBot:
    """The primary interaction layer for the owner via Telegram."""

    def __init__(self, token: str, owner_id: int, brain: 'Brain'):
        self.bot = Bot(token=token)
        self.dp = Dispatcher()
        self.owner_id = owner_id
        self.brain = brain
        self._register_handlers()

    def _register_handlers(self):
        """Registers all bot commands and message handlers."""
        
        @self.dp.message(Command("start"))
        async def cmd_start(message: types.Message):
            if message.from_user.id != self.owner_id:
                await message.reply("⛔ [ACCESS DENIED] This system is security-locked to a specific owner.")
                return

            profile = self.brain.memory_store.data.get("owner_profile", {})
            if not profile:
                await message.answer("👋 Namaste! I am NEXUS AGENT.\n\nPlease tell me: What is your name?")
                self.brain.memory_store.data["awaiting_onboarding"] = True
            else:
                await message.answer(
                    f"Welcome back, {profile.get('name', 'Owner')}. NEXUS AGENT is online.\n\n"
                    "All LLM Nodes (DeepSeek, Qwen, Mistral) are connected across your 3 VPS instances.",
                    reply_markup=self._get_main_keyboard()
                )

        @self.dp.message()
        async def handle_message(message: types.Message):
            if message.from_user.id != self.owner_id:
                return

            # Onboarding check
            if self.brain.memory_store.data.get("awaiting_onboarding"):
                name = message.text.strip()
                self.brain.memory_store.data["owner_profile"] = {"name": name}
                self.brain.memory_store.data["awaiting_onboarding"] = False
                await self.brain.memory_store.save()
                await message.answer(f"Confirmed. From now on, I am your loyal agent, {name}.\n"
                                     "I have full control over the main VPS and can evolve my own code as per your commands.\n"
                                     "What would you like me to do first?")
                return

            # Process AI task
            status_msg = await message.answer("🧠 [NEXUS THINKING] Starting orchestration sequence...")
            
            try:
                # Orchestral processing
                response = await self.brain.process_task(message.text, ".")
                
                # If the response is too long, split it or send as file
                if len(response) > 4000:
                    parts = [response[i:i+4000] for i in range(0, len(response), 4000)]
                    for p in parts:
                        await message.answer(p)
                else:
                    await message.answer(response, parse_mode="Markdown")
            except Exception as e:
                await message.answer(f"⚠️ [ERROR] Orchestration failed: {str(e)}")
            finally:
                await self.bot.delete_message(message.chat.id, status_msg.message_id)

    def _get_main_keyboard(self) -> InlineKeyboardMarkup:
        """Standard interaction buttons."""
        buttons = [
            [InlineKeyboardButton(text="📊 System Status", callback_data="status")],
            [InlineKeyboardButton(text="🧠 Evolution Mode", callback_data="evolution")],
            [InlineKeyboardButton(text="📁 Workspace Tree", callback_data="tree")]
        ]
        return InlineKeyboardMarkup(inline_keyboard=buttons)

    async def start(self):
        """Starts the bot polling."""
        logger.info("NEXUS Telegram Bot started...")
        await self.dp.start_polling(self.bot)

    async def stop(self):
        """Shutdown the bot."""
        await self.bot.session.close()
