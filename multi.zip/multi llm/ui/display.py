"""
NEXUS AGENT - UI Display
Professional, colored terminal UI components using the Rich library.
"""

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.live import Live
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich.markdown import Markdown
from rich.syntax import Syntax
from rich.theme import Theme
from datetime import datetime

# Custom theme for NEXUS AGENT
NEXUS_THEME = Theme({
    "info": "cyan",
    "warning": "yellow",
    "error": "bold red",
    "success": "bold green",
    "model.deepseek": "bold blue",
    "model.qwen": "bold purple",
    "model.mistral": "bold orange3",
    "engine.thinking": "cyan",
    "engine.planning": "green",
    "engine.analysis": "yellow",
    "engine.generation": "blue",
})

console = Console(theme=NEXUS_THEME)

class UIDisplay:
    """Utilities for rendering the NEXUS AGENT interface."""

    @staticmethod
    def show_banner():
        """Displays the startup banner."""
        banner = """
[bold cyan]
███╗   ██╗███████╗██╗  ██╗██╗   ██╗███████╗    █████╗  ██████╗ ███████╗███╗   ██╗████████╗
████╗  ██║██╔════╝╚██╗██╔╝██║   ██║██╔════╝   ██╔══██╗██╔════╝ ██╔════╝████╗  ██║╚══██╔══╝
██╔██╗ ██║█████╗   ╚███╔╝ ██║   ██║███████╗   ███████║██║  ███╗█████╗  ██╔██╗ ██║   ██║   
██║╚██╗██║██╔══╝   ██╔██╗ ██║   ██║╚════██║   ██╔══██║██║   ██║██╔══╝  ██║╚██╗██║   ██║   
██║ ╚████║███████╗██╔╝ ██╗╚██████╔╝███████║   ██║  ██║╚██████╔╝███████╗██║ ╚████║   ██║   
╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝   ╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝  ╚═══╝   ╚═╝   
[/bold cyan]
[bold white]Production-Grade Multi-LLM Orchestration System[/bold white]
    """
        console.print(banner)

    @staticmethod
    def show_status(model_health: dict):
        """Displays a table of model health statuses."""
        table = Table(title="Model Status")
        table.add_column("Role", style="cyan")
        table.add_column("Status", style="bold")
        
        for role, healthy in model_health.items():
            status = "[green]ONLINE[/green]" if healthy else "[red]OFFLINE[/red]"
            table.add_row(role.capitalize(), status)
        
        console.print(table)

    @staticmethod
    def print_message(role: str, content: str):
        """Prints a message from a model with specific styling."""
        style = f"model.{role.lower()}"
        panel = Panel(
            Markdown(content),
            title=f"[bold]{role.upper()}[/bold]",
            border_style=style,
            padding=(1, 2)
        )
        console.print(panel)

    @staticmethod
    def show_engine_progress(engine_name: str, task: str):
        """Displays a simple progress indicator for an engine."""
        style = f"engine.{engine_name.lower()}"
        console.print(f"[{style}]▶[/] [bold]{engine_name.upper()}:[/] {task}...", style="white")

    @staticmethod
    def print_code(code: str, language: str = "python"):
        """Prints syntax-highlighted code."""
        syntax = Syntax(code, language, theme="monokai", line_numbers=True)
        console.print(syntax)

    @staticmethod
    def debug(msg: str):
        """Prints a debug message."""
        console.print(f"[dim gray][DEBUG] {msg}[/]")
