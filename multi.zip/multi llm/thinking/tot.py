"""
NEXUS AGENT - Tree of Thoughts (ToT)
Generates multiple reasoning paths, evaluates them, and selects the best one.
"""

import asyncio
import json
from typing import List, Dict, Any, TYPE_CHECKING

if TYPE_CHECKING:
    from core.model_client import ModelClient

class TreeOfThoughts:
    """Orchestrates multi-path reasoning."""

    def __init__(self, model_client: 'ModelClient'):
        self.model = model_client

    async def solve(self, problem: str, num_paths: int = 3) -> Dict[str, Any]:
        """
        1. Generate N different approaches (branches).
        2. Evaluate each approach.
        3. Select the best one.
        """
        # Step 1: Generate Branches
        branch_prompt = f"Generate {num_paths} distinct, creative, and viable approaches to solve this problem:\n{problem}\n\nFormat as a numbered list."
        branches_raw = await self.model.generate(branch_prompt)
        
        # Parse branches (simple split for 7B models)
        branches = [b.strip() for b in branches_raw.split('\n') if b.strip() and any(c.isdigit() for c in b[:2])]
        if not branches:
            branches = [branches_raw]

        # Step 2: Evaluate Branches (Parallel)
        eval_tasks = [self._evaluate_branch(problem, b) for b in branches]
        evaluations = await asyncio.gather(*eval_tasks)

        # Step 3: Select Winner
        best_idx = 0
        max_score = -1
        for i, eval_data in enumerate(evaluations):
            if eval_data['score'] > max_score:
                max_score = eval_data['score']
                best_idx = i

        return {
            "branches": branches,
            "evaluations": evaluations,
            "best_approach": branches[best_idx],
            "reasoning": evaluations[best_idx]['reasoning']
        }

    async def _evaluate_branch(self, problem: str, branch: str) -> Dict[str, Any]:
        eval_prompt = f"""
        PROBLEM: {problem}
        PROPOSED APPROACH: {branch}
        
        Evaluate this approach for:
        1. FEASIBILITY (0-10)
        2. EFFICIENCY (0-10)
        3. SECURITY (0-10)
        
        FORMAT YOUR RESPONSE AS JSON:
        {{
            "score": TOTAL_AVG_SCORE,
            "reasoning": "Brief explanation",
            "risks": ["...", "..."]
        }}
        """
        response = await self.model.generate(eval_prompt)
        try:
            start = response.find('{')
            end = response.rfind('}') + 1
            return json.loads(response[start:end])
        except:
            return {"score": 5, "reasoning": "Evaluation failed", "risks": []}
