"""
NEXUS AGENT - Multi-Model Consensus
Finds common ground when multiple models generate different outputs.
"""

import asyncio
from typing import List, Dict, Any
import logging

logger = logging.getLogger("consensus")

class ConsensusBuilder:
    """Builds consensus between different models."""

    def __init__(self, model_pool: 'ModelPool'):
        self.pool = model_pool

    async def get_consensus(self, prompt: str, roles: List[str]) -> Dict[str, Any]:
        """
        1. Get output from all specified model roles.
        2. Use the 'Thinker' model to synthesize a consensus.
        """
        # Step 1: Collect responses from all roles in parallel
        tasks = []
        for role in roles:
            client = await self.pool.get_client(role)
            tasks.append(client.generate(prompt))
            
        responses = await asyncio.gather(*tasks)
        role_responses = dict(zip(roles, responses))

        # Step 2: Synthesis by the Thinker
        thinker = await self.pool.get_client("thinker")
        
        synthesis_prompt = f"""
        Multiple AI models have provided different perspectives on the same task.
        
        TASK: {prompt}
        
        RESPONSES:
        {chr(10).join([f"--- ROLE: {role} ---\n{resp}\n" for role, resp in role_responses.items()])}
        
        YOUR GOAL:
        1. Identify common ground (agreements).
        2. Identify contradictions (disagreements).
        3. Determine the most valid path forward based on technical merit.
        4. Provide the FINAL CONSENSUS answer.
        
        FORMAT YOUR RESPONSE AS JSON:
        {{
            "agreements": ["...", "..."],
            "disagreements": ["...", "..."],
            "resolution": "...",
            "final_answer": "..."
        }}
        """
        
        result_raw = await thinker.generate(synthesis_prompt)
        try:
            import json
            start = result_raw.find('{')
            end = result_raw.rfind('}') + 1
            consensus = json.loads(result_raw[start:end])
            return consensus
        except:
            return {
                "final_answer": role_responses.get("thinker", responses[0]),
                "resolution": "Syntheses failed, falling back to primary response."
            }
