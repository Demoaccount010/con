"""
NEXUS AGENT - Chain of Thought (CoT)
Implements step-by-step reasoning for complex decision making.
"""

from typing import List, Dict, Any, Optional, TYPE_CHECKING
import json

if TYPE_CHECKING:
    from core.model_client import ModelClient

class ChainOfThought:
    """Orchestrates step-by-step reasoning for a given prompt."""

    def __init__(self, model_client: 'ModelClient'):
        self.model = model_client

    async def reason(self, prompt: str, steps: int = 3) -> Dict[str, Any]:
        """
        Forces the model to reason in steps.
        Each step builds on the previous one.
        """
        history: List[str] = []
        current_context = prompt
        
        system_prompt = f"""
        You are using CHAIN-OF-THOUGHT reasoning.
        Break the problem into exactly {steps} logical steps.
        For each step, provide:
        1. THOUGHT: Your internal reasoning.
        2. CONCLUSION: The result of this step.
        """

        for i in range(1, steps + 1):
            step_prompt = f"REASONING STEP {i}/{steps}.\nContext so far: {' '.join(history)}\n\nNext logical reasoning step for: {current_context}"
            
            response = await self.model.generate(step_prompt, system_prompt=system_prompt)
            history.append(response)
            
        final_prompt = f"Based on these reasoning steps: {' '.join(history)}\n\nProvide the final definitive answer."
        final_answer = await self.model.generate(final_prompt)
        
        return {
            "steps": history,
            "final_answer": final_answer
        }
