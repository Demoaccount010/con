"""
NEXUS AGENT - Self Reflection
Allows the model to check its own output and self-correct.
"""

import json
import logging
from typing import Dict, Any

logger = logging.getLogger("reflection")

class SelfReflection:
    """Enables iterative improvement via self-critique."""

    def __init__(self, model_client: 'ModelClient'):
        self.model = model_client

    async def reflect(self, original_prompt: str, original_output: str, rounds: int = 1) -> str:
        """
        1. Critique the output.
        2. Revise based on critique.
        """
        current_output = original_output

        for r in range(rounds):
            logger.info(f"Self-reflection round {r+1}/{rounds}...")
            
            critique_prompt = f"""
            ORIGINAL PROMPT: {original_prompt}
            YOUR PREVIOUS OUTPUT: {current_output}
            
            Find all mistakes, inconsistencies, or areas for improvement in your previous output.
            Be extremely harsh. If it's perfect, say "PERFECT".
            """
            
            critique = await self.model.generate(critique_prompt)
            
            if "PERFECT" in critique.upper() and len(critique) < 20:
                break
                
            revision_prompt = f"""
            ORIGINAL PROMPT: {original_prompt}
            PREVIOUS OUTPUT: {current_output}
            CRITIQUE: {critique}
            
            Rewrite your output to address all points in the critique. 
            Maintain the original format but improve the quality.
            """
            
            current_output = await self.model.generate(revision_prompt)

        return current_output
