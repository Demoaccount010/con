"""
NEXUS AGENT - Thinking Engine
Orchestrates the 5-layer deep thinking process.
"""

import logging
import json
from typing import Dict, Any, List
from prompts.thinking import (
    UNDERSTAND_PROMPT, EXPAND_PROMPT, CHALLENGE_PROMPT, 
    REFINE_PROMPT, VALIDATE_PROMPT
)
from thinking.reflection import SelfReflection

logger = logging.getLogger("thinking_engine")

class ThinkingEngine:
    """The 5-Layer Thinking Processor."""

    def __init__(self, model_pool: 'ModelPool', config: Dict[str, Any]):
        self.pool = model_pool
        self.config = config
        self.reflection = None # Init later to avoid circular issues

    async def think(self, user_prompt: str, context: str) -> Dict[str, Any]:
        """Runs the 5-layer thinking pipeline."""
        logger.info("Starting 5-Layer Thinking process...")
        
        thinker = await self.pool.get_client("thinker")
        reviewer = await self.pool.get_client("reviewer")
        
        # Layer 1: UNDERSTAND (Qwen)
        logger.info("Layer 1: Understanding intent...")
        l1_input = UNDERSTAND_PROMPT.format(user_prompt=user_prompt, context=context)
        understanding = await self._call_json(thinker, l1_input)

        # Layer 2: EXPAND (Qwen)
        logger.info("Layer 2: Expanding possibilities...")
        l2_input = EXPAND_PROMPT.format(understanding=json.dumps(understanding))
        expansion = await self._call_json(thinker, l2_input)

        # Layer 3: CHALLENGE (Mistral)
        logger.info("Layer 3: Challenging assumptions...")
        l3_input = CHALLENGE_PROMPT.format(plan=json.dumps({"intent": understanding, "details": expansion}))
        challenges = await self._call_json(reviewer, l3_input)

        # Layer 4: REFINE (Qwen)
        logger.info("Layer 4: Refining requirements...")
        l4_input = REFINE_PROMPT.format(understanding=json.dumps(understanding), challenges=json.dumps(challenges))
        refinement = await self._call_json(thinker, l4_input)

        # Layer 5: VALIDATE (Mistral)
        logger.info("Layer 5: Validating final plan...")
        l5_input = VALIDATE_PROMPT.format(refined_reqs=json.dumps(refinement))
        validation = await self._call_json(reviewer, l5_input)

        return {
            "understanding": understanding,
            "expansion": expansion,
            "challenges": challenges,
            "refinement": refinement,
            "validation": validation
        }

    async def _call_json(self, client: 'ModelClient', prompt: str) -> Dict[str, Any]:
        """Helper to get JSON output from models."""
        response = await client.generate(prompt)
        try:
            start = response.find('{')
            end = response.rfind('}') + 1
            return json.loads(response[start:end])
        except Exception as e:
            logger.error(f"JSON Parsing failed for thinking layer: {e}")
            return {"error": "Invalid JSON response", "raw": response}
