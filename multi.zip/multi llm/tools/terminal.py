"""
NEXUS AGENT - Terminal Executor
Safe execution of terminal commands within the workspace.
"""

import asyncio
import os
import logging
import shlex
from typing import Tuple, List, Optional
from pydantic import BaseModel

logger = logging.getLogger("terminal")

class CommandResult(BaseModel):
    stdout: str
    stderr: str
    exit_code: int
    success: bool

class TerminalExecutor:
    """Safely executes commands in a subprocess."""

    def __init__(self, workspace_root: str, allowed_commands: List[str], blocked_patterns: List[str]):
        self.workspace_root = workspace_root
        self.allowed_commands = allowed_commands
        self.blocked_patterns = blocked_patterns
        self.history: List[str] = []

    async def execute(self, command_str: str, timeout: int = 120) -> CommandResult:
        """
        Executes a shell command after safety checks.
        """
        self.history.append(command_str)
        
        # 1. Parse command
        try:
            args = shlex.split(command_str)
            if not args:
                return CommandResult(stdout="", stderr="Empty command", exit_code=1, success=False)
            base_cmd = args[0]
        except Exception as e:
            return CommandResult(stdout="", stderr=f"Parse error: {e}", exit_code=1, success=False)

        # 2. Safety Whitelist
        if base_cmd not in self.allowed_commands:
            return CommandResult(
                stdout="", 
                stderr=f"BLOCKED: Command '{base_cmd}' is not in the whitelist.", 
                exit_code=403, 
                success=False
            )

        # 3. Pattern Blacklist
        for pattern in self.blocked_patterns:
            if pattern in command_str:
                return CommandResult(
                    stdout="", 
                    stderr=f"BLOCKED: Command contains forbidden pattern: '{pattern}'", 
                    exit_code=403, 
                    success=False
                )

        # 4. Execute
        try:
            logger.info(f"Executing: {command_str}")
            process = await asyncio.create_subprocess_shell(
                command_str,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=self.workspace_root,
                env=os.environ # Pass current env
            )

            try:
                stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=timeout)
                return CommandResult(
                    stdout=stdout.decode().strip(),
                    stderr=stderr.decode().strip(),
                    exit_code=process.returncode or 0,
                    success=process.returncode == 0
                )
            except asyncio.TimeoutError:
                process.kill()
                return CommandResult(stdout="", stderr="ERROR: Command timed out", exit_code=124, success=False)

        except Exception as e:
            logger.error(f"Execution failed: {e}")
            return CommandResult(stdout="", stderr=str(e), exit_code=1, success=False)
