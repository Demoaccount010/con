"""
NEXUS AGENT - File Tools
Helpers for file reading, listing, and gitignore matching.
"""

import os
import pathspec
import logging
from typing import List, Dict, Set

logger = logging.getLogger("file_tools")

class FileTools:
    """Utilities for interacting with the workspace filesystem."""

    def __init__(self, workspace_root: str):
        self.workspace_root = os.path.abspath(workspace_root)
        self.gitignore = self._load_gitignore()

    def _load_gitignore(self):
        """Loads .gitignore patterns for filtering."""
        gitignore_path = os.path.join(self.workspace_root, ".gitignore")
        patterns = []
        if os.path.exists(gitignore_path):
            with open(gitignore_path, "r") as f:
                patterns = f.readlines()
        
        # Add default ignores
        patterns.extend([".git/", ".venv/", "__pycache__/", "*.pyc", ".DS_Store", ".nexus/"])
        return pathspec.PathSpec.from_lines('gitwildmatch', patterns)

    def is_ignored(self, path: str) -> bool:
        """Checks if a path should be ignored."""
        relative_path = os.path.relpath(path, self.workspace_root)
        if relative_path == ".":
            return False
        return self.gitignore.match_file(relative_path)

    def list_files(self, recursive: bool = True) -> List[str]:
        """Lists all non-ignored files in the workspace."""
        all_files = []
        for root, dirs, files in os.walk(self.workspace_root):
            # Filter directories in-place for os.walk
            dirs[:] = [d for d in dirs if not self.is_ignored(os.path.join(root, d))]
            
            for file in files:
                full_path = os.path.join(root, file)
                if not self.is_ignored(full_path):
                    all_files.append(os.path.relpath(full_path, self.workspace_root))
            
            if not recursive:
                break
        return all_files

    def read_file(self, relative_path: str) -> str:
        """Reads a file's content safely."""
        abs_path = os.path.abspath(os.path.join(self.workspace_root, relative_path))
        if not abs_path.startswith(self.workspace_root):
            raise PermissionError("Path traversal detected.")
            
        with open(abs_path, 'r', encoding='utf-8', errors='replace') as f:
            return f.read()

    def get_project_files_content(self, max_files: int = 50) -> Dict[str, str]:
        """Reads content of all important non-ignored files."""
        files = self.list_files()
        content_map = {}
        for f in files[:max_files]:
            try:
                # Skip binary files roughly
                if f.lower().endswith(('.png', '.pyc', '.exe', '.dll', '.so', '.bin')):
                    continue
                content_map[f] = self.read_file(f)
            except Exception as e:
                logger.warning(f"Could not read {f}: {e}")
        return content_map
