"""
NEXUS AGENT - Evolution Engine
Allows the agent to recursively modify and improve its own code.
"""

import os
import logging
import asyncio
from typing import Dict, Any

logger = logging.getLogger("evolution")

class EvolutionEngine:
    """The recursive self-modification heart of NEXUS AGENT."""

    def __init__(self, brain: 'Brain'):
        self.brain = brain
        # Self-code paths
        self.core_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    async def self_upgrade(self, target_file: str, new_code: str, reasoning: str):
        """
        Attempts to overwrite its own source code with an improved version.
        """
        full_path = os.path.join(self.core_dir, target_file)
        
        # Security check (though owner-only, we log heavily)
        logger.warning(f"EVOLUTION: Self-upgrading {target_file}...")
        logger.info(f"Reasoning: {reasoning}")

        try:
            # Backup old version
            backup_path = f"{full_path}.bak"
            if os.path.exists(full_path):
                with open(full_path, 'r') as old:
                    with open(backup_path, 'w') as bak:
                        bak.write(old.read())

            # Write new code
            with open(full_path, 'w') as f:
                f.write(new_code)
            
            logger.info(f"EVOLUTION: {target_file} upgraded successfully.")
            return True
        except Exception as e:
            logger.error(f"EVOLUTION: Self-upgrade failed for {target_file}: {e}")
            return False

    async def analyze_self(self):
        """
        Agent looks at its own codebase to identify bottlenecks or improvements.
        """
        # Read a some core file as a test
        try:
            with open(os.path.join(self.core_dir, "core/brain.py"), 'r') as f:
                 code = f.read()
            
            # Use analysis engine on self
            analysis = await self.brain.analysis_engine.analyze(code, "python")
            return analysis
        except Exception as e:
            return f"Failed to analyze self: {e}"
