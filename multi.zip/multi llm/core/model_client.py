"""
NEXUS AGENT - Model Client
Handles asynchronous communication with Ollama instances running on VPS servers.
Includes retry logic, streaming support, and metrics tracking.
"""

import asyncio
import json
import time
import logging
from typing import AsyncGenerator, Dict, List, Optional, Any, Union
import aiohttp
from pydantic import BaseModel, Field

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("model_client")

class ModelMetrics(BaseModel):
    """Tracks performance metrics for a specific model client."""
    request_count: int = 0
    error_count: int = 0
    total_tokens: int = 0
    avg_response_time: float = 0.0
    last_request_time: float = 0.0

class ModelConfig(BaseModel):
    """Configuration for a specific model instance."""
    name: str
    role: str
    vps_url: str
    api_key: str
    model_id: str
    temperature: float = 0.2
    max_tokens: int = 4096
    timeout: int = 300
    context_window: int = 8192

class ModelClient:
    """ASync client for communicating with a single Ollama VPS."""

    def __init__(self, config: ModelConfig):
        self.config = config
        self.metrics = ModelMetrics()
        self.headers = {
            "Content-Type": "application/json",
            "X-API-Key": config.api_key
        }
        self._session: Optional[aiohttp.ClientSession] = None

    async def get_session(self) -> aiohttp.ClientSession:
        """Returns or creates an aiohttp session."""
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(headers=self.headers)
        return self._session

    async def close(self):
        """Closes the client session."""
        if self._session and not self._session.closed:
            await self._session.close()

    async def health_check(self) -> bool:
        """Verifies the VPS is reachable and the model is loaded."""
        try:
            session = await self.get_session()
            url = f"{self.config.vps_url}/api/tags"
            async with session.get(url, timeout=10) as response:
                if response.status == 200:
                    data = await response.json()
                    models = [m['name'] for m in data.get('models', [])]
                    is_loaded = self.config.model_id in models or any(self.config.model_id in name for name in models)
                    if not is_loaded:
                        logger.warning(f"Model {self.config.model_id} not found on {self.config.name}. Available: {models}")
                    return is_loaded
                else:
                    error_text = await response.text()
                    logger.error(f"Health check failed for {self.config.name}: Status {response.status}, Error: {error_text}")
            return False
        except Exception as e:
            logger.error(f"Health check failed for {self.config.name}: Connection Error: {str(e)}")
            return False

    async def generate(self, prompt: str, system_prompt: Optional[str] = None, stream: bool = False) -> Union[str, AsyncGenerator[str, None]]:
        """Sends a generation request to the model."""
        payload = {
            "model": self.config.model_id,
            "prompt": prompt,
            "stream": stream,
            "options": {
                "temperature": self.config.temperature,
                "num_predict": self.config.max_tokens,
                "num_ctx": self.config.context_window
            }
        }
        if system_prompt:
            payload["system"] = system_prompt

        return await self._execute_request("/api/generate", payload, stream)

    async def chat(self, messages: List[Dict[str, str]], stream: bool = False) -> Union[str, AsyncGenerator[str, None]]:
        """Sends a chat request to the model."""
        payload = {
            "model": self.config.model_id,
            "messages": messages,
            "stream": stream,
            "options": {
                "temperature": self.config.temperature,
                "num_predict": self.config.max_tokens,
                "num_ctx": self.config.context_window
            }
        }
        return await self._execute_request("/api/chat", payload, stream)

    async def _execute_request(self, endpoint: str, payload: Dict[str, Any], stream: bool) -> Union[str, AsyncGenerator[str, None]]:
        """Internal helper to handle the HTTP request with retries."""
        url = f"{self.config.vps_url}{endpoint}"
        retries = 3
        backoff = 2

        for attempt in range(retries):
            try:
                session = await self.get_session()
                start_time = time.time()
                
                async with session.post(url, json=payload, timeout=self.config.timeout) as response:
                    if response.status != 200:
                        error_text = await response.text()
                        raise Exception(f"Ollama API Error ({response.status}): {error_text}")

                    if stream:
                        return self._stream_response(response, start_time)
                    else:
                        data = await response.json()
                        result = data.get("response") or data.get("message", {}).get("content")
                        
                        # Update metrics
                        duration = time.time() - start_time
                        self.metrics.request_count += 1
                        self.metrics.last_request_time = start_time
                        self.metrics.avg_response_time = (self.metrics.avg_response_time * (self.metrics.request_count - 1) + duration) / self.metrics.request_count
                        
                        return result

            except Exception as e:
                logger.warning(f"Attempt {attempt + 1} failed for {self.config.name}: {e}")
                if attempt < retries - 1:
                    await asyncio.sleep(backoff ** attempt)
                else:
                    self.metrics.error_count += 1
                    raise e

    async def _stream_response(self, response: aiohttp.ClientResponse, start_time: float) -> AsyncGenerator[str, None]:
        """Generator for streaming responses."""
        full_response = ""
        async for line in response.content:
            if line:
                data = json.loads(line.decode("utf-8"))
                chunk = data.get("response") or data.get("message", {}).get("content", "")
                full_response += chunk
                
                if data.get("done"):
                    # Update metrics on completion
                    duration = time.time() - start_time
                    self.metrics.request_count += 1
                    self.metrics.avg_response_time = (self.metrics.avg_response_time * (self.metrics.request_count - 1) + duration) / self.metrics.request_count
                
                yield chunk

class ModelPool:
    """Manages multiple ModelClients for role-based routing."""
    
    def __init__(self, configs: Union[List[ModelConfig], Dict[str, Any]]):
        if isinstance(configs, dict):
            # Convert dictionary of model configs into ModelConfig objects
            processed_configs = []
            for key, val in configs.items():
                if isinstance(val, dict):
                    processed_configs.append(ModelConfig(**val))
                else:
                    processed_configs.append(val)
            configs = processed_configs

        self.clients: Dict[str, ModelClient] = {
            cfg.role: ModelClient(cfg) for cfg in configs
        }

    async def get_client(self, role: str) -> ModelClient:
        """Returns the client assigned to a specific role."""
        if role not in self.clients:
            raise ValueError(f"No model configured for role: {role}")
        return self.clients[role]

    async def check_all_health(self) -> Dict[str, bool]:
        """Checks health of all configured VPS nodes."""
        tasks = {role: client.health_check() for role, client in self.clients.items()}
        results = await asyncio.gather(*tasks.values())
        return dict(zip(tasks.keys(), results))

    async def close_all(self):
        """Closes all clients."""
        for client in self.clients.values():
            await client.close()
