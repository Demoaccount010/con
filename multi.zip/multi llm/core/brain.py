"""
NEXUS AGENT - Main Orchestrator
The central brain that coordinates all engines (Thinking, Planning, Analysis, Generation).
"""

import asyncio
import logging
from typing import Dict, Any, List, Optional
from core.model_client import ModelPool
from core.router import TaskRouter, TaskClassification, OrchestrationStrategy
from thinking.engine import ThinkingEngine
from planning.planner import PlanningEngine
from analysis.analyzer import AnalysisEngine
from generation.generator import GenerationEngine
from core.evolution import EvolutionEngine
from memory.context import ContextBuilder
from memory.store import MemoryStore
from tools.terminal import TerminalExecutor

logger = logging.getLogger("brain")

class Brain:
    """The central orchestrator for NEXUS AGENT."""

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.model_pool = ModelPool(config['models'])
        self.router = TaskRouter(config.get('routing', {}))
        
        # Engines initialized in initialize()
        self.thinking_engine: Optional[ThinkingEngine] = None
        self.planning_engine: Optional[PlanningEngine] = None
        self.analysis_engine: Optional[AnalysisEngine] = None
        self.generation_engine: Optional[GenerationEngine] = None
        self.evolution_engine: Optional[EvolutionEngine] = None
        
        # Tools
        self.context_builder: Optional[ContextBuilder] = None
        self.memory_store: Optional[MemoryStore] = None
        self.terminal: Optional[TerminalExecutor] = None

    async def initialize(self) -> Dict[str, bool]:
        """Initializes all models and engines."""
        health = await self.model_pool.check_all_health()
        
        # Initialize engines if not already done manually
        if not self.thinking_engine:
            self.thinking_engine = ThinkingEngine(self.model_pool, self.config)
        
        if not self.planning_engine:
            self.planning_engine = PlanningEngine(self.model_pool)

        if not self.analysis_engine:
            self.analysis_engine = AnalysisEngine(self.model_pool)

        if not self.generation_engine:
            self.generation_engine = GenerationEngine(self.model_pool, ".")

        if not self.evolution_engine:
            self.evolution_engine = EvolutionEngine(self)

        return health

    async def process_task(self, prompt: str, workspace_path: str) -> str:
        """
        The core orchestration workflow.
        1. Classify Task
        2. Build Context
        3. Think & Plan
        4. Analyze & Generate
        5. Evolve if requested
        """
        # 1. Routing
        classification = await self.router.classify(prompt)
        
        # 2. Context Building
        files = self.context_builder.get_project_files_content() if self.context_builder else {}
        history = self.memory_store.get_history() if self.memory_store else []
        context = await self.context_builder.build_context(prompt, history, files) if self.context_builder else ""

        # 3. Thinking
        thinking_result = await self.thinking_engine.think(prompt, context)
        
        # 4. Planning
        plan = await self.planning_engine.plan(thinking_result['refinement'])
        
        # 5. Execution (Generation)
        result = await self.generation_engine.generate(plan)
        
        # 6. Memory Update
        if self.memory_store:
            self.memory_store.add_message("user", prompt)
            self.memory_store.add_message("assistant", result)
            await self.memory_store.save()

        return result

    async def shutdown(self):
        """Graceful shutdown of all clients."""
        await self.model_pool.close_all()
