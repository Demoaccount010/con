"""
NEXUS AGENT - Task Router
Classifies user requests and determines the orchestration strategy.
"""

import json
from typing import Dict, List, Optional, Tuple
from enum import Enum
from pydantic import BaseModel

class TaskCategory(str, Enum):
    NEW_PROJECT = "NEW_PROJECT"
    ADD_FEATURE = "ADD_FEATURE"
    FIX_BUG = "FIX_BUG"
    REFACTOR = "REFACTOR"
    ANALYZE = "ANALYZE"
    EXPLAIN = "EXPLAIN"
    GENERAL = "GENERAL"

class Complexity(str, Enum):
    TRIVIAL = "TRIVIAL"
    SIMPLE = "SIMPLE"
    MEDIUM = "MEDIUM"
    COMPLEX = "COMPLEX"
    MASSIVE = "MASSIVE"

class ThinkingDepth(str, Enum):
    SHALLOW = "SHALLOW"
    MODERATE = "MODERATE"
    DEEP = "DEEP"

class OrchestrationStrategy(str, Enum):
    PIPELINE = "PIPELINE"   # Thinking -> Planning -> Analysis -> Generation
    PARALLEL = "PARALLEL"   # Direct generation (trivial tasks)
    DEBATE = "DEBATE"       # Multi-model consensus (complex architectural decisions)

class TaskClassification(BaseModel):
    category: TaskCategory
    complexity: Complexity
    thinking_depth: ThinkingDepth
    strategy: OrchestrationStrategy
    reasoning: str

class Router:
    """Intelligently routes tasks to engines and models."""

    def __init__(self):
        pass

    async def classify_task(self, user_prompt: str, context_summary: str, model_client: 'ModelClient') -> TaskClassification:
        """
        Uses the 'Thinker' model to classify the task.
        """
        system_prompt = """
        You are the TASK ROUTER for NEXUS AGENT. 
        Analyze the user prompt and context to classify the task.
        
        CATEGORIES:
        - NEW_PROJECT: Creating a new application or significant module from scratch.
        - ADD_FEATURE: Adding a specific feature to existing code.
        - FIX_BUG: Identifying and fixing a reported issue.
        - REFACTOR: Improving existing code structure without changing behavior.
        - ANALYZE: Deep codebase analysis, security scans, or quality reports.
        - EXPLAIN: Questions about how the code works or technical concepts.
        - GENERAL: Simple questions or non-coding tasks.

        STRATEGIES:
        - PIPELINE: Standard for most coding tasks.
        - PARALLEL: Use only for TRIVIAL/SIMPLE tasks with no dependencies.
        - DEBATE: Use for COMPLEX architectural decisions where consensus is needed.

        FORMAT YOUR RESPONSE AS JSON ONLY:
        {
            "category": "CATEGORY_NAME",
            "complexity": "COMPLEXITY_LEVEL",
            "thinking_depth": "DEPTH_LEVEL",
            "strategy": "STRATEGY_NAME",
            "reasoning": "Brief explanation of why"
        }
        """

        prompt = f"User Prompt: {user_prompt}\n\nContext Summary: {context_summary}"
        
        try:
            response = await model_client.generate(prompt, system_prompt=system_prompt)
            # Find JSON boundaries in case the model adds extra text
            start = response.find('{')
            end = response.rfind('}') + 1
            if start == -1 or end == 0:
                raise ValueError("Could not find JSON in router response")
            
            data = json.loads(response[start:end])
            return TaskClassification(**data)
        except Exception as e:
            # Fallback for classification failure
            return TaskClassification(
                category=TaskCategory.GENERAL,
                complexity=Complexity.MEDIUM,
                thinking_depth=ThinkingDepth.MODERATE,
                strategy=OrchestrationStrategy.PIPELINE,
                reasoning=f"Fallback due to router error: {e}"
            )
