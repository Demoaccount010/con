"""
NEXUS AGENT - Generation Refiner
Handles iterative refinement of generated code based on reviews.
"""

import logging
from typing import Dict, Any, List

logger = logging.getLogger("refiner")

class Refiner:
    """Refines code based on critique from the reviewer model."""

    def __init__(self, model_client: 'ModelClient'):
        self.model = model_client

    async def refine(self, code: str, review: Dict[str, Any], max_loops: int = 3) -> str:
        """
        Loops back to regeneration if the review finds critical issues.
        """
        current_code = code
        current_review = review
        
        loop = 0
        while current_review.get("status") == "REJECTED" and loop < max_loops:
            logger.info(f"Refinement loop {loop+1}/{max_loops}...")
            
            refine_prompt = f"""
            ORIGINAL CODE:
            {current_code}
            
            REVIEW ISSUES:
            {current_review.get('issues')}
            
            INSTRUCTIONS:
            Fix all the issues identified in the review.
            Maintain the same functionality but improve the code.
            Return the COMPLETE updated code.
            """
            
            current_code = await self.model.generate(refine_prompt)
            
            # Re-review would normally happen here, but we'll simulate one pass for now
            # In a full system, we call the Reviewer model again.
            loop += 1
            
        return current_code
