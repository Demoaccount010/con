"""
NEXUS AGENT - File Writer
Safe file extraction from LLM output and writing to workspace.
"""

import os
import re
import aiofiles
import logging
from typing import Dict, List, Optional

logger = logging.getLogger("writer")

class FileWriter:
    """Safe extraction and writing of code blocks."""

    def __init__(self, workspace_root: str):
        self.workspace_root = os.path.abspath(workspace_root)

    def extract_code_blocks(self, text: str) -> List[str]:
        """Extracts code between triple backticks."""
        pattern = r"```(?:[\w+-]+)?\n(.*?)\n```"
        matches = re.findall(pattern, text, re.DOTALL)
        return matches if matches else [text]

    async def write_file(self, relative_path: str, content: str) -> bool:
        """Writes content to a file within the workspace with safety checks."""
        # Safety: Check for path traversal
        abs_path = os.path.abspath(os.path.join(self.workspace_root, relative_path))
        if not abs_path.startswith(self.workspace_root):
            logger.error(f"BLOCKED: Path traversal attempt to {relative_path}")
            return False

        try:
            # Create directories if they don't exist
            os.makedirs(os.path.dirname(abs_path), exist_ok=True)
            
            async with aiofiles.open(abs_path, mode='w', encoding='utf-8') as f:
                await f.write(content)
            
            logger.info(f"Successfully wrote file: {relative_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to write file {relative_path}: {e}")
            return False

    async def write_project(self, files: Dict[str, str]):
        """Writes multiple files to the workspace."""
        for path, content in files.items():
            await self.write_file(path, content)
