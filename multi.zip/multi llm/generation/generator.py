"""
NEXUS AGENT - Generation Engine
Orchestrates the 7-phase code generation process.
"""

import logging
import json
from typing import Dict, Any, List
from generation.refiner import Refiner
from generation.writer import FileWriter
from prompts.generation import (
    SKELETON_PROMPT, IMPLEMENT_PROMPT, HARDEN_PROMPT,
    TEST_PROMPT, REVIEW_PROMPT
)

logger = logging.getLogger("generation_engine")

class GenerationEngine:
    """The 7-Phase Code Generation Processor."""

    def __init__(self, model_pool: 'ModelPool', workspace: str):
        self.pool = model_pool
        self.writer = FileWriter(workspace)
        self.refiner = None

    async def generate_file(self, file_path: str, description: str, context: str) -> str:
        """Runs the generation pipeline for a single file."""
        logger.info(f"Generating file: {file_path}...")
        
        coder = await self.pool.get_client("coder")
        reviewer = await self.pool.get_client("reviewer")
        
        if not self.refiner:
            self.refiner = Refiner(coder)

        # Phase 1: SKELETON
        logger.info(f"Phase 1: Skeleton for {file_path}")
        p1_input = SKELETON_PROMPT.format(file_path=file_path, description=description, context=context)
        skeleton_raw = await coder.generate(p1_input)
        skeleton = self.writer.extract_code_blocks(skeleton_raw)[0]

        # Phase 2: IMPLEMENT
        logger.info(f"Phase 2: Implementing {file_path}")
        p2_input = IMPLEMENT_PROMPT.format(skeleton=skeleton, details=description)
        impl_raw = await coder.generate(p2_input)
        implementation = self.writer.extract_code_blocks(impl_raw)[0]

        # Phase 3: HARDEN
        logger.info(f"Phase 3: Hardening {file_path}")
        p3_input = HARDEN_PROMPT.format(code=implementation)
        hardened_raw = await coder.generate(p3_input)
        hardened = self.writer.extract_code_blocks(hardened_raw)[0]

        # Phase 6: REVIEW
        logger.info(f"Phase 6: Reviewing {file_path}")
        p6_input = REVIEW_PROMPT.format(code=hardened)
        review_raw = await reviewer.generate(p6_input)
        
        try:
            start = review_raw.find('{')
            end = review_raw.rfind('}') + 1
            review = json.loads(review_raw[start:end])
        except:
            review = {"status": "APPROVED", "issues": []}

        # Phase 7: ITERATIVE REFINEMENT
        if review.get("status") == "REJECTED":
            final_code = await self.refiner.refine(hardened, review)
        else:
            final_code = hardened

        return final_code

    async def generate_project(self, plan: Dict[str, Any]):
        """Generates all files in a plan following the sequence."""
        build_order = plan.get("sequence", {}).get("build_order", [])
        
        generated_files = {}
        for step in build_order:
            path = step.get("file_path")
            desc = step.get("description")
            
            # Generate code
            code = await self.generate_file(path, desc, str(generated_files.keys()))
            generated_files[path] = code
            
            # Write immediately
            await self.writer.write_file(path, code)
            
        return generated_files
