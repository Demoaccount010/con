# NEXUS AGENT - Multi-LLM Orchestration System

NEXUS AGENT is a production-grade, distributed AI coding agent system that orchestrates three separate LLMs running on remote VPS servers to function as a unified, deep-thinking intelligence.

## 🚀 Architecture Overview

```text
┌─────────────────────────────────────────────────────────────┐
│ MY LAPTOP (NEXUS CLIENT)                                     │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ ORCHESTRATOR (brain.py)                                 │ │
│ │ - Thinking Engine (5-Layer Reasoning)                   │ │
│ │ - Planning Engine (5-Phase Tasking)                     │ │
│ │ - Analysis Engine (6-Scope code scanning)               │ │
│ │ - Generation Engine (7-Phase professional coding)       │ │
│ └───────┬──────────────┬──────────────┬───────────────────┘ │
└─────────┼──────────────┼──────────────┼─────────────────────┘
          │              │              │
    HTTP/REST (Ollama)   │        HTTP/REST (Ollama)
          │              │              │
┌─────────▼───┐  ┌───────▼─────┐  ┌─────▼─────────┐
│   VPS 1     │  │    VPS 2    │  │     VPS 3     │
│  DeepSeek   │  │  Qwen 2.5   │  │    Mistral    │
│   (CODER)   │  │  (THINKER)  │  │  (REVIEWER)   │
└─────────────┘  └─────────────┘  └───────────────┘
```

## 🛠 Prerequisites

- **Local Machine:** Python 3.11+, Internet access.
- **VPS Servers:** 3 separate instances (recommended 8GB+ RAM each) running Ubuntu/Linux.
- **Models:** Ollama installed on each VPS.

## 📥 Setup Instructions

### 1. VPS Setup (Run on each server)
Upload `vps/setup_vps.sh` to your VPS and run:

**VPS 1 (Coder):**
```bash
bash setup_vps.sh deepseek-coder:6.7b
```

**VPS 2 (Thinker):**
```bash
bash setup_vps.sh qwen2.5:7b
```

**VPS 3 (Reviewer):**
```bash
bash setup_vps.sh mistral:7b
```
*Note the IP address and API Key printed at the end of each script.*

### 2. Local Setup
Clone this repository and run the setup script:
```bash
bash setup.sh
```

### 3. Configuration
Edit `config.yaml` and replace the following with your VPS details:
- `vps_url`: The URL (e.g., `http://1.2.3.4:8080`)
- `api_key`: The generated hex key from the VPS setup process.

## 🎮 Usage

Activate your environment and start the agent:
```bash
source .venv/bin/activate
python main.py -w /path/to/your/coding/project
```

### Example Commands
- `Build a FastAPI todo application with SQLite and JWT auth`
- `Analyze my codebase and find all SQL injection vulnerabilities`
- `Refactor the authentication logic to use a professional service pattern`

### Slash Commands
- `/help`: Show available commands.
- `/tree`: Visualize project file structure.
- `/status`: Check LLM node connectivity.
- `/run <cmd>`: Securely execute terminal commands.
- `/clear`: Clear terminal.
- `/quit`: Exit NEXUS AGENT.

## 🧠 How it Works

1.  **Thinking Engine (5-Layer):** Uses Qwen and Mistral to Understand, Expand, Challenge, Refine, and Validate your request before a single line of code is written.
2.  **Planning Engine (5-Phase):** Decomposes the task, designs the architecture (MVC/Clean), assesses risks, and creates a build sequence.
3.  **Analysis Engine (6-Scope):** Scans existing code for patterns, security vulnerabilities, and quality metrics.
4.  **Generation Engine (7-Phase):** DeepSeek generates code in phases (Skeleton -> Implementation -> Hardening) with a final review from Mistral.

## 🛡 Security & Safety

- **Sandboxed Terminal:** Commands are restricted by a configurable whitelist.
- **Path Protection:** File operations are restricted to the specified workspace folder.
- **API Security:** All VPS communication is proxied via Nginx with X-API-Key validation.

## ❓ FAQ

**Q: Can I run this with less than 3 models?**
A: Yes, you can point multiple roles to the same VPS URL in `config.yaml`, but performance may degrade.

**Q: How do I open port 11434?**
A: The `setup_vps.sh` handles this via UFW, but you may also need to open it in your VPS provider's control panel.

**Q: What languages does it support?**
A: Python, JS, TS, Go, C++, Java, HTML/CSS, and more.
