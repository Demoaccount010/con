"""
NEXUS AGENT - Architect
Designs folder structures and system interfaces.
"""

import json
import logging
from typing import Dict, Any, List, TYPE_CHECKING

if TYPE_CHECKING:
    from core.model_client import ModelClient

logger = logging.getLogger("architect")

class Architect:
    """Handles system architecture design."""

    def __init__(self, model_client: 'ModelClient'):
        self.model = model_client

    async def design(self, decomposition: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Generates the architecture design based on decomposed tasks.
        """
        from prompts.planning import ARCHITECT_PROMPT
        
        prompt = ARCHITECT_PROMPT.format(decomposition=json.dumps(decomposition))
        response = await self.model.generate(prompt)
        
        try:
            start = response.find('{')
            end = response.rfind('}') + 1
            return json.loads(response[start:end])
        except Exception as e:
            logger.error(f"Architecture design parsing failed: {e}")
            return {
                "pattern": {"name": "Flat", "reason": "Parsing failed"},
                "folder_structure": ["."],
                "interfaces": [],
                "data_models": [],
                "external_dependencies": []
            }
