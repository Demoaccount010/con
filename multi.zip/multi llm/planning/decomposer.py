"""
NEXUS AGENT - Decomposer
Breaks high-level tasks into granular, actionable sub-tasks.
"""

import json
import logging
from typing import Dict, Any, List

logger = logging.getLogger("decomposer")

class Decomposer:
    """Handles hierarchical task decomposition."""

    def __init__(self, model_client: 'ModelClient'):
        self.model = model_client

    async def decompose(self, refined_reqs: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Calls the LLM to break requirements into tasks.
        """
        from prompts.planning import DECOMPOSE_PROMPT
        
        prompt = DECOMPOSE_PROMPT.format(refined_reqs=json.dumps(refined_reqs))
        response = await self.model.generate(prompt)
        
        try:
            start = response.find('{')
            end = response.rfind('}') + 1
            data = json.loads(response[start:end])
            return data.get("hierarchy", [])
        except Exception as e:
            logger.error(f"Decomposition parsing failed: {e}")
            return []

    def flatten_tasks(self, hierarchy: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Flattens the component-based hierarchy into a linear task list."""
        flat_list = []
        for component in hierarchy:
            for task in component.get("tasks", []):
                # Add component name to task context
                task["component"] = component["component"]
                flat_list.append(task)
        return flat_list
