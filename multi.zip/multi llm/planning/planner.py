"""
NEXUS AGENT - Planning Engine
Orchestrates the 5-phase hierarchical planning process.
"""

import logging
import json
from typing import Dict, Any, List
from planning.decomposer import Decomposer
from planning.architect import Architect
from prompts.planning import RISK_PROMPT, SEQUENCE_PROMPT

logger = logging.getLogger("planning_engine")

class PlanningEngine:
    """The 5-Phase Planning Processor."""

    def __init__(self, model_pool: 'ModelPool'):
        self.pool = model_pool
        self.decomposer = None
        self.architect = None

    async def plan(self, refined_reqs: Dict[str, Any]) -> Dict[str, Any]:
        """Runs the full 5nd-phase planning pipeline."""
        logger.info("Starting 5-Phase Planning process...")
        
        thinker = await self.pool.get_client("thinker")
        reviewer = await self.pool.get_client("reviewer")
        
        # Init internal modules if needed
        if not self.decomposer:
            self.decomposer = Decomposer(thinker)
        if not self.architect:
            self.architect = Architect(thinker)

        # Phase 1: DECOMPOSE
        logger.info("Phase 1: Decomposing task...")
        hierarchy = await self.decomposer.decompose(refined_reqs)
        tasks = self.decomposer.flatten_tasks(hierarchy)

        # Phase 2: DEPENDENCY MAP (Implicit in Sequence but could be expanded)

        # Phase 3: ARCHITECT
        logger.info("Phase 3: Designing architecture...")
        architecture = await self.architect.design(hierarchy)

        # Phase 4: RISK ASSESSMENT (Mistral)
        logger.info("Phase 4: Assessing risks...")
        risk_input = RISK_PROMPT.format(architecture=json.dumps(architecture))
        risks = await self._call_json(reviewer, risk_input)

        # Phase 5: SEQUENCE
        logger.info("Phase 5: Sequencing build...")
        seq_input = SEQUENCE_PROMPT.format(tasks=json.dumps(tasks), risks=json.dumps(risks))
        sequence = await self._call_json(thinker, seq_input)

        return {
            "hierarchy": hierarchy,
            "tasks": tasks,
            "architecture": architecture,
            "risks": risks,
            "sequence": sequence
        }

    async def _call_json(self, client: 'ModelClient', prompt: str) -> Dict[str, Any]:
        """Helper to get JSON output from models."""
        response = await client.generate(prompt)
        try:
            start = response.find('{')
            end = response.rfind('}') + 1
            return json.loads(response[start:end])
        except Exception as e:
            logger.error(f"JSON Parsing failed for planning phase: {e}")
            return {"error": "Invalid JSON response", "raw": response}
