# Memory Module Initialization
