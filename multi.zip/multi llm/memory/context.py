"""
NEXUS AGENT - Context Builder
Constructs token-aware context for model prompts.
"""

import os
import tiktoken
import logging
from typing import List, Dict, Any, Optional

logger = logging.getLogger("context")

class ContextBuilder:
    """Intelligently manages the model's context window."""

    def __init__(self, workspace_root: str, budget_tokens: int = 3500):
        self.workspace_root = workspace_root
        self.budget_tokens = budget_tokens
        # Using cl100k_base for token approximation (compatible with many models)
        try:
            self.encoder = tiktoken.get_encoding("cl100k_base")
        except:
            self.encoder = None

    def count_tokens(self, text: str) -> int:
        """Approximates token count."""
        if self.encoder:
            return len(self.encoder.encode(text))
        return len(text) // 4 # Rough fallback

    async def build_context(self, prompt: str, history: List[Dict[str, str]], files: Dict[str, str]) -> str:
        """
        Assembles a context string that fits within the token budget.
        Priority: Prompt > History > Relevant Files > Project Tree
        """
        context_parts = []
        current_tokens = self.count_tokens(prompt)

        # 1. Add Recent History (last 5 messages)
        history_text = "\n".join([f"{m['role']}: {m['content']}" for m in history[-5:]])
        history_tokens = self.count_tokens(history_text)
        
        if current_tokens + history_tokens < self.budget_tokens:
            context_parts.append(f"### RECENT HISTORY:\n{history_text}")
            current_tokens += history_tokens

        # 2. Add File Tree
        tree = self._get_file_tree()
        tree_text = f"### PROJECT STRUCTURE:\n{tree}"
        tree_tokens = self.count_tokens(tree_text)
        
        if current_tokens + tree_tokens < self.budget_tokens:
            context_parts.append(tree_text)
            current_tokens += tree_tokens

        # 3. Add Important Files
        for path, content in files.items():
            file_header = f"\n### FILE: {path}\n"
            file_text = file_header + content
            file_tokens = self.count_tokens(file_text)

            if current_tokens + file_tokens < self.budget_tokens:
                context_parts.append(file_text)
                current_tokens += file_tokens
            else:
                # Truncate if it's the first file but too large, otherwise skip
                if current_tokens < self.budget_tokens * 0.8:
                    truncated = content[: (self.budget_tokens - current_tokens) * 2]
                    context_parts.append(f"{file_header}{truncated}...\n[TRUNCATED]")
                break

        return "\n\n".join(context_parts)

    def _get_file_tree(self) -> str:
        """Generates a simple text-based file tree."""
        tree = []
        for root, dirs, files in os.walk(self.workspace_root):
            # Skip hidden dirs
            dirs[:] = [d for d in dirs if not d.startswith('.')]
            level = root.replace(self.workspace_root, '').count(os.sep)
            indent = ' ' * 4 * level
            tree.append('{}{}/'.format(indent, os.path.basename(root)))
            subindent = ' ' * 4 * (level + 1)
            for f in files:
                if not f.startswith('.'):
                    tree.append('{}{}'.format(subindent, f))
        return "\n".join(tree)
