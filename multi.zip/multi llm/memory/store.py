"""
NEXUS AGENT - Memory Store
Handles persistent storage of conversation history and project decisions.
"""

import os
import json
import logging
import aiofiles
from typing import Dict, Any, List, Optional
from datetime import datetime

logger = logging.getLogger("memory_store")

class MemoryStore:
    """Manages persistent JSON-based memory for NEXUS AGENT."""

    def __init__(self, memory_file: str):
        self.memory_file = memory_file
        self.data: Dict[str, Any] = {
            "project_name": "Nexus Project",
            "created_at": datetime.now().isoformat(),
            "conversation_history": [],
            "decisions": {},
            "analysis_cache": {}
        }

    async def load(self):
        """Loads memory from disk."""
        if os.path.exists(self.memory_file):
            try:
                async with aiofiles.open(self.memory_file, mode='r') as f:
                    content = await f.read()
                    self.data = json.loads(content)
                logger.info("Project memory loaded successfully.")
            except Exception as e:
                logger.error(f"Failed to load memory: {e}")
        
        # Ensure base structure
        if "owner_profile" not in self.data:
            self.data["owner_profile"] = {}
        if "conversation_history" not in self.data:
            self.data["conversation_history"] = []

    async def save(self):
        """Saves memory to disk."""
        try:
            os.makedirs(os.path.dirname(self.memory_file), exist_ok=True)
            async with aiofiles.open(self.memory_file, mode='w') as f:
                await f.write(json.dumps(self.data, indent=2))
        except Exception as e:
            logger.error(f"Failed to save memory: {e}")

    def add_message(self, role: str, content: str):
        """Adds a message to history."""
        self.data["conversation_history"].append({
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat()
        })
        # Limit history size (Keep it deep for evolution)
        if len(self.data["conversation_history"]) > 100:
            self.data["conversation_history"] = self.data["conversation_history"][-100:]

    def get_history(self) -> List[Dict[str, str]]:
        """Returns messages as a list of dicts for LLM consumption."""
        return [{"role": m["role"], "content": m["content"]} for m in self.data["conversation_history"]]

    def record_decision(self, feature: str, decision: str):
        """Saves an architectural or technical decision."""
        self.data["decisions"][feature] = {
            "decision": decision,
            "timestamp": datetime.now().isoformat()
        }
