"""
NEXUS AGENT - Security Scanner
Scans code for vulnerabilities using LLM-based reasoning.
"""

import json
import logging
from typing import Dict, Any, List

logger = logging.getLogger("security")

class SecurityScanner:
    """Performs security audits on code snippets."""

    def __init__(self, model_client: 'ModelClient'):
        self.model = model_client

    async def scan_file(self, file_path: str, content: str) -> List[Dict[str, Any]]:
        """
        Scans a single file for vulnerabilities.
        """
        from prompts.analysis import SECURITY_PROMPT
        
        prompt = SECURITY_PROMPT.format(code=f"### FILE: {file_path}\n{content}")
        response = await self.model.generate(prompt)
        
        try:
            start = response.find('{')
            end = response.rfind('}') + 1
            data = json.loads(response[start:end])
            return data.get("vulnerabilities", [])
        except Exception as e:
            logger.error(f"Security scan parsing failed for {file_path}: {e}")
            return []
