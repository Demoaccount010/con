"""
NEXUS AGENT - Analysis Engine
Orchestrates the 6-scope deep analysis process.
"""

import logging
import json
from typing import Dict, Any, List
from analysis.patterns import PatternAnalyzer
from analysis.security import SecurityScanner
from prompts.analysis import CODEMAP_PROMPT, QUALITY_PROMPT

logger = logging.getLogger("analysis_engine")

class AnalysisEngine:
    """The 6-Scope Analysis Processor."""

    def __init__(self, model_pool: 'ModelPool'):
        self.pool = model_pool
        self.pattern_analyzer = None
        self.security_scanner = None

    async def analyze(self, files: Dict[str, str]) -> Dict[str, Any]:
        """Runs the full analysis pipeline on a set of files."""
        logger.info("Starting Deep Analysis process...")
        
        thinker = await self.pool.get_client("thinker")
        reviewer = await self.pool.get_client("reviewer")
        
        if not self.pattern_analyzer:
            self.pattern_analyzer = PatternAnalyzer(thinker)
        if not self.security_scanner:
            self.security_scanner = SecurityScanner(reviewer)

        # Scope 1: CODE MAP
        logger.info("Scope 1: Mapping codebase...")
        map_input = CODEMAP_PROMPT.format(files=list(files.keys()))
        code_map = await self._call_json(thinker, map_input)

        # Scope 2/3: FLOW & PATTERNS
        logger.info("Scope 3: Detecting patterns...")
        pattern_results = []
        for path, content in files.items():
            res = await self.pattern_analyzer.analyze_file(path, content)
            pattern_results.append({"file": path, "results": res})

        # Scope 4: SECURITY SCAN
        logger.info("Scope 4: Performing security scan...")
        security_results = []
        for path, content in files.items():
            res = await self.security_scanner.scan_file(path, content)
            security_results.extend(res)

        # Scope 6: QUALITY SCORING
        logger.info("Scope 6: Final quality scoring...")
        quality_input = QUALITY_PROMPT.format(analyses=json.dumps({
            "patterns": pattern_results,
            "security": security_results
        }))
        quality_report = await self._call_json(reviewer, quality_input)

        return {
            "code_map": code_map,
            "patterns": pattern_results,
            "security": security_results,
            "quality": quality_report
        }

    async def _call_json(self, client: 'ModelClient', prompt: str) -> Dict[str, Any]:
        """Helper to get JSON output from models."""
        response = await client.generate(prompt)
        try:
            start = response.find('{')
            end = response.rfind('}') + 1
            return json.loads(response[start:end])
        except Exception as e:
            logger.error(f"JSON Parsing failed for analysis scope: {e}")
            return {"error": "Invalid JSON response", "raw": response}
