"""
NEXUS AGENT - Pattern Detection
Identifies architectural patterns and common coding mistakes.
"""

import json
import logging
from typing import Dict, Any, List

logger = logging.getLogger("patterns")

class PatternAnalyzer:
    """Detects patterns and anti-patterns in code snippets."""

    def __init__(self, model_client: 'ModelClient'):
        self.model = model_client

    async def analyze_file(self, file_path: str, content: str) -> Dict[str, Any]:
        """
        Runs pattern detection on a single file.
        """
        from prompts.analysis import PATTERN_PROMPT
        
        prompt = PATTERN_PROMPT.format(code=f"### FILE: {file_path}\n{content}")
        response = await self.model.generate(prompt)
        
        try:
            start = response.find('{')
            end = response.rfind('}') + 1
            return json.loads(response[start:end])
        except Exception as e:
            logger.error(f"Pattern analysis parsing failed for {file_path}: {e}")
            return {"patterns_found": [], "anti_patterns": [], "quality_score": 5}
