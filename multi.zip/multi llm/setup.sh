#!/bin/bash

# =================================================================
# NEXUS AGENT - LOCAL SETUP SCRIPT
# Role: Sets up the Python environment and dependencies locally.
# =================================================================

echo "--- Starting Local Setup for NEXUS AGENT ---"

# 1. CLEANUP (Optional)
if [ -d ".venv" ]; then
    echo "Found existing virtual environment. Removing it for a fresh setup..."
    rm -rf .venv
fi

# 2. CHECK PYTHON VERSION
PYTHON_VERSION=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
REQUIRED_VERSION="3.11"

if [ "$(printf '%s\n' "$REQUIRED_VERSION" "$PYTHON_VERSION" | sort -V | head -n1)" != "$REQUIRED_VERSION" ]; then
    echo "Error: Python $REQUIRED_VERSION+ is required. Found Python $PYTHON_VERSION."
    exit 1
fi
echo "[1/4] Python version $PYTHON_VERSION confirmed."

# 2. CREATE VIRTUAL ENVIRONMENT
if [ ! -d ".venv" ]; then
    echo "[2/4] Creating virtual environment..."
    python3 -m venv .venv
else
    echo "[2/4] Virtual environment already exists."
fi

# 3. INSTALL DEPENDENCIES
echo "[3/4] Installing dependencies from requirements.txt..."
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

# 4. INITIALIZE CONFIG
if [ ! -f "config.yaml" ]; then
    echo "[4/4] Creating config.yaml from example..."
    cp config.yaml.example config.yaml
    echo "IMPORTANT: Please edit config.yaml with your VPS details before running."
else
    echo "[4/4] config.yaml already exists."
fi

echo "---------------------------------------------------------"
echo "SETUP COMPLETE!"
echo "---------------------------------------------------------"
echo "To start NEXUS AGENT:"
echo "1. Activate environment: source .venv/bin/activate"
echo "2. Run: python main.py -w /your/workspace/path"
echo "---------------------------------------------------------"
