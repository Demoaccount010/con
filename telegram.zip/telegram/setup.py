"""
Interactive Setup Wizard
========================
First-run setup for Telegram bot configuration.

Collects:
- Bot token from user
- Admin user ID
- Optional whitelist
- Other settings

Saves to config file for future runs.
"""

import os
import sys
import re
import asyncio
from typing import Optional, List, Tuple
from datetime import datetime

from main_agent.storage.config_store import (
    ConfigStore,
    BotSettings,
    config_exists,
    load_config,
    save_config,
    get_config_path,
)
from main_agent.utils.logger import Logger, get_logger


class Colors:
    """ANSI color codes for terminal output."""
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    END = '\033[0m'
    
    @classmethod
    def disable(cls):
        """Disable colors (for non-TTY)."""
        cls.HEADER = ''
        cls.BLUE = ''
        cls.CYAN = ''
        cls.GREEN = ''
        cls.YELLOW = ''
        cls.RED = ''
        cls.BOLD = ''
        cls.UNDERLINE = ''
        cls.END = ''


# Disable colors if not TTY
if not sys.stdout.isatty():
    Colors.disable()


def print_banner():
    """Print setup wizard banner."""
    banner = f"""
{Colors.CYAN}{Colors.BOLD}
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║           🤖 MAIN AI AGENT - SETUP WIZARD 🤖                 ║
║                                                              ║
║              First-time Configuration                        ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
{Colors.END}
"""
    print(banner)


def print_step(step: int, total: int, title: str):
    """Print step header."""
    print(f"\n{Colors.BLUE}{'─' * 60}{Colors.END}")
    print(f"{Colors.BOLD}Step {step}/{total}: {title}{Colors.END}")
    print(f"{Colors.BLUE}{'─' * 60}{Colors.END}\n")


def print_success(message: str):
    """Print success message."""
    print(f"{Colors.GREEN}✓ {message}{Colors.END}")


def print_error(message: str):
    """Print error message."""
    print(f"{Colors.RED}✗ {message}{Colors.END}")


def print_warning(message: str):
    """Print warning message."""
    print(f"{Colors.YELLOW}⚠ {message}{Colors.END}")


def print_info(message: str):
    """Print info message."""
    print(f"{Colors.CYAN}ℹ {message}{Colors.END}")


def get_input(prompt: str, default: str = "", required: bool = True) -> str:
    """
    Get user input with optional default.
    
    Args:
        prompt: Input prompt
        default: Default value
        required: If True, keep asking until valid input
        
    Returns:
        User input or default
    """
    default_text = f" [{default}]" if default else ""
    full_prompt = f"{Colors.YELLOW}→{Colors.END} {prompt}{default_text}: "
    
    while True:
        try:
            value = input(full_prompt).strip()
            
            if not value and default:
                return default
            
            if not value and required:
                print_error("This field is required. Please enter a value.")
                continue
            
            return value
            
        except EOFError:
            if default:
                return default
            if not required:
                return ""
            continue
        except KeyboardInterrupt:
            print("\n")
            raise


def get_yes_no(prompt: str, default: bool = True) -> bool:
    """
    Get yes/no input.
    
    Args:
        prompt: Question prompt
        default: Default value
        
    Returns:
        True for yes, False for no
    """
    default_text = "Y/n" if default else "y/N"
    full_prompt = f"{Colors.YELLOW}→{Colors.END} {prompt} [{default_text}]: "
    
    while True:
        try:
            value = input(full_prompt).strip().lower()
            
            if not value:
                return default
            
            if value in ("y", "yes", "да", "1", "true"):
                return True
            elif value in ("n", "no", "нет", "0", "false"):
                return False
            else:
                print_error("Please enter 'y' for yes or 'n' for no.")
                
        except (EOFError, KeyboardInterrupt):
            print("\n")
            return default


def get_int_input(prompt: str, default: int, min_val: int = 0, max_val: int = 999999) -> int:
    """
    Get integer input with validation.
    
    Args:
        prompt: Input prompt
        default: Default value
        min_val: Minimum allowed value
        max_val: Maximum allowed value
        
    Returns:
        Integer value
    """
    full_prompt = f"{Colors.YELLOW}→{Colors.END} {prompt} [{default}]: "
    
    while True:
        try:
            value = input(full_prompt).strip()
            
            if not value:
                return default
            
            int_value = int(value)
            
            if int_value < min_val or int_value > max_val:
                print_error(f"Please enter a number between {min_val} and {max_val}.")
                continue
            
            return int_value
            
        except ValueError:
            print_error("Please enter a valid number.")
        except (EOFError, KeyboardInterrupt):
            print("\n")
            return default


def get_list_input(prompt: str, example: str = "") -> List[int]:
    """
    Get list of integers (comma-separated).
    
    Args:
        prompt: Input prompt
        example: Example format
        
    Returns:
        List of integers
    """
    if example:
        print_info(f"Example: {example}")
    
    full_prompt = f"{Colors.YELLOW}→{Colors.END} {prompt}: "
    
    while True:
        try:
            value = input(full_prompt).strip()
            
            if not value:
                return []
            
            # Parse comma-separated values
            ids = []
            for part in value.split(","):
                part = part.strip()
                if part:
                    try:
                        ids.append(int(part))
                    except ValueError:
                        print_error(f"Invalid number: {part}")
                        break
            else:
                return ids
                
        except (EOFError, KeyboardInterrupt):
            print("\n")
            return []


def validate_bot_token(token: str) -> Tuple[bool, str]:
    """
    Validate Telegram bot token format.
    
    Args:
        token: Bot token to validate
        
    Returns:
        Tuple of (is_valid, error_message)
    """
    if not token:
        return False, "Token cannot be empty"
    
    # Token format: 123456789:ABCdefGHIjklMNOpqrsTUVwxyz
    pattern = r'^\d{8,10}:[A-Za-z0-9_-]{35}$'
    
    if not re.match(pattern, token):
        return False, "Invalid token format. Token should be like: 123456789:ABCdefGHIjklMNOpqrsTUVwxyz"
    
    return True, ""


async def verify_bot_token(token: str) -> Tuple[bool, str, str]:
    """
    Verify bot token with Telegram API.
    
    Args:
        token: Bot token
        
    Returns:
        Tuple of (is_valid, bot_username, error_message)
    """
    try:
        from telegram import Bot
        
        bot = Bot(token=token)
        me = await bot.get_me()
        
        return True, me.username, ""
        
    except Exception as e:
        return False, "", str(e)


def get_user_telegram_id_instructions():
    """Print instructions to get Telegram user ID."""
    print(f"""
{Colors.CYAN}How to get your Telegram User ID:{Colors.END}

{Colors.BOLD}Method 1 (Easiest):{Colors.END}
  1. Open Telegram
  2. Search for @userinfobot
  3. Start the bot
  4. It will show your User ID

{Colors.BOLD}Method 2:{Colors.END}
  1. Open Telegram
  2. Search for @RawDataBot
  3. Start the bot
  4. Send any message
  5. Find "id" in the response

{Colors.BOLD}Method 3:{Colors.END}
  1. Open https://web.telegram.org
  2. Click on your profile
  3. Look at the URL - the number is your ID
""")


class SetupWizard:
    """
    Interactive Setup Wizard
    ========================
    
    Guides user through first-time configuration.
    
    Usage:
        wizard = SetupWizard()
        settings = wizard.run()
        
        if settings:
            # Settings saved successfully
            start_bot(settings)
    """
    
    TOTAL_STEPS = 5
    
    def __init__(self, logger: Optional[Logger] = None):
        """Initialize setup wizard."""
        self._logger = logger or get_logger("SetupWizard")
        self.settings = BotSettings()
    
    def run(self) -> Optional[BotSettings]:
        """
        Run the setup wizard.
        
        Returns:
            BotSettings if setup complete, None if cancelled
        """
        try:
            print_banner()
            
            # Check if config already exists
            if config_exists():
                existing = load_config()
                if existing and existing.setup_complete:
                    print_info(f"Existing configuration found at: {get_config_path()}")
                    
                    if not get_yes_no("Do you want to reconfigure?", default=False):
                        print_success("Using existing configuration.")
                        return existing
                    
                    print_warning("Starting fresh configuration...\n")
            
            # Step 1: Bot Token
            self._step_bot_token()
            
            # Step 2: Admin Setup
            self._step_admin_setup()
            
            # Step 3: Access Control
            self._step_access_control()
            
            # Step 4: Ollama Settings
            self._step_ollama_settings()
            
            # Step 5: Confirm & Save
            if not self._step_confirm_save():
                print_warning("Setup cancelled.")
                return None
            
            return self.settings
            
        except KeyboardInterrupt:
            print(f"\n\n{Colors.YELLOW}Setup cancelled by user.{Colors.END}")
            return None
        except Exception as e:
            print_error(f"Setup error: {e}")
            self._logger.exception("Setup wizard error")
            return None
    
    def _step_bot_token(self):
        """Step 1: Get and verify bot token."""
        print_step(1, self.TOTAL_STEPS, "Telegram Bot Token")
        
        print(f"""
{Colors.CYAN}To create a Telegram bot:{Colors.END}

  1. Open Telegram and search for @BotFather
  2. Send /newbot command
  3. Follow the instructions to create your bot
  4. Copy the API token that BotFather gives you

""")
        
        while True:
            token = get_input("Enter your bot token", required=True)
            
            # Validate format
            is_valid, error = validate_bot_token(token)
            if not is_valid:
                print_error(error)
                continue
            
            # Verify with Telegram
            print_info("Verifying token with Telegram...")
            
            try:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                is_valid, username, error = loop.run_until_complete(
                    verify_bot_token(token)
                )
                loop.close()
                
                if is_valid:
                    print_success(f"Token verified! Bot username: @{username}")
                    self.settings.bot_token = token
                    self.settings.bot_username = username
                    break
                else:
                    print_error(f"Token verification failed: {error}")
                    if not get_yes_no("Try again?", default=True):
                        raise KeyboardInterrupt()
                        
            except ImportError:
                print_warning("Cannot verify token (python-telegram-bot not installed)")
                print_info("Token format looks valid, proceeding...")
                self.settings.bot_token = token
                break
    
    def _step_admin_setup(self):
        """Step 2: Setup admin user."""
        print_step(2, self.TOTAL_STEPS, "Admin Setup")
        
        get_user_telegram_id_instructions()
        
        while True:
            admin_id_str = get_input(
                "Enter your Telegram User ID (admin)",
                required=True
            )
            
            try:
                admin_id = int(admin_id_str)
                
                if admin_id <= 0:
                    print_error("User ID must be a positive number.")
                    continue
                
                self.settings.admin_ids = [admin_id]
                self.settings.whitelist_ids = [admin_id]  # Admin is auto-whitelisted
                print_success(f"Admin ID set: {admin_id}")
                break
                
            except ValueError:
                print_error("Please enter a valid number.")
    
    def _step_access_control(self):
        """Step 3: Configure access control."""
        print_step(3, self.TOTAL_STEPS, "Access Control")
        
        print(f"""
{Colors.CYAN}Access Control Modes:{Colors.END}

  1. {Colors.BOLD}ADMIN_ONLY{Colors.END}  - Only you (admin) can use the bot
  2. {Colors.BOLD}WHITELIST{Colors.END}   - Only approved users can use (recommended)
  3. {Colors.BOLD}OPEN{Colors.END}        - Anyone can use the bot (not recommended)

""")
        
        while True:
            mode = get_input(
                "Select mode (1/2/3)",
                default="2",
                required=True
            )
            
            if mode == "1":
                self.settings.auth_mode = "ADMIN_ONLY"
                print_success("Mode set: ADMIN_ONLY")
                break
            elif mode == "2":
                self.settings.auth_mode = "WHITELIST"
                print_success("Mode set: WHITELIST")
                
                # Ask for additional users
                if get_yes_no("Add other users to whitelist now?", default=False):
                    print_info("Enter user IDs separated by commas")
                    additional = get_list_input(
                        "Additional user IDs",
                        example="123456789, 987654321"
                    )
                    
                    for uid in additional:
                        if uid not in self.settings.whitelist_ids:
                            self.settings.whitelist_ids.append(uid)
                    
                    print_success(f"Whitelist updated: {len(self.settings.whitelist_ids)} users")
                break
            elif mode == "3":
                self.settings.auth_mode = "OPEN"
                print_warning("Mode set: OPEN - Anyone can use your bot!")
                
                if not get_yes_no("Are you sure?", default=False):
                    continue
                break
            else:
                print_error("Please enter 1, 2, or 3")
    
    def _step_ollama_settings(self):
        """Step 4: Ollama configuration."""
        print_step(4, self.TOTAL_STEPS, "Ollama Settings")
        
        print(f"""
{Colors.CYAN}Ollama is used for AI/LLM capabilities.{Colors.END}

Default settings work for local Ollama installation.
Only change if Ollama is running on a different host/port.

""")
        
        if get_yes_no("Use default Ollama settings? (127.0.0.1:11434)", default=True):
            self.settings.ollama_host = "127.0.0.1"
            self.settings.ollama_port = 11434
            print_success("Using default Ollama settings")
        else:
            self.settings.ollama_host = get_input(
                "Ollama host",
                default="127.0.0.1"
            )
            self.settings.ollama_port = get_int_input(
                "Ollama port",
                default=11434,
                min_val=1,
                max_val=65535
            )
            print_success(f"Ollama: {self.settings.ollama_host}:{self.settings.ollama_port}")
    
    def _step_confirm_save(self) -> bool:
        """Step 5: Confirm and save configuration."""
        print_step(5, self.TOTAL_STEPS, "Confirm & Save")
        
        # Show summary
        print(f"""
{Colors.CYAN}Configuration Summary:{Colors.END}

  {Colors.BOLD}Telegram Bot:{Colors.END}
    • Username: @{self.settings.bot_username or 'unknown'}
    • Token: {self.settings.bot_token[:20]}...
  
  {Colors.BOLD}Access Control:{Colors.END}
    • Mode: {self.settings.auth_mode}
    • Admins: {self.settings.admin_ids}
    • Whitelist: {len(self.settings.whitelist_ids)} users
  
  {Colors.BOLD}Ollama:{Colors.END}
    • Host: {self.settings.ollama_host}:{self.settings.ollama_port}
  
  {Colors.BOLD}Config File:{Colors.END}
    • {get_config_path()}

""")
        
        if not get_yes_no("Save this configuration?", default=True):
            return False
        
        # Mark setup as complete
        self.settings.setup_complete = True
        self.settings.created_at = datetime.now().isoformat()
        
        # Save configuration
        if save_config(self.settings):
            print_success(f"Configuration saved to: {get_config_path()}")
            print(f"""
{Colors.GREEN}{Colors.BOLD}
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║              ✅ SETUP COMPLETE!                              ║
║                                                              ║
║  Your bot is now configured and ready to run.                ║
║                                                              ║
║  The bot will start automatically...                         ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
{Colors.END}
""")
            return True
        else:
            print_error("Failed to save configuration!")
            return False


def run_setup() -> Optional[BotSettings]:
    """
    Run the setup wizard.
    
    Convenience function for running setup.
    
    Returns:
        BotSettings if successful, None if cancelled
    """
    wizard = SetupWizard()
    return wizard.run()


def ensure_setup() -> BotSettings:
    """
    Ensure bot is configured.
    
    Runs setup if needed, loads existing config otherwise.
    
    Returns:
        BotSettings (runs setup if needed)
        
    Raises:
        SystemExit: If setup fails or is cancelled
    """
    # Check for existing config
    if config_exists():
        settings = load_config()
        if settings and settings.setup_complete:
            is_valid, error = settings.is_valid()
            if is_valid:
                return settings
            else:
                print_warning(f"Existing config invalid: {error}")
                print_info("Running setup wizard...\n")
    
    # Run setup
    settings = run_setup()
    
    if not settings:
        print_error("Setup is required to run the bot.")
        sys.exit(1)
    
    return settings