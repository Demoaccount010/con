"""
Telegram Integration Module
===========================
Telegram bot for interacting with the Main AI Agent.

Features:
- Command handling (/start, /task, /status, etc.)
- Task creation via messages
- Real-time status updates
- Worker management
- Task history

Usage:
    from main_agent.telegram import TelegramBot
    
    bot = TelegramBot(agent=agent, token="YOUR_BOT_TOKEN")
    bot.run()
"""

from main_agent.telegram.bot import TelegramBot, BotConfig
from main_agent.telegram.commands import CommandHandler
from main_agent.telegram.handlers import MessageHandler
from main_agent.telegram.keyboards import KeyboardBuilder
from main_agent.telegram.middleware import AuthMiddleware, RateLimiter

__all__ = [
    "TelegramBot",
    "BotConfig",
    "CommandHandler",
    "MessageHandler",
    "KeyboardBuilder",
    "AuthMiddleware",
    "RateLimiter",
]