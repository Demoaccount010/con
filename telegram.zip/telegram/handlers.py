"""
Telegram Message Handlers
=========================
Handles non-command messages and callbacks.
"""

import re
import json
from typing import Optional, Dict, Any
from datetime import datetime

from telegram import Update, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from telegram.constants import ParseMode, ChatAction

from main_agent.utils.logger import Logger, get_logger
from main_agent.telegram.keyboards import KeyboardBuilder


class MessageHandler:
    """
    Handles regular messages (non-commands).
    
    Processes:
    - Task descriptions from users
    - Replies to bot questions
    - State-based conversations
    """
    
    def __init__(
        self,
        agent: Any,  # MainAgent
        auth_middleware: Any,  # AuthMiddleware
        logger: Optional[Logger] = None,
    ):
        """
        Initialize message handler.
        
        Args:
            agent: MainAgent instance
            auth_middleware: Auth middleware for user states
            logger: Optional logger
        """
        self.agent = agent
        self.auth = auth_middleware
        self._logger = logger or get_logger("MessageHandler")
    
    async def handle_message(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ) -> None:
        """Handle incoming text messages."""
        if not update.message or not update.message.text:
            return
        
        user = update.effective_user
        text = update.message.text.strip()
        
        self._logger.debug(f"Message from {user.id}: {text[:50]}...")
        
        # Get user state
        state, state_data = self.auth.get_user_state(user.id)
        
        # Handle based on state
        if state == "waiting_task":
            await self._handle_task_input(update, context, text)
        elif state == "waiting_confirmation":
            await self._handle_confirmation(update, context, text, state_data)
        else:
            # Default: treat as new task
            await self._handle_new_task(update, context, text)
    
    async def _handle_new_task(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
        text: str,
    ) -> None:
        """Handle new task input."""
        # Check for quick commands via text
        text_lower = text.lower()
        
        if text_lower in ["📝 new task", "new task"]:
            await update.message.reply_text(
                "📝 *New Task*\n\n"
                "Please describe what you want me to do.\n\n"
                "Examples:\n"
                "• _Download images from a website_\n"
                "• _Create a Python script that..._\n"
                "• _Analyze this CSV file_",
                parse_mode=ParseMode.MARKDOWN,
            )
            self.auth.set_user_state(update.effective_user.id, "waiting_task")
            return
        
        if text_lower in ["📊 status", "status"]:
            await self._send_status(update, context)
            return
        
        if text_lower in ["👷 workers", "workers"]:
            await self._send_workers(update, context)
            return
        
        if text_lower in ["📜 history", "history"]:
            await self._send_history(update, context)
            return
        
        if text_lower in ["❓ help", "help"]:
            await self._send_help(update, context)
            return
        
        # Treat as task description
        await self._process_task(update, context, text)
    
    async def _handle_task_input(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
        text: str,
    ) -> None:
        """Handle task input when in waiting_task state."""
        self.auth.clear_user_state(update.effective_user.id)
        await self._process_task(update, context, text)
    
    async def _process_task(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
        task_description: str,
    ) -> None:
        """Process a task description and create a plan."""
        user = update.effective_user
        
        # Send typing indicator
        await context.bot.send_chat_action(
            chat_id=update.effective_chat.id,
            action=ChatAction.TYPING,
        )
        
        # Show planning message
        planning_msg = await update.message.reply_text(
            "🔄 *Planning your task...*\n\n"
            "Please wait while I analyze your request.",
            parse_mode=ParseMode.MARKDOWN,
        )
        
        try:
            # Check if agent is ready
            if not self.agent.is_ready:
                await planning_msg.edit_text(
                    "❌ *Agent Not Ready*\n\n"
                    "The agent is not ready. Please try again later.",
                    parse_mode=ParseMode.MARKDOWN,
                )
                return
            
            # Create plan
            task = self.agent.plan_task(task_description)
            
            # Format response
            response = self._format_task_response(task)
            
            # Generate task ID for actions
            task_id = task.plan_id
            
            # Store task in context for later use
            if "tasks" not in context.user_data:
                context.user_data["tasks"] = {}
            context.user_data["tasks"][task_id] = task.to_full_dict()
            
            # Send response with action buttons
            await planning_msg.edit_text(
                response,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=KeyboardBuilder.task_actions(task_id),
            )
            
            self._logger.info(f"Task planned for user {user.id}: {task.goal[:50]}")
            
        except Exception as e:
            self._logger.error(f"Task planning failed: {e}")
            await planning_msg.edit_text(
                f"❌ *Planning Failed*\n\n"
                f"Error: {str(e)}\n\n"
                f"Please try rephrasing your request.",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=KeyboardBuilder.back_button(),
            )
    
    def _format_task_response(self, task: Any) -> str:
        """Format task plan as Telegram message."""
        # Task type emoji
        type_emoji = {
            "QUESTION": "❓",
            "FILE_OPERATION": "📁",
            "CODE_GENERATION": "💻",
            "SYSTEM_COMMAND": "⚙️",
            "WEB_TASK": "🌐",
            "DATA_ANALYSIS": "📊",
            "CONVERSATION": "💬",
        }.get(task.task_type.value, "📝")
        
        # Confidence bar
        conf_percent = int(task.confidence * 100)
        conf_filled = int(task.confidence * 10)
        conf_bar = "█" * conf_filled + "░" * (10 - conf_filled)
        
        # Format steps
        steps_text = ""
        for i, step in enumerate(task.steps[:5], 1):  # Max 5 steps shown
            steps_text += f"  {i}. `{step.name}`\n"
        
        if len(task.steps) > 5:
            steps_text += f"  _... and {len(task.steps) - 5} more steps_\n"
        
        # Format requirements
        reqs = task.requirements.to_dict()
        active_reqs = [k for k, v in reqs.items() if v]
        reqs_text = ", ".join(active_reqs) if active_reqs else "None"
        
        response = f"""
✅ *Task Plan Created*

{type_emoji} *Goal:* {task.goal}

📂 *Type:* `{task.task_type.value}`
📊 *Confidence:* `{conf_bar}` {conf_percent}%

📋 *Steps:*
{steps_text}
🔧 *Requirements:* {reqs_text}
⚠️ *On Error:* {task.on_error}

─────────────────────
_What would you like to do?_
"""
        return response
    
    async def _handle_confirmation(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
        text: str,
        state_data: Dict[str, Any],
    ) -> None:
        """Handle confirmation responses."""
        text_lower = text.lower()
        
        if text_lower in ["yes", "y", "да", "confirm", "ok"]:
            action = state_data.get("pending_action")
            if action == "execute_task":
                task_id = state_data.get("task_id")
                await self._execute_task(update, context, task_id)
        else:
            await update.message.reply_text(
                "❌ Action cancelled.",
                reply_markup=KeyboardBuilder.main_menu(),
            )
        
        self.auth.clear_user_state(update.effective_user.id)
    
    async def _send_status(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ) -> None:
        """Send agent status."""
        try:
            status = self.agent.get_status()
            
            agent_info = status.get("agent", {})
            system_info = status.get("system", {})
            ollama_info = status.get("components", {}).get("ollama", {})
            planner_info = status.get("components", {}).get("planner", {})
            
            # System RAM
            mem = system_info.get("memory", {}) if system_info else {}
            ram_text = f"{mem.get('available_gb', 0):.1f}GB / {mem.get('total_gb', 0):.1f}GB"
            
            response = f"""
📊 *Agent Status*

🤖 *Agent:*
  • Name: `{agent_info.get('name', 'Unknown')}`
  • Version: `{agent_info.get('version', '?')}`
  • State: `{agent_info.get('state', 'Unknown')}`
  • Ready: {'✅' if agent_info.get('is_ready') else '❌'}

💻 *System:*
  • OS: `{system_info.get('os', {}).get('type', 'Unknown') if system_info else 'Unknown'}`
  • CPU: `{system_info.get('cpu', {}).get('cores', '?') if system_info else '?'} cores`
  • RAM: `{ram_text}`

🦙 *Ollama:*
  • Status: {'✅ Healthy' if ollama_info and ollama_info.get('healthy') else '❌ Unhealthy'}
  • Model: `{ollama_info.get('model', 'None') if ollama_info else 'None'}`

🧠 *Planner:*
  • Ready: {'✅' if planner_info and planner_info.get('ready') else '❌'}
  • LLM: {'✅ Enabled' if planner_info and planner_info.get('llm_available') else '❌ Disabled'}
"""
            await update.message.reply_text(
                response,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=KeyboardBuilder.back_button(),
            )
            
        except Exception as e:
            await update.message.reply_text(
                f"❌ Error getting status: {str(e)}",
                reply_markup=KeyboardBuilder.back_button(),
            )
    
    async def _send_workers(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ) -> None:
        """Send workers list."""
        # TODO: Get actual workers from registry
        await update.message.reply_text(
            "👷 *Workers*\n\n"
            "_No workers connected yet._\n\n"
            "Workers will appear here when VPS agents connect.",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=KeyboardBuilder.back_button(),
        )
    
    async def _send_history(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ) -> None:
        """Send task history."""
        tasks = context.user_data.get("tasks", {})
        
        if not tasks:
            await update.message.reply_text(
                "📜 *Task History*\n\n"
                "_No tasks yet._\n\n"
                "Your completed tasks will appear here.",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=KeyboardBuilder.back_button(),
            )
            return
        
        # Format recent tasks
        response = "📜 *Task History*\n\n"
        
        for i, (task_id, task) in enumerate(list(tasks.items())[-5:], 1):
            goal = task.get("goal", "Unknown")[:40]
            status = task.get("status", "PENDING")
            created = task.get("created_at", "")[:10]
            
            status_emoji = "✅" if status == "COMPLETED" else "⏳" if status == "PENDING" else "❌"
            response += f"{i}. {status_emoji} {goal}...\n   _Created: {created}_\n\n"
        
        await update.message.reply_text(
            response,
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=KeyboardBuilder.back_button(),
        )
    
    async def _send_help(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ) -> None:
        """Send help message."""
        help_text = """
❓ *Help & Commands*

*Basic Commands:*
• `/start` - Start the bot
• `/help` - Show this help
• `/status` - Agent status
• `/task <description>` - Create a task
• `/workers` - List connected workers
• `/history` - Task history

*How to Create Tasks:*
Just send me a description of what you want to do!

Examples:
• _"Download all images from example.com"_
• _"Create a Python script that..."_
• _"Analyze the data in file.csv"_

*Task Types:*
🌐 Web Tasks - Scraping, downloads
📁 File Tasks - Create, read, modify files
💻 Code Tasks - Generate, execute code
⚙️ System Tasks - Run commands

*Tips:*
• Be specific in your task description
• Check status before creating tasks
• Use /cancel to stop current operation
"""
        await update.message.reply_text(
            help_text,
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=KeyboardBuilder.main_menu(),
        )
    
    async def _execute_task(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
        task_id: str,
    ) -> None:
        """Execute a planned task."""
        # TODO: Implement actual task execution via workers
        await update.message.reply_text(
            "⚙️ *Executing Task...*\n\n"
            "_Task execution via workers coming soon!_",
            parse_mode=ParseMode.MARKDOWN,
        )


class CallbackHandler:
    """
    Handles inline keyboard callbacks.
    """
    
    def __init__(
        self,
        agent: Any,
        auth_middleware: Any,
        message_handler: MessageHandler,
        logger: Optional[Logger] = None,
    ):
        """
        Initialize callback handler.
        
        Args:
            agent: MainAgent instance
            auth_middleware: Auth middleware
            message_handler: Message handler for reusing methods
            logger: Optional logger
        """
        self.agent = agent
        self.auth = auth_middleware
        self.message_handler = message_handler
        self._logger = logger or get_logger("CallbackHandler")
    
    async def handle_callback(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ) -> None:
        """Handle callback query from inline keyboard."""
        query = update.callback_query
        await query.answer()  # Acknowledge callback
        
        data = query.data
        user = update.effective_user
        
        self._logger.debug(f"Callback from {user.id}: {data}")
        
        # Parse callback data
        parts = data.split("_", 2)
        action = parts[0]
        
        # Route to appropriate handler
        if data == "menu_main":
            await self._show_main_menu(query)
        
        elif data == "menu_new_task":
            await self._prompt_new_task(query)
        
        elif data == "menu_status":
            await self._show_status(query, context)
        
        elif data == "menu_workers":
            await self._show_workers(query, context)
        
        elif data == "menu_history":
            await self._show_history(query, context)
        
        elif data == "menu_settings":
            await self._show_settings(query)
        
        elif data == "menu_help":
            await self._show_help(query)
        
        elif data.startswith("task_execute_"):
            task_id = data.replace("task_execute_", "")
            await self._execute_task(query, context, task_id)
        
        elif data.startswith("task_details_"):
            task_id = data.replace("task_details_", "")
            await self._show_task_details(query, context, task_id)
        
        elif data.startswith("task_cancel_"):
            task_id = data.replace("task_cancel_", "")
            await self._cancel_task(query, context, task_id)
        
        elif data == "workers_refresh":
            await self._show_workers(query, context)
        
        else:
            await query.edit_message_text(
                "⚠️ Unknown action. Please try again.",
                reply_markup=KeyboardBuilder.back_button(),
            )
    
    async def _show_main_menu(self, query) -> None:
        """Show main menu."""
        await query.edit_message_text(
            "🤖 *Main AI Agent*\n\n"
            "What would you like to do?",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=KeyboardBuilder.main_menu(),
        )
    
    async def _prompt_new_task(self, query) -> None:
        """Prompt for new task."""
        user_id = query.from_user.id
        self.auth.set_user_state(user_id, "waiting_task")
        
        await query.edit_message_text(
            "📝 *New Task*\n\n"
            "Please send me a description of what you want to do.\n\n"
            "Examples:\n"
            "• _Download images from a website_\n"
            "• _Create a Python script that..._\n"
            "• _Analyze this CSV file_",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=KeyboardBuilder.back_button(),
        )
    
    async def _show_status(self, query, context) -> None:
        """Show agent status."""
        try:
            status = self.agent.get_status()
            
            agent_info = status.get("agent", {})
            system_info = status.get("system", {})
            ollama_info = status.get("components", {}).get("ollama", {})
            
            mem = system_info.get("memory", {}) if system_info else {}
            ram_text = f"{mem.get('available_gb', 0):.1f}GB / {mem.get('total_gb', 0):.1f}GB"
            
            response = f"""
📊 *Agent Status*

🤖 *Agent:* `{agent_info.get('state', 'Unknown')}`
💻 *RAM:* `{ram_text}`
🦙 *Model:* `{ollama_info.get('model', 'None') if ollama_info else 'None'}`

_Updated: {datetime.now().strftime('%H:%M:%S')}_
"""
            await query.edit_message_text(
                response,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=KeyboardBuilder.back_button(),
            )
        except Exception as e:
            await query.edit_message_text(
                f"❌ Error: {str(e)}",
                reply_markup=KeyboardBuilder.back_button(),
            )
    
    async def _show_workers(self, query, context) -> None:
        """Show workers list."""
        # TODO: Get actual workers
        await query.edit_message_text(
            "👷 *Workers*\n\n"
            "_No workers connected._",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=KeyboardBuilder.back_button(),
        )
    
    async def _show_history(self, query, context) -> None:
        """Show task history."""
        tasks = context.user_data.get("tasks", {})
        
        if not tasks:
            await query.edit_message_text(
                "📜 *Task History*\n\n_No tasks yet._",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=KeyboardBuilder.back_button(),
            )
            return
        
        response = "📜 *Recent Tasks*\n\n"
        for task_id, task in list(tasks.items())[-5:]:
            goal = task.get("goal", "Unknown")[:30]
            response += f"• {goal}...\n"
        
        await query.edit_message_text(
            response,
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=KeyboardBuilder.back_button(),
        )
    
    async def _show_settings(self, query) -> None:
        """Show settings menu."""
        await query.edit_message_text(
            "⚙️ *Settings*\n\n"
            "Configure your preferences:",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=KeyboardBuilder.settings_menu(),
        )
    
    async def _show_help(self, query) -> None:
        """Show help."""
        await query.edit_message_text(
            "❓ *Help*\n\n"
            "Send me a task description and I'll plan it for you!\n\n"
            "Commands:\n"
            "• /start - Start bot\n"
            "• /task - New task\n"
            "• /status - Agent status\n"
            "• /help - This help",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=KeyboardBuilder.back_button(),
        )
    
    async def _execute_task(self, query, context, task_id: str) -> None:
        """Execute a task."""
        tasks = context.user_data.get("tasks", {})
        task = tasks.get(task_id)
        
        if not task:
            await query.edit_message_text(
                "❌ Task not found.",
                reply_markup=KeyboardBuilder.back_button(),
            )
            return
        
        await query.edit_message_text(
            f"⚙️ *Executing Task*\n\n"
            f"Goal: _{task.get('goal', 'Unknown')}_\n\n"
            f"_Execution via workers coming soon!_",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=KeyboardBuilder.back_button(),
        )
    
    async def _show_task_details(self, query, context, task_id: str) -> None:
        """Show task details."""
        tasks = context.user_data.get("tasks", {})
        task = tasks.get(task_id)
        
        if not task:
            await query.edit_message_text(
                "❌ Task not found.",
                reply_markup=KeyboardBuilder.back_button(),
            )
            return
        
        # Format JSON
        json_str = json.dumps(task, indent=2, ensure_ascii=False)
        if len(json_str) > 3000:
            json_str = json_str[:3000] + "\n..."
        
        await query.edit_message_text(
            f"📋 *Task Details*\n\n```json\n{json_str}\n```",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=KeyboardBuilder.back_button(),
        )
    
    async def _cancel_task(self, query, context, task_id: str) -> None:
        """Cancel a task."""
        tasks = context.user_data.get("tasks", {})
        
        if task_id in tasks:
            del tasks[task_id]
            await query.edit_message_text(
                "✅ Task cancelled.",
                reply_markup=KeyboardBuilder.back_button(),
            )
        else:
            await query.edit_message_text(
                "❌ Task not found.",
                reply_markup=KeyboardBuilder.back_button(),
            )