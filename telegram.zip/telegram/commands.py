"""
Telegram Command Handlers
=========================
Handles /commands from users.
"""

from typing import Optional, List
from datetime import datetime

from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode

from main_agent.utils.logger import Logger, get_logger
from main_agent.telegram.keyboards import KeyboardBuilder
from main_agent.telegram.middleware import require_auth, require_admin, rate_limit


class CommandHandler:
    """
    Handles all bot commands.
    
    Commands:
    - /start - Welcome and main menu
    - /help - Help information
    - /task - Create new task
    - /status - Agent status
    - /workers - List workers
    - /history - Task history
    - /cancel - Cancel current operation
    - /settings - Bot settings (admin)
    - /admin - Admin commands
    """
    
    def __init__(
        self,
        agent: any,  # MainAgent
        auth_middleware: any,
        rate_limiter: any,
        logger: Optional[Logger] = None,
    ):
        """
        Initialize command handler.
        
        Args:
            agent: MainAgent instance
            auth_middleware: Auth middleware
            rate_limiter: Rate limiter
            logger: Optional logger
        """
        self.agent = agent
        self.auth = auth_middleware
        self.rate_limiter = rate_limiter
        self._logger = logger or get_logger("CommandHandler")
    
    @require_auth
    @rate_limit
    async def start_command(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ) -> None:
        """Handle /start command."""
        user = update.effective_user
        
        # Record session
        self.auth.get_session(user.id, user.username)
        
        welcome_text = f"""
🤖 *Welcome to Main AI Agent!*

Hello, {user.first_name}! 👋

I'm your intelligent task planning assistant. I can help you:

• 📝 Plan and execute complex tasks
• 🌐 Automate web operations
• 📁 Manage files across systems
• 💻 Generate and run code
• 🔗 Coordinate multiple VPS workers

*Quick Start:*
Just send me a description of what you want to do!

Or use the menu below to get started.
"""
        await update.message.reply_text(
            welcome_text,
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=KeyboardBuilder.main_menu(),
        )
        
        self._logger.info(f"User {user.id} ({user.username}) started the bot")
    
    @require_auth
    @rate_limit
    async def help_command(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ) -> None:
        """Handle /help command."""
        help_text = """
❓ *Help & Commands*

*📋 Basic Commands:*
• `/start` - Start bot & show menu
• `/help` - Show this help message
• `/task <text>` - Create a new task
• `/status` - Check agent status
• `/workers` - List connected workers
• `/history` - View task history
• `/cancel` - Cancel current operation

*💡 How to Use:*
1️⃣ Send a task description
2️⃣ Review the generated plan
3️⃣ Execute or modify as needed

*📝 Task Examples:*
• _"Download all images from example.com"_
• _"Create a Python web scraper"_
• _"Monitor server CPU usage"_
• _"Backup database to cloud"_

*🔧 Task Types:*
🌐 Web - Scraping, downloads, API calls
📁 File - Create, read, modify, delete
💻 Code - Generate, execute, debug
⚙️ System - Commands, processes, services

*⚡ Tips:*
• Be specific in task descriptions
• Check agent status before large tasks
• Use workers for distributed operations
"""
        await update.message.reply_text(
            help_text,
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=KeyboardBuilder.main_menu(),
        )
    
    @require_auth
    @rate_limit
    async def task_command(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ) -> None:
        """Handle /task command."""
        user = update.effective_user
        
        # Check if task description provided
        if context.args:
            task_description = " ".join(context.args)
            
            # Plan the task
            await self._plan_task(update, context, task_description)
        else:
            # Prompt for task
            self.auth.set_user_state(user.id, "waiting_task")
            
            await update.message.reply_text(
                "📝 *New Task*\n\n"
                "Please describe what you want me to do.\n\n"
                "Send your task description now:",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=KeyboardBuilder.back_button(),
            )
    
    async def _plan_task(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
        description: str,
    ) -> None:
        """Plan a task and show results."""
        from telegram.constants import ChatAction
        
        # Show typing
        await context.bot.send_chat_action(
            chat_id=update.effective_chat.id,
            action=ChatAction.TYPING,
        )
        
        planning_msg = await update.message.reply_text(
            "🔄 *Planning task...*",
            parse_mode=ParseMode.MARKDOWN,
        )
        
        try:
            if not self.agent.is_ready:
                await planning_msg.edit_text(
                    "❌ *Agent Not Ready*\n\nPlease try again later.",
                    parse_mode=ParseMode.MARKDOWN,
                )
                return
            
            # Create plan
            task = self.agent.plan_task(description)
            
            # Format response
            type_emoji = {
                "QUESTION": "❓",
                "FILE_OPERATION": "📁",
                "CODE_GENERATION": "💻",
                "SYSTEM_COMMAND": "⚙️",
                "WEB_TASK": "🌐",
                "DATA_ANALYSIS": "📊",
            }.get(task.task_type.value, "📝")
            
            steps_text = "\n".join(
                f"  {i}. `{s.name}`" 
                for i, s in enumerate(task.steps[:5], 1)
            )
            
            response = f"""
✅ *Task Planned!*

{type_emoji} *Goal:* {task.goal}

📊 *Confidence:* {int(task.confidence * 100)}%
📂 *Type:* `{task.task_type.value}`

📋 *Steps:*
{steps_text}

_Select an action below:_
"""
            # Store task
            if "tasks" not in context.user_data:
                context.user_data["tasks"] = {}
            context.user_data["tasks"][task.plan_id] = task.to_full_dict()
            
            await planning_msg.edit_text(
                response,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=KeyboardBuilder.task_actions(task.plan_id),
            )
            
        except Exception as e:
            self._logger.error(f"Task planning error: {e}")
            await planning_msg.edit_text(
                f"❌ *Error:* {str(e)}",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=KeyboardBuilder.back_button(),
            )
    
    @require_auth
    async def status_command(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ) -> None:
        """Handle /status command."""
        try:
            status = self.agent.get_status()
            
            agent = status.get("agent", {})
            system = status.get("system", {})
            ollama = status.get("components", {}).get("ollama", {})
            planner = status.get("components", {}).get("planner", {})
            
            mem = system.get("memory", {}) if system else {}
            
            response = f"""
📊 *System Status*

🤖 *Agent:*
  State: `{agent.get('state', '?')}`
  Ready: {'✅' if agent.get('is_ready') else '❌'}
  Version: `{agent.get('version', '?')}`

💻 *System:*
  OS: `{system.get('os', {}).get('type', '?') if system else '?'}`
  CPU: `{system.get('cpu', {}).get('cores', '?') if system else '?'} cores`
  RAM: `{mem.get('available_gb', 0):.1f}GB free`
  Usage: `{mem.get('usage_percent', 0):.1f}%`

🦙 *Ollama:*
  Status: {'✅ Online' if ollama and ollama.get('healthy') else '❌ Offline'}
  Model: `{ollama.get('model', 'N/A') if ollama else 'N/A'}`
  Safety: `{ollama.get('model_safety', 'N/A') if ollama else 'N/A'}`

🧠 *Planner:*
  Ready: {'✅' if planner and planner.get('ready') else '❌'}
  LLM: {'✅' if planner and planner.get('llm_available') else '❌'}
  Plans: `{planner.get('statistics', {}).get('plans_created', 0) if planner else 0}`

⏰ _Updated: {datetime.now().strftime('%H:%M:%S')}_
"""
            await update.message.reply_text(
                response,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=KeyboardBuilder.back_button(),
            )
            
        except Exception as e:
            await update.message.reply_text(
                f"❌ Error getting status: {str(e)}",
            )
    
    @require_auth
    async def workers_command(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ) -> None:
        """Handle /workers command."""
        # TODO: Get actual workers from registry
        response = """
👷 *Connected Workers*

_No workers connected yet._

Workers will appear here when VPS agents register with the main agent.

*How to add workers:*
1. Deploy worker agent on VPS
2. Configure main agent URL
3. Worker auto-registers on startup

Use /help for more information.
"""
        await update.message.reply_text(
            response,
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=KeyboardBuilder.back_button(),
        )
    
    @require_auth
    async def history_command(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ) -> None:
        """Handle /history command."""
        tasks = context.user_data.get("tasks", {})
        
        if not tasks:
            await update.message.reply_text(
                "📜 *Task History*\n\n"
                "_No tasks yet._\n\n"
                "Create a task with /task or by sending a description.",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=KeyboardBuilder.back_button(),
            )
            return
        
        response = "📜 *Task History*\n\n"
        
        for i, (task_id, task) in enumerate(list(tasks.items())[-10:], 1):
            goal = task.get("goal", "Unknown")[:35]
            status = task.get("status", "PENDING")
            created = task.get("created_at", "")[:16]
            
            emoji = "✅" if status == "COMPLETED" else "⏳" if status in ("PENDING", "READY") else "❌"
            response += f"{i}. {emoji} {goal}...\n   `{created}`\n\n"
        
        await update.message.reply_text(
            response,
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=KeyboardBuilder.history_navigation(1, 1),
        )
    
    @require_auth
    async def cancel_command(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ) -> None:
        """Handle /cancel command."""
        user = update.effective_user
        
        # Clear user state
        self.auth.clear_user_state(user.id)
        
        await update.message.reply_text(
            "✅ *Operation Cancelled*\n\n"
            "All pending operations have been cancelled.\n"
            "You can start fresh with /start or /task.",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=KeyboardBuilder.main_menu(),
        )
    
    @require_admin
    async def admin_command(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ) -> None:
        """Handle /admin command."""
        admin_text = """
🔐 *Admin Panel*

*Commands:*
• `/admin stats` - Bot statistics
• `/admin users` - List users
• `/admin add <user_id>` - Add to whitelist
• `/admin remove <user_id>` - Remove from whitelist
• `/admin broadcast <msg>` - Send to all users

*Current Settings:*
• Auth Mode: `{mode}`
• Admins: `{admins}`
• Whitelisted: `{whitelist}`
""".format(
            mode=self.auth.mode,
            admins=len(self.auth.admin_ids),
            whitelist=len(self.auth.whitelist_ids),
        )
        
        if context.args:
            subcommand = context.args[0].lower()
            
            if subcommand == "stats":
                sessions = self.auth.get_all_sessions()
                active = self.auth.get_active_users(30)
                
                admin_text = f"""
📊 *Bot Statistics*

👥 Total Users: `{len(sessions)}`
🟢 Active (30m): `{len(active)}`
📝 Total Tasks: `{sum(s.message_count for s in sessions.values())}`

⏰ _As of {datetime.now().strftime('%H:%M:%S')}_
"""
            
            elif subcommand == "add" and len(context.args) > 1:
                try:
                    user_id = int(context.args[1])
                    self.auth.add_to_whitelist(user_id)
                    admin_text = f"✅ User `{user_id}` added to whitelist."
                except ValueError:
                    admin_text = "❌ Invalid user ID."
            
            elif subcommand == "remove" and len(context.args) > 1:
                try:
                    user_id = int(context.args[1])
                    self.auth.remove_from_whitelist(user_id)
                    admin_text = f"✅ User `{user_id}` removed from whitelist."
                except ValueError:
                    admin_text = "❌ Invalid user ID."
        
        await update.message.reply_text(
            admin_text,
            parse_mode=ParseMode.MARKDOWN,
        )
    
    async def unknown_command(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ) -> None:
        """Handle unknown commands."""
        await update.message.reply_text(
            "❓ Unknown command.\n\n"
            "Use /help to see available commands.",
            reply_markup=KeyboardBuilder.main_menu(),
        )