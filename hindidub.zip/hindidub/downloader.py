"""
YouTube Video Downloader Module
Hindi Dubbing Bot - Telegram Integrated
Uses yt-dlp for downloading videos from YouTube
"""

import os
import asyncio
import subprocess
from pathlib import Path
from typing import Optional, Dict, Any, Callable, Tuple
from dataclasses import dataclass
from datetime import datetime
import json
import re

try:
    import yt_dlp
except ImportError:
    raise ImportError("yt-dlp not installed. Run: pip install yt-dlp")

from config import config, QualityPreset, ProcessingStage
from utils import (
    logger,
    session_manager,
    format_file_size,
    format_duration,
    safe_filename,
    get_user_workspace,
    is_youtube_url,
    extract_video_id,
    sanitize_url,
    retry_async,
    log_execution_time,
    handle_errors,
    AsyncProgressTracker,
)


@dataclass
class VideoInfo:
    """Video information container"""
    video_id: str
    title: str
    duration: int  # seconds
    description: str
    thumbnail_url: str
    channel: str
    channel_id: str
    upload_date: str
    view_count: int
    like_count: int
    formats: list
    requested_format: str
    filesize_approx: int
    resolution: str
    fps: int
    ext: str
    url: str
    
    def to_dict(self) -> Dict:
        return {
            "video_id": self.video_id,
            "title": self.title,
            "duration": self.duration,
            "description": self.description,
            "thumbnail_url": self.thumbnail_url,
            "channel": self.channel,
            "upload_date": self.upload_date,
            "view_count": self.view_count,
            "filesize_approx": self.filesize_approx,
            "resolution": self.resolution,
        }
    
    def get_summary(self) -> str:
        """Get human-readable summary"""
        return (
            f"📹 *{self.title}*\n"
            f"👤 Channel: {self.channel}\n"
            f"⏱ Duration: {format_duration(self.duration)}\n"
            f"📊 Resolution: {self.resolution}\n"
            f"💾 Size: ~{format_file_size(self.filesize_approx)}"
        )


class YouTubeDownloader:
    """
    YouTube video downloader using yt-dlp
    Handles video downloading with progress tracking
    """
    
    def __init__(self, user_id: int, quality: QualityPreset = QualityPreset.HIGH):
        self.user_id = user_id
        self.quality = quality
        self.workspace = get_user_workspace(user_id)
        self.download_dir = self.workspace["downloads"]
        self.current_download: Optional[str] = None
        self.progress_callback: Optional[Callable] = None
        self.video_info: Optional[VideoInfo] = None
        
        # Progress tracking
        self.progress_tracker: Optional[AsyncProgressTracker] = None
        self._last_progress = 0
        
        logger.info(f"YouTubeDownloader initialized for user {user_id}")
    
    def _get_ydl_options(self, output_path: Path) -> Dict[str, Any]:
        """Get yt-dlp options based on quality setting"""
        
        # Get format based on quality
        format_string = config.ytdlp.get_format_for_quality(self.quality)
        
        options = {
            'format': format_string,
            'outtmpl': str(output_path / '%(title)s.%(ext)s'),
            'restrictfilenames': True,
            'noplaylist': config.ytdlp.no_playlist,
            'geo_bypass': config.ytdlp.geo_bypass,
            'socket_timeout': config.ytdlp.socket_timeout,
            'retries': config.ytdlp.retries,
            'fragment_retries': config.ytdlp.fragment_retries,
            'ignoreerrors': False,
            'no_warnings': False,
            'quiet': not config.debug_mode,
            'no_color': True,
            'progress_hooks': [self._progress_hook],
            'postprocessor_hooks': [self._postprocessor_hook],
            
            # Merge format options
            'merge_output_format': 'mp4',
            'keepvideo': False,
            
            # Metadata options
            'writeinfojson': True,
            'writethumbnail': False,
            
            # Rate limiting (optional)
            # 'ratelimit': 5000000,  # 5MB/s
            
            # FFmpeg options
            'ffmpeg_location': config.ffmpeg.ffmpeg_path if config.ffmpeg.ffmpeg_path != 'ffmpeg' else None,
            
            # Post-processing
            'postprocessors': [{
                'key': 'FFmpegVideoConvertor',
                'preferedformat': 'mp4',
            }],
        }
        
        return options
    
    def _progress_hook(self, d: Dict[str, Any]):
        """Progress hook for yt-dlp"""
        if d['status'] == 'downloading':
            try:
                # Calculate progress percentage
                if 'total_bytes' in d and d['total_bytes']:
                    progress = (d['downloaded_bytes'] / d['total_bytes']) * 100
                elif 'total_bytes_estimate' in d and d['total_bytes_estimate']:
                    progress = (d['downloaded_bytes'] / d['total_bytes_estimate']) * 100
                else:
                    progress = 0
                
                # Update progress tracker
                if self.progress_tracker and progress > self._last_progress:
                    self.progress_tracker.set_progress(int(progress))
                    self._last_progress = progress
                
                # Call external callback if set
                if self.progress_callback and progress - self._last_progress >= 5:
                    self._last_progress = progress
                    
                    info = {
                        'status': 'downloading',
                        'progress': progress,
                        'downloaded': format_file_size(d.get('downloaded_bytes', 0)),
                        'total': format_file_size(d.get('total_bytes', d.get('total_bytes_estimate', 0))),
                        'speed': d.get('_speed_str', 'N/A'),
                        'eta': d.get('_eta_str', 'N/A'),
                    }
                    
                    # Run callback in asyncio if it's async
                    if asyncio.iscoroutinefunction(self.progress_callback):
                        asyncio.create_task(self.progress_callback(info))
                    else:
                        self.progress_callback(info)
                        
            except Exception as e:
                logger.debug(f"Progress hook error: {e}")
        
        elif d['status'] == 'finished':
            logger.info(f"Download finished: {d.get('filename', 'unknown')}")
            self.current_download = d.get('filename')
    
    def _postprocessor_hook(self, d: Dict[str, Any]):
        """Post-processor hook for yt-dlp"""
        if d['status'] == 'finished':
            logger.info(f"Post-processing finished: {d.get('info_dict', {}).get('filepath', 'unknown')}")
    
    async def get_video_info(self, url: str) -> Optional[VideoInfo]:
        """
        Get video information without downloading
        
        Args:
            url: YouTube video URL
            
        Returns:
            VideoInfo object or None if failed
        """
        url = sanitize_url(url)
        
        if not is_youtube_url(url):
            logger.error(f"Invalid YouTube URL: {url}")
            return None
        
        logger.info(f"Fetching video info for: {url}")
        
        try:
            ydl_opts = {
                'quiet': True,
                'no_warnings': True,
                'extract_flat': False,
                'format': config.ytdlp.get_format_for_quality(self.quality),
            }
            
            # Run in executor to avoid blocking
            loop = asyncio.get_event_loop()
            
            def extract_info():
                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    return ydl.extract_info(url, download=False)
            
            info = await loop.run_in_executor(None, extract_info)
            
            if not info:
                logger.error("Failed to extract video info")
                return None
            
            # Find best format info
            formats = info.get('formats', [])
            best_video = None
            best_audio = None
            
            for f in formats:
                if f.get('vcodec') != 'none' and f.get('acodec') == 'none':
                    if not best_video or (f.get('height', 0) > best_video.get('height', 0)):
                        best_video = f
                elif f.get('acodec') != 'none' and f.get('vcodec') == 'none':
                    if not best_audio or (f.get('abr', 0) > best_audio.get('abr', 0)):
                        best_audio = f
            
            # Calculate approximate file size
            filesize = 0
            if best_video:
                filesize += best_video.get('filesize', 0) or best_video.get('filesize_approx', 0) or 0
            if best_audio:
                filesize += best_audio.get('filesize', 0) or best_audio.get('filesize_approx', 0) or 0
            
            # If still no filesize, estimate based on duration and bitrate
            if filesize == 0 and info.get('duration'):
                # Rough estimate: 5 Mbps for video + 192 kbps for audio
                bitrate = 5 * 1024 * 1024 + 192 * 1024  # bits per second
                filesize = int((bitrate / 8) * info.get('duration', 0))
            
            # Get resolution
            resolution = "Unknown"
            if best_video:
                resolution = f"{best_video.get('width', '?')}x{best_video.get('height', '?')}"
            elif info.get('width') and info.get('height'):
                resolution = f"{info['width']}x{info['height']}"
            
            video_info = VideoInfo(
                video_id=info.get('id', ''),
                title=info.get('title', 'Unknown Title'),
                duration=info.get('duration', 0),
                description=info.get('description', '')[:500],  # Truncate
                thumbnail_url=info.get('thumbnail', ''),
                channel=info.get('channel', info.get('uploader', 'Unknown')),
                channel_id=info.get('channel_id', ''),
                upload_date=info.get('upload_date', ''),
                view_count=info.get('view_count', 0),
                like_count=info.get('like_count', 0),
                formats=formats,
                requested_format=config.ytdlp.get_format_for_quality(self.quality),
                filesize_approx=filesize,
                resolution=resolution,
                fps=best_video.get('fps', 30) if best_video else 30,
                ext='mp4',
                url=url,
            )
            
            self.video_info = video_info
            logger.info(f"Video info fetched: {video_info.title} ({format_duration(video_info.duration)})")
            
            return video_info
            
        except yt_dlp.utils.DownloadError as e:
            logger.error(f"yt-dlp download error: {e}")
            return None
        except Exception as e:
            logger.error(f"Failed to get video info: {e}")
            return None
    
    @log_execution_time
    async def download_video(
        self,
        url: str,
        progress_callback: Optional[Callable] = None,
        output_filename: Optional[str] = None
    ) -> Optional[Path]:
        """
        Download video from YouTube
        
        Args:
            url: YouTube video URL
            progress_callback: Optional callback for progress updates
            output_filename: Optional custom output filename
            
        Returns:
            Path to downloaded video file or None if failed
        """
        url = sanitize_url(url)
        
        if not is_youtube_url(url):
            logger.error(f"Invalid YouTube URL: {url}")
            raise ValueError("Invalid YouTube URL")
        
        self.progress_callback = progress_callback
        self._last_progress = 0
        
        # Initialize progress tracker
        self.progress_tracker = AsyncProgressTracker(
            total=100,
            description="Downloading video"
        )
        
        # Update session
        session_manager.update_session(
            self.user_id,
            stage=ProcessingStage.DOWNLOADING,
            youtube_url=url
        )
        
        logger.info(f"Starting download: {url}")
        
        try:
            # Get video info first if not already fetched
            if not self.video_info:
                self.video_info = await self.get_video_info(url)
                
            if not self.video_info:
                raise Exception("Failed to get video information")
            
            # Check file size limit
            max_size_bytes = config.telegram.max_file_size_mb * 1024 * 1024
            if self.video_info.filesize_approx > max_size_bytes:
                raise Exception(
                    f"Video too large: {format_file_size(self.video_info.filesize_approx)} "
                    f"(max: {config.telegram.max_file_size_mb}MB)"
                )
            
            # Prepare output path
            if output_filename:
                safe_name = safe_filename(output_filename)
            else:
                safe_name = safe_filename(self.video_info.title)
            
            # Ensure .mp4 extension
            if not safe_name.endswith('.mp4'):
                safe_name = f"{safe_name}.mp4"
            
            output_path = self.download_dir / safe_name
            
            # Check if already downloaded
            if output_path.exists():
                logger.info(f"Video already exists: {output_path}")
                
                # Update session
                session_manager.update_session(
                    self.user_id,
                    video_title=self.video_info.title,
                    video_duration=self.video_info.duration,
                    input_video_path=str(output_path)
                )
                
                return output_path
            
            # Get yt-dlp options
            ydl_opts = self._get_ydl_options(self.download_dir)
            ydl_opts['outtmpl'] = str(self.download_dir / f"{safe_name.rsplit('.', 1)[0]}.%(ext)s")
            
            # Download in executor
            loop = asyncio.get_event_loop()
            
            def do_download():
                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    ydl.download([url])
            
            await loop.run_in_executor(None, do_download)
            
            # Find the downloaded file
            downloaded_file = None
            
            # Check for exact match first
            if output_path.exists():
                downloaded_file = output_path
            else:
                # Look for any matching file
                pattern = safe_name.rsplit('.', 1)[0]
                for file in self.download_dir.iterdir():
                    if file.stem.startswith(pattern[:50]) and file.suffix == '.mp4':
                        downloaded_file = file
                        break
                
                # Also check the current_download from progress hook
                if not downloaded_file and self.current_download:
                    current_path = Path(self.current_download)
                    if current_path.exists():
                        downloaded_file = current_path
            
            if not downloaded_file or not downloaded_file.exists():
                # Last resort: find most recent mp4
                mp4_files = list(self.download_dir.glob("*.mp4"))
                if mp4_files:
                    downloaded_file = max(mp4_files, key=lambda x: x.stat().st_mtime)
            
            if downloaded_file and downloaded_file.exists():
                # Rename to expected output path if different
                if downloaded_file != output_path:
                    downloaded_file.rename(output_path)
                    downloaded_file = output_path
                
                logger.info(f"Download complete: {downloaded_file}")
                logger.info(f"File size: {format_file_size(downloaded_file.stat().st_size)}")
                
                # Update session
                session_manager.update_session(
                    self.user_id,
                    video_title=self.video_info.title,
                    video_duration=self.video_info.duration,
                    input_video_path=str(downloaded_file)
                )
                
                return downloaded_file
            else:
                raise Exception("Download completed but file not found")
                
        except yt_dlp.utils.DownloadError as e:
            error_msg = str(e)
            
            # Parse common errors
            if "Private video" in error_msg:
                error_msg = "This video is private"
            elif "Video unavailable" in error_msg:
                error_msg = "Video is unavailable"
            elif "age-restricted" in error_msg.lower():
                error_msg = "Video is age-restricted"
            elif "copyright" in error_msg.lower():
                error_msg = "Video is blocked due to copyright"
            
            logger.error(f"Download failed: {error_msg}")
            session_manager.update_session(
                self.user_id,
                stage=ProcessingStage.FAILED,
                error_message=error_msg
            )
            raise Exception(error_msg)
            
        except Exception as e:
            logger.error(f"Download failed: {e}")
            session_manager.update_session(
                self.user_id,
                stage=ProcessingStage.FAILED,
                error_message=str(e)
            )
            raise
    
    async def download_audio_only(
        self,
        url: str,
        progress_callback: Optional[Callable] = None
    ) -> Optional[Path]:
        """
        Download only audio from YouTube video
        
        Args:
            url: YouTube video URL
            progress_callback: Optional callback for progress updates
            
        Returns:
            Path to downloaded audio file or None if failed
        """
        url = sanitize_url(url)
        self.progress_callback = progress_callback
        
        logger.info(f"Starting audio-only download: {url}")
        
        try:
            # Get video info
            if not self.video_info:
                self.video_info = await self.get_video_info(url)
            
            if not self.video_info:
                raise Exception("Failed to get video information")
            
            safe_name = safe_filename(self.video_info.title)
            output_path = self.download_dir / f"{safe_name}.mp3"
            
            ydl_opts = {
                'format': 'bestaudio/best',
                'outtmpl': str(self.download_dir / f"{safe_name}.%(ext)s"),
                'quiet': not config.debug_mode,
                'no_warnings': True,
                'progress_hooks': [self._progress_hook],
                'postprocessors': [{
                    'key': 'FFmpegExtractAudio',
                    'preferredcodec': 'mp3',
                    'preferredquality': '192',
                }],
            }
            
            loop = asyncio.get_event_loop()
            
            def do_download():
                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    ydl.download([url])
            
            await loop.run_in_executor(None, do_download)
            
            if output_path.exists():
                logger.info(f"Audio download complete: {output_path}")
                return output_path
            
            # Find the downloaded file
            for file in self.download_dir.iterdir():
                if file.stem == safe_name and file.suffix in ['.mp3', '.m4a', '.wav']:
                    return file
            
            raise Exception("Audio download completed but file not found")
            
        except Exception as e:
            logger.error(f"Audio download failed: {e}")
            raise
    
    def get_available_formats(self) -> list:
        """Get list of available formats for the video"""
        if self.video_info:
            return self.video_info.formats
        return []
    
    def set_quality(self, quality: QualityPreset):
        """Set download quality preset"""
        self.quality = quality
        logger.info(f"Quality set to: {quality.value}")
    
    async def cleanup(self):
        """Clean up temporary files"""
        try:
            temp_files = list(self.download_dir.glob("*.part"))
            temp_files.extend(self.download_dir.glob("*.ytdl"))
            temp_files.extend(self.download_dir.glob("*.temp"))
            
            for temp_file in temp_files:
                temp_file.unlink()
                logger.debug(f"Cleaned up: {temp_file}")
                
        except Exception as e:
            logger.warning(f"Cleanup error: {e}")


# Convenience function for quick downloads
async def download_youtube_video(
    url: str,
    user_id: int,
    quality: QualityPreset = QualityPreset.HIGH,
    progress_callback: Optional[Callable] = None
) -> Tuple[Optional[Path], Optional[VideoInfo]]:
    """
    Convenience function to download YouTube video
    
    Args:
        url: YouTube video URL
        user_id: User ID for workspace
        quality: Quality preset
        progress_callback: Optional progress callback
        
    Returns:
        Tuple of (video_path, video_info) or (None, None) if failed
    """
    downloader = YouTubeDownloader(user_id, quality)
    
    try:
        video_info = await downloader.get_video_info(url)
        if not video_info:
            return None, None
        
        video_path = await downloader.download_video(url, progress_callback)
        return video_path, video_info
        
    except Exception as e:
        logger.error(f"Download failed: {e}")
        return None, None


# Test function
async def test_downloader():
    """Test the downloader module"""
    print("\n" + "=" * 50)
    print("🧪 Testing YouTube Downloader")
    print("=" * 50)
    
    # Test URL validation
    test_urls = [
        "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
        "https://youtu.be/dQw4w9WgXcQ",
        "https://youtube.com/shorts/abc123def45",
        "https://invalid-url.com/video",
    ]
    
    print("\n📋 URL Validation Tests:")
    for url in test_urls:
        is_valid = is_youtube_url(url)
        video_id = extract_video_id(url)
        print(f"  {url[:50]:50} -> Valid: {is_valid}, ID: {video_id}")
    
    print("\n✅ Downloader module loaded successfully!")
    print("=" * 50)


if __name__ == "__main__":
    asyncio.run(test_downloader())