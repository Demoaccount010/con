"""
Audio/Video Merger Module
Hindi Dubbing Bot - Telegram Integrated

Handles:
- Merging Hindi audio with background music
- Audio ducking (lowering background during narration)
- Final video creation with new audio track
"""

import asyncio
import subprocess
from pathlib import Path
from typing import Optional, Dict, List, Tuple, Callable
from dataclasses import dataclass

try:
    from pydub import AudioSegment, effects
    PYDUB_AVAILABLE = True
except ImportError:
    PYDUB_AVAILABLE = False

from config import config, ProcessingStage
from utils import (
    logger,
    session_manager,
    get_user_workspace,
    format_file_size,
    format_duration,
    get_audio_duration,
    log_execution_time,
)


@dataclass
class MergeResult:
    """Result of audio/video merge"""
    output_path: Path
    duration: float
    file_size: int
    
    def to_dict(self) -> Dict:
        return {
            "output_path": str(self.output_path),
            "duration": self.duration,
            "file_size": self.file_size,
        }


class AudioMerger:
    """
    Merges Hindi narration with background music/effects
    Creates final dubbed audio track
    """
    
    def __init__(self, user_id: int):
        self.user_id = user_id
        self.workspace = get_user_workspace(user_id)
        self.output_dir = self.workspace["output"]
        self.temp_dir = self.workspace["temp"]
        
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.temp_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"AudioMerger initialized for user {user_id}")
    
    def _run_ffmpeg(self, args: List[str], timeout: int = 3600) -> subprocess.CompletedProcess:
        """Run FFmpeg command"""
        cmd = [config.ffmpeg.ffmpeg_path] + args
        logger.debug(f"FFmpeg: {' '.join(cmd[:10])}...")
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        
        if result.returncode != 0:
            logger.error(f"FFmpeg error: {result.stderr[:500]}")
            raise subprocess.CalledProcessError(result.returncode, cmd)
        
        return result
    
    @log_execution_time
    async def merge_audio_tracks(
        self,
        hindi_audio_path: Path,
        background_audio_path: Path,
        output_path: Optional[Path] = None,
        narration_volume: float = 1.0,
        background_volume: float = 0.3,
        enable_ducking: bool = True,
        progress_callback: Callable = None
    ) -> Optional[Path]:
        """
        Merge Hindi narration with background audio
        
        Args:
            hindi_audio_path: Path to Hindi narration audio
            background_audio_path: Path to background music/effects
            output_path: Output path for merged audio
            narration_volume: Volume for narration (0.0-2.0)
            background_volume: Volume for background (0.0-2.0)
            enable_ducking: Lower background when narration plays
            progress_callback: Progress callback
            
        Returns:
            Path to merged audio file
        """
        if not hindi_audio_path.exists():
            raise FileNotFoundError(f"Hindi audio not found: {hindi_audio_path}")
        if not background_audio_path.exists():
            raise FileNotFoundError(f"Background audio not found: {background_audio_path}")
        
        session_manager.update_session(self.user_id, stage=ProcessingStage.MERGING_AUDIO)
        
        output_path = output_path or self.output_dir / "merged_audio.wav"
        
        logger.info(f"Merging audio tracks...")
        logger.info(f"  Narration: {hindi_audio_path}")
        logger.info(f"  Background: {background_audio_path}")
        
        if progress_callback:
            await progress_callback({
                "status": "merging",
                "message": "Merging audio tracks..."
            })
        
        try:
            loop = asyncio.get_event_loop()
            
            if PYDUB_AVAILABLE and enable_ducking:
                # Use pydub for advanced ducking
                merged_path = await loop.run_in_executor(
                    None,
                    self._merge_with_ducking_pydub,
                    hindi_audio_path,
                    background_audio_path,
                    output_path,
                    narration_volume,
                    background_volume
                )
            else:
                # Use FFmpeg for simple mixing
                merged_path = await loop.run_in_executor(
                    None,
                    self._merge_with_ffmpeg,
                    hindi_audio_path,
                    background_audio_path,
                    output_path,
                    narration_volume,
                    background_volume
                )
            
            if merged_path and merged_path.exists():
                logger.info(f"Audio merged: {merged_path} ({format_file_size(merged_path.stat().st_size)})")
                return merged_path
            
            raise Exception("Merge failed - output not created")
            
        except Exception as e:
            logger.error(f"Audio merge failed: {e}")
            raise
    
    def _merge_with_ffmpeg(
        self,
        narration_path: Path,
        background_path: Path,
        output_path: Path,
        narration_vol: float,
        background_vol: float
    ) -> Path:
        """Simple FFmpeg mixing"""
        
        # Complex filter for mixing
        filter_complex = (
            f"[0:a]volume={narration_vol}[narr];"
            f"[1:a]volume={background_vol}[bg];"
            f"[narr][bg]amix=inputs=2:duration=longest:dropout_transition=2[out]"
        )
        
        args = [
            '-i', str(narration_path),
            '-i', str(background_path),
            '-filter_complex', filter_complex,
            '-map', '[out]',
            '-ar', '44100',
            '-ac', '2',
            '-y',
            str(output_path)
        ]
        
        self._run_ffmpeg(args)
        return output_path
    
    def _merge_with_ducking_pydub(
        self,
        narration_path: Path,
        background_path: Path,
        output_path: Path,
        narration_vol: float,
        background_vol: float
    ) -> Path:
        """Advanced mixing with audio ducking using pydub"""
        
        # Load audio files
        narration = AudioSegment.from_file(str(narration_path))
        background = AudioSegment.from_file(str(background_path))
        
        # Adjust volumes (pydub uses dB)
        narration_db = 20 * (narration_vol - 1) if narration_vol != 1 else 0
        background_db = 20 * (background_vol - 1) if background_vol != 1 else 0
        
        narration = narration + narration_db
        background = background + background_db
        
        # Match lengths
        if len(background) < len(narration):
            # Loop background if shorter
            loops_needed = (len(narration) // len(background)) + 1
            background = background * loops_needed
        
        background = background[:len(narration)]
        
        # Simple ducking: reduce background volume
        ducking_reduction = config.audio_merge.ducking_reduction
        background = background + (20 * (ducking_reduction - 1))
        
        # Overlay narration on background
        merged = background.overlay(narration)
        
        # Normalize
        merged = effects.normalize(merged)
        
        # Export
        merged.export(str(output_path), format="wav")
        
        return output_path
    
    @log_execution_time
    async def create_final_video(
        self,
        video_path: Path,
        audio_path: Path,
        output_path: Optional[Path] = None,
        progress_callback: Callable = None
    ) -> Optional[MergeResult]:
        """
        Create final video with new audio track
        
        Args:
            video_path: Original video file
            audio_path: New audio track (merged Hindi + background)
            output_path: Output video path
            progress_callback: Progress callback
            
        Returns:
            MergeResult with output info
        """
        if not video_path.exists():
            raise FileNotFoundError(f"Video not found: {video_path}")
        if not audio_path.exists():
            raise FileNotFoundError(f"Audio not found: {audio_path}")
        
        session_manager.update_session(self.user_id, stage=ProcessingStage.CREATING_VIDEO)
        
        output_path = output_path or self.output_dir / "final_hindi_video.mp4"
        
        logger.info(f"Creating final video...")
        logger.info(f"  Video: {video_path}")
        logger.info(f"  Audio: {audio_path}")
        
        if progress_callback:
            await progress_callback({
                "status": "creating_video",
                "message": "Creating final dubbed video..."
            })
        
        try:
            loop = asyncio.get_event_loop()
            
            def create_video():
                # Get quality settings
                quality = config.ffmpeg.quality_settings.get(
                    session_manager.get_session(self.user_id).quality_preset,
                    config.ffmpeg.quality_settings[config.QualityPreset.HIGH]
                ) if hasattr(config, 'QualityPreset') else {
                    "crf": 23, "preset": "medium", "audio_bitrate": "192k"
                }
                
                args = [
                    '-i', str(video_path),
                    '-i', str(audio_path),
                    '-c:v', 'copy',  # Copy video stream (fast)
                    '-c:a', 'aac',
                    '-b:a', quality.get("audio_bitrate", "192k"),
                    '-map', '0:v:0',
                    '-map', '1:a:0',
                    '-shortest',
                    '-y',
                    str(output_path)
                ]
                
                self._run_ffmpeg(args)
            
            await loop.run_in_executor(None, create_video)
            
            if output_path.exists():
                duration = get_audio_duration(output_path) or 0
                file_size = output_path.stat().st_size
                
                logger.info(f"Final video created: {output_path}")
                logger.info(f"  Duration: {format_duration(duration)}")
                logger.info(f"  Size: {format_file_size(file_size)}")
                
                # Update session
                session_manager.update_session(
                    self.user_id,
                    stage=ProcessingStage.COMPLETED,
                    final_video_path=str(output_path)
                )
                
                return MergeResult(
                    output_path=output_path,
                    duration=duration,
                    file_size=file_size
                )
            
            raise Exception("Video creation failed")
            
        except Exception as e:
            logger.error(f"Video creation failed: {e}")
            session_manager.update_session(
                self.user_id,
                stage=ProcessingStage.FAILED,
                error_message=str(e)
            )
            raise


class VideoMerger:
    """
    Complete video dubbing pipeline
    Combines all merging operations
    """
    
    def __init__(self, user_id: int):
        self.user_id = user_id
        self.audio_merger = AudioMerger(user_id)
        self.workspace = get_user_workspace(user_id)
    
    @log_execution_time
    async def create_dubbed_video(
        self,
        original_video_path: Path,
        hindi_audio_path: Path,
        background_audio_path: Path,
        output_path: Optional[Path] = None,
        narration_volume: float = 1.0,
        background_volume: float = 0.3,
        audio_offset_ms: int = 0,
        progress_callback: Callable = None
    ) -> Optional[MergeResult]:
        """
        Complete dubbing pipeline: merge audio and create video
        
        Args:
            original_video_path: Original video file
            hindi_audio_path: Hindi narration audio
            background_audio_path: Background music/effects (no_vocals.wav)
            output_path: Final output path
            narration_volume: Hindi narration volume
            background_volume: Background volume
            audio_offset_ms: Offset for Hindi audio in milliseconds
            progress_callback: Progress callback
            
        Returns:
            MergeResult with final video info
        """
        logger.info("Starting complete dubbing pipeline")
        
        # Step 1: Apply offset to Hindi audio if needed
        processed_hindi = hindi_audio_path
        if audio_offset_ms != 0 and PYDUB_AVAILABLE:
            processed_hindi = await self._apply_audio_offset(
                hindi_audio_path, audio_offset_ms
            )
        
        # Step 2: Merge audio tracks
        if progress_callback:
            await progress_callback({
                "status": "merging",
                "message": "🔀 Merging audio tracks..."
            })
        
        merged_audio = await self.audio_merger.merge_audio_tracks(
            processed_hindi,
            background_audio_path,
            narration_volume=narration_volume,
            background_volume=background_volume,
            progress_callback=progress_callback
        )
        
        if not merged_audio:
            raise Exception("Audio merge failed")
        
        # Step 3: Create final video
        if progress_callback:
            await progress_callback({
                "status": "creating_video",
                "message": "🎬 Creating final video..."
            })
        
        result = await self.audio_merger.create_final_video(
            original_video_path,
            merged_audio,
            output_path,
            progress_callback
        )
        
        return result
    
    async def _apply_audio_offset(self, audio_path: Path, offset_ms: int) -> Path:
        """Apply timing offset to audio"""
        if not PYDUB_AVAILABLE:
            return audio_path
        
        audio = AudioSegment.from_file(str(audio_path))
        
        if offset_ms > 0:
            # Add silence at beginning
            silence = AudioSegment.silent(duration=offset_ms)
            audio = silence + audio
        elif offset_ms < 0:
            # Trim from beginning
            audio = audio[abs(offset_ms):]
        
        output_path = self.workspace["temp"] / "offset_audio.wav"
        audio.export(str(output_path), format="wav")
        
        return output_path


async def create_dubbed_video(
    user_id: int,
    original_video_path: Path,
    hindi_audio_path: Path,
    background_audio_path: Path,
    progress_callback: Callable = None
) -> Optional[MergeResult]:
    """
    Convenience function for complete dubbing
    """
    merger = VideoMerger(user_id)
    
    return await merger.create_dubbed_video(
        original_video_path,
        hindi_audio_path,
        background_audio_path,
        narration_volume=config.audio_merge.narration_volume,
        background_volume=config.audio_merge.background_volume,
        audio_offset_ms=config.audio_merge.audio_offset_ms,
        progress_callback=progress_callback
    )


async def test_merger():
    """Test merger module"""
    print("\n" + "=" * 50)
    print("🧪 Testing Merger Module")
    print("=" * 50)
    
    print(f"\n📋 Dependency Check:")
    print(f"  PyDub: {'✅' if PYDUB_AVAILABLE else '❌'}")
    
    print("\n✅ Merger module loaded!")
    print("=" * 50)


if __name__ == "__main__":
    asyncio.run(test_merger())