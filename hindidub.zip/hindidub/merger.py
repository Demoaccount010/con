"""
Enhanced Audio/Video Merger Module
Hindi Dubbing Bot - With ADVANCED SYNC FEATURES

Handles:
- Segment-wise audio synchronization
- Time stretching to match original duration
- Audio ducking with smart detection
- Professional audio mixing
"""

import asyncio
import subprocess
import json
from pathlib import Path
from typing import Optional, Dict, List, Tuple, Callable
from dataclasses import dataclass, field
import tempfile

try:
    from pydub import AudioSegment, effects, silence
    PYDUB_AVAILABLE = True
except ImportError:
    PYDUB_AVAILABLE = False

try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False

from config import config, ProcessingStage
from utils import (
    logger,
    session_manager,
    get_user_workspace,
    format_file_size,
    format_duration,
    get_audio_duration,
    log_execution_time,
)


@dataclass
class SyncSegment:
    """Segment for synchronization"""
    id: int
    start: float  # seconds
    end: float    # seconds
    text: str = ""
    
    @property
    def duration(self) -> float:
        return self.end - self.start


@dataclass
class SyncResult:
    """Result of synchronization"""
    synced_audio_path: Path
    original_duration: float
    synced_duration: float
    speed_factor: float
    segments_processed: int
    sync_quality: str  # "perfect", "good", "acceptable", "poor"


@dataclass
class MergeResult:
    """Result of audio/video merge"""
    output_path: Path
    duration: float
    file_size: int
    sync_info: Optional[SyncResult] = None


class AudioSynchronizer:
    """
    Advanced audio synchronization
    Matches Hindi audio timing to original video
    """
    
    def __init__(self, user_id: int):
        self.user_id = user_id
        self.workspace = get_user_workspace(user_id)
        self.temp_dir = self.workspace["temp"]
        self.temp_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"AudioSynchronizer initialized for user {user_id}")
    
    def _run_ffmpeg(self, args: List[str], timeout: int = 600) -> subprocess.CompletedProcess:
        """Run FFmpeg command"""
        cmd = [config.ffmpeg.ffmpeg_path] + args
        logger.debug(f"FFmpeg: {' '.join(cmd[:8])}...")
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        if result.returncode != 0:
            logger.error(f"FFmpeg error: {result.stderr[:300]}")
            raise subprocess.CalledProcessError(result.returncode, cmd)
        return result
    
    async def analyze_audio(self, audio_path: Path) -> Dict:
        """
        Analyze audio file for sync information
        
        Returns:
            Dict with duration, silence regions, speech regions
        """
        if not audio_path.exists():
            raise FileNotFoundError(f"Audio not found: {audio_path}")
        
        duration = get_audio_duration(audio_path) or 0
        
        analysis = {
            "duration": duration,
            "silence_regions": [],
            "speech_regions": [],
        }
        
        if PYDUB_AVAILABLE:
            try:
                audio = AudioSegment.from_file(str(audio_path))
                
                # Detect silence regions
                silence_ranges = silence.detect_silence(
                    audio,
                    min_silence_len=500,  # 500ms minimum silence
                    silence_thresh=-40     # -40 dB threshold
                )
                
                analysis["silence_regions"] = [
                    {"start": s/1000, "end": e/1000} 
                    for s, e in silence_ranges
                ]
                
                # Calculate speech regions (inverse of silence)
                speech_regions = []
                prev_end = 0
                for s, e in silence_ranges:
                    if s > prev_end:
                        speech_regions.append({
                            "start": prev_end/1000, 
                            "end": s/1000
                        })
                    prev_end = e
                
                if prev_end < len(audio):
                    speech_regions.append({
                        "start": prev_end/1000,
                        "end": len(audio)/1000
                    })
                
                analysis["speech_regions"] = speech_regions
                
            except Exception as e:
                logger.warning(f"Audio analysis failed: {e}")
        
        return analysis
    
    async def simple_sync(
        self,
        hindi_audio_path: Path,
        target_duration: float,
        output_path: Optional[Path] = None
    ) -> Path:
        """
        Simple sync: Stretch/compress entire audio to match target duration
        
        Args:
            hindi_audio_path: Path to Hindi audio
            target_duration: Target duration in seconds
            output_path: Output path
            
        Returns:
            Path to synced audio
        """
        output_path = output_path or self.temp_dir / "synced_simple.wav"
        
        current_duration = get_audio_duration(hindi_audio_path) or 0
        
        if current_duration <= 0:
            raise ValueError("Invalid audio duration")
        
        # Calculate speed factor
        speed_factor = current_duration / target_duration
        
        logger.info(f"Simple sync: {current_duration:.2f}s → {target_duration:.2f}s")
        logger.info(f"Speed factor: {speed_factor:.3f}x")
        
        if abs(speed_factor - 1.0) < 0.05:
            # Less than 5% difference, no adjustment needed
            logger.info("Audio duration already matched (within 5%)")
            
            # Just copy/convert
            args = [
                '-i', str(hindi_audio_path),
                '-ar', '44100',
                '-ac', '2',
                '-y',
                str(output_path)
            ]
            self._run_ffmpeg(args)
        else:
            # Use FFmpeg atempo filter
            # atempo range is 0.5 to 2.0, chain multiple if needed
            tempo_filters = self._build_tempo_chain(speed_factor)
            
            args = [
                '-i', str(hindi_audio_path),
                '-filter:a', tempo_filters,
                '-ar', '44100',
                '-ac', '2',
                '-y',
                str(output_path)
            ]
            self._run_ffmpeg(args)
        
        logger.info(f"Synced audio saved: {output_path}")
        return output_path
    
    def _build_tempo_chain(self, speed_factor: float) -> str:
        """
        Build atempo filter chain for FFmpeg
        atempo only supports 0.5 to 2.0, so chain multiple filters
        """
        filters = []
        remaining = speed_factor
        
        while remaining > 2.0:
            filters.append("atempo=2.0")
            remaining /= 2.0
        
        while remaining < 0.5:
            filters.append("atempo=0.5")
            remaining /= 0.5
        
        filters.append(f"atempo={remaining:.4f}")
        
        return ",".join(filters)
    
    async def segment_sync(
        self,
        hindi_audio_path: Path,
        segments: List[SyncSegment],
        output_path: Optional[Path] = None,
        progress_callback: Callable = None
    ) -> SyncResult:
        """
        Advanced sync: Match each segment individually
        
        This provides the BEST sync quality by:
        1. Splitting Hindi audio by detected pauses
        2. Matching each Hindi segment to original segment duration
        3. Stretching/compressing each segment individually
        4. Reassembling with correct timing
        
        Args:
            hindi_audio_path: Path to Hindi audio
            segments: List of original segment timings
            output_path: Output path
            progress_callback: Progress callback
            
        Returns:
            SyncResult with sync information
        """
        if not PYDUB_AVAILABLE:
            logger.warning("PyDub not available, falling back to simple sync")
            total_duration = segments[-1].end if segments else 0
            synced = await self.simple_sync(hindi_audio_path, total_duration)
            return SyncResult(
                synced_audio_path=synced,
                original_duration=total_duration,
                synced_duration=get_audio_duration(synced) or 0,
                speed_factor=1.0,
                segments_processed=0,
                sync_quality="acceptable"
            )
        
        output_path = output_path or self.temp_dir / "synced_segments.wav"
        
        logger.info(f"Segment sync: Processing {len(segments)} segments")
        
        # Load Hindi audio
        hindi_audio = AudioSegment.from_file(str(hindi_audio_path))
        hindi_duration = len(hindi_audio) / 1000  # ms to seconds
        
        # Calculate total original duration
        original_duration = segments[-1].end if segments else 0
        
        # Detect speech segments in Hindi audio
        hindi_segments = await self._detect_speech_segments(hindi_audio)
        
        logger.info(f"Detected {len(hindi_segments)} speech segments in Hindi audio")
        
        # Match segments
        if len(hindi_segments) >= len(segments):
            # We have enough Hindi segments
            synced_audio = await self._match_segments(
                hindi_audio, 
                hindi_segments, 
                segments,
                progress_callback
            )
        else:
            # Not enough segments detected, use simple stretch
            logger.warning("Not enough segments detected, using proportional stretch")
            synced_audio = await self._proportional_stretch(
                hindi_audio,
                original_duration
            )
        
        # Export
        synced_audio.export(str(output_path), format="wav")
        
        synced_duration = len(synced_audio) / 1000
        speed_factor = hindi_duration / synced_duration if synced_duration > 0 else 1.0
        
        # Determine sync quality
        time_diff = abs(synced_duration - original_duration)
        if time_diff < 0.5:
            sync_quality = "perfect"
        elif time_diff < 2.0:
            sync_quality = "good"
        elif time_diff < 5.0:
            sync_quality = "acceptable"
        else:
            sync_quality = "poor"
        
        logger.info(f"Sync complete: {hindi_duration:.2f}s → {synced_duration:.2f}s")
        logger.info(f"Sync quality: {sync_quality}")
        
        return SyncResult(
            synced_audio_path=output_path,
            original_duration=original_duration,
            synced_duration=synced_duration,
            speed_factor=speed_factor,
            segments_processed=len(segments),
            sync_quality=sync_quality
        )
    
    async def _detect_speech_segments(
        self, 
        audio: AudioSegment,
        min_silence_len: int = 400,
        silence_thresh: int = -40
    ) -> List[Tuple[int, int]]:
        """Detect speech segments (non-silent regions)"""
        
        # Detect silence
        silent_ranges = silence.detect_silence(
            audio,
            min_silence_len=min_silence_len,
            silence_thresh=silence_thresh
        )
        
        # Get speech ranges (inverse of silence)
        speech_ranges = []
        prev_end = 0
        
        for silence_start, silence_end in silent_ranges:
            if silence_start > prev_end:
                speech_ranges.append((prev_end, silence_start))
            prev_end = silence_end
        
        # Add final segment if audio ends with speech
        if prev_end < len(audio):
            speech_ranges.append((prev_end, len(audio)))
        
        return speech_ranges
    
    async def _match_segments(
        self,
        hindi_audio: AudioSegment,
        hindi_segments: List[Tuple[int, int]],
        target_segments: List[SyncSegment],
        progress_callback: Callable = None
    ) -> AudioSegment:
        """Match and stretch Hindi segments to target timings"""
        
        # Create output audio with correct total duration
        total_duration_ms = int(target_segments[-1].end * 1000)
        output = AudioSegment.silent(duration=total_duration_ms)
        
        # Match each target segment with a Hindi segment
        num_hindi = len(hindi_segments)
        num_target = len(target_segments)
        
        for i, target in enumerate(target_segments):
            # Find corresponding Hindi segment
            hindi_idx = int((i / num_target) * num_hindi)
            hindi_idx = min(hindi_idx, num_hindi - 1)
            
            hindi_start, hindi_end = hindi_segments[hindi_idx]
            hindi_segment = hindi_audio[hindi_start:hindi_end]
            
            # Calculate required duration
            target_duration_ms = int(target.duration * 1000)
            hindi_duration_ms = len(hindi_segment)
            
            if hindi_duration_ms > 0 and target_duration_ms > 0:
                # Calculate speed change
                speed_factor = hindi_duration_ms / target_duration_ms
                
                # Apply speed change (with limits)
                if speed_factor > 0.5 and speed_factor < 2.0:
                    # Use pydub speedup (basic)
                    if speed_factor > 1.0:
                        # Speed up
                        hindi_segment = hindi_segment.speedup(
                            playback_speed=speed_factor,
                            crossfade=50
                        )
                    else:
                        # Slow down - add silence or use FFmpeg
                        pass
                
                # Trim or pad to exact duration
                if len(hindi_segment) > target_duration_ms:
                    hindi_segment = hindi_segment[:target_duration_ms]
                elif len(hindi_segment) < target_duration_ms:
                    padding = AudioSegment.silent(
                        duration=target_duration_ms - len(hindi_segment)
                    )
                    hindi_segment = hindi_segment + padding
                
                # Place at correct position
                target_start_ms = int(target.start * 1000)
                output = output.overlay(hindi_segment, position=target_start_ms)
            
            # Progress update
            if progress_callback and (i + 1) % 10 == 0:
                progress = ((i + 1) / num_target) * 100
                await progress_callback({
                    "status": "syncing",
                    "progress": progress,
                    "message": f"Syncing segment {i+1}/{num_target}"
                })
        
        return output
    
    async def _proportional_stretch(
        self,
        audio: AudioSegment,
        target_duration: float
    ) -> AudioSegment:
        """Proportionally stretch audio to target duration"""
        
        current_duration = len(audio) / 1000  # seconds
        
        if current_duration <= 0:
            return audio
        
        speed_factor = current_duration / target_duration
        
        if abs(speed_factor - 1.0) < 0.05:
            # Close enough, no change needed
            return audio
        
        # For significant changes, use FFmpeg (better quality)
        temp_input = self.temp_dir / "temp_input.wav"
        temp_output = self.temp_dir / "temp_stretched.wav"
        
        audio.export(str(temp_input), format="wav")
        
        tempo_filter = self._build_tempo_chain(speed_factor)
        
        args = [
            '-i', str(temp_input),
            '-filter:a', tempo_filter,
            '-ar', '44100',
            '-y',
            str(temp_output)
        ]
        self._run_ffmpeg(args)
        
        return AudioSegment.from_file(str(temp_output))


class AdvancedAudioMerger:
    """
    Advanced audio merger with synchronization
    """
    
    def __init__(self, user_id: int):
        self.user_id = user_id
        self.workspace = get_user_workspace(user_id)
        self.output_dir = self.workspace["output"]
        self.temp_dir = self.workspace["temp"]
        self.synchronizer = AudioSynchronizer(user_id)
        
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.temp_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"AdvancedAudioMerger initialized for user {user_id}")
    
    def _run_ffmpeg(self, args: List[str], timeout: int = 3600) -> subprocess.CompletedProcess:
        """Run FFmpeg command"""
        cmd = [config.ffmpeg.ffmpeg_path] + args
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        if result.returncode != 0:
            logger.error(f"FFmpeg error: {result.stderr[:300]}")
            raise subprocess.CalledProcessError(result.returncode, cmd)
        return result
    
    @log_execution_time
    async def merge_with_sync(
        self,
        hindi_audio_path: Path,
        background_audio_path: Path,
        original_video_path: Path,
        segments: Optional[List[SyncSegment]] = None,
        narration_volume: float = 1.0,
        background_volume: float = 0.3,
        sync_mode: str = "auto",  # "auto", "simple", "segment", "none"
        progress_callback: Callable = None
    ) -> Tuple[Path, Optional[SyncResult]]:
        """
        Merge audio with synchronization
        
        Args:
            hindi_audio_path: Hindi narration audio
            background_audio_path: Background music/SFX
            original_video_path: Original video (for duration reference)
            segments: Original transcript segments (for segment sync)
            narration_volume: Hindi voice volume
            background_volume: Background volume
            sync_mode: Synchronization mode
            progress_callback: Progress callback
            
        Returns:
            Tuple of (merged_audio_path, sync_result)
        """
        # Get original video duration
        original_duration = get_audio_duration(original_video_path) or 0
        hindi_duration = get_audio_duration(hindi_audio_path) or 0
        
        logger.info(f"Original duration: {format_duration(original_duration)}")
        logger.info(f"Hindi audio duration: {format_duration(hindi_duration)}")
        logger.info(f"Sync mode: {sync_mode}")
        
        sync_result = None
        synced_hindi_path = hindi_audio_path
        
        # === STEP 1: SYNCHRONIZE HINDI AUDIO ===
        if progress_callback:
            await progress_callback({
                "status": "syncing",
                "message": "🔄 Synchronizing Hindi audio with video..."
            })
        
        if sync_mode == "none":
            # No sync, use as-is
            synced_hindi_path = hindi_audio_path
            
        elif sync_mode == "simple" or (sync_mode == "auto" and not segments):
            # Simple duration matching
            if abs(hindi_duration - original_duration) > 1.0:  # More than 1 second difference
                synced_hindi_path = await self.synchronizer.simple_sync(
                    hindi_audio_path,
                    original_duration
                )
                sync_result = SyncResult(
                    synced_audio_path=synced_hindi_path,
                    original_duration=original_duration,
                    synced_duration=get_audio_duration(synced_hindi_path) or 0,
                    speed_factor=hindi_duration / original_duration,
                    segments_processed=0,
                    sync_quality="good"
                )
            else:
                logger.info("Duration already matched, no sync needed")
                
        elif sync_mode == "segment" or (sync_mode == "auto" and segments):
            # Segment-wise sync (best quality)
            if segments:
                sync_result = await self.synchronizer.segment_sync(
                    hindi_audio_path,
                    segments,
                    progress_callback=progress_callback
                )
                synced_hindi_path = sync_result.synced_audio_path
            else:
                # Fallback to simple
                synced_hindi_path = await self.synchronizer.simple_sync(
                    hindi_audio_path,
                    original_duration
                )
        
        # === STEP 2: MERGE WITH BACKGROUND ===
        if progress_callback:
            await progress_callback({
                "status": "merging",
                "message": "🔀 Mixing Hindi voice with background audio..."
            })
        
        merged_audio_path = await self._mix_audio_tracks(
            synced_hindi_path,
            background_audio_path,
            narration_volume,
            background_volume,
            original_duration
        )
        
        return merged_audio_path, sync_result
    
    async def _mix_audio_tracks(
        self,
        narration_path: Path,
        background_path: Path,
        narration_volume: float,
        background_volume: float,
        target_duration: float
    ) -> Path:
        """Mix narration and background audio"""
        
        output_path = self.output_dir / "merged_audio.wav"
        
        if PYDUB_AVAILABLE:
            # Use PyDub for better control
            narration = AudioSegment.from_file(str(narration_path))
            background = AudioSegment.from_file(str(background_path))
            
            # Adjust volumes (dB)
            narration_db = 20 * np.log10(narration_volume) if NUMPY_AVAILABLE and narration_volume > 0 else 0
            background_db = 20 * np.log10(background_volume) if NUMPY_AVAILABLE and background_volume > 0 else -10
            
            narration = narration + narration_db
            background = background + background_db
            
            # Match background to target duration
            target_ms = int(target_duration * 1000)
            
            if len(background) < target_ms:
                # Loop background
                loops = (target_ms // len(background)) + 1
                background = background * loops
            
            background = background[:target_ms]
            
            # Match narration to target duration (pad if shorter)
            if len(narration) < target_ms:
                padding = AudioSegment.silent(duration=target_ms - len(narration))
                narration = narration + padding
            elif len(narration) > target_ms:
                narration = narration[:target_ms]
            
            # Apply ducking: reduce background where narration exists
            if config.audio_merge.enable_ducking:
                background = self._apply_ducking(narration, background)
            
            # Overlay
            merged = background.overlay(narration)
            
            # Normalize
            merged = effects.normalize(merged)
            
            # Export
            merged.export(str(output_path), format="wav")
            
        else:
            # Fallback to FFmpeg
            filter_complex = (
                f"[0:a]volume={narration_volume}[narr];"
                f"[1:a]volume={background_volume}[bg];"
                f"[narr][bg]amix=inputs=2:duration=longest[out]"
            )
            
            args = [
                '-i', str(narration_path),
                '-i', str(background_path),
                '-filter_complex', filter_complex,
                '-map', '[out]',
                '-t', str(target_duration),
                '-ar', '44100',
                '-y',
                str(output_path)
            ]
            self._run_ffmpeg(args)
        
        logger.info(f"Audio merged: {output_path}")
        return output_path
    
    def _apply_ducking(
        self,
        narration: AudioSegment,
        background: AudioSegment,
        duck_amount: float = 0.3
    ) -> AudioSegment:
        """
        Apply audio ducking: reduce background volume where narration plays
        """
        # This is a simplified ducking implementation
        # For production, consider using more sophisticated algorithms
        
        # Detect non-silent regions in narration
        speech_regions = silence.detect_nonsilent(
            narration,
            min_silence_len=200,
            silence_thresh=-40
        )
        
        # Create ducked background
        ducked = background
        duck_db = 20 * np.log10(duck_amount) if NUMPY_AVAILABLE else -10
        
        for start_ms, end_ms in speech_regions:
            # Fade margins for smooth transition
            fade_ms = 50
            
            # Get segment
            before = ducked[:max(0, start_ms - fade_ms)]
            during = ducked[start_ms:end_ms] + duck_db
            after = ducked[min(len(ducked), end_ms + fade_ms):]
            
            # Apply crossfades
            if start_ms > fade_ms:
                fade_out = ducked[start_ms - fade_ms:start_ms].fade_out(fade_ms)
                before = before[:-fade_ms] + fade_out
            
            ducked = before + during + after
        
        return ducked[:len(background)]  # Ensure same length
    
    @log_execution_time
    async def create_final_video(
        self,
        video_path: Path,
        merged_audio_path: Path,
        output_path: Optional[Path] = None,
        sync_result: Optional[SyncResult] = None,
        progress_callback: Callable = None
    ) -> MergeResult:
        """
        Create final video with merged audio
        """
        if not video_path.exists():
            raise FileNotFoundError(f"Video not found: {video_path}")
        if not merged_audio_path.exists():
            raise FileNotFoundError(f"Audio not found: {merged_audio_path}")
        
        session_manager.update_session(self.user_id, stage=ProcessingStage.CREATING_VIDEO)
        
        output_path = output_path or self.output_dir / "final_hindi_video.mp4"
        
        if progress_callback:
            await progress_callback({
                "status": "creating_video",
                "message": "🎬 Creating final dubbed video..."
            })
        
        logger.info(f"Creating final video: {output_path}")
        
        # FFmpeg command to replace audio
        args = [
            '-i', str(video_path),
            '-i', str(merged_audio_path),
            '-c:v', 'copy',  # Copy video stream
            '-c:a', 'aac',
            '-b:a', '192k',
            '-map', '0:v:0',  # Take video from first input
            '-map', '1:a:0',  # Take audio from second input
            '-shortest',
            '-y',
            str(output_path)
        ]
        
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, lambda: self._run_ffmpeg(args))
        
        if output_path.exists():
            duration = get_audio_duration(output_path) or 0
            file_size = output_path.stat().st_size
            
            logger.info(f"Final video created: {output_path}")
            logger.info(f"Duration: {format_duration(duration)}, Size: {format_file_size(file_size)}")
            
            session_manager.update_session(
                self.user_id,
                stage=ProcessingStage.COMPLETED,
                final_video_path=str(output_path)
            )
            
            return MergeResult(
                output_path=output_path,
                duration=duration,
                file_size=file_size,
                sync_info=sync_result
            )
        
        raise Exception("Video creation failed")


class VideoMerger:
    """
    Complete video dubbing pipeline with sync
    """
    
    def __init__(self, user_id: int):
        self.user_id = user_id
        self.merger = AdvancedAudioMerger(user_id)
        self.workspace = get_user_workspace(user_id)
    
    @log_execution_time
    async def create_dubbed_video(
        self,
        original_video_path: Path,
        hindi_audio_path: Path,
        background_audio_path: Path,
        segments: Optional[List[SyncSegment]] = None,
        output_path: Optional[Path] = None,
        narration_volume: float = 1.0,
        background_volume: float = 0.3,
        sync_mode: str = "auto",
        audio_offset_ms: int = 0,
        progress_callback: Callable = None
    ) -> MergeResult:
        """
        Complete dubbed video creation with sync
        
        Args:
            original_video_path: Original video
            hindi_audio_path: Hindi narration
            background_audio_path: Background audio (no_vocals.wav)
            segments: Transcript segments for segment-wise sync
            output_path: Output path
            narration_volume: Hindi volume
            background_volume: Background volume
            sync_mode: "auto", "simple", "segment", "none"
            audio_offset_ms: Manual offset in milliseconds
            progress_callback: Progress callback
            
        Returns:
            MergeResult with all info
        """
        logger.info("=" * 50)
        logger.info("Starting dubbed video creation with SYNC")
        logger.info("=" * 50)
        
        # Apply manual offset if specified
        if audio_offset_ms != 0:
            hindi_audio_path = await self._apply_offset(
                hindi_audio_path, 
                audio_offset_ms
            )
        
        # Merge audio with sync
        merged_audio, sync_result = await self.merger.merge_with_sync(
            hindi_audio_path,
            background_audio_path,
            original_video_path,
            segments=segments,
            narration_volume=narration_volume,
            background_volume=background_volume,
            sync_mode=sync_mode,
            progress_callback=progress_callback
        )
        
        # Create final video
        result = await self.merger.create_final_video(
            original_video_path,
            merged_audio,
            output_path,
            sync_result,
            progress_callback
        )
        
        # Log sync info
        if sync_result:
            logger.info(f"Sync Quality: {sync_result.sync_quality}")
            logger.info(f"Speed Factor: {sync_result.speed_factor:.3f}x")
        
        return result
    
    async def _apply_offset(self, audio_path: Path, offset_ms: int) -> Path:
        """Apply timing offset"""
        if not PYDUB_AVAILABLE:
            return audio_path
        
        audio = AudioSegment.from_file(str(audio_path))
        
        if offset_ms > 0:
            # Add silence at beginning (delay audio)
            silence_seg = AudioSegment.silent(duration=offset_ms)
            audio = silence_seg + audio
        elif offset_ms < 0:
            # Trim from beginning (advance audio)
            audio = audio[abs(offset_ms):]
        
        output_path = self.workspace["temp"] / "offset_hindi.wav"
        audio.export(str(output_path), format="wav")
        
        logger.info(f"Applied offset: {offset_ms}ms")
        return output_path


# ============ CONVENIENCE FUNCTIONS ============

async def create_dubbed_video(
    user_id: int,
    original_video_path: Path,
    hindi_audio_path: Path,
    background_audio_path: Path,
    segments: Optional[List[SyncSegment]] = None,
    sync_mode: str = "auto",
    progress_callback: Callable = None
) -> MergeResult:
    """
    Main convenience function for creating dubbed video
    """
    merger = VideoMerger(user_id)
    
    return await merger.create_dubbed_video(
        original_video_path,
        hindi_audio_path,
        background_audio_path,
        segments=segments,
        narration_volume=config.audio_merge.narration_volume,
        background_volume=config.audio_merge.background_volume,
        sync_mode=sync_mode,
        audio_offset_ms=config.audio_merge.audio_offset_ms,
        progress_callback=progress_callback
    )


def load_segments_from_srt(srt_path: Path) -> List[SyncSegment]:
    """Load segments from SRT file for sync"""
    segments = []
    
    with open(srt_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    import re
    
    # Parse SRT format
    pattern = r'(\d+)\n(\d{2}:\d{2}:\d{2},\d{3}) --> (\d{2}:\d{2}:\d{2},\d{3})\n(.+?)(?=\n\n|\Z)'
    matches = re.findall(pattern, content, re.DOTALL)
    
    for match in matches:
        idx, start_ts, end_ts, text = match
        
        # Parse timestamp
        def parse_ts(ts):
            h, m, s = ts.replace(',', '.').split(':')
            return int(h) * 3600 + int(m) * 60 + float(s)
        
        segments.append(SyncSegment(
            id=int(idx),
            start=parse_ts(start_ts),
            end=parse_ts(end_ts),
            text=text.strip()
        ))
    
    return segments


async def test_sync():
    """Test sync functionality"""
    print("\n" + "=" * 50)
    print("🧪 Testing Sync Module")
    print("=" * 50)
    print(f"\n✅ PyDub: {'Available' if PYDUB_AVAILABLE else 'Not Available'}")
    print(f"✅ NumPy: {'Available' if NUMPY_AVAILABLE else 'Not Available'}")
    print("\n✅ Sync module loaded successfully!")
    print("=" * 50)


if __name__ == "__main__":
    asyncio.run(test_sync())