"""
Transcription Module
Hindi Dubbing Bot - Telegram Integrated

Handles:
- Speech-to-text using OpenAI Whisper
- Timestamp generation
- SRT subtitle file creation
"""

import os
import asyncio
import json
from pathlib import Path
from typing import Optional, Dict, Any, Callable, List, Tuple
from dataclasses import dataclass, field
from datetime import timedelta
import re

try:
    import whisper
    WHISPER_AVAILABLE = True
except ImportError:
    WHISPER_AVAILABLE = False

try:
    import torch
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False

try:
    import srt
    SRT_AVAILABLE = True
except ImportError:
    SRT_AVAILABLE = False

from config import config, ProcessingStage
from utils import (
    logger,
    session_manager,
    format_duration,
    get_user_workspace,
    get_audio_duration,
    log_execution_time,
    handle_errors,
    AsyncProgressTracker,
)


@dataclass
class TranscriptSegment:
    """Single transcript segment with timing"""
    id: int
    start: float  # seconds
    end: float  # seconds
    text: str
    confidence: float = 1.0
    words: List[Dict] = field(default_factory=list)
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "start": self.start,
            "end": self.end,
            "text": self.text,
            "confidence": self.confidence,
        }
    
    @property
    def duration(self) -> float:
        return self.end - self.start
    
    def format_timestamp(self, seconds: float) -> str:
        """Format seconds to SRT timestamp (HH:MM:SS,mmm)"""
        td = timedelta(seconds=seconds)
        hours, remainder = divmod(td.seconds, 3600)
        minutes, secs = divmod(remainder, 60)
        milliseconds = td.microseconds // 1000
        return f"{hours:02d}:{minutes:02d}:{secs:02d},{milliseconds:03d}"
    
    def to_srt_block(self) -> str:
        """Convert to SRT format block"""
        start_ts = self.format_timestamp(self.start)
        end_ts = self.format_timestamp(self.end)
        return f"{self.id}\n{start_ts} --> {end_ts}\n{self.text}\n"


@dataclass
class TranscriptionResult:
    """Complete transcription result"""
    segments: List[TranscriptSegment]
    full_text: str
    language: str
    language_probability: float
    duration: float
    word_count: int
    
    def to_dict(self) -> Dict:
        return {
            "segments": [s.to_dict() for s in self.segments],
            "full_text": self.full_text,
            "language": self.language,
            "language_probability": self.language_probability,
            "duration": self.duration,
            "word_count": self.word_count,
        }
    
    def get_text_with_timestamps(self) -> str:
        """Get formatted text with timestamps"""
        lines = []
        for seg in self.segments:
            timestamp = f"[{format_duration(seg.start)} - {format_duration(seg.end)}]"
            lines.append(f"{timestamp} {seg.text}")
        return "\n".join(lines)
    
    def to_srt(self) -> str:
        """Convert to SRT format"""
        blocks = [seg.to_srt_block() for seg in self.segments]
        return "\n".join(blocks)
    
    def to_txt(self) -> str:
        """Get plain text without timestamps"""
        return self.full_text
    
    def to_json(self) -> str:
        """Get JSON representation"""
        return json.dumps(self.to_dict(), indent=2, ensure_ascii=False)


class WhisperTranscriber:
    """
    Speech-to-text transcription using OpenAI Whisper
    Generates transcripts with timestamps in multiple formats
    """
    
    def __init__(self, user_id: int, model_size: Optional[str] = None):
        self.user_id = user_id
        self.model_size = model_size or config.whisper.model_size
        self.workspace = get_user_workspace(user_id)
        self.transcripts_dir = self.workspace["transcripts"]
        
        # Model and device
        self.model = None
        self.device = self._get_device()
        
        # Check dependencies
        if not WHISPER_AVAILABLE:
            raise ImportError("Whisper not installed. Run: pip install openai-whisper")
        
        logger.info(f"WhisperTranscriber initialized (model: {self.model_size}, device: {self.device})")
    
    def _get_device(self) -> str:
        """Get best available device"""
        if config.whisper.device != "auto":
            return config.whisper.device
        
        if TORCH_AVAILABLE and torch.cuda.is_available():
            return "cuda"
        return "cpu"
    
    async def load_model(self, progress_callback: Optional[Callable] = None):
        """
        Load Whisper model (lazy loading)
        
        Args:
            progress_callback: Optional callback for progress updates
        """
        if self.model is not None:
            return
        
        logger.info(f"Loading Whisper model: {self.model_size}")
        
        if progress_callback:
            await progress_callback({
                "status": "loading_model",
                "message": f"Loading Whisper {self.model_size} model..."
            })
        
        try:
            loop = asyncio.get_event_loop()
            
            def load():
                return whisper.load_model(
                    self.model_size,
                    device=self.device
                )
            
            self.model = await loop.run_in_executor(None, load)
            logger.info(f"Whisper model loaded successfully on {self.device}")
            
        except Exception as e:
            logger.error(f"Failed to load Whisper model: {e}")
            raise
    
    def _process_whisper_result(self, result: Dict) -> TranscriptionResult:
        """
        Process Whisper output into TranscriptionResult
        
        Args:
            result: Raw Whisper transcription result
            
        Returns:
            TranscriptionResult object
        """
        segments = []
        
        for i, seg in enumerate(result.get('segments', []), start=1):
            # Get word-level timestamps if available
            words = []
            if 'words' in seg:
                words = [
                    {
                        "word": w['word'],
                        "start": w['start'],
                        "end": w['end'],
                        "probability": w.get('probability', 1.0)
                    }
                    for w in seg['words']
                ]
            
            segment = TranscriptSegment(
                id=i,
                start=seg['start'],
                end=seg['end'],
                text=seg['text'].strip(),
                confidence=seg.get('avg_logprob', 0),
                words=words
            )
            segments.append(segment)
        
        # Calculate word count
        full_text = result.get('text', '').strip()
        word_count = len(full_text.split())
        
        return TranscriptionResult(
            segments=segments,
            full_text=full_text,
            language=result.get('language', 'en'),
            language_probability=result.get('language_probability', 1.0),
            duration=segments[-1].end if segments else 0,
            word_count=word_count
        )
    
    @log_execution_time
    async def transcribe(
        self,
        audio_path: Path,
        language: Optional[str] = None,
        task: str = "transcribe",
        progress_callback: Optional[Callable] = None
    ) -> Optional[TranscriptionResult]:
        """
        Transcribe audio file to text with timestamps
        
        Args:
            audio_path: Path to audio file
            language: Source language code (None = auto-detect)
            task: "transcribe" or "translate"
            progress_callback: Optional progress callback
            
        Returns:
            TranscriptionResult or None if failed
        """
        if not audio_path.exists():
            raise FileNotFoundError(f"Audio not found: {audio_path}")
        
        # Update session
        session_manager.update_session(
            self.user_id,
            stage=ProcessingStage.TRANSCRIBING
        )
        
        # Load model if needed
        await self.load_model(progress_callback)
        
        # Get audio duration for time estimate
        duration = get_audio_duration(audio_path) or 0
        
        # Estimate processing time
        model_speed = config.whisper.model_info.get(self.model_size, {}).get('speed', '~2x')
        if self.device == "cuda":
            est_factor = 0.1  # Much faster on GPU
        else:
            est_factor = float(model_speed.replace('~', '').replace('x', '')) if 'x' in model_speed else 2
        
        est_time = duration / est_factor if est_factor else duration
        
        logger.info(f"Transcribing: {audio_path}")
        logger.info(f"Audio duration: {format_duration(duration)}")
        logger.info(f"Estimated time: {format_duration(est_time)}")
        
        if progress_callback:
            await progress_callback({
                "status": "transcribing",
                "message": f"Transcribing audio ({format_duration(duration)})...",
                "estimated_time": format_duration(est_time)
            })
        
        try:
            loop = asyncio.get_event_loop()
            
            def do_transcribe():
                # Transcription options
                options = {
                    "task": task,
                    "beam_size": config.whisper.beam_size,
                    "best_of": config.whisper.best_of,
                    "temperature": config.whisper.temperature,
                    "word_timestamps": config.whisper.word_timestamps,
                    "verbose": config.whisper.verbose,
                    "fp16": config.whisper.fp16 and self.device == "cuda",
                }
                
                if language:
                    options["language"] = language
                
                return self.model.transcribe(str(audio_path), **options)
            
            # Run transcription
            result = await loop.run_in_executor(None, do_transcribe)
            
            # Process result
            transcription = self._process_whisper_result(result)
            
            logger.info(f"Transcription complete: {transcription.word_count} words, "
                       f"language: {transcription.language}")
            
            return transcription
            
        except Exception as e:
            logger.error(f"Transcription failed: {e}")
            raise
    
    async def save_transcription(
        self,
        transcription: TranscriptionResult,
        base_name: str = "transcript",
        formats: List[str] = None
    ) -> Dict[str, Path]:
        """
        Save transcription in multiple formats
        
        Args:
            transcription: TranscriptionResult to save
            base_name: Base filename without extension
            formats: List of formats to save (srt, txt, json)
            
        Returns:
            Dict mapping format to file path
        """
        formats = formats or ["srt", "txt", "json"]
        saved_files = {}
        
        self.transcripts_dir.mkdir(parents=True, exist_ok=True)
        
        for fmt in formats:
            output_path = self.transcripts_dir / f"{base_name}.{fmt}"
            
            try:
                if fmt == "srt":
                    content = transcription.to_srt()
                elif fmt == "txt":
                    content = transcription.get_text_with_timestamps()
                elif fmt == "json":
                    content = transcription.to_json()
                else:
                    logger.warning(f"Unknown format: {fmt}")
                    continue
                
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                
                saved_files[fmt] = output_path
                logger.info(f"Saved {fmt}: {output_path}")
                
            except Exception as e:
                logger.error(f"Failed to save {fmt}: {e}")
        
        # Update session with transcript path
        if "srt" in saved_files:
            session_manager.update_session(
                self.user_id,
                transcript_path=str(saved_files["srt"])
            )
        
        return saved_files
    
    async def generate_script_for_dubbing(
        self,
        transcription: TranscriptionResult,
        output_path: Optional[Path] = None
    ) -> Path:
        """
        Generate a formatted script for dubbing
        Includes timestamps and space for Hindi translation
        
        Args:
            transcription: TranscriptionResult
            output_path: Optional output path
            
        Returns:
            Path to generated script file
        """
        output_path = output_path or self.transcripts_dir / "english_script_for_dubbing.txt"
        
        lines = [
            "=" * 60,
            "DUBBING SCRIPT - ENGLISH TO HINDI",
            "=" * 60,
            f"Total Duration: {format_duration(transcription.duration)}",
            f"Total Segments: {len(transcription.segments)}",
            f"Word Count: {transcription.word_count}",
            "=" * 60,
            "",
            "Instructions:",
            "1. Each segment has a timestamp and English text",
            "2. Record Hindi audio matching the timing",
            "3. Try to match the duration of each segment",
            "",
            "=" * 60,
            ""
        ]
        
        for seg in transcription.segments:
            start_ts = format_duration(seg.start)
            end_ts = format_duration(seg.end)
            duration = format_duration(seg.duration)
            
            lines.extend([
                f"[{seg.id:03d}] {start_ts} --> {end_ts} (Duration: {duration})",
                f"ENGLISH: {seg.text}",
                "",
                "-" * 40,
                ""
            ])
        
        content = "\n".join(lines)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        logger.info(f"Dubbing script saved: {output_path}")
        return output_path


class SRTHandler:
    """
    Utility class for handling SRT subtitle files
    """
    
    @staticmethod
    def parse_srt(srt_path: Path) -> List[TranscriptSegment]:
        """Parse SRT file into segments"""
        if not srt_path.exists():
            raise FileNotFoundError(f"SRT file not found: {srt_path}")
        
        with open(srt_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        if SRT_AVAILABLE:
            # Use srt library
            subtitles = list(srt.parse(content))
            return [
                TranscriptSegment(
                    id=sub.index,
                    start=sub.start.total_seconds(),
                    end=sub.end.total_seconds(),
                    text=sub.content
                )
                for sub in subtitles
            ]
        else:
            # Manual parsing
            return SRTHandler._parse_srt_manual(content)
    
    @staticmethod
    def _parse_srt_manual(content: str) -> List[TranscriptSegment]:
        """Manually parse SRT content"""
        segments = []
        
        # Split by double newlines
        blocks = re.split(r'\n\n+', content.strip())
        
        for block in blocks:
            lines = block.strip().split('\n')
            if len(lines) < 3:
                continue
            
            try:
                # Parse index
                idx = int(lines[0])
                
                # Parse timestamps
                timestamp_match = re.match(
                    r'(\d{2}:\d{2}:\d{2},\d{3})\s*-->\s*(\d{2}:\d{2}:\d{2},\d{3})',
                    lines[1]
                )
                
                if not timestamp_match:
                    continue
                
                start = SRTHandler._parse_timestamp(timestamp_match.group(1))
                end = SRTHandler._parse_timestamp(timestamp_match.group(2))
                
                # Text is remaining lines
                text = '\n'.join(lines[2:])
                
                segments.append(TranscriptSegment(
                    id=idx,
                    start=start,
                    end=end,
                    text=text
                ))
                
            except (ValueError, IndexError) as e:
                logger.warning(f"Failed to parse SRT block: {e}")
                continue
        
        return segments
    
    @staticmethod
    def _parse_timestamp(ts: str) -> float:
        """Parse SRT timestamp to seconds"""
        # Format: HH:MM:SS,mmm
        match = re.match(r'(\d{2}):(\d{2}):(\d{2}),(\d{3})', ts)
        if not match:
            return 0.0
        
        hours, minutes, seconds, millis = map(int, match.groups())
        return hours * 3600 + minutes * 60 + seconds + millis / 1000
    
    @staticmethod
    def write_srt(segments: List[TranscriptSegment], output_path: Path):
        """Write segments to SRT file"""
        with open(output_path, 'w', encoding='utf-8') as f:
            for seg in segments:
                f.write(seg.to_srt_block())
                f.write("\n")
    
    @staticmethod
    def shift_timestamps(
        segments: List[TranscriptSegment],
        offset_seconds: float
    ) -> List[TranscriptSegment]:
        """Shift all timestamps by offset"""
        shifted = []
        for seg in segments:
            new_seg = TranscriptSegment(
                id=seg.id,
                start=max(0, seg.start + offset_seconds),
                end=max(0, seg.end + offset_seconds),
                text=seg.text,
                confidence=seg.confidence,
                words=seg.words
            )
            shifted.append(new_seg)
        return shifted
    
    @staticmethod
    def merge_segments(
        segments: List[TranscriptSegment],
        max_gap: float = 1.0,
        max_duration: float = 10.0
    ) -> List[TranscriptSegment]:
        """Merge nearby segments into longer ones"""
        if not segments:
            return []
        
        merged = []
        current = segments[0]
        
        for seg in segments[1:]:
            gap = seg.start - current.end
            combined_duration = seg.end - current.start
            
            if gap <= max_gap and combined_duration <= max_duration:
                # Merge segments
                current = TranscriptSegment(
                    id=current.id,
                    start=current.start,
                    end=seg.end,
                    text=f"{current.text} {seg.text}",
                    confidence=(current.confidence + seg.confidence) / 2
                )
            else:
                merged.append(current)
                current = TranscriptSegment(
                    id=len(merged) + 1,
                    start=seg.start,
                    end=seg.end,
                    text=seg.text,
                    confidence=seg.confidence
                )
        
        merged.append(current)
        
        # Renumber
        for i, seg in enumerate(merged, start=1):
            seg.id = i
        
        return merged


# Convenience function
async def transcribe_audio(
    audio_path: Path,
    user_id: int,
    progress_callback: Optional[Callable] = None
) -> Tuple[Optional[TranscriptionResult], Dict[str, Path]]:
    """
    Complete transcription pipeline
    
    Args:
        audio_path: Path to audio file
        user_id: User ID
        progress_callback: Optional progress callback
        
    Returns:
        Tuple of (TranscriptionResult, saved_files_dict)
    """
    transcriber = WhisperTranscriber(user_id)
    
    try:
        # Transcribe
        transcription = await transcriber.transcribe(
            audio_path,
            language="en",
            progress_callback=progress_callback
        )
        
        if not transcription:
            return None, {}
        
        # Save in multiple formats
        saved_files = await transcriber.save_transcription(
            transcription,
            base_name="transcript",
            formats=["srt", "txt", "json"]
        )
        
        # Generate dubbing script
        dubbing_script = await transcriber.generate_script_for_dubbing(transcription)
        saved_files["dubbing_script"] = dubbing_script
        
        return transcription, saved_files
        
    except Exception as e:
        logger.error(f"Transcription pipeline failed: {e}")
        return None, {}


# Test function
async def test_transcription():
    """Test the transcription module"""
    print("\n" + "=" * 50)
    print("🧪 Testing Transcription Module")
    print("=" * 50)
    
    # Check dependencies
    print("\n📋 Dependency Check:")
    print(f"  Whisper: {'✅' if WHISPER_AVAILABLE else '❌'}")
    print(f"  PyTorch: {'✅' if TORCH_AVAILABLE else '❌'}")
    print(f"  SRT: {'✅' if SRT_AVAILABLE else '❌'}")
    
    if TORCH_AVAILABLE:
        device = "cuda" if torch.cuda.is_available() else "cpu"
        print(f"  Device: {device}")
        if device == "cuda":
            print(f"  GPU: {torch.cuda.get_device_name(0)}")
    
    # Show model info
    if WHISPER_AVAILABLE:
        print("\n📊 Available Whisper Models:")
        for model, info in config.whisper.model_info.items():
            print(f"  {model:12} - VRAM: {info['vram']:4}, Speed: {info['speed']}")
    
    print("\n✅ Transcription module loaded successfully!")
    print("=" * 50)


if __name__ == "__main__":
    asyncio.run(test_transcription())