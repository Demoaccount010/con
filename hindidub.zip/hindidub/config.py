"""
Configuration and Settings Management
Hindi Dubbing Bot - Telegram Integrated
"""

import os
from pathlib import Path
from dataclasses import dataclass, field
from typing import Dict, List, Optional
from enum import Enum
import json


class QualityPreset(Enum):
    """Video/Audio quality presets"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    ULTRA = "ultra"


class ProcessingStage(Enum):
    """Processing stages for tracking progress"""
    IDLE = "idle"
    DOWNLOADING = "downloading"
    EXTRACTING_AUDIO = "extracting_audio"
    SEPARATING_VOCALS = "separating_vocals"
    TRANSCRIBING = "transcribing"
    TRANSLATING = "translating"
    WAITING_HINDI_AUDIO = "waiting_hindi_audio"
    MERGING_AUDIO = "merging_audio"
    CREATING_VIDEO = "creating_video"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class TelegramConfig:
    """Telegram Bot Configuration"""
    bot_token: str = ""  # Set your bot token here or via environment
    admin_user_ids: List[int] = field(default_factory=list)  # Admin user IDs
    allowed_user_ids: List[int] = field(default_factory=list)  # Empty = allow all
    max_file_size_mb: int = 2000  # Max download size
    telegram_file_limit_mb: int = 50  # Telegram's file size limit
    request_timeout: int = 300  # Request timeout in seconds
    
    def __post_init__(self):
        # Try to get token from environment if not set
        if not self.bot_token:
            self.bot_token = os.getenv("TELEGRAM_BOT_TOKEN", "")


@dataclass
class PathConfig:
    """File and Directory Paths Configuration"""
    base_dir: Path = field(default_factory=lambda: Path(__file__).parent)
    
    def __post_init__(self):
        self.base_dir = Path(self.base_dir)
        
    @property
    def workspace_dir(self) -> Path:
        return self.base_dir / "workspace"
    
    @property
    def downloads_dir(self) -> Path:
        return self.workspace_dir / "downloads"
    
    @property
    def audio_dir(self) -> Path:
        return self.workspace_dir / "audio"
    
    @property
    def separated_dir(self) -> Path:
        return self.workspace_dir / "separated"
    
    @property
    def transcripts_dir(self) -> Path:
        return self.workspace_dir / "transcripts"
    
    @property
    def output_dir(self) -> Path:
        return self.workspace_dir / "output"
    
    @property
    def temp_dir(self) -> Path:
        return self.workspace_dir / "temp"
    
    @property
    def logs_dir(self) -> Path:
        return self.base_dir / "logs"
    
    @property
    def sessions_dir(self) -> Path:
        return self.workspace_dir / "sessions"
    
    def get_user_dir(self, user_id: int) -> Path:
        """Get user-specific workspace directory"""
        return self.workspace_dir / f"user_{user_id}"
    
    def create_all_directories(self, user_id: Optional[int] = None):
        """Create all necessary directories"""
        dirs = [
            self.workspace_dir,
            self.downloads_dir,
            self.audio_dir,
            self.separated_dir,
            self.transcripts_dir,
            self.output_dir,
            self.temp_dir,
            self.logs_dir,
            self.sessions_dir,
        ]
        
        if user_id:
            user_dir = self.get_user_dir(user_id)
            dirs.extend([
                user_dir,
                user_dir / "downloads",
                user_dir / "audio",
                user_dir / "separated",
                user_dir / "transcripts",
                user_dir / "output",
                user_dir / "temp",
            ])
        
        for dir_path in dirs:
            dir_path.mkdir(parents=True, exist_ok=True)


@dataclass
class FFmpegConfig:
    """FFmpeg Configuration"""
    ffmpeg_path: str = "ffmpeg"  # Use system ffmpeg or specify path
    ffprobe_path: str = "ffprobe"
    audio_codec: str = "pcm_s16le"  # For WAV output
    audio_sample_rate: int = 44100
    audio_channels: int = 2
    video_codec: str = "libx264"
    video_preset: str = "medium"
    video_crf: int = 23  # Quality (lower = better, 18-28 typical)
    
    # Quality preset mappings
    quality_settings: Dict = field(default_factory=lambda: {
        QualityPreset.LOW: {"crf": 28, "preset": "faster", "audio_bitrate": "128k"},
        QualityPreset.MEDIUM: {"crf": 23, "preset": "medium", "audio_bitrate": "192k"},
        QualityPreset.HIGH: {"crf": 20, "preset": "slow", "audio_bitrate": "256k"},
        QualityPreset.ULTRA: {"crf": 18, "preset": "slower", "audio_bitrate": "320k"},
    })


@dataclass
class YTDLPConfig:
    """yt-dlp Download Configuration"""
    format_selection: str = "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best"
    max_resolution: Optional[int] = None  # None = best available
    prefer_free_formats: bool = True
    geo_bypass: bool = True
    no_playlist: bool = True
    extract_audio: bool = False
    socket_timeout: int = 60
    retries: int = 3
    fragment_retries: int = 3
    
    # Quality preset mappings for resolution
    resolution_presets: Dict = field(default_factory=lambda: {
        QualityPreset.LOW: 480,
        QualityPreset.MEDIUM: 720,
        QualityPreset.HIGH: 1080,
        QualityPreset.ULTRA: 2160,
    })
    
    def get_format_for_quality(self, quality: QualityPreset) -> str:
        """Get format string for quality preset"""
        max_res = self.resolution_presets.get(quality, 1080)
        return f"bestvideo[height<={max_res}][ext=mp4]+bestaudio[ext=m4a]/best[height<={max_res}][ext=mp4]/best"


@dataclass
class DemucsConfig:
    """Demucs AI Voice Separation Configuration"""
    model_name: str = "htdemucs"  # htdemucs, htdemucs_ft, mdx_extra
    device: str = "auto"  # auto, cuda, cpu
    shifts: int = 1  # Number of random shifts for better quality (1-10)
    overlap: float = 0.25  # Overlap between chunks
    jobs: int = 0  # Parallel jobs (0 = auto)
    split: bool = True  # Split audio to reduce memory
    segment: Optional[int] = None  # Segment length in seconds
    two_stems: Optional[str] = "vocals"  # Only separate vocals vs rest
    
    # Model options
    available_models: List[str] = field(default_factory=lambda: [
        "htdemucs",      # Default hybrid transformer
        "htdemucs_ft",   # Fine-tuned version
        "htdemucs_6s",   # 6 sources version
        "mdx_extra",     # MDX-Net architecture
        "mdx_extra_q",   # Quantized version
    ])


@dataclass
class WhisperConfig:
    """OpenAI Whisper Transcription Configuration"""
    model_size: str = "medium"  # tiny, base, small, medium, large, large-v2, large-v3
    device: str = "auto"  # auto, cuda, cpu
    language: str = "en"  # Source language
    task: str = "transcribe"  # transcribe or translate
    fp16: bool = True  # Use FP16 (faster on GPU)
    beam_size: int = 5
    best_of: int = 5
    temperature: float = 0.0
    word_timestamps: bool = True
    verbose: bool = False
    
    # Model sizes with VRAM requirements
    model_info: Dict = field(default_factory=lambda: {
        "tiny": {"vram": "1GB", "params": "39M", "speed": "~32x"},
        "base": {"vram": "1GB", "params": "74M", "speed": "~16x"},
        "small": {"vram": "2GB", "params": "244M", "speed": "~6x"},
        "medium": {"vram": "5GB", "params": "769M", "speed": "~2x"},
        "large": {"vram": "10GB", "params": "1550M", "speed": "~1x"},
        "large-v2": {"vram": "10GB", "params": "1550M", "speed": "~1x"},
        "large-v3": {"vram": "10GB", "params": "1550M", "speed": "~1x"},
    })


@dataclass
class TranslatorConfig:
    """Translation Configuration"""
    source_language: str = "en"
    target_language: str = "hi"
    translator_service: str = "google"  # google, mymemory, microsoft
    max_chars_per_request: int = 4500  # API limit safety
    retry_attempts: int = 3
    delay_between_requests: float = 0.5  # Seconds
    
    # Available translation services
    available_services: List[str] = field(default_factory=lambda: [
        "google",
        "mymemory",
        "libre",
    ])


@dataclass
class AudioMergeConfig:
    """Audio Merging Configuration"""
    narration_volume: float = 1.0  # 0.0 to 2.0
    background_volume: float = 0.3  # 0.0 to 2.0
    enable_ducking: bool = True  # Lower background during narration
    ducking_threshold: float = -30  # dB threshold for ducking
    ducking_reduction: float = 0.4  # Reduce background to this level
    crossfade_duration: int = 100  # Milliseconds
    normalize_audio: bool = True
    target_loudness: float = -14.0  # LUFS target
    sample_rate: int = 44100
    
    # Timing adjustments
    audio_offset_ms: int = 0  # Offset Hindi audio by milliseconds
    sync_mode: str = "auto"  # auto, manual, segment


@dataclass
class UserSession:
    """User session data"""
    user_id: int
    username: Optional[str] = None
    current_stage: ProcessingStage = ProcessingStage.IDLE
    quality_preset: QualityPreset = QualityPreset.HIGH
    youtube_url: Optional[str] = None
    video_title: Optional[str] = None
    video_duration: Optional[int] = None
    input_video_path: Optional[str] = None
    extracted_audio_path: Optional[str] = None
    vocals_path: Optional[str] = None
    no_vocals_path: Optional[str] = None
    transcript_path: Optional[str] = None
    hindi_script_path: Optional[str] = None
    hindi_srt_path: Optional[str] = None
    hindi_audio_path: Optional[str] = None
    final_video_path: Optional[str] = None
    error_message: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    settings: Dict = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        """Convert session to dictionary"""
        return {
            "user_id": self.user_id,
            "username": self.username,
            "current_stage": self.current_stage.value,
            "quality_preset": self.quality_preset.value,
            "youtube_url": self.youtube_url,
            "video_title": self.video_title,
            "video_duration": self.video_duration,
            "input_video_path": self.input_video_path,
            "extracted_audio_path": self.extracted_audio_path,
            "vocals_path": self.vocals_path,
            "no_vocals_path": self.no_vocals_path,
            "transcript_path": self.transcript_path,
            "hindi_script_path": self.hindi_script_path,
            "hindi_srt_path": self.hindi_srt_path,
            "hindi_audio_path": self.hindi_audio_path,
            "final_video_path": self.final_video_path,
            "error_message": self.error_message,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "settings": self.settings,
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> "UserSession":
        """Create session from dictionary"""
        session = cls(user_id=data["user_id"])
        session.username = data.get("username")
        session.current_stage = ProcessingStage(data.get("current_stage", "idle"))
        session.quality_preset = QualityPreset(data.get("quality_preset", "high"))
        session.youtube_url = data.get("youtube_url")
        session.video_title = data.get("video_title")
        session.video_duration = data.get("video_duration")
        session.input_video_path = data.get("input_video_path")
        session.extracted_audio_path = data.get("extracted_audio_path")
        session.vocals_path = data.get("vocals_path")
        session.no_vocals_path = data.get("no_vocals_path")
        session.transcript_path = data.get("transcript_path")
        session.hindi_script_path = data.get("hindi_script_path")
        session.hindi_srt_path = data.get("hindi_srt_path")
        session.hindi_audio_path = data.get("hindi_audio_path")
        session.final_video_path = data.get("final_video_path")
        session.error_message = data.get("error_message")
        session.created_at = data.get("created_at")
        session.updated_at = data.get("updated_at")
        session.settings = data.get("settings", {})
        return session


@dataclass
class BotConfig:
    """Master Configuration Class"""
    telegram: TelegramConfig = field(default_factory=TelegramConfig)
    paths: PathConfig = field(default_factory=PathConfig)
    ffmpeg: FFmpegConfig = field(default_factory=FFmpegConfig)
    ytdlp: YTDLPConfig = field(default_factory=YTDLPConfig)
    demucs: DemucsConfig = field(default_factory=DemucsConfig)
    whisper: WhisperConfig = field(default_factory=WhisperConfig)
    translator: TranslatorConfig = field(default_factory=TranslatorConfig)
    audio_merge: AudioMergeConfig = field(default_factory=AudioMergeConfig)
    
    # Global settings
    debug_mode: bool = False
    keep_intermediate_files: bool = True
    max_concurrent_users: int = 3
    auto_cleanup_hours: int = 24
    
    def __post_init__(self):
        """Initialize paths after creation"""
        self.paths.create_all_directories()
    
    def save_to_file(self, filepath: str = "bot_config.json"):
        """Save configuration to JSON file"""
        config_dict = {
            "telegram": {
                "bot_token": self.telegram.bot_token,
                "admin_user_ids": self.telegram.admin_user_ids,
                "allowed_user_ids": self.telegram.allowed_user_ids,
                "max_file_size_mb": self.telegram.max_file_size_mb,
            },
            "quality_preset": "high",
            "whisper_model": self.whisper.model_size,
            "demucs_model": self.demucs.model_name,
            "debug_mode": self.debug_mode,
            "keep_intermediate_files": self.keep_intermediate_files,
        }
        
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(config_dict, f, indent=4, ensure_ascii=False)
    
    @classmethod
    def load_from_file(cls, filepath: str = "bot_config.json") -> "BotConfig":
        """Load configuration from JSON file"""
        config = cls()
        
        if os.path.exists(filepath):
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
            
            if "telegram" in data:
                config.telegram.bot_token = data["telegram"].get("bot_token", "")
                config.telegram.admin_user_ids = data["telegram"].get("admin_user_ids", [])
                config.telegram.allowed_user_ids = data["telegram"].get("allowed_user_ids", [])
            
            config.whisper.model_size = data.get("whisper_model", "medium")
            config.demucs.model_name = data.get("demucs_model", "htdemucs")
            config.debug_mode = data.get("debug_mode", False)
            config.keep_intermediate_files = data.get("keep_intermediate_files", True)
        
        return config


# Global config instance
config = BotConfig()


# Messages and UI Text
class Messages:
    """Bot messages in Hindi/English"""
    
    WELCOME = """
🎬 *Hindi Dubbing Bot में आपका स्वागत है!*

यह bot YouTube videos को Hindi में dub करने में मदद करता है।

*कैसे use करें:*
1️⃣ YouTube URL भेजें
2️⃣ Bot video download करेगा और process करेगा
3️⃣ Hindi script मिलेगी - उसे edit करें
4️⃣ Hindi audio record करके भेजें
5️⃣ Final dubbed video प्राप्त करें!

📹 *शुरू करने के लिए YouTube URL भेजें*
"""
    
    HELP = """
📚 *Help & Commands*

*Available Commands:*
/start - Bot शुरू करें
/help - यह help message
/status - Current processing status
/cancel - वर्तमान operation cancel करें
/settings - Quality settings बदलें
/clean - Temporary files delete करें

*How to use:*
• Simply paste any YouTube URL
• Wait for processing to complete
• Send your recorded Hindi audio when asked
• Receive final dubbed video

*Supported Formats:*
• YouTube URLs (regular & shorts)
• Audio: MP3, WAV, M4A, OGG

*Tips:*
• Use good quality microphone for recording
• Match the timing of original narration
• Speak clearly for best results
"""
    
    URL_RECEIVED = "✅ URL received! Starting download..."
    DOWNLOADING = "📥 Downloading video... {progress}"
    DOWNLOAD_COMPLETE = "✅ Download complete!\n📊 Size: {size}\n⏱ Duration: {duration}"
    EXTRACTING_AUDIO = "🎵 Extracting audio from video..."
    SEPARATING_VOCALS = """
🎤 Separating vocals using AI...
यह प्रक्रिया में {estimate} लग सकते हैं।
कृपया प्रतीक्षा करें...
"""
    SEPARATION_COMPLETE = "✅ Audio separation complete!"
    TRANSCRIBING = "📝 Transcribing English audio with Whisper AI..."
    TRANSCRIPTION_COMPLETE = "✅ Transcription complete!"
    TRANSLATING = "🇮🇳 Translating to Hindi..."
    TRANSLATION_COMPLETE = """
✅ Translation complete!

📄 *Hindi script ऊपर भेज दी गई है।*

*अगला कदम:*
1. Script को edit करें (if needed)
2. Hindi में audio record करें
3. Audio file यहां भेजें (MP3/WAV)

⏳ मैं आपके Hindi audio का इंतज़ार कर रहा हूं...
"""
    
    WAITING_AUDIO = "⏳ Hindi audio file भेजें..."
    AUDIO_RECEIVED = "✅ Hindi audio received! Processing..."
    MERGING = "🔀 Merging audio tracks..."
    CREATING_VIDEO = "🎬 Creating final video..."
    PROCESSING_COMPLETE = """
🎉 *Processing Complete!*

आपकी Hindi dubbed video तैयार है!
"""
    
    ERROR_GENERIC = "❌ Error: {error}"
    ERROR_INVALID_URL = "❌ Invalid YouTube URL। कृपया सही URL भेजें।"
    ERROR_DOWNLOAD_FAILED = "❌ Download failed: {error}"
    ERROR_PROCESSING_FAILED = "❌ Processing failed: {error}"
    ERROR_NO_AUDIO = "❌ कृपया audio file भेजें (MP3, WAV, M4A)"
    ERROR_FILE_TOO_LARGE = "❌ File बहुत बड़ी है। Maximum size: {max_size}MB"
    
    CANCELLED = "🚫 Operation cancelled."
    STATUS_IDLE = "😴 No active processing. Send a YouTube URL to start."
    STATUS_PROCESSING = """
📊 *Current Status*

Stage: {stage}
Video: {title}
Progress: {progress}
"""
    
    SETTINGS_MENU = """
⚙️ *Settings*

Current Quality: {quality}
Whisper Model: {whisper}

Select quality preset:
"""
    
    QUALITY_CHANGED = "✅ Quality changed to: {quality}"


# Emoji mappings for stages
STAGE_EMOJI = {
    ProcessingStage.IDLE: "😴",
    ProcessingStage.DOWNLOADING: "📥",
    ProcessingStage.EXTRACTING_AUDIO: "🎵",
    ProcessingStage.SEPARATING_VOCALS: "🎤",
    ProcessingStage.TRANSCRIBING: "📝",
    ProcessingStage.TRANSLATING: "🇮🇳",
    ProcessingStage.WAITING_HINDI_AUDIO: "⏳",
    ProcessingStage.MERGING_AUDIO: "🔀",
    ProcessingStage.CREATING_VIDEO: "🎬",
    ProcessingStage.COMPLETED: "✅",
    ProcessingStage.FAILED: "❌",
    ProcessingStage.CANCELLED: "🚫",
}