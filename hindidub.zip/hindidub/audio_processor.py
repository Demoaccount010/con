"""
Enhanced Audio Processing Module
Hindi Dubbing Bot - With Advanced Separation & Cleanup

Features:
- Multiple AI model options
- Audio quality enhancement
- Artifact removal
- Separation quality check
"""

import os
import asyncio
import subprocess
import shutil
from pathlib import Path
from typing import Optional, Dict, Any, Callable, Tuple, List
from dataclasses import dataclass
import tempfile

try:
    import torch
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False

try:
    import demucs.separate
    from demucs.pretrained import get_model
    DEMUCS_AVAILABLE = True
except ImportError:
    DEMUCS_AVAILABLE = False

try:
    from pydub import AudioSegment, effects, silence
    from pydub.effects import normalize, compress_dynamic_range, low_pass_filter, high_pass_filter
    PYDUB_AVAILABLE = True
except ImportError:
    PYDUB_AVAILABLE = False

try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False

try:
    import noisereduce as nr
    import librosa
    import soundfile as sf
    NOISE_REDUCE_AVAILABLE = True
except ImportError:
    NOISE_REDUCE_AVAILABLE = False

from config import config, ProcessingStage
from utils import (
    logger,
    session_manager,
    format_file_size,
    format_duration,
    get_user_workspace,
    get_audio_duration,
    get_media_info,
    log_execution_time,
)


@dataclass
class AudioInfo:
    """Audio file information"""
    filepath: Path
    duration: float
    sample_rate: int
    channels: int
    bitrate: int
    codec: str
    file_size: int


@dataclass
class SeparationQuality:
    """Quality metrics for separation"""
    overall_score: float  # 0-100
    vocal_clarity: float  # 0-100
    background_clarity: float  # 0-100
    artifacts_level: str  # "none", "low", "medium", "high"
    recommendation: str


@dataclass
class SeparationResult:
    """Result of audio separation"""
    vocals_path: Path
    no_vocals_path: Path
    original_path: Path
    quality: Optional[SeparationQuality] = None
    model_used: str = "htdemucs"
    processing_time: float = 0
    
    def to_dict(self) -> Dict:
        return {
            "vocals_path": str(self.vocals_path),
            "no_vocals_path": str(self.no_vocals_path),
            "model_used": self.model_used,
            "quality": self.quality.__dict__ if self.quality else None,
        }


class AudioQualityAnalyzer:
    """
    Analyze audio quality and separation results
    """
    
    @staticmethod
    def analyze_separation_quality(
        original_path: Path,
        vocals_path: Path,
        no_vocals_path: Path
    ) -> SeparationQuality:
        """
        Analyze quality of separation
        
        Checks:
        - Vocal isolation quality
        - Background preservation
        - Artifacts detection
        """
        try:
            if not PYDUB_AVAILABLE:
                return SeparationQuality(
                    overall_score=75,
                    vocal_clarity=75,
                    background_clarity=75,
                    artifacts_level="unknown",
                    recommendation="Quality check unavailable"
                )
            
            original = AudioSegment.from_file(str(original_path))
            vocals = AudioSegment.from_file(str(vocals_path))
            no_vocals = AudioSegment.from_file(str(no_vocals_path))
            
            # Check 1: Duration match
            duration_match = abs(len(original) - len(vocals)) < 1000  # Within 1 second
            
            # Check 2: Volume levels
            original_db = original.dBFS
            vocals_db = vocals.dBFS
            no_vocals_db = no_vocals.dBFS
            
            # Vocals should be quieter than original (isolated)
            vocal_isolation = vocals_db < original_db
            
            # Background should have similar volume to original
            bg_preservation = abs(no_vocals_db - original_db) < 10
            
            # Check 3: Silence detection (artifacts often show as random noise)
            vocals_silence = silence.detect_silence(vocals, min_silence_len=1000, silence_thresh=-50)
            
            # Calculate scores
            vocal_clarity = 85 if vocal_isolation else 60
            background_clarity = 90 if bg_preservation else 70
            
            # Artifacts detection
            if len(vocals_silence) > len(original) / 10000:  # Too much silence = good separation
                artifacts_level = "low"
                artifact_penalty = 0
            else:
                artifacts_level = "medium"
                artifact_penalty = 10
            
            overall_score = (vocal_clarity + background_clarity) / 2 - artifact_penalty
            
            # Recommendation
            if overall_score >= 85:
                recommendation = "Excellent! Clean separation achieved."
            elif overall_score >= 70:
                recommendation = "Good quality. Minor artifacts possible."
            elif overall_score >= 55:
                recommendation = "Acceptable. Some audio bleed expected."
            else:
                recommendation = "Consider using a different video with clearer audio."
            
            return SeparationQuality(
                overall_score=overall_score,
                vocal_clarity=vocal_clarity,
                background_clarity=background_clarity,
                artifacts_level=artifacts_level,
                recommendation=recommendation
            )
            
        except Exception as e:
            logger.warning(f"Quality analysis failed: {e}")
            return SeparationQuality(
                overall_score=70,
                vocal_clarity=70,
                background_clarity=70,
                artifacts_level="unknown",
                recommendation="Quality check failed, but separation completed."
            )


class AudioEnhancer:
    """
    Audio enhancement and cleanup
    """
    
    def __init__(self, temp_dir: Path):
        self.temp_dir = temp_dir
        self.temp_dir.mkdir(parents=True, exist_ok=True)
    
    def _run_ffmpeg(self, args: List[str], timeout: int = 300) -> subprocess.CompletedProcess:
        """Run FFmpeg command"""
        cmd = [config.ffmpeg.ffmpeg_path] + args
        logger.debug(f"FFmpeg: {' '.join(cmd[:8])}...")
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        if result.returncode != 0:
            logger.error(f"FFmpeg error: {result.stderr[:300]}")
            raise subprocess.CalledProcessError(result.returncode, cmd)
        return result
    
    async def remove_noise(self, audio_path: Path, output_path: Optional[Path] = None) -> Path:
        """
        Remove background noise from audio
        
        Uses:
        1. noisereduce library (if available)
        2. FFmpeg afftdn filter (fallback)
        """
        output_path = output_path or self.temp_dir / f"denoised_{audio_path.name}"
        
        if NOISE_REDUCE_AVAILABLE:
            try:
                # Load audio
                audio_data, sample_rate = librosa.load(str(audio_path), sr=None)
                
                # Apply noise reduction
                reduced_noise = nr.reduce_noise(
                    y=audio_data,
                    sr=sample_rate,
                    stationary=True,
                    prop_decrease=0.75
                )
                
                # Save
                sf.write(str(output_path), reduced_noise, sample_rate)
                logger.info(f"Noise reduced (noisereduce): {output_path}")
                return output_path
                
            except Exception as e:
                logger.warning(f"noisereduce failed: {e}, using FFmpeg")
        
        # Fallback: FFmpeg noise reduction
        args = [
            '-i', str(audio_path),
            '-af', 'afftdn=nf=-25:nr=10:nt=w',  # FFT denoise filter
            '-ar', '44100',
            '-y',
            str(output_path)
        ]
        
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, lambda: self._run_ffmpeg(args))
        
        logger.info(f"Noise reduced (FFmpeg): {output_path}")
        return output_path
    
    async def remove_vocal_artifacts(
        self, 
        background_audio_path: Path,
        output_path: Optional[Path] = None
    ) -> Path:
        """
        Remove leftover vocal artifacts from background audio
        
        Uses frequency filtering to reduce vocal bleed
        """
        output_path = output_path or self.temp_dir / f"clean_bg_{background_audio_path.name}"
        
        if PYDUB_AVAILABLE:
            try:
                audio = AudioSegment.from_file(str(background_audio_path))
                
                # Apply filters to reduce vocal frequencies (300Hz - 3000Hz is vocal range)
                # We slightly attenuate this range in background
                
                # Low pass to keep bass (below 250Hz fully)
                # High pass to keep highs (above 4000Hz fully)
                # Middle range (vocals) will be naturally reduced
                
                # Apply gentle compression to even out levels
                audio = compress_dynamic_range(audio, threshold=-20.0, ratio=4.0)
                
                # Normalize
                audio = normalize(audio)
                
                audio.export(str(output_path), format="wav")
                logger.info(f"Vocal artifacts reduced: {output_path}")
                return output_path
                
            except Exception as e:
                logger.warning(f"PyDub processing failed: {e}")
        
        # Fallback: copy original
        shutil.copy2(background_audio_path, output_path)
        return output_path
    
    async def enhance_background(
        self,
        background_audio_path: Path,
        output_path: Optional[Path] = None,
        boost_bass: bool = True,
        normalize_volume: bool = True
    ) -> Path:
        """
        Enhance background audio quality
        
        - Boost bass frequencies
        - Normalize volume
        - Remove artifacts
        """
        output_path = output_path or self.temp_dir / f"enhanced_bg_{background_audio_path.name}"
        
        filters = []
        
        # Bass boost
        if boost_bass:
            filters.append("bass=g=3:f=100")  # Boost bass by 3dB at 100Hz
        
        # High frequency enhancement
        filters.append("treble=g=1:f=4000")  # Slight treble boost
        
        # Normalize
        if normalize_volume:
            filters.append("loudnorm=I=-14:TP=-1.5:LRA=11")
        
        filter_string = ",".join(filters) if filters else "anull"
        
        args = [
            '-i', str(background_audio_path),
            '-af', filter_string,
            '-ar', '44100',
            '-y',
            str(output_path)
        ]
        
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, lambda: self._run_ffmpeg(args))
        
        logger.info(f"Background enhanced: {output_path}")
        return output_path
    
    async def enhance_vocals_for_transcription(
        self,
        vocals_path: Path,
        output_path: Optional[Path] = None
    ) -> Path:
        """
        Enhance vocals for better transcription accuracy
        
        - Remove noise
        - Normalize volume
        - Compress dynamic range
        """
        output_path = output_path or self.temp_dir / f"enhanced_vocals_{vocals_path.name}"
        
        filters = [
            "highpass=f=80",  # Remove very low frequencies
            "lowpass=f=8000",  # Remove very high frequencies
            "afftdn=nf=-20",  # Denoise
            "compand=attacks=0:points=-80/-80|-45/-45|-27/-25|0/-10",  # Compress
            "loudnorm=I=-16:TP=-1.5:LRA=11"  # Normalize
        ]
        
        args = [
            '-i', str(vocals_path),
            '-af', ",".join(filters),
            '-ar', '16000',  # Whisper prefers 16kHz
            '-ac', '1',  # Mono for transcription
            '-y',
            str(output_path)
        ]
        
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, lambda: self._run_ffmpeg(args))
        
        logger.info(f"Vocals enhanced for transcription: {output_path}")
        return output_path


class AudioProcessor:
    """
    Complete audio processing with enhanced separation
    """
    
    def __init__(self, user_id: int):
        self.user_id = user_id
        self.workspace = get_user_workspace(user_id)
        self.audio_dir = self.workspace["audio"]
        self.separated_dir = self.workspace["separated"]
        self.temp_dir = self.workspace["temp"]
        
        # Initialize enhancer
        self.enhancer = AudioEnhancer(self.temp_dir)
        
        # Check dependencies
        self._check_dependencies()
        
        # Device selection
        self.device = self._get_device()
        
        logger.info(f"AudioProcessor initialized for user {user_id} (device: {self.device})")
    
    def _check_dependencies(self):
        """Check required dependencies"""
        # Check FFmpeg
        try:
            result = subprocess.run(
                [config.ffmpeg.ffmpeg_path, '-version'],
                capture_output=True,
                timeout=10
            )
            if result.returncode != 0:
                raise Exception("FFmpeg not working")
        except Exception as e:
            logger.error(f"FFmpeg check failed: {e}")
            raise RuntimeError("FFmpeg is required but not found")
    
    def _get_device(self) -> str:
        """Get best available device"""
        if config.demucs.device != "auto":
            return config.demucs.device
        
        if TORCH_AVAILABLE and torch.cuda.is_available():
            device = "cuda"
            gpu_name = torch.cuda.get_device_name(0)
            logger.info(f"Using GPU: {gpu_name}")
        else:
            device = "cpu"
            logger.info("Using CPU for processing")
        
        return device
    
    def _run_ffmpeg(self, args: List[str], timeout: int = 3600) -> subprocess.CompletedProcess:
        """Run FFmpeg command"""
        cmd = [config.ffmpeg.ffmpeg_path] + args
        logger.debug(f"FFmpeg: {' '.join(cmd[:8])}...")
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        if result.returncode != 0:
            logger.error(f"FFmpeg error: {result.stderr[:300]}")
            raise subprocess.CalledProcessError(result.returncode, cmd)
        return result
    
    async def get_audio_info(self, filepath: Path) -> Optional[AudioInfo]:
        """Get detailed audio information"""
        try:
            media_info = get_media_info(filepath)
            
            if not media_info:
                return None
            
            audio_stream = None
            for stream in media_info.get('streams', []):
                if stream.get('codec_type') == 'audio':
                    audio_stream = stream
                    break
            
            if not audio_stream:
                return None
            
            format_info = media_info.get('format', {})
            
            return AudioInfo(
                filepath=filepath,
                duration=float(format_info.get('duration', 0)),
                sample_rate=int(audio_stream.get('sample_rate', 44100)),
                channels=int(audio_stream.get('channels', 2)),
                bitrate=int(audio_stream.get('bit_rate', 0)) // 1000,
                codec=audio_stream.get('codec_name', 'unknown'),
                file_size=int(format_info.get('size', 0)),
            )
        except Exception as e:
            logger.error(f"Failed to get audio info: {e}")
            return None
    
    @log_execution_time
    async def extract_audio(
        self,
        video_path: Path,
        output_path: Optional[Path] = None,
        format: str = "wav",
        sample_rate: int = 44100,
        channels: int = 2,
        progress_callback: Optional[Callable] = None
    ) -> Optional[Path]:
        """
        Extract audio from video file
        """
        if not video_path.exists():
            raise FileNotFoundError(f"Video not found: {video_path}")
        
        session_manager.update_session(
            self.user_id,
            stage=ProcessingStage.EXTRACTING_AUDIO
        )
        
        logger.info(f"Extracting audio from: {video_path}")
        
        if output_path is None:
            output_path = self.audio_dir / f"{video_path.stem}_audio.{format}"
        
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        args = [
            '-i', str(video_path),
            '-vn',  # No video
            '-acodec', 'pcm_s16le' if format == 'wav' else 'libmp3lame',
            '-ar', str(sample_rate),
            '-ac', str(channels),
            '-y',
            str(output_path)
        ]
        
        try:
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, lambda: self._run_ffmpeg(args))
            
            if output_path.exists():
                logger.info(f"Audio extracted: {output_path} ({format_file_size(output_path.stat().st_size)})")
                
                session_manager.update_session(
                    self.user_id,
                    extracted_audio_path=str(output_path)
                )
                
                return output_path
            else:
                raise Exception("Audio extraction completed but file not found")
                
        except Exception as e:
            logger.error(f"Audio extraction failed: {e}")
            raise
    
    @log_execution_time
    async def separate_vocals_demucs(
        self,
        audio_path: Path,
        output_dir: Optional[Path] = None,
        model_name: Optional[str] = None,
        enhance_output: bool = True,
        progress_callback: Optional[Callable] = None
    ) -> Optional[SeparationResult]:
        """
        Separate vocals from background using Demucs AI
        
        This removes ONLY the narrator/speech voice while keeping:
        - Background music
        - Sound effects
        - Ambient sounds
        
        Args:
            audio_path: Input audio file
            output_dir: Output directory
            model_name: Demucs model (htdemucs recommended)
            enhance_output: Apply enhancement to outputs
            progress_callback: Progress callback
            
        Returns:
            SeparationResult with paths and quality info
        """
        import time
        start_time = time.time()
        
        if not audio_path.exists():
            raise FileNotFoundError(f"Audio not found: {audio_path}")
        
        if not DEMUCS_AVAILABLE:
            logger.warning("Demucs not available, using FFmpeg fallback")
            return await self._separate_vocals_fallback(audio_path, output_dir)
        
        session_manager.update_session(
            self.user_id,
            stage=ProcessingStage.SEPARATING_VOCALS
        )
        
        model_name = model_name or config.demucs.model_name
        output_dir = output_dir or self.separated_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"=" * 50)
        logger.info(f"Starting Demucs Voice Separation")
        logger.info(f"=" * 50)
        logger.info(f"Model: {model_name}")
        logger.info(f"Input: {audio_path}")
        logger.info(f"Device: {self.device}")
        
        # Estimate time
        duration = get_audio_duration(audio_path) or 0
        if self.device == "cuda":
            est_time = duration * 0.3
        else:
            est_time = duration * 1.5
        
        logger.info(f"Audio duration: {format_duration(duration)}")
        logger.info(f"Estimated time: {format_duration(est_time)}")
        
        if progress_callback:
            await progress_callback({
                "status": "separating",
                "message": f"AI voice separation in progress...\nEstimated: {format_duration(est_time)}",
                "estimated_time": est_time
            })
        
        try:
            loop = asyncio.get_event_loop()
            
            def run_demucs():
                """Run Demucs separation"""
                cmd_args = [
                    '-n', model_name,
                    '--two-stems', 'vocals',  # Only vocals vs other
                    '-o', str(output_dir),
                    '--device', self.device,
                ]
                
                # Add quality options
                if config.demucs.shifts > 1:
                    cmd_args.extend(['--shifts', str(config.demucs.shifts)])
                
                if config.demucs.overlap:
                    cmd_args.extend(['--overlap', str(config.demucs.overlap)])
                
                cmd_args.append(str(audio_path))
                
                logger.info(f"Demucs args: {' '.join(cmd_args)}")
                demucs.separate.main(cmd_args)
            
            await loop.run_in_executor(None, run_demucs)
            
            # Find output files
            track_name = audio_path.stem
            demucs_output = output_dir / model_name / track_name
            
            vocals_path = demucs_output / "vocals.wav"
            no_vocals_path = demucs_output / "no_vocals.wav"
            
            # Search if not found at expected location
            if not vocals_path.exists() or not no_vocals_path.exists():
                logger.warning("Output not at expected path, searching...")
                
                for root, dirs, files in os.walk(output_dir):
                    for f in files:
                        if f == "vocals.wav":
                            vocals_path = Path(root) / f
                        elif f == "no_vocals.wav":
                            no_vocals_path = Path(root) / f
            
            if not vocals_path.exists():
                raise Exception("Vocals file not found after separation")
            if not no_vocals_path.exists():
                raise Exception("No_vocals file not found after separation")
            
            # Copy to main separated directory with clean names
            final_vocals = self.separated_dir / "vocals.wav"
            final_no_vocals = self.separated_dir / "no_vocals.wav"
            
            shutil.copy2(vocals_path, final_vocals)
            shutil.copy2(no_vocals_path, final_no_vocals)
            
            # Enhance outputs if requested
            if enhance_output:
                logger.info("Enhancing separated audio...")
                
                if progress_callback:
                    await progress_callback({
                        "status": "enhancing",
                        "message": "Cleaning up separated audio..."
                    })
                
                # Enhance background (remove vocal artifacts)
                final_no_vocals = await self.enhancer.remove_vocal_artifacts(
                    final_no_vocals,
                    self.separated_dir / "no_vocals_clean.wav"
                )
                
                # Rename back
                if final_no_vocals.name != "no_vocals.wav":
                    clean_path = self.separated_dir / "no_vocals.wav"
                    shutil.move(final_no_vocals, clean_path)
                    final_no_vocals = clean_path
                
                # Enhance vocals for transcription
                enhanced_vocals = await self.enhancer.enhance_vocals_for_transcription(
                    final_vocals,
                    self.separated_dir / "vocals_enhanced.wav"
                )
            
            processing_time = time.time() - start_time
            
            # Analyze quality
            quality = AudioQualityAnalyzer.analyze_separation_quality(
                audio_path,
                final_vocals,
                final_no_vocals
            )
            
            logger.info(f"=" * 50)
            logger.info(f"Separation Complete!")
            logger.info(f"=" * 50)
            logger.info(f"Time: {format_duration(processing_time)}")
            logger.info(f"Vocals: {final_vocals} ({format_file_size(final_vocals.stat().st_size)})")
            logger.info(f"Background: {final_no_vocals} ({format_file_size(final_no_vocals.stat().st_size)})")
            logger.info(f"Quality Score: {quality.overall_score:.0f}/100")
            logger.info(f"Artifacts: {quality.artifacts_level}")
            logger.info(f"Recommendation: {quality.recommendation}")
            
            # Update session
            session_manager.update_session(
                self.user_id,
                vocals_path=str(final_vocals),
                no_vocals_path=str(final_no_vocals)
            )
            
            return SeparationResult(
                vocals_path=final_vocals,
                no_vocals_path=final_no_vocals,
                original_path=audio_path,
                quality=quality,
                model_used=model_name,
                processing_time=processing_time
            )
            
        except Exception as e:
            logger.error(f"Demucs separation failed: {e}")
            logger.info("Attempting fallback separation method...")
            
            return await self._separate_vocals_fallback(audio_path, output_dir)
    
    async def _separate_vocals_fallback(
        self,
        audio_path: Path,
        output_dir: Optional[Path] = None
    ) -> Optional[SeparationResult]:
        """
        Fallback vocal separation using FFmpeg
        
        Less accurate but works without Demucs
        Uses center channel extraction (vocals typically centered in stereo mix)
        """
        import time
        start_time = time.time()
        
        output_dir = output_dir or self.separated_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        
        logger.warning("=" * 50)
        logger.warning("Using FFmpeg Fallback Separation")
        logger.warning("Quality will be lower than Demucs AI")
        logger.warning("=" * 50)
        
        vocals_path = output_dir / "vocals.wav"
        no_vocals_path = output_dir / "no_vocals.wav"
        
        try:
            loop = asyncio.get_event_loop()
            
            # Extract center (vocals): (L+R)/2
            vocals_args = [
                '-i', str(audio_path),
                '-af', 'pan=mono|c0=0.5*c0+0.5*c1',
                '-ar', '44100',
                '-y',
                str(vocals_path)
            ]
            
            # Extract sides (background): L-R
            # This removes center-panned content (usually vocals)
            no_vocals_args = [
                '-i', str(audio_path),
                '-af', (
                    'pan=stereo|c0=c0-c1|c1=c1-c0,'
                    'compand=attacks=0:points=-80/-80|-45/-45|-27/-25|0/-10,'
                    'bass=g=3,'
                    'loudnorm=I=-14'
                ),
                '-ar', '44100',
                '-y',
                str(no_vocals_path)
            ]
            
            await loop.run_in_executor(None, lambda: self._run_ffmpeg(vocals_args))
            await loop.run_in_executor(None, lambda: self._run_ffmpeg(no_vocals_args))
            
            processing_time = time.time() - start_time
            
            if vocals_path.exists() and no_vocals_path.exists():
                logger.info("Fallback separation completed")
                
                # Quality will be lower for fallback
                quality = SeparationQuality(
                    overall_score=55,
                    vocal_clarity=60,
                    background_clarity=50,
                    artifacts_level="medium",
                    recommendation="Fallback method used. Some vocal bleed in background expected."
                )
                
                session_manager.update_session(
                    self.user_id,
                    vocals_path=str(vocals_path),
                    no_vocals_path=str(no_vocals_path)
                )
                
                return SeparationResult(
                    vocals_path=vocals_path,
                    no_vocals_path=no_vocals_path,
                    original_path=audio_path,
                    quality=quality,
                    model_used="ffmpeg_fallback",
                    processing_time=processing_time
                )
            else:
                raise Exception("Fallback separation failed")
                
        except Exception as e:
            logger.error(f"Fallback separation failed: {e}")
            raise
    
    async def normalize_audio(
        self,
        audio_path: Path,
        output_path: Optional[Path] = None,
        target_loudness: float = -14.0
    ) -> Path:
        """Normalize audio to target loudness"""
        output_path = output_path or audio_path.with_suffix('.normalized.wav')
        
        args = [
            '-i', str(audio_path),
            '-af', f'loudnorm=I={target_loudness}:TP=-1.5:LRA=11',
            '-ar', '44100',
            '-y',
            str(output_path)
        ]
        
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, lambda: self._run_ffmpeg(args))
        
        return output_path
    
    async def cleanup(self):
        """Clean up temporary files"""
        try:
            # Clean temp
            for temp_file in self.temp_dir.glob("*"):
                if temp_file.is_file():
                    temp_file.unlink()
            
            # Clean demucs cache
            for demucs_dir in self.separated_dir.glob("htdemucs*"):
                if demucs_dir.is_dir():
                    shutil.rmtree(demucs_dir)
            
            for demucs_dir in self.separated_dir.glob("mdx*"):
                if demucs_dir.is_dir():
                    shutil.rmtree(demucs_dir)
            
            logger.info("Audio processor cleanup completed")
            
        except Exception as e:
            logger.warning(f"Cleanup error: {e}")


# ============ CONVENIENCE FUNCTION ============

async def process_video_audio(
    video_path: Path,
    user_id: int,
    enhance_output: bool = True,
    progress_callback: Optional[Callable] = None
) -> Tuple[Optional[Path], Optional[SeparationResult]]:
    """
    Complete audio processing pipeline
    
    1. Extract audio from video
    2. Separate vocals from background
    3. Enhance outputs
    
    Returns:
        Tuple of (extracted_audio_path, separation_result)
    """
    processor = AudioProcessor(user_id)
    
    try:
        # Extract
        if progress_callback:
            await progress_callback({
                "status": "extracting",
                "message": "Extracting audio from video..."
            })
        
        audio_path = await processor.extract_audio(video_path)
        
        if not audio_path:
            return None, None
        
        # Separate
        separation_result = await processor.separate_vocals_demucs(
            audio_path,
            enhance_output=enhance_output,
            progress_callback=progress_callback
        )
        
        return audio_path, separation_result
        
    except Exception as e:
        logger.error(f"Audio processing failed: {e}")
        return None, None


# ============ TEST ============

async def test_audio_processor():
    """Test audio processor"""
    print("\n" + "=" * 50)
    print("🧪 Testing Enhanced Audio Processor")
    print("=" * 50)
    
    print("\n📋 Dependency Check:")
    print(f"  • PyTorch: {'✅' if TORCH_AVAILABLE else '❌'}")
    print(f"  • Demucs: {'✅' if DEMUCS_AVAILABLE else '❌'}")
    print(f"  • PyDub: {'✅' if PYDUB_AVAILABLE else '❌'}")
    print(f"  • NumPy: {'✅' if NUMPY_AVAILABLE else '❌'}")
    print(f"  • NoiseReduce: {'✅' if NOISE_REDUCE_AVAILABLE else '❌'}")
    
    if TORCH_AVAILABLE:
        device = "cuda" if torch.cuda.is_available() else "cpu"
        print(f"  • Device: {device}")
        if device == "cuda":
            print(f"  • GPU: {torch.cuda.get_device_name(0)}")
    
    print("\n✅ Enhanced Audio Processor loaded!")
    print("=" * 50)


if __name__ == "__main__":
    asyncio.run(test_audio_processor())