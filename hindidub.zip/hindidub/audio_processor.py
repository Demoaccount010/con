"""
Audio Processing Module
Hindi Dubbing Bot - Telegram Integrated

Handles:
- Audio extraction from video using FFmpeg
- Voice separation using Demucs AI
- Audio normalization and processing
"""

import os
import asyncio
import subprocess
import shutil
from pathlib import Path
from typing import Optional, Dict, Any, Callable, Tuple, List
from dataclasses import dataclass
import tempfile
import json

try:
    import torch
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False

try:
    import demucs.separate
    from demucs.pretrained import get_model
    from demucs.apply import apply_model
    DEMUCS_AVAILABLE = True
except ImportError:
    DEMUCS_AVAILABLE = False

try:
    from pydub import AudioSegment
    from pydub.effects import normalize, compress_dynamic_range
    PYDUB_AVAILABLE = True
except ImportError:
    PYDUB_AVAILABLE = False

from config import config, ProcessingStage
from utils import (
    logger,
    session_manager,
    format_file_size,
    format_duration,
    get_user_workspace,
    get_audio_duration,
    get_media_info,
    log_execution_time,
    handle_errors,
    AsyncProgressTracker,
)


@dataclass
class AudioInfo:
    """Audio file information"""
    filepath: Path
    duration: float
    sample_rate: int
    channels: int
    bitrate: int
    codec: str
    file_size: int
    
    def to_dict(self) -> Dict:
        return {
            "filepath": str(self.filepath),
            "duration": self.duration,
            "sample_rate": self.sample_rate,
            "channels": self.channels,
            "bitrate": self.bitrate,
            "codec": self.codec,
            "file_size": self.file_size,
        }


@dataclass
class SeparationResult:
    """Result of audio separation"""
    vocals_path: Path
    no_vocals_path: Path  # Background music + sound effects
    drums_path: Optional[Path] = None
    bass_path: Optional[Path] = None
    other_path: Optional[Path] = None
    
    def to_dict(self) -> Dict:
        return {
            "vocals_path": str(self.vocals_path),
            "no_vocals_path": str(self.no_vocals_path),
            "drums_path": str(self.drums_path) if self.drums_path else None,
            "bass_path": str(self.bass_path) if self.bass_path else None,
            "other_path": str(self.other_path) if self.other_path else None,
        }


class AudioProcessor:
    """
    Audio processing using FFmpeg and Demucs
    Handles extraction, separation, and processing
    """
    
    def __init__(self, user_id: int):
        self.user_id = user_id
        self.workspace = get_user_workspace(user_id)
        self.audio_dir = self.workspace["audio"]
        self.separated_dir = self.workspace["separated"]
        self.temp_dir = self.workspace["temp"]
        
        # Check dependencies
        self._check_dependencies()
        
        # Device selection for AI models
        self.device = self._get_device()
        
        logger.info(f"AudioProcessor initialized for user {user_id} (device: {self.device})")
    
    def _check_dependencies(self):
        """Check required dependencies"""
        if not PYDUB_AVAILABLE:
            logger.warning("pydub not available. Some features may be limited.")
        
        if not DEMUCS_AVAILABLE:
            logger.warning("demucs not available. Voice separation will use fallback method.")
        
        # Check FFmpeg
        try:
            result = subprocess.run(
                [config.ffmpeg.ffmpeg_path, '-version'],
                capture_output=True,
                timeout=10
            )
            if result.returncode != 0:
                raise Exception("FFmpeg not working properly")
        except Exception as e:
            logger.error(f"FFmpeg check failed: {e}")
            raise RuntimeError("FFmpeg is required but not found or not working")
    
    def _get_device(self) -> str:
        """Get the best available device for AI processing"""
        if config.demucs.device != "auto":
            return config.demucs.device
        
        if TORCH_AVAILABLE and torch.cuda.is_available():
            device = "cuda"
            gpu_name = torch.cuda.get_device_name(0)
            logger.info(f"Using GPU: {gpu_name}")
        else:
            device = "cpu"
            logger.info("Using CPU for processing")
        
        return device
    
    def _run_ffmpeg(
        self,
        args: List[str],
        timeout: int = 3600,
        progress_callback: Optional[Callable] = None
    ) -> subprocess.CompletedProcess:
        """
        Run FFmpeg command with proper error handling
        
        Args:
            args: FFmpeg arguments (without 'ffmpeg' at start)
            timeout: Command timeout in seconds
            progress_callback: Optional progress callback
            
        Returns:
            CompletedProcess result
        """
        cmd = [config.ffmpeg.ffmpeg_path] + args
        
        logger.debug(f"Running FFmpeg: {' '.join(cmd)}")
        
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            
            if result.returncode != 0:
                logger.error(f"FFmpeg error: {result.stderr}")
                raise subprocess.CalledProcessError(
                    result.returncode, cmd, result.stdout, result.stderr
                )
            
            return result
            
        except subprocess.TimeoutExpired:
            logger.error(f"FFmpeg timed out after {timeout}s")
            raise
        except Exception as e:
            logger.error(f"FFmpeg failed: {e}")
            raise
    
    async def get_audio_info(self, filepath: Path) -> Optional[AudioInfo]:
        """
        Get detailed audio information
        
        Args:
            filepath: Path to audio/video file
            
        Returns:
            AudioInfo object or None
        """
        try:
            media_info = get_media_info(filepath)
            
            if not media_info:
                return None
            
            # Find audio stream
            audio_stream = None
            for stream in media_info.get('streams', []):
                if stream.get('codec_type') == 'audio':
                    audio_stream = stream
                    break
            
            if not audio_stream:
                logger.warning(f"No audio stream found in {filepath}")
                return None
            
            # Get format info
            format_info = media_info.get('format', {})
            
            return AudioInfo(
                filepath=filepath,
                duration=float(format_info.get('duration', 0)),
                sample_rate=int(audio_stream.get('sample_rate', 44100)),
                channels=int(audio_stream.get('channels', 2)),
                bitrate=int(audio_stream.get('bit_rate', 0)) // 1000,  # kbps
                codec=audio_stream.get('codec_name', 'unknown'),
                file_size=int(format_info.get('size', 0)),
            )
            
        except Exception as e:
            logger.error(f"Failed to get audio info: {e}")
            return None
    
    @log_execution_time
    async def extract_audio(
        self,
        video_path: Path,
        output_path: Optional[Path] = None,
        format: str = "wav",
        sample_rate: int = 44100,
        channels: int = 2,
        progress_callback: Optional[Callable] = None
    ) -> Optional[Path]:
        """
        Extract audio from video file using FFmpeg
        
        Args:
            video_path: Path to input video
            output_path: Optional output path (auto-generated if None)
            format: Output format (wav, mp3, etc.)
            sample_rate: Output sample rate
            channels: Number of output channels
            progress_callback: Optional progress callback
            
        Returns:
            Path to extracted audio file
        """
        if not video_path.exists():
            raise FileNotFoundError(f"Video not found: {video_path}")
        
        # Update session
        session_manager.update_session(
            self.user_id,
            stage=ProcessingStage.EXTRACTING_AUDIO
        )
        
        logger.info(f"Extracting audio from: {video_path}")
        
        # Generate output path
        if output_path is None:
            output_path = self.audio_dir / f"{video_path.stem}_audio.{format}"
        
        # Ensure output directory exists
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        # FFmpeg arguments
        args = [
            '-i', str(video_path),
            '-vn',  # No video
            '-acodec', 'pcm_s16le' if format == 'wav' else 'libmp3lame',
            '-ar', str(sample_rate),
            '-ac', str(channels),
            '-y',  # Overwrite output
            str(output_path)
        ]
        
        try:
            # Run in executor to avoid blocking
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, lambda: self._run_ffmpeg(args))
            
            if output_path.exists():
                file_size = output_path.stat().st_size
                logger.info(f"Audio extracted: {output_path} ({format_file_size(file_size)})")
                
                # Update session
                session_manager.update_session(
                    self.user_id,
                    extracted_audio_path=str(output_path)
                )
                
                return output_path
            else:
                raise Exception("Audio extraction completed but file not found")
                
        except Exception as e:
            logger.error(f"Audio extraction failed: {e}")
            raise
    
    @log_execution_time
    async def separate_vocals_demucs(
        self,
        audio_path: Path,
        output_dir: Optional[Path] = None,
        model_name: Optional[str] = None,
        progress_callback: Optional[Callable] = None
    ) -> Optional[SeparationResult]:
        """
        Separate vocals from background using Demucs AI
        
        This is the MAIN vocal separation function.
        Separates audio into:
        - vocals.wav (English narration/voice)
        - no_vocals.wav (background music + sound effects)
        
        Args:
            audio_path: Path to input audio file
            output_dir: Output directory for separated files
            model_name: Demucs model name (default: htdemucs)
            progress_callback: Optional progress callback
            
        Returns:
            SeparationResult with paths to separated audio files
        """
        if not audio_path.exists():
            raise FileNotFoundError(f"Audio not found: {audio_path}")
        
        if not DEMUCS_AVAILABLE:
            logger.warning("Demucs not available, using FFmpeg fallback")
            return await self._separate_vocals_fallback(audio_path, output_dir)
        
        # Update session
        session_manager.update_session(
            self.user_id,
            stage=ProcessingStage.SEPARATING_VOCALS
        )
        
        model_name = model_name or config.demucs.model_name
        output_dir = output_dir or self.separated_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"Starting vocal separation with Demucs ({model_name})")
        logger.info(f"Input: {audio_path}")
        logger.info(f"Device: {self.device}")
        
        # Estimate processing time
        duration = get_audio_duration(audio_path) or 0
        if self.device == "cuda":
            est_time = duration * 0.3  # ~0.3x realtime on GPU
        else:
            est_time = duration * 2  # ~2x realtime on CPU
        
        logger.info(f"Estimated processing time: {format_duration(est_time)}")
        
        try:
            # Run Demucs separation
            loop = asyncio.get_event_loop()
            
            def run_demucs():
                """Run Demucs in a separate thread"""
                # Build demucs command arguments
                cmd_args = [
                    '-n', model_name,
                    '--two-stems', 'vocals',  # Only separate vocals vs rest
                    '-o', str(output_dir),
                    '--device', self.device,
                    str(audio_path)
                ]
                
                if config.demucs.shifts > 1:
                    cmd_args.extend(['--shifts', str(config.demucs.shifts)])
                
                if config.demucs.overlap:
                    cmd_args.extend(['--overlap', str(config.demucs.overlap)])
                
                # Use demucs.separate main function
                demucs.separate.main(cmd_args)
            
            # Execute in thread pool
            if progress_callback:
                await progress_callback({
                    "status": "separating",
                    "message": "AI vocal separation in progress...",
                    "estimated_time": format_duration(est_time)
                })
            
            await loop.run_in_executor(None, run_demucs)
            
            # Find output files
            # Demucs creates: output_dir/model_name/track_name/vocals.wav, no_vocals.wav
            track_name = audio_path.stem
            demucs_output = output_dir / model_name / track_name
            
            vocals_path = demucs_output / "vocals.wav"
            no_vocals_path = demucs_output / "no_vocals.wav"
            
            # Check if files exist
            if not vocals_path.exists() or not no_vocals_path.exists():
                # Try alternative structure
                for subdir in output_dir.iterdir():
                    if subdir.is_dir():
                        for track_dir in subdir.iterdir():
                            if track_dir.is_dir():
                                v_path = track_dir / "vocals.wav"
                                nv_path = track_dir / "no_vocals.wav"
                                if v_path.exists():
                                    vocals_path = v_path
                                if nv_path.exists():
                                    no_vocals_path = nv_path
            
            if not vocals_path.exists():
                raise Exception("Vocals file not found after separation")
            
            if not no_vocals_path.exists():
                raise Exception("No_vocals file not found after separation")
            
            # Move files to expected location
            final_vocals = self.separated_dir / "vocals.wav"
            final_no_vocals = self.separated_dir / "no_vocals.wav"
            
            shutil.copy2(vocals_path, final_vocals)
            shutil.copy2(no_vocals_path, final_no_vocals)
            
            logger.info(f"Vocals saved: {final_vocals} ({format_file_size(final_vocals.stat().st_size)})")
            logger.info(f"No-vocals saved: {final_no_vocals} ({format_file_size(final_no_vocals.stat().st_size)})")
            
            # Update session
            session_manager.update_session(
                self.user_id,
                vocals_path=str(final_vocals),
                no_vocals_path=str(final_no_vocals)
            )
            
            result = SeparationResult(
                vocals_path=final_vocals,
                no_vocals_path=final_no_vocals
            )
            
            return result
            
        except Exception as e:
            logger.error(f"Demucs separation failed: {e}")
            
            # Try fallback method
            logger.info("Attempting fallback separation method...")
            return await self._separate_vocals_fallback(audio_path, output_dir)
    
    async def _separate_vocals_fallback(
        self,
        audio_path: Path,
        output_dir: Optional[Path] = None
    ) -> Optional[SeparationResult]:
        """
        Fallback vocal separation using FFmpeg filters
        Less accurate than Demucs but doesn't require AI model
        
        Uses center channel extraction (vocals are usually centered)
        """
        output_dir = output_dir or self.separated_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        
        logger.warning("Using FFmpeg fallback for vocal separation (less accurate)")
        
        vocals_path = output_dir / "vocals.wav"
        no_vocals_path = output_dir / "no_vocals.wav"
        
        try:
            # Extract center channel (approximate vocals)
            # This uses the "vocal remover" technique: L-R gives background, L+R gives vocals
            
            # For vocals (center): pan=mono|c0=0.5*c0+0.5*c1
            vocals_args = [
                '-i', str(audio_path),
                '-af', 'pan=mono|c0=0.5*c0+0.5*c1',
                '-ar', '44100',
                '-y',
                str(vocals_path)
            ]
            
            # For background (sides): pan=stereo|c0=c0-c1|c1=c1-c0
            # This cancels center-panned sounds
            no_vocals_args = [
                '-i', str(audio_path),
                '-af', 'pan=stereo|c0=c0-c1|c1=c1-c0,acompressor=threshold=-20dB:ratio=4:attack=5:release=100',
                '-ar', '44100',
                '-y',
                str(no_vocals_path)
            ]
            
            loop = asyncio.get_event_loop()
            
            await loop.run_in_executor(None, lambda: self._run_ffmpeg(vocals_args))
            await loop.run_in_executor(None, lambda: self._run_ffmpeg(no_vocals_args))
            
            if vocals_path.exists() and no_vocals_path.exists():
                logger.info("Fallback separation completed")
                
                # Update session
                session_manager.update_session(
                    self.user_id,
                    vocals_path=str(vocals_path),
                    no_vocals_path=str(no_vocals_path)
                )
                
                return SeparationResult(
                    vocals_path=vocals_path,
                    no_vocals_path=no_vocals_path
                )
            else:
                raise Exception("Fallback separation failed")
                
        except Exception as e:
            logger.error(f"Fallback separation failed: {e}")
            raise
    
    async def normalize_audio(
        self,
        audio_path: Path,
        output_path: Optional[Path] = None,
        target_loudness: float = -14.0
    ) -> Path:
        """
        Normalize audio to target loudness
        
        Args:
            audio_path: Input audio path
            output_path: Output path (overwrites input if None)
            target_loudness: Target loudness in LUFS
            
        Returns:
            Path to normalized audio
        """
        if not audio_path.exists():
            raise FileNotFoundError(f"Audio not found: {audio_path}")
        
        output_path = output_path or audio_path.with_suffix('.normalized.wav')
        
        logger.info(f"Normalizing audio to {target_loudness} LUFS")
        
        # Use FFmpeg loudnorm filter
        args = [
            '-i', str(audio_path),
            '-af', f'loudnorm=I={target_loudness}:TP=-1.5:LRA=11',
            '-ar', '44100',
            '-y',
            str(output_path)
        ]
        
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, lambda: self._run_ffmpeg(args))
        
        if output_path.exists():
            logger.info(f"Audio normalized: {output_path}")
            return output_path
        else:
            raise Exception("Normalization failed")
    
    async def convert_audio_format(
        self,
        input_path: Path,
        output_format: str = "wav",
        sample_rate: int = 44100,
        channels: int = 2
    ) -> Path:
        """
        Convert audio to different format
        
        Args:
            input_path: Input audio path
            output_format: Output format (wav, mp3, etc.)
            sample_rate: Output sample rate
            channels: Number of channels
            
        Returns:
            Path to converted audio
        """
        if not input_path.exists():
            raise FileNotFoundError(f"Audio not found: {input_path}")
        
        output_path = input_path.with_suffix(f'.{output_format}')
        
        codec = 'pcm_s16le' if output_format == 'wav' else 'libmp3lame'
        
        args = [
            '-i', str(input_path),
            '-acodec', codec,
            '-ar', str(sample_rate),
            '-ac', str(channels),
            '-y',
            str(output_path)
        ]
        
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, lambda: self._run_ffmpeg(args))
        
        if output_path.exists():
            logger.info(f"Audio converted: {output_path}")
            return output_path
        else:
            raise Exception("Conversion failed")
    
    async def trim_audio(
        self,
        audio_path: Path,
        start_time: float,
        end_time: float,
        output_path: Optional[Path] = None
    ) -> Path:
        """
        Trim audio to specific time range
        
        Args:
            audio_path: Input audio path
            start_time: Start time in seconds
            end_time: End time in seconds
            output_path: Optional output path
            
        Returns:
            Path to trimmed audio
        """
        if not audio_path.exists():
            raise FileNotFoundError(f"Audio not found: {audio_path}")
        
        output_path = output_path or self.temp_dir / f"trimmed_{audio_path.name}"
        
        args = [
            '-i', str(audio_path),
            '-ss', str(start_time),
            '-to', str(end_time),
            '-acodec', 'copy',
            '-y',
            str(output_path)
        ]
        
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, lambda: self._run_ffmpeg(args))
        
        if output_path.exists():
            return output_path
        else:
            raise Exception("Trimming failed")
    
    async def adjust_volume(
        self,
        audio_path: Path,
        volume_factor: float = 1.0,
        output_path: Optional[Path] = None
    ) -> Path:
        """
        Adjust audio volume
        
        Args:
            audio_path: Input audio path
            volume_factor: Volume multiplier (1.0 = no change)
            output_path: Optional output path
            
        Returns:
            Path to adjusted audio
        """
        if not audio_path.exists():
            raise FileNotFoundError(f"Audio not found: {audio_path}")
        
        output_path = output_path or audio_path.with_suffix('.vol.wav')
        
        args = [
            '-i', str(audio_path),
            '-af', f'volume={volume_factor}',
            '-y',
            str(output_path)
        ]
        
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, lambda: self._run_ffmpeg(args))
        
        if output_path.exists():
            return output_path
        else:
            raise Exception("Volume adjustment failed")
    
    async def cleanup(self):
        """Clean up temporary files"""
        try:
            # Clean temp directory
            for temp_file in self.temp_dir.glob("*"):
                if temp_file.is_file():
                    temp_file.unlink()
            
            # Clean demucs intermediate files
            demucs_dirs = list(self.separated_dir.glob("htdemucs*"))
            demucs_dirs.extend(self.separated_dir.glob("mdx*"))
            
            for demucs_dir in demucs_dirs:
                if demucs_dir.is_dir():
                    shutil.rmtree(demucs_dir)
                    
            logger.info("Audio processor cleanup completed")
            
        except Exception as e:
            logger.warning(f"Cleanup error: {e}")


# Convenience function
async def process_video_audio(
    video_path: Path,
    user_id: int,
    progress_callback: Optional[Callable] = None
) -> Tuple[Optional[Path], Optional[SeparationResult]]:
    """
    Complete audio processing pipeline:
    1. Extract audio from video
    2. Separate vocals from background
    
    Args:
        video_path: Path to video file
        user_id: User ID
        progress_callback: Optional progress callback
        
    Returns:
        Tuple of (extracted_audio_path, separation_result)
    """
    processor = AudioProcessor(user_id)
    
    try:
        # Extract audio
        if progress_callback:
            await progress_callback({
                "status": "extracting",
                "message": "Extracting audio from video..."
            })
        
        audio_path = await processor.extract_audio(video_path)
        
        if not audio_path:
            return None, None
        
        # Separate vocals
        if progress_callback:
            await progress_callback({
                "status": "separating",
                "message": "Separating vocals using AI (this may take a while)..."
            })
        
        separation_result = await processor.separate_vocals_demucs(
            audio_path,
            progress_callback=progress_callback
        )
        
        return audio_path, separation_result
        
    except Exception as e:
        logger.error(f"Audio processing failed: {e}")
        return None, None


# Test function
async def test_audio_processor():
    """Test the audio processor module"""
    print("\n" + "=" * 50)
    print("🧪 Testing Audio Processor")
    print("=" * 50)
    
    # Check dependencies
    print("\n📋 Dependency Check:")
    print(f"  PyTorch: {'✅' if TORCH_AVAILABLE else '❌'}")
    print(f"  Demucs: {'✅' if DEMUCS_AVAILABLE else '❌'}")
    print(f"  PyDub: {'✅' if PYDUB_AVAILABLE else '❌'}")
    
    if TORCH_AVAILABLE:
        print(f"  CUDA: {'✅ ' + torch.cuda.get_device_name(0) if torch.cuda.is_available() else '❌ (CPU mode)'}")
    
    print("\n✅ Audio processor module loaded successfully!")
    print("=" * 50)


if __name__ == "__main__":
    asyncio.run(test_audio_processor())