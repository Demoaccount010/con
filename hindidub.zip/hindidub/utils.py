"""
Utility Functions, Logging, and Helper Classes
Hindi Dubbing Bot - Telegram Integrated
"""

import os
import sys
import logging
import asyncio
import hashlib
import shutil
import json
import re
import subprocess
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, Callable, List, Tuple, Union
from functools import wraps
import time
import traceback

# For progress tracking
try:
    from tqdm import tqdm
except ImportError:
    tqdm = None

from config import (
    config, 
    ProcessingStage, 
    UserSession, 
    STAGE_EMOJI,
    QualityPreset
)


# ==================== LOGGING SETUP ====================

class ColoredFormatter(logging.Formatter):
    """Custom formatter with colors for console output"""
    
    COLORS = {
        'DEBUG': '\033[36m',     # Cyan
        'INFO': '\033[32m',      # Green
        'WARNING': '\033[33m',   # Yellow
        'ERROR': '\033[31m',     # Red
        'CRITICAL': '\033[35m',  # Magenta
        'RESET': '\033[0m',      # Reset
    }
    
    def format(self, record):
        color = self.COLORS.get(record.levelname, self.COLORS['RESET'])
        reset = self.COLORS['RESET']
        
        # Add color to levelname
        record.levelname = f"{color}{record.levelname}{reset}"
        
        return super().format(record)


def setup_logging(
    log_level: str = "INFO",
    log_file: Optional[str] = None,
    console_output: bool = True
) -> logging.Logger:
    """Setup logging configuration"""
    
    # Create logger
    logger = logging.getLogger("HindiDubbingBot")
    logger.setLevel(getattr(logging, log_level.upper()))
    logger.handlers = []  # Clear existing handlers
    
    # Log format
    file_format = logging.Formatter(
        '%(asctime)s | %(levelname)-8s | %(name)s | %(funcName)s:%(lineno)d | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    console_format = ColoredFormatter(
        '%(asctime)s | %(levelname)-8s | %(message)s',
        datefmt='%H:%M:%S'
    )
    
    # Console handler
    if console_output:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.DEBUG if config.debug_mode else logging.INFO)
        console_handler.setFormatter(console_format)
        logger.addHandler(console_handler)
    
    # File handler
    if log_file:
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(file_format)
        logger.addHandler(file_handler)
    
    return logger


# Initialize default logger
log_file = config.paths.logs_dir / f"bot_{datetime.now().strftime('%Y%m%d')}.log"
logger = setup_logging(
    log_level="DEBUG" if config.debug_mode else "INFO",
    log_file=str(log_file)
)


# ==================== SESSION MANAGEMENT ====================

class SessionManager:
    """Manage user sessions with persistence"""
    
    def __init__(self, sessions_dir: Path):
        self.sessions_dir = sessions_dir
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self.active_sessions: Dict[int, UserSession] = {}
        self._load_all_sessions()
    
    def _get_session_file(self, user_id: int) -> Path:
        """Get session file path for user"""
        return self.sessions_dir / f"session_{user_id}.json"
    
    def _load_all_sessions(self):
        """Load all existing sessions from disk"""
        for session_file in self.sessions_dir.glob("session_*.json"):
            try:
                with open(session_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    session = UserSession.from_dict(data)
                    self.active_sessions[session.user_id] = session
            except Exception as e:
                logger.error(f"Failed to load session {session_file}: {e}")
    
    def get_session(self, user_id: int, username: Optional[str] = None) -> UserSession:
        """Get or create session for user"""
        if user_id not in self.active_sessions:
            session = UserSession(
                user_id=user_id,
                username=username,
                created_at=datetime.now().isoformat()
            )
            self.active_sessions[user_id] = session
            self.save_session(user_id)
            logger.info(f"Created new session for user {user_id}")
        
        return self.active_sessions[user_id]
    
    def save_session(self, user_id: int):
        """Save session to disk"""
        if user_id in self.active_sessions:
            session = self.active_sessions[user_id]
            session.updated_at = datetime.now().isoformat()
            
            session_file = self._get_session_file(user_id)
            with open(session_file, 'w', encoding='utf-8') as f:
                json.dump(session.to_dict(), f, indent=2, ensure_ascii=False)
    
    def update_session(
        self, 
        user_id: int, 
        stage: Optional[ProcessingStage] = None,
        **kwargs
    ):
        """Update session with new values"""
        session = self.get_session(user_id)
        
        if stage:
            session.current_stage = stage
        
        for key, value in kwargs.items():
            if hasattr(session, key):
                setattr(session, key, value)
        
        self.save_session(user_id)
    
    def reset_session(self, user_id: int):
        """Reset session to initial state"""
        if user_id in self.active_sessions:
            username = self.active_sessions[user_id].username
            self.active_sessions[user_id] = UserSession(
                user_id=user_id,
                username=username,
                created_at=datetime.now().isoformat()
            )
            self.save_session(user_id)
    
    def delete_session(self, user_id: int):
        """Delete session completely"""
        if user_id in self.active_sessions:
            del self.active_sessions[user_id]
        
        session_file = self._get_session_file(user_id)
        if session_file.exists():
            session_file.unlink()
    
    def get_processing_users(self) -> List[int]:
        """Get list of users currently processing"""
        processing_stages = [
            ProcessingStage.DOWNLOADING,
            ProcessingStage.EXTRACTING_AUDIO,
            ProcessingStage.SEPARATING_VOCALS,
            ProcessingStage.TRANSCRIBING,
            ProcessingStage.TRANSLATING,
            ProcessingStage.MERGING_AUDIO,
            ProcessingStage.CREATING_VIDEO,
        ]
        
        return [
            user_id for user_id, session in self.active_sessions.items()
            if session.current_stage in processing_stages
        ]


# Global session manager
session_manager = SessionManager(config.paths.sessions_dir)


# ==================== PROGRESS TRACKING ====================

class ProgressTracker:
    """Track and report progress for long operations"""
    
    def __init__(self, total: int = 100, description: str = "Processing"):
        self.total = total
        self.current = 0
        self.description = description
        self.start_time = time.time()
        self.callbacks: List[Callable] = []
    
    def update(self, amount: int = 1):
        """Update progress by amount"""
        self.current = min(self.current + amount, self.total)
        self._notify()
    
    def set_progress(self, value: int):
        """Set progress to specific value"""
        self.current = min(value, self.total)
        self._notify()
    
    @property
    def percentage(self) -> float:
        """Get progress as percentage"""
        return (self.current / self.total * 100) if self.total > 0 else 0
    
    @property
    def elapsed(self) -> float:
        """Get elapsed time in seconds"""
        return time.time() - self.start_time
    
    @property
    def eta(self) -> Optional[float]:
        """Estimate time remaining in seconds"""
        if self.current == 0:
            return None
        
        rate = self.current / self.elapsed
        remaining = self.total - self.current
        return remaining / rate if rate > 0 else None
    
    def get_progress_bar(self, width: int = 20) -> str:
        """Generate text progress bar"""
        filled = int(width * self.current / self.total) if self.total > 0 else 0
        bar = "█" * filled + "░" * (width - filled)
        return f"[{bar}] {self.percentage:.1f}%"
    
    def add_callback(self, callback: Callable):
        """Add callback for progress updates"""
        self.callbacks.append(callback)
    
    def _notify(self):
        """Notify all callbacks of progress update"""
        for callback in self.callbacks:
            try:
                callback(self)
            except Exception as e:
                logger.error(f"Progress callback error: {e}")


class AsyncProgressTracker(ProgressTracker):
    """Async version of progress tracker for Telegram updates"""
    
    def __init__(
        self, 
        total: int = 100, 
        description: str = "Processing",
        update_interval: float = 2.0  # Seconds between Telegram updates
    ):
        super().__init__(total, description)
        self.update_interval = update_interval
        self.last_update_time = 0
        self.async_callbacks: List[Callable] = []
    
    async def update_async(self, amount: int = 1):
        """Update progress and notify async callbacks if interval passed"""
        self.current = min(self.current + amount, self.total)
        
        current_time = time.time()
        if current_time - self.last_update_time >= self.update_interval:
            self.last_update_time = current_time
            await self._notify_async()
    
    def add_async_callback(self, callback: Callable):
        """Add async callback for progress updates"""
        self.async_callbacks.append(callback)
    
    async def _notify_async(self):
        """Notify all async callbacks"""
        for callback in self.async_callbacks:
            try:
                await callback(self)
            except Exception as e:
                logger.error(f"Async progress callback error: {e}")


# ==================== FILE UTILITIES ====================

def get_file_size(filepath: Union[str, Path]) -> int:
    """Get file size in bytes"""
    return Path(filepath).stat().st_size if Path(filepath).exists() else 0


def format_file_size(size_bytes: int) -> str:
    """Format file size to human readable string"""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.2f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.2f} PB"


def format_duration(seconds: Union[int, float]) -> str:
    """Format duration to human readable string"""
    if seconds is None:
        return "Unknown"
    
    seconds = int(seconds)
    hours, remainder = divmod(seconds, 3600)
    minutes, secs = divmod(remainder, 60)
    
    if hours > 0:
        return f"{hours}:{minutes:02d}:{secs:02d}"
    else:
        return f"{minutes}:{secs:02d}"


def get_file_hash(filepath: Union[str, Path], algorithm: str = 'md5') -> str:
    """Calculate file hash"""
    hash_func = hashlib.new(algorithm)
    
    with open(filepath, 'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            hash_func.update(chunk)
    
    return hash_func.hexdigest()


def safe_filename(filename: str, max_length: int = 200) -> str:
    """Create safe filename by removing/replacing invalid characters"""
    # Remove invalid characters
    filename = re.sub(r'[<>:"/\\|?*]', '', filename)
    # Replace spaces and special chars
    filename = re.sub(r'[\s]+', '_', filename)
    # Remove leading/trailing dots and spaces
    filename = filename.strip('. ')
    # Limit length
    if len(filename) > max_length:
        name, ext = os.path.splitext(filename)
        filename = name[:max_length - len(ext)] + ext
    
    return filename or "unnamed"


def ensure_directory(path: Union[str, Path]) -> Path:
    """Ensure directory exists, create if not"""
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


def clean_directory(path: Union[str, Path], older_than_hours: Optional[int] = None):
    """Clean directory contents, optionally only files older than specified hours"""
    path = Path(path)
    
    if not path.exists():
        return
    
    cutoff_time = None
    if older_than_hours:
        cutoff_time = datetime.now() - timedelta(hours=older_than_hours)
    
    for item in path.iterdir():
        try:
            if cutoff_time:
                mtime = datetime.fromtimestamp(item.stat().st_mtime)
                if mtime > cutoff_time:
                    continue
            
            if item.is_file():
                item.unlink()
            elif item.is_dir():
                shutil.rmtree(item)
            
            logger.debug(f"Cleaned: {item}")
        except Exception as e:
            logger.error(f"Failed to clean {item}: {e}")


def get_user_workspace(user_id: int) -> Dict[str, Path]:
    """Get all workspace paths for a user"""
    base = config.paths.get_user_dir(user_id)
    
    paths = {
        "base": base,
        "downloads": base / "downloads",
        "audio": base / "audio",
        "separated": base / "separated",
        "transcripts": base / "transcripts",
        "output": base / "output",
        "temp": base / "temp",
    }
    
    # Ensure all directories exist
    for path in paths.values():
        path.mkdir(parents=True, exist_ok=True)
    
    return paths


# ==================== URL UTILITIES ====================

def is_youtube_url(url: str) -> bool:
    """Check if URL is a valid YouTube URL"""
    youtube_patterns = [
        r'(https?://)?(www\.)?youtube\.com/watch\?v=[\w-]+',
        r'(https?://)?(www\.)?youtube\.com/shorts/[\w-]+',
        r'(https?://)?(www\.)?youtu\.be/[\w-]+',
        r'(https?://)?(www\.)?youtube\.com/embed/[\w-]+',
        r'(https?://)?m\.youtube\.com/watch\?v=[\w-]+',
    ]
    
    for pattern in youtube_patterns:
        if re.match(pattern, url):
            return True
    
    return False


def extract_video_id(url: str) -> Optional[str]:
    """Extract video ID from YouTube URL"""
    patterns = [
        r'(?:v=|/v/|youtu\.be/|/embed/|/shorts/)([a-zA-Z0-9_-]{11})',
    ]
    
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1)
    
    return None


def sanitize_url(url: str) -> str:
    """Clean and validate URL"""
    url = url.strip()
    
    # Add https if missing
    if not url.startswith(('http://', 'https://')):
        url = 'https://' + url
    
    return url


# ==================== FFMPEG UTILITIES ====================

def check_ffmpeg_installed() -> bool:
    """Check if FFmpeg is installed and accessible"""
    try:
        result = subprocess.run(
            [config.ffmpeg.ffmpeg_path, '-version'],
            capture_output=True,
            text=True,
            timeout=10
        )
        return result.returncode == 0
    except Exception:
        return False


def get_media_info(filepath: Union[str, Path]) -> Dict[str, Any]:
    """Get media file information using ffprobe"""
    try:
        cmd = [
            config.ffmpeg.ffprobe_path,
            '-v', 'quiet',
            '-print_format', 'json',
            '-show_format',
            '-show_streams',
            str(filepath)
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        
        if result.returncode == 0:
            return json.loads(result.stdout)
        else:
            logger.error(f"ffprobe error: {result.stderr}")
            return {}
    
    except Exception as e:
        logger.error(f"Failed to get media info: {e}")
        return {}


def get_audio_duration(filepath: Union[str, Path]) -> Optional[float]:
    """Get audio/video duration in seconds"""
    info = get_media_info(filepath)
    
    if info and 'format' in info:
        try:
            return float(info['format'].get('duration', 0))
        except (ValueError, TypeError):
            pass
    
    return None


def get_video_resolution(filepath: Union[str, Path]) -> Tuple[int, int]:
    """Get video resolution (width, height)"""
    info = get_media_info(filepath)
    
    if info and 'streams' in info:
        for stream in info['streams']:
            if stream.get('codec_type') == 'video':
                return (
                    stream.get('width', 0),
                    stream.get('height', 0)
                )
    
    return (0, 0)


# ==================== DECORATORS ====================

def retry_async(
    max_attempts: int = 3,
    delay: float = 1.0,
    backoff: float = 2.0,
    exceptions: tuple = (Exception,)
):
    """Retry decorator for async functions"""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            current_delay = delay
            last_exception = None
            
            for attempt in range(max_attempts):
                try:
                    return await func(*args, **kwargs)
                except exceptions as e:
                    last_exception = e
                    logger.warning(
                        f"Attempt {attempt + 1}/{max_attempts} failed for {func.__name__}: {e}"
                    )
                    
                    if attempt < max_attempts - 1:
                        await asyncio.sleep(current_delay)
                        current_delay *= backoff
            
            raise last_exception
        
        return wrapper
    return decorator


def retry_sync(
    max_attempts: int = 3,
    delay: float = 1.0,
    backoff: float = 2.0,
    exceptions: tuple = (Exception,)
):
    """Retry decorator for sync functions"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            current_delay = delay
            last_exception = None
            
            for attempt in range(max_attempts):
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    last_exception = e
                    logger.warning(
                        f"Attempt {attempt + 1}/{max_attempts} failed for {func.__name__}: {e}"
                    )
                    
                    if attempt < max_attempts - 1:
                        time.sleep(current_delay)
                        current_delay *= backoff
            
            raise last_exception
        
        return wrapper
    return decorator


def log_execution_time(func):
    """Decorator to log function execution time"""
    @wraps(func)
    async def async_wrapper(*args, **kwargs):
        start_time = time.time()
        result = await func(*args, **kwargs)
        elapsed = time.time() - start_time
        logger.info(f"{func.__name__} completed in {elapsed:.2f}s")
        return result
    
    @wraps(func)
    def sync_wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        elapsed = time.time() - start_time
        logger.info(f"{func.__name__} completed in {elapsed:.2f}s")
        return result
    
    if asyncio.iscoroutinefunction(func):
        return async_wrapper
    return sync_wrapper


def handle_errors(error_message: str = "An error occurred"):
    """Decorator to handle and log errors gracefully"""
    def decorator(func):
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                logger.error(f"{error_message}: {e}")
                logger.debug(traceback.format_exc())
                raise
        
        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                logger.error(f"{error_message}: {e}")
                logger.debug(traceback.format_exc())
                raise
        
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        return sync_wrapper
    
    return decorator


# ==================== TELEGRAM HELPERS ====================

async def split_file_for_telegram(
    filepath: Path,
    max_size_mb: int = 50
) -> List[Path]:
    """Split large file into chunks for Telegram upload"""
    file_size = get_file_size(filepath)
    max_size_bytes = max_size_mb * 1024 * 1024
    
    if file_size <= max_size_bytes:
        return [filepath]
    
    # For video files, we need to use FFmpeg to split
    # This is a placeholder - actual implementation would depend on file type
    logger.warning(f"File {filepath} is larger than {max_size_mb}MB, splitting not implemented yet")
    return [filepath]


def escape_markdown(text: str) -> str:
    """Escape special characters for Telegram MarkdownV2"""
    special_chars = ['_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!']
    
    for char in special_chars:
        text = text.replace(char, f'\\{char}')
    
    return text


def truncate_text(text: str, max_length: int = 4096, suffix: str = "...") -> str:
    """Truncate text to maximum length for Telegram"""
    if len(text) <= max_length:
        return text
    
    return text[:max_length - len(suffix)] + suffix


# ==================== SYSTEM CHECKS ====================

def check_system_requirements() -> Dict[str, bool]:
    """Check all system requirements"""
    requirements = {}
    
    # Check FFmpeg
    requirements['ffmpeg'] = check_ffmpeg_installed()
    
    # Check Python version
    requirements['python'] = sys.version_info >= (3, 8)
    
    # Check GPU availability (for faster processing)
    try:
        import torch
        requirements['cuda'] = torch.cuda.is_available()
        if requirements['cuda']:
            requirements['gpu_name'] = torch.cuda.get_device_name(0)
    except ImportError:
        requirements['cuda'] = False
    
    # Check disk space
    workspace_path = config.paths.workspace_dir
    try:
        total, used, free = shutil.disk_usage(workspace_path)
        requirements['disk_space_gb'] = free / (1024 ** 3)
        requirements['disk_ok'] = requirements['disk_space_gb'] > 10  # At least 10GB free
    except Exception:
        requirements['disk_ok'] = True
    
    return requirements


def print_system_status():
    """Print system status to console"""
    reqs = check_system_requirements()
    
    print("\n" + "=" * 50)
    print("🔧 SYSTEM STATUS")
    print("=" * 50)
    print(f"✓ Python 3.8+: {'✅' if reqs.get('python') else '❌'}")
    print(f"✓ FFmpeg: {'✅' if reqs.get('ffmpeg') else '❌ (Required!)'}")
    print(f"✓ CUDA/GPU: {'✅ ' + reqs.get('gpu_name', '') if reqs.get('cuda') else '❌ (CPU mode)'}")
    print(f"✓ Disk Space: {reqs.get('disk_space_gb', 0):.1f} GB free")
    print("=" * 50 + "\n")
    
    if not reqs.get('ffmpeg'):
        print("⚠️  FFmpeg is required! Install it:")
        print("   Ubuntu/Debian: sudo apt install ffmpeg")
        print("   MacOS: brew install ffmpeg")
        print("   Windows: Download from https://ffmpeg.org/download.html")
        print()


# ==================== INITIALIZATION ====================

def initialize_bot():
    """Initialize bot and check requirements"""
    logger.info("Initializing Hindi Dubbing Bot...")
    
    # Create directories
    config.paths.create_all_directories()
    
    # Check system requirements
    print_system_status()
    reqs = check_system_requirements()
    
    if not reqs.get('ffmpeg'):
        logger.error("FFmpeg not found! Please install FFmpeg first.")
        return False
    
    # Load or create config file
    config_file = config.paths.base_dir / "bot_config.json"
    if config_file.exists():
        logger.info("Loading configuration from bot_config.json")
    else:
        config.save_to_file(str(config_file))
        logger.info("Created default configuration file: bot_config.json")
    
    logger.info("Bot initialized successfully!")
    return True


if __name__ == "__main__":
    # Test utilities
    initialize_bot()
    
    print("\n📋 Testing Utilities:")
    print(f"Format size: {format_file_size(1234567890)}")
    print(f"Format duration: {format_duration(3725)}")
    print(f"YouTube URL check: {is_youtube_url('https://youtube.com/watch?v=dQw4w9WgXcQ')}")
    print(f"Extract video ID: {extract_video_id('https://youtube.com/watch?v=dQw4w9WgXcQ')}")