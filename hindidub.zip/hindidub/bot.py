"""
Main Telegram Bot - COMPLETE UPDATED VERSION
Hindi Dubbing Bot - With Full Sync Integration

Single command to run: python bot.py
All control through Telegram
"""

import os
import sys
import asyncio
import logging
from pathlib import Path
from typing import Optional, Dict, List
from datetime import datetime
import json

# Telegram imports
try:
    from telegram import (
        Update, 
        InlineKeyboardButton, 
        InlineKeyboardMarkup,
        BotCommand
    )
    from telegram.ext import (
        Application,
        CommandHandler,
        MessageHandler,
        CallbackQueryHandler,
        ContextTypes,
        filters
    )
    from telegram.constants import ParseMode, ChatAction
    TELEGRAM_AVAILABLE = True
except ImportError:
    TELEGRAM_AVAILABLE = False
    print("❌ python-telegram-bot not installed!")
    print("Run: pip install python-telegram-bot")
    sys.exit(1)

# Local imports
from config import config, ProcessingStage, QualityPreset, Messages, STAGE_EMOJI
from utils import (
    logger,
    session_manager,
    is_youtube_url,
    format_file_size,
    format_duration,
    get_user_workspace,
    initialize_bot,
    check_system_requirements,
)
from downloader import YouTubeDownloader
from audio_processor import AudioProcessor
from transcription import WhisperTranscriber, transcribe_audio, TranscriptionResult
from translator import HindiTranslator, translate_and_save
from merger import (
    VideoMerger, 
    create_dubbed_video, 
    SyncSegment, 
    load_segments_from_srt,
    MergeResult
)


# ==================== CUSTOM MESSAGES ====================

class BotMessages:
    """Extended bot messages"""
    
    WELCOME = """
🎬 *Hindi Dubbing Bot में आपका स्वागत है!*

यह bot YouTube videos को Hindi में dub करने में मदद करता है।

*🔄 Complete Process:*
1️⃣ YouTube URL भेजें
2️⃣ Bot video process करेगा (5-15 min)
3️⃣ Hindi script मिलेगी
4️⃣ Script पढ़कर Hindi audio record करें
5️⃣ Audio file भेजें
6️⃣ Final dubbed video प्राप्त करें! 🎉

*✨ Features:*
• AI Voice Separation (Demucs)
• AI Transcription (Whisper)
• Auto Hindi Translation
• Smart Audio Sync
• Background Music Preservation

📹 *शुरू करने के लिए YouTube URL भेजें*
"""
    
    HELP = """
📚 *Help & Commands*

*Available Commands:*
/start - Bot शुरू करें
/help - यह help message
/status - Current processing status
/cancel - Operation cancel करें
/settings - Quality settings
/sync - Sync settings
/clean - Temporary files delete करें

*📹 How to Use:*
1. YouTube URL paste करें
2. Processing complete होने का wait करें
3. Hindi script file मिलेगी
4. Audio record करें (tips नीचे)
5. Audio file भेजें
6. Dubbed video receive करें!

*🎤 Recording Tips:*
• Original video देखते हुए record करें
• Same timing maintain करें
• Clear voice में बोलें
• Background noise avoid करें
• Sentences के बीच pause रखें

*📁 Supported Formats:*
• Audio: MP3, WAV, M4A, OGG, FLAC
• Max size: 50MB

*⚙️ Sync Modes:*
• Auto - Automatic best sync
• Simple - Basic duration match
• Segment - Per-sentence sync (best)
"""
    
    RECORDING_TIPS = """
🎤 *Hindi Audio Recording Tips*

*⏱ Timing के लिए:*
• Original video देखते हुए record करें
• जहाँ pause है वहाँ pause रखें
• ±20% speed variation okay है

*🎙 Quality के लिए:*
• Quiet room में record करें
• Phone को stable रखें
• Mic के पास बोलें
• Echo avoid करें

*📝 Script के लिए:*
• Script को पहले 2-3 बार पढ़ें
• Natural तरीके से बोलें
• जल्दबाजी न करें

*✅ Good Recording:*
• Clear voice
• Consistent volume
• Matching timing
• No background noise

*⏳ Duration Guide:*
Original: {duration}
Your audio should be: similar length (±30% okay)
"""

    SYNC_SETTINGS = """
⚙️ *Sync Settings*

Current Mode: *{current_mode}*

*Available Modes:*

🤖 *Auto* (Recommended)
   Automatically chooses best sync method

⚡ *Simple*
   Stretches entire audio to match duration
   Fast but less accurate

🎯 *Segment*
   Syncs each sentence individually
   Best quality, slower

❌ *None*
   No sync, use audio as-is
   Not recommended

Select sync mode:
"""

    PROCESSING_STATUS = """
📊 *Processing Status*

*Video:* {title}
*Stage:* {stage_emoji} {stage}
*Progress:* {progress}

{details}
"""

    SYNC_COMPLETE = """
✅ *Sync Information*

Original Duration: {original_duration}
Your Audio Duration: {hindi_duration}
Synced Duration: {synced_duration}

Speed Adjustment: {speed_factor}x
Sync Quality: {quality_emoji} {quality}

{quality_message}
"""

    FINAL_VIDEO_READY = """
🎉 *Dubbing Complete!*

📹 *Video Details:*
• Duration: {duration}
• Size: {file_size}
• Quality: {quality}

🔄 *Sync Info:*
• Mode: {sync_mode}
• Quality: {sync_quality}

✨ Send another YouTube URL for new video!
"""


# ==================== SYNC QUALITY HELPERS ====================

def get_sync_quality_emoji(quality: str) -> str:
    """Get emoji for sync quality"""
    emojis = {
        "perfect": "✅",
        "good": "👍",
        "acceptable": "⚠️",
        "poor": "❌"
    }
    return emojis.get(quality, "❓")


def get_sync_quality_message(quality: str) -> str:
    """Get message for sync quality"""
    messages = {
        "perfect": "Excellent! Audio perfectly synchronized.",
        "good": "Great! Minor adjustments made, sounds natural.",
        "acceptable": "Okay. Some timing differences but watchable.",
        "poor": "Consider re-recording with better timing."
    }
    return messages.get(quality, "Sync completed.")


# ==================== MAIN BOT CLASS ====================

class HindiDubbingBot:
    """
    Main Telegram Bot for Hindi Dubbing
    Complete workflow with sync integration
    """
    
    def __init__(self):
        self.token = config.telegram.bot_token
        
        if not self.token:
            self.token = os.getenv("TELEGRAM_BOT_TOKEN", "")
        
        if not self.token:
            raise ValueError(
                "❌ Bot token not found!\n\n"
                "Set token using one of these methods:\n"
                "1. Environment variable: export TELEGRAM_BOT_TOKEN='your_token'\n"
                "2. Edit bot_config.json file\n"
                "3. Edit config.py directly"
            )
        
        self.app: Optional[Application] = None
        self.processing_users: Dict[int, bool] = {}
        self.user_sync_modes: Dict[int, str] = {}  # Store user sync preferences
        
        logger.info("HindiDubbingBot initialized")
    
    # ==================== COMMAND HANDLERS ====================
    
    async def start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /start command"""
        user = update.effective_user
        session = session_manager.get_session(user.id, user.username)
        
        # Reset session for fresh start
        if session.current_stage not in [ProcessingStage.IDLE, ProcessingStage.WAITING_HINDI_AUDIO]:
            session_manager.reset_session(user.id)
        
        # Welcome keyboard
        keyboard = [
            [InlineKeyboardButton("📚 Help", callback_data="help")],
            [InlineKeyboardButton("⚙️ Settings", callback_data="settings")],
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            BotMessages.WELCOME,
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=reply_markup
        )
        
        logger.info(f"User {user.id} ({user.username}) started bot")
    
    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /help command"""
        await update.message.reply_text(
            BotMessages.HELP,
            parse_mode=ParseMode.MARKDOWN
        )
    
    async def status_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /status command"""
        user_id = update.effective_user.id
        session = session_manager.get_session(user_id)
        
        if session.current_stage == ProcessingStage.IDLE:
            await update.message.reply_text(
                "😴 *No Active Processing*\n\n"
                "Send a YouTube URL to start dubbing!",
                parse_mode=ParseMode.MARKDOWN
            )
            return
        
        # Build status message
        emoji = STAGE_EMOJI.get(session.current_stage, "🔄")
        stage_name = session.current_stage.value.replace("_", " ").title()
        
        details = ""
        if session.video_title:
            details += f"📹 {session.video_title[:40]}...\n"
        if session.video_duration:
            details += f"⏱ Duration: {format_duration(session.video_duration)}\n"
        if session.error_message:
            details += f"❌ Error: {session.error_message}\n"
        
        progress = "In progress..."
        if session.current_stage == ProcessingStage.WAITING_HINDI_AUDIO:
            progress = "Waiting for your Hindi audio"
        elif session.current_stage == ProcessingStage.COMPLETED:
            progress = "Completed!"
        elif session.current_stage == ProcessingStage.FAILED:
            progress = "Failed"
        
        status_text = BotMessages.PROCESSING_STATUS.format(
            title=session.video_title or "Unknown",
            stage_emoji=emoji,
            stage=stage_name,
            progress=progress,
            details=details
        )
        
        await update.message.reply_text(status_text, parse_mode=ParseMode.MARKDOWN)
    
    async def cancel_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /cancel command"""
        user_id = update.effective_user.id
        
        if user_id in self.processing_users and self.processing_users[user_id]:
            self.processing_users[user_id] = False
            session_manager.update_session(user_id, stage=ProcessingStage.CANCELLED)
            await update.message.reply_text(
                "🚫 *Operation Cancelled*\n\n"
                "Send a new YouTube URL to start again.",
                parse_mode=ParseMode.MARKDOWN
            )
        else:
            session = session_manager.get_session(user_id)
            if session.current_stage == ProcessingStage.WAITING_HINDI_AUDIO:
                session_manager.reset_session(user_id)
                await update.message.reply_text(
                    "🚫 *Session Reset*\n\n"
                    "Send a new YouTube URL to start again.",
                    parse_mode=ParseMode.MARKDOWN
                )
            else:
                await update.message.reply_text(
                    "ℹ️ No active operation to cancel.\n"
                    "Send a YouTube URL to start."
                )
    
    async def settings_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /settings command"""
        user_id = update.effective_user.id
        session = session_manager.get_session(user_id)
        
        keyboard = [
            [
                InlineKeyboardButton("🔽 Low", callback_data="quality_low"),
                InlineKeyboardButton("📊 Medium", callback_data="quality_medium"),
            ],
            [
                InlineKeyboardButton("📈 High", callback_data="quality_high"),
                InlineKeyboardButton("🚀 Ultra", callback_data="quality_ultra"),
            ],
            [
                InlineKeyboardButton("🔄 Sync Settings", callback_data="sync_settings"),
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        text = (
            "⚙️ *Settings*\n\n"
            f"📹 Video Quality: *{session.quality_preset.value.upper()}*\n"
            f"🔄 Sync Mode: *{self.user_sync_modes.get(user_id, 'auto').upper()}*\n"
            f"🎤 Whisper Model: *{config.whisper.model_size}*\n\n"
            "Select video quality:"
        )
        
        await update.message.reply_text(
            text,
            reply_markup=reply_markup,
            parse_mode=ParseMode.MARKDOWN
        )
    
    async def sync_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /sync command - Show sync settings"""
        user_id = update.effective_user.id
        current_mode = self.user_sync_modes.get(user_id, "auto")
        
        keyboard = [
            [InlineKeyboardButton(
                f"{'✅ ' if current_mode == 'auto' else ''}🤖 Auto", 
                callback_data="sync_auto"
            )],
            [InlineKeyboardButton(
                f"{'✅ ' if current_mode == 'simple' else ''}⚡ Simple", 
                callback_data="sync_simple"
            )],
            [InlineKeyboardButton(
                f"{'✅ ' if current_mode == 'segment' else ''}🎯 Segment", 
                callback_data="sync_segment"
            )],
            [InlineKeyboardButton(
                f"{'✅ ' if current_mode == 'none' else ''}❌ None", 
                callback_data="sync_none"
            )],
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            BotMessages.SYNC_SETTINGS.format(current_mode=current_mode.upper()),
            reply_markup=reply_markup,
            parse_mode=ParseMode.MARKDOWN
        )
    
    async def clean_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /clean command"""
        user_id = update.effective_user.id
        workspace = get_user_workspace(user_id)
        
        # Confirm keyboard
        keyboard = [
            [
                InlineKeyboardButton("✅ Yes, Clean", callback_data="clean_confirm"),
                InlineKeyboardButton("❌ Cancel", callback_data="clean_cancel"),
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            "🧹 *Clean Temporary Files?*\n\n"
            "This will delete:\n"
            "• Downloaded videos\n"
            "• Extracted audio\n"
            "• Intermediate files\n\n"
            "Final videos will be kept.",
            reply_markup=reply_markup,
            parse_mode=ParseMode.MARKDOWN
        )
    
    # ==================== CALLBACK HANDLERS ====================
    
    async def handle_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle inline keyboard callbacks"""
        query = update.callback_query
        await query.answer()
        
        user_id = query.from_user.id
        data = query.data
        
        # Quality settings
        if data.startswith("quality_"):
            quality_name = data.replace("quality_", "")
            quality_map = {
                "low": QualityPreset.LOW,
                "medium": QualityPreset.MEDIUM,
                "high": QualityPreset.HIGH,
                "ultra": QualityPreset.ULTRA
            }
            
            if quality_name in quality_map:
                session = session_manager.get_session(user_id)
                session.quality_preset = quality_map[quality_name]
                session_manager.save_session(user_id)
                
                await query.edit_message_text(
                    f"✅ *Quality Changed*\n\n"
                    f"Video quality set to: *{quality_name.upper()}*\n\n"
                    f"Send a YouTube URL to start!",
                    parse_mode=ParseMode.MARKDOWN
                )
        
        # Sync settings
        elif data.startswith("sync_"):
            sync_mode = data.replace("sync_", "")
            
            if sync_mode in ["auto", "simple", "segment", "none"]:
                self.user_sync_modes[user_id] = sync_mode
                
                mode_descriptions = {
                    "auto": "🤖 Auto - Best method auto-selected",
                    "simple": "⚡ Simple - Fast duration matching",
                    "segment": "🎯 Segment - Best quality per-sentence sync",
                    "none": "❌ None - No sync (not recommended)"
                }
                
                await query.edit_message_text(
                    f"✅ *Sync Mode Changed*\n\n"
                    f"{mode_descriptions.get(sync_mode, sync_mode)}\n\n"
                    f"This will apply to your next video.",
                    parse_mode=ParseMode.MARKDOWN
                )
            
            elif sync_mode == "settings":
                # Show sync settings
                await self.sync_command(update, context)
        
        # Help
        elif data == "help":
            await query.edit_message_text(
                BotMessages.HELP,
                parse_mode=ParseMode.MARKDOWN
            )
        
        # Settings
        elif data == "settings":
            session = session_manager.get_session(user_id)
            keyboard = [
                [
                    InlineKeyboardButton("🔽 Low", callback_data="quality_low"),
                    InlineKeyboardButton("📊 Medium", callback_data="quality_medium"),
                ],
                [
                    InlineKeyboardButton("📈 High", callback_data="quality_high"),
                    InlineKeyboardButton("🚀 Ultra", callback_data="quality_ultra"),
                ],
                [
                    InlineKeyboardButton("🔄 Sync Settings", callback_data="sync_settings"),
                ]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                f"⚙️ *Settings*\n\n"
                f"Current Quality: *{session.quality_preset.value.upper()}*\n"
                f"Sync Mode: *{self.user_sync_modes.get(user_id, 'auto').upper()}*\n\n"
                f"Select quality:",
                reply_markup=reply_markup,
                parse_mode=ParseMode.MARKDOWN
            )
        
        # Clean confirm
        elif data == "clean_confirm":
            workspace = get_user_workspace(user_id)
            cleaned = 0
            
            for folder_name in ["temp", "audio", "separated", "downloads"]:
                folder_path = workspace.get(folder_name)
                if folder_path and folder_path.exists():
                    for f in folder_path.iterdir():
                        if f.is_file():
                            try:
                                f.unlink()
                                cleaned += 1
                            except:
                                pass
            
            session_manager.reset_session(user_id)
            
            await query.edit_message_text(
                f"🧹 *Cleanup Complete*\n\n"
                f"Deleted {cleaned} temporary files.\n"
                f"Session reset.\n\n"
                f"Send a YouTube URL to start fresh!",
                parse_mode=ParseMode.MARKDOWN
            )
        
        elif data == "clean_cancel":
            await query.edit_message_text(
                "❌ Cleanup cancelled.",
                parse_mode=ParseMode.MARKDOWN
            )
    
    # ==================== MESSAGE HANDLERS ====================
    
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle general text messages"""
        text = update.message.text.strip()
        
        # Check if it's a YouTube URL
        if 'youtube.com' in text.lower() or 'youtu.be' in text.lower():
            await self.handle_youtube_url(update, context)
        else:
            session = session_manager.get_session(update.effective_user.id)
            
            if session.current_stage == ProcessingStage.WAITING_HINDI_AUDIO:
                await update.message.reply_text(
                    "⏳ *Waiting for Hindi Audio*\n\n"
                    "Please send your recorded Hindi audio file (MP3/WAV).\n\n"
                    "💡 Tip: Send as audio file, not voice message for better quality.",
                    parse_mode=ParseMode.MARKDOWN
                )
            else:
                await update.message.reply_text(
                    "📹 Send a YouTube URL to start dubbing!\n\n"
                    "Example:\n"
                    "`https://www.youtube.com/watch?v=xxxxx`\n\n"
                    "Or use /help for more info.",
                    parse_mode=ParseMode.MARKDOWN
                )
    
    async def handle_youtube_url(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle YouTube URL messages"""
        user_id = update.effective_user.id
        url = update.message.text.strip()
        
        # Check if already processing
        if self.processing_users.get(user_id):
            await update.message.reply_text(
                "⚠️ *Already Processing*\n\n"
                "Please wait for current video to complete.\n"
                "Use /cancel to stop current processing.",
                parse_mode=ParseMode.MARKDOWN
            )
            return
        
        # Validate URL
        if not is_youtube_url(url):
            await update.message.reply_text(
                "❌ *Invalid YouTube URL*\n\n"
                "Please send a valid YouTube URL.\n\n"
                "Supported formats:\n"
                "• `youtube.com/watch?v=xxxxx`\n"
                "• `youtu.be/xxxxx`\n"
                "• `youtube.com/shorts/xxxxx`",
                parse_mode=ParseMode.MARKDOWN
            )
            return
        
        # Start processing
        self.processing_users[user_id] = True
        
        try:
            await self.process_youtube_video(update, context, url)
        except asyncio.CancelledError:
            logger.info(f"Processing cancelled for user {user_id}")
            await update.message.reply_text("🚫 Processing cancelled.")
        except Exception as e:
            logger.error(f"Processing error for user {user_id}: {e}")
            import traceback
            logger.error(traceback.format_exc())
            
            await update.message.reply_text(
                f"❌ *Processing Failed*\n\n"
                f"Error: {str(e)[:200]}\n\n"
                f"Please try again or use /clean to reset.",
                parse_mode=ParseMode.MARKDOWN
            )
            
            session_manager.update_session(
                user_id,
                stage=ProcessingStage.FAILED,
                error_message=str(e)
            )
        finally:
            self.processing_users[user_id] = False
    
    # ==================== MAIN PROCESSING PIPELINE ====================
    
    async def process_youtube_video(
        self, 
        update: Update, 
        context: ContextTypes.DEFAULT_TYPE, 
        url: str
    ):
        """Complete processing pipeline for YouTube video"""
        user_id = update.effective_user.id
        chat_id = update.effective_chat.id
        session = session_manager.get_session(user_id)
        workspace = get_user_workspace(user_id)
        
        # Initial status message
        status_msg = await update.message.reply_text(
            "✅ *URL Received!*\n\n"
            "🔄 Starting download...",
            parse_mode=ParseMode.MARKDOWN
        )
        
        # Helper function to update status
        async def update_status(text: str, parse_mode=ParseMode.MARKDOWN):
            try:
                await status_msg.edit_text(text, parse_mode=parse_mode)
            except Exception as e:
                logger.debug(f"Status update failed: {e}")
        
        # Progress callback for detailed updates
        last_progress_update = [0]  # Use list to allow modification in nested function
        
        async def progress_callback(info: dict):
            current_progress = info.get('progress', 0)
            
            # Only update if progress changed significantly (every 10%)
            if current_progress - last_progress_update[0] >= 10:
                last_progress_update[0] = current_progress
                
                if info.get('status') == 'downloading':
                    await update_status(
                        f"📥 *Downloading...*\n\n"
                        f"Progress: {current_progress:.0f}%\n"
                        f"Downloaded: {info.get('downloaded', 'N/A')}\n"
                        f"Speed: {info.get('speed', 'N/A')}"
                    )
        
        try:
            # ============ STAGE 1: DOWNLOAD ============
            await context.bot.send_chat_action(chat_id, ChatAction.TYPING)
            
            downloader = YouTubeDownloader(user_id, session.quality_preset)
            
            # Get video info first
            await update_status(
                "🔍 *Fetching Video Info...*\n\n"
                "Getting video details..."
            )
            
            video_info = await downloader.get_video_info(url)
            
            if not video_info:
                raise Exception("Failed to get video information. Video might be private or unavailable.")
            
            # Check if cancelled
            if not self.processing_users.get(user_id, True):
                raise asyncio.CancelledError()
            
            await update_status(
                f"📥 *Downloading Video...*\n\n"
                f"📹 *{video_info.title[:50]}*\n"
                f"⏱ Duration: {format_duration(video_info.duration)}\n"
                f"💾 Size: ~{format_file_size(video_info.filesize_approx)}\n"
                f"📊 Quality: {video_info.resolution}\n\n"
                f"Please wait..."
            )
            
            video_path = await downloader.download_video(url, progress_callback)
            
            if not video_path or not video_path.exists():
                raise Exception("Download failed - video file not found")
            
            logger.info(f"Downloaded: {video_path}")
            
            # ============ STAGE 2: EXTRACT AUDIO ============
            if not self.processing_users.get(user_id, True):
                raise asyncio.CancelledError()
            
            await update_status(
                f"✅ *Download Complete!*\n\n"
                f"📹 {video_info.title[:40]}...\n"
                f"💾 Size: {format_file_size(video_path.stat().st_size)}\n\n"
                f"🎵 Extracting audio..."
            )
            await context.bot.send_chat_action(chat_id, ChatAction.RECORD_VOICE)
            
            processor = AudioProcessor(user_id)
            audio_path = await processor.extract_audio(video_path)
            
            if not audio_path or not audio_path.exists():
                raise Exception("Audio extraction failed")
            
            logger.info(f"Audio extracted: {audio_path}")
            
            # ============ STAGE 3: VOICE SEPARATION ============
            if not self.processing_users.get(user_id, True):
                raise asyncio.CancelledError()
            
            # Estimate time based on duration and device
            duration = video_info.duration
            if config.demucs.device == "cuda":
                est_time = max(1, duration * 0.3)  # ~0.3x realtime on GPU
            else:
                est_time = max(2, duration * 1.5)  # ~1.5x realtime on CPU
            
            await update_status(
                f"🎤 *AI Voice Separation*\n\n"
                f"Using Demucs AI to separate:\n"
                f"• 🗣 Narrator voice\n"
                f"• 🎵 Background music\n"
                f"• 🔊 Sound effects\n\n"
                f"⏱ Estimated time: {format_duration(est_time)}\n\n"
                f"_This is the longest step, please wait..._"
            )
            
            separation = await processor.separate_vocals_demucs(
                audio_path,
                progress_callback=progress_callback
            )
            
            if not separation:
                raise Exception("Voice separation failed")
            
            if not separation.vocals_path.exists() or not separation.no_vocals_path.exists():
                raise Exception("Separated audio files not found")
            
            logger.info(f"Vocals: {separation.vocals_path}")
            logger.info(f"Background: {separation.no_vocals_path}")
            
            # ============ STAGE 4: TRANSCRIPTION ============
            if not self.processing_users.get(user_id, True):
                raise asyncio.CancelledError()
            
            await update_status(
                f"✅ *Voice Separation Complete!*\n\n"
                f"📝 *Transcribing with Whisper AI...*\n\n"
                f"Converting speech to text with timestamps..."
            )
            await context.bot.send_chat_action(chat_id, ChatAction.TYPING)
            
            transcription, transcript_files = await transcribe_audio(
                separation.vocals_path,
                user_id,
                progress_callback
            )
            
            if not transcription:
                raise Exception("Transcription failed")
            
            logger.info(f"Transcribed: {transcription.word_count} words")
            
            # ============ STAGE 5: TRANSLATION ============
            if not self.processing_users.get(user_id, True):
                raise asyncio.CancelledError()
            
            await update_status(
                f"✅ *Transcription Complete!*\n\n"
                f"📝 {transcription.word_count} words transcribed\n\n"
                f"🇮🇳 *Translating to Hindi...*"
            )
            
            translation, translation_files = await translate_and_save(
                transcription,
                user_id,
                progress_callback
            )
            
            if not translation:
                raise Exception("Translation failed")
            
            logger.info(f"Translated: {translation.total_segments} segments")
            
            # ============ STAGE 6: SAVE SEGMENTS FOR SYNC ============
            # Store segments in session for later sync
            segments_data = [
                {
                    "id": seg.id,
                    "start": seg.start,
                    "end": seg.end,
                    "text": seg.translated_text
                }
                for seg in translation.segments
            ]
            
            session = session_manager.get_session(user_id)
            session.settings["segments"] = segments_data
            session.settings["sync_mode"] = self.user_sync_modes.get(user_id, "auto")
            session_manager.save_session(user_id)
            
            # ============ STAGE 7: SEND SCRIPTS TO USER ============
            session_manager.update_session(
                user_id,
                stage=ProcessingStage.WAITING_HINDI_AUDIO
            )
            
            await update_status(
                f"✅ *Processing Complete!*\n\n"
                f"📄 Sending Hindi script files..."
            )
            
            # Send bilingual script
            bilingual_path = translation_files.get("bilingual")
            if bilingual_path and bilingual_path.exists():
                await context.bot.send_document(
                    chat_id,
                    document=open(bilingual_path, 'rb'),
                    filename="hindi_dubbing_script.txt",
                    caption=(
                        "📄 *Hindi Dubbing Script*\n\n"
                        "This file contains:\n"
                        "• Original English text\n"
                        "• Hindi translation\n"
                        "• Timestamps for each segment\n\n"
                        "Use this to record your Hindi audio."
                    ),
                    parse_mode=ParseMode.MARKDOWN
                )
            
            # Send Hindi SRT subtitles
            hindi_srt_path = translation_files.get("hindi_srt")
            if hindi_srt_path and hindi_srt_path.exists():
                await context.bot.send_document(
                    chat_id,
                    document=open(hindi_srt_path, 'rb'),
                    filename="hindi_subtitles.srt",
                    caption="📝 Hindi subtitles file (SRT format)"
                )
            
            # Send recording tips
            recording_tips = BotMessages.RECORDING_TIPS.format(
                duration=format_duration(video_info.duration)
            )
            
            await update.message.reply_text(
                f"✅ *Ready for Your Hindi Audio!*\n\n"
                f"📹 Video: {video_info.title[:40]}...\n"
                f"⏱ Duration: {format_duration(video_info.duration)}\n"
                f"📝 Segments: {translation.total_segments}\n\n"
                f"━━━━━━━━━━━━━━━━━━━━\n\n"
                f"{recording_tips}\n\n"
                f"━━━━━━━━━━━━━━━━━━━━\n\n"
                f"🎤 *Now record Hindi audio and send it here!*\n\n"
                f"Supported formats: MP3, WAV, M4A, OGG",
                parse_mode=ParseMode.MARKDOWN
            )
            
            logger.info(f"User {user_id}: Processing complete, waiting for Hindi audio")
            
        except asyncio.CancelledError:
            raise
        except Exception as e:
            logger.error(f"Pipeline error: {e}")
            session_manager.update_session(
                user_id,
                stage=ProcessingStage.FAILED,
                error_message=str(e)
            )
            raise
    
    # ==================== AUDIO HANDLER ====================
    
    async def handle_audio(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle audio file uploads (Hindi narration)"""
        user_id = update.effective_user.id
        chat_id = update.effective_chat.id
        session = session_manager.get_session(user_id)
        
        # Check if waiting for audio
        if session.current_stage != ProcessingStage.WAITING_HINDI_AUDIO:
            await update.message.reply_text(
                "⚠️ *No Active Session*\n\n"
                "First send a YouTube URL to start the dubbing process.\n\n"
                "Use /start to begin.",
                parse_mode=ParseMode.MARKDOWN
            )
            return
        
        # Validate required files exist
        if not session.no_vocals_path or not session.input_video_path:
            await update.message.reply_text(
                "❌ *Session Expired*\n\n"
                "Required files are missing.\n"
                "Please start again with a YouTube URL.",
                parse_mode=ParseMode.MARKDOWN
            )
            session_manager.reset_session(user_id)
            return
        
        if not Path(session.no_vocals_path).exists():
            await update.message.reply_text(
                "❌ *Files Not Found*\n\n"
                "Background audio file missing.\n"
                "Please start again with a YouTube URL.",
                parse_mode=ParseMode.MARKDOWN
            )
            session_manager.reset_session(user_id)
            return
        
        workspace = get_user_workspace(user_id)
        
        # Get audio file
        audio_file = (
            update.message.audio or 
            update.message.voice or 
            update.message.document
        )
        
        if not audio_file:
            await update.message.reply_text(
                "❌ *No Audio Detected*\n\n"
                "Please send an audio file (MP3, WAV, M4A, OGG).\n\n"
                "💡 Tip: Send as 'Audio' not as 'File' for better handling.",
                parse_mode=ParseMode.MARKDOWN
            )
            return
        
        # Check file size (50MB limit for Telegram)
        file_size = audio_file.file_size or 0
        if file_size > 50 * 1024 * 1024:
            await update.message.reply_text(
                "❌ *File Too Large*\n\n"
                f"Your file: {format_file_size(file_size)}\n"
                f"Maximum: 50 MB\n\n"
                "Please compress your audio and try again.",
                parse_mode=ParseMode.MARKDOWN
            )
            return
        
        # Start processing
        status_msg = await update.message.reply_text(
            "✅ *Hindi Audio Received!*\n\n"
            f"📁 Size: {format_file_size(file_size)}\n\n"
            "🔄 Processing...",
            parse_mode=ParseMode.MARKDOWN
        )
        
        # Mark as processing
        self.processing_users[user_id] = True
        
        try:
            # Download audio from Telegram
            await context.bot.send_chat_action(chat_id, ChatAction.RECORD_VIDEO)
            
            hindi_audio_path = workspace["audio"] / "hindi_narration.mp3"
            
            file = await context.bot.get_file(audio_file.file_id)
            await file.download_to_drive(hindi_audio_path)
            
            logger.info(f"Hindi audio received: {hindi_audio_path}")
            logger.info(f"File size: {format_file_size(hindi_audio_path.stat().st_size)}")
            
            # Update session
            session_manager.update_session(
                user_id,
                hindi_audio_path=str(hindi_audio_path)
            )
            
            # Helper to update status
            async def update_status(text: str):
                try:
                    await status_msg.edit_text(text, parse_mode=ParseMode.MARKDOWN)
                except:
                    pass
            
            # Progress callback
            async def progress_callback(info: dict):
                status = info.get('status', '')
                message = info.get('message', 'Processing...')
                
                if status == 'syncing':
                    progress = info.get('progress', 0)
                    await update_status(
                        f"🔄 *Synchronizing Audio*\n\n"
                        f"{message}\n"
                        f"Progress: {progress:.0f}%"
                    )
                elif status == 'merging':
                    await update_status(
                        f"🔀 *Merging Audio Tracks*\n\n"
                        f"{message}"
                    )
                elif status == 'creating_video':
                    await update_status(
                        f"🎬 *Creating Final Video*\n\n"
                        f"{message}"
                    )
            
            # ============ LOAD SEGMENTS FOR SYNC ============
            segments = None
            sync_mode = session.settings.get("sync_mode", "auto")
            
            # Try to load segments from session
            segments_data = session.settings.get("segments", [])
            if segments_data:
                segments = [
                    SyncSegment(
                        id=s["id"],
                        start=s["start"],
                        end=s["end"],
                        text=s.get("text", "")
                    )
                    for s in segments_data
                ]
                logger.info(f"Loaded {len(segments)} segments for sync")
            
            # Or try from SRT file
            elif session.transcript_path:
                srt_path = Path(session.transcript_path)
                if srt_path.exists():
                    try:
                        segments = load_segments_from_srt(srt_path)
                        logger.info(f"Loaded {len(segments)} segments from SRT")
                    except Exception as e:
                        logger.warning(f"Failed to load SRT: {e}")
            
            # ============ SYNC AND MERGE ============
            await update_status(
                "🔄 *Synchronizing Hindi Audio*\n\n"
                f"Sync Mode: {sync_mode.upper()}\n"
                f"Segments: {len(segments) if segments else 'N/A'}\n\n"
                "_Matching your audio to video timing..._"
            )
            
            # Create dubbed video with sync
            result = await create_dubbed_video(
                user_id=user_id,
                original_video_path=Path(session.input_video_path),
                hindi_audio_path=hindi_audio_path,
                background_audio_path=Path(session.no_vocals_path),
                segments=segments,
                sync_mode=sync_mode,
                progress_callback=progress_callback
            )
            
            if not result or not result.output_path.exists():
                raise Exception("Video creation failed")
            
            # ============ SEND FINAL VIDEO ============
            final_video = result.output_path
            file_size = final_video.stat().st_size
            
            # Prepare sync info message
            sync_info = ""
            if result.sync_info:
                si = result.sync_info
                sync_info = (
                    f"\n*🔄 Sync Details:*\n"
                    f"• Original: {format_duration(si.original_duration)}\n"
                    f"• Synced: {format_duration(si.synced_duration)}\n"
                    f"• Adjustment: {si.speed_factor:.2f}x\n"
                    f"• Quality: {get_sync_quality_emoji(si.sync_quality)} {si.sync_quality.title()}"
                )
            
            await update_status(
                f"✅ *Video Ready!*\n\n"
                f"📹 Duration: {format_duration(result.duration)}\n"
                f"💾 Size: {format_file_size(file_size)}"
                f"{sync_info}\n\n"
                f"📤 Uploading to Telegram..."
            )
            
            await context.bot.send_chat_action(chat_id, ChatAction.UPLOAD_VIDEO)
            
            # Send video (as video or document based on size)
            if file_size <= 50 * 1024 * 1024:  # 50MB limit
                try:
                    await context.bot.send_video(
                        chat_id,
                        video=open(final_video, 'rb'),
                        caption=(
                            f"🎬 *Hindi Dubbed Video*\n\n"
                            f"📹 Duration: {format_duration(result.duration)}\n"
                            f"💾 Size: {format_file_size(file_size)}"
                            f"{sync_info}"
                        ),
                        parse_mode=ParseMode.MARKDOWN,
                        supports_streaming=True,
                        read_timeout=300,
                        write_timeout=300
                    )
                except Exception as e:
                    logger.warning(f"Video send failed, trying as document: {e}")
                    # Fallback to document
                    await context.bot.send_document(
                        chat_id,
                        document=open(final_video, 'rb'),
                        filename="hindi_dubbed_video.mp4",
                        caption=(
                            f"🎬 *Hindi Dubbed Video*\n\n"
                            f"📹 Duration: {format_duration(result.duration)}\n"
                            f"💾 Size: {format_file_size(file_size)}"
                        ),
                        parse_mode=ParseMode.MARKDOWN,
                        read_timeout=300,
                        write_timeout=300
                    )
            else:
                # File too large for video, send as document
                await context.bot.send_document(
                    chat_id,
                    document=open(final_video, 'rb'),
                    filename="hindi_dubbed_video.mp4",
                    caption=(
                        f"🎬 *Hindi Dubbed Video*\n\n"
                        f"📹 Duration: {format_duration(result.duration)}\n"
                        f"💾 Size: {format_file_size(file_size)}\n\n"
                        f"_(Sent as document due to large size)_"
                    ),
                    parse_mode=ParseMode.MARKDOWN,
                    read_timeout=300,
                    write_timeout=300
                )
            
            # Success message
            quality_msg = ""
            if result.sync_info:
                quality_msg = get_sync_quality_message(result.sync_info.sync_quality)
            
            await update.message.reply_text(
                f"🎉 *Dubbing Complete!*\n\n"
                f"{quality_msg}\n\n"
                f"━━━━━━━━━━━━━━━━━━━━\n\n"
                f"✨ Send another YouTube URL for new video!\n\n"
                f"📊 Use /status to check progress\n"
                f"⚙️ Use /settings to change quality",
                parse_mode=ParseMode.MARKDOWN
            )
            
            # Reset session for next video
            session_manager.reset_session(user_id)
            
            logger.info(f"User {user_id}: Dubbing completed successfully!")
            
        except Exception as e:
            logger.error(f"Audio merge error: {e}")
            import traceback
            logger.error(traceback.format_exc())
            
            await update.message.reply_text(
                f"❌ *Processing Failed*\n\n"
                f"Error: {str(e)[:200]}\n\n"
                f"Please try again:\n"
                f"• Check audio file format\n"
                f"• Try shorter audio\n"
                f"• Use /clean and start fresh",
                parse_mode=ParseMode.MARKDOWN
            )
            
            session_manager.update_session(
                user_id,
                stage=ProcessingStage.FAILED,
                error_message=str(e)
            )
        
        finally:
            self.processing_users[user_id] = False
    
    # ==================== BOT INITIALIZATION ====================
    
    async def post_init(self, application: Application):
        """Post-initialization setup"""
        # Set bot commands
        commands = [
            BotCommand("start", "🚀 Start the bot"),
            BotCommand("help", "📚 Show help"),
            BotCommand("status", "📊 Check processing status"),
            BotCommand("settings", "⚙️ Change settings"),
            BotCommand("sync", "🔄 Sync mode settings"),
            BotCommand("cancel", "🚫 Cancel current operation"),
            BotCommand("clean", "🧹 Clean temporary files"),
        ]
        
        await application.bot.set_my_commands(commands)
        logger.info("Bot commands registered")
        
        # Log bot info
        bot_info = await application.bot.get_me()
        logger.info(f"Bot started: @{bot_info.username}")
        print(f"\n✅ Bot is running: @{bot_info.username}")
        print(f"📱 Open Telegram and send /start to @{bot_info.username}")
    
    def run(self):
        """Run the bot"""
        print("\n" + "=" * 50)
        print("🎬 Hindi Dubbing Bot")
        print("=" * 50)
        
        # Initialize
        if not initialize_bot():
            print("❌ Initialization failed!")
            return
        
        # Check requirements
        reqs = check_system_requirements()
        
        if not reqs.get('ffmpeg'):
            print("\n❌ FFmpeg is required but not found!")
            print("\nInstall FFmpeg:")
            print("  Ubuntu/Debian: sudo apt install ffmpeg")
            print("  MacOS: brew install ffmpeg")
            print("  Windows: Download from https://ffmpeg.org/download.html")
            return
        
        print(f"\n📋 System Check:")
        print(f"  • Python: {'✅' if reqs.get('python') else '❌'}")
        print(f"  • FFmpeg: {'✅' if reqs.get('ffmpeg') else '❌'}")
        print(f"  • CUDA/GPU: {'✅ ' + str(reqs.get('gpu_name', '')) if reqs.get('cuda') else '❌ (CPU mode)'}")
        print(f"  • Disk Space: {reqs.get('disk_space_gb', 0):.1f} GB free")
        
        # Build application
        print("\n🔧 Starting Telegram bot...")
        
        self.app = (
            Application.builder()
            .token(self.token)
            .post_init(self.post_init)
            .read_timeout(60)
            .write_timeout(60)
            .connect_timeout(30)
            .build()
        )
        
        # Add handlers
        self.app.add_handler(CommandHandler("start", self.start_command))
        self.app.add_handler(CommandHandler("help", self.help_command))
        self.app.add_handler(CommandHandler("status", self.status_command))
        self.app.add_handler(CommandHandler("settings", self.settings_command))
        self.app.add_handler(CommandHandler("sync", self.sync_command))
        self.app.add_handler(CommandHandler("cancel", self.cancel_command))
        self.app.add_handler(CommandHandler("clean", self.clean_command))
        
        # Callback handler
        self.app.add_handler(CallbackQueryHandler(self.handle_callback))
        
        # Audio handler (for Hindi audio files)
        self.app.add_handler(MessageHandler(
            filters.AUDIO | filters.VOICE | filters.Document.AUDIO | filters.Document.ALL,
            self.handle_audio
        ))
        
        # Text/URL handler
        self.app.add_handler(MessageHandler(
            filters.TEXT & ~filters.COMMAND,
            self.handle_message
        ))
        
        print("\n" + "=" * 50)
        print("🤖 Bot is ready!")
        print("=" * 50)
        print("\n🛑 Press Ctrl+C to stop\n")
        
        # Run polling
        self.app.run_polling(
            allowed_updates=Update.ALL_TYPES,
            drop_pending_updates=True
        )


# ==================== MAIN ENTRY POINT ====================

def main():
    """Main entry point"""
    try:
        bot = HindiDubbingBot()
        bot.run()
    except KeyboardInterrupt:
        print("\n\n👋 Bot stopped by user")
    except ValueError as e:
        print(f"\n❌ Configuration Error:\n{e}")
        print("\nTo fix this:")
        print("1. Get bot token from @BotFather on Telegram")
        print("2. Set token: export TELEGRAM_BOT_TOKEN='your_token'")
        print("3. Or edit bot_config.json file")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Fatal Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()