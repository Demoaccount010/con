"""
Main Telegram Bot
Hindi Dubbing Bot - Complete Telegram Integration

Single command to run: python bot.py
All control through Telegram
"""

import os
import sys
import asyncio
import logging
from pathlib import Path
from typing import Optional, Dict
from datetime import datetime

# Telegram imports
try:
    from telegram import (
        Update, 
        InlineKeyboardButton, 
        InlineKeyboardMarkup,
        BotCommand
    )
    from telegram.ext import (
        Application,
        CommandHandler,
        MessageHandler,
        CallbackQueryHandler,
        ContextTypes,
        filters
    )
    from telegram.constants import ParseMode, ChatAction
    TELEGRAM_AVAILABLE = True
except ImportError:
    TELEGRAM_AVAILABLE = False
    print("❌ python-telegram-bot not installed!")
    print("Run: pip install python-telegram-bot")
    sys.exit(1)

# Local imports
from config import config, ProcessingStage, QualityPreset, Messages, STAGE_EMOJI
from utils import (
    logger,
    session_manager,
    is_youtube_url,
    format_file_size,
    format_duration,
    get_user_workspace,
    initialize_bot,
    check_system_requirements,
)
from downloader import YouTubeDownloader
from audio_processor import AudioProcessor
from transcription import WhisperTranscriber, transcribe_audio
from translator import HindiTranslator, translate_and_save
from merger import VideoMerger, create_dubbed_video


class HindiDubbingBot:
    """
    Main Telegram Bot for Hindi Dubbing
    Handles complete workflow from URL to dubbed video
    """
    
    def __init__(self):
        self.token = config.telegram.bot_token
        
        if not self.token:
            # Try environment variable
            self.token = os.getenv("TELEGRAM_BOT_TOKEN", "")
        
        if not self.token:
            raise ValueError(
                "Bot token not found!\n"
                "Set TELEGRAM_BOT_TOKEN environment variable or\n"
                "Add token in bot_config.json"
            )
        
        self.app: Optional[Application] = None
        self.processing_users: Dict[int, bool] = {}
        
        logger.info("HindiDubbingBot initialized")
    
    async def start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /start command"""
        user = update.effective_user
        session_manager.get_session(user.id, user.username)
        
        await update.message.reply_text(
            Messages.WELCOME,
            parse_mode=ParseMode.MARKDOWN
        )
        logger.info(f"User {user.id} ({user.username}) started bot")
    
    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /help command"""
        await update.message.reply_text(
            Messages.HELP,
            parse_mode=ParseMode.MARKDOWN
        )
    
    async def status_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /status command"""
        user_id = update.effective_user.id
        session = session_manager.get_session(user_id)
        
        if session.current_stage == ProcessingStage.IDLE:
            await update.message.reply_text(Messages.STATUS_IDLE)
        else:
            emoji = STAGE_EMOJI.get(session.current_stage, "🔄")
            stage_name = session.current_stage.value.replace("_", " ").title()
            
            status_text = Messages.STATUS_PROCESSING.format(
                stage=f"{emoji} {stage_name}",
                title=session.video_title or "Unknown",
                progress="In progress..."
            )
            await update.message.reply_text(status_text, parse_mode=ParseMode.MARKDOWN)
    
    async def cancel_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /cancel command"""
        user_id = update.effective_user.id
        
        if user_id in self.processing_users:
            self.processing_users[user_id] = False
            session_manager.update_session(user_id, stage=ProcessingStage.CANCELLED)
            await update.message.reply_text(Messages.CANCELLED)
        else:
            await update.message.reply_text("No active operation to cancel.")
    
    async def settings_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /settings command"""
        user_id = update.effective_user.id
        session = session_manager.get_session(user_id)
        
        keyboard = [
            [
                InlineKeyboardButton("🔽 Low", callback_data="quality_low"),
                InlineKeyboardButton("📊 Medium", callback_data="quality_medium"),
            ],
            [
                InlineKeyboardButton("📈 High", callback_data="quality_high"),
                InlineKeyboardButton("🚀 Ultra", callback_data="quality_ultra"),
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        text = Messages.SETTINGS_MENU.format(
            quality=session.quality_preset.value,
            whisper=config.whisper.model_size
        )
        
        await update.message.reply_text(
            text,
            reply_markup=reply_markup,
            parse_mode=ParseMode.MARKDOWN
        )
    
    async def clean_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /clean command"""
        user_id = update.effective_user.id
        workspace = get_user_workspace(user_id)
        
        # Clean temp files
        cleaned = 0
        for folder in ["temp", "audio", "separated"]:
            folder_path = workspace.get(folder)
            if folder_path and folder_path.exists():
                for f in folder_path.iterdir():
                    if f.is_file():
                        f.unlink()
                        cleaned += 1
        
        await update.message.reply_text(f"🧹 Cleaned {cleaned} temporary files.")
    
    async def handle_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle inline keyboard callbacks"""
        query = update.callback_query
        await query.answer()
        
        user_id = query.from_user.id
        data = query.data
        
        if data.startswith("quality_"):
            quality_name = data.replace("quality_", "")
            quality_map = {
                "low": QualityPreset.LOW,
                "medium": QualityPreset.MEDIUM,
                "high": QualityPreset.HIGH,
                "ultra": QualityPreset.ULTRA
            }
            
            if quality_name in quality_map:
                session = session_manager.get_session(user_id)
                session.quality_preset = quality_map[quality_name]
                session_manager.save_session(user_id)
                
                await query.edit_message_text(
                    Messages.QUALITY_CHANGED.format(quality=quality_name.upper())
                )
    
    async def handle_url(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle YouTube URL messages"""
        user_id = update.effective_user.id
        url = update.message.text.strip()
        
        # Check if already processing
        if self.processing_users.get(user_id):
            await update.message.reply_text(
                "⚠️ Already processing a video. Wait or use /cancel"
            )
            return
        
        # Validate URL
        if not is_youtube_url(url):
            await update.message.reply_text(Messages.ERROR_INVALID_URL)
            return
        
        # Start processing
        self.processing_users[user_id] = True
        
        try:
            await self.process_youtube_video(update, context, url)
        except Exception as e:
            logger.error(f"Processing error for user {user_id}: {e}")
            await update.message.reply_text(
                Messages.ERROR_PROCESSING_FAILED.format(error=str(e)[:200])
            )
        finally:
            self.processing_users[user_id] = False
    
    async def process_youtube_video(
        self, 
        update: Update, 
        context: ContextTypes.DEFAULT_TYPE, 
        url: str
    ):
        """Complete processing pipeline for YouTube video"""
        user_id = update.effective_user.id
        chat_id = update.effective_chat.id
        session = session_manager.get_session(user_id)
        workspace = get_user_workspace(user_id)
        
        status_msg = await update.message.reply_text(Messages.URL_RECEIVED)
        
        async def update_status(text: str):
            """Update status message"""
            try:
                await status_msg.edit_text(text, parse_mode=ParseMode.MARKDOWN)
            except:
                pass
        
        async def progress_callback(info: dict):
            """Handle progress updates"""
            if info.get("status") == "downloading":
                text = Messages.DOWNLOADING.format(
                    progress=f"{info.get('progress', 0):.1f}%"
                )
                await update_status(text)
        
        try:
            # === STEP 1: Download Video ===
            await context.bot.send_chat_action(chat_id, ChatAction.TYPING)
            
            downloader = YouTubeDownloader(user_id, session.quality_preset)
            video_info = await downloader.get_video_info(url)
            
            if not video_info:
                raise Exception("Failed to get video info")
            
            await update_status(
                f"📥 *Downloading...*\n\n"
                f"📹 {video_info.title[:50]}...\n"
                f"⏱ {format_duration(video_info.duration)}\n"
                f"💾 ~{format_file_size(video_info.filesize_approx)}"
            )
            
            video_path = await downloader.download_video(url, progress_callback)
            
            if not video_path:
                raise Exception("Download failed")
            
            await update_status(Messages.DOWNLOAD_COMPLETE.format(
                size=format_file_size(video_path.stat().st_size),
                duration=format_duration(video_info.duration)
            ))
            
            # === STEP 2: Extract Audio ===
            await update_status(Messages.EXTRACTING_AUDIO)
            await context.bot.send_chat_action(chat_id, ChatAction.RECORD_VOICE)
            
            processor = AudioProcessor(user_id)
            audio_path = await processor.extract_audio(video_path)
            
            if not audio_path:
                raise Exception("Audio extraction failed")
            
            # === STEP 3: Separate Vocals ===
            estimate = "5-10 minutes" if config.demucs.device == "cpu" else "1-3 minutes"
            await update_status(Messages.SEPARATING_VOCALS.format(estimate=estimate))
            
            separation = await processor.separate_vocals_demucs(audio_path)
            
            if not separation:
                raise Exception("Vocal separation failed")
            
            await update_status(Messages.SEPARATION_COMPLETE)
            
            # === STEP 4: Transcribe ===
            await update_status(Messages.TRANSCRIBING)
            await context.bot.send_chat_action(chat_id, ChatAction.TYPING)
            
            transcription, transcript_files = await transcribe_audio(
                separation.vocals_path,
                user_id,
                progress_callback
            )
            
            if not transcription:
                raise Exception("Transcription failed")
            
            await update_status(Messages.TRANSCRIPTION_COMPLETE)
            
            # === STEP 5: Translate ===
            await update_status(Messages.TRANSLATING)
            
            translation, translation_files = await translate_and_save(
                transcription,
                user_id,
                progress_callback
            )
            
            if not translation:
                raise Exception("Translation failed")
            
            # === STEP 6: Send Hindi Script ===
            session_manager.update_session(
                user_id,
                stage=ProcessingStage.WAITING_HINDI_AUDIO
            )
            
            # Send bilingual script
            script_path = translation_files.get("bilingual")
            if script_path and script_path.exists():
                await context.bot.send_document(
                    chat_id,
                    document=open(script_path, 'rb'),
                    filename="hindi_dubbing_script.txt",
                    caption="📄 *Hindi Dubbing Script*\n\nEdit this and record audio",
                    parse_mode=ParseMode.MARKDOWN
                )
            
            # Send Hindi SRT
            srt_path = translation_files.get("hindi_srt")
            if srt_path and srt_path.exists():
                await context.bot.send_document(
                    chat_id,
                    document=open(srt_path, 'rb'),
                    filename="hindi_subtitles.srt",
                    caption="📝 Hindi subtitles"
                )
            
            await update.message.reply_text(
                Messages.TRANSLATION_COMPLETE,
                parse_mode=ParseMode.MARKDOWN
            )
            
            logger.info(f"User {user_id}: Processing complete, waiting for Hindi audio")
            
        except Exception as e:
            logger.error(f"Pipeline error: {e}")
            session_manager.update_session(
                user_id,
                stage=ProcessingStage.FAILED,
                error_message=str(e)
            )
            raise
    
    async def handle_audio(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle audio file uploads (Hindi narration)"""
        user_id = update.effective_user.id
        chat_id = update.effective_chat.id
        session = session_manager.get_session(user_id)
        
        # Check if waiting for audio
        if session.current_stage != ProcessingStage.WAITING_HINDI_AUDIO:
            await update.message.reply_text(
                "⚠️ First send a YouTube URL to process!"
            )
            return
        
        # Check required files exist
        if not session.no_vocals_path or not session.input_video_path:
            await update.message.reply_text(
                "❌ Missing processed files. Please start again with YouTube URL."
            )
            session_manager.reset_session(user_id)
            return
        
        workspace = get_user_workspace(user_id)
        
        status_msg = await update.message.reply_text(Messages.AUDIO_RECEIVED)
        
        try:
            # Download audio file from Telegram
            audio_file = update.message.audio or update.message.voice or update.message.document
            
            if not audio_file:
                await update.message.reply_text(Messages.ERROR_NO_AUDIO)
                return
            
            # Download file
            hindi_audio_path = workspace["audio"] / "hindi_narration.mp3"
            
            file = await context.bot.get_file(audio_file.file_id)
            await file.download_to_drive(hindi_audio_path)
            
            logger.info(f"Hindi audio received: {hindi_audio_path}")
            
            # Update session
            session_manager.update_session(
                user_id,
                hindi_audio_path=str(hindi_audio_path)
            )
            
            # Progress callback
            async def progress_callback(info: dict):
                try:
                    await status_msg.edit_text(
                        f"🔄 {info.get('message', 'Processing...')}"
                    )
                except:
                    pass
            
            # === Merge and create final video ===
            await status_msg.edit_text(Messages.MERGING)
            await context.bot.send_chat_action(chat_id, ChatAction.RECORD_VIDEO)
            
            result = await create_dubbed_video(
                user_id,
                Path(session.input_video_path),
                hindi_audio_path,
                Path(session.no_vocals_path),
                progress_callback
            )
            
            if not result:
                raise Exception("Video creation failed")
            
            # === Send final video ===
            await status_msg.edit_text(Messages.PROCESSING_COMPLETE)
            
            final_video = result.output_path
            file_size = final_video.stat().st_size
            
            # Check Telegram file size limit (50MB for bots)
            if file_size <= 50 * 1024 * 1024:
                await context.bot.send_video(
                    chat_id,
                    video=open(final_video, 'rb'),
                    caption=(
                        f"🎬 *Hindi Dubbed Video*\n\n"
                        f"⏱ Duration: {format_duration(result.duration)}\n"
                        f"💾 Size: {format_file_size(file_size)}"
                    ),
                    parse_mode=ParseMode.MARKDOWN,
                    supports_streaming=True
                )
            else:
                # File too large, send as document
                await context.bot.send_document(
                    chat_id,
                    document=open(final_video, 'rb'),
                    filename="hindi_dubbed_video.mp4",
                    caption=(
                        f"🎬 *Hindi Dubbed Video*\n\n"
                        f"⏱ Duration: {format_duration(result.duration)}\n"
                        f"💾 Size: {format_file_size(file_size)}\n\n"
                        f"(File sent as document due to size)"
                    ),
                    parse_mode=ParseMode.MARKDOWN
                )
            
            await update.message.reply_text(
                "✅ *Dubbing Complete!*\n\n"
                "Send another YouTube URL for new video.",
                parse_mode=ParseMode.MARKDOWN
            )
            
            # Reset session for new video
            session_manager.reset_session(user_id)
            
            logger.info(f"User {user_id}: Dubbing completed successfully!")
            
        except Exception as e:
            logger.error(f"Audio merge error: {e}")
            await update.message.reply_text(
                Messages.ERROR_PROCESSING_FAILED.format(error=str(e)[:200])
            )
            session_manager.update_session(
                user_id,
                stage=ProcessingStage.FAILED,
                error_message=str(e)
            )
    
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle general text messages"""
        text = update.message.text.strip()
        
        # Check if it's a URL
        if 'youtube.com' in text or 'youtu.be' in text:
            await self.handle_url(update, context)
        else:
            await update.message.reply_text(
                "📹 Send a YouTube URL to start dubbing!\n"
                "Or use /help for more info."
            )
    
    async def post_init(self, application: Application):
        """Post-initialization setup"""
        # Set bot commands
        commands = [
            BotCommand("start", "Start the bot"),
            BotCommand("help", "Show help"),
            BotCommand("status", "Check processing status"),
            BotCommand("settings", "Change settings"),
            BotCommand("cancel", "Cancel current operation"),
            BotCommand("clean", "Clean temporary files"),
        ]
        await application.bot.set_my_commands(commands)
        logger.info("Bot commands set")
    
    def run(self):
        """Run the bot"""
        print("\n" + "=" * 50)
        print("🎬 Hindi Dubbing Bot")
        print("=" * 50)
        
        # Initialize
        if not initialize_bot():
            print("❌ Initialization failed!")
            return
        
        # Check requirements
        reqs = check_system_requirements()
        if not reqs.get('ffmpeg'):
            print("❌ FFmpeg required! Install it first.")
            return
        
        # Build application
        self.app = (
            Application.builder()
            .token(self.token)
            .post_init(self.post_init)
            .build()
        )
        
        # Add handlers
        self.app.add_handler(CommandHandler("start", self.start_command))
        self.app.add_handler(CommandHandler("help", self.help_command))
        self.app.add_handler(CommandHandler("status", self.status_command))
        self.app.add_handler(CommandHandler("settings", self.settings_command))
        self.app.add_handler(CommandHandler("cancel", self.cancel_command))
        self.app.add_handler(CommandHandler("clean", self.clean_command))
        
        self.app.add_handler(CallbackQueryHandler(self.handle_callback))
        
        # Audio handler
        self.app.add_handler(MessageHandler(
            filters.AUDIO | filters.VOICE | filters.Document.AUDIO,
            self.handle_audio
        ))
        
        # Text/URL handler
        self.app.add_handler(MessageHandler(
            filters.TEXT & ~filters.COMMAND,
            self.handle_message
        ))
        
        print("\n✅ Bot is running!")
        print("📱 Open Telegram and send /start to your bot")
        print("🛑 Press Ctrl+C to stop\n")
        
        # Run bot
        self.app.run_polling(
            allowed_updates=Update.ALL_TYPES,
            drop_pending_updates=True
        )


def main():
    """Main entry point"""
    try:
        bot = HindiDubbingBot()
        bot.run()
    except KeyboardInterrupt:
        print("\n\n👋 Bot stopped by user")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        logger.exception("Bot crashed")
        sys.exit(1)


if __name__ == "__main__":
    main()