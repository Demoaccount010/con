"""
Translation Module
Hindi Dubbing Bot - Telegram Integrated

Handles:
- English to Hindi translation
- Multiple translation services support
- Script formatting for dubbing
"""

import asyncio
import time
import re
from pathlib import Path
from typing import Optional, Dict, List, Tuple, Any
from dataclasses import dataclass

try:
    from deep_translator import GoogleTranslator, MyMemoryTranslator
    TRANSLATOR_AVAILABLE = True
except ImportError:
    TRANSLATOR_AVAILABLE = False

from config import config, ProcessingStage
from utils import (
    logger,
    session_manager,
    get_user_workspace,
    log_execution_time,
    retry_sync,
)
from transcription import TranscriptSegment, TranscriptionResult, SRTHandler


@dataclass
class TranslatedSegment:
    """Translated segment with original and translated text"""
    id: int
    start: float
    end: float
    original_text: str
    translated_text: str
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "start": self.start,
            "end": self.end,
            "original": self.original_text,
            "translated": self.translated_text,
        }
    
    @property
    def duration(self) -> float:
        return self.end - self.start


@dataclass
class TranslationResult:
    """Complete translation result"""
    segments: List[TranslatedSegment]
    original_language: str
    target_language: str
    total_segments: int
    
    def get_hindi_script(self) -> str:
        """Get Hindi script formatted for dubbing"""
        lines = []
        for seg in self.segments:
            lines.append(f"[{seg.id:03d}] {seg.translated_text}")
        return "\n\n".join(lines)
    
    def get_bilingual_script(self) -> str:
        """Get script with both English and Hindi"""
        lines = [
            "=" * 60,
            "BILINGUAL DUBBING SCRIPT",
            "English → Hindi",
            "=" * 60,
            ""
        ]
        
        for seg in self.segments:
            start_min = int(seg.start // 60)
            start_sec = int(seg.start % 60)
            end_min = int(seg.end // 60)
            end_sec = int(seg.end % 60)
            
            lines.extend([
                f"[{seg.id:03d}] [{start_min:02d}:{start_sec:02d} - {end_min:02d}:{end_sec:02d}]",
                f"EN: {seg.original_text}",
                f"HI: {seg.translated_text}",
                "",
                "-" * 40,
                ""
            ])
        
        return "\n".join(lines)
    
    def to_hindi_srt(self) -> str:
        """Generate Hindi SRT content"""
        blocks = []
        for seg in self.segments:
            # Format timestamps
            start_td = seg.start
            end_td = seg.end
            
            start_h = int(start_td // 3600)
            start_m = int((start_td % 3600) // 60)
            start_s = int(start_td % 60)
            start_ms = int((start_td % 1) * 1000)
            
            end_h = int(end_td // 3600)
            end_m = int((end_td % 3600) // 60)
            end_s = int(end_td % 60)
            end_ms = int((end_td % 1) * 1000)
            
            start_ts = f"{start_h:02d}:{start_m:02d}:{start_s:02d},{start_ms:03d}"
            end_ts = f"{end_h:02d}:{end_m:02d}:{end_s:02d},{end_ms:03d}"
            
            block = f"{seg.id}\n{start_ts} --> {end_ts}\n{seg.translated_text}\n"
            blocks.append(block)
        
        return "\n".join(blocks)


class HindiTranslator:
    """
    English to Hindi translator
    Uses multiple translation services with fallback
    """
    
    def __init__(self, user_id: int):
        self.user_id = user_id
        self.workspace = get_user_workspace(user_id)
        self.transcripts_dir = self.workspace["transcripts"]
        
        if not TRANSLATOR_AVAILABLE:
            raise ImportError("deep-translator not installed. Run: pip install deep-translator")
        
        # Initialize translators
        self.google_translator = GoogleTranslator(source='en', target='hi')
        self.backup_translator = MyMemoryTranslator(source='en', target='hi')
        
        # Rate limiting
        self.last_request_time = 0
        self.min_request_interval = config.translator.delay_between_requests
        
        logger.info(f"HindiTranslator initialized for user {user_id}")
    
    def _rate_limit(self):
        """Apply rate limiting between requests"""
        current_time = time.time()
        elapsed = current_time - self.last_request_time
        
        if elapsed < self.min_request_interval:
            time.sleep(self.min_request_interval - elapsed)
        
        self.last_request_time = time.time()
    
    @retry_sync(max_attempts=3, delay=1.0)
    def _translate_text(self, text: str) -> str:
        """
        Translate single text with retry and fallback
        
        Args:
            text: English text to translate
            
        Returns:
            Hindi translated text
        """
        if not text or not text.strip():
            return ""
        
        self._rate_limit()
        
        try:
            # Try Google Translate first
            result = self.google_translator.translate(text)
            return result if result else text
            
        except Exception as e:
            logger.warning(f"Google translate failed: {e}, trying backup...")
            
            try:
                # Fallback to MyMemory
                result = self.backup_translator.translate(text)
                return result if result else text
                
            except Exception as e2:
                logger.error(f"All translators failed: {e2}")
                return text  # Return original if all fail
    
    def _split_long_text(self, text: str, max_length: int = 4500) -> List[str]:
        """Split long text into chunks for translation"""
        if len(text) <= max_length:
            return [text]
        
        # Split by sentences
        sentences = re.split(r'(?<=[.!?])\s+', text)
        chunks = []
        current_chunk = ""
        
        for sentence in sentences:
            if len(current_chunk) + len(sentence) + 1 <= max_length:
                current_chunk += " " + sentence if current_chunk else sentence
            else:
                if current_chunk:
                    chunks.append(current_chunk)
                current_chunk = sentence
        
        if current_chunk:
            chunks.append(current_chunk)
        
        return chunks
    
    async def translate_text(self, text: str) -> str:
        """
        Async wrapper for text translation
        
        Args:
            text: English text
            
        Returns:
            Hindi text
        """
        loop = asyncio.get_event_loop()
        
        # Handle long text
        if len(text) > config.translator.max_chars_per_request:
            chunks = self._split_long_text(text)
            translated_chunks = []
            
            for chunk in chunks:
                translated = await loop.run_in_executor(
                    None, self._translate_text, chunk
                )
                translated_chunks.append(translated)
            
            return " ".join(translated_chunks)
        else:
            return await loop.run_in_executor(None, self._translate_text, text)
    
    @log_execution_time
    async def translate_transcription(
        self,
        transcription: TranscriptionResult,
        progress_callback=None
    ) -> Optional[TranslationResult]:
        """
        Translate complete transcription to Hindi
        
        Args:
            transcription: TranscriptionResult to translate
            progress_callback: Optional progress callback
            
        Returns:
            TranslationResult or None
        """
        # Update session
        session_manager.update_session(
            self.user_id,
            stage=ProcessingStage.TRANSLATING
        )
        
        logger.info(f"Translating {len(transcription.segments)} segments to Hindi")
        
        translated_segments = []
        total = len(transcription.segments)
        
        for i, seg in enumerate(transcription.segments):
            try:
                # Translate segment text
                hindi_text = await self.translate_text(seg.text)
                
                translated_seg = TranslatedSegment(
                    id=seg.id,
                    start=seg.start,
                    end=seg.end,
                    original_text=seg.text,
                    translated_text=hindi_text
                )
                translated_segments.append(translated_seg)
                
                # Progress update
                if progress_callback and (i + 1) % 5 == 0:
                    progress = ((i + 1) / total) * 100
                    await progress_callback({
                        "status": "translating",
                        "progress": progress,
                        "current": i + 1,
                        "total": total
                    })
                
                logger.debug(f"Translated segment {i + 1}/{total}")
                
            except Exception as e:
                logger.error(f"Failed to translate segment {seg.id}: {e}")
                # Use original text as fallback
                translated_segments.append(TranslatedSegment(
                    id=seg.id,
                    start=seg.start,
                    end=seg.end,
                    original_text=seg.text,
                    translated_text=seg.text
                ))
        
        result = TranslationResult(
            segments=translated_segments,
            original_language="en",
            target_language="hi",
            total_segments=len(translated_segments)
        )
        
        logger.info("Translation completed successfully")
        return result
    
    async def save_translation(
        self,
        translation: TranslationResult,
        base_name: str = "hindi"
    ) -> Dict[str, Path]:
        """
        Save translation in multiple formats
        
        Args:
            translation: TranslationResult to save
            base_name: Base filename
            
        Returns:
            Dict of format to path
        """
        saved_files = {}
        self.transcripts_dir.mkdir(parents=True, exist_ok=True)
        
        # Save Hindi script (plain text for dubbing)
        hindi_script_path = self.transcripts_dir / f"{base_name}_script.txt"
        with open(hindi_script_path, 'w', encoding='utf-8') as f:
            f.write(translation.get_hindi_script())
        saved_files["hindi_script"] = hindi_script_path
        logger.info(f"Saved Hindi script: {hindi_script_path}")
        
        # Save bilingual script
        bilingual_path = self.transcripts_dir / f"{base_name}_bilingual.txt"
        with open(bilingual_path, 'w', encoding='utf-8') as f:
            f.write(translation.get_bilingual_script())
        saved_files["bilingual"] = bilingual_path
        logger.info(f"Saved bilingual script: {bilingual_path}")
        
        # Save Hindi SRT
        hindi_srt_path = self.transcripts_dir / f"{base_name}_subtitles.srt"
        with open(hindi_srt_path, 'w', encoding='utf-8') as f:
            f.write(translation.to_hindi_srt())
        saved_files["hindi_srt"] = hindi_srt_path
        logger.info(f"Saved Hindi SRT: {hindi_srt_path}")
        
        # Update session
        session_manager.update_session(
            self.user_id,
            hindi_script_path=str(hindi_script_path),
            hindi_srt_path=str(hindi_srt_path)
        )
        
        return saved_files


async def translate_and_save(
    transcription: TranscriptionResult,
    user_id: int,
    progress_callback=None
) -> Tuple[Optional[TranslationResult], Dict[str, Path]]:
    """
    Complete translation pipeline
    
    Args:
        transcription: Transcription to translate
        user_id: User ID
        progress_callback: Optional progress callback
        
    Returns:
        Tuple of (TranslationResult, saved_files)
    """
    translator = HindiTranslator(user_id)
    
    try:
        translation = await translator.translate_transcription(
            transcription,
            progress_callback
        )
        
        if not translation:
            return None, {}
        
        saved_files = await translator.save_translation(translation)
        return translation, saved_files
        
    except Exception as e:
        logger.error(f"Translation pipeline failed: {e}")
        return None, {}


async def test_translator():
    """Test translation module"""
    print("\n" + "=" * 50)
    print("🧪 Testing Translation Module")
    print("=" * 50)
    
    print(f"\n📋 Dependency Check:")
    print(f"  deep-translator: {'✅' if TRANSLATOR_AVAILABLE else '❌'}")
    
    if TRANSLATOR_AVAILABLE:
        print("\n🔤 Testing translation...")
        translator = GoogleTranslator(source='en', target='hi')
        test_text = "Hello, how are you?"
        result = translator.translate(test_text)
        print(f"  EN: {test_text}")
        print(f"  HI: {result}")
    
    print("\n✅ Translation module loaded!")
    print("=" * 50)


if __name__ == "__main__":
    asyncio.run(test_translator())