"""
Telegram Inline Keyboards (Updated)
===================================
Reusable keyboard builders for bot interactions.
"""

from typing import List, Optional, Dict, Any
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton


class KeyboardBuilder:
    """
    Builder class for Telegram keyboards.
    
    Creates inline and reply keyboards for various bot interactions.
    """
    
    @staticmethod
    def main_menu() -> InlineKeyboardMarkup:
        """Main menu keyboard."""
        keyboard = [
            [
                InlineKeyboardButton("📝 New Task", callback_data="menu_new_task"),
                InlineKeyboardButton("📊 Status", callback_data="menu_status"),
            ],
            [
                InlineKeyboardButton("👷 Workers", callback_data="menu_workers"),
                InlineKeyboardButton("📜 History", callback_data="menu_history"),
            ],
            [
                InlineKeyboardButton("⚙️ Settings", callback_data="menu_settings"),
                InlineKeyboardButton("❓ Help", callback_data="menu_help"),
            ],
        ]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def task_actions(task_id: str) -> InlineKeyboardMarkup:
        """Actions for a specific task."""
        keyboard = [
            [
                InlineKeyboardButton("▶️ Select Worker", callback_data=f"task_select_worker_{task_id}"),
                InlineKeyboardButton("📋 Details", callback_data=f"task_details_{task_id}"),
            ],
            [
                InlineKeyboardButton("✏️ Modify", callback_data=f"task_modify_{task_id}"),
                InlineKeyboardButton("❌ Cancel", callback_data=f"task_cancel_{task_id}"),
            ],
            [
                InlineKeyboardButton("🔙 Back", callback_data="menu_main"),
            ],
        ]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def worker_selection(task_id: str, workers: List[Dict[str, Any]]) -> InlineKeyboardMarkup:
        """
        Keyboard to select a VPS for a task.
        Shows Online/Offline status.
        """
        keyboard = []
        
        # Add "Auto Select" option
        keyboard.append([
            InlineKeyboardButton("🤖 Auto Select (Best VPS)", callback_data=f"worker_auto_{task_id}")
        ])
        
        # Add individual workers
        if not workers:
            keyboard.append([InlineKeyboardButton("❌ No Workers Found", callback_data="none")])
        else:
            for worker in workers:
                name = worker.get("name", "Unknown")
                worker_id = worker.get("worker_id", "")
                is_online = worker.get("is_online", False)
                
                status_icon = "🟢" if is_online else "🔴"
                text = f"{status_icon} {name}"
                
                keyboard.append([
                    InlineKeyboardButton(
                        text,
                        callback_data=f"worker_assign_{worker_id}_{task_id}"
                    )
                ])
        
        keyboard.append([
            InlineKeyboardButton("🔙 Cancel", callback_data=f"task_cancel_{task_id}")
        ])
        
        return InlineKeyboardMarkup(keyboard)

    @staticmethod
    def confirm_execution(task_id: str, worker_name: str) -> InlineKeyboardMarkup:
        """Confirm execution on specific worker."""
        keyboard = [
            [
                InlineKeyboardButton("🚀 Run Now", callback_data=f"task_run_{task_id}"),
                InlineKeyboardButton("❌ Cancel", callback_data=f"task_cancel_{task_id}"),
            ],
        ]
        return InlineKeyboardMarkup(keyboard)

    @staticmethod
    def confirm_action(action: str, data: str) -> InlineKeyboardMarkup:
        """Confirmation keyboard."""
        keyboard = [
            [
                InlineKeyboardButton("✅ Yes", callback_data=f"confirm_{action}_{data}"),
                InlineKeyboardButton("❌ No", callback_data=f"cancel_{action}_{data}"),
            ],
        ]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def worker_list(workers: List[Dict[str, Any]]) -> InlineKeyboardMarkup:
        """List of workers keyboard."""
        keyboard = []
        
        for worker in workers[:10]:  # Max 10 workers
            status_icon = "🟢"  # Placeholder, handled by handler logic usually
            name = worker.get("name", "Unknown")[:20]
            worker_id = worker.get("worker_id", "")
            
            keyboard.append([
                InlineKeyboardButton(
                    f"{status_icon} {name}",
                    callback_data=f"worker_info_{worker_id}"
                )
            ])
        
        keyboard.append([
            InlineKeyboardButton("➕ Add Worker", callback_data="worker_add"),
            InlineKeyboardButton("🔄 Refresh", callback_data="workers_refresh"),
        ])
        keyboard.append([
            InlineKeyboardButton("🔙 Back", callback_data="menu_main"),
        ])
        
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def history_navigation(page: int, total_pages: int) -> InlineKeyboardMarkup:
        """History pagination keyboard."""
        keyboard = []
        nav_row = []
        
        if page > 1:
            nav_row.append(
                InlineKeyboardButton("◀️ Prev", callback_data=f"history_page_{page-1}")
            )
        
        nav_row.append(
            InlineKeyboardButton(f"📄 {page}/{total_pages}", callback_data="history_current")
        )
        
        if page < total_pages:
            nav_row.append(
                InlineKeyboardButton("Next ▶️", callback_data=f"history_page_{page+1}")
            )
        
        keyboard.append(nav_row)
        keyboard.append([
            InlineKeyboardButton("🔙 Back", callback_data="menu_main")
        ])
        
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def settings_menu() -> InlineKeyboardMarkup:
        """Settings menu keyboard."""
        keyboard = [
            [
                InlineKeyboardButton("🔔 Notifications", callback_data="settings_notifications"),
                InlineKeyboardButton("🌐 Language", callback_data="settings_language"),
            ],
            [
                InlineKeyboardButton("🤖 Model", callback_data="settings_model"),
                InlineKeyboardButton("⏱️ Timeout", callback_data="settings_timeout"),
            ],
            [
                InlineKeyboardButton("🔙 Back", callback_data="menu_main"),
            ],
        ]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def back_button(callback_data: str = "menu_main") -> InlineKeyboardMarkup:
        """Simple back button."""
        keyboard = [[
            InlineKeyboardButton("🔙 Back", callback_data=callback_data)
        ]]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def yes_no(action_id: str) -> InlineKeyboardMarkup:
        """Simple Yes/No keyboard."""
        keyboard = [[
            InlineKeyboardButton("✅ Yes", callback_data=f"yes_{action_id}"),
            InlineKeyboardButton("❌ No", callback_data=f"no_{action_id}"),
        ]]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def reply_keyboard_main() -> ReplyKeyboardMarkup:
        """Main reply keyboard (persistent)."""
        keyboard = [
            [KeyboardButton("📝 New Task"), KeyboardButton("📊 Status")],
            [KeyboardButton("👷 Workers"), KeyboardButton("📜 History")],
            [KeyboardButton("❓ Help")],
        ]
        return ReplyKeyboardMarkup(
            keyboard,
            resize_keyboard=True,
            one_time_keyboard=False,
        )
    
    @staticmethod
    def task_type_selection() -> InlineKeyboardMarkup:
        """Task type selection keyboard."""
        keyboard = [
            [
                InlineKeyboardButton("🌐 Web Task", callback_data="tasktype_web"),
                InlineKeyboardButton("📁 File Task", callback_data="tasktype_file"),
            ],
            [
                InlineKeyboardButton("💻 Code Task", callback_data="tasktype_code"),
                InlineKeyboardButton("🔧 System Task", callback_data="tasktype_system"),
            ],
            [
                InlineKeyboardButton("🤖 Auto Detect", callback_data="tasktype_auto"),
            ],
            [
                InlineKeyboardButton("🔙 Cancel", callback_data="menu_main"),
            ],
        ]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def error_retry(action: str) -> InlineKeyboardMarkup:
        """Error with retry option."""
        keyboard = [
            [
                InlineKeyboardButton("🔄 Retry", callback_data=f"retry_{action}"),
                InlineKeyboardButton("🔙 Back", callback_data="menu_main"),
            ],
        ]
        return InlineKeyboardMarkup(keyboard)