"""
Telegram Message Handlers (Final Clean Version)
===============================================
Handles non-command messages, callbacks, worker execution, and setup.
"""

import re
import json
import aiohttp
from typing import Optional, Dict, Any
from datetime import datetime

from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode, ChatAction

from main_agent.utils.logger import Logger, get_logger
from main_agent.telegram.keyboards import KeyboardBuilder
from main_agent.storage.config_store import _get_store


class MessageHandler:
    """
    Handles regular messages, wizard flows, and shared UI logic.
    """
    
    def __init__(
        self,
        agent: Any,  # MainAgent
        auth_middleware: Any,  # AuthMiddleware
        logger: Optional[Logger] = None,
    ):
        self.agent = agent
        self.auth = auth_middleware
        self._logger = logger or get_logger("MessageHandler")
    
    async def handle_message(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ) -> None:
        """Handle incoming text messages."""
        if not update.message or not update.message.text:
            return
        
        user = update.effective_user
        text = update.message.text.strip()
        
        self._logger.debug(f"Message from {user.id}: {text[:50]}...")
        
        # --- 1. HANDLE TRAINING COMMAND ---
        if text.startswith("/train"):
            feedback = text.replace("/train", "").strip()
            if not feedback:
                await update.message.reply_text("Usage: /train <feedback>")
                return
            
            if hasattr(self.agent, '_learning') and self.agent._learning:
                self.agent._learning.record_task({
                    "input": "User Feedback", 
                    "feedback": feedback
                }, success=False)
            
            await update.message.reply_text("🧠 Thanks! Feedback recorded for improvement.")
            return

        # --- 2. GET USER STATE ---
        state, state_data = self.auth.get_user_state(user.id)
        
        # --- 3. STATE-BASED ROUTING ---
        
        # A. Worker Setup Wizard (Highest Priority)
        if state and state.startswith("worker_setup_"):
            await self._handle_worker_setup(update, context, text, state, state_data)
            return
        
        # B. Waiting for Task Input via Button
        elif state == "waiting_task":
            await self._handle_task_input(update, context, text)
            return
            
        # C. Waiting for Confirmation
        elif state == "waiting_confirmation":
            await self._handle_confirmation(update, context, text, state_data)
            return
            
        # --- 4. DEFAULT TEXT HANDLER ---
        await self._handle_new_task(update, context, text)
    
    async def _handle_new_task(self, update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> None:
        """Handle new task input or menu text commands."""
        text_lower = text.lower()
        
        if text_lower in ["📝 new task", "new task"]:
            await self.show_new_task_prompt(update, context)
        elif text_lower in ["📊 status", "status"]:
            await self.show_status(update, context)
        elif text_lower in ["👷 workers", "workers"]:
            await self.show_workers(update, context)
        elif text_lower in ["📜 history", "history"]:
            await self.show_history(update, context)
        elif text_lower in ["❓ help", "help"]:
            await self.show_help(update, context)
        else:
            # Treat as task/chat description
            await self._process_task(update, context, text)
    
    async def _handle_task_input(self, update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> None:
        """Handle task input when in waiting_task state."""
        self.auth.clear_user_state(update.effective_user.id)
        await self._process_task(update, context, text)
    
    async def _process_task(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
        task_description: str,
    ) -> None:
        """Process a task description (Chat vs Task)."""
        user = update.effective_user
        
        # Send typing indicator
        await context.bot.send_chat_action(
            chat_id=update.effective_chat.id,
            action=ChatAction.TYPING,
        )
        
        # Temporary thinking message
        status_msg = await update.message.reply_text("🤔 *Thinking...*", parse_mode=ParseMode.MARKDOWN)
        
        try:
            # Check readiness
            if not self.agent.is_ready:
                msg = "❌ *Agent Not Ready*\n\nPlease wait for startup to complete."
                await status_msg.edit_text(msg, parse_mode=ParseMode.MARKDOWN)
                return
            
            # --- EVOLUTION HANDLING ---
            if "learn" in task_description.lower() and "how" in task_description.lower():
                if hasattr(self.agent, '_evolution') and self.agent._evolution:
                    await status_msg.edit_text("🧠 *Evolution Mode*\nLearning from internet...", parse_mode=ParseMode.MARKDOWN)
                    result = self.agent._evolution.handle_evolution_request(task_description)
                    await status_msg.edit_text(result, parse_mode=ParseMode.MARKDOWN)
                    return

            # --- SYSTEM INFO SHORTCUT ---
            lower_input = task_description.lower()
            if any(k in lower_input for k in ["ram", "cpu", "memory", "usage"]) and "check" in lower_input:
                await status_msg.delete()
                await self.show_status(update, context)
                return
            
            # --- PLANNING ---
            task = self.agent.plan_task(task_description, user_id=user.id)
            
            # --- CHAT RESULT ---
            if task.is_conversational:
                await status_msg.delete()
                await update.message.reply_text(
                    task.response_text or "I heard you, but I'm not sure what to say.",
                    parse_mode=None
                )
                return
            
            # --- TASK RESULT ---
            task_id = task.plan_id
            if "tasks" not in context.user_data: context.user_data["tasks"] = {}
            context.user_data["tasks"][task_id] = task.to_full_dict()
            
            # Get workers for selection
            store = _get_store()
            workers = store.get_workers()
            
            response = f"✅ *Plan Created!*\n\n📌 *Goal:* {task.goal}\n📂 *Type:* `{task.task_type.value}`\n\n👇 *Select a VPS (Worker) to execute this:*"
            
            await status_msg.edit_text(
                response,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=KeyboardBuilder.worker_selection(task_id, workers)
            )
            
        except Exception as e:
            msg = f"❌ *Error:* {str(e)}"
            await status_msg.edit_text(msg, parse_mode=ParseMode.MARKDOWN)
    
    async def _handle_worker_setup(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE, text: str, state: str, state_data: Dict[str, Any]
    ) -> None:
        """Worker Setup Wizard."""
        user = update.effective_user
        if text.lower() == "cancel":
            self.auth.clear_user_state(user.id)
            await update.message.reply_text("❌ Setup cancelled.")
            return

        if state == "worker_setup_name":
            self.auth.set_user_state(user.id, "worker_setup_url", {"name": text})
            await update.message.reply_text(f"✅ Name: `{text}`\n\nEnter **Worker URL** (e.g., `http://1.2.3.4:8001`)", parse_mode=ParseMode.MARKDOWN)
            
        elif state == "worker_setup_url":
            if not text.startswith("http"): text = "http://" + text
            state_data["url"] = text
            self.auth.set_user_state(user.id, "worker_setup_token", state_data)
            await update.message.reply_text(f"✅ URL: `{text}`\n\nEnter **Auth Token**:", parse_mode=ParseMode.MARKDOWN)
            
        elif state == "worker_setup_token":
            state_data["token"] = text
            msg = await update.message.reply_text("🔄 Verifying...")
            
            success, info = await self._test_worker_connection(state_data)
            
            if success:
                store = _get_store()
                state_data["worker_id"] = info.get("worker_id", f"worker-{len(store.get_workers()) + 1}")
                store.add_worker(state_data)
                self.auth.clear_user_state(user.id)
                await msg.edit_text("✅ **Worker Connected & Saved!**")
            else:
                await msg.edit_text(f"❌ Failed: {info}\nType 'cancel' to exit or enter token again.")

    async def _test_worker_connection(self, worker_data: Dict[str, Any]) -> tuple:
        """Test connection to worker API with correct headers."""
        url = f"{worker_data['url'].rstrip('/')}/health"
        # Health usually doesn't need token, but capabilities does. Let's try capabilities to verify token.
        cap_url = f"{worker_data['url'].rstrip('/')}/capabilities"
        
        headers = {
            "x-auth-token": worker_data.get("token", ""),
            "Content-Type": "application/json"
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                # First check health (basic connectivity)
                async with session.get(url, timeout=5) as response:
                    if response.status != 200:
                        return False, f"Health Check Failed: {response.status}"
                
                # Then check capabilities (token verification)
                async with session.get(cap_url, headers=headers, timeout=5) as response:
                    if response.status == 200:
                        data = await response.json()
                        return True, data
                    elif response.status == 401:
                        return False, "Invalid Auth Token"
                    else:
                        return False, f"HTTP {response.status}"
        except Exception as e:
            return False, str(e)

    async def _handle_confirmation(self, update, context, text, state_data):
        pass

    # --- SHARED UI METHODS (Called by CallbackHandler too) ---

    async def show_new_task_prompt(self, update, context, is_callback=False):
        text = "📝 *New Task*\n\nDescribe what you want me to do."
        self.auth.set_user_state(update.effective_user.id, "waiting_task")
        await self._respond(update, text, KeyboardBuilder.back_button(), is_callback)

    async def show_status(self, update, context, is_callback=False):
        try:
            st = self.agent.get_status()
            sys_ = st.get("system", {})
            mem = sys_.get("memory", {})
            response = f"📊 *System Status*\n\n🤖 *Agent:* `{st['agent']['state']}`\n💻 *RAM:* `{mem.get('available_gb', 0):.1f}GB free`"
            await self._respond(update, response, KeyboardBuilder.back_button(), is_callback)
        except Exception as e:
            await self._respond(update, f"❌ Error: {str(e)}", KeyboardBuilder.back_button(), is_callback)

    async def show_workers(self, update, context, is_callback=False):
        store = _get_store()
        workers = store.get_workers()
        text = "👷 *Workers*\n\n" + ("\n".join([f"• `{w['name']}` ({w['url']})" for w in workers]) if workers else "_No workers connected._")
        await self._respond(update, text, KeyboardBuilder.back_button(), is_callback)

    async def show_history(self, update, context, is_callback=False):
        tasks = context.user_data.get("tasks", {})
        text = "📜 *Recent Tasks*\n\n" + ("\n".join([f"• {t.get('goal', '')[:30]}..." for t in list(tasks.values())[-5:]]) if tasks else "_No tasks yet._")
        await self._respond(update, text, KeyboardBuilder.back_button(), is_callback)

    async def show_help(self, update, context, is_callback=False):
        text = "❓ *Help*\n\nType a task description or use the menu."
        await self._respond(update, text, KeyboardBuilder.main_menu(), is_callback)

    async def show_main_menu(self, update, is_callback=False):
        text = "🤖 *Main AI Agent*\n\nWhat would you like to do?"
        await self._respond(update, text, KeyboardBuilder.main_menu(), is_callback)
    
    async def show_settings(self, update, context, is_callback=False):
        text = "⚙️ *Settings*\n\nConfigure your preferences:"
        await self._respond(update, text, KeyboardBuilder.settings_menu(), is_callback)
            
    async def show_task_details(self, update, context, task_id):
        tasks = context.user_data.get("tasks", {})
        task = tasks.get(task_id)
        if not task:
            await update.callback_query.edit_message_text("❌ Task not found.", reply_markup=KeyboardBuilder.back_button())
            return
        json_str = json.dumps(task, indent=2, ensure_ascii=False)[:3000]
        await update.callback_query.edit_message_text(f"📋 *Task Details*\n\n```json\n{json_str}\n```", parse_mode=ParseMode.MARKDOWN, reply_markup=KeyboardBuilder.back_button())

    async def cancel_task(self, update, context, task_id):
        tasks = context.user_data.get("tasks", {})
        if task_id in tasks: del tasks[task_id]
        await update.callback_query.edit_message_text("✅ Task cancelled.", reply_markup=KeyboardBuilder.main_menu())

    async def _respond(self, update, text, markup, is_callback):
        if is_callback:
            await update.callback_query.edit_message_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=markup)
        else:
            await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=markup)


class CallbackHandler:
    """
    Handles inline keyboard callbacks.
    """
    
    def __init__(self, agent, auth_middleware, message_handler, logger=None):
        self.agent = agent
        self.auth = auth_middleware
        self.mh = message_handler
        self._logger = logger or get_logger("CallbackHandler")
    
    async def handle_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        await query.answer()
        data = query.data
        
        # Menu Navigation
        if data == "menu_main": await self.mh.show_main_menu(update, is_callback=True)
        elif data == "menu_new_task": await self.mh.show_new_task_prompt(update, context, is_callback=True)
        elif data == "menu_status": await self.mh.show_status(update, context, is_callback=True)
        elif data == "menu_workers" or data == "workers_refresh": await self.mh.show_workers(update, context, is_callback=True)
        elif data == "menu_history": await self.mh.show_history(update, context, is_callback=True)
        elif data == "menu_settings": await self.mh.show_settings(update, context, is_callback=True)
        elif data == "menu_help": await self.mh.show_help(update, context, is_callback=True)
        
        # Setup trigger
        elif data == "worker_add":
            self.auth.set_user_state(query.from_user.id, "worker_setup_name")
            await query.edit_message_text("👷 *Add New Worker*\n\nEnter Worker Name:", parse_mode=ParseMode.MARKDOWN, reply_markup=KeyboardBuilder.back_button())
            
        # Task Actions
        elif data.startswith("task_details_"): await self.mh.show_task_details(update, context, data.replace("task_details_", ""))
        elif data.startswith("task_cancel_"): await self.mh.cancel_task(update, context, data.replace("task_cancel_", ""))
        elif data.startswith("worker_assign_"):
            parts = data.split("_")
            await self._assign_worker(query, context, parts[2], parts[3])
        elif data.startswith("worker_auto_"):
            await self._auto_assign_worker(query, context, data.replace("worker_auto_", ""))
        elif data.startswith("task_run_"):
            await self._execute_task(query, context, data.replace("task_run_", ""))
    
    async def _assign_worker(self, query, context, worker_id, task_id):
        tasks = context.user_data.get("tasks", {})
        task = tasks.get(task_id)
        
        store = _get_store()
        workers = store.get_workers()
        worker = next((w for w in workers if w.get("worker_id") == worker_id), None)
        
        if not worker:
            await query.edit_message_text("❌ Worker not found.", reply_markup=KeyboardBuilder.back_button())
            return
            
        task["assigned_worker"] = worker
        await query.edit_message_text(
            f"🎯 *Worker Selected: {worker['name']}*\n\nReady to execute task:\n_{task['goal']}_",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=KeyboardBuilder.confirm_execution(task_id, worker['name'])
        )
    
    async def _auto_assign_worker(self, query, context, task_id):
        store = _get_store()
        workers = store.get_workers()
        if not workers:
            await query.edit_message_text("❌ No workers available.", reply_markup=KeyboardBuilder.back_button())
            return
        await self._assign_worker(query, context, workers[0].get("worker_id"), task_id)

    async def _execute_task(self, query, context, task_id):
        tasks = context.user_data.get("tasks", {})
        task = tasks.get(task_id)
        worker = task.get("assigned_worker")
        
        if not worker:
            await query.edit_message_text("❌ No worker assigned.", reply_markup=KeyboardBuilder.back_button())
            return
            
        await query.edit_message_text("🚀 *Sending Task to Worker...*", parse_mode=ParseMode.MARKDOWN)
        
        url = f"{worker['url'].rstrip('/')}/execute"
        token = worker.get("token", "")
        
        # Build payload based on task
        payload = {
            "task_id": task_id,
            "goal": task["goal"],
            "requirements": task["requirements"],
            "steps": [s["name"] if isinstance(s, dict) else str(s) for s in task["steps"]],
            "on_error": task["on_error"]
        }
        
        # Header Fix for Worker Auth
        headers = {
            "x-auth-token": token,
            "Content-Type": "application/json"
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=payload, headers=headers, timeout=300) as response:
                    if response.status == 200:
                        result = await response.json()
                        
                        # Formatting Results
                        results_text = ""
                        res_data = result.get("results", {})
                        for step, output in res_data.items():
                            val = output.get("stdout", output.get("message", str(output))) if isinstance(output, dict) else str(output)
                            results_text += f"\n🔹 *{step}:*\n`{val.strip()[:200]}`"
                            
                        await query.edit_message_text(
                            f"✅ *Execution Successful*\n{results_text}",
                            parse_mode=ParseMode.MARKDOWN,
                            reply_markup=KeyboardBuilder.back_button()
                        )
                        task["status"] = "COMPLETED"
                    else:
                        err = await response.text()
                        await query.edit_message_text(f"❌ *Failed:* {err[:200]}", parse_mode=ParseMode.MARKDOWN, reply_markup=KeyboardBuilder.back_button())
        except Exception as e:
            await query.edit_message_text(f"❌ *Connection Error:* {str(e)}", parse_mode=ParseMode.MARKDOWN, reply_markup=KeyboardBuilder.back_button())