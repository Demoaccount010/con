"""
Telegram Bot Middleware
=======================
Authentication, rate limiting, and request processing.
"""

import time
import asyncio
from typing import Dict, Set, Optional, List, Callable, Any
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from functools import wraps

from telegram import Update
from telegram.ext import ContextTypes

from main_agent.utils.logger import Logger, get_logger


@dataclass
class UserSession:
    """User session data."""
    user_id: int
    username: Optional[str]
    first_seen: datetime
    last_active: datetime
    message_count: int = 0
    is_admin: bool = False
    is_blocked: bool = False
    current_state: Optional[str] = None
    state_data: Dict[str, Any] = field(default_factory=dict)


class AuthMiddleware:
    """
    Authentication Middleware
    =========================
    
    Controls who can use the bot.
    
    Modes:
    - OPEN: Anyone can use
    - WHITELIST: Only whitelisted users
    - ADMIN_ONLY: Only admins
    """
    
    def __init__(
        self,
        admin_ids: Optional[List[int]] = None,
        whitelist_ids: Optional[List[int]] = None,
        mode: str = "WHITELIST",
        logger: Optional[Logger] = None,
    ):
        """
        Initialize auth middleware.
        
        Args:
            admin_ids: List of admin user IDs
            whitelist_ids: List of allowed user IDs
            mode: "OPEN", "WHITELIST", or "ADMIN_ONLY"
            logger: Optional logger
        """
        self.admin_ids: Set[int] = set(admin_ids or [])
        self.whitelist_ids: Set[int] = set(whitelist_ids or [])
        self.mode = mode.upper()
        self._logger = logger or get_logger("AuthMiddleware")
        
        # Add admins to whitelist automatically
        self.whitelist_ids.update(self.admin_ids)
        
        # User sessions
        self._sessions: Dict[int, UserSession] = {}
        
        self._logger.info(
            f"AuthMiddleware initialized (mode={self.mode}, "
            f"admins={len(self.admin_ids)}, whitelist={len(self.whitelist_ids)})"
        )
    
    def is_authorized(self, user_id: int) -> bool:
        """Check if user is authorized."""
        if self.mode == "OPEN":
            return True
        elif self.mode == "ADMIN_ONLY":
            return user_id in self.admin_ids
        else:  # WHITELIST
            return user_id in self.whitelist_ids
    
    def is_admin(self, user_id: int) -> bool:
        """Check if user is admin."""
        return user_id in self.admin_ids
    
    def add_to_whitelist(self, user_id: int) -> None:
        """Add user to whitelist."""
        self.whitelist_ids.add(user_id)
        self._logger.info(f"User {user_id} added to whitelist")
    
    def remove_from_whitelist(self, user_id: int) -> None:
        """Remove user from whitelist."""
        self.whitelist_ids.discard(user_id)
        if user_id in self._sessions:
            self._sessions[user_id].is_blocked = True
        self._logger.info(f"User {user_id} removed from whitelist")
    
    def add_admin(self, user_id: int) -> None:
        """Add user as admin."""
        self.admin_ids.add(user_id)
        self.whitelist_ids.add(user_id)
        if user_id in self._sessions:
            self._sessions[user_id].is_admin = True
        self._logger.info(f"User {user_id} added as admin")
    
    def get_session(self, user_id: int, username: Optional[str] = None) -> UserSession:
        """Get or create user session."""
        if user_id not in self._sessions:
            self._sessions[user_id] = UserSession(
                user_id=user_id,
                username=username,
                first_seen=datetime.now(),
                last_active=datetime.now(),
                is_admin=user_id in self.admin_ids,
            )
        else:
            self._sessions[user_id].last_active = datetime.now()
            self._sessions[user_id].message_count += 1
            if username:
                self._sessions[user_id].username = username
        
        return self._sessions[user_id]
    
    def set_user_state(
        self,
        user_id: int,
        state: Optional[str],
        data: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Set user conversation state."""
        # Ensure session exists first
        if user_id not in self._sessions:
            self.get_session(user_id)
            
        self._sessions[user_id].current_state = state
        self._sessions[user_id].state_data = data or {}
        
        self._logger.debug(f"User {user_id} state set to: {state}")
    
    def get_user_state(self, user_id: int) -> tuple:
        """Get user conversation state."""
        if user_id in self._sessions:
            session = self._sessions[user_id]
            return session.current_state, session.state_data
        return None, {}
    
    def clear_user_state(self, user_id: int) -> None:
        """Clear user conversation state."""
        if user_id in self._sessions:
            self._sessions[user_id].current_state = None
            self._sessions[user_id].state_data = {}
            self._logger.debug(f"User {user_id} state cleared")
    
    def get_all_sessions(self) -> Dict[int, UserSession]:
        """Get all user sessions."""
        return self._sessions.copy()
    
    def get_active_users(self, minutes: int = 30) -> List[UserSession]:
        """Get recently active users."""
        cutoff = datetime.now() - timedelta(minutes=minutes)
        return [
            s for s in self._sessions.values()
            if s.last_active > cutoff
        ]


class RateLimiter:
    """
    Rate Limiter
    ============
    
    Prevents spam and abuse.
    
    Features:
    - Per-user rate limiting
    - Sliding window algorithm
    - Automatic cooldown
    """
    
    def __init__(
        self,
        max_requests: int = 30,
        window_seconds: int = 60,
        cooldown_seconds: int = 60,
        logger: Optional[Logger] = None,
    ):
        """
        Initialize rate limiter.
        
        Args:
            max_requests: Max requests per window
            window_seconds: Time window in seconds
            cooldown_seconds: Cooldown after limit exceeded
            logger: Optional logger
        """
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self.cooldown_seconds = cooldown_seconds
        self._logger = logger or get_logger("RateLimiter")
        
        # User request timestamps
        self._requests: Dict[int, List[float]] = {}
        
        # Users in cooldown
        self._cooldowns: Dict[int, float] = {}
    
    def is_allowed(self, user_id: int) -> tuple:
        """
        Check if user is allowed to make request.
        
        Returns:
            Tuple of (allowed: bool, wait_seconds: int)
        """
        now = time.time()
        
        # Check cooldown
        if user_id in self._cooldowns:
            cooldown_end = self._cooldowns[user_id]
            if now < cooldown_end:
                wait = int(cooldown_end - now)
                return False, wait
            else:
                del self._cooldowns[user_id]
        
        # Initialize user requests
        if user_id not in self._requests:
            self._requests[user_id] = []
        
        # Clean old requests
        window_start = now - self.window_seconds
        self._requests[user_id] = [
            t for t in self._requests[user_id]
            if t > window_start
        ]
        
        # Check limit
        if len(self._requests[user_id]) >= self.max_requests:
            # Set cooldown
            self._cooldowns[user_id] = now + self.cooldown_seconds
            self._logger.warning(f"User {user_id} rate limited")
            return False, self.cooldown_seconds
        
        # Record request
        self._requests[user_id].append(now)
        return True, 0
    
    def get_remaining(self, user_id: int) -> int:
        """Get remaining requests for user."""
        if user_id not in self._requests:
            return self.max_requests
        
        now = time.time()
        window_start = now - self.window_seconds
        recent = [t for t in self._requests[user_id] if t > window_start]
        
        return max(0, self.max_requests - len(recent))
    
    def reset_user(self, user_id: int) -> None:
        """Reset rate limit for user."""
        self._requests.pop(user_id, None)
        self._cooldowns.pop(user_id, None)
    
    def reset_all(self) -> None:
        """Reset all rate limits."""
        self._requests.clear()
        self._cooldowns.clear()


def require_auth(func: Callable) -> Callable:
    """Decorator to require authentication."""
    @wraps(func)
    async def wrapper(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user = update.effective_user
        if not user:
            return
        
        if not self.auth.is_authorized(user.id):
            await update.message.reply_text(
                "⛔ Access Denied\n\n"
                "You are not authorized to use this bot.\n"
                "Contact the administrator for access."
            )
            return
        
        return await func(self, update, context)
    return wrapper


def require_admin(func: Callable) -> Callable:
    """Decorator to require admin privileges."""
    @wraps(func)
    async def wrapper(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user = update.effective_user
        if not user:
            return
        
        if not self.auth.is_admin(user.id):
            await update.message.reply_text(
                "⛔ Admin Access Required\n\n"
                "This command requires administrator privileges."
            )
            return
        
        return await func(self, update, context)
    return wrapper


def rate_limit(func: Callable) -> Callable:
    """Decorator to apply rate limiting."""
    @wraps(func)
    async def wrapper(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user = update.effective_user
        if not user:
            return
        
        # Admins bypass rate limit
        if self.auth.is_admin(user.id):
            return await func(self, update, context)
        
        allowed, wait_seconds = self.rate_limiter.is_allowed(user.id)
        
        if not allowed:
            await update.message.reply_text(
                f"⏳ Rate Limit Exceeded\n\n"
                f"Please wait {wait_seconds} seconds before sending more messages."
            )
            return
        
        return await func(self, update, context)
    return wrapper