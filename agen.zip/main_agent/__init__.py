"""
Main AI Agent Package
=====================
A modular AI System Controller framework.

This is NOT a chatbot - this is an AI SYSTEM CONTROLLER.

Version: 1.0.0
Part: 1A - Core Foundation
"""

__version__ = "1.0.0"
__author__ = "AI Systems Architect"
__part__ = "1A"

from main_agent.core.agent import MainAgent
from main_agent.config import Config

__all__ = ["MainAgent", "Config", "__version__"]
