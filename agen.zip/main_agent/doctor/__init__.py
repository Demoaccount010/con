"""
Doctor Agent Module
===================
Health monitoring and auto-healing for the AI system.

Components:
- Monitor: Watches system health, agent status, resource usage
- Healer: Attempts automatic fixes for common problems

The Doctor module is responsible for:
1. Continuous health monitoring of all components
2. Detecting failure patterns and anomalies
3. Attempting automatic fixes when possible
4. Escalating to user when auto-fix fails
"""

from main_agent.doctor.monitor import (
    HealthMonitor,
    HealthStatus,
    HealthReport,
    ComponentHealth,
    ComponentType,
    FailureTracker,
)
from main_agent.doctor.healer import (
    Healer,
    HealAction,
    HealActionType,
    HealResult,
    HealingThrottle,
)

__all__ = [
    # Monitor exports
    "HealthMonitor",
    "HealthStatus",
    "HealthReport",
    "ComponentHealth",
    "ComponentType",
    "FailureTracker",
    # Healer exports
    "Healer",
    "HealAction",
    "HealActionType",
    "HealResult",
    "HealingThrottle",
]