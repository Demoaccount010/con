"""
Planning Engine (Fast & Smart)
==============================
Optimized for speed and conversational intelligence.

Converts user text input into structured task plans OR conversation responses.

The planner is the "thinking" component that:
1. Analyzes user input
2. Determines intent (CHAT vs TASK)
3. Creates structured execution plans for tasks
4. Generates direct responses for conversation
5. Does NOT execute - only plans

Output Format (STRICT):
{
    "goal": "Human readable goal",
    "requirements": {
        "gui": false,
        "browser": null,
        "docker": false
    },
    "steps": [
        "check_environment",
        "prepare_context",
        "execute_action",
        "verify_result"
    ],
    "on_error": "report"
}

Design Principles:
- Extensible: Easy to add new task types
- Fail-safe: Graceful degradation without LLM
- Transparent: Every step has a reason
- Independent: Does not assume worker availability
"""

import json
import re
from typing import Dict, Any, Optional, List, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
from abc import ABC, abstractmethod

# Import from PART-1A
from main_agent.core.errors import (
    AgentError,
    ErrorCategory,
    ErrorSeverity,
    ErrorResponse,
    format_error_response,
)
from main_agent.utils.logger import Logger, get_logger
from main_agent.knowledge.search import WebSearch # New Knowledge Import


class TaskType(Enum):
    """
    Classification of task types.
    
    Each type has different planning strategies.
    """
    QUESTION = "QUESTION"           # Information retrieval
    FILE_OPERATION = "FILE_OP"      # Create/read/modify files
    CODE_GENERATION = "CODE_GEN"    # Write code
    SYSTEM_COMMAND = "SYSTEM_CMD"   # Execute system operations
    WEB_TASK = "WEB_TASK"           # Browser/web operations
    DATA_ANALYSIS = "DATA_ANALYSIS" # Analyze data
    CONVERSATION = "CONVERSATION"   # General chat
    UNKNOWN = "UNKNOWN"


class PlanStatus(Enum):
    """Status of a planned task."""
    PENDING = "PENDING"         # Just created
    READY = "READY"             # Ready for execution
    VALIDATED = "VALIDATED"     # Validated and confirmed
    REJECTED = "REJECTED"       # Cannot be executed
    FAILED = "FAILED"           # Planning failed


@dataclass
class TaskRequirements:
    """
    Requirements for task execution.
    
    Specifies what resources/permissions the task needs.
    Workers will check these before accepting tasks.
    """
    gui: bool = False                    # Needs graphical interface
    browser: Optional[str] = None        # Needs browser (None, "any", "chrome", etc.)
    docker: bool = False                 # Needs Docker
    network: bool = False                # Needs network access
    file_system: bool = False            # Needs file system access
    sudo: bool = False                   # Needs elevated privileges
    gpu: bool = False                    # Needs GPU
    min_memory_gb: float = 0.0           # Minimum RAM needed
    custom: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        result = {
            "gui": self.gui,
            "browser": self.browser,
            "docker": self.docker,
            "network": self.network,
            "file_system": self.file_system,
            "sudo": self.sudo,
            "gpu": self.gpu,
        }
        if self.min_memory_gb > 0:
            result["min_memory_gb"] = self.min_memory_gb
        if self.custom:
            result.update(self.custom)
        return result


@dataclass
class PlanStep:
    """
    A single step in the execution plan.
    
    Each step is atomic and has a clear purpose.
    """
    name: str                           # Step identifier (e.g., "check_environment")
    description: str                    # Human-readable description
    reason: str                         # WHY this step is needed
    order: int                          # Execution order
    required: bool = True               # Must succeed to continue
    timeout_sec: int = 60               # Max execution time
    retry_count: int = 0                # Number of retries on failure
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "reason": self.reason,
            "order": self.order,
            "required": self.required,
            "timeout_sec": self.timeout_sec,
        }
    
    def __str__(self) -> str:
        return self.name


@dataclass
class PlannedTask:
    """
    Complete structured task plan.
    
    This is the PRIMARY OUTPUT of the planner.
    Workers receive this to execute tasks.
    """
    goal: str                                           # Human-readable goal
    original_input: str                                 # Raw user input
    task_type: TaskType                                 # Classified task type
    requirements: TaskRequirements                      # Execution requirements
    steps: List[PlanStep]                               # Ordered execution steps
    on_error: str = "report"                            # Error strategy: report/retry/abort
    status: PlanStatus = PlanStatus.PENDING
    confidence: float = 0.0                             # Planning confidence (0-1)
    
    # Conversational Fields (New)
    is_conversational: bool = False                     # True if it's just chat
    response_text: Optional[str] = None                 # Direct response for chat
    
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    plan_id: str = field(default_factory=lambda: datetime.now().strftime("%Y%m%d%H%M%S%f"))
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert to the STRICT output format.
        
        This is what workers receive.
        """
        return {
            "goal": self.goal,
            "requirements": self.requirements.to_dict(),
            "steps": [step.name for step in self.steps],  # Simplified step list
            "on_error": self.on_error,
        }
    
    def to_full_dict(self) -> Dict[str, Any]:
        """Full representation with all metadata."""
        return {
            "plan_id": self.plan_id,
            "goal": self.goal,
            "original_input": self.original_input,
            "task_type": self.task_type.value,
            "is_conversational": self.is_conversational,
            "response": self.response_text,
            "requirements": self.requirements.to_dict(),
            "steps": [s.to_dict() for s in self.steps],
            "on_error": self.on_error,
            "status": self.status.value,
            "confidence": round(self.confidence, 2),
            "created_at": self.created_at,
            "metadata": self.metadata,
        }
    
    def to_json(self, indent: int = 2, full: bool = False) -> str:
        """Convert to JSON string."""
        data = self.to_full_dict() if full else self.to_dict()
        return json.dumps(data, indent=indent, ensure_ascii=False)
    
    def get_step_names(self) -> List[str]:
        """Get ordered list of step names."""
        return [step.name for step in sorted(self.steps, key=lambda s: s.order)]
    
    def __str__(self) -> str:
        if self.is_conversational:
            return f"CHAT: {self.response_text}"
            
        lines = [
            "=" * 60,
            "PLANNED TASK",
            "=" * 60,
            f"Plan ID: {self.plan_id}",
            f"Goal: {self.goal}",
            f"Type: {self.task_type.value}",
            f"Status: {self.status.value}",
            f"Confidence: {self.confidence:.0%}",
            "",
            "Requirements:",
        ]
        
        reqs = self.requirements.to_dict()
        for key, value in reqs.items():
            if value:  # Only show non-empty requirements
                lines.append(f"  • {key}: {value}")
        
        lines.extend(["", "Steps:"])
        for step in sorted(self.steps, key=lambda s: s.order):
            lines.append(f"  {step.order}. {step.name}")
            lines.append(f"     → {step.description}")
            lines.append(f"     Why: {step.reason}")
        
        lines.extend([
            "",
            f"On Error: {self.on_error}",
            "=" * 60,
        ])
        
        return "\n".join(lines)


class PlannerError(AgentError):
    """Raised when planning fails."""
    default_category = ErrorCategory.RUNTIME
    default_severity = ErrorSeverity.MEDIUM
    default_suggestion = "Try rephrasing your request or provide more details"


class TaskAnalyzer:
    """
    Analyzes user input to determine task type and extract key information.
    
    Uses pattern matching and keyword analysis.
    This is the first stage of planning.
    """
    
    # Keyword patterns for task type detection
    # Each pattern: (keywords, task_type, confidence_boost)
    TASK_PATTERNS = [
        # Questions
        (["what is", "what are", "how do", "how to", "why", "explain", "tell me", "?"], 
         TaskType.QUESTION, 0.8),
        
        # File operations
        (["create file", "write file", "read file", "delete file", "move file", 
          "copy file", "rename", "save to", "open file"],
         TaskType.FILE_OPERATION, 0.9),
        
        # Code generation
        (["write code", "create script", "python script", "generate code", 
          "function that", "class that", "implement", "code for"],
         TaskType.CODE_GENERATION, 0.9),
        
        # System commands
        (["run command", "execute", "install", "uninstall", "restart", "stop service",
          "start service", "kill process", "sudo", "apt", "pip install"],
         TaskType.SYSTEM_COMMAND, 0.9),
        
        # Web tasks
        (["open browser", "go to website", "download from", "scrape", "browse",
          "search online", "fetch url", "http", "https"],
         TaskType.WEB_TASK, 0.9),
        
        # Data analysis
        (["analyze", "statistics", "chart", "graph", "plot", "csv", "json data",
          "parse", "extract data", "summarize data"],
         TaskType.DATA_ANALYSIS, 0.85),
         
        # Conversation
        (["hi", "hello", "hey", "namaste", "hola", "thanks", "bye", "good", "morning", "night", "kaisa", "kaise", "haal", "name", "naam"],
         TaskType.CONVERSATION, 0.95),
    ]
    
    # Requirement indicators
    REQUIREMENT_PATTERNS = {
        "gui": ["window", "gui", "display", "show window", "graphical", "ui"],
        "browser": ["browser", "chrome", "firefox", "website", "url", "http"],
        "docker": ["docker", "container", "kubernetes", "k8s"],
        "network": ["download", "upload", "fetch", "api", "http", "url", "internet"],
        "file_system": ["file", "folder", "directory", "path", "save", "read", "write"],
        "sudo": ["sudo", "admin", "root", "permission", "install"],
    }
    
    def __init__(self, logger: Optional[Logger] = None):
        self._logger = logger or get_logger("TaskAnalyzer")
    
    def analyze(self, text: str) -> Tuple[TaskType, float, TaskRequirements]:
        """
        Analyze user input and determine task type and requirements.
        
        Args:
            text: User input text
            
        Returns:
            Tuple of (TaskType, confidence, TaskRequirements)
        """
        text_lower = text.lower()
        
        # Detect task type
        task_type, confidence = self._detect_task_type(text_lower)
        
        # Detect requirements
        requirements = self._detect_requirements(text_lower)
        
        self._logger.debug(
            f"Analysis result: type={task_type.value}, "
            f"confidence={confidence:.2f}"
        )
        
        return task_type, confidence, requirements
    
    def _detect_task_type(self, text: str) -> Tuple[TaskType, float]:
        """Detect the task type from text."""
        best_match = (TaskType.UNKNOWN, 0.3)
        
        for keywords, task_type, base_confidence in self.TASK_PATTERNS:
            matches = sum(1 for kw in keywords if kw in text)
            if matches > 0:
                # More matches = higher confidence
                confidence = min(base_confidence + (matches * 0.05), 1.0)
                if confidence > best_match[1]:
                    best_match = (task_type, confidence)
        
        # If very short input, likely conversation
        if len(text.split()) < 3 and best_match[0] == TaskType.UNKNOWN:
            return TaskType.CONVERSATION, 0.6
        
        # Default to conversation if nothing matches well
        if best_match[1] < 0.5:
            return TaskType.CONVERSATION, 0.5
        
        return best_match
    
    def _detect_requirements(self, text: str) -> TaskRequirements:
        """Detect execution requirements from text."""
        reqs = TaskRequirements()
        
        for req_name, keywords in self.REQUIREMENT_PATTERNS.items():
            if any(kw in text for kw in keywords):
                if req_name == "gui":
                    reqs.gui = True
                elif req_name == "browser":
                    reqs.browser = "any"
                elif req_name == "docker":
                    reqs.docker = True
                elif req_name == "network":
                    reqs.network = True
                elif req_name == "file_system":
                    reqs.file_system = True
                elif req_name == "sudo":
                    reqs.sudo = True
        
        return reqs


class StepGenerator:
    """
    Generates execution steps based on task type.
    
    Each task type has predefined step templates.
    Steps are ordered and have clear purposes.
    """
    
    # Step templates for each task type
    # Each step: (name, description, reason, required)
    STEP_TEMPLATES = {
        TaskType.QUESTION: [
            ("understand_query", "Parse and understand the question",
             "Need to extract the core question before answering", True),
            ("gather_context", "Gather relevant context",
             "Context improves answer accuracy", True),
            ("formulate_answer", "Generate the answer",
             "This is the main response generation", True),
            ("verify_answer", "Verify answer accuracy",
             "Ensures response is correct and helpful", False),
        ],
        
        TaskType.FILE_OPERATION: [
            ("check_environment", "Verify file system access",
             "Must confirm we can access the target location", True),
            ("validate_path", "Validate file path and permissions",
             "Prevents errors from invalid paths", True),
            ("prepare_context", "Prepare file content or operation details",
             "Sets up what needs to be done", True),
            ("execute_action", "Perform the file operation",
             "This is the actual file manipulation", True),
            ("verify_result", "Confirm operation success",
             "Ensures the operation completed correctly", True),
        ],
        
        TaskType.CODE_GENERATION: [
            ("check_environment", "Check development environment",
             "Verify required tools are available", True),
            ("analyze_requirements", "Analyze code requirements",
             "Understand what the code needs to do", True),
            ("design_structure", "Design code structure",
             "Plan the code architecture before writing", True),
            ("generate_code", "Generate the code",
             "Write the actual code implementation", True),
            ("validate_syntax", "Validate syntax and logic",
             "Check for errors before delivery", True),
            ("format_output", "Format and document code",
             "Make code readable and well-documented", False),
        ],
        
        TaskType.SYSTEM_COMMAND: [
            ("check_environment", "Check system environment",
             "Verify OS and available tools", True),
            ("validate_permissions", "Validate required permissions",
             "Ensure we have rights to execute", True),
            ("prepare_command", "Prepare command and arguments",
             "Build the exact command to run", True),
            ("risk_assessment", "Assess command risk level",
             "Evaluate potential system impact", True),
            ("execute_action", "Execute the command",
             "Run the system command", True),
            ("verify_result", "Verify execution result",
             "Confirm command completed successfully", True),
        ],
        
        TaskType.WEB_TASK: [
            ("check_environment", "Check network and browser availability",
             "Ensure we can access the web", True),
            ("validate_url", "Validate URL and accessibility",
             "Confirm target is reachable", True),
            ("prepare_context", "Prepare request context",
             "Set up headers, cookies, etc.", True),
            ("execute_action", "Perform web operation",
             "Execute the actual web task", True),
            ("process_response", "Process web response",
             "Handle and parse the response", True),
            ("verify_result", "Verify task completion",
             "Confirm expected outcome", True),
        ],
        
        TaskType.DATA_ANALYSIS: [
            ("check_environment", "Check analysis tools availability",
             "Verify required libraries exist", True),
            ("load_data", "Load and validate data",
             "Read data into memory", True),
            ("prepare_context", "Clean and prepare data",
             "Handle missing values, format issues", True),
            ("execute_action", "Perform analysis",
             "Run the actual analysis computations", True),
            ("generate_output", "Generate analysis output",
             "Create visualizations or reports", True),
            ("verify_result", "Validate results",
             "Check analysis accuracy", False),
        ],
        
        TaskType.CONVERSATION: [
            ("understand_context", "Understand conversation context",
             "Parse what user is saying", True),
            ("formulate_response", "Generate response",
             "Create appropriate reply", True),
        ],
        
        TaskType.UNKNOWN: [
            ("analyze_input", "Analyze user input",
             "Try to understand the request", True),
            ("request_clarification", "Request clarification if needed",
             "Get more details from user", False),
            ("prepare_response", "Prepare best-effort response",
             "Generate helpful response despite uncertainty", True),
        ],
    }
    
    def __init__(self, logger: Optional[Logger] = None):
        self._logger = logger or get_logger("StepGenerator")
    
    def generate_steps(
        self,
        task_type: TaskType,
        requirements: TaskRequirements,
        custom_steps: Optional[List[str]] = None,
    ) -> List[PlanStep]:
        """
        Generate execution steps for a task.
        
        Args:
            task_type: The classified task type
            requirements: Task requirements
            custom_steps: Optional custom step names to include
            
        Returns:
            Ordered list of PlanStep objects
        """
        # Get template for this task type
        template = self.STEP_TEMPLATES.get(
            task_type,
            self.STEP_TEMPLATES[TaskType.UNKNOWN]
        )
        
        steps = []
        for order, (name, description, reason, required) in enumerate(template, 1):
            steps.append(PlanStep(
                name=name,
                description=description,
                reason=reason,
                order=order,
                required=required,
                timeout_sec=60,
                retry_count=0
            ))
        
        # Add requirement-specific steps
        extra_steps = self._get_requirement_steps(requirements, len(steps))
        steps.extend(extra_steps)
        
        # Add custom steps if provided
        if custom_steps:
            for i, step_name in enumerate(custom_steps):
                if not any(s.name == step_name for s in steps):
                    steps.append(PlanStep(
                        name=step_name,
                        description=f"Execute {step_name}",
                        reason="Explicitly requested",
                        order=len(steps) + 1,
                        required=True,
                        timeout_sec=60,
                        retry_count=0
                    ))
        
        self._logger.debug(f"Generated {len(steps)} steps for {task_type.value}")
        return steps
    
    def _get_requirement_steps(
        self,
        requirements: TaskRequirements,
        start_order: int,
    ) -> List[PlanStep]:
        """Add steps based on requirements."""
        extra = []
        order = start_order
        
        if requirements.sudo:
            order += 1
            extra.append(PlanStep(
                name="elevate_privileges",
                description="Request elevated privileges",
                reason="Task requires sudo/admin access",
                order=order,
                required=True,
                timeout_sec=60,
                retry_count=0
            ))
        
        if requirements.docker:
            order += 1
            extra.append(PlanStep(
                name="check_docker",
                description="Verify Docker is available",
                reason="Task requires Docker containers",
                order=order,
                required=True,
                timeout_sec=60,
                retry_count=0
            ))
        
        return extra


class Planner:
    """
    Main Planning Engine
    ====================
    
    Converts raw user input into structured task plans.
    
    Architecture:
    1. TaskAnalyzer - Determines what type of task this is
    2. StepGenerator - Creates execution steps
    3. Plan Assembly - Builds final PlannedTask
    
    The planner uses Ollama for enhanced understanding when available,
    but falls back to pattern matching when LLM is unavailable.
    
    CRITICAL: This is PLANNING ONLY - NO EXECUTION happens here.
    """
    
    # LLM prompt for enhanced planning (used when Ollama available)
    # UPDATED PROMPT TO HANDLE CONVERSATION AND TASKS CORRECTLY
    PLANNING_PROMPT = '''You are the AI Brain of an Autonomous System Controller.
    
WHO YOU ARE:
- You are a powerful AI that controls VPS servers.
- You have memory, internet access, and execution power.
- You can learn, adapt, and execute complex tasks.

SYSTEM CONTEXT:
- You have access to remote VPS workers via API.
- You DO NOT need SSH credentials.
- You DO NOT need user guidance.
- You MUST generate a plan.

AVAILABLE ACTIONS (Only use these for steps):
- check_environment (Check CPU/RAM/Disk)
- execute_command (Run shell command)
- list_files (List directory)
- read_file (Read file content)
- write_file (Create/Edit file)
- http_request (Make API call)

CONTEXT FROM MEMORY:
{context}

USER REQUEST: "{input}"

YOUR GOAL:
1. If the user asks a question you don't know -> Use "SEARCH" tool.
2. If the user wants to chat -> Reply smartly & creatively.
3. If the user gives a command -> Create a TASK.

RESPONSE FORMAT (JSON ONLY):
{{
    "type": "CHAT" or "TASK" or "SEARCH",
    "category": "CONVERSATION" or "SYSTEM_CMD" or "KNOWLEDGE",
    "goal": "Summary of intent",
    "response": "Your smart reply here (for CHAT)",
    "search_query": "Query to search online (for SEARCH)",
    "requirements": {{ "network": false, "sudo": false }},
    "steps": ["step1_name", "step2_name"] (Required for TASK, use generic names)
}}
'''

    def __init__(self, logger: Optional[Logger] = None, conversation_manager: Any = None, learning_engine: Any = None):
        """Initialize the planner."""
        self._logger = logger or get_logger("Planner")
        self._ollama_client = None
        self._initialized = False
        
        # Memory Components
        self._memory = conversation_manager
        self._learning = learning_engine
        
        # Sub-components
        self._analyzer = TaskAnalyzer(logger=self._logger)
        self._step_generator = StepGenerator(logger=self._logger)
        
        # Knowledge
        self.search_engine = WebSearch()
        
        # Fast Patterns for Instant Reply
        self._chat_patterns = {
            r"\b(hi|hello|hey|hola)\b": "Hello buddy! Kaise ho?",
            r"\b(kaisa|kaise|haal)\b": "Main badhiya hoon! Aap sunao?",
            r"\b(name|naam)\b": "Mera naam Smile hai, aapka AI best friend!",
            r"\b(thank|sukriya)\b": "Arre, dosti mein no sorry, no thank you!",
            r"\b(bye|goodbye)\b": "Bye buddy! Phir milenge.",
        }
        
        # Statistics
        self._plans_created = 0
        self._llm_plans = 0
        self._fallback_plans = 0
    
    def initialize(self, ollama_client: Optional[Any] = None) -> bool:
        """
        Initialize the planner with dependencies.
        
        Args:
            ollama_client: OllamaClient instance for LLM-enhanced planning
            
        Returns:
            True if initialization successful
        """
        self._ollama_client = ollama_client
        self._initialized = True
        
        if ollama_client:
            self._logger.info("Planner initialized with Ollama LLM support")
        else:
            self._logger.warning(
                "Planner initialized WITHOUT Ollama - using pattern matching only"
            )
        
        return True
    
    def plan(self, user_input: str, user_id: Optional[int] = None) -> PlannedTask:
        """
        Convert user input to structured task plan.
        
        This is the MAIN ENTRY POINT for planning.
        """
        if not user_input or not user_input.strip():
            return self._create_empty_plan()
        
        user_input_clean = user_input.strip()
        self._logger.info(f"Planning task for: {user_input_clean[:50]}...")
        
        # 1. FORCE TASK DETECTION (Regex Override)
        task_keywords = ["vps", "check", "run", "install", "delete", "create", "ram", "cpu", "disk", "ping", "download"]
        is_forced_task = any(k in user_input_clean.lower() for k in task_keywords)
        
        # 2. FAST CHECK: Regex Patterns (Instant Reply)
        if not is_forced_task and len(user_input_clean.split()) < 10:
            for pattern, reply in self._chat_patterns.items():
                if re.search(pattern, user_input_clean, re.IGNORECASE):
                    return PlannedTask(
                        goal="Instant Chat",
                        original_input=user_input,
                        task_type=TaskType.CONVERSATION,
                        requirements=TaskRequirements(),
                        steps=[],
                        confidence=1.0,
                        is_conversational=True,
                        response_text=reply
                    )
        
        # 3. Context from Memory
        context_str = "No prior context."
        if self._memory and user_id:
            try:
                history = self._memory.get_history(user_id, limit=5)
                user_profile = self._memory.get_user_profile(user_id)
                
                parts = []
                if user_profile:
                    parts.append(f"User Info: {user_profile}")
                if history:
                    chat_log = "\n".join([f"{m['role']}: {m['content']}" for m in history])
                    parts.append(f"Chat History:\n{chat_log}")
                
                context_str = "\n\n".join(parts)
                
                # Save User Input
                self._memory.add_message(user_id, "user", user_input)
            except Exception as e:
                self._logger.warning(f"Memory access failed: {e}")

        # 4. LLM Planning
        if self._ollama_client:
            llm_input = f"Context:\n{context_str}\n\nRequest: {user_input}"
            task = self._plan_with_llm(llm_input, context_str, force_task=is_forced_task)
            
            # Restore original input
            if task:
                task.original_input = user_input
                self._llm_plans += 1
                self._plans_created += 1
                
                # Save response to memory
                if task.is_conversational and self._memory and user_id:
                    try:
                        self._memory.add_message(user_id, "assistant", task.response_text)
                    except:
                        pass
                return task
            
        # Fallback to pattern-based planning
        task = self._plan_with_patterns(user_input)
        self._fallback_plans += 1
        self._plans_created += 1
        return task
    
    def _plan_with_llm(self, user_input: str, context: str, force_task: bool = False) -> Optional[PlannedTask]:
        """
        Create plan using Ollama LLM for better understanding.
        """
        self._logger.debug("Attempting LLM-enhanced planning...")
        
        try:
            prompt = self.PLANNING_PROMPT.format(input=user_input, context=context)
            response = self._ollama_client.generate(
                prompt=prompt,
                temperature=0.2,  # Low temp for consistent JSON
            )
            
            if not response.is_success:
                self._logger.warning(f"LLM request failed: {response.error_message}")
                return None
            
            # Parse JSON from response
            data = self._parse_llm_response(response.content)
            
            if not data:
                # If JSON fails but we forced task, create a default task
                if force_task:
                    return PlannedTask(
                        goal="Execute Command",
                        original_input=user_input,
                        task_type=TaskType.SYSTEM_COMMAND,
                        requirements=TaskRequirements(),
                        steps=[PlanStep(name="execute_command", description="Execute Command", reason="Forced Task", order=1, required=True, timeout_sec=60, retry_count=0)],
                        confidence=1.0,
                        is_conversational=False
                    )
                # Fallback to chat if not forced
                return PlannedTask(
                    goal="Chat",
                    original_input=user_input,
                    task_type=TaskType.CONVERSATION,
                    requirements=TaskRequirements(),
                    steps=[],
                    confidence=0.5,
                    is_conversational=True,
                    response_text=response.content.strip()
                )
            
            # Handle SEARCH (Knowledge Access)
            if data.get("type") == "SEARCH":
                query = data.get("search_query", user_input)
                search_result = self.search_engine.search(query)
                
                # Save to memory
                if self._memory:
                    self._memory.add_message(0, "system", f"Internet Info: {search_result}")
                    
                return PlannedTask(
                    goal="Internet Search",
                    original_input=user_input,
                    task_type=TaskType.CONVERSATION,
                    is_conversational=True,
                    response_text=f"🔍 I searched the web for you:\n\n{search_result}"
                )

            # Override LLM if we know it's a task
            if force_task:
                data["type"] = "TASK"
                data["category"] = "SYSTEM_CMD"
            
            # Handle CHAT
            if data.get("type") == "CHAT" or data.get("category") == "CONVERSATION":
                return PlannedTask(
                    goal="Conversation",
                    original_input=user_input,
                    task_type=TaskType.CONVERSATION,
                    requirements=TaskRequirements(),
                    steps=[],
                    confidence=float(data.get("confidence", 0.9)),
                    is_conversational=True,
                    response_text=data.get("response", "I'm listening.")
                )
            
            # Handle TASK
            task_type = self._parse_task_type(data.get("category") or data.get("task_type", "UNKNOWN"))
            
            requirements = TaskRequirements(
                gui=data.get("requirements", {}).get("gui", False),
                browser=data.get("requirements", {}).get("browser"),
                docker=data.get("requirements", {}).get("docker", False),
                network=data.get("requirements", {}).get("network", False),
                file_system=data.get("requirements", {}).get("file_system", False),
                sudo=data.get("requirements", {}).get("sudo", False),
            )
            
            # Generate steps
            suggested = data.get("steps", [])
            steps = []
            
            if suggested and isinstance(suggested, list):
                for i, s in enumerate(suggested):
                    steps.append(PlanStep(
                        name=s,
                        description=f"Execute {s}",
                        reason="AI Generated",
                        order=i+1,
                        required=True,
                        timeout_sec=60,
                        retry_count=0
                    ))
            else:
                steps = self._step_generator.generate_steps(
                    task_type=task_type,
                    requirements=requirements
                )
            
            return PlannedTask(
                goal=data.get("goal", user_input[:100]),
                original_input=user_input,
                task_type=task_type,
                requirements=requirements,
                steps=steps,
                on_error=data.get("on_error", "report"),
                status=PlanStatus.READY,
                confidence=float(data.get("confidence", 0.8)),
                is_conversational=False,
                metadata={
                    "planning_method": "llm",
                    "model": self._ollama_client.model,
                },
            )
            
        except Exception as e:
            self._logger.warning(f"LLM planning error: {e}")
            return None
    
    def _plan_with_patterns(self, user_input: str) -> PlannedTask:
        """
        Create plan using pattern matching (fallback method).
        """
        self._logger.debug("Using pattern-based planning...")
        
        # Analyze input
        task_type, confidence, requirements = self._analyzer.analyze(user_input)
        
        # Check if conversation
        if task_type == TaskType.CONVERSATION:
            return PlannedTask(
                goal="Chat",
                original_input=user_input,
                task_type=TaskType.CONVERSATION,
                requirements=TaskRequirements(),
                steps=[],
                confidence=confidence,
                is_conversational=True,
                response_text="Hello! I am your AI Agent. How can I help you?"
            )
        
        # Generate steps
        steps = self._step_generator.generate_steps(
            task_type=task_type,
            requirements=requirements,
        )
        
        # Create goal
        goal = self._extract_goal(user_input)
        
        return PlannedTask(
            goal=goal,
            original_input=user_input,
            task_type=task_type,
            requirements=requirements,
            steps=steps,
            on_error="report",
            status=PlanStatus.READY,
            confidence=confidence * 0.8,
            is_conversational=False,
            metadata={
                "planning_method": "pattern_matching",
            },
        )
    
    def _parse_llm_response(self, content: str) -> Optional[Dict[str, Any]]:
        """Parse JSON from LLM response."""
        content = content.strip()
        
        # Remove markdown blocks
        clean_content = re.sub(r'^```json\s*', '', content)
        clean_content = re.sub(r'^```', '', clean_content)
        clean_content = re.sub(r'```$', '', clean_content)
        clean_content = clean_content.strip()
        
        # Try direct parse
        try:
            return json.loads(clean_content)
        except json.JSONDecodeError:
            pass
        
        # Try finding JSON block
        try:
            start = content.find('{')
            end = content.rfind('}')
            if start != -1 and end != -1:
                json_str = content[start:end+1]
                return json.loads(json_str)
        except json.JSONDecodeError:
            pass
            
        return None
    
    def _parse_task_type(self, type_str: str) -> TaskType:
        """Parse task type string to enum."""
        type_map = {
            "QUESTION": TaskType.QUESTION,
            "FILE_OP": TaskType.FILE_OPERATION,
            "FILE_OPERATION": TaskType.FILE_OPERATION,
            "CODE_GEN": TaskType.CODE_GENERATION,
            "CODE_GENERATION": TaskType.CODE_GENERATION,
            "SYSTEM_CMD": TaskType.SYSTEM_COMMAND,
            "SYSTEM_COMMAND": TaskType.SYSTEM_COMMAND,
            "WEB_TASK": TaskType.WEB_TASK,
            "DATA_ANALYSIS": TaskType.DATA_ANALYSIS,
            "CONVERSATION": TaskType.CONVERSATION,
        }
        return type_map.get(type_str.upper(), TaskType.UNKNOWN)
    
    def _extract_goal(self, text: str) -> str:
        sentences = re.split(r'[.!?]', text)
        if sentences:
            goal = sentences[0].strip()
            if len(goal) > 100:
                goal = goal[:97] + "..."
            return goal
        return text[:100]
    
    def _create_empty_plan(self) -> PlannedTask:
        return PlannedTask(
            goal="Empty Input",
            original_input="",
            task_type=TaskType.UNKNOWN,
            requirements=TaskRequirements(),
            steps=[],
            status=PlanStatus.FAILED
        )
    
    @property
    def is_ready(self) -> bool:
        return self._initialized
    
    @property
    def has_llm(self) -> bool:
        return self._ollama_client is not None
    
    @property
    def status(self) -> Dict[str, Any]:
        return {
            "initialized": self._initialized,
            "llm_available": self._ollama_client is not None,
            "llm_model": self._ollama_client.model if self._ollama_client else None,
            "ready": self.is_ready,
            "memory_connected": self._memory is not None,
            "statistics": {
                "plans_created": self._plans_created,
                "llm_plans": self._llm_plans,
                "fallback_plans": self._fallback_plans,
            },
        }
    
    def __repr__(self) -> str:
        return (
            f"Planner(initialized={self._initialized}, "
            f"llm={'yes' if self._ollama_client else 'no'})"
        )