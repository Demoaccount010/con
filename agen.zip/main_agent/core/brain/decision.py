"""
Brain-2: Decision Engine
========================
Routes the validated request to the correct subsystem.
"""

from typing import Dict, Any
from main_agent.core.brain.router import IntentType, IntentResult
from main_agent.utils.logger import get_logger

class DecisionEngine:
    """
    Strategist that decides the execution path.
    """
    
    def __init__(self, agent):
        self.agent = agent # Access to Main Agent components
        self.logger = get_logger("Brain-Decision")

    def decide(self, analysis: IntentResult, user_id: int) -> Dict[str, Any]:
        """
        Route the request based on intent.
        """
        self.logger.info(f"Deciding strategy for: {analysis.intent.value}")

        # STRATEGY 1: CONVERSATION
        if analysis.intent == IntentType.CHAT:
            return {
                "type": "CHAT",
                "response": self._generate_chat_response(analysis.original_input)
            }

        # STRATEGY 2: KNOWLEDGE / INFO
        if analysis.intent == IntentType.QUESTION:
            return {
                "type": "CHAT", # Treat answers as chat for now
                "response": self._generate_knowledge_response(analysis.original_input)
            }

        # STRATEGY 3: SYSTEM CHECK
        if analysis.intent == IntentType.SYSTEM:
            return {
                "type": "SYSTEM",
                "action": "internal_check",
                "query": analysis.original_input
            }

        # STRATEGY 4: TASK EXECUTION
        if analysis.intent == IntentType.TASK:
            return {
                "type": "TASK",
                "description": analysis.original_input
            }
            
        return {"type": "ERROR", "message": "Decision Logic Failed"}

    def _generate_chat_response(self, text: str) -> str:
        """Casual conversation."""
        prompt = f"You are Smile, an AI Assistant. User says: '{text}'. Reply naturally and briefly."
        resp = self.agent.ollama_client.generate(prompt, temperature=0.7)
        return resp.content.strip()

    def _generate_knowledge_response(self, text: str) -> str:
        """Information retrieval (Internal + Internet)."""
        # Note: Will hook into Internet search here later
        prompt = f"Answer this question concisely: '{text}'"
        resp = self.agent.ollama_client.generate(prompt, temperature=0.3)
        return resp.content.strip()