"""
Cognitive Engine (The Master Controller)
========================================
Integrates all brain layers into a single thinking process.
"""

from typing import Dict, Any, Optional
from main_agent.core.brain.router import CognitiveRouter, IntentType
from main_agent.core.brain.validator import MeaningValidator
from main_agent.core.brain.decision import DecisionEngine
from main_agent.core.brain.tools import ToolManager
from main_agent.utils.logger import get_logger

class CognitiveEngine:
    """
    The Brain of the AI Agent.
    """
    
    def __init__(self, agent):
        self.agent = agent
        self.logger = get_logger("CognitiveEngine")
        
        # Initialize Layers
        self.router = None
        self.validator = None
        self.decision_engine = None
        self.tool_manager = None
        
    def initialize(self):
        """Initialize all cognitive sub-systems."""
        client = self.agent.ollama_client
        self.router = CognitiveRouter(client)
        self.validator = MeaningValidator(client)
        self.decision_engine = DecisionEngine(self.agent)
        self.tool_manager = ToolManager(self.agent)
        self.logger.info("Cognitive Engine Online")

    def think(self, user_input: str, user_id: int) -> Dict[str, Any]:
        """
        The Main Thinking Loop.
        Input -> Router -> Validator -> Decision -> Action -> Response
        """
        if not user_input.strip():
            return {"type": "CHAT", "message": "..."}

        # 1. ROUTER: Determine Intent
        intent_analysis = self.router.classify(user_input)
        self.logger.info(f"Intent: {intent_analysis.intent.value} ({intent_analysis.confidence:.2f})")

        # 2. VALIDATOR: Check Ambiguity
        is_valid, clarification = self.validator.validate(intent_analysis)
        if not is_valid:
            return {"type": "CHAT", "message": clarification}

        # 3. DECISION & TOOLS: Handle Knowledge/System Intents
        if intent_analysis.intent == IntentType.QUESTION:
            # Check if we need external tools (Internet)
            tool_result = self.tool_manager.select_and_execute(user_input)
            
            if tool_result["used"]:
                # Synthesize answer from tool result
                return self._synthesize_answer(user_input, tool_result["result"])
            
            # Else, internal knowledge answer (handled by DecisionEngine)
            
        elif intent_analysis.intent == IntentType.SYSTEM:
             # Run system check
             return self.decision_engine.decide(intent_analysis, user_id)

        # 4. DECIDE: Final Strategy (Chat or Task)
        decision = self.decision_engine.decide(intent_analysis, user_id)
        
        return decision

    def _synthesize_answer(self, question: str, data: str) -> Dict[str, str]:
        """Convert raw tool data into a natural answer."""
        prompt = f"""
You are an AI assistant.
User asked: "{question}"
Information retrieved: "{data}"

Summarize this information into a helpful, natural response.
"""
        response = self.agent.ollama_client.generate(prompt, temperature=0.5)
        return {"type": "CHAT", "message": response.content.strip()}