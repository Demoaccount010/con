"""
Brain-0: Cognitive Router (Intent Detection)
============================================
The Gatekeeper. Determines the fundamental nature of the input.

It distinguishes between:
1. CHAT: "Hi", "How are you", "Nice weather"
2. QUESTION: "What is RAM?", "Who made you?" (Informational)
3. TASK: "Delete files", "Install Nginx" (Actionable)
4. SYSTEM: "Check internet", "Disk space" (Diagnostic)
5. UNKNOWN: Gibberish or ambiguous
"""

import json
import re
from enum import Enum
from dataclasses import dataclass
from typing import Optional, Dict, Any, List

from main_agent.utils.logger import get_logger

class IntentType(Enum):
    CHAT = "CHAT"           # Casual conversation
    QUESTION = "QUESTION"   # Knowledge retrieval
    TASK = "TASK"           # Action execution
    SYSTEM = "SYSTEM"       # Capability/Health check
    UNKNOWN = "UNKNOWN"     # Needs clarification

@dataclass
class IntentResult:
    intent: IntentType
    confidence: float
    reason: str
    original_input: str
    
    def is_actionable(self) -> bool:
        return self.intent in (IntentType.TASK, IntentType.SYSTEM)

class CognitiveRouter:
    """
    The Brain's Input Processor.
    Uses LLM to classify intent strictly.
    """
    
    # Strict System Prompt for Intent Classification
    ROUTER_PROMPT = '''You are the Cognitive Router of an AI System Controller.
    
YOUR SOLE PURPOSE is to classify the user's input into exactly one category.
DO NOT answer the user. DO NOT execute. Just classify.

CATEGORIES:
1. CHAT: Casual greetings, small talk, emotions, feedback.
   Examples: "Hi", "Good morning", "You are smart", "I am tired"
   
2. QUESTION: Asking for general knowledge, definitions, or explanations.
   Examples: "What is Docker?", "Who created Python?", "Explain HTTP"
   
3. TASK: Explicit instruction to change state, create, delete, or run something.
   Examples: "Install Nginx", "Create file test.txt", "Deploy worker", "Run script"
   
4. SYSTEM: Diagnostic checks, status queries, capability tests.
   Examples: "Check RAM", "Is internet working?", "Show active workers", "Status report"

5. UNKNOWN: If the input is too short, gibberish, or completely ambiguous.
   Examples: "Run", "Yes", "No", "File"

INPUT: "{input}"

CONTEXT: {context}

RESPONSE FORMAT (JSON ONLY):
{{
    "intent": "CHAT | QUESTION | TASK | SYSTEM | UNKNOWN",
    "confidence": 0.0 to 1.0,
    "reason": "Brief explanation of why"
}}
'''

    def __init__(self, ollama_client):
        self.client = ollama_client
        self.logger = get_logger("Brain-Router")
        
        # Fast Regex Patterns for common inputs (Optimization)
        self._fast_patterns = {
            r"^(hi|hello|hey|hola)\b": IntentType.CHAT,
            r"^(thanks|thank you)\b": IntentType.CHAT,
            r"^(bye|goodbye)\b": IntentType.CHAT,
            r"\b(check|status|health)\b": IntentType.SYSTEM,
            r"\b(ram|cpu|disk|uptime)\b": IntentType.SYSTEM,
            r"\b(install|remove|delete|create|run)\b": IntentType.TASK,
            r"\b(what is|who is|explain)\b": IntentType.QUESTION,
        }

    def classify(self, user_input: str, context: str = "") -> IntentResult:
        """
        Classify user input into an Intent.
        """
        self.logger.debug(f"Routing input: {user_input[:50]}...")
        
        # 1. Fast Path: Regex Check (Low Latency)
        # Only for very short inputs to save LLM calls
        if len(user_input.split()) < 5:
            for pattern, intent in self._fast_patterns.items():
                if re.search(pattern, user_input, re.IGNORECASE):
                    self.logger.debug(f"Fast-path matched: {intent.value}")
                    return IntentResult(
                        intent=intent,
                        confidence=0.9,
                        reason="Matched keyword pattern",
                        original_input=user_input
                    )

        # 2. Slow Path: LLM Analysis (High Intelligence)
        return self._classify_with_llm(user_input, context)

    def _classify_with_llm(self, user_input: str, context: str) -> IntentResult:
        """Use LLM to determine intent."""
        try:
            prompt = self.ROUTER_PROMPT.format(input=user_input, context=context)
            
            # Low temperature for deterministic classification
            response = self.client.generate(prompt, temperature=0.0)
            
            if not response.is_success:
                return IntentResult(IntentType.UNKNOWN, 0.0, "LLM Error", user_input)
            
            data = self._parse_json(response.content)
            
            if not data:
                return IntentResult(IntentType.CHAT, 0.5, "Fallback (JSON Parse Fail)", user_input)
            
            intent_str = data.get("intent", "UNKNOWN").upper()
            try:
                intent = IntentType(intent_str)
            except ValueError:
                intent = IntentType.UNKNOWN
                
            return IntentResult(
                intent=intent,
                confidence=float(data.get("confidence", 0.5)),
                reason=data.get("reason", "LLM decision"),
                original_input=user_input
            )
            
        except Exception as e:
            self.logger.error(f"Router Exception: {e}")
            return IntentResult(IntentType.UNKNOWN, 0.0, str(e), user_input)

    def _parse_json(self, content: str) -> Optional[Dict[str, Any]]:
        """ robust JSON extractor """
        try:
            clean = content.strip()
            # Remove markdown code blocks if present
            clean = re.sub(r'^```json', '', clean, flags=re.MULTILINE)
            clean = re.sub(r'^```', '', clean, flags=re.MULTILINE)
            
            # Find JSON object
            start = clean.find('{')
            end = clean.rfind('}')
            if start != -1 and end != -1:
                return json.loads(clean[start:end+1])
            return None
        except:
            return None