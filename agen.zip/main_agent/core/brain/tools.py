"""
Brain-4: Tool & Capability Manager
==================================
Manages access to Internet, System, and Worker capabilities.
Decides IF and HOW to use a tool.
"""

import json
import re
from typing import Dict, Any, Optional, List
from main_agent.knowledge.search import WebSearch
from main_agent.utils.logger import get_logger

class ToolManager:
    """
    Manages external tools (Search, System, Workers).
    """
    
    TOOL_PROMPT = '''You are the Tool Selector.
User Question: "{input}"

Available Tools:
1. INTERNET_SEARCH: For current events, docs, or specific facts you don't know.
2. SYSTEM_CHECK: For checking RAM, CPU, Disk on THIS server.
3. WORKER_LIST: To see available remote workers.
4. NONE: If you can answer from internal knowledge.

DECISION (JSON ONLY):
{{
    "tool": "INTERNET_SEARCH" | "SYSTEM_CHECK" | "WORKER_LIST" | "NONE",
    "query": "search query or command" (if tool is used)
}}
'''

    def __init__(self, agent):
        self.agent = agent
        self.search_engine = WebSearch()
        self.logger = get_logger("Brain-Tools")

    def select_and_execute(self, user_input: str) -> Dict[str, Any]:
        """
        Decide if a tool is needed, and execute it.
        """
        self.logger.debug(f"Evaluating tools for: {user_input[:30]}...")
        
        # 1. Ask LLM which tool to use
        tool_decision = self._decide_tool(user_input)
        
        if tool_decision["tool"] == "NONE":
            return {"used": False, "result": None}
            
        # 2. Execute the selected tool
        tool_name = tool_decision["tool"]
        query = tool_decision.get("query", user_input)
        
        self.logger.info(f"Tool Selected: {tool_name}")
        
        result = None
        if tool_name == "INTERNET_SEARCH":
            result = self._use_internet(query)
            
        elif tool_name == "SYSTEM_CHECK":
            result = self._check_system()
            
        elif tool_name == "WORKER_LIST":
            result = self._get_workers()
            
        return {
            "used": True,
            "tool": tool_name,
            "result": result
        }

    def _decide_tool(self, text: str) -> Dict[str, str]:
        """Ask LLM if a tool is required."""
        try:
            prompt = self.TOOL_PROMPT.format(input=text)
            response = self.agent.ollama_client.generate(prompt, temperature=0.0)
            
            # Parse JSON
            match = re.search(r'\{.*\}', response.content, re.DOTALL)
            if match:
                return json.loads(match.group(0))
            return {"tool": "NONE"}
        except:
            return {"tool": "NONE"}

    def _use_internet(self, query: str) -> str:
        """Perform a web search."""
        self.logger.info(f"Searching web for: {query}")
        return self.search_engine.search(query)

    def _check_system(self) -> str:
        """Check local system stats."""
        status = self.agent.get_status()
        sys = status.get("system", {})
        mem = sys.get("memory", {})
        return (
            f"OS: {sys.get('os', {}).get('type')}\n"
            f"CPU: {sys.get('cpu', {}).get('cores')} cores\n"
            f"RAM: {mem.get('available_gb')}GB free"
        )

    def _get_workers(self) -> str:
        """Get list of connected workers."""
        # This assumes registry is available on agent
        # We'll need to hook this up in integration
        return "Worker list capability is ready."