"""
Brain-1: Meaning & Validation Layer
===================================
Checks for ambiguity and safety.
Ensures we don't execute dangerous or unclear commands.
"""

from typing import Dict, Optional, Tuple
from main_agent.core.brain.router import IntentType, IntentResult
from main_agent.utils.logger import get_logger

class MeaningValidator:
    """
    Validates intent and checks for ambiguity.
    """
    
    CLARIFY_PROMPT = '''You are the Clarification Engine.
The user's request is ambiguous or potentially risky.
Generate a polite, smart question to clarify their intent.

User Input: "{input}"
Detected Intent: {intent}

Your Question:
'''

    def __init__(self, ollama_client):
        self.client = ollama_client
        self.logger = get_logger("Brain-Validator")

    def validate(self, analysis: IntentResult) -> Tuple[bool, Optional[str]]:
        """
        Validate the intent.
        
        Returns:
            Tuple(is_valid: bool, clarification_message: str)
        """
        # 1. Check Confidence
        if analysis.confidence < 0.6:
            self.logger.warning(f"Low confidence ({analysis.confidence}). Asking clarification.")
            return False, self._generate_clarification(analysis.original_input, analysis.intent)

        # 2. Check for UNKNOWN
        if analysis.intent == IntentType.UNKNOWN:
            return False, "I'm not sure I understand. Could you rephrase that? Are you asking a question or giving a task?"

        # 3. Safety Check for Tasks
        if analysis.intent == IntentType.TASK:
            if self._is_risky(analysis.original_input):
                return False, "This looks like a risky operation (System Modification). Are you sure you want to proceed?"

        return True, None

    def _is_risky(self, text: str) -> bool:
        """Simple keyword check for high-risk commands."""
        risky_keywords = ["delete", "remove", "rm -rf", "format", "shutdown", "reboot", "kill"]
        return any(k in text.lower() for k in risky_keywords)

    def _generate_clarification(self, text: str, intent: IntentType) -> str:
        """Ask LLM to generate a specific clarification question."""
        try:
            prompt = self.CLARIFY_PROMPT.format(input=text, intent=intent.value)
            response = self.client.generate(prompt, temperature=0.7)
            return response.content.strip()
        except:
            return "Could you provide more details?"