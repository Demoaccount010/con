"""
Configuration Storage
=====================
Persistent storage for bot configuration.

Stores:
- Telegram bot token
- Admin user IDs
- Whitelist user IDs
- Bot settings
- Worker configurations

Storage location: ~/.main_agent/config.json
"""

import os
import json
import base64
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path

from main_agent.utils.logger import Logger, get_logger


# Default storage directory
DEFAULT_CONFIG_DIR = os.path.expanduser("~/.main_agent")
DEFAULT_CONFIG_FILE = "config.json"


@dataclass
class BotSettings:
    """
    Bot configuration settings.
    
    All settings that need to persist between runs.
    """
    # Telegram settings
    bot_token: str = ""
    bot_username: str = ""
    admin_ids: List[int] = field(default_factory=list)
    whitelist_ids: List[int] = field(default_factory=list)
    auth_mode: str = "WHITELIST"  # OPEN, WHITELIST, ADMIN_ONLY
    
    # Rate limiting
    rate_limit_messages: int = 30
    rate_limit_window: int = 60
    
    # Agent settings
    agent_name: str = "MainAgent"
    log_level: str = "INFO"
    
    # Ollama settings
    ollama_host: str = "127.0.0.1"
    ollama_port: int = 11434
    ollama_model: str = ""  # Auto-detected if empty
    
    # Worker settings
    worker_api_port: int = 8001
    worker_auth_token: str = ""
    registered_workers: List[Dict[str, Any]] = field(default_factory=list)
    
    # Metadata
    created_at: str = ""
    updated_at: str = ""
    version: str = "1.0.0"
    setup_complete: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BotSettings":
        """Create from dictionary."""
        # Filter only known fields
        known_fields = {f.name for f in cls.__dataclass_fields__.values()}
        filtered_data = {k: v for k, v in data.items() if k in known_fields}
        return cls(**filtered_data)
    
    def is_valid(self) -> tuple:
        """
        Check if settings are valid for bot startup.
        
        Returns:
            Tuple of (is_valid: bool, error_message: str)
        """
        if not self.bot_token:
            return False, "Bot token is required"
        
        if not self.admin_ids:
            return False, "At least one admin ID is required"
        
        if self.auth_mode not in ("OPEN", "WHITELIST", "ADMIN_ONLY"):
            return False, f"Invalid auth mode: {self.auth_mode}"
        
        return True, ""


class ConfigStore:
    """
    Configuration Storage Manager
    =============================
    
    Handles reading and writing configuration to disk.
    
    Features:
    - Automatic directory creation
    - JSON storage with pretty formatting
    - Token encoding (basic obfuscation)
    - Backup on update
    
    Usage:
        store = ConfigStore()
        
        # Save settings
        settings = BotSettings(bot_token="xxx", admin_ids=[123])
        store.save(settings)
        
        # Load settings
        settings = store.load()
        
        # Check if exists
        if store.exists():
            settings = store.load()
    """
    
    def __init__(
        self,
        config_dir: Optional[str] = None,
        config_file: str = DEFAULT_CONFIG_FILE,
        logger: Optional[Logger] = None,
    ):
        """
        Initialize config store.
        
        Args:
            config_dir: Directory for config file
            config_file: Config file name
            logger: Optional logger
        """
        self.config_dir = Path(config_dir or DEFAULT_CONFIG_DIR)
        self.config_file = config_file
        self.config_path = self.config_dir / self.config_file
        self._logger = logger or get_logger("ConfigStore")
        
        # Ensure directory exists
        self._ensure_dir()
    
    def _ensure_dir(self) -> None:
        """Ensure config directory exists."""
        if not self.config_dir.exists():
            self.config_dir.mkdir(parents=True, exist_ok=True)
            self._logger.debug(f"Created config directory: {self.config_dir}")
    
    def exists(self) -> bool:
        """Check if config file exists."""
        return self.config_path.exists()
    
    def load(self) -> Optional[BotSettings]:
        """
        Load settings from file.
        
        Returns:
            BotSettings or None if not found
        """
        if not self.exists():
            self._logger.debug("Config file not found")
            return None
        
        try:
            with open(self.config_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            
            # Decode token if encoded
            if data.get("bot_token_encoded"):
                data["bot_token"] = self._decode_token(data.pop("bot_token_encoded"))
            
            if data.get("worker_auth_token_encoded"):
                data["worker_auth_token"] = self._decode_token(
                    data.pop("worker_auth_token_encoded")
                )
            
            settings = BotSettings.from_dict(data)
            self._logger.info("Configuration loaded successfully")
            return settings
            
        except json.JSONDecodeError as e:
            self._logger.error(f"Config file corrupted: {e}")
            return None
        except Exception as e:
            self._logger.error(f"Error loading config: {e}")
            return None
    
    def save(self, settings: BotSettings) -> bool:
        """
        Save settings to file.
        
        Args:
            settings: BotSettings to save
            
        Returns:
            True if saved successfully
        """
        try:
            # Update timestamps
            now = datetime.now().isoformat()
            if not settings.created_at:
                settings.created_at = now
            settings.updated_at = now
            
            # Convert to dict
            data = settings.to_dict()
            
            # Encode sensitive tokens
            if data.get("bot_token"):
                data["bot_token_encoded"] = self._encode_token(data.pop("bot_token"))
            
            if data.get("worker_auth_token"):
                data["worker_auth_token_encoded"] = self._encode_token(
                    data.pop("worker_auth_token")
                )
            
            # Backup existing config
            if self.exists():
                self._backup()
            
            # Write config
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            
            # Set file permissions (Unix only)
            try:
                os.chmod(self.config_path, 0o600)
            except:
                pass
            
            self._logger.info(f"Configuration saved to {self.config_path}")
            return True
            
        except Exception as e:
            self._logger.error(f"Error saving config: {e}")
            return False
    
    def delete(self) -> bool:
        """Delete config file."""
        try:
            if self.exists():
                os.remove(self.config_path)
                self._logger.info("Configuration deleted")
            return True
        except Exception as e:
            self._logger.error(f"Error deleting config: {e}")
            return False
    
    def _backup(self) -> None:
        """Create backup of existing config."""
        try:
            backup_path = self.config_path.with_suffix(".json.bak")
            if self.config_path.exists():
                import shutil
                shutil.copy(self.config_path, backup_path)
                self._logger.debug(f"Config backed up to {backup_path}")
        except Exception as e:
            self._logger.warning(f"Backup failed: {e}")
    
    def _encode_token(self, token: str) -> str:
        """Encode token (basic obfuscation, not encryption)."""
        if not token:
            return ""
        return base64.b64encode(token.encode()).decode()
    
    def _decode_token(self, encoded: str) -> str:
        """Decode token."""
        if not encoded:
            return ""
        try:
            return base64.b64decode(encoded.encode()).decode()
        except:
            return encoded
    
    def update(self, **kwargs) -> bool:
        """
        Update specific settings.
        
        Args:
            **kwargs: Settings to update
            
        Returns:
            True if updated successfully
        """
        settings = self.load()
        if not settings:
            settings = BotSettings()
        
        for key, value in kwargs.items():
            if hasattr(settings, key):
                setattr(settings, key, value)
        
        return self.save(settings)
    
    def get_path(self) -> str:
        """Get config file path."""
        return str(self.config_path)
    
    # NEW: Worker Management Methods
    def add_worker(self, worker_data: Dict[str, Any]) -> bool:
        """Add or update a worker."""
        settings = self.load()
        if not settings:
            return False
        
        # Remove existing with same name or ID to avoid duplicates
        settings.registered_workers = [
            w for w in settings.registered_workers 
            if w.get("name") != worker_data.get("name") and 
               w.get("worker_id") != worker_data.get("worker_id")
        ]
        
        # Add new worker
        settings.registered_workers.append(worker_data)
        return self.save(settings)
    
    def remove_worker(self, worker_id: str) -> bool:
        """Remove a worker by ID."""
        settings = self.load()
        if not settings:
            return False
        
        settings.registered_workers = [
            w for w in settings.registered_workers 
            if w.get("worker_id") != worker_id
        ]
        return self.save(settings)
    
    def get_workers(self) -> List[Dict[str, Any]]:
        """Get all registered workers."""
        settings = self.load()
        return settings.registered_workers if settings else []


# Convenience functions
_default_store: Optional[ConfigStore] = None


def _get_store() -> ConfigStore:
    """Get default config store."""
    global _default_store
    if _default_store is None:
        _default_store = ConfigStore()
    return _default_store


def config_exists() -> bool:
    """Check if config exists."""
    return _get_store().exists()


def load_config() -> Optional[BotSettings]:
    """Load config from default location."""
    return _get_store().load()


def save_config(settings: BotSettings) -> bool:
    """Save config to default location."""
    return _get_store().save(settings)


def delete_config() -> bool:
    """Delete config file."""
    return _get_store().delete()


def get_config_path() -> str:
    """Get config file path."""
    return _get_store().get_path()