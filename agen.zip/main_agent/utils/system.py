"""
System Information & Checks
===========================
Detect OS, RAM, CPU and validate system requirements.
"""

import os
import sys
import platform
from typing import Dict, Any, List, Tuple, Optional
from dataclasses import dataclass


@dataclass
class SystemInfo:
    """
    System Information Container
    ============================
    
    Holds all detected system information in a structured format.
    """
    os_type: str              # Linux, Darwin, Windows
    os_name: str              # Full OS name
    os_version: str           # OS version
    architecture: str         # x86_64, arm64, etc.
    python_version: str       # Python version string
    cpu_cores: int            # Number of CPU cores
    cpu_cores_logical: int    # Logical CPU cores
    total_ram_gb: float       # Total RAM in GB
    available_ram_gb: float   # Available RAM in GB
    ram_usage_percent: float  # RAM usage percentage
    hostname: str             # Machine hostname
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "os": {
                "type": self.os_type,
                "name": self.os_name,
                "version": self.os_version,
                "architecture": self.architecture,
            },
            "python": {
                "version": self.python_version,
            },
            "cpu": {
                "cores": self.cpu_cores,
                "cores_logical": self.cpu_cores_logical,
            },
            "memory": {
                "total_gb": round(self.total_ram_gb, 2),
                "available_gb": round(self.available_ram_gb, 2),
                "usage_percent": round(self.ram_usage_percent, 1),
            },
            "hostname": self.hostname,
        }
    
    def __str__(self) -> str:
        return (
            f"System: {self.os_name} ({self.os_type} {self.architecture})\n"
            f"Python: {self.python_version}\n"
            f"CPU: {self.cpu_cores} cores ({self.cpu_cores_logical} logical)\n"
            f"RAM: {self.available_ram_gb:.1f}GB available / "
            f"{self.total_ram_gb:.1f}GB total ({self.ram_usage_percent:.1f}% used)"
        )


def get_os_info() -> Dict[str, str]:
    """
    Get operating system information.
    
    Returns:
        Dictionary with OS type, name, version, and architecture
    """
    return {
        "type": platform.system(),              # Linux, Darwin, Windows
        "name": platform.platform(),            # Full platform string
        "version": platform.version(),          # OS version
        "architecture": platform.machine(),     # x86_64, arm64, etc.
        "hostname": platform.node(),            # Machine hostname
    }


def get_cpu_info() -> Dict[str, int]:
    """
    Get CPU information.
    
    Returns:
        Dictionary with CPU core counts
    """
    # Physical cores (may return None on some systems)
    try:
        physical_cores = os.cpu_count()
    except:
        physical_cores = 1
    
    # Try to get physical vs logical cores
    # This is a simplified version - psutil would give more accurate info
    logical_cores = physical_cores or 1
    
    return {
        "cores": physical_cores or 1,
        "cores_logical": logical_cores,
    }


def get_memory_info() -> Dict[str, float]:
    """
    Get memory (RAM) information.
    
    Uses different methods depending on OS.
    Falls back to conservative estimates if detection fails.
    
    Returns:
        Dictionary with total, available RAM in GB and usage percent
    """
    total_gb = 0.0
    available_gb = 0.0
    
    try:
        if platform.system() == "Linux":
            total_gb, available_gb = _get_memory_linux()
        elif platform.system() == "Darwin":  # macOS
            total_gb, available_gb = _get_memory_macos()
        elif platform.system() == "Windows":
            total_gb, available_gb = _get_memory_windows()
        else:
            # Fallback - assume minimal
            total_gb, available_gb = 4.0, 2.0
            
    except Exception:
        # Fallback on any error
        total_gb, available_gb = 4.0, 2.0
    
    # Calculate usage
    if total_gb > 0:
        usage_percent = ((total_gb - available_gb) / total_gb) * 100
    else:
        usage_percent = 0.0
    
    return {
        "total_gb": total_gb,
        "available_gb": available_gb,
        "usage_percent": usage_percent,
    }


def _get_memory_linux() -> Tuple[float, float]:
    """Get memory info on Linux via /proc/meminfo."""
    total = 0
    available = 0
    
    try:
        with open("/proc/meminfo", "r") as f:
            for line in f:
                if line.startswith("MemTotal:"):
                    # Value is in kB
                    total = int(line.split()[1]) / (1024 * 1024)
                elif line.startswith("MemAvailable:"):
                    available = int(line.split()[1]) / (1024 * 1024)
    except:
        pass
    
    return (total, available) if total > 0 else (4.0, 2.0)


def _get_memory_macos() -> Tuple[float, float]:
    """Get memory info on macOS via sysctl."""
    import subprocess
    
    try:
        # Get total memory
        result = subprocess.run(
            ["sysctl", "-n", "hw.memsize"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        total = int(result.stdout.strip()) / (1024 ** 3)
        
        # Get VM stats for available memory
        result = subprocess.run(
            ["vm_stat"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        
        # Parse vm_stat output
        page_size = 4096  # Default page size
        free_pages = 0
        inactive_pages = 0
        
        for line in result.stdout.split("\n"):
            if "page size" in line.lower():
                page_size = int("".join(filter(str.isdigit, line)))
            elif "Pages free:" in line:
                free_pages = int("".join(filter(str.isdigit, line)))
            elif "Pages inactive:" in line:
                inactive_pages = int("".join(filter(str.isdigit, line)))
        
        available = (free_pages + inactive_pages) * page_size / (1024 ** 3)
        
        return (total, available)
        
    except:
        return (4.0, 2.0)


def _get_memory_windows() -> Tuple[float, float]:
    """Get memory info on Windows via ctypes."""
    try:
        import ctypes
        
        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_ = [
                ("dwLength", ctypes.c_ulong),
                ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong),
                ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong),
                ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong),
                ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
            ]
        
        stat = MEMORYSTATUSEX()
        stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))
        
        total = stat.ullTotalPhys / (1024 ** 3)
        available = stat.ullAvailPhys / (1024 ** 3)
        
        return (total, available)
        
    except:
        return (4.0, 2.0)


def get_system_info() -> SystemInfo:
    """
    Collect all system information.
    
    Returns:
        SystemInfo dataclass with all detected information
    """
    os_info = get_os_info()
    cpu_info = get_cpu_info()
    mem_info = get_memory_info()
    
    return SystemInfo(
        os_type=os_info["type"],
        os_name=os_info["name"],
        os_version=os_info["version"],
        architecture=os_info["architecture"],
        python_version=platform.python_version(),
        cpu_cores=cpu_info["cores"],
        cpu_cores_logical=cpu_info["cores_logical"],
        total_ram_gb=mem_info["total_gb"],
        available_ram_gb=mem_info["available_gb"],
        ram_usage_percent=mem_info["usage_percent"],
        hostname=os_info["hostname"],
    )


def check_system_requirements(
    system_info: Optional[SystemInfo] = None,
    min_ram_gb: float = 4.0,
    min_cpu_cores: int = 2,
    supported_os: Tuple[str, ...] = ("Linux", "Darwin", "Windows"),
) -> Dict[str, Any]:
    """
    Check if system meets minimum requirements.
    
    Args:
        system_info: Pre-collected system info (will collect if None)
        min_ram_gb: Minimum RAM required in GB
        min_cpu_cores: Minimum CPU cores required
        supported_os: Tuple of supported OS types
        
    Returns:
        Dictionary with 'passed' bool and 'failures' list
    """
    if system_info is None:
        system_info = get_system_info()
    
    failures: List[str] = []
    warnings: List[str] = []
    
    # Check OS
    if system_info.os_type not in supported_os:
        failures.append(
            f"Unsupported OS: {system_info.os_type} "
            f"(supported: {', '.join(supported_os)})"
        )
    
    # Check RAM
    if system_info.available_ram_gb < min_ram_gb:
        failures.append(
            f"Insufficient available RAM: {system_info.available_ram_gb:.1f}GB "
            f"(minimum: {min_ram_gb}GB)"
        )
    elif system_info.available_ram_gb < min_ram_gb * 1.5:
        warnings.append(
            f"Low available RAM: {system_info.available_ram_gb:.1f}GB "
            f"(recommended: {min_ram_gb * 1.5:.1f}GB)"
        )
    
    # Check CPU
    if system_info.cpu_cores < min_cpu_cores:
        failures.append(
            f"Insufficient CPU cores: {system_info.cpu_cores} "
            f"(minimum: {min_cpu_cores})"
        )
    
    return {
        "passed": len(failures) == 0,
        "failures": failures,
        "warnings": warnings,
        "system_info": system_info.to_dict(),
    }