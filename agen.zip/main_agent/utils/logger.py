"""
Logging System
==============
Centralized logging with console and file output.
"""

import os
import sys
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Optional, Any, Dict
from datetime import datetime


class ColorFormatter(logging.Formatter):
    """Custom formatter with color support for console output."""
    
    # ANSI color codes
    COLORS = {
        "DEBUG": "\033[36m",     # Cyan
        "INFO": "\033[32m",      # Green
        "WARNING": "\033[33m",   # Yellow
        "ERROR": "\033[31m",     # Red
        "CRITICAL": "\033[35m",  # Magenta
        "RESET": "\033[0m",      # Reset
    }
    
    def __init__(self, fmt: str, datefmt: str = None, use_colors: bool = True):
        super().__init__(fmt, datefmt)
        self.use_colors = use_colors and self._supports_colors()
    
    @staticmethod
    def _supports_colors() -> bool:
        """Check if terminal supports colors."""
        if os.name == "nt":  # Windows
            return os.environ.get("TERM") == "xterm" or "ANSICON" in os.environ
        return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()
    
    def format(self, record: logging.LogRecord) -> str:
        if self.use_colors:
            color = self.COLORS.get(record.levelname, self.COLORS["RESET"])
            reset = self.COLORS["RESET"]
            record.levelname = f"{color}{record.levelname}{reset}"
            record.msg = f"{color}{record.msg}{reset}"
        
        return super().format(record)


class Logger:
    """
    Custom Logger Class
    ===================
    
    Provides:
    - Console output with colors
    - File output with rotation
    - Structured logging support
    - Level-based filtering
    
    Usage:
        logger = Logger("MyAgent")
        logger.info("Agent started")
        logger.error("Something went wrong", extra={"code": 500})
    """
    
    # Default format strings
    CONSOLE_FORMAT = "%(asctime)s | %(levelname)-8s | %(message)s"
    FILE_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
    DATE_FORMAT = "%Y-%m-%d %H:%M:%S"
    
    def __init__(
        self,
        name: str,
        level: str = "INFO",
        log_dir: str = "logs",
        log_file: str = "agent.log",
        console_output: bool = True,
        file_output: bool = True,
        max_file_size_mb: int = 10,
        backup_count: int = 5,
    ):
        """
        Initialize the logger.
        
        Args:
            name: Logger name (usually agent name)
            level: Minimum log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
            log_dir: Directory for log files
            log_file: Log file name
            console_output: Enable console logging
            file_output: Enable file logging
            max_file_size_mb: Max size before rotation
            backup_count: Number of backup files to keep
        """
        self.name = name
        self.level = getattr(logging, level.upper(), logging.INFO)
        self.log_dir = log_dir
        self.log_file = log_file
        self.console_output = console_output
        self.file_output = file_output
        self.max_file_size = max_file_size_mb * 1024 * 1024
        self.backup_count = backup_count
        
        # Create the underlying logger
        self._logger = logging.getLogger(name)
        self._logger.setLevel(self.level)
        self._logger.handlers = []  # Clear any existing handlers
        
        # Setup handlers
        self._setup_handlers()
    
    def _setup_handlers(self) -> None:
        """Setup console and file handlers."""
        # Console handler
        if self.console_output:
            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setLevel(self.level)
            console_formatter = ColorFormatter(
                self.CONSOLE_FORMAT,
                self.DATE_FORMAT,
                use_colors=True
            )
            console_handler.setFormatter(console_formatter)
            self._logger.addHandler(console_handler)
        
        # File handler
        if self.file_output:
            # Create log directory if needed
            log_path = Path(self.log_dir)
            log_path.mkdir(parents=True, exist_ok=True)
            
            file_path = log_path / self.log_file
            
            file_handler = RotatingFileHandler(
                file_path,
                maxBytes=self.max_file_size,
                backupCount=self.backup_count,
                encoding="utf-8",
            )
            file_handler.setLevel(self.level)
            file_formatter = logging.Formatter(
                self.FILE_FORMAT,
                self.DATE_FORMAT
            )
            file_handler.setFormatter(file_formatter)
            self._logger.addHandler(file_handler)
    
    def _format_extra(self, extra: Optional[Dict[str, Any]]) -> str:
        """Format extra data for log message."""
        if not extra:
            return ""
        formatted = " | ".join(f"{k}={v}" for k, v in extra.items())
        return f" [{formatted}]"
    
    def debug(self, message: str, extra: Optional[Dict[str, Any]] = None) -> None:
        """Log debug message."""
        full_message = f"{message}{self._format_extra(extra)}"
        self._logger.debug(full_message)
    
    def info(self, message: str, extra: Optional[Dict[str, Any]] = None) -> None:
        """Log info message."""
        full_message = f"{message}{self._format_extra(extra)}"
        self._logger.info(full_message)
    
    def warning(self, message: str, extra: Optional[Dict[str, Any]] = None) -> None:
        """Log warning message."""
        full_message = f"{message}{self._format_extra(extra)}"
        self._logger.warning(full_message)
    
    def error(self, message: str, extra: Optional[Dict[str, Any]] = None) -> None:
        """Log error message."""
        full_message = f"{message}{self._format_extra(extra)}"
        self._logger.error(full_message)
    
    def critical(self, message: str, extra: Optional[Dict[str, Any]] = None) -> None:
        """Log critical message."""
        full_message = f"{message}{self._format_extra(extra)}"
        self._logger.critical(full_message)
    
    def exception(
        self, 
        message: str, 
        exc_info: bool = True,
        extra: Optional[Dict[str, Any]] = None
    ) -> None:
        """Log exception with traceback."""
        full_message = f"{message}{self._format_extra(extra)}"
        self._logger.exception(full_message, exc_info=exc_info)
    
    def set_level(self, level: str) -> None:
        """Change log level at runtime."""
        new_level = getattr(logging, level.upper(), logging.INFO)
        self._logger.setLevel(new_level)
        for handler in self._logger.handlers:
            handler.setLevel(new_level)
    
    def __repr__(self) -> str:
        return f"Logger(name={self.name!r}, level={logging.getLevelName(self.level)})"


# Global logger instance cache
_loggers: Dict[str, Logger] = {}


def get_logger(
    name: str = "MainAgent",
    level: str = "INFO",
    log_dir: str = "logs",
    log_file: str = "agent.log",
    console_output: bool = True,
    file_output: bool = True,
) -> Logger:
    """
    Get or create a logger instance.
    
    Uses caching to return the same logger for the same name.
    
    Args:
        name: Logger name
        level: Log level
        log_dir: Log directory
        log_file: Log file name
        console_output: Enable console logging
        file_output: Enable file logging
        
    Returns:
        Logger instance
    """
    if name not in _loggers:
        _loggers[name] = Logger(
            name=name,
            level=level,
            log_dir=log_dir,
            log_file=log_file,
            console_output=console_output,
            file_output=file_output,
        )
    return _loggers[name]