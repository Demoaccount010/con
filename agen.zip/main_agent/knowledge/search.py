"""
Web Knowledge Engine
====================
Provides internet access to the AI.
"""

from duckduckgo_search import DDGS
from typing import List, Dict

class WebSearch:
    def __init__(self):
        self.ddgs = DDGS()
    
    def search(self, query: str, max_results: int = 3) -> str:
        """Search the web and return a summary."""
        try:
            results = list(self.ddgs.text(query, max_results=max_results))
            if not results:
                return "No information found online."
            
            summary = "Here is what I found on the internet:\n"
            for r in results:
                summary += f"- {r['title']}: {r['body']}\n"
            
            return summary
        except Exception as e:
            return f"Search error: {str(e)}"