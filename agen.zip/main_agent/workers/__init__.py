"""
Workers Module
==============
Task execution system for the AI agent.

Components:
- Registry: Manages worker registration and capabilities
- Dispatcher: Routes tasks to appropriate workers

Architecture:
- Workers are EXECUTORS, not thinkers
- Workers receive structured tasks from Planner
- Workers report results back to Main Agent
- Workers can be local or remote (REST API)

Design Principles:
1. Workers don't plan - they only execute
2. Workers have defined capabilities
3. Workers have health status
4. Workers can fail gracefully
5. Results are always structured
"""

from main_agent.workers.registry import (
    WorkerRegistry,
    WorkerInfo,
    WorkerStatus,
    WorkerCapability,
    WorkerType,
)
from main_agent.workers.dispatcher import (
    TaskDispatcher,
    DispatchResult,
    DispatchStatus,
    TaskExecution,
)

__all__ = [
    # Registry exports
    "WorkerRegistry",
    "WorkerInfo",
    "WorkerStatus",
    "WorkerCapability",
    "WorkerType",
    # Dispatcher exports
    "TaskDispatcher",
    "DispatchResult",
    "DispatchStatus",
    "TaskExecution",
]