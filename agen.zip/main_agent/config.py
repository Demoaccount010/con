"""
Configuration Management System
===============================
Centralized configuration with environment variable overrides.
"""

import os
from typing import Any, Dict, Optional, Tuple
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class SystemRequirements:
    """Minimum system requirements for the agent."""
    min_ram_gb: float = 4.0
    min_cpu_cores: int = 2
    supported_os: tuple = ("Linux", "Darwin", "Windows")


@dataclass
class LoggingConfig:
    """Logging configuration."""
    level: str = "INFO"
    log_dir: str = "logs"
    log_file: str = "agent.log"
    max_file_size_mb: int = 10
    backup_count: int = 5
    console_output: bool = True
    file_output: bool = True


@dataclass
class AgentConfig:
    """Core agent configuration."""
    name: str = "MainAgent"
    version: str = "1.0.0"
    startup_timeout_sec: int = 30
    shutdown_timeout_sec: int = 10
    health_check_interval_sec: int = 60


@dataclass
class OllamaConfig:
    """Ollama configuration (placeholder for PART-1B)."""
    host: str = "127.0.0.1"
    port: int = 11434
    timeout_sec: int = 120
    default_model: str = "llama2"


class ConfigValidationError(Exception):
    """Raised when configuration validation fails."""
    pass


class Config:
    """
    Central Configuration Manager
    =============================
    
    Handles:
    - Default configuration values
    - Environment variable overrides
    - Configuration validation
    - Runtime configuration access
    
    Usage:
        config = Config()
        config.load()
        print(config.agent.name)
    """
    
    # Environment variable prefix
    ENV_PREFIX = "MAINAGENT_"
    
    def __init__(self):
        self.system_requirements = SystemRequirements()
        self.logging = LoggingConfig()
        self.agent = AgentConfig()
        self.ollama = OllamaConfig()
        self._loaded = False
        self._validated = False
    
    def load(self) -> "Config":
        """
        Load configuration from environment variables.
        
        Environment variables override defaults using prefix MAINAGENT_
        Examples:
            MAINAGENT_LOG_LEVEL=DEBUG
            MAINAGENT_AGENT_NAME=CustomAgent
            MAINAGENT_OLLAMA_PORT=11435
        
        Returns:
            Self for method chaining
        """
        # Logging overrides
        self.logging.level = self._get_env("LOG_LEVEL", self.logging.level)
        self.logging.log_dir = self._get_env("LOG_DIR", self.logging.log_dir)
        self.logging.log_file = self._get_env("LOG_FILE", self.logging.log_file)
        self.logging.console_output = self._get_env_bool(
            "LOG_CONSOLE", self.logging.console_output
        )
        self.logging.file_output = self._get_env_bool(
            "LOG_FILE_OUTPUT", self.logging.file_output
        )
        
        # Agent overrides
        self.agent.name = self._get_env("AGENT_NAME", self.agent.name)
        self.agent.startup_timeout_sec = self._get_env_int(
            "STARTUP_TIMEOUT", self.agent.startup_timeout_sec
        )
        self.agent.shutdown_timeout_sec = self._get_env_int(
            "SHUTDOWN_TIMEOUT", self.agent.shutdown_timeout_sec
        )
        
        # System requirement overrides
        self.system_requirements.min_ram_gb = self._get_env_float(
            "MIN_RAM_GB", self.system_requirements.min_ram_gb
        )
        self.system_requirements.min_cpu_cores = self._get_env_int(
            "MIN_CPU_CORES", self.system_requirements.min_cpu_cores
        )
        
        # Ollama overrides (for PART-1B)
        self.ollama.host = self._get_env("OLLAMA_HOST", self.ollama.host)
        self.ollama.port = self._get_env_int("OLLAMA_PORT", self.ollama.port)
        self.ollama.timeout_sec = self._get_env_int(
            "OLLAMA_TIMEOUT", self.ollama.timeout_sec
        )
        self.ollama.default_model = self._get_env(
            "OLLAMA_MODEL", self.ollama.default_model
        )
        
        self._loaded = True
        return self
    
    def validate(self) -> "Config":
        """
        Validate all configuration values.
        
        Raises:
            ConfigValidationError: If any configuration is invalid
            
        Returns:
            Self for method chaining
        """
        errors = []
        
        # Validate logging
        valid_levels = ("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL")
        if self.logging.level.upper() not in valid_levels:
            errors.append(
                f"Invalid log level '{self.logging.level}'. "
                f"Must be one of: {valid_levels}"
            )
        
        # Validate system requirements
        if self.system_requirements.min_ram_gb <= 0:
            errors.append("min_ram_gb must be positive")
        
        if self.system_requirements.min_cpu_cores <= 0:
            errors.append("min_cpu_cores must be positive")
        
        # Validate agent config
        if not self.agent.name:
            errors.append("Agent name cannot be empty")
        
        if self.agent.startup_timeout_sec <= 0:
            errors.append("startup_timeout_sec must be positive")
        
        # Validate Ollama config
        if self.ollama.port <= 0 or self.ollama.port > 65535:
            errors.append("Ollama port must be between 1 and 65535")
        
        if errors:
            raise ConfigValidationError(
                f"Configuration validation failed:\n" + 
                "\n".join(f"  - {e}" for e in errors)
            )
        
        self._validated = True
        return self
    
    def _get_env(self, key: str, default: str) -> str:
        """Get string environment variable with prefix."""
        return os.environ.get(f"{self.ENV_PREFIX}{key}", default)
    
    def _get_env_int(self, key: str, default: int) -> int:
        """Get integer environment variable with prefix."""
        value = os.environ.get(f"{self.ENV_PREFIX}{key}")
        if value is None:
            return default
        try:
            return int(value)
        except ValueError:
            return default
    
    def _get_env_float(self, key: str, default: float) -> float:
        """Get float environment variable with prefix."""
        value = os.environ.get(f"{self.ENV_PREFIX}{key}")
        if value is None:
            return default
        try:
            return float(value)
        except ValueError:
            return default
    
    def _get_env_bool(self, key: str, default: bool) -> bool:
        """Get boolean environment variable with prefix."""
        value = os.environ.get(f"{self.ENV_PREFIX}{key}")
        if value is None:
            return default
        return value.lower() in ("true", "1", "yes", "on")
    
    def to_dict(self) -> Dict[str, Any]:
        """Export configuration as dictionary."""
        return {
            "system_requirements": {
                "min_ram_gb": self.system_requirements.min_ram_gb,
                "min_cpu_cores": self.system_requirements.min_cpu_cores,
                "supported_os": self.system_requirements.supported_os,
            },
            "logging": {
                "level": self.logging.level,
                "log_dir": self.logging.log_dir,
                "log_file": self.logging.log_file,
                "console_output": self.logging.console_output,
                "file_output": self.logging.file_output,
            },
            "agent": {
                "name": self.agent.name,
                "version": self.agent.version,
                "startup_timeout_sec": self.agent.startup_timeout_sec,
                "shutdown_timeout_sec": self.agent.shutdown_timeout_sec,
            },
            "ollama": {
                "host": self.ollama.host,
                "port": self.ollama.port,
                "timeout_sec": self.ollama.timeout_sec,
                "default_model": self.ollama.default_model,
            },
        }
    
    @property
    def is_loaded(self) -> bool:
        """Check if configuration has been loaded."""
        return self._loaded
    
    @property
    def is_validated(self) -> bool:
        """Check if configuration has been validated."""
        return self._validated
    
    def __repr__(self) -> str:
        return (
            f"Config(loaded={self._loaded}, validated={self._validated}, "
            f"agent={self.agent.name})"
        )
