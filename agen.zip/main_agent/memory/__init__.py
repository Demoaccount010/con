"""
Memory Module
=============
Handles persistent memory using MongoDB.

Features:
- Conversation History
- User Profiles & Preferences
- Task Learning (Self-Improvement)
"""

# Import classes to expose them at module level
from main_agent.memory.db import MemoryDB
from main_agent.memory.conversation import ConversationManager
from main_agent.memory.learning import LearningEngine

__all__ = [
    "MemoryDB",
    "ConversationManager",
    "LearningEngine",
]