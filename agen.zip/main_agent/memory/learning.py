"""
Self-Improvement Engine
=======================
Learns from past tasks successes and failures.
"""

from datetime import datetime
from main_agent.memory.db import MemoryDB

class LearningEngine:
    """
    Tracks task execution to improve future planning.
    """
    
    def __init__(self, db: MemoryDB):
        self.collection = db.get_collection("task_history")
    
    def record_task(self, task_data: dict, success: bool, feedback: str = ""):
        """
        Save task result.
        """
        if self.collection is None:
            return
            
        doc = {
            "goal": task_data.get("goal"),
            "type": task_data.get("task_type"),
            "steps": task_data.get("steps"),
            "success": success,
            "feedback": feedback,
            "timestamp": datetime.now()
        }
        self.collection.insert_one(doc)
    
    def get_similar_tasks(self, goal: str) -> list:
        """
        Find similar past tasks to learn from.
        (Simple text search for now)
        """
        if self.collection is None:
            return []
            
        # Basic search (can be upgraded to vector search later)
        return list(self.collection.find({"goal": {"$regex": goal, "$options": "i"}}).limit(3))