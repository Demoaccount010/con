"""
Database Connection
===================
Manages MongoDB connection and collections.
"""

import os
from typing import Optional
from pymongo import MongoClient
from pymongo.collection import Collection
from pymongo.database import Database

from main_agent.utils.logger import get_logger

class MemoryDB:
    """
    MongoDB Wrapper for AI Memory.
    """
    
    def __init__(self, uri: str = "mongodb://localhost:27017/", db_name: str = "ai_agent_memory"):
        self._uri = os.getenv("MONGO_URI", uri)
        self._db_name = os.getenv("MONGO_DB", db_name)
        self._client: Optional[MongoClient] = None
        self._db: Optional[Database] = None
        self._logger = get_logger("MemoryDB")
        
        self.connect()
    
    def connect(self):
        """Connect to MongoDB."""
        try:
            self._client = MongoClient(self._uri, serverSelectionTimeoutMS=5000)
            self._db = self._client[self._db_name]
            # Test connection
            self._client.server_info()
            self._logger.info(f"Connected to MongoDB: {self._db_name}")
        except Exception as e:
            self._logger.error(f"MongoDB Connection Failed: {e}")
            self._client = None
            self._db = None
    
    @property
    def is_connected(self) -> bool:
        return self._client is not None
    
    def get_collection(self, name: str) -> Optional[Collection]:
        if self.is_connected:
            return self._db[name]
        return None
    
    def close(self):
        if self._client:
            self._client.close()