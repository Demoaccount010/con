#!/usr/bin/env python3
"""
🚀 UNIVERSAL LAUNCHER & CONFIGURATOR (v2.1 - Smart Env Fix)
===========================================================
Automates setup, configuration, and launch of Main AI Agent.

Features:
- Environment & Dependency Check
- Directory Structure Setup
- Ollama Service Verification
- MongoDB Database Setup & Verification (Smart Env Loading)
- Telegram Bot Configuration
- Auto-Launch Logic

Usage:
    python launcher.py
"""

import os
import sys
import subprocess
import time
import shutil
import platform
from pathlib import Path

# --- Configuration ---
PROJECT_ROOT = Path(__file__).parent.absolute()
MAIN_MODULE = "main_agent.main"
REQUIREMENTS_FILE = PROJECT_ROOT / "main_agent" / "requirements.txt"
CONFIG_DIR = Path.home() / ".main_agent"
CONFIG_FILE = CONFIG_DIR / "config.json"
ENV_FILE = PROJECT_ROOT / ".env"

# --- Colors ---
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BOLD = '\033[1m'
    END = '\033[0m'

    @staticmethod
    def disable():
        Colors.HEADER = ''
        Colors.BLUE = ''
        Colors.GREEN = ''
        Colors.YELLOW = ''
        Colors.RED = ''
        Colors.END = ''

if not sys.stdout.isatty():
    Colors.disable()

# --- Helper Functions ---

def print_banner():
    print(f"""{Colors.CYAN}{Colors.BOLD}
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║           🚀 MAIN AGENT - AUTO LAUNCHER v2.1 🚀              ║
║                                                              ║
║      Diagnosing • Configuring • Launching                    ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
{Colors.END}""")

def log_step(message):
    print(f"{Colors.BLUE}ℹ  {message}...{Colors.END}")
    time.sleep(0.3)

def log_success(message):
    print(f"{Colors.GREEN}✅ {message}{Colors.END}")

def log_fail(message, error=None):
    err_msg = f" - {error}" if error else ""
    print(f"{Colors.RED}❌ {message}{err_msg} (SKIPPING){Colors.END}")

def get_input(prompt, default=None):
    d_text = f" [{default}]" if default else ""
    return input(f"{Colors.YELLOW}→ {prompt}{d_text}: {Colors.END}").strip() or default

def load_env():
    """Load environment variables from .env file"""
    if ENV_FILE.exists():
        with open(ENV_FILE, 'r') as f:
            for line in f:
                if '=' in line and not line.startswith('#'):
                    k, v = line.strip().split('=', 1)
                    os.environ[k] = v

def save_env_var(key, value):
    """Save variable to .env file"""
    lines = []
    if ENV_FILE.exists():
        with open(ENV_FILE, 'r') as f:
            lines = f.readlines()
    
    # Remove existing key
    lines = [l for l in lines if not l.startswith(f"{key}=")]
    
    # Add new key
    lines.append(f"{key}={value}\n")
    
    with open(ENV_FILE, 'w') as f:
        f.writelines(lines)
    
    # Update current environment
    os.environ[key] = value

# --- Configuration Steps ---

results = {
    "env": "PENDING",
    "deps": "PENDING",
    "dirs": "PENDING",
    "ollama": "PENDING",
    "mongo": "PENDING",
    "telegram": "PENDING"
}

failed_reasons = []

def step_check_environment():
    log_step("Checking System Environment")
    try:
        if sys.version_info < (3, 10):
            raise Exception(f"Python 3.10+ required, found {sys.version.split()[0]}")
        log_success("Environment OK")
        results["env"] = "SUCCESS"
    except Exception as e:
        log_fail("Environment Check Failed", str(e))
        results["env"] = "FAILED"
        failed_reasons.append(f"Environment: {str(e)}")

def step_install_dependencies():
    log_step("Checking Dependencies")
    try:
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", "-r", str(REQUIREMENTS_FILE)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        log_success("Dependencies installed/verified")
        results["deps"] = "SUCCESS"
    except Exception as e:
        log_fail("Dependency Check Error", str(e))
        results["deps"] = "FAILED"
        failed_reasons.append("Dependencies failed")

def step_create_directories():
    log_step("Configuring Directory Structure")
    try:
        dirs = [PROJECT_ROOT / "logs", CONFIG_DIR]
        for d in dirs:
            os.makedirs(d, exist_ok=True)
        log_success("Directories ready")
        results["dirs"] = "SUCCESS"
    except Exception as e:
        log_fail("Directory Creation Failed", str(e))
        results["dirs"] = "FAILED"

def step_check_ollama():
    log_step("Checking Ollama Service")
    try:
        import urllib.request
        with urllib.request.urlopen("http://127.0.0.1:11434/api/tags", timeout=2):
            pass
        log_success("Ollama is running")
        results["ollama"] = "SUCCESS"
    except:
        log_fail("Ollama not responding")
        results["ollama"] = "FAILED"
        failed_reasons.append("Ollama service not running")

def step_check_mongo():
    """Step 5: Check MongoDB Connection (Smart Env Check)"""
    log_step("Checking MongoDB Database")
    
    # 1. Try loading from Env
    mongo_uri = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
    
    try:
        from pymongo import MongoClient
        
        # Test Connection
        client = MongoClient(mongo_uri, serverSelectionTimeoutMS=2000)
        client.server_info()
        log_success(f"MongoDB Connected ({mongo_uri})")
        results["mongo"] = "SUCCESS"
        
        # Ensure it's saved in .env if not already
        save_env_var("MONGO_URI", mongo_uri)
        return
        
    except ImportError:
        log_fail("pymongo not installed")
        results["mongo"] = "FAILED"
        failed_reasons.append("pymongo missing")
        return
        
    except Exception:
        # Connection Failed - Fallback to Interactive Mode
        print(f"{Colors.YELLOW}⚠️  Could not connect to {mongo_uri}{Colors.END}")
        
        if shutil.which("docker"):
            print(f"{Colors.CYAN}ℹ  Docker detected. Want to start a MongoDB container?{Colors.END}")
            choice = get_input("Start MongoDB via Docker? (y/n)", "y")
            if choice.lower() == 'y':
                try:
                    subprocess.run(
                        ["docker", "run", "-d", "-p", "27017:27017", "--name", "mongo-agent", "mongo:latest"],
                        check=True
                    )
                    log_success("MongoDB Container Started")
                    save_env_var("MONGO_URI", "mongodb://localhost:27017/")
                    results["mongo"] = "SUCCESS"
                    return
                except:
                    print(f"{Colors.RED}✗ Docker start failed{Colors.END}")

        # Manual URI Input
        new_uri = get_input("Enter MongoDB Connection URI", "mongodb://localhost:27017/")
        try:
            client = MongoClient(new_uri, serverSelectionTimeoutMS=2000)
            client.server_info()
            log_success("Connection Successful!")
            save_env_var("MONGO_URI", new_uri)
            results["mongo"] = "SUCCESS"
        except Exception as e:
            log_fail("MongoDB Connection Failed", str(e))
            results["mongo"] = "FAILED"
            failed_reasons.append("MongoDB unreachable (Memory won't work)")

def step_check_telegram_config():
    log_step("Checking Telegram Configuration")
    if CONFIG_FILE.exists():
        log_success("Telegram config found")
        results["telegram"] = "SUCCESS"
    else:
        log_fail("Telegram config missing (Will launch Setup Wizard)")
        results["telegram"] = "FAILED"

def print_summary():
    print(f"\n{Colors.HEADER}══════════════ CONFIGURATION SUMMARY ══════════════{Colors.END}")
    for check, status in results.items():
        icon = "✅" if status == "SUCCESS" else "❌"
        color = Colors.GREEN if status == "SUCCESS" else Colors.RED
        print(f"{color}{icon} {check.upper().ljust(15)} : {status}{Colors.END}")
    print(f"{Colors.HEADER}═══════════════════════════════════════════════════{Colors.END}")

def launch_main_agent():
    print(f"\n{Colors.CYAN}🚀 Launching Main Agent...{Colors.END}")
    time.sleep(1)
    
    cmd = [sys.executable, "-m", "main_agent.main", "--telegram"]
    
    # Load env vars for subprocess
    env = os.environ.copy()
    env["PYTHONPATH"] = str(PROJECT_ROOT)
    
    try:
        subprocess.run(cmd, env=env)
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}🛑 Stopped by user.{Colors.END}")

def main():
    # Load existing env vars first!
    load_env()
    
    print_banner()
    step_check_environment()
    step_install_dependencies()
    step_create_directories()
    step_check_ollama()
    step_check_mongo()
    step_check_telegram_config()
    print_summary()
    
    print(f"\n{Colors.BOLD}Starting in 3 seconds...{Colors.END}")
    try:
        time.sleep(3)
        launch_main_agent()
    except KeyboardInterrupt:
        print("\nLaunch cancelled.")

if __name__ == "__main__":
    main()