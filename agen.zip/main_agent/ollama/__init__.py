"""
Ollama Integration Module
=========================
Handles all Ollama-related functionality:
- Service health checks
- Model management
- LLM client interface
"""

from main_agent.ollama.checker import (
    OllamaChecker,
    OllamaHealthStatus,
    check_ollama_health,
)
from main_agent.ollama.models import (
    OllamaModelManager,
    ModelInfo,
    ModelSafetyLevel,
    get_model_manager,
)
from main_agent.ollama.client import (
    OllamaClient,
    OllamaResponse,
    create_ollama_client,
)

__all__ = [
    # Checker
    "OllamaChecker",
    "OllamaHealthStatus",
    "check_ollama_health",
    # Models
    "OllamaModelManager",
    "ModelInfo",
    "ModelSafetyLevel",
    "get_model_manager",
    # Client
    "OllamaClient",
    "OllamaResponse",
    "create_ollama_client",
]