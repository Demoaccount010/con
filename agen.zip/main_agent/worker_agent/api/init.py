"""
Worker API Module
=================
REST API for receiving and executing tasks.

Endpoints:
- GET  /health       - Health check
- GET  /status       - Worker status
- POST /execute      - Execute a task
- GET  /capabilities - List capabilities
- GET  /tasks        - List running tasks
- POST /cancel       - Cancel a task
"""

from worker_agent.api.server import WorkerServer
from worker_agent.api.auth import TokenAuth, verify_token, require_auth

__all__ = [
    "WorkerServer",
    "TokenAuth",
    "verify_token",
    "require_auth",
]