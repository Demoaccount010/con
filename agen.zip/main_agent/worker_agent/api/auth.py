"""
Worker API Authentication
=========================
Token-based authentication for worker API.

Features:
- Bearer token authentication
- IP whitelist support
- Request signing (optional)
"""

import time
import hmac
import hashlib
from typing import Optional, List, Callable, Dict, Any
from functools import wraps
from dataclasses import dataclass


@dataclass
class AuthResult:
    """Result of authentication check."""
    authenticated: bool
    reason: str = ""
    user_id: Optional[str] = None
    permissions: List[str] = None
    
    def __post_init__(self):
        if self.permissions is None:
            self.permissions = []


class TokenAuth:
    """
    Token-based Authentication
    ==========================
    
    Validates Bearer tokens in Authorization header.
    
    Usage:
        auth = TokenAuth(valid_tokens=["token1", "token2"])
        result = auth.verify("token1")
        
        # Or with IP whitelist
        auth = TokenAuth(
            valid_tokens=["token1"],
            allowed_ips=["192.168.1.100"]
        )
    """
    
    def __init__(
        self,
        valid_tokens: Optional[List[str]] = None,
        allowed_ips: Optional[List[str]] = None,
        require_token: bool = True,
    ):
        """
        Initialize token auth.
        
        Args:
            valid_tokens: List of valid tokens
            allowed_ips: List of allowed IP addresses (empty = all allowed)
            require_token: If True, token is required
        """
        self.valid_tokens = set(valid_tokens or [])
        self.allowed_ips = set(allowed_ips or [])
        self.require_token = require_token
    
    def verify(
        self,
        token: Optional[str],
        client_ip: Optional[str] = None,
    ) -> AuthResult:
        """
        Verify authentication.
        
        Args:
            token: Bearer token (without "Bearer " prefix)
            client_ip: Client IP address
            
        Returns:
            AuthResult with authentication status
        """
        # Check IP whitelist first
        if self.allowed_ips and client_ip:
            if client_ip not in self.allowed_ips and client_ip != "127.0.0.1":
                return AuthResult(
                    authenticated=False,
                    reason=f"IP not allowed: {client_ip}",
                )
        
        # Check if token required
        if not self.require_token:
            return AuthResult(authenticated=True, reason="Token not required")
        
        # Check token
        if not token:
            return AuthResult(
                authenticated=False,
                reason="No token provided",
            )
        
        # Validate token
        if token in self.valid_tokens:
            return AuthResult(
                authenticated=True,
                reason="Valid token",
                permissions=["execute", "read", "write"],
            )
        
        return AuthResult(
            authenticated=False,
            reason="Invalid token",
        )
    
    def add_token(self, token: str) -> None:
        """Add a valid token."""
        self.valid_tokens.add(token)
    
    def remove_token(self, token: str) -> None:
        """Remove a token."""
        self.valid_tokens.discard(token)
    
    def add_allowed_ip(self, ip: str) -> None:
        """Add an allowed IP."""
        self.allowed_ips.add(ip)
    
    def remove_allowed_ip(self, ip: str) -> None:
        """Remove an allowed IP."""
        self.allowed_ips.discard(ip)


def extract_token(authorization_header: Optional[str]) -> Optional[str]:
    """
    Extract token from Authorization header.
    
    Args:
        authorization_header: Full Authorization header value
        
    Returns:
        Token string or None
    """
    if not authorization_header:
        return None
    
    parts = authorization_header.split()
    
    if len(parts) == 2 and parts[0].lower() == "bearer":
        return parts[1]
    
    # Allow raw token without Bearer prefix
    if len(parts) == 1:
        return parts[0]
    
    return None


def verify_token(
    token: str,
    valid_tokens: List[str],
) -> bool:
    """
    Simple token verification.
    
    Args:
        token: Token to verify
        valid_tokens: List of valid tokens
        
    Returns:
        True if token is valid
    """
    return token in valid_tokens


def generate_signature(
    payload: str,
    secret: str,
    timestamp: Optional[int] = None,
) -> str:
    """
    Generate HMAC signature for request.
    
    Args:
        payload: Request payload (JSON string)
        secret: Shared secret
        timestamp: Unix timestamp (uses current if not provided)
        
    Returns:
        Signature string
    """
    if timestamp is None:
        timestamp = int(time.time())
    
    message = f"{timestamp}:{payload}"
    signature = hmac.new(
        secret.encode(),
        message.encode(),
        hashlib.sha256,
    ).hexdigest()
    
    return f"{timestamp}.{signature}"


def verify_signature(
    payload: str,
    signature: str,
    secret: str,
    max_age_seconds: int = 300,
) -> bool:
    """
    Verify HMAC signature.
    
    Args:
        payload: Request payload
        signature: Signature string (timestamp.hash)
        secret: Shared secret
        max_age_seconds: Maximum age of signature
        
    Returns:
        True if signature is valid
    """
    try:
        parts = signature.split(".")
        if len(parts) != 2:
            return False
        
        timestamp = int(parts[0])
        provided_hash = parts[1]
        
        # Check timestamp
        now = int(time.time())
        if abs(now - timestamp) > max_age_seconds:
            return False
        
        # Verify hash
        message = f"{timestamp}:{payload}"
        expected_hash = hmac.new(
            secret.encode(),
            message.encode(),
            hashlib.sha256,
        ).hexdigest()
        
        return hmac.compare_digest(provided_hash, expected_hash)
        
    except Exception:
        return False


class RequestSigner:
    """
    Signs and verifies requests.
    
    Usage:
        signer = RequestSigner(secret="shared_secret")
        
        # Sign a request
        signature = signer.sign({"action": "execute"})
        
        # Verify a request
        is_valid = signer.verify({"action": "execute"}, signature)
    """
    
    def __init__(self, secret: str, max_age_seconds: int = 300):
        """
        Initialize request signer.
        
        Args:
            secret: Shared secret for HMAC
            max_age_seconds: Maximum signature age
        """
        self.secret = secret
        self.max_age_seconds = max_age_seconds
    
    def sign(self, payload: Dict[str, Any]) -> str:
        """
        Sign a request payload.
        
        Args:
            payload: Request data
            
        Returns:
            Signature string
        """
        import json
        payload_str = json.dumps(payload, sort_keys=True)
        return generate_signature(payload_str, self.secret)
    
    def verify(self, payload: Dict[str, Any], signature: str) -> bool:
        """
        Verify a request signature.
        
        Args:
            payload: Request data
            signature: Signature to verify
            
        Returns:
            True if valid
        """
        import json
        payload_str = json.dumps(payload, sort_keys=True)
        return verify_signature(
            payload_str,
            signature,
            self.secret,
            self.max_age_seconds,
        )


def require_auth(auth: TokenAuth):
    """
    Decorator factory for requiring authentication.
    
    Usage (with aiohttp):
        @require_auth(auth)
        async def handle_execute(request):
            ...
    """
    def decorator(func: Callable):
        @wraps(func)
        async def wrapper(request, *args, **kwargs):
            # Extract token
            auth_header = request.headers.get("Authorization", "")
            token = extract_token(auth_header)
            
            # Get client IP
            client_ip = request.remote
            
            # Verify
            result = auth.verify(token, client_ip)
            
            if not result.authenticated:
                from aiohttp import web
                return web.json_response(
                    {
                        "error": "Unauthorized",
                        "reason": result.reason,
                    },
                    status=401,
                )
            
            # Add auth result to request
            request["auth"] = result
            
            return await func(request, *args, **kwargs)
        return wrapper
    return decorator