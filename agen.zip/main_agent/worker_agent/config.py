"""
Worker Agent Configuration
==========================
Configuration management for worker agents.

Supports:
- Environment variables
- Config file (JSON)
- Command line arguments
- Auto-registration with Main Agent
"""

import os
import json
import uuid
import socket
import platform
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path


# Default paths
DEFAULT_CONFIG_DIR = os.path.expanduser("~/.worker_agent")
DEFAULT_CONFIG_FILE = "config.json"


@dataclass
class WorkerConfig:
    """
    Worker Agent Configuration.
    
    All settings for worker operation.
    """
    # Worker Identity
    worker_id: str = ""
    worker_name: str = ""
    worker_type: str = "GENERAL"  # GENERAL, WEB, FILE, CODE, DOCKER
    
    # API Server
    host: str = "0.0.0.0"
    port: int = 8001
    debug: bool = False
    
    # Authentication
    auth_token: str = ""
    allowed_ips: List[str] = field(default_factory=list)
    require_auth: bool = True
    
    # Main Agent Connection
    main_agent_url: str = ""
    auto_register: bool = True
    heartbeat_interval: int = 30  # seconds
    
    # Capabilities
    capabilities: List[str] = field(default_factory=lambda: [
        "FILE_READ", "FILE_WRITE", "CODE_EXECUTE", "HTTP_REQUEST"
    ])
    
    # Limits
    max_concurrent_tasks: int = 5
    task_timeout: int = 300  # 5 minutes default
    max_memory_mb: int = 1024
    
    # Paths
    workspace_dir: str = "/tmp/worker_agent"
    log_dir: str = "logs"
    log_level: str = "INFO"
    
    # Security
    allowed_commands: List[str] = field(default_factory=list)  # Empty = all allowed
    blocked_commands: List[str] = field(default_factory=lambda: [
        "rm -rf /", "mkfs", "dd if=/dev/zero", ":(){ :|:& };:",
        "shutdown", "reboot", "halt", "poweroff"
    ])
    allowed_paths: List[str] = field(default_factory=lambda: ["/tmp", "/home"])
    sandbox_mode: bool = True
    
    # Metadata
    created_at: str = ""
    updated_at: str = ""
    version: str = "1.0.0"
    
    def __post_init__(self):
        """Initialize defaults after creation."""
        # Generate worker ID if not set
        if not self.worker_id:
            self.worker_id = self._generate_worker_id()
        
        # Generate worker name if not set
        if not self.worker_name:
            self.worker_name = self._generate_worker_name()
        
        # Generate auth token if not set
        if not self.auth_token:
            self.auth_token = self._generate_auth_token()
        
        # Set timestamps
        if not self.created_at:
            self.created_at = datetime.now().isoformat()
        self.updated_at = datetime.now().isoformat()
    
    def _generate_worker_id(self) -> str:
        """Generate unique worker ID."""
        hostname = socket.gethostname()[:8]
        unique = uuid.uuid4().hex[:8]
        return f"worker-{hostname}-{unique}"
    
    def _generate_worker_name(self) -> str:
        """Generate worker name."""
        hostname = socket.gethostname()
        return f"Worker@{hostname}"
    
    def _generate_auth_token(self) -> str:
        """Generate authentication token."""
        return uuid.uuid4().hex + uuid.uuid4().hex
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "WorkerConfig":
        """Create from dictionary."""
        known_fields = {f.name for f in cls.__dataclass_fields__.values()}
        filtered = {k: v for k, v in data.items() if k in known_fields}
        return cls(**filtered)
    
    def get_api_url(self) -> str:
        """Get this worker's API URL."""
        # Try to get public IP
        try:
            hostname = socket.gethostname()
            local_ip = socket.gethostbyname(hostname)
        except:
            local_ip = "127.0.0.1"
        
        return f"http://{local_ip}:{self.port}"
    
    def get_system_info(self) -> Dict[str, Any]:
        """Get system information."""
        return {
            "hostname": socket.gethostname(),
            "platform": platform.system(),
            "platform_version": platform.version(),
            "architecture": platform.machine(),
            "python_version": platform.python_version(),
        }
    
    def get_registration_payload(self) -> Dict[str, Any]:
        """Get payload for registering with Main Agent."""
        return {
            "worker_id": self.worker_id,
            "name": self.worker_name,
            "type": self.worker_type,
            "endpoint": self.get_api_url(),
            "auth_token": self.auth_token,
            "capabilities": self.capabilities,
            "max_concurrent_tasks": self.max_concurrent_tasks,
            "system_info": self.get_system_info(),
            "version": self.version,
        }
    
    def is_command_allowed(self, command: str) -> bool:
        """Check if a command is allowed to execute."""
        # Check blocked commands
        for blocked in self.blocked_commands:
            if blocked in command:
                return False
        
        # If allowed_commands is empty, allow all (except blocked)
        if not self.allowed_commands:
            return True
        
        # Check if command starts with allowed command
        cmd_name = command.split()[0] if command else ""
        return cmd_name in self.allowed_commands
    
    def is_path_allowed(self, path: str) -> bool:
        """Check if a path is allowed for file operations."""
        if not self.allowed_paths:
            return True
        
        path = os.path.abspath(path)
        return any(path.startswith(allowed) for allowed in self.allowed_paths)


class WorkerConfigStore:
    """
    Manages worker configuration persistence.
    """
    
    def __init__(
        self,
        config_dir: Optional[str] = None,
        config_file: str = DEFAULT_CONFIG_FILE,
    ):
        """
        Initialize config store.
        
        Args:
            config_dir: Directory for config file
            config_file: Config file name
        """
        self.config_dir = Path(config_dir or DEFAULT_CONFIG_DIR)
        self.config_file = config_file
        self.config_path = self.config_dir / self.config_file
        
        # Ensure directory exists
        self.config_dir.mkdir(parents=True, exist_ok=True)
    
    def exists(self) -> bool:
        """Check if config file exists."""
        return self.config_path.exists()
    
    def load(self) -> Optional[WorkerConfig]:
        """Load configuration from file."""
        if not self.exists():
            return None
        
        try:
            with open(self.config_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return WorkerConfig.from_dict(data)
        except Exception as e:
            print(f"Error loading config: {e}")
            return None
    
    def save(self, config: WorkerConfig) -> bool:
        """Save configuration to file."""
        try:
            config.updated_at = datetime.now().isoformat()
            
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(config.to_dict(), f, indent=2)
            
            # Set file permissions
            try:
                os.chmod(self.config_path, 0o600)
            except:
                pass
            
            return True
        except Exception as e:
            print(f"Error saving config: {e}")
            return False
    
    def delete(self) -> bool:
        """Delete config file."""
        try:
            if self.exists():
                os.remove(self.config_path)
            return True
        except:
            return False


def load_worker_config(
    config_path: Optional[str] = None,
    create_if_missing: bool = True,
) -> WorkerConfig:
    """
    Load or create worker configuration.
    
    Args:
        config_path: Optional path to config file
        create_if_missing: Create default config if not found
        
    Returns:
        WorkerConfig instance
    """
    store = WorkerConfigStore(config_dir=config_path)
    
    # Try to load existing
    config = store.load()
    
    if config:
        return config
    
    # Create new config
    if create_if_missing:
        config = WorkerConfig()
        store.save(config)
        print(f"Created new worker config: {store.config_path}")
        return config
    
    raise FileNotFoundError("Worker config not found")


def load_from_env() -> WorkerConfig:
    """
    Load configuration from environment variables.
    
    Environment variables:
        WORKER_ID, WORKER_NAME, WORKER_TYPE
        WORKER_HOST, WORKER_PORT
        WORKER_AUTH_TOKEN
        WORKER_MAIN_AGENT_URL
        WORKER_CAPABILITIES (comma-separated)
    """
    config = WorkerConfig()
    
    # Identity
    if os.getenv("WORKER_ID"):
        config.worker_id = os.getenv("WORKER_ID")
    if os.getenv("WORKER_NAME"):
        config.worker_name = os.getenv("WORKER_NAME")
    if os.getenv("WORKER_TYPE"):
        config.worker_type = os.getenv("WORKER_TYPE")
    
    # Server
    if os.getenv("WORKER_HOST"):
        config.host = os.getenv("WORKER_HOST")
    if os.getenv("WORKER_PORT"):
        config.port = int(os.getenv("WORKER_PORT"))
    
    # Auth
    if os.getenv("WORKER_AUTH_TOKEN"):
        config.auth_token = os.getenv("WORKER_AUTH_TOKEN")
    
    # Main Agent
    if os.getenv("WORKER_MAIN_AGENT_URL"):
        config.main_agent_url = os.getenv("WORKER_MAIN_AGENT_URL")
    
    # Capabilities
    if os.getenv("WORKER_CAPABILITIES"):
        config.capabilities = [
            c.strip() for c in os.getenv("WORKER_CAPABILITIES").split(",")
        ]
    
    return config