"""
Web Executor
============
Handles web-related tasks:
- HTTP requests
- File downloads
- Web scraping
- Image downloads

Features:
- Async HTTP requests
- Progress tracking
- Retry logic
- Content parsing
"""

import os
import re
import json
import asyncio
import urllib.request
import urllib.error
import urllib.parse
from typing import Dict, Any, Optional, List
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import ssl
import socket

from worker_agent.executors.base import (
    BaseExecutor,
    ExecutorResult,
    ExecutorError,
    ValidationError,
)


class WebExecutor(BaseExecutor):
    """
    Web Task Executor
    =================
    
    Handles:
    - HTTP/HTTPS requests
    - File downloads
    - Web page scraping
    - Image downloads
    
    Actions:
    - http_request: Make HTTP request
    - download_file: Download a file
    - web_scrape: Scrape web page content
    - download_images: Download images from page
    
    Usage:
        executor = WebExecutor(config)
        result = await executor.http_request({
            "url": "https://api.example.com/data",
            "method": "GET"
        })
    """
    
    # Default settings
    DEFAULT_TIMEOUT = 30
    DEFAULT_USER_AGENT = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    )
    MAX_RETRIES = 3
    RETRY_DELAY = 1.0
    MAX_DOWNLOAD_SIZE = 100 * 1024 * 1024  # 100 MB
    
    def __init__(self, config: Any, logger=None):
        """Initialize web executor."""
        super().__init__(config, logger)
        
        self._thread_pool = ThreadPoolExecutor(max_workers=5)
        self._download_dir = getattr(
            config, 'workspace_dir', '/tmp/worker_agent'
        )
        
        # Ensure download directory exists
        os.makedirs(self._download_dir, exist_ok=True)
    
    def get_actions(self) -> List[str]:
        """Get supported actions."""
        return [
            "http_request",
            "download_file",
            "web_scrape",
            "download_images",
        ]
    
    async def execute(
        self,
        action: str,
        params: Dict[str, Any],
    ) -> ExecutorResult:
        """Execute web action."""
        if action == "http_request":
            return await self.http_request(params)
        elif action == "download_file":
            return await self.download_file(params)
        elif action == "web_scrape":
            return await self.scrape(params)
        elif action == "download_images":
            return await self.download_images(params)
        else:
            return ExecutorResult.fail(f"Unknown action: {action}")
    
    async def http_request(self, params: Dict[str, Any]) -> ExecutorResult:
        """
        Make HTTP request.
        
        Params:
            url: Request URL (required)
            method: HTTP method (GET, POST, PUT, DELETE)
            headers: Request headers dict
            body: Request body (dict for JSON, string otherwise)
            timeout: Request timeout in seconds
            follow_redirects: Follow redirects (default: True)
            
        Returns:
            ExecutorResult with response data
        """
        self.validate_required(params, ["url"])
        
        url = params["url"]
        method = params.get("method", "GET").upper()
        headers = params.get("headers", {})
        body = params.get("body")
        timeout = params.get("timeout", self.DEFAULT_TIMEOUT)
        
        # Set default headers
        if "User-Agent" not in headers:
            headers["User-Agent"] = self.DEFAULT_USER_AGENT
        
        # Prepare body
        data = None
        if body:
            if isinstance(body, dict):
                data = json.dumps(body).encode('utf-8')
                if "Content-Type" not in headers:
                    headers["Content-Type"] = "application/json"
            elif isinstance(body, str):
                data = body.encode('utf-8')
            else:
                data = body
        
        # Create request
        request = urllib.request.Request(
            url,
            data=data,
            headers=headers,
            method=method,
        )
        
        # Create SSL context
        ssl_context = ssl.create_default_context()
        
        try:
            # Execute in thread pool (urllib is blocking)
            loop = asyncio.get_event_loop()
            response = await loop.run_in_executor(
                self._thread_pool,
                lambda: self._do_request(request, timeout, ssl_context),
            )
            
            return ExecutorResult.ok(response)
            
        except urllib.error.HTTPError as e:
            return ExecutorResult.fail(
                error=f"HTTP {e.code}: {e.reason}",
                error_type="HTTPError",
                metadata={
                    "status_code": e.code,
                    "url": url,
                    "headers": dict(e.headers) if e.headers else {},
                },
            )
        except urllib.error.URLError as e:
            return ExecutorResult.fail(
                error=f"URL Error: {e.reason}",
                error_type="URLError",
                metadata={"url": url},
            )
        except socket.timeout:
            return ExecutorResult.timeout(f"Request timed out after {timeout}s")
        except Exception as e:
            return ExecutorResult.fail(
                error=str(e),
                error_type=type(e).__name__,
            )
    
    def _do_request(
        self,
        request: urllib.request.Request,
        timeout: int,
        ssl_context: ssl.SSLContext,
    ) -> Dict[str, Any]:
        """Execute HTTP request (blocking)."""
        with urllib.request.urlopen(
            request,
            timeout=timeout,
            context=ssl_context,
        ) as response:
            content = response.read()
            
            # Try to decode as text
            content_type = response.headers.get("Content-Type", "")
            
            if "text" in content_type or "json" in content_type or "xml" in content_type:
                encoding = response.headers.get_content_charset() or 'utf-8'
                try:
                    content_text = content.decode(encoding, errors='replace')
                except:
                    content_text = content.decode('utf-8', errors='replace')
                
                # Try to parse JSON
                if "json" in content_type:
                    try:
                        content_text = json.loads(content_text)
                    except:
                        pass
            else:
                content_text = f"[Binary content: {len(content)} bytes]"
            
            return {
                "status_code": response.status,
                "url": response.url,
                "headers": dict(response.headers),
                "content": content_text,
                "content_length": len(content),
            }
    
    async def download_file(self, params: Dict[str, Any]) -> ExecutorResult:
        """
        Download a file.
        
        Params:
            url: File URL (required)
            save_path: Path to save file (optional, auto-generated if not provided)
            filename: Override filename (optional)
            timeout: Download timeout
            max_size: Maximum file size in bytes
            
        Returns:
            ExecutorResult with download info
        """
        self.validate_required(params, ["url"])
        
        url = params["url"]
        save_path = params.get("save_path")
        filename = params.get("filename")
        timeout = params.get("timeout", 300)
        max_size = params.get("max_size", self.MAX_DOWNLOAD_SIZE)
        
        # Generate filename if not provided
        if not filename:
            parsed = urllib.parse.urlparse(url)
            filename = os.path.basename(parsed.path) or "downloaded_file"
        
        # Generate save path if not provided
        if not save_path:
            save_path = os.path.join(self._download_dir, filename)
        
        # Check path allowed
        self.check_path_allowed(save_path)
        
        # Create directory if needed
        os.makedirs(os.path.dirname(save_path) or ".", exist_ok=True)
        
        try:
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(
                self._thread_pool,
                lambda: self._do_download(url, save_path, timeout, max_size),
            )
            
            return ExecutorResult.ok(result)
            
        except Exception as e:
            return ExecutorResult.fail(
                error=str(e),
                error_type=type(e).__name__,
            )
    
    def _do_download(
        self,
        url: str,
        save_path: str,
        timeout: int,
        max_size: int,
    ) -> Dict[str, Any]:
        """Download file (blocking)."""
        request = urllib.request.Request(
            url,
            headers={"User-Agent": self.DEFAULT_USER_AGENT},
        )
        
        with urllib.request.urlopen(request, timeout=timeout) as response:
            # Check content length
            content_length = response.headers.get("Content-Length")
            if content_length and int(content_length) > max_size:
                raise ValueError(
                    f"File too large: {int(content_length)} bytes "
                    f"(max: {max_size} bytes)"
                )
            
            # Download with size limit
            downloaded = 0
            with open(save_path, 'wb') as f:
                while True:
                    chunk = response.read(8192)
                    if not chunk:
                        break
                    
                    downloaded += len(chunk)
                    if downloaded > max_size:
                        os.remove(save_path)
                        raise ValueError(f"File exceeded max size: {max_size} bytes")
                    
                    f.write(chunk)
            
            return {
                "url": url,
                "save_path": save_path,
                "filename": os.path.basename(save_path),
                "size_bytes": downloaded,
                "size_mb": round(downloaded / (1024 * 1024), 2),
                "content_type": response.headers.get("Content-Type"),
            }
    
    async def scrape(self, params: Dict[str, Any]) -> ExecutorResult:
        """
        Scrape web page content.
        
        Params:
            url: Page URL (required)
            selector: CSS selector for elements (optional)
            extract: What to extract - "text", "html", "links", "images"
            timeout: Request timeout
            
        Returns:
            ExecutorResult with scraped content
        """
        self.validate_required(params, ["url"])
        
        url = params["url"]
        extract = params.get("extract", "text")
        selector = params.get("selector")
        timeout = params.get("timeout", self.DEFAULT_TIMEOUT)
        
        # First, get the page content
        request_result = await self.http_request({
            "url": url,
            "timeout": timeout,
        })
        
        if not request_result.success:
            return request_result
        
        content = request_result.data.get("content", "")
        
        if not isinstance(content, str):
            content = str(content)
        
        result = {
            "url": url,
            "title": self._extract_title(content),
        }
        
        if extract == "text":
            result["text"] = self._extract_text(content)
        elif extract == "html":
            result["html"] = content
        elif extract == "links":
            result["links"] = self._extract_links(content, url)
        elif extract == "images":
            result["images"] = self._extract_images(content, url)
        elif extract == "all":
            result["text"] = self._extract_text(content)
            result["links"] = self._extract_links(content, url)
            result["images"] = self._extract_images(content, url)
        
        return ExecutorResult.ok(result)
    
    def _extract_title(self, html: str) -> str:
        """Extract page title."""
        match = re.search(r'<title[^>]*>([^<]+)</title>', html, re.IGNORECASE)
        return match.group(1).strip() if match else ""
    
    def _extract_text(self, html: str) -> str:
        """Extract text content from HTML."""
        # Remove scripts and styles
        text = re.sub(r'<script[^>]*>[\s\S]*?</script>', '', html, flags=re.IGNORECASE)
        text = re.sub(r'<style[^>]*>[\s\S]*?</style>', '', text, flags=re.IGNORECASE)
        
        # Remove HTML tags
        text = re.sub(r'<[^>]+>', ' ', text)
        
        # Clean whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Decode HTML entities
        text = text.replace('&nbsp;', ' ')
        text = text.replace('&amp;', '&')
        text = text.replace('&lt;', '<')
        text = text.replace('&gt;', '>')
        text = text.replace('&quot;', '"')
        
        return text.strip()
    
    def _extract_links(self, html: str, base_url: str) -> List[Dict[str, str]]:
        """Extract all links from HTML."""
        links = []
        
        # Find all anchor tags
        pattern = r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>([^<]*)</a>'
        matches = re.findall(pattern, html, re.IGNORECASE)
        
        for href, text in matches:
            # Make absolute URL
            full_url = urllib.parse.urljoin(base_url, href)
            
            links.append({
                "url": full_url,
                "text": text.strip(),
            })
        
        return links
    
    def _extract_images(self, html: str, base_url: str) -> List[Dict[str, str]]:
        """Extract all images from HTML."""
        images = []
        
        # Find all img tags
        pattern = r'<img[^>]+src=["\']([^"\']+)["\'][^>]*>'
        matches = re.findall(pattern, html, re.IGNORECASE)
        
        for src in matches:
            # Make absolute URL
            full_url = urllib.parse.urljoin(base_url, src)
            
            # Get alt text
            alt_match = re.search(
                rf'<img[^>]+src=["\'{re.escape(src)}["\'][^>]*alt=["\']([^"\']*)["\']',
                html,
                re.IGNORECASE,
            )
            alt = alt_match.group(1) if alt_match else ""
            
            images.append({
                "url": full_url,
                "alt": alt,
            })
        
        return images
    
    async def download_images(self, params: Dict[str, Any]) -> ExecutorResult:
        """
        Download all images from a web page.
        
        Params:
            url: Page URL (required)
            save_dir: Directory to save images
            limit: Maximum images to download
            min_size: Minimum file size in bytes
            extensions: Allowed extensions list
            
        Returns:
            ExecutorResult with download summary
        """
        self.validate_required(params, ["url"])
        
        url = params["url"]
        save_dir = params.get("save_dir", os.path.join(self._download_dir, "images"))
        limit = params.get("limit", 50)
        min_size = params.get("min_size", 1000)  # 1KB minimum
        extensions = params.get("extensions", [".jpg", ".jpeg", ".png", ".gif", ".webp"])
        
        # Check path
        self.check_path_allowed(save_dir)
        
        # Create directory
        os.makedirs(save_dir, exist_ok=True)
        
        # First scrape the page for images
        scrape_result = await self.scrape({
            "url": url,
            "extract": "images",
        })
        
        if not scrape_result.success:
            return scrape_result
        
        images = scrape_result.data.get("images", [])
        
        # Filter by extension
        filtered = []
        for img in images:
            img_url = img["url"]
            ext = os.path.splitext(urllib.parse.urlparse(img_url).path)[1].lower()
            if ext in extensions or not extensions:
                filtered.append(img)
        
        # Limit images
        filtered = filtered[:limit]
        
        # Download images
        downloaded = []
        failed = []
        
        for i, img in enumerate(filtered):
            img_url = img["url"]
            
            # Generate filename
            parsed = urllib.parse.urlparse(img_url)
            filename = os.path.basename(parsed.path)
            if not filename:
                filename = f"image_{i}.jpg"
            
            # Make unique
            save_path = os.path.join(save_dir, f"{i:03d}_{filename}")
            
            try:
                result = await self.download_file({
                    "url": img_url,
                    "save_path": save_path,
                    "timeout": 30,
                })
                
                if result.success:
                    size = result.data.get("size_bytes", 0)
                    if size >= min_size:
                        downloaded.append({
                            "url": img_url,
                            "path": save_path,
                            "size": size,
                        })
                    else:
                        # Too small, delete
                        os.remove(save_path)
                        failed.append({
                            "url": img_url,
                            "error": f"Too small: {size} bytes",
                        })
                else:
                    failed.append({
                        "url": img_url,
                        "error": result.error,
                    })
                    
            except Exception as e:
                failed.append({
                    "url": img_url,
                    "error": str(e),
                })
        
        return ExecutorResult.ok({
            "source_url": url,
            "save_dir": save_dir,
            "total_found": len(images),
            "total_downloaded": len(downloaded),
            "total_failed": len(failed),
            "downloaded": downloaded,
            "failed": failed[:10],  # Limit failed list
        })