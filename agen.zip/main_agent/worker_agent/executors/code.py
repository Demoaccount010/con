"""
Code Executor
=============
Executes code in various languages:
- Python scripts
- Shell commands
- Node.js scripts
- Custom scripts

Features:
- Sandboxed execution
- Timeout management
- Output capture
- Error handling

Security:
- Command blocking
- Resource limits
- Path restrictions
"""

import os
import sys
import subprocess
import tempfile
import shutil
from typing import Dict, Any, Optional, List
from datetime import datetime

from worker_agent.executors.base import (
    BaseExecutor,
    ExecutorResult,
    ExecutorError,
    ValidationError,
    PermissionDeniedError,
)


class CodeExecutor(BaseExecutor):
    """
    Code Execution Executor
    =======================
    
    Executes code safely with proper sandboxing.
    
    Actions:
    - code_execute: Execute code in specified language
    - python_run: Execute Python code
    - shell_run: Execute shell command
    - script_run: Execute script file
    
    Security:
    - All commands checked against blocked list
    - Execution timeout enforced
    - Sandboxed working directory
    - Resource limits (where supported)
    
    Usage:
        executor = CodeExecutor(config)
        result = await executor.run_python({
            "code": "print('Hello World')"
        })
    """
    
    # Limits
    DEFAULT_TIMEOUT = 60  # seconds
    MAX_OUTPUT_SIZE = 1024 * 1024  # 1 MB
    MAX_CODE_SIZE = 100 * 1024  # 100 KB
    
    # Supported languages
    LANGUAGES = {
        "python": {
            "command": [sys.executable, "-c"],
            "file_ext": ".py",
            "file_command": [sys.executable],
        },
        "python3": {
            "command": ["python3", "-c"],
            "file_ext": ".py",
            "file_command": ["python3"],
        },
        "bash": {
            "command": ["bash", "-c"],
            "file_ext": ".sh",
            "file_command": ["bash"],
        },
        "sh": {
            "command": ["sh", "-c"],
            "file_ext": ".sh",
            "file_command": ["sh"],
        },
        "node": {
            "command": ["node", "-e"],
            "file_ext": ".js",
            "file_command": ["node"],
        },
        "ruby": {
            "command": ["ruby", "-e"],
            "file_ext": ".rb",
            "file_command": ["ruby"],
        },
        "perl": {
            "command": ["perl", "-e"],
            "file_ext": ".pl",
            "file_command": ["perl"],
        },
    }
    
    def __init__(self, config: Any, logger=None):
        """Initialize code executor."""
        super().__init__(config, logger)
        
        self._workspace = getattr(
            config, 'workspace_dir', '/tmp/worker_agent'
        )
        self._sandbox_dir = os.path.join(self._workspace, "sandbox")
        
        # Ensure directories exist
        os.makedirs(self._sandbox_dir, exist_ok=True)
    
    def get_actions(self) -> List[str]:
        """Get supported actions."""
        return [
            "code_execute",
            "python_run",
            "shell_run",
            "script_run",
        ]
    
    async def execute(
        self,
        action: str,
        params: Dict[str, Any],
    ) -> ExecutorResult:
        """Execute code action."""
        if action == "code_execute":
            return await self._execute_code(params)
        elif action == "python_run":
            return await self.run_python(params)
        elif action == "shell_run":
            return await self.run_shell(params)
        elif action == "script_run":
            return await self.run_script(params)
        else:
            return ExecutorResult.fail(f"Unknown action: {action}")
    
    async def _execute_code(self, params: Dict[str, Any]) -> ExecutorResult:
        """
        Execute code in specified language.
        
        Params:
            code: Code to execute (required)
            language: Programming language (required)
            timeout: Execution timeout
            env: Environment variables
            cwd: Working directory
            
        Returns:
            ExecutorResult with execution output
        """
        self.validate_required(params, ["code", "language"])
        
        code = params["code"]
        language = params["language"].lower()
        timeout = params.get("timeout", self.DEFAULT_TIMEOUT)
        env = params.get("env", {})
        cwd = params.get("cwd")
        
        # Check language supported
        if language not in self.LANGUAGES:
            return ExecutorResult.fail(
                f"Unsupported language: {language}. "
                f"Supported: {', '.join(self.LANGUAGES.keys())}",
            )
        
        # Check code size
        if len(code) > self.MAX_CODE_SIZE:
            return ExecutorResult.fail(
                f"Code too large: {len(code)} bytes (max: {self.MAX_CODE_SIZE})",
            )
        
        # Security check
        self.check_command_allowed(code)
        
        # Get language config
        lang_config = self.LANGUAGES[language]
        command = lang_config["command"] + [code]
        
        return await self._run_command(
            command=command,
            timeout=timeout,
            env=env,
            cwd=cwd,
        )
    
    async def run_python(self, params: Dict[str, Any]) -> ExecutorResult:
        """
        Execute Python code.
        
        Params:
            code: Python code to execute (required)
            timeout: Execution timeout
            env: Environment variables
            packages: List of packages to import (convenience)
            
        Returns:
            ExecutorResult with execution output
        """
        self.validate_required(params, ["code"])
        
        code = params["code"]
        packages = params.get("packages", [])
        
        # Add package imports
        if packages:
            imports = "\n".join(f"import {pkg}" for pkg in packages)
            code = imports + "\n\n" + code
        
        params["code"] = code
        params["language"] = "python"
        
        return await self._execute_code(params)
    
    async def run_shell(self, params: Dict[str, Any]) -> ExecutorResult:
        """
        Execute shell command.
        
        Params:
            command: Command to execute (required)
            shell: Shell to use (bash, sh) (default: bash)
            timeout: Execution timeout
            env: Environment variables
            cwd: Working directory
            
        Returns:
            ExecutorResult with command output
        """
        self.validate_required(params, ["command"])
        
        command = params["command"]
        shell = params.get("shell", "bash")
        timeout = params.get("timeout", self.DEFAULT_TIMEOUT)
        env = params.get("env", {})
        cwd = params.get("cwd")
        
        # Security check
        self.check_command_allowed(command)
        
        # Build command
        if shell == "bash":
            cmd = ["bash", "-c", command]
        else:
            cmd = ["sh", "-c", command]
        
        return await self._run_command(
            command=cmd,
            timeout=timeout,
            env=env,
            cwd=cwd,
        )
    
    async def run_script(self, params: Dict[str, Any]) -> ExecutorResult:
        """
        Execute a script file.
        
        Params:
            path: Script file path (required)
            language: Script language (auto-detect if not specified)
            args: Command line arguments
            timeout: Execution timeout
            env: Environment variables
            
        Returns:
            ExecutorResult with script output
        """
        self.validate_required(params, ["path"])
        
        path = params["path"]
        language = params.get("language")
        args = params.get("args", [])
        timeout = params.get("timeout", self.DEFAULT_TIMEOUT)
        env = params.get("env", {})
        
        # Resolve path
        if not os.path.isabs(path):
            path = os.path.join(self._workspace, path)
        
        # Security check
        self.check_path_allowed(path)
        
        # Check file exists
        if not os.path.exists(path):
            return ExecutorResult.fail(f"Script not found: {path}")
        
        # Auto-detect language
        if not language:
            ext = os.path.splitext(path)[1].lower()
            lang_map = {
                ".py": "python",
                ".sh": "bash",
                ".js": "node",
                ".rb": "ruby",
                ".pl": "perl",
            }
            language = lang_map.get(ext, "bash")
        
        # Check language supported
        if language not in self.LANGUAGES:
            return ExecutorResult.fail(f"Unsupported language: {language}")
        
        # Build command
        lang_config = self.LANGUAGES[language]
        command = lang_config["file_command"] + [path] + args
        
        # Security check the script content
        try:
            with open(path, 'r') as f:
                content = f.read(self.MAX_CODE_SIZE)
            self.check_command_allowed(content)
        except Exception as e:
            return ExecutorResult.fail(f"Cannot read script: {e}")
        
        return await self._run_command(
            command=command,
            timeout=timeout,
            env=env,
            cwd=os.path.dirname(path),
        )
    
    async def _run_command(
        self,
        command: List[str],
        timeout: int,
        env: Optional[Dict[str, str]] = None,
        cwd: Optional[str] = None,
    ) -> ExecutorResult:
        """
        Run a command and capture output.
        
        Args:
            command: Command and arguments
            timeout: Timeout in seconds
            env: Environment variables
            cwd: Working directory
            
        Returns:
            ExecutorResult with command output
        """
        # Prepare environment
        full_env = os.environ.copy()
        if env:
            full_env.update(env)
        
        # Use sandbox directory if no cwd specified
        if not cwd:
            cwd = self._sandbox_dir
        elif not os.path.isabs(cwd):
            cwd = os.path.join(self._workspace, cwd)
        
        # Ensure cwd exists
        os.makedirs(cwd, exist_ok=True)
        
        start_time = datetime.now()
        
        try:
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=cwd,
                env=full_env,
            )
            
            duration = (datetime.now() - start_time).total_seconds() * 1000
            
            # Truncate output if too large
            stdout = result.stdout
            stderr = result.stderr
            
            if len(stdout) > self.MAX_OUTPUT_SIZE:
                stdout = stdout[:self.MAX_OUTPUT_SIZE] + "\n... [output truncated]"
            
            if len(stderr) > self.MAX_OUTPUT_SIZE:
                stderr = stderr[:self.MAX_OUTPUT_SIZE] + "\n... [output truncated]"
            
            return ExecutorResult.ok(
                data={
                    "stdout": stdout,
                    "stderr": stderr,
                    "returncode": result.returncode,
                    "success": result.returncode == 0,
                    "command": " ".join(command[:3]) + ("..." if len(command) > 3 else ""),
                },
                duration_ms=duration,
            )
            
        except subprocess.TimeoutExpired:
            return ExecutorResult.timeout(
                f"Command timed out after {timeout} seconds",
            )
            
        except FileNotFoundError as e:
            return ExecutorResult.fail(
                f"Command not found: {command[0]}",
                error_type="FileNotFoundError",
            )
            
        except PermissionError as e:
            return ExecutorResult.permission_denied(str(e))
            
        except Exception as e:
            return ExecutorResult.fail(
                str(e),
                error_type=type(e).__name__,
            )
    
    def create_temp_script(
        self,
        code: str,
        language: str,
        name: Optional[str] = None,
    ) -> str:
        """
        Create a temporary script file.
        
        Args:
            code: Script content
            language: Script language
            name: Optional script name
            
        Returns:
            Path to temporary script
        """
        if language not in self.LANGUAGES:
            raise ValueError(f"Unsupported language: {language}")
        
        ext = self.LANGUAGES[language]["file_ext"]
        
        if name:
            path = os.path.join(self._sandbox_dir, name + ext)
        else:
            fd, path = tempfile.mkstemp(suffix=ext, dir=self._sandbox_dir)
            os.close(fd)
        
        with open(path, 'w') as f:
            f.write(code)
        
        # Make executable
        os.chmod(path, 0o755)
        
        return path
    
    def cleanup_sandbox(self) -> None:
        """Clean up sandbox directory."""
        if os.path.exists(self._sandbox_dir):
            for item in os.listdir(self._sandbox_dir):
                item_path = os.path.join(self._sandbox_dir, item)
                try:
                    if os.path.isdir(item_path):
                        shutil.rmtree(item_path)
                    else:
                        os.remove(item_path)
                except:
                    pass