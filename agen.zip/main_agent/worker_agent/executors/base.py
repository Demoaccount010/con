"""
Base Executor
=============
Abstract base class for all task executors.

Provides:
- Common interface for execution
- Result structure
- Error handling
- Logging
- Timeout management
"""

import os
import time
import asyncio
import logging
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, Callable, List, Union
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class ExecutorStatus(Enum):
    """Execution status."""
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    TIMEOUT = "TIMEOUT"
    CANCELLED = "CANCELLED"
    PERMISSION_DENIED = "PERMISSION_DENIED"


@dataclass
class ExecutorResult:
    """
    Standardized result from executor.
    
    All executors return this structure.
    """
    status: ExecutorStatus
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    error_type: Optional[str] = None
    duration_ms: float = 0.0
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "status": self.status.value,
            "data": self.data,
            "error": self.error,
            "error_type": self.error_type,
            "duration_ms": round(self.duration_ms, 2),
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }
    
    @property
    def success(self) -> bool:
        """Check if execution was successful."""
        return self.status == ExecutorStatus.SUCCESS
    
    @classmethod
    def ok(cls, data: Dict[str, Any], **kwargs) -> "ExecutorResult":
        """Create success result."""
        return cls(
            status=ExecutorStatus.SUCCESS,
            data=data,
            **kwargs,
        )
    
    @classmethod
    def fail(cls, error: str, error_type: str = "Error", **kwargs) -> "ExecutorResult":
        """Create failure result."""
        return cls(
            status=ExecutorStatus.FAILED,
            error=error,
            error_type=error_type,
            **kwargs,
        )
    
    @classmethod
    def timeout(cls, message: str = "Operation timed out", **kwargs) -> "ExecutorResult":
        """Create timeout result."""
        return cls(
            status=ExecutorStatus.TIMEOUT,
            error=message,
            error_type="TimeoutError",
            **kwargs,
        )
    
    @classmethod
    def permission_denied(cls, message: str, **kwargs) -> "ExecutorResult":
        """Create permission denied result."""
        return cls(
            status=ExecutorStatus.PERMISSION_DENIED,
            error=message,
            error_type="PermissionError",
            **kwargs,
        )


class ExecutorError(Exception):
    """Base exception for executor errors."""
    
    def __init__(self, message: str, error_type: str = "ExecutorError"):
        self.message = message
        self.error_type = error_type
        super().__init__(message)
    
    def to_result(self) -> ExecutorResult:
        """Convert to ExecutorResult."""
        return ExecutorResult.fail(
            error=self.message,
            error_type=self.error_type,
        )


class PermissionDeniedError(ExecutorError):
    """Raised when operation is not permitted."""
    
    def __init__(self, message: str):
        super().__init__(message, "PermissionError")


class ValidationError(ExecutorError):
    """Raised when input validation fails."""
    
    def __init__(self, message: str):
        super().__init__(message, "ValidationError")


class BaseExecutor(ABC):
    """
    Base Executor Class
    ===================
    
    Abstract base for all task executors.
    
    Subclasses must implement:
    - get_actions(): Return list of supported actions
    - execute(action, params): Execute an action
    
    Usage:
        class MyExecutor(BaseExecutor):
            def get_actions(self):
                return ["my_action"]
            
            async def execute(self, action, params):
                if action == "my_action":
                    return await self._do_my_action(params)
    """
    
    def __init__(self, config: Any, logger: Optional[logging.Logger] = None):
        """
        Initialize executor.
        
        Args:
            config: WorkerConfig instance
            logger: Optional logger
        """
        self.config = config
        self.logger = logger or logging.getLogger(self.__class__.__name__)
        self._action_handlers: Dict[str, Callable] = {}
    
    @abstractmethod
    def get_actions(self) -> List[str]:
        """
        Get list of supported actions.
        
        Returns:
            List of action names
        """
        pass
    
    @abstractmethod
    async def execute(
        self,
        action: str,
        params: Dict[str, Any],
    ) -> ExecutorResult:
        """
        Execute an action.
        
        Args:
            action: Action name
            params: Action parameters
            
        Returns:
            ExecutorResult
        """
        pass
    
    def register_action(self, action: str, handler: Callable):
        """
        Register an action handler.
        
        Args:
            action: Action name
            handler: Handler function
        """
        self._action_handlers[action] = handler
    
    def validate_required(
        self,
        params: Dict[str, Any],
        required: List[str],
    ) -> None:
        """
        Validate required parameters.
        
        Args:
            params: Parameters dict
            required: List of required parameter names
            
        Raises:
            ValidationError: If required parameter missing
        """
        for key in required:
            if key not in params or params[key] is None:
                raise ValidationError(f"Missing required parameter: {key}")
    
    def check_path_allowed(self, path: str) -> None:
        """
        Check if path is allowed.
        
        Args:
            path: File path to check
            
        Raises:
            PermissionDeniedError: If path not allowed
        """
        if hasattr(self.config, 'is_path_allowed'):
            if not self.config.is_path_allowed(path):
                raise PermissionDeniedError(f"Path not allowed: {path}")
    
    def check_command_allowed(self, command: str) -> None:
        """
        Check if command is allowed.
        
        Args:
            command: Command to check
            
        Raises:
            PermissionDeniedError: If command not allowed
        """
        if hasattr(self.config, 'is_command_allowed'):
            if not self.config.is_command_allowed(command):
                raise PermissionDeniedError(f"Command not allowed: {command}")
    
    async def run_with_timeout(
        self,
        coro,
        timeout: Optional[int] = None,
    ) -> Any:
        """
        Run coroutine with timeout.
        
        Args:
            coro: Coroutine to run
            timeout: Timeout in seconds
            
        Returns:
            Coroutine result
            
        Raises:
            asyncio.TimeoutError: If timeout exceeded
        """
        timeout = timeout or getattr(self.config, 'task_timeout', 300)
        return await asyncio.wait_for(coro, timeout=timeout)
    
    def measure_time(self, func: Callable) -> Callable:
        """
        Decorator to measure execution time.
        
        Args:
            func: Function to wrap
            
        Returns:
            Wrapped function that includes duration in result
        """
        async def wrapper(*args, **kwargs) -> ExecutorResult:
            start = time.time()
            try:
                result = await func(*args, **kwargs)
                if isinstance(result, ExecutorResult):
                    result.duration_ms = (time.time() - start) * 1000
                return result
            except Exception as e:
                return ExecutorResult.fail(
                    error=str(e),
                    error_type=type(e).__name__,
                    duration_ms=(time.time() - start) * 1000,
                )
        return wrapper


class ExecutorRegistry:
    """
    Registry for task executors.
    
    Manages mapping of action names to executor functions.
    
    Usage:
        registry = ExecutorRegistry()
        registry.register("my_action", my_executor.execute)
        
        result = await registry.execute("my_action", {"param": "value"})
    """
    
    def __init__(self):
        """Initialize registry."""
        self._executors: Dict[str, Callable] = {}
        self._metadata: Dict[str, Dict[str, Any]] = {}
    
    def register(
        self,
        action: str,
        executor: Callable,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Register an executor for an action.
        
        Args:
            action: Action name
            executor: Executor function (async or sync)
            metadata: Optional metadata about the action
        """
        self._executors[action] = executor
        self._metadata[action] = metadata or {}
    
    def unregister(self, action: str) -> bool:
        """
        Unregister an action.
        
        Args:
            action: Action name
            
        Returns:
            True if action was registered
        """
        if action in self._executors:
            del self._executors[action]
            del self._metadata[action]
            return True
        return False
    
    def get(self, action: str) -> Optional[Callable]:
        """
        Get executor for action.
        
        Args:
            action: Action name
            
        Returns:
            Executor function or None
        """
        return self._executors.get(action)
    
    def has(self, action: str) -> bool:
        """Check if action is registered."""
        return action in self._executors
    
    def list_actions(self) -> List[str]:
        """Get list of registered actions."""
        return list(self._executors.keys())
    
    def get_metadata(self, action: str) -> Dict[str, Any]:
        """Get metadata for an action."""
        return self._metadata.get(action, {})
    
    async def execute(
        self,
        action: str,
        params: Dict[str, Any],
    ) -> ExecutorResult:
        """
        Execute an action.
        
        Args:
            action: Action name
            params: Action parameters
            
        Returns:
            ExecutorResult
        """
        executor = self._executors.get(action)
        
        if not executor:
            return ExecutorResult.fail(
                error=f"Unknown action: {action}",
                error_type="ActionNotFound",
                metadata={"available_actions": self.list_actions()},
            )
        
        start = time.time()
        
        try:
            # Call executor
            if asyncio.iscoroutinefunction(executor):
                result = await executor(params)
            else:
                result = executor(params)
            
            duration = (time.time() - start) * 1000
            
            # Wrap result if needed
            if isinstance(result, ExecutorResult):
                result.duration_ms = duration
                return result
            elif isinstance(result, dict):
                return ExecutorResult.ok(result, duration_ms=duration)
            else:
                return ExecutorResult.ok(
                    {"result": result},
                    duration_ms=duration,
                )
                
        except ExecutorError as e:
            return e.to_result()
            
        except asyncio.TimeoutError:
            return ExecutorResult.timeout()
            
        except PermissionError as e:
            return ExecutorResult.permission_denied(str(e))
            
        except Exception as e:
            return ExecutorResult.fail(
                error=str(e),
                error_type=type(e).__name__,
                duration_ms=(time.time() - start) * 1000,
            )
    
    def __contains__(self, action: str) -> bool:
        return action in self._executors
    
    def __len__(self) -> int:
        return len(self._executors)