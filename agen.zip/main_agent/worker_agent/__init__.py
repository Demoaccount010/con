"""
Worker Agent Package
====================
Executes tasks received from Main Agent.

This runs on remote VPS machines and:
- Exposes REST API for task execution
- Registers with Main Agent
- Executes various task types
- Reports results back

This is NOT the brain - this is the MUSCLE.
Workers don't think, they execute.

Usage:
    python -m worker_agent.main
    python -m worker_agent.main --port 8001
    python -m worker_agent.main --register http://main-agent:8000
"""

__version__ = "1.0.0"
__author__ = "AI Systems Architect"
__type__ = "WORKER"

from worker_agent.config import WorkerConfig, load_worker_config
from worker_agent.api.server import WorkerServer

__all__ = [
    "WorkerConfig",
    "load_worker_config",
    "WorkerServer",
    "__version__",
]