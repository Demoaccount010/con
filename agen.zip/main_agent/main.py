#!/usr/bin/env python3
"""
Main Agent Entry Point
======================
Primary entry point for the Main AI Agent.

Modes:
- Interactive CLI: python -m main_agent.main
- With Telegram: python -m main_agent.main --telegram
- Status only: python -m main_agent.main --status
- Reconfigure: python -m main_agent.main --telegram --setup

The bot will automatically run setup wizard on first run.
"""

import sys
import argparse
from typing import Optional

from main_agent.config import Config, ConfigValidationError
from main_agent.core.agent import MainAgent, AgentState
from main_agent.core.errors import (
    AgentError,
    StartupError,
    format_error_response,
    ErrorCategory,
    ErrorSeverity,
)
from main_agent.utils.logger import get_logger, Logger


# Exit codes
EXIT_SUCCESS = 0
EXIT_CONFIG_ERROR = 1
EXIT_STARTUP_ERROR = 2
EXIT_RUNTIME_ERROR = 3
EXIT_UNKNOWN_ERROR = 4


def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Main AI Agent - Intelligent Task Planner & Executor",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    python -m main_agent.main                     # Interactive CLI mode
    python -m main_agent.main --telegram          # Run with Telegram bot
    python -m main_agent.main --telegram --setup  # Force reconfigure
    python -m main_agent.main --status            # Show status only
        """
    )
    
    parser.add_argument(
        "--telegram", "-t",
        action="store_true",
        help="Run with Telegram bot"
    )
    
    parser.add_argument(
        "--setup", "-s",
        action="store_true",
        help="Force run setup wizard (with --telegram)"
    )
    
    parser.add_argument(
        "--status",
        action="store_true",
        help="Show agent status and exit"
    )
    
    parser.add_argument(
        "--debug", "-d",
        action="store_true",
        help="Enable debug logging"
    )
    
    parser.add_argument(
        "--config",
        type=str,
        help="Path to config directory"
    )
    
    return parser.parse_args()


def print_banner():
    """Print welcome banner."""
    banner = """
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║     ███╗   ███╗ █████╗ ██╗███╗   ██╗                        ║
║     ████╗ ████║██╔══██╗██║████╗  ██║                        ║
║     ██╔████╔██║███████║██║██╔██╗ ██║                        ║
║     ██║╚██╔╝██║██╔══██║██║██║╚██╗██║                        ║
║     ██║ ╚═╝ ██║██║  ██║██║██║ ╚████║                        ║
║     ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝                        ║
║                                                              ║
║          █████╗ ██╗      █████╗  ██████╗ ███████╗███╗   ██╗ ║
║         ██╔══██╗██║     ██╔══██╗██╔════╝ ██╔════╝████╗  ██║ ║
║         ███████║██║     ███████║██║  ███╗█████╗  ██╔██╗ ██║ ║
║         ██╔══██║██║     ██╔══██║██║   ██║██╔══╝  ██║╚██╗██║ ║
║         ██║  ██║██║     ██║  ██║╚██████╔╝███████╗██║ ╚████║ ║
║         ╚═╝  ╚═╝╚═╝     ╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝  ╚═══╝ ║
║                                                              ║
║            🤖 Intelligent Task Planning System 🤖            ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
    """
    print(banner)


def initialize_agent(debug: bool = False) -> tuple:
    """
    Initialize configuration and agent.
    
    Returns:
        Tuple of (agent, logger)
    """
    # Load config
    config = Config()
    config.load()
    
    if debug:
        config.logging.level = "DEBUG"
    
    config.validate()
    
    # Create logger
    logger = get_logger(
        name=config.agent.name,
        level=config.logging.level,
        log_dir=config.logging.log_dir,
        log_file=config.logging.log_file,
        console_output=config.logging.console_output,
        file_output=config.logging.file_output,
    )
    
    # Create and start agent
    logger.info("Creating Main Agent...")
    agent = MainAgent(config=config, logger=logger)
    
    logger.info("Starting Main Agent...")
    agent.start()
    
    return agent, logger


def run_with_telegram(args) -> int:
    """
    Run agent with Telegram bot.
    
    Automatically runs setup wizard if no config exists.
    """
    from main_agent.telegram.setup import (
        SetupWizard,
        ensure_setup,
        print_banner as setup_banner,
    )
    from main_agent.telegram.bot import TelegramBot
    from main_agent.storage.config_store import (
        config_exists,
        load_config,
        delete_config,
    )
    
    # Force setup if --setup flag
    if args.setup and config_exists():
        print("\n⚠️  Reconfiguring bot...\n")
        delete_config()
    
    # Run setup wizard (will load existing config if valid)
    bot_settings = ensure_setup()
    
    # Initialize agent
    print("\n⏳ Starting Main Agent...\n")
    
    try:
        agent, logger = initialize_agent(debug=args.debug)
    except Exception as e:
        print(f"\n❌ Failed to start agent: {e}")
        return EXIT_STARTUP_ERROR
    
    # Update Ollama settings from bot config if needed
    if bot_settings.ollama_host:
        agent.config.ollama.host = bot_settings.ollama_host
    if bot_settings.ollama_port:
        agent.config.ollama.port = bot_settings.ollama_port
    
    # Create and run bot
    try:
        bot = TelegramBot(
            agent=agent,
            settings=bot_settings,
            logger=logger,
        )
        
        logger.info("Starting Telegram bot...")
        bot.run()  # Blocking
        
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except Exception as e:
        logger.error(f"Bot error: {e}")
        return EXIT_RUNTIME_ERROR
    finally:
        if agent.is_running:
            agent.stop()
    
    return EXIT_SUCCESS


def run_interactive(agent: MainAgent, logger: Logger) -> int:
    """Run interactive CLI mode."""
    from main_agent.telegram.keyboards import KeyboardBuilder
    
    print_banner()
    
    print("""
╔══════════════════════════════════════════════════════════════╗
║                        COMMANDS                              ║
╠══════════════════════════════════════════════════════════════╣
║  Type any task description to create a plan                  ║
║                                                              ║
║  Special commands:                                           ║
║    /help     - Show help                                     ║
║    /status   - Show agent status                             ║
║    /model    - Show current model                            ║
║    /quit     - Exit                                          ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝

✅ Agent is ready! Type a task or /help for commands.
""")
    
    try:
        while True:
            try:
                user_input = input("\n🤖 Enter task > ").strip()
                
                if not user_input:
                    continue
                
                # Handle commands
                if user_input.lower() in ("/quit", "/exit", "/q"):
                    print("\n👋 Goodbye!")
                    break
                
                elif user_input.lower() == "/help":
                    print("""
Commands:
  /status - Show agent status
  /model  - Show current model
  /quit   - Exit

Or just type a task description to create a plan.
""")
                    continue
                
                elif user_input.lower() == "/status":
                    status = agent.get_status()
                    print(f"""
📊 Status:
  State: {status['agent']['state']}
  Model: {status['components']['ollama']['model'] if status['components'].get('ollama') else 'N/A'}
  Ready: {'✅' if status['agent']['is_ready'] else '❌'}
""")
                    continue
                
                elif user_input.lower() == "/model":
                    if agent.selected_model:
                        print(f"""
🦙 Model: {agent.selected_model.name}
  Size: {agent.selected_model.size_gb:.1f} GB
  Safety: {agent.selected_model.safety_level.value}
""")
                    else:
                        print("❌ No model selected")
                    continue
                
                # Process as task
                print("\n🔄 Planning task...")
                
                task = agent.plan_task(user_input)
                
                print(f"""
✅ PLAN CREATED
{'=' * 50}
📎 Goal: {task.goal}
📂 Type: {task.task_type.value}
📊 Confidence: {int(task.confidence * 100)}%

📝 Steps:""")
                
                for i, step in enumerate(task.steps, 1):
                    print(f"   {i}. {step.name}")
                
                print(f"""
📄 JSON:
{task.to_json()}
{'=' * 50}
""")
                
            except EOFError:
                print("\n👋 Goodbye!")
                break
                
    except KeyboardInterrupt:
        print("\n\n⚠️ Interrupted by user")
    
    return EXIT_SUCCESS


def show_status(agent: MainAgent) -> int:
    """Show agent status and exit."""
    status = agent.get_status()
    
    print(f"""
╔══════════════════════════════════════════════════════════════╗
║                      AGENT STATUS                            ║
╚══════════════════════════════════════════════════════════════╝

🤖 Agent:
   Name:    {status['agent']['name']}
   Version: {status['agent']['version']}
   State:   {status['agent']['state']}
   Ready:   {'✅ Yes' if status['agent']['is_ready'] else '❌ No'}
""")
    
    if status['system']:
        mem = status['system'].get('memory', {})
        print(f"""💻 System:
   OS:    {status['system']['os']['type']}
   CPU:   {status['system']['cpu']['cores']} cores
   RAM:   {mem.get('available_gb', 0):.1f}GB / {mem.get('total_gb', 0):.1f}GB
""")
    
    if status['components'].get('ollama'):
        ollama = status['components']['ollama']
        print(f"""🦙 Ollama:
   Status: {'✅ Healthy' if ollama.get('healthy') else '❌ Unhealthy'}
   Model:  {ollama.get('model', 'N/A')}
   Safety: {ollama.get('model_safety', 'N/A')}
""")
    
    return EXIT_SUCCESS


def main() -> int:
    """Main entry point."""
    args = parse_arguments()
    
    agent: Optional[MainAgent] = None
    logger: Optional[Logger] = None
    
    try:
        # Telegram mode
        if args.telegram:
            return run_with_telegram(args)
        
        # Initialize agent for other modes
        print("⏳ Starting Main Agent...")
        agent, logger = initialize_agent(debug=args.debug)
        
        # Status mode
        if args.status:
            return show_status(agent)
        
        # Interactive mode (default)
        return run_interactive(agent, logger)
        
    except ConfigValidationError as e:
        print(f"❌ Configuration Error: {e}", file=sys.stderr)
        return EXIT_CONFIG_ERROR
        
    except StartupError as e:
        print(f"❌ Startup Error: {e}", file=sys.stderr)
        return EXIT_STARTUP_ERROR
        
    except AgentError as e:
        print(f"❌ Agent Error: {e}", file=sys.stderr)
        return EXIT_RUNTIME_ERROR
        
    except KeyboardInterrupt:
        print("\n\n⚠️ Interrupted by user")
        return EXIT_SUCCESS
        
    except Exception as e:
        print(f"❌ Unexpected Error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return EXIT_UNKNOWN_ERROR
        
    finally:
        if agent and agent.is_running:
            agent.stop()
        if logger:
            logger.info("Main Agent process ended")


if __name__ == "__main__":
    sys.exit(main())