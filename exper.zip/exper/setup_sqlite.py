import asyncio
from app.core.database import init_db, async_session_maker
from app.models.plan import Plan
from sqlalchemy import select

async def setup():
    print("🚀 Initializing SQLite database...")
    await init_db()
    
    async with async_session_maker() as session:
        # Check if plans already exist
        result = await session.execute(select(Plan))
        if result.scalars().first():
            print("✅ Plans already exist, skipping seeding.")
            return

        print("🌱 Seeding default plans...")
        plans = [
            Plan(
                name="free",
                display_name="Free Plan",
                description="Perfect for small bots and testing.",
                price=0.00,
                duration_days=3650,
                max_deployments=1,
                ram_limit_mb=512,
                cpu_limit=0.5,
                storage_limit_mb=1024,
                custom_domain=False,
                is_active=True,
                sort_order=1
            ),
            Plan(
                name="starter",
                display_name="Starter",
                description="Small projects and hobby bots.",
                price=199.00,
                duration_days=30,
                max_deployments=3,
                ram_limit_mb=1024,
                cpu_limit=1.0,
                storage_limit_mb=2048,
                custom_domain=False,
                is_active=True,
                sort_order=2
            ),
            Plan(
                name="pro",
                display_name="Pro",
                description="Serious bots with high traffic.",
                price=499.00,
                duration_days=30,
                max_deployments=10,
                ram_limit_mb=2048,
                cpu_limit=2.0,
                storage_limit_mb=5120,
                custom_domain=True,
                is_active=True,
                sort_order=3
            ),
            Plan(
                name="enterprise",
                display_name="Enterprise",
                description="Maximum performance and scale.",
                price=1499.00,
                duration_days=30,
                max_deployments=50,
                ram_limit_mb=8192,
                cpu_limit=4.0,
                storage_limit_mb=20480,
                custom_domain=True,
                is_active=True,
                sort_order=4
            )
        ]
        
        session.add_all(plans)
        await session.commit()
        print("✅ SQLite database setup complete with default plans!")

if __name__ == "__main__":
    asyncio.run(setup())
