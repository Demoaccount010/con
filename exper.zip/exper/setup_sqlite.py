import asyncio
from app.core.database import init_db, async_session_maker
from app.models.plan import Plan
from app.models.vps_node import VPSNode
from sqlalchemy import select

async def setup():
    print("🚀 Initializing SQLite database...")
    await init_db()
    
    async with async_session_maker() as session:
        # 1. Seed Plans
        result = await session.execute(select(Plan))
        if not result.scalars().first():
            print("🌱 Seeding default plans...")
            plans = [
                Plan(
                    name="free",
                    display_name="Free Plan",
                    description="Perfect for small bots and testing.",
                    price=0.00,
                    duration_days=3650,
                    max_deployments=1,
                    ram_limit_mb=512,
                    cpu_limit=0.5,
                    storage_limit_mb=1024,
                    custom_domain=False,
                    is_active=True,
                    sort_order=1
                ),
                Plan(
                    name="starter",
                    display_name="Starter",
                    description="Small projects and hobby bots.",
                    price=199.00,
                    duration_days=30,
                    max_deployments=3,
                    ram_limit_mb=1024,
                    cpu_limit=1.0,
                    storage_limit_mb=2048,
                    custom_domain=False,
                    is_active=True,
                    sort_order=2
                ),
                Plan(
                    name="pro",
                    display_name="Pro",
                    description="Serious bots with high traffic.",
                    price=499.00,
                    duration_days=30,
                    max_deployments=10,
                    ram_limit_mb=2048,
                    cpu_limit=2.0,
                    storage_limit_mb=5120,
                    custom_domain=True,
                    is_active=True,
                    sort_order=3
                ),
                Plan(
                    name="enterprise",
                    display_name="Enterprise",
                    description="Maximum performance and scale.",
                    price=1499.00,
                    duration_days=30,
                    max_deployments=50,
                    ram_limit_mb=8192,
                    cpu_limit=4.0,
                    storage_limit_mb=20480,
                    custom_domain=True,
                    is_active=True,
                    sort_order=4
                )
            ]
            session.add_all(plans)
            print("✅ Plans seeded.")
        else:
            print("ℹ️ Plans already exist.")

        # 2. Seed Default VPS Node
        node_result = await session.execute(select(VPSNode).where(VPSNode.name == "vps-agent-1"))
        if not node_result.scalars().first():
            print("🌱 Seeding default VPS node...")
            default_node = VPSNode(
                name="vps-agent-1",
                host="127.0.0.1",
                agent_secret="your-super-secret-agent-key-123",  # Match this in agent .env
                is_enabled=True,
                is_online=False,
                max_containers=20,
                priority=100
            )
            session.add(default_node)
            print("✅ Default VPS node seeded.")
        else:
            print("ℹ️ Default VPS node already exists.")
            
        await session.commit()
        print("\n✨ SQLite database setup complete!")

if __name__ == "__main__":
    asyncio.run(setup())
