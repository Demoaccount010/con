import asyncio
import os
from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine
from dotenv import load_dotenv

async def run_fix(engine, table, fix_sql, name):
    try:
        async with engine.begin() as conn:
            await conn.execute(text(f"ALTER TABLE {table} {fix_sql}"))
            print(f"✅ Checked {name} in {table}")
    except Exception as e:
        # Ignore errors where column already exists or similar
        if "already exists" in str(e).lower():
            print(f"✅ {name} already exists in {table}")
        else:
            print(f"⚠️ Error with {name} in {table}: {e}")

async def patch_db():
    load_dotenv()
    db_url = os.getenv("DATABASE_URL")
    if not db_url:
        print("❌ DATABASE_URL not found in .env")
        return

    print(f"Connecting to database...")
    engine = create_async_engine(db_url)
    
    # --- USERS TABLE ---
    print("\n[1/4] Checking users table...")
    user_fixes = [
        ("ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT TRUE", "is_active"),
        ("ADD COLUMN IF NOT EXISTS is_admin BOOLEAN DEFAULT FALSE", "is_admin"),
        ("ADD COLUMN IF NOT EXISTS is_banned BOOLEAN DEFAULT FALSE", "is_banned"),
        ("ALTER COLUMN first_name TYPE VARCHAR(255)", "first_name_type"),
        ("ALTER COLUMN last_name TYPE VARCHAR(255)", "last_name_type"),
        ("ALTER COLUMN username TYPE VARCHAR(255)", "username_type"),
    ]
    for fix_sql, name in user_fixes:
        await run_fix(engine, "users", fix_sql, name)

    # Rename last_activity_at -> last_active_at
    try:
        async with engine.begin() as conn:
            await conn.execute(text("ALTER TABLE users RENAME COLUMN last_activity_at TO last_active_at"))
            print("✅ Renamed users.last_activity_at -> last_active_at")
    except Exception:
        await run_fix(engine, "users", "ADD COLUMN IF NOT EXISTS last_active_at TIMESTAMP WITHOUT TIME ZONE", "last_active_at")

    # --- PLANS TABLE ---
    print("\n[2/4] Checking plans table...")
    plan_fixes = [
        ("ADD COLUMN IF NOT EXISTS price_yearly NUMERIC(10, 2)", "price_yearly"),
        ("ADD COLUMN IF NOT EXISTS auto_deploy BOOLEAN DEFAULT FALSE", "auto_deploy"),
        ("ADD COLUMN IF NOT EXISTS analytics BOOLEAN DEFAULT FALSE", "analytics"),
        ("ALTER COLUMN created_at DROP NOT NULL", "created_at_null"),
        ("ALTER COLUMN created_at TYPE TIMESTAMP WITHOUT TIME ZONE", "created_at_type"),
    ]
    for fix_sql, name in plan_fixes:
        await run_fix(engine, "plans", fix_sql, name)

    # --- VPS_NODES TABLE ---
    print("\n[3/4] Checking vps_nodes table...")
    vps_fixes = [
        ("ADD COLUMN IF NOT EXISTS description TEXT", "description"),
        ("ADD COLUMN IF NOT EXISTS port INTEGER DEFAULT 22", "port"),
        ("ADD COLUMN IF NOT EXISTS ssh_user VARCHAR(100) DEFAULT 'root'", "ssh_user"),
        ("ADD COLUMN IF NOT EXISTS ssh_key_path VARCHAR(500)", "ssh_key_path"),
        ("ADD COLUMN IF NOT EXISTS total_ram_mb INTEGER DEFAULT 0", "total_ram_mb"),
        ("ADD COLUMN IF NOT EXISTS free_ram_mb INTEGER DEFAULT 0", "free_ram_mb"),
        ("ADD COLUMN IF NOT EXISTS total_disk_gb INTEGER DEFAULT 0", "total_disk_gb"),
        ("ADD COLUMN IF NOT EXISTS free_disk_gb INTEGER DEFAULT 0", "free_disk_gb"),
        ("ADD COLUMN IF NOT EXISTS cpu_cores INTEGER DEFAULT 1", "cpu_cores"),
        ("ADD COLUMN IF NOT EXISTS cpu_usage_percent FLOAT DEFAULT 0.0", "cpu_usage_percent"),
        ("ADD COLUMN IF NOT EXISTS region VARCHAR(50)", "region"),
        ("ADD COLUMN IF NOT EXISTS country VARCHAR(50)", "country"),
        ("ADD COLUMN IF NOT EXISTS priority INTEGER DEFAULT 0", "priority"),
    ]
    for fix_sql, name in vps_fixes:
        await run_fix(engine, "vps_nodes", fix_sql, name)

    # Rename os_info type if needed
    await run_fix(engine, "vps_nodes", "ALTER COLUMN os_info TYPE VARCHAR(200)", "os_info_type")

    # --- DEPLOYMENTS TABLE ---
    print("\n[4/6] Checking deployments table...")
    deployment_fixes = [
        ("ADD COLUMN IF NOT EXISTS detected_env_vars JSON", "detected_env_vars"),
        ("ADD COLUMN IF NOT EXISTS pids_limit INTEGER DEFAULT 100", "pids_limit"),
        ("ADD COLUMN IF NOT EXISTS storage_used INTEGER DEFAULT 0", "storage_used"),
        ("ADD COLUMN IF NOT EXISTS internal_port INTEGER", "internal_port"),
        ("ADD COLUMN IF NOT EXISTS external_port INTEGER", "external_port"),
        ("ADD COLUMN IF NOT EXISTS github_webhook_id VARCHAR(100)", "github_webhook_id"),
        ("ADD COLUMN IF NOT EXISTS last_restart_at TIMESTAMP WITHOUT TIME ZONE", "last_restart_at"),
        ("ADD COLUMN IF NOT EXISTS is_healthy BOOLEAN DEFAULT TRUE", "is_healthy"),
        ("ADD COLUMN IF NOT EXISTS idle_shutdown_enabled BOOLEAN DEFAULT TRUE", "idle_shutdown_enabled"),
        ("ADD COLUMN IF NOT EXISTS auto_deploy BOOLEAN DEFAULT FALSE", "auto_deploy"),
        ("ADD COLUMN IF NOT EXISTS started_at TIMESTAMP WITHOUT TIME ZONE", "started_at"),
        ("ADD COLUMN IF NOT EXISTS stopped_at TIMESTAMP WITHOUT TIME ZONE", "stopped_at"),
    ]
    for fix_sql, name in deployment_fixes:
        await run_fix(engine, "deployments", fix_sql, name)

    # --- PAYMENTS TABLE ---
    print("\n[5/6] Checking payments table...")
    payment_fixes = [
        ("ADD COLUMN IF NOT EXISTS payment_link_id VARCHAR(100)", "payment_link_id"),
        ("ADD COLUMN IF NOT EXISTS payment_link_url VARCHAR(500)", "payment_link_url"),
        ("ADD COLUMN IF NOT EXISTS status_message TEXT", "status_message"),
        ("ADD COLUMN IF NOT EXISTS plan_id INTEGER", "plan_id"),
        ("ADD COLUMN IF NOT EXISTS plan_name VARCHAR(100)", "plan_name"),
        ("ADD COLUMN IF NOT EXISTS description TEXT", "description"),
        ("ADD COLUMN IF NOT EXISTS completed_at TIMESTAMP WITHOUT TIME ZONE", "completed_at"),
    ]
    for fix_sql, name in payment_fixes:
        await run_fix(engine, "payments", fix_sql, name)

    # --- SUBSCRIPTIONS TABLE ---
    print("\n[6/6] Checking subscriptions table...")
    subscription_fixes = [
        ("ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT TRUE", "is_active"),
        ("ADD COLUMN IF NOT EXISTS auto_renew BOOLEAN DEFAULT TRUE", "auto_renew"),
        ("ADD COLUMN IF NOT EXISTS started_at TIMESTAMP WITHOUT TIME ZONE DEFAULT NOW()", "started_at"),
        ("ADD COLUMN IF NOT EXISTS expires_at TIMESTAMP WITHOUT TIME ZONE", "expires_at"),
        ("ADD COLUMN IF NOT EXISTS cancelled_at TIMESTAMP WITHOUT TIME ZONE", "cancelled_at"),
    ]
    for fix_sql, name in subscription_fixes:
        await run_fix(engine, "subscriptions", fix_sql, name)

    print("\n🚀 Database synchronization complete!")
    print("Please restart your API and Bot now.")
    await engine.dispose()

if __name__ == "__main__":
    asyncio.run(patch_db())
