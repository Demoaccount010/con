import asyncio
import os
from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine
from dotenv import load_dotenv

async def patch_db():
    load_dotenv()
    db_url = os.getenv("DATABASE_URL")
    if not db_url:
        print("❌ DATABASE_URL not found in .env")
        return

    print(f"Connecting to database...")
    engine = create_async_engine(db_url)
    
    async with engine.begin() as conn:
        print("Checking users table...")
        # Add is_active if missing
        try:
            await conn.execute(text("ALTER TABLE users ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT TRUE"))
            print("✅ Added/Checked is_active in users")
        except Exception as e:
            print(f"⚠️ Error with is_active: {e}")

        # Rename last_activity_at to last_active_at if needed
        try:
            # Check if last_activity_at exists and last_active_at does not
            await conn.execute(text("ALTER TABLE users RENAME COLUMN last_activity_at TO last_active_at"))
            print("✅ Renamed last_activity_at to last_active_at")
        except Exception:
            # If rename fails (column already renamed or doesn't exist), check if it exists or add it
            try:
                await conn.execute(text("ALTER TABLE users ADD COLUMN IF NOT EXISTS last_active_at TIMESTAMP WITHOUT TIME ZONE"))
                print("✅ Checked last_active_at in users")
            except Exception as e:
                print(f"⚠️ Error with last_active_at: {e}")

        # Fix VPS Nodes table
        print("Checking vps_nodes table...")
        vps_fixes = [
            ("ADD COLUMN IF NOT EXISTS description TEXT", "description"),
            ("ADD COLUMN IF NOT EXISTS port INTEGER DEFAULT 22", "port"),
            ("ADD COLUMN IF NOT EXISTS ssh_user VARCHAR(100) DEFAULT 'root'", "ssh_user"),
            ("ADD COLUMN IF NOT EXISTS ssh_key_path VARCHAR(500)", "ssh_key_path"),
            ("ADD COLUMN IF NOT EXISTS total_ram_mb INTEGER DEFAULT 0", "total_ram_mb"),
            ("ADD COLUMN IF NOT EXISTS free_ram_mb INTEGER DEFAULT 0", "free_ram_mb"),
            ("ADD COLUMN IF NOT EXISTS total_disk_gb INTEGER DEFAULT 0", "total_disk_gb"),
            ("ADD COLUMN IF NOT EXISTS free_disk_gb INTEGER DEFAULT 0", "free_disk_gb"),
            ("ADD COLUMN IF NOT EXISTS cpu_cores INTEGER DEFAULT 1", "cpu_cores"),
            ("ADD COLUMN IF NOT EXISTS cpu_usage_percent FLOAT DEFAULT 0.0", "cpu_usage_percent"),
            ("ADD COLUMN IF NOT EXISTS region VARCHAR(50)", "region"),
            ("ADD COLUMN IF NOT EXISTS country VARCHAR(50)", "country"),
            ("ADD COLUMN IF NOT EXISTS priority INTEGER DEFAULT 0", "priority"),
        ]
        
        for fix_sql, name in vps_fixes:
            try:
                await conn.execute(text(f"ALTER TABLE vps_nodes {fix_sql}"))
                print(f"✅ Checked {name} in vps_nodes")
            except Exception as e:
                print(f"⚠️ Error with {name}: {e}")

        # Fix Deployments table
        print("Checking deployments table...")
        deployment_fixes = [
            ("ADD COLUMN IF NOT EXISTS detected_env_vars JSON", "detected_env_vars"),
            ("ADD COLUMN IF NOT EXISTS pids_limit INTEGER DEFAULT 100", "pids_limit"),
            ("ADD COLUMN IF NOT EXISTS storage_used INTEGER DEFAULT 0", "storage_used"),
            ("ADD COLUMN IF NOT EXISTS internal_port INTEGER", "internal_port"),
            ("ADD COLUMN IF NOT EXISTS external_port INTEGER", "external_port"),
            ("ADD COLUMN IF NOT EXISTS github_webhook_id VARCHAR(100)", "github_webhook_id"),
            ("ADD COLUMN IF NOT EXISTS last_restart_at TIMESTAMP WITHOUT TIME ZONE", "last_restart_at"),
            ("ADD COLUMN IF NOT EXISTS is_healthy BOOLEAN DEFAULT TRUE", "is_healthy"),
            ("ADD COLUMN IF NOT EXISTS idle_shutdown_enabled BOOLEAN DEFAULT TRUE", "idle_shutdown_enabled"),
        ]

        for fix_sql, name in deployment_fixes:
            try:
                await conn.execute(text(f"ALTER TABLE deployments {fix_sql}"))
                print(f"   Checked {name} in deployments")
            except Exception as e:
                print(f"   ⚠️ Error with {name}: {e}")

    print("\nDatabase synchronization complete!")
    print("You can now restart your API and Bot.")
    await engine.dispose()

if __name__ == "__main__":
    asyncio.run(patch_db())
