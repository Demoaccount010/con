#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                           SMILE AI AGENT OS v1.0                             ║
║                    Self-evolving Modular Intelligence Layer Engine           ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Author: Dynamic (Set by Owner)                                              ║
║  Purpose: Autonomous AI Agent with Self-Evolution Capabilities               ║
║  License: MIT                                                                ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import sys
import json
import asyncio
import logging
import hashlib
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field, asdict
from enum import Enum, auto
import importlib
import traceback

# ═══════════════════════════════════════════════════════════════════════════════
# SYSTEM CONSTANTS AND CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

VERSION = "1.0.0"
AGENT_NAME = "Smile"
BUILD_DATE = datetime.now().isoformat()

# Directory Structure
BASE_DIR = Path(__file__).parent.absolute()
CORE_DIR = BASE_DIR / "core"
PLUGINS_DIR = BASE_DIR / "plugins"
MEMORY_DIR = BASE_DIR / "memory"
CONFIG_DIR = BASE_DIR / "config"
TOOLS_DIR = BASE_DIR / "tools"
SANDBOX_DIR = BASE_DIR / "sandbox"
LOGS_DIR = BASE_DIR / "logs"
BACKUPS_DIR = BASE_DIR / "backups"

# Ensure all directories exist
for directory in [CORE_DIR, PLUGINS_DIR, MEMORY_DIR, CONFIG_DIR, 
                  TOOLS_DIR, SANDBOX_DIR, LOGS_DIR, BACKUPS_DIR]:
    directory.mkdir(parents=True, exist_ok=True)

# ═══════════════════════════════════════════════════════════════════════════════
# LOGGING CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)-8s | %(name)-20s | %(message)s',
    handlers=[
        logging.FileHandler(LOGS_DIR / f"smile_{datetime.now().strftime('%Y%m%d')}.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("SMILE.Main")

# ═══════════════════════════════════════════════════════════════════════════════
# ENUMS AND DATA CLASSES
# ═══════════════════════════════════════════════════════════════════════════════

class AgentState(Enum):
    """Current operational state of the agent"""
    INITIALIZING = auto()
    FIRST_RUN_SETUP = auto()
    LOADING = auto()
    READY = auto()
    THINKING = auto()
    EXECUTING = auto()
    UPGRADING = auto()
    ERROR = auto()
    SHUTTING_DOWN = auto()

class TaskComplexity(Enum):
    """Task complexity levels for routing decisions"""
    SIMPLE = "simple"           # Rule-based, instant
    MEDIUM = "medium"           # Tool-based, structured
    COMPLEX = "complex"         # Deep reasoning required
    UNKNOWN = "unknown"         # Needs analysis

class ConfidenceLevel(Enum):
    """Agent's confidence in its response/action"""
    CERTAIN = 0.9
    HIGH = 0.75
    MEDIUM = 0.5
    LOW = 0.25
    UNCERTAIN = 0.1

@dataclass
class OwnerProfile:
    """Owner identity and preferences"""
    name: str = ""
    relationship: str = ""
    preferences: Dict[str, Any] = field(default_factory=dict)
    coding_style: Dict[str, Any] = field(default_factory=dict)
    permission_levels: Dict[str, bool] = field(default_factory=dict)
    interaction_patterns: List[Dict] = field(default_factory=list)
    created_at: str = ""
    last_interaction: str = ""
    total_interactions: int = 0
    
    def to_dict(self) -> Dict:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'OwnerProfile':
        return cls(**data)

@dataclass
class AgentIdentity:
    """Agent's self-awareness data"""
    name: str = AGENT_NAME
    version: str = VERSION
    owner: Optional[OwnerProfile] = None
    capabilities: List[str] = field(default_factory=list)
    limitations: List[str] = field(default_factory=list)
    architecture: Dict[str, Any] = field(default_factory=dict)
    evolution_history: List[Dict] = field(default_factory=list)
    health_score: float = 100.0
    
    def to_dict(self) -> Dict:
        data = asdict(self)
        if self.owner:
            data['owner'] = self.owner.to_dict()
        return data

@dataclass
class SystemHealth:
    """Self-diagnostics data"""
    cpu_usage: float = 0.0
    memory_usage: float = 0.0
    api_health: Dict[str, bool] = field(default_factory=dict)
    plugin_status: Dict[str, str] = field(default_factory=dict)
    last_error: Optional[str] = None
    uptime_seconds: float = 0.0
    tasks_completed: int = 0
    tasks_failed: int = 0
    evolution_count: int = 0

# ═══════════════════════════════════════════════════════════════════════════════
# SMILE AGENT CORE CLASS
# ═══════════════════════════════════════════════════════════════════════════════

class SmileAgent:
    """
    SMILE - Self-evolving Modular Intelligence Layer Engine
    
    The main orchestrator class that coordinates all subsystems:
    - Meta Brain (Decision Layer)
    - Thinking Engine
    - Memory System
    - Plugin System
    - API Manager
    - Initiative Engine
    - Upgrade Engine
    - And more...
    """
    
    def __init__(self):
        logger.info("=" * 70)
        logger.info(f"  Initializing {AGENT_NAME} AI Agent OS v{VERSION}")
        logger.info("=" * 70)
        
        self.state = AgentState.INITIALIZING
        self.identity = AgentIdentity()
        self.health = SystemHealth()
        self.start_time = datetime.now()
        
        # Core subsystems (will be initialized)
        self.meta_brain = None
        self.memory_system = None
        self.thinking_engine = None
        self.router_engine = None
        self.tool_manager = None
        self.plugin_system = None
        self.api_manager = None
        self.code_index = None
        self.upgrade_engine = None
        self.execution_engine = None
        self.initiative_engine = None
        self.reflection_engine = None  # My addition
        
        # Runtime data
        self.active_plugins: Dict[str, Any] = {}
        self.loaded_tools: Dict[str, callable] = {}
        self.conversation_history: List[Dict] = []
        self.pending_initiatives: List[Dict] = []
        
        # Initialize identity awareness
        self._init_self_awareness()
        
    def _init_self_awareness(self):
        """Initialize agent's understanding of itself"""
        self.identity.capabilities = [
            "Natural language understanding and generation",
            "Multi-step reasoning and planning",
            "Code generation and analysis",
            "Web search and information retrieval",
            "Plugin development and integration",
            "Self-upgrade and evolution",
            "Persistent memory across sessions",
            "Proactive communication",
            "Pattern learning from interactions",
            "Self-reflection and improvement"
        ]
        
        self.identity.limitations = [
            "Cannot execute code without sandbox",
            "Cannot access owner's system without permission",
            "Cannot make decisions above permission level",
            "Cannot guarantee 100% accuracy",
            "Must verify unknown facts",
            "Cannot operate without at least one API key"
        ]
        
        self.identity.architecture = {
            "meta_brain": "Decision layer - routes all requests",
            "thinking_engine": "Deep reasoning and planning",
            "memory_system": "5-layer persistent memory",
            "plugin_system": "Dynamic capability extension",
            "api_manager": "Multi-provider API orchestration",
            "upgrade_engine": "Safe self-modification",
            "initiative_engine": "Proactive communication",
            "reflection_engine": "Self-improvement analysis"
        }
        
    async def initialize(self) -> bool:
        """
        Full system initialization sequence
        Returns True if successful, False otherwise
        """
        try:
            logger.info("Starting full system initialization...")
            
            # Step 1: Initialize Memory System (critical - must be first)
            logger.info("[1/8] Initializing Memory System...")
            from core.memory_system import MemorySystem
            self.memory_system = MemorySystem(MEMORY_DIR)
            await self.memory_system.initialize()
            
            # Step 2: Check for first run / owner setup
            logger.info("[2/8] Checking owner profile...")
            is_first_run = await self._check_first_run()
            
            if is_first_run:
                self.state = AgentState.FIRST_RUN_SETUP
                await self._first_run_setup()
            else:
                await self._load_owner_profile()
            
            # Step 3: Initialize Meta Brain
            logger.info("[3/8] Initializing Meta Brain...")
            from core.meta_brain import MetaBrain
            self.meta_brain = MetaBrain(self)
            await self.meta_brain.initialize()
            
            # Step 4: Initialize API Manager
            logger.info("[4/8] Initializing API Manager...")
            await self._init_api_manager()
            
            # Step 5: Initialize Plugin System
            logger.info("[5/8] Initializing Plugin System...")
            await self._init_plugin_system()
            
            # Step 6: Initialize Code Index
            logger.info("[6/8] Building Code Index...")
            await self._init_code_index()
            
            # Step 7: Initialize Initiative Engine
            logger.info("[7/8] Initializing Initiative Engine...")
            await self._init_initiative_engine()
            
            # Step 8: Initialize Reflection Engine (my addition)
            logger.info("[8/8] Initializing Self-Reflection Engine...")
            await self._init_reflection_engine()
            
            self.state = AgentState.READY
            logger.info("=" * 70)
            logger.info(f"  {AGENT_NAME} is READY")
            logger.info(f"  Owner: {self.identity.owner.name if self.identity.owner else 'Unknown'}")
            logger.info(f"  Plugins Loaded: {len(self.active_plugins)}")
            logger.info(f"  Tools Available: {len(self.loaded_tools)}")
            logger.info("=" * 70)
            
            return True
            
        except Exception as e:
            logger.error(f"Initialization failed: {e}")
            logger.error(traceback.format_exc())
            self.state = AgentState.ERROR
            return False
    
    async def _check_first_run(self) -> bool:
        """Check if this is the first run (no owner profile exists)"""
        owner_file = MEMORY_DIR / "owner_profile.json"
        return not owner_file.exists()
    
    async def _first_run_setup(self):
        """Interactive first-run setup to establish owner identity"""
        print("\n" + "═" * 70)
        print(f"  Welcome to {AGENT_NAME} - Your Personal AI Agent")
        print("  First-time Setup")
        print("═" * 70 + "\n")
        
        print(f"Hello! I'm {AGENT_NAME}, your personal evolving AI agent.")
        print("Let's get to know each other so I can serve you better.\n")
        
        # 1. Owner Name
        owner_name = input("👤 What is your name? > ").strip()
        while not owner_name:
            print("I need to know who you are to serve you properly.")
            owner_name = input("👤 What is your name? > ").strip()
        
        # 2. Relationship
        print(f"\nNice to meet you, {owner_name}!")
        print("What should our relationship be?")
        print("  1. Personal Assistant")
        print("  2. Development Partner")
        print("  3. Research Companion")
        print("  4. Learning Buddy")
        print("  5. Custom (describe)")
        
        rel_choice = input("🤝 Choose (1-5): > ").strip()
        relationships = {
            "1": "Personal Assistant",
            "2": "Development Partner", 
            "3": "Research Companion",
            "4": "Learning Buddy"
        }
        relationship = relationships.get(rel_choice, "")
        if rel_choice == "5" or not relationship:
            relationship = input("🤝 Describe our relationship: > ").strip()
        
        # 3. Preferences
        print(f"\nGreat! I'll be your {relationship}.")
        print("Let me learn your preferences:")
        
        preferences = {}
        
        # Communication style
        print("\nHow should I communicate with you?")
        print("  1. Formal and professional")
        print("  2. Casual and friendly")
        print("  3. Technical and precise")
        print("  4. Adaptive (match your style)")
        
        comm_choice = input("💬 Choose (1-4): > ").strip()
        comm_styles = {
            "1": "formal",
            "2": "casual",
            "3": "technical",
            "4": "adaptive"
        }
        preferences["communication_style"] = comm_styles.get(comm_choice, "adaptive")
        
        # Verbosity
        print("\nHow detailed should my responses be?")
        print("  1. Concise - Just the essentials")
        print("  2. Balanced - Good detail when needed")
        print("  3. Comprehensive - Full explanations")
        
        verb_choice = input("📝 Choose (1-3): > ").strip()
        verbosity = {"1": "concise", "2": "balanced", "3": "comprehensive"}
        preferences["verbosity"] = verbosity.get(verb_choice, "balanced")
        
        # Proactivity
        print("\nHow proactive should I be?")
        print("  1. Only respond when asked")
        print("  2. Suggest improvements occasionally")
        print("  3. Actively help and anticipate needs")
        
        proactive_choice = input("🎯 Choose (1-3): > ").strip()
        proactivity = {"1": "passive", "2": "moderate", "3": "active"}
        preferences["proactivity"] = proactivity.get(proactive_choice, "moderate")
        
        # 4. Coding Style Preferences
        print("\nNow let's configure coding preferences:")
        
        coding_style = {}
        
        # Primary language
        primary_lang = input("💻 Primary programming language? > ").strip()
        coding_style["primary_language"] = primary_lang or "Python"
        
        # Style preferences
        print("\nCode style preference?")
        print("  1. Clean and readable")
        print("  2. Highly optimized")
        print("  3. Heavily documented")
        print("  4. Balanced")
        
        style_choice = input("🎨 Choose (1-4): > ").strip()
        styles = {
            "1": "clean_readable",
            "2": "optimized",
            "3": "documented",
            "4": "balanced"
        }
        coding_style["style"] = styles.get(style_choice, "balanced")
        
        # Frameworks
        frameworks = input("📦 Preferred frameworks (comma-separated)? > ").strip()
        coding_style["frameworks"] = [f.strip() for f in frameworks.split(",")] if frameworks else []
        
        # 5. Permission Levels
        print("\nFinally, let's set my permissions:")
        
        permission_levels = {}
        
        permissions_questions = [
            ("file_read", "Can I read files on your system?"),
            ("file_write", "Can I create/modify files?"),
            ("execute_code", "Can I execute code (in sandbox)?"),
            ("web_access", "Can I access the internet?"),
            ("self_upgrade", "Can I upgrade myself?"),
            ("proactive_message", "Can I message you proactively?"),
            ("install_packages", "Can I install Python packages?"),
        ]
        
        for perm_key, question in permissions_questions:
            answer = input(f"🔐 {question} (y/n) > ").strip().lower()
            permission_levels[perm_key] = answer in ['y', 'yes', '1', 'true']
        
        # Create and save owner profile
        self.identity.owner = OwnerProfile(
            name=owner_name,
            relationship=relationship,
            preferences=preferences,
            coding_style=coding_style,
            permission_levels=permission_levels,
            interaction_patterns=[],
            created_at=datetime.now().isoformat(),
            last_interaction=datetime.now().isoformat(),
            total_interactions=0
        )
        
        await self._save_owner_profile()
        
        print("\n" + "═" * 70)
        print(f"  Setup Complete!")
        print(f"  I'm now configured as your {relationship}, {owner_name}!")
        print("═" * 70 + "\n")
        
        # Save initial greeting to memory
        await self.memory_system.store_long_term(
            "first_meeting",
            {
                "event": "first_meeting",
                "owner": owner_name,
                "relationship": relationship,
                "timestamp": datetime.now().isoformat()
            }
        )
    
    async def _load_owner_profile(self):
        """Load existing owner profile from memory"""
        owner_file = MEMORY_DIR / "owner_profile.json"
        try:
            with open(owner_file, 'r') as f:
                data = json.load(f)
            self.identity.owner = OwnerProfile.from_dict(data)
            logger.info(f"Loaded owner profile: {self.identity.owner.name}")
        except Exception as e:
            logger.error(f"Failed to load owner profile: {e}")
            raise
    
    async def _save_owner_profile(self):
        """Save owner profile to persistent storage"""
        owner_file = MEMORY_DIR / "owner_profile.json"
        try:
            with open(owner_file, 'w') as f:
                json.dump(self.identity.owner.to_dict(), f, indent=2)
            logger.info("Owner profile saved successfully")
        except Exception as e:
            logger.error(f"Failed to save owner profile: {e}")
            raise
    
    async def _init_api_manager(self):
        """Initialize the API manager with user-provided keys"""
        api_config_file = CONFIG_DIR / "api_config.json"
        
        if not api_config_file.exists():
            print("\n" + "─" * 50)
            print("  API Configuration Required")
            print("─" * 50)
            print("\nI need at least one AI API to function.")
            print("Supported providers: OpenAI, Anthropic, Google, OpenRouter, Local")
            
            apis = {}
            
            while not apis:
                print("\nAdd API keys (leave blank to skip):")
                
                openai_key = input("🔑 OpenAI API Key: > ").strip()
                if openai_key:
                    apis["openai"] = {
                        "key": openai_key,
                        "model": "gpt-4-turbo-preview",
                        "active": True,
                        "priority": 1
                    }
                
                anthropic_key = input("🔑 Anthropic API Key: > ").strip()
                if anthropic_key:
                    apis["anthropic"] = {
                        "key": anthropic_key,
                        "model": "claude-3-opus-20240229",
                        "active": True,
                        "priority": 2
                    }
                
                google_key = input("🔑 Google AI API Key: > ").strip()
                if google_key:
                    apis["google"] = {
                        "key": google_key,
                        "model": "gemini-pro",
                        "active": True,
                        "priority": 3
                    }
                
                openrouter_key = input("🔑 OpenRouter API Key: > ").strip()
                if openrouter_key:
                    apis["openrouter"] = {
                        "key": openrouter_key,
                        "model": "auto",
                        "active": True,
                        "priority": 4
                    }
                
                if not apis:
                    print("\n⚠️  At least one API key is required!")
                    continue_setup = input("Try again? (y/n) > ").strip().lower()
                    if continue_setup != 'y':
                        raise ValueError("Cannot operate without API keys")
            
            # Save API configuration (encrypted in production)
            with open(api_config_file, 'w') as f:
                json.dump({"apis": apis, "created": datetime.now().isoformat()}, f, indent=2)
            
            print("\n✅ API configuration saved!")
        
        # Load API config
        with open(api_config_file, 'r') as f:
            api_config = json.load(f)
        
        # Initialize API Manager
        from core.api_manager import APIManager
        self.api_manager = APIManager(api_config)
        await self.api_manager.initialize()
        
        logger.info(f"API Manager initialized with {len(api_config.get('apis', {}))} providers")
    
    async def _init_plugin_system(self):
        """Initialize the plugin system and load all plugins"""
        from core.plugin_system import PluginSystem
        self.plugin_system = PluginSystem(PLUGINS_DIR, self)
        await self.plugin_system.initialize()
        self.active_plugins = self.plugin_system.get_active_plugins()
        self.loaded_tools = self.plugin_system.get_all_tools()
    
    async def _init_code_index(self):
        """Build index of the agent's own codebase"""
        from core.code_index import CodeIndex
        self.code_index = CodeIndex(BASE_DIR)
        await self.code_index.build_index()
    
    async def _init_initiative_engine(self):
        """Initialize proactive messaging system"""
        from core.initiative_engine import InitiativeEngine
        self.initiative_engine = InitiativeEngine(self)
        await self.initiative_engine.initialize()
    
    async def _init_reflection_engine(self):
        """Initialize self-reflection and improvement system"""
        from core.reflection_engine import ReflectionEngine
        self.reflection_engine = ReflectionEngine(self)
        await self.reflection_engine.initialize()
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MAIN INTERACTION METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def process_input(self, user_input: str) -> Dict[str, Any]:
        """
        Main entry point for processing user input
        Routes through Meta Brain for decision making
        """
        self.state = AgentState.THINKING
        
        # Update interaction stats
        self.identity.owner.total_interactions += 1
        self.identity.owner.last_interaction = datetime.now().isoformat()
        
        # Store in short-term memory
        await self.memory_system.store_short_term({
            "role": "user",
            "content": user_input,
            "timestamp": datetime.now().isoformat()
        })
        
        try:
            # Route through Meta Brain
            response = await self.meta_brain.process(user_input)
            
            # Store response in memory
            await self.memory_system.store_short_term({
                "role": "assistant",
                "content": response.get("response", ""),
                "timestamp": datetime.now().isoformat(),
                "confidence": response.get("confidence", 0.5)
            })
            
            # Trigger self-reflection (async, non-blocking)
            asyncio.create_task(
                self.reflection_engine.reflect_on_interaction(user_input, response)
            )
            
            self.state = AgentState.READY
            self.health.tasks_completed += 1
            
            return response
            
        except Exception as e:
            logger.error(f"Error processing input: {e}")
            self.state = AgentState.ERROR
            self.health.tasks_failed += 1
            self.health.last_error = str(e)
            
            return {
                "response": f"I encountered an error: {str(e)}. Let me try to recover.",
                "error": True,
                "confidence": ConfidenceLevel.UNCERTAIN.value
            }
    
    async def get_proactive_message(self) -> Optional[str]:
        """Check if agent has any proactive messages to send"""
        if not self.identity.owner.permission_levels.get("proactive_message", False):
            return None
        return await self.initiative_engine.get_pending_message()
    
    def get_identity_summary(self) -> str:
        """Return a summary of who the agent is"""
        owner_name = self.identity.owner.name if self.identity.owner else "Unknown"
        return f"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  Agent Identity Summary                                                      ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Name: {self.identity.name:<66} ║
║  Version: {self.identity.version:<63} ║
║  Owner: {owner_name:<65} ║
║  State: {self.state.name:<65} ║
║  Health Score: {self.identity.health_score:.1f}%{' ' * 55} ║
║  Capabilities: {len(self.identity.capabilities):<58} ║
║  Active Plugins: {len(self.active_plugins):<55} ║
║  Available Tools: {len(self.loaded_tools):<54} ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""
    
    async def shutdown(self):
        """Graceful shutdown procedure"""
        logger.info("Initiating graceful shutdown...")
        self.state = AgentState.SHUTTING_DOWN
        
        # Save all memory
        await self.memory_system.persist_all()
        
        # Save owner profile
        if self.identity.owner:
            await self._save_owner_profile()
        
        # Shutdown plugins
        if self.plugin_system:
            await self.plugin_system.shutdown()
        
        logger.info("Shutdown complete. Goodbye!")


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN INTERACTION LOOP
# ═══════════════════════════════════════════════════════════════════════════════

async def main():
    """Main entry point - starts the agent and runs interaction loop"""
    agent = SmileAgent()
    
    try:
        # Initialize the agent
        success = await agent.initialize()
        if not success:
            print("Failed to initialize agent. Check logs for details.")
            return
        
        # Print identity
        print(agent.get_identity_summary())
        
        # Check for proactive messages
        proactive_msg = await agent.get_proactive_message()
        if proactive_msg:
            print(f"\n💭 {AGENT_NAME}: {proactive_msg}\n")
        
        # Main interaction loop
        owner_name = agent.identity.owner.name if agent.identity.owner else "User"
        print(f"\nHello {owner_name}! I'm ready to help. Type 'exit' to quit.\n")
        
        while True:
            try:
                # Get user input
                user_input = input(f"🧑 {owner_name}: ").strip()
                
                if not user_input:
                    continue
                
                if user_input.lower() in ['exit', 'quit', 'bye', 'goodbye']:
                    print(f"\n🤖 {AGENT_NAME}: Goodbye {owner_name}! See you next time! 👋\n")
                    break
                
                if user_input.lower() == 'status':
                    print(agent.get_identity_summary())
                    continue
                
                # Process input
                response = await agent.process_input(user_input)
                
                # Display response
                confidence_emoji = "🎯" if response.get("confidence", 0) > 0.7 else "🤔"
                print(f"\n{confidence_emoji} {AGENT_NAME}: {response.get('response', 'I apologize, I could not generate a response.')}\n")
                
                # Check for any proactive follow-up
                proactive_msg = await agent.get_proactive_message()
                if proactive_msg:
                    print(f"💭 {AGENT_NAME}: {proactive_msg}\n")
                    
            except KeyboardInterrupt:
                print("\n\nInterrupted by user.")
                break
            except Exception as e:
                logger.error(f"Error in main loop: {e}")
                print(f"\n⚠️ An error occurred: {e}\n")
        
        # Graceful shutdown
        await agent.shutdown()
        
    except Exception as e:
        logger.critical(f"Critical error: {e}")
        logger.critical(traceback.format_exc())
        raise


if __name__ == "__main__":
    asyncio.run(main())