"""
Environment Variable Detection Service

Scans repositories for environment variables before build.
"""

import re
import os
from typing import List, Dict, Optional, Set
from pathlib import Path
import tempfile
import shutil

import git
import aiofiles

from app.schemas.deployment import DetectedEnvVar, EnvDetectionResult


class EnvDetectorService:
    """
    Service for detecting environment variables in repositories.
    
    Detection sources:
    - .env.example, .env.sample files
    - config.py, config.js, config.json files
    - Source code patterns (process.env, os.getenv, etc.)
    - Dockerfile ENV and ARG lines
    - README configuration sections
    """
    
    # Regex patterns for env var detection
    PATTERNS = {
        # Python patterns
        "python_getenv": re.compile(r'os\.getenv\s*\(\s*["\']([A-Z_][A-Z0-9_]*)["\']', re.IGNORECASE),
        "python_environ": re.compile(r'os\.environ\s*\[\s*["\']([A-Z_][A-Z0-9_]*)["\']', re.IGNORECASE),
        "python_environ_get": re.compile(r'os\.environ\.get\s*\(\s*["\']([A-Z_][A-Z0-9_]*)["\']', re.IGNORECASE),
        
        # JavaScript/Node patterns
        "node_env": re.compile(r'process\.env\.([A-Z_][A-Z0-9_]*)', re.IGNORECASE),
        "node_env_bracket": re.compile(r'process\.env\[["\']([A-Z_][A-Z0-9_]*)["\']\]', re.IGNORECASE),
        
        # Dockerfile patterns
        "docker_env": re.compile(r'^ENV\s+([A-Z_][A-Z0-9_]*)', re.MULTILINE | re.IGNORECASE),
        "docker_arg": re.compile(r'^ARG\s+([A-Z_][A-Z0-9_]*)', re.MULTILINE | re.IGNORECASE),
        
        # Generic config patterns
        "config_key": re.compile(r'["\']([A-Z_][A-Z0-9_]{2,})["\']:\s*["\']', re.IGNORECASE),
    }
    
    # File extensions to scan
    SOURCE_EXTENSIONS = {".py", ".js", ".ts", ".jsx", ".tsx", ".go", ".rs", ".rb", ".php"}
    CONFIG_FILES = {"config.py", "config.js", "config.ts", "config.json", "settings.py", "settings.json"}
    ENV_EXAMPLE_FILES = {".env.example", ".env.sample", ".env.template", "example.env", ".env.local.example"}
    
    # Common env vars to recognize
    COMMON_VARS: Dict[str, Dict] = {
        "BOT_TOKEN": {"required": True, "example": "123456:ABC-DEF...", "description": "Telegram Bot Token"},
        "API_KEY": {"required": True, "example": "sk-...", "description": "API Key"},
        "DATABASE_URL": {"required": True, "example": "postgresql://user:pass@host/db", "description": "Database Connection URL"},
        "REDIS_URL": {"required": False, "example": "redis://localhost:6379", "description": "Redis Connection URL"},
        "PORT": {"required": False, "default": "3000", "description": "Application Port"},
        "HOST": {"required": False, "default": "0.0.0.0", "description": "Application Host"},
        "DEBUG": {"required": False, "default": "false", "description": "Debug Mode"},
        "SECRET_KEY": {"required": True, "example": "your-secret-key", "description": "Application Secret Key"},
        "JWT_SECRET": {"required": True, "example": "jwt-secret-key", "description": "JWT Secret Key"},
        "WEBHOOK_URL": {"required": False, "example": "https://...", "description": "Webhook URL"},
    }
    
    def __init__(self):
        self.detected_vars: Dict[str, DetectedEnvVar] = {}
        self.source_files: Set[str] = set()
        self.has_dockerfile: bool = False
        self.dockerfile_base_image: Optional[str] = None
    
    async def detect_from_repo(self, repo_url: str, branch: str = "main") -> EnvDetectionResult:
        """
        Clone repository and detect environment variables.
        
        Args:
            repo_url: Git repository URL
            branch: Branch to clone
        
        Returns:
            EnvDetectionResult with detected variables
        """
        # Create temp directory
        temp_dir = tempfile.mkdtemp(prefix="env_detect_")
        
        try:
            # Clone repository
            repo = git.Repo.clone_from(
                repo_url,
                temp_dir,
                branch=branch,
                depth=1,  # Shallow clone
                single_branch=True
            )
            
            # Detect from various sources
            await self._scan_env_files(temp_dir)
            await self._scan_dockerfile(temp_dir)
            await self._scan_config_files(temp_dir)
            await self._scan_source_files(temp_dir)
            await self._scan_readme(temp_dir)
            
            # Build result
            return EnvDetectionResult(
                detected_vars=list(self.detected_vars.values()),
                source_files=list(self.source_files),
                has_dockerfile=self.has_dockerfile,
                dockerfile_base_image=self.dockerfile_base_image
            )
            
        finally:
            # Cleanup
            shutil.rmtree(temp_dir, ignore_errors=True)
    
    async def detect_from_path(self, path: str) -> EnvDetectionResult:
        """
        Detect environment variables from local path.
        
        Args:
            path: Local directory path
        
        Returns:
            EnvDetectionResult with detected variables
        """
        await self._scan_env_files(path)
        await self._scan_dockerfile(path)
        await self._scan_config_files(path)
        await self._scan_source_files(path)
        await self._scan_readme(path)
        
        return EnvDetectionResult(
            detected_vars=list(self.detected_vars.values()),
            source_files=list(self.source_files),
            has_dockerfile=self.has_dockerfile,
            dockerfile_base_image=self.dockerfile_base_image
        )
    
    async def _scan_env_files(self, base_path: str) -> None:
        """Scan .env.example and similar files."""
        for filename in self.ENV_EXAMPLE_FILES:
            file_path = os.path.join(base_path, filename)
            if os.path.exists(file_path):
                self.source_files.add(filename)
                await self._parse_env_file(file_path)
    
    async def _parse_env_file(self, file_path: str) -> None:
        """Parse .env format file."""
        async with aiofiles.open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = await f.read()
        
        for line in content.split('\n'):
            line = line.strip()
            
            # Skip comments and empty lines
            if not line or line.startswith('#'):
                continue
            
            # Parse KEY=value format
            if '=' in line:
                key, _, value = line.partition('=')
                key = key.strip()
                value = value.strip().strip('"').strip("'")
                
                if self._is_valid_env_name(key):
                    self._add_var(
                        key,
                        example=value if value and not self._is_placeholder(value) else None,
                        source=os.path.basename(file_path)
                    )
    
    async def _scan_dockerfile(self, base_path: str) -> None:
        """Scan Dockerfile for ENV and ARG."""
        dockerfile_names = ["Dockerfile", "dockerfile", "Dockerfile.prod", "Dockerfile.dev"]
        
        for dockerfile_name in dockerfile_names:
            file_path = os.path.join(base_path, dockerfile_name)
            if os.path.exists(file_path):
                self.has_dockerfile = True
                self.source_files.add(dockerfile_name)
                
                async with aiofiles.open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = await f.read()
                
                # Extract base image
                from_match = re.search(r'^FROM\s+(\S+)', content, re.MULTILINE)
                if from_match:
                    self.dockerfile_base_image = from_match.group(1)
                
                # Extract ENV variables
                for match in self.PATTERNS["docker_env"].finditer(content):
                    self._add_var(match.group(1), source=dockerfile_name)
                
                # Extract ARG variables (build-time)
                for match in self.PATTERNS["docker_arg"].finditer(content):
                    self._add_var(match.group(1), source=dockerfile_name, required=False)
                
                break  # Only scan first Dockerfile found
    
    async def _scan_config_files(self, base_path: str) -> None:
        """Scan config files."""
        for root, _, files in os.walk(base_path):
            # Skip node_modules, venv, etc.
            if any(skip in root for skip in ['node_modules', 'venv', '.git', '__pycache__']):
                continue
            
            for filename in files:
                if filename in self.CONFIG_FILES:
                    file_path = os.path.join(root, filename)
                    rel_path = os.path.relpath(file_path, base_path)
                    self.source_files.add(rel_path)
                    
                    async with aiofiles.open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        content = await f.read()
                    
                    # Apply all patterns
                    for pattern_name, pattern in self.PATTERNS.items():
                        for match in pattern.finditer(content):
                            self._add_var(match.group(1), source=rel_path)
    
    async def _scan_source_files(self, base_path: str) -> None:
        """Scan source code files for env references."""
        for root, _, files in os.walk(base_path):
            # Skip common directories
            if any(skip in root for skip in ['node_modules', 'venv', '.git', '__pycache__', 'dist', 'build']):
                continue
            
            for filename in files:
                ext = os.path.splitext(filename)[1].lower()
                if ext in self.SOURCE_EXTENSIONS:
                    file_path = os.path.join(root, filename)
                    rel_path = os.path.relpath(file_path, base_path)
                    
                    try:
                        async with aiofiles.open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            content = await f.read()
                        
                        found_any = False
                        for pattern_name, pattern in self.PATTERNS.items():
                            for match in pattern.finditer(content):
                                var_name = match.group(1)
                                if self._is_valid_env_name(var_name):
                                    self._add_var(var_name, source=rel_path)
                                    found_any = True
                        
                        if found_any:
                            self.source_files.add(rel_path)
                            
                    except Exception:
                        continue
    
    async def _scan_readme(self, base_path: str) -> None:
        """Scan README for configuration section."""
        readme_files = ["README.md", "readme.md", "README.txt", "README"]
        
        for readme in readme_files:
            file_path = os.path.join(base_path, readme)
            if os.path.exists(file_path):
                async with aiofiles.open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = await f.read()
                
                # Look for configuration sections
                config_section = re.search(
                    r'#+\s*(configuration|environment|setup|env).*?\n(.*?)(?=\n#+|\Z)',
                    content,
                    re.IGNORECASE | re.DOTALL
                )
                
                if config_section:
                    section_content = config_section.group(2)
                    
                    # Find env var mentions
                    env_mentions = re.findall(
                        r'`?([A-Z_][A-Z0-9_]{2,})`?',
                        section_content
                    )
                    
                    for var in env_mentions:
                        if self._is_valid_env_name(var):
                            self._add_var(var, source=readme, required=False)
                    
                    if env_mentions:
                        self.source_files.add(readme)
                
                break
    
    def _add_var(
        self,
        name: str,
        example: Optional[str] = None,
        default: Optional[str] = None,
        source: Optional[str] = None,
        required: Optional[bool] = None
    ) -> None:
        """Add detected environment variable."""
        name = name.upper()
        
        # Check if already detected
        if name in self.detected_vars:
            # Update with new info if not already set
            existing = self.detected_vars[name]
            if not existing.example and example:
                existing.example = example
            if not existing.source and source:
                existing.source = source
            return
        
        # Get common var info if available
        common_info = self.COMMON_VARS.get(name, {})
        
        self.detected_vars[name] = DetectedEnvVar(
            name=name,
            required=required if required is not None else common_info.get("required", True),
            example=example or common_info.get("example"),
            default=default or common_info.get("default"),
            description=common_info.get("description"),
            source=source
        )
    
    def _is_valid_env_name(self, name: str) -> bool:
        """Check if name is a valid environment variable name."""
        if not name or len(name) < 2:
            return False
        
        # Must start with letter/underscore
        if not name[0].isalpha() and name[0] != '_':
            return False
        
        # Skip common false positives
        skip_names = {
            'TRUE', 'FALSE', 'NULL', 'NONE', 'GET', 'POST', 'PUT', 'DELETE',
            'HTTP', 'HTTPS', 'WWW', 'API', 'URL', 'URI', 'JSON', 'XML',
            'UTF', 'ASCII', 'HTML', 'CSS', 'JS', 'TS'
        }
        if name.upper() in skip_names:
            return False
        
        return True
    
    def _is_placeholder(self, value: str) -> bool:
        """Check if value is a placeholder."""
        placeholders = [
            'your-', 'your_', 'xxx', 'TODO', 'CHANGEME', 'REPLACE',
            '<', '>', '${', 'example', 'placeholder'
        ]
        value_lower = value.lower()
        return any(p in value_lower for p in placeholders)
