"""
User Service

Business logic for user management.
"""

from typing import Optional, List
from datetime import datetime, timedelta
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.user import User
from app.models.plan import Plan
from app.schemas.user import UserCreate, UserUpdate, UserWithPlan
from app.core.exceptions import AuthenticationError


class UserService:
    """Service for user management operations."""
    
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def get_by_id(self, user_id: int) -> Optional[User]:
        """Get user by ID."""
        result = await self.db.execute(
            select(User)
            .options(selectinload(User.plan))
            .where(User.id == user_id)
        )
        return result.scalar_one_or_none()
    
    async def get_by_telegram_id(self, telegram_id: int) -> Optional[User]:
        """Get user by Telegram ID."""
        result = await self.db.execute(
            select(User)
            .options(selectinload(User.plan))
            .where(User.telegram_id == telegram_id)
        )
        return result.scalar_one_or_none()
    
    async def get_or_create(
        self,
        telegram_id: int,
        username: Optional[str] = None,
        first_name: Optional[str] = None,
        last_name: Optional[str] = None
    ) -> User:
        """
        Get existing user or create new one.
        
        This is called on /start to ensure user exists.
        """
        user = await self.get_by_telegram_id(telegram_id)
        
        if user:
            # Update last active
            user.last_active_at = datetime.utcnow()
            # Update username if changed
            if username and user.username != username:
                user.username = username
            if first_name and user.first_name != first_name:
                user.first_name = first_name
            if last_name and user.last_name != last_name:
                user.last_name = last_name
            
            await self.db.commit()
            return user
        
        # Create new user with free plan
        free_plan = await self._get_free_plan()
        
        user = User(
            telegram_id=telegram_id,
            username=username,
            first_name=first_name,
            last_name=last_name,
            plan_id=free_plan.id if free_plan else None,
            last_active_at=datetime.utcnow()
        )
        
        self.db.add(user)
        await self.db.commit()
        await self.db.refresh(user)
        
        return user
    
    async def update(self, user_id: int, data: UserUpdate) -> Optional[User]:
        """Update user."""
        user = await self.get_by_id(user_id)
        if not user:
            return None
        
        update_data = data.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            setattr(user, key, value)
        
        await self.db.commit()
        await self.db.refresh(user)
        
        return user
    
    async def set_admin(self, telegram_id: int, is_admin: bool) -> bool:
        """Set admin status for user."""
        result = await self.db.execute(
            update(User)
            .where(User.telegram_id == telegram_id)
            .values(is_admin=is_admin)
        )
        await self.db.commit()
        return result.rowcount > 0
    
    async def ban_user(
        self,
        telegram_id: int,
        reason: Optional[str] = None
    ) -> bool:
        """Ban a user."""
        result = await self.db.execute(
            update(User)
            .where(User.telegram_id == telegram_id)
            .values(is_banned=True, ban_reason=reason)
        )
        await self.db.commit()
        return result.rowcount > 0
    
    async def unban_user(self, telegram_id: int) -> bool:
        """Unban a user."""
        result = await self.db.execute(
            update(User)
            .where(User.telegram_id == telegram_id)
            .values(is_banned=False, ban_reason=None)
        )
        await self.db.commit()
        return result.rowcount > 0
    
    async def upgrade_plan(
        self,
        user_id: int,
        plan_id: int,
        duration_days: int
    ) -> User:
        """
        Upgrade user's plan.
        
        Called after successful payment.
        """
        user = await self.get_by_id(user_id)
        if not user:
            raise ValueError(f"User {user_id} not found")
        
        user.plan_id = plan_id
        
        # Set or extend subscription
        now = datetime.utcnow()
        if user.subscription_expires_at and user.subscription_expires_at > now:
            # Extend existing subscription
            user.subscription_expires_at += timedelta(days=duration_days)
        else:
            # New subscription
            user.subscription_expires_at = now + timedelta(days=duration_days)
        
        await self.db.commit()
        await self.db.refresh(user)
        
        return user
    
    async def get_all_users(
        self,
        skip: int = 0,
        limit: int = 100,
        active_only: bool = False
    ) -> List[User]:
        """Get all users with pagination."""
        query = select(User).options(selectinload(User.plan))
        
        if active_only:
            query = query.where(User.is_active == True, User.is_banned == False)
        
        query = query.offset(skip).limit(limit)
        
        result = await self.db.execute(query)
        return list(result.scalars().all())
    
    async def get_user_count(self) -> int:
        """Get total user count."""
        from sqlalchemy import func
        result = await self.db.execute(select(func.count(User.id)))
        return result.scalar_one()
    
    async def get_admin_ids(self) -> List[int]:
        """Get all admin Telegram IDs."""
        result = await self.db.execute(
            select(User.telegram_id).where(User.is_admin == True)
        )
        return list(result.scalars().all())
    
    async def check_admin(self, telegram_id: int) -> bool:
        """Check if user is an admin."""
        user = await self.get_by_telegram_id(telegram_id)
        return user is not None and user.is_admin
    
    async def _get_free_plan(self) -> Optional[Plan]:
        """Get the default free plan."""
        result = await self.db.execute(
            select(Plan)
            .where(Plan.is_active == True, Plan.price == 0)
            .order_by(Plan.sort_order)
            .limit(1)
        )
        return result.scalar_one_or_none()
    
    def to_display(self, user: User) -> UserWithPlan:
        """Convert user to display format."""
        return UserWithPlan(
            id=user.id,
            telegram_id=user.telegram_id,
            username=user.username,
            first_name=user.first_name,
            last_name=user.last_name,
            balance=user.balance,
            is_admin=user.is_admin,
            is_active=user.is_active,
            is_banned=user.is_banned,
            plan_id=user.plan_id,
            subscription_expires_at=user.subscription_expires_at,
            created_at=user.created_at,
            last_active_at=user.last_active_at,
            plan_name=user.plan.display_name if user.plan else None,
            max_deployments=user.plan.max_deployments if user.plan else 0,
            ram_limit_mb=user.plan.ram_limit_mb if user.plan else 0,
            deployment_count=user.deployment_count,
            is_subscription_active=user.is_subscription_active
        )
