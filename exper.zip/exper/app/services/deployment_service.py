"""
Deployment Service

Business logic for deployment management.
"""

import uuid
from typing import Optional, List
from datetime import datetime
from sqlalchemy import select, update, func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.deployment import Deployment, DeploymentStatus, DeploymentLog
from app.models.user import User
from app.models.vps_node import VPSNode
from app.schemas.deployment import DeploymentCreate, DeploymentUpdate, EnvDetectionResult
from app.services.queue_service import QueueService
from app.services.env_detector import EnvDetectorService
from app.core.security import encrypt_data, decrypt_data
from app.core.exceptions import (
    DeploymentNotFoundError,
    DeploymentLimitReachedError,
    NoAvailableVPSError
)


class DeploymentService:
    """Service for deployment management operations."""
    
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def get_by_id(self, deployment_id: uuid.UUID) -> Optional[Deployment]:
        """Get deployment by ID."""
        result = await self.db.execute(
            select(Deployment)
            .options(
                selectinload(Deployment.user),
                selectinload(Deployment.vps_node)
            )
            .where(Deployment.id == deployment_id)
        )
        return result.scalar_one_or_none()
    
    async def get_by_user(
        self,
        user_id: int,
        include_deleted: bool = False
    ) -> List[Deployment]:
        """Get all deployments for a user."""
        query = select(Deployment).where(Deployment.user_id == user_id)
        
        if not include_deleted:
            query = query.where(Deployment.status != DeploymentStatus.DELETED)
        
        query = query.order_by(Deployment.created_at.desc())
        
        result = await self.db.execute(query)
        return list(result.scalars().all())
    
    async def create(
        self,
        user: User,
        data: DeploymentCreate
    ) -> Deployment:
        """
        Create a new deployment.
        
        Checks limits and queues the build task.
        """
        # Check deployment limit
        active_count = await self._get_active_count(user.id)
        max_deployments = user.plan.max_deployments if user.plan else 1
        
        if active_count >= max_deployments:
            raise DeploymentLimitReachedError(active_count, max_deployments)
        
        # Get resource limits from plan
        memory_limit = data.memory_limit or (
            f"{user.plan.ram_limit_mb}m" if user.plan else "512m"
        )
        cpu_limit = data.cpu_limit or (
            user.plan.cpu_limit if user.plan else 0.5
        )
        
        # Create deployment record
        deployment = Deployment(
            user_id=user.id,
            name=data.name,
            repo_url=data.repo_url,
            branch=data.branch,
            status=DeploymentStatus.PENDING,
            memory_limit=memory_limit,
            cpu_limit=cpu_limit,
            auto_deploy=data.auto_deploy
        )
        
        self.db.add(deployment)
        await self.db.commit()
        await self.db.refresh(deployment)
        
        # Add log entry
        await self._add_log(
            deployment.id,
            "info",
            "system",
            f"Deployment created. Repository: {data.repo_url}"
        )
        
        return deployment
    
    async def detect_env_vars(
        self,
        deployment_id: uuid.UUID
    ) -> EnvDetectionResult:
        """
        Detect environment variables for a deployment.
        
        Updates deployment status and returns detected vars.
        """
        deployment = await self.get_by_id(deployment_id)
        if not deployment:
            raise DeploymentNotFoundError(str(deployment_id))
        
        # Update status
        deployment.status = DeploymentStatus.DETECTING
        deployment.status_message = "Scanning repository for environment variables..."
        await self.db.commit()
        
        # Run detection
        detector = EnvDetectorService()
        result = await detector.detect_from_repo(
            deployment.repo_url,
            deployment.branch
        )
        
        # Store detected vars
        deployment.detected_env_vars = {
            "vars": [v.model_dump() for v in result.detected_vars],
            "source_files": result.source_files,
            "has_dockerfile": result.has_dockerfile
        }
        deployment.status = DeploymentStatus.CONFIGURING
        deployment.status_message = f"Detected {len(result.detected_vars)} environment variables"
        
        await self.db.commit()
        
        await self._add_log(
            deployment.id,
            "info",
            "system",
            f"Detected {len(result.detected_vars)} environment variables from {len(result.source_files)} files"
        )
        
        return result
    
    async def configure_env(
        self,
        deployment_id: uuid.UUID,
        env_vars: dict
    ) -> Deployment:
        """
        Configure environment variables for deployment.
        
        Encrypts and stores env vars, then queues build.
        """
        deployment = await self.get_by_id(deployment_id)
        if not deployment:
            raise DeploymentNotFoundError(str(deployment_id))
        
        # Encrypt env vars
        import json
        deployment.env_vars_encrypted = encrypt_data(json.dumps(env_vars))
        deployment.status = DeploymentStatus.PENDING
        deployment.status_message = "Queued for build"
        
        await self.db.commit()
        
        await self._add_log(
            deployment.id,
            "info",
            "system",
            f"Environment configured with {len(env_vars)} variables"
        )
        
        # Queue build task
        await QueueService.enqueue_deployment(
            deployment_id=deployment.id,
            action="build",
            repo_url=deployment.repo_url,
            branch=deployment.branch,
            env_vars=env_vars,
            memory_limit=deployment.memory_limit,
            cpu_limit=deployment.cpu_limit
        )
        
        return deployment
    
    async def assign_vps(self, deployment_id: uuid.UUID) -> VPSNode:
        """
        Assign deployment to best available VPS node.
        
        Selection criteria: load score (lowest wins)
        """
        # Get available VPS nodes
        result = await self.db.execute(
            select(VPSNode)
            .where(
                VPSNode.is_enabled == True,
                VPSNode.is_online == True
            )
        )
        nodes = list(result.scalars().all())
        
        # Filter and sort by load score
        available = [n for n in nodes if n.can_accept_deployment]
        if not available:
            raise NoAvailableVPSError()
        
        # Select best node
        best_node = min(available, key=lambda n: n.load_score)
        
        # Update deployment
        await self.db.execute(
            update(Deployment)
            .where(Deployment.id == deployment_id)
            .values(vps_node_id=best_node.id)
        )
        
        # Update VPS container count
        best_node.current_containers += 1
        await self.db.commit()
        
        return best_node
    
    async def update_status(
        self,
        deployment_id: uuid.UUID,
        status: DeploymentStatus,
        message: Optional[str] = None,
        container_id: Optional[str] = None
    ) -> Deployment:
        """Update deployment status."""
        deployment = await self.get_by_id(deployment_id)
        if not deployment:
            raise DeploymentNotFoundError(str(deployment_id))
        
        deployment.status = status
        if message:
            deployment.status_message = message
        if container_id:
            deployment.container_id = container_id
        
        # Set timestamps
        if status == DeploymentStatus.RUNNING:
            deployment.started_at = datetime.utcnow()
            deployment.last_activity_at = datetime.utcnow()
        elif status in (DeploymentStatus.STOPPED, DeploymentStatus.DELETED):
            deployment.stopped_at = datetime.utcnow()
        
        await self.db.commit()
        await self.db.refresh(deployment)
        
        return deployment
    
    async def start(self, deployment_id: uuid.UUID) -> None:
        """Start a stopped deployment."""
        deployment = await self.get_by_id(deployment_id)
        if not deployment:
            raise DeploymentNotFoundError(str(deployment_id))
        
        deployment.status = DeploymentStatus.STARTING
        await self.db.commit()
        
        await QueueService.enqueue_deployment(
            deployment_id=deployment.id,
            action="start"
        )
    
    async def stop(self, deployment_id: uuid.UUID) -> None:
        """Stop a running deployment."""
        deployment = await self.get_by_id(deployment_id)
        if not deployment:
            raise DeploymentNotFoundError(str(deployment_id))
        
        await QueueService.enqueue_deployment(
            deployment_id=deployment.id,
            action="stop"
        )
    
    async def restart(self, deployment_id: uuid.UUID) -> None:
        """Restart a deployment."""
        deployment = await self.get_by_id(deployment_id)
        if not deployment:
            raise DeploymentNotFoundError(str(deployment_id))
        
        deployment.restart_count += 1
        deployment.last_restart_at = datetime.utcnow()
        await self.db.commit()
        
        await QueueService.enqueue_deployment(
            deployment_id=deployment.id,
            action="restart"
        )
    
    async def delete(self, deployment_id: uuid.UUID) -> None:
        """Delete a deployment."""
        deployment = await self.get_by_id(deployment_id)
        if not deployment:
            raise DeploymentNotFoundError(str(deployment_id))
        
        # Queue deletion
        await QueueService.enqueue_deployment(
            deployment_id=deployment.id,
            action="delete"
        )
        
        # Mark as deleted
        deployment.status = DeploymentStatus.DELETED
        
        # Update VPS container count
        if deployment.vps_node:
            deployment.vps_node.current_containers = max(
                0,
                deployment.vps_node.current_containers - 1
            )
        
        await self.db.commit()
    
    async def get_logs(
        self,
        deployment_id: uuid.UUID,
        limit: int = 100
    ) -> List[DeploymentLog]:
        """Get deployment logs."""
        result = await self.db.execute(
            select(DeploymentLog)
            .where(DeploymentLog.deployment_id == deployment_id)
            .order_by(DeploymentLog.created_at.desc())
            .limit(limit)
        )
        return list(result.scalars().all())

    async def fetch_logs(self, deployment_id: uuid.UUID) -> None:
        """Queue log fetch task."""
        deployment = await self.get_by_id(deployment_id)
        if not deployment:
            raise DeploymentNotFoundError(str(deployment_id))
            
        await QueueService.enqueue_deployment(
            deployment_id=deployment_id,
            action="fetch_logs"
        )
    
    async def get_decrypted_env(
        self,
        deployment_id: uuid.UUID
    ) -> dict:
        """Get decrypted environment variables."""
        deployment = await self.get_by_id(deployment_id)
        if not deployment or not deployment.env_vars_encrypted:
            return {}
        
        import json
        return json.loads(decrypt_data(deployment.env_vars_encrypted))
    
    async def _get_active_count(self, user_id: int) -> int:
        """Get count of active deployments for user."""
        result = await self.db.execute(
            select(func.count(Deployment.id))
            .where(
                Deployment.user_id == user_id,
                Deployment.status.not_in([
                    DeploymentStatus.STOPPED,
                    DeploymentStatus.DELETED,
                    DeploymentStatus.FAILED
                ])
            )
        )
        return result.scalar_one()
    
    async def _add_log(
        self,
        deployment_id: uuid.UUID,
        level: str,
        source: str,
        message: str
    ) -> None:
        """Add log entry for deployment."""
        log = DeploymentLog(
            deployment_id=deployment_id,
            level=level,
            source=source,
            message=message
        )
        self.db.add(log)
        await self.db.commit()
