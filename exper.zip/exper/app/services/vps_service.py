"""
VPS Service

Business logic for VPS node management.
"""

from typing import Optional, List
from datetime import datetime, timedelta
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.vps_node import VPSNode
from app.schemas.vps import VPSNodeCreate, VPSNodeUpdate, VPSNodeStats, VPSHeartbeat
from app.core.exceptions import VPSNotFoundError


class VPSService:
    """Service for VPS node management operations."""
    
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def get_by_id(self, vps_id: int) -> Optional[VPSNode]:
        """Get VPS node by ID."""
        result = await self.db.execute(
            select(VPSNode)
            .options(selectinload(VPSNode.deployments))
            .where(VPSNode.id == vps_id)
        )
        node = result.scalar_one_or_none()
        
        if node:
            from app.models.deployment import DeploymentStatus
            # Update current_containers for display (ephemeral)
            node.current_containers = len([
                d for d in node.deployments 
                if d.status not in (DeploymentStatus.DELETED, DeploymentStatus.STOPPED)
            ])
            
        return node
    
    async def get_by_name(self, name: str) -> Optional[VPSNode]:
        """Get VPS node by name."""
        result = await self.db.execute(
            select(VPSNode).where(VPSNode.name == name)
        )
        return result.scalar_one_or_none()
    
    async def get_all(
        self,
        enabled_only: bool = False,
        online_only: bool = False
    ) -> List[VPSNode]:
        """Get all VPS nodes."""
        query = select(VPSNode)
        
        if enabled_only:
            query = query.where(VPSNode.is_enabled == True)
        if online_only:
            query = query.where(VPSNode.is_online == True)
        
        query = query.order_by(VPSNode.priority.desc(), VPSNode.name)
        
        result = await self.db.execute(query)
        nodes = list(result.scalars().all())
        
        from app.models.deployment import DeploymentStatus
        for node in nodes:
             node.current_containers = len([
                d for d in node.deployments 
                if d.status not in (DeploymentStatus.DELETED, DeploymentStatus.STOPPED)
            ])
            
        return nodes
    
    async def create(self, data: VPSNodeCreate) -> VPSNode:
        """Create a new VPS node."""
        node = VPSNode(
            name=data.name,
            host=data.host,
            port=data.port,
            ssh_user=data.ssh_user,
            ssh_key_path=data.ssh_key_path,
            agent_port=data.agent_port,
            agent_secret=data.agent_secret,
            max_containers=data.max_containers,
            region=data.region,
            country=data.country,
            priority=data.priority
        )
        
        self.db.add(node)
        await self.db.commit()
        await self.db.refresh(node)
        
        return node
    
    async def update(
        self,
        vps_id: int,
        data: VPSNodeUpdate
    ) -> Optional[VPSNode]:
        """Update a VPS node."""
        node = await self.get_by_id(vps_id)
        if not node:
            raise VPSNotFoundError(vps_id)
        
        update_data = data.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            setattr(node, key, value)
        
        await self.db.commit()
        await self.db.refresh(node)
        
        return node
    
    async def delete(self, vps_id: int) -> bool:
        """Delete a VPS node (if no active deployments)."""
        node = await self.get_by_id(vps_id)
        if not node:
            raise VPSNotFoundError(vps_id)
        
        # Check for active deployments
        if node.current_containers > 0:
            raise ValueError(
                f"Cannot delete VPS with {node.current_containers} active containers"
            )
        
        await self.db.delete(node)
        await self.db.commit()
        
        return True
    
    async def enable(self, vps_id: int) -> VPSNode:
        """Enable a VPS node."""
        result = await self.db.execute(
            update(VPSNode)
            .where(VPSNode.id == vps_id)
            .values(is_enabled=True)
            .returning(VPSNode)
        )
        await self.db.commit()
        return result.scalar_one()
    
    async def disable(self, vps_id: int) -> VPSNode:
        """Disable a VPS node."""
        result = await self.db.execute(
            update(VPSNode)
            .where(VPSNode.id == vps_id)
            .values(is_enabled=False)
            .returning(VPSNode)
        )
        await self.db.commit()
        return result.scalar_one()
    
    async def process_heartbeat(self, heartbeat: VPSHeartbeat) -> VPSNode:
        """
        Process heartbeat from VPS agent.
        
        Updates resource stats and marks node as online.
        """
        node = await self.get_by_id(heartbeat.node_id)
        if not node:
            raise VPSNotFoundError(heartbeat.node_id)
        
        # Verify agent secret
        if node.agent_secret != heartbeat.agent_secret:
            raise ValueError("Invalid agent secret")
        
        # Update stats
        node.is_online = True
        node.last_heartbeat = datetime.utcnow()
        node.total_ram_mb = heartbeat.total_ram_mb
        node.free_ram_mb = heartbeat.free_ram_mb
        node.cpu_usage_percent = heartbeat.cpu_usage_percent
        node.total_disk_gb = heartbeat.total_disk_gb
        node.free_disk_gb = heartbeat.free_disk_gb
        node.current_containers = heartbeat.current_containers
        node.docker_version = heartbeat.docker_version
        node.os_info = heartbeat.os_info
        
        await self.db.commit()
        await self.db.refresh(node)
        
        return node
    
    async def check_offline_nodes(self, timeout_minutes: int = 5) -> List[VPSNode]:
        """
        Mark nodes as offline if no heartbeat received.
        
        Returns list of nodes marked offline.
        """
        cutoff = datetime.utcnow() - timedelta(minutes=timeout_minutes)
        
        result = await self.db.execute(
            select(VPSNode)
            .where(
                VPSNode.is_online == True,
                VPSNode.last_heartbeat < cutoff
            )
        )
        stale_nodes = list(result.scalars().all())
        
        for node in stale_nodes:
            node.is_online = False
        
        await self.db.commit()
        
        return stale_nodes
    
    async def get_best_node(self) -> Optional[VPSNode]:
        """
        Get the best available VPS node for new deployment.
        
        Returns node with lowest load score.
        """
        nodes = await self.get_all(enabled_only=True, online_only=True)
        
        available = [n for n in nodes if n.can_accept_deployment]
        if not available:
            return None
        
        return min(available, key=lambda n: n.load_score)
    
    async def get_stats(self) -> List[VPSNodeStats]:
        """Get stats for all VPS nodes."""
        nodes = await self.get_all()
        stats = []
        
        from app.models.deployment import DeploymentStatus
        
        for node in nodes:
            # Calculate active deployments from DB
            active_deployments = len([
                d for d in node.deployments 
                if d.status not in (DeploymentStatus.DELETED, DeploymentStatus.STOPPED)
            ])
            
            # Use DB count if agent is offline or reporting 0 but we have deployments
            display_count = active_deployments
            if node.is_online and node.current_containers > active_deployments:
                # If agent reports more (e.g. system containers), maybe respect it?
                # But for now, let's stick to our platform deployments count for consistency
                pass
            
            stats.append(VPSNodeStats(
                id=node.id,
                name=node.name,
                status_emoji=node.status_emoji,
                utilization_bar=node.utilization_bar,
                is_online=node.is_online,
                is_enabled=node.is_enabled,
                containers=f"{display_count}/{node.max_containers}",
                ram=f"{(node.total_ram_mb - node.free_ram_mb) / 1024:.1f}/{node.total_ram_mb / 1024:.1f} GB",
                cpu=f"{node.cpu_usage_percent:.1f}%",
                disk=f"{node.total_disk_gb - node.free_disk_gb}/{node.total_disk_gb} GB",
                load_score=node.load_score
            ))
        
        return stats
    
    async def set_container_limit(
        self,
        vps_id: int,
        max_containers: int
    ) -> VPSNode:
        """Set max container limit for VPS."""
        node = await self.get_by_id(vps_id)
        if not node:
            raise VPSNotFoundError(vps_id)
        
        node.max_containers = max_containers
        await self.db.commit()
        await self.db.refresh(node)
        
        return node
