"""
Queue Service

Manages Redis queue for deployment tasks.
"""

import json
import uuid
from typing import Optional, Dict, Any
from datetime import datetime

from app.core.redis import redis_client
from app.schemas.deployment import DeploymentQueueTask


# Queue names
DEPLOYMENT_QUEUE = "deployment:queue"
DEPLOYMENT_RESULTS = "deployment:results"
VPS_TASKS_PREFIX = "vps:tasks:"


class QueueService:
    """
    Service for managing deployment task queue.
    
    Tasks flow:
    1. Backend creates task -> DEPLOYMENT_QUEUE
    2. Scheduler assigns to VPS -> VPS_TASKS_PREFIX:{vps_id}
    3. Agent processes and reports -> DEPLOYMENT_RESULTS
    """
    
    @staticmethod
    async def enqueue_deployment(
        deployment_id: uuid.UUID,
        action: str,
        **kwargs
    ) -> str:
        """
        Add deployment task to queue.
        
        Args:
            deployment_id: Deployment UUID
            action: Action to perform (build, start, stop, restart, delete)
            **kwargs: Additional task parameters
        
        Returns:
            Task ID
        """
        task_id = str(uuid.uuid4())
        
        task = DeploymentQueueTask(
            deployment_id=deployment_id,
            action=action,
            **kwargs
        )
        
        task_data = {
            "task_id": task_id,
            "deployment_id": str(deployment_id),
            "action": action,
            "data": task.model_dump(mode="json"),
            "created_at": datetime.utcnow().isoformat(),
            "status": "pending"
        }
        
        await redis_client.enqueue(DEPLOYMENT_QUEUE, task_data)
        
        return task_id
    
    @staticmethod
    async def assign_to_vps(
        task_id: str,
        vps_id: int,
        task_data: dict
    ) -> None:
        """
        Assign task to specific VPS node.
        
        Args:
            task_id: Task ID
            vps_id: Target VPS node ID
            task_data: Task data
        """
        queue_name = f"{VPS_TASKS_PREFIX}{vps_id}"
        
        task_data["assigned_at"] = datetime.utcnow().isoformat()
        task_data["vps_id"] = vps_id
        task_data["status"] = "assigned"
        
        await redis_client.enqueue(queue_name, task_data)
    
    @staticmethod
    async def get_pending_task() -> Optional[dict]:
        """
        Get next pending task from main queue.
        
        Returns:
            Task data or None
        """
        return await redis_client.dequeue(DEPLOYMENT_QUEUE, timeout=5)
    
    @staticmethod
    async def get_vps_task(vps_id: int, timeout: int = 5) -> Optional[dict]:
        """
        Get next task for specific VPS.
        
        Args:
            vps_id: VPS node ID
            timeout: Blocking timeout in seconds
        
        Returns:
            Task data or None
        """
        queue_name = f"{VPS_TASKS_PREFIX}{vps_id}"
        return await redis_client.dequeue(queue_name, timeout=timeout)
    
    @staticmethod
    async def report_result(
        task_id: str,
        deployment_id: str,
        success: bool,
        message: str,
        data: Optional[dict] = None
    ) -> None:
        """
        Report task result.
        
        Args:
            task_id: Task ID
            deployment_id: Deployment ID
            success: Whether task succeeded
            message: Result message
            data: Additional result data
        """
        result = {
            "task_id": task_id,
            "deployment_id": deployment_id,
            "success": success,
            "message": message,
            "data": data or {},
            "completed_at": datetime.utcnow().isoformat()
        }
        
        # Push to results queue
        await redis_client.enqueue(DEPLOYMENT_RESULTS, result)
        
        # Also publish for real-time updates
        await redis_client.publish(
            f"deployment:{deployment_id}:status",
            result
        )
    
    @staticmethod
    async def get_queue_length() -> int:
        """Get main queue length."""
        return await redis_client.queue_length(DEPLOYMENT_QUEUE)
    
    @staticmethod
    async def get_vps_queue_length(vps_id: int) -> int:
        """Get VPS queue length."""
        return await redis_client.queue_length(f"{VPS_TASKS_PREFIX}{vps_id}")
    
    @staticmethod
    async def clear_vps_queue(vps_id: int) -> None:
        """Clear all tasks for a VPS node."""
        queue_name = f"{VPS_TASKS_PREFIX}{vps_id}"
        await redis_client.client.delete(queue_name)
    
    @staticmethod
    async def subscribe_to_deployment(
        deployment_id: str
    ):
        """
        Subscribe to deployment status updates.
        
        Args:
            deployment_id: Deployment ID
        
        Yields:
            Status update messages
        """
        pubsub = redis_client.pubsub()
        channel = f"deployment:{deployment_id}:status"
        
        await pubsub.subscribe(channel)
        
        try:
            async for message in pubsub.listen():
                if message["type"] == "message":
                    yield json.loads(message["data"])
        finally:
            await pubsub.unsubscribe(channel)
            await pubsub.close()
