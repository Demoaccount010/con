"""
Payment Service

Business logic for Razorpay payment integration.
"""

from typing import Optional
from datetime import datetime, timedelta
from decimal import Decimal
import razorpay
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.models.payment import Payment, PaymentStatus, Subscription
from app.models.plan import Plan
from app.models.user import User
from app.schemas.payment import PaymentWebhook
from app.core.security import verify_razorpay_signature
from app.core.exceptions import PaymentError, PaymentVerificationError


class PaymentService:
    """Service for payment operations with Razorpay."""
    
    def __init__(self, db: AsyncSession):
        self.db = db
        self.client = razorpay.Client(
            auth=(settings.razorpay_key_id, settings.razorpay_key_secret)
        )
    
    async def create_payment_link(
        self,
        user: User,
        plan: Plan,
        description: Optional[str] = None
    ) -> Payment:
        """
        Create a Razorpay payment link for plan purchase.
        
        Returns payment record with link URL.
        """
        amount_paise = int(plan.price * 100)  # Convert to paise
        
        # Create Razorpay order
        order = self.client.order.create({
            "amount": amount_paise,
            "currency": "INR",
            "notes": {
                "user_id": str(user.id),
                "telegram_id": str(user.telegram_id),
                "plan_id": str(plan.id),
                "plan_name": plan.name
            }
        })
        
        # Create payment link
        link = self.client.payment_link.create({
            "amount": amount_paise,
            "currency": "INR",
            "accept_partial": False,
            "description": description or f"Purchase {plan.display_name} Plan",
            "customer": {
                "name": user.display_name,
                "contact": "",  # Optional
                "email": ""     # Optional
            },
            "notify": {
                "sms": False,
                "email": False
            },
            "reminder_enable": False,
            "notes": {
                "user_id": str(user.id),
                "telegram_id": str(user.telegram_id),
                "plan_id": str(plan.id),
                "order_id": order["id"]
            },
            "callback_url": f"{settings.base_domain}/api/webhooks/razorpay/callback",
            "callback_method": "get"
        })
        
        # Create payment record
        payment = Payment(
            user_id=user.id,
            amount=plan.price,
            currency="INR",
            razorpay_order_id=order["id"],
            payment_link_id=link["id"],
            payment_link_url=link["short_url"],
            status=PaymentStatus.PENDING,
            plan_id=plan.id,
            plan_name=plan.display_name,
            description=description or f"Purchase {plan.display_name} Plan"
        )
        
        self.db.add(payment)
        await self.db.commit()
        await self.db.refresh(payment)
        
        return payment
    
    async def verify_payment(
        self,
        order_id: str,
        payment_id: str,
        signature: str
    ) -> Payment:
        """
        Verify Razorpay payment signature and complete payment.
        
        Upgrades user plan on success.
        """
        # Verify signature
        if not verify_razorpay_signature(order_id, payment_id, signature):
            raise PaymentVerificationError("Invalid payment signature")
        
        # Get payment record
        result = await self.db.execute(
            select(Payment)
            .where(Payment.razorpay_order_id == order_id)
        )
        payment = result.scalar_one_or_none()
        
        if not payment:
            raise PaymentError("Payment record not found")
        
        # Update payment
        payment.razorpay_payment_id = payment_id
        payment.razorpay_signature = signature
        payment.status = PaymentStatus.COMPLETED
        payment.completed_at = datetime.utcnow()
        
        await self.db.commit()
        
        # Upgrade user plan
        await self._upgrade_user(payment)
        
        return payment
    
    async def process_webhook(self, webhook: PaymentWebhook) -> Optional[Payment]:
        """
        Process Razorpay webhook event.
        
        Handles payment.captured, payment.failed events.
        """
        event = webhook.event
        
        if event == "payment.captured":
            return await self._handle_payment_captured(webhook)
        elif event == "payment.failed":
            return await self._handle_payment_failed(webhook)
        elif event == "subscription.charged":
            return await self._handle_subscription_charged(webhook)
        elif event == "subscription.cancelled":
            return await self._handle_subscription_cancelled(webhook)
        
        return None
    
    async def _handle_payment_captured(
        self,
        webhook: PaymentWebhook
    ) -> Optional[Payment]:
        """Handle successful payment capture."""
        order_id = webhook.order_id
        payment_id = webhook.payment_id
        
        if not order_id:
            return None
        
        result = await self.db.execute(
            select(Payment)
            .where(Payment.razorpay_order_id == order_id)
        )
        payment = result.scalar_one_or_none()
        
        if not payment:
            return None
        
        if payment.status == PaymentStatus.COMPLETED:
            return payment  # Already processed
        
        payment.razorpay_payment_id = payment_id
        payment.status = PaymentStatus.COMPLETED
        payment.completed_at = datetime.utcnow()
        
        await self.db.commit()
        
        # Upgrade user
        await self._upgrade_user(payment)
        
        return payment
    
    async def _handle_payment_failed(
        self,
        webhook: PaymentWebhook
    ) -> Optional[Payment]:
        """Handle failed payment."""
        order_id = webhook.order_id
        
        if not order_id:
            return None
        
        result = await self.db.execute(
            select(Payment)
            .where(Payment.razorpay_order_id == order_id)
        )
        payment = result.scalar_one_or_none()
        
        if not payment:
            return None
        
        payment.status = PaymentStatus.FAILED
        payment.status_message = "Payment failed"
        
        await self.db.commit()
        
        return payment
    
    async def _handle_subscription_charged(
        self,
        webhook: PaymentWebhook
    ) -> None:
        """Handle subscription charge success."""
        subscription_data = webhook.payload.get("subscription", {}).get("entity", {})
        subscription_id = subscription_data.get("id")
        
        if not subscription_id:
            return
        
        result = await self.db.execute(
            select(Subscription)
            .where(Subscription.razorpay_subscription_id == subscription_id)
        )
        subscription = result.scalar_one_or_none()
        
        if subscription:
            # Extend subscription
            plan = await self.db.get(Plan, subscription.plan_id)
            if plan:
                subscription.expires_at = (
                    subscription.expires_at + timedelta(days=plan.duration_days)
                )
                subscription.is_active = True
                await self.db.commit()
    
    async def _handle_subscription_cancelled(
        self,
        webhook: PaymentWebhook
    ) -> None:
        """Handle subscription cancellation."""
        subscription_data = webhook.payload.get("subscription", {}).get("entity", {})
        subscription_id = subscription_data.get("id")
        
        if not subscription_id:
            return
        
        result = await self.db.execute(
            select(Subscription)
            .where(Subscription.razorpay_subscription_id == subscription_id)
        )
        subscription = result.scalar_one_or_none()
        
        if subscription:
            subscription.is_active = False
            subscription.auto_renew = False
            subscription.cancelled_at = datetime.utcnow()
            await self.db.commit()
    
    async def _upgrade_user(self, payment: Payment) -> None:
        """Upgrade user plan after successful payment."""
        if not payment.plan_id:
            return
        
        plan = await self.db.get(Plan, payment.plan_id)
        if not plan:
            return
        
        user = await self.db.get(User, payment.user_id)
        if not user:
            return
        
        # Update user plan
        user.plan_id = plan.id
        
        # Set/extend subscription
        now = datetime.utcnow()
        if user.subscription_expires_at and user.subscription_expires_at > now:
            user.subscription_expires_at += timedelta(days=plan.duration_days)
        else:
            user.subscription_expires_at = now + timedelta(days=plan.duration_days)
        
        # Create subscription record
        subscription = Subscription(
            user_id=user.id,
            plan_id=plan.id,
            started_at=now,
            expires_at=user.subscription_expires_at,
            is_active=True
        )
        self.db.add(subscription)
        
        await self.db.commit()
    
    async def get_user_payments(
        self,
        user_id: int,
        limit: int = 10
    ) -> list:
        """Get user's payment history."""
        result = await self.db.execute(
            select(Payment)
            .where(Payment.user_id == user_id)
            .order_by(Payment.created_at.desc())
            .limit(limit)
        )
        return list(result.scalars().all())
    
    async def check_expired_subscriptions(self) -> list:
        """
        Check and handle expired subscriptions.
        
        Returns list of expired user IDs.
        """
        now = datetime.utcnow()
        
        result = await self.db.execute(
            select(User)
            .where(
                User.subscription_expires_at < now,
                User.plan_id.isnot(None)
            )
        )
        expired_users = list(result.scalars().all())
        
        # Get free plan
        free_plan = await self.db.execute(
            select(Plan)
            .where(Plan.is_active == True, Plan.price == 0)
            .limit(1)
        )
        free_plan = free_plan.scalar_one_or_none()
        
        expired_ids = []
        for user in expired_users:
            # Downgrade to free plan
            if free_plan:
                user.plan_id = free_plan.id
            expired_ids.append(user.id)
        
        await self.db.commit()
        
        return expired_ids
