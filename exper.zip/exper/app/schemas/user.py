"""
User Schemas
"""

from datetime import datetime
from typing import Optional
from decimal import Decimal
from pydantic import BaseModel, Field


class UserBase(BaseModel):
    """Base user schema."""
    
    telegram_id: int
    username: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None


class UserCreate(UserBase):
    """Schema for creating a user."""
    pass


class UserUpdate(BaseModel):
    """Schema for updating a user."""
    
    username: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    plan_id: Optional[int] = None
    is_admin: Optional[bool] = None
    is_active: Optional[bool] = None
    is_banned: Optional[bool] = None
    ban_reason: Optional[str] = None
    subscription_expires_at: Optional[datetime] = None


class UserResponse(UserBase):
    """Schema for user response."""
    
    id: int
    balance: Decimal
    is_admin: bool
    is_active: bool
    is_banned: bool
    plan_id: Optional[int] = None
    subscription_expires_at: Optional[datetime] = None
    created_at: datetime
    last_active_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True


class UserWithPlan(UserResponse):
    """User response with plan details."""
    
    plan_name: Optional[str] = None
    max_deployments: int = 0
    ram_limit_mb: int = 0
    deployment_count: int = 0
    is_subscription_active: bool = False
