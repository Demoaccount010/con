"""
Plan Schemas
"""

from datetime import datetime
from typing import Optional, List
from decimal import Decimal
from pydantic import BaseModel, Field


class PlanBase(BaseModel):
    """Base plan schema."""
    
    name: str = Field(..., min_length=1, max_length=100)
    display_name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None


class PlanCreate(PlanBase):
    """Schema for creating a plan."""
    
    price: Decimal = Field(default=Decimal("0.00"), ge=0)
    price_yearly: Optional[Decimal] = None
    duration_days: int = Field(default=30, ge=1)
    
    max_deployments: int = Field(default=1, ge=1)
    ram_limit_mb: int = Field(default=512, ge=128)
    cpu_limit: float = Field(default=0.5, ge=0.1, le=8.0)
    storage_limit_mb: int = Field(default=1024, ge=100)
    bandwidth_limit_gb: Optional[int] = None
    
    custom_domain: bool = False
    auto_deploy: bool = False
    priority_support: bool = False
    analytics: bool = False
    
    is_active: bool = True
    is_featured: bool = False
    sort_order: int = Field(default=0)


class PlanUpdate(BaseModel):
    """Schema for updating a plan."""
    
    name: Optional[str] = None
    display_name: Optional[str] = None
    description: Optional[str] = None
    
    price: Optional[Decimal] = None
    price_yearly: Optional[Decimal] = None
    duration_days: Optional[int] = None
    
    max_deployments: Optional[int] = None
    ram_limit_mb: Optional[int] = None
    cpu_limit: Optional[float] = None
    storage_limit_mb: Optional[int] = None
    bandwidth_limit_gb: Optional[int] = None
    
    custom_domain: Optional[bool] = None
    auto_deploy: Optional[bool] = None
    priority_support: Optional[bool] = None
    analytics: Optional[bool] = None
    
    is_active: Optional[bool] = None
    is_featured: Optional[bool] = None
    sort_order: Optional[int] = None


class PlanResponse(PlanBase):
    """Schema for plan response."""
    
    id: int
    price: Decimal
    price_yearly: Optional[Decimal] = None
    duration_days: int
    
    max_deployments: int
    ram_limit_mb: int
    cpu_limit: float
    storage_limit_mb: int
    bandwidth_limit_gb: Optional[int] = None
    
    custom_domain: bool
    auto_deploy: bool
    priority_support: bool
    analytics: bool
    
    is_active: bool
    is_featured: bool
    sort_order: int
    
    # Computed
    formatted_price: str
    ram_display: str
    storage_display: str
    is_free: bool
    
    created_at: datetime
    
    class Config:
        from_attributes = True


class PlanDisplay(BaseModel):
    """Plan display for Telegram."""
    
    id: int
    name: str
    display_name: str
    price: str
    
    deployments: int
    ram: str
    cpu: str
    storage: str
    
    features: List[str]
    is_featured: bool
