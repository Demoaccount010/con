"""
Deployment Schemas
"""

import uuid
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field, HttpUrl


class EnvVarInput(BaseModel):
    """Schema for environment variable input."""
    
    name: str = Field(..., min_length=1, max_length=100)
    value: str
    is_secret: bool = False


class DetectedEnvVar(BaseModel):
    """Schema for detected environment variable."""
    
    name: str
    required: bool = True
    example: Optional[str] = None
    default: Optional[str] = None
    description: Optional[str] = None
    source: Optional[str] = None  # Where it was detected


class DeploymentBase(BaseModel):
    """Base deployment schema."""
    
    name: str = Field(..., min_length=1, max_length=100)
    repo_url: str = Field(..., max_length=500)
    branch: str = Field(default="main", max_length=100)


class DeploymentCreate(DeploymentBase):
    """Schema for creating a deployment."""
    
    env_vars: Optional[List[EnvVarInput]] = None
    memory_limit: Optional[str] = "512m"
    cpu_limit: Optional[float] = 0.5
    auto_deploy: bool = False


class DeploymentUpdate(BaseModel):
    """Schema for updating a deployment."""
    
    name: Optional[str] = None
    branch: Optional[str] = None
    env_vars: Optional[List[EnvVarInput]] = None
    memory_limit: Optional[str] = None
    cpu_limit: Optional[float] = None
    auto_deploy: Optional[bool] = None
    idle_shutdown_enabled: Optional[bool] = None


class DeploymentResponse(DeploymentBase):
    """Schema for deployment response."""
    
    id: uuid.UUID
    user_id: int
    vps_node_id: Optional[int] = None
    container_id: Optional[str] = None
    
    status: str
    status_message: Optional[str] = None
    
    memory_limit: str
    cpu_limit: float
    storage_used: int
    
    subdomain: Optional[str] = None
    full_url: Optional[str] = None
    
    is_healthy: bool
    restart_count: int
    auto_deploy: bool
    
    created_at: datetime
    started_at: Optional[datetime] = None
    last_health_check: Optional[datetime] = None
    
    class Config:
        from_attributes = True


class DeploymentWithLogs(DeploymentResponse):
    """Deployment response with recent logs."""
    
    logs: List[Dict[str, Any]] = []


class DeploymentLogResponse(BaseModel):
    """Schema for deployment log."""
    
    id: int
    level: str
    source: str
    message: str
    created_at: datetime
    
    class Config:
        from_attributes = True


class EnvDetectionResult(BaseModel):
    """Result of environment variable detection."""
    
    detected_vars: List[DetectedEnvVar]
    source_files: List[str]
    has_dockerfile: bool = False
    dockerfile_base_image: Optional[str] = None


class DeploymentQueueTask(BaseModel):
    """Task to be queued for deployment."""
    
    deployment_id: uuid.UUID
    action: str  # build, start, stop, restart, delete
    repo_url: Optional[str] = None
    branch: Optional[str] = None
    env_vars: Optional[Dict[str, str]] = None
    memory_limit: Optional[str] = None
    cpu_limit: Optional[float] = None
