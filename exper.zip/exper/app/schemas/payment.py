"""
Payment Schemas
"""

from datetime import datetime
from typing import Optional
from decimal import Decimal
from pydantic import BaseModel, Field


class PaymentCreate(BaseModel):
    """Schema for creating a payment."""
    
    user_id: int
    plan_id: int
    amount: Decimal


class CreatePaymentLink(BaseModel):
    """Schema for creating a Razorpay payment link."""
    
    plan_id: int
    description: Optional[str] = None


class PaymentResponse(BaseModel):
    """Schema for payment response."""
    
    id: int
    user_id: int
    amount: Decimal
    currency: str
    
    razorpay_order_id: str
    razorpay_payment_id: Optional[str] = None
    payment_link_url: Optional[str] = None
    
    status: str
    status_message: Optional[str] = None
    
    plan_id: Optional[int] = None
    plan_name: Optional[str] = None
    
    created_at: datetime
    completed_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True


class PaymentWebhook(BaseModel):
    """Schema for Razorpay webhook payload."""
    
    event: str
    payload: dict
    
    # Extracted from payload
    @property
    def order_id(self) -> Optional[str]:
        payment = self.payload.get("payment", {}).get("entity", {})
        return payment.get("order_id")
    
    @property
    def payment_id(self) -> Optional[str]:
        payment = self.payload.get("payment", {}).get("entity", {})
        return payment.get("id")
    
    @property
    def amount(self) -> int:
        payment = self.payload.get("payment", {}).get("entity", {})
        return payment.get("amount", 0)
    
    @property
    def status(self) -> str:
        payment = self.payload.get("payment", {}).get("entity", {})
        return payment.get("status", "")


class SubscriptionCreate(BaseModel):
    """Schema for creating a subscription."""
    
    user_id: int
    plan_id: int
    razorpay_subscription_id: Optional[str] = None


class SubscriptionResponse(BaseModel):
    """Schema for subscription response."""
    
    id: int
    user_id: int
    plan_id: int
    
    is_active: bool
    auto_renew: bool
    
    started_at: datetime
    expires_at: datetime
    cancelled_at: Optional[datetime] = None
    
    days_remaining: int
    is_expired: bool
    
    class Config:
        from_attributes = True
