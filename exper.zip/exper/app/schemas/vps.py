"""
VPS Node Schemas
"""

from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field


class VPSNodeBase(BaseModel):
    """Base VPS node schema."""
    
    name: str = Field(..., min_length=1, max_length=100)
    host: str = Field(..., min_length=1, max_length=255)
    port: int = Field(default=22, ge=1, le=65535)
    ssh_user: str = Field(default="root", max_length=100)


class VPSNodeCreate(VPSNodeBase):
    """Schema for creating a VPS node."""
    
    ssh_key_path: Optional[str] = None
    agent_port: int = Field(default=8080, ge=1, le=65535)
    agent_secret: str = Field(..., min_length=16)
    max_containers: int = Field(default=20, ge=1, le=100)
    region: Optional[str] = None
    country: Optional[str] = None
    priority: int = Field(default=0)


class VPSNodeUpdate(BaseModel):
    """Schema for updating a VPS node."""
    
    name: Optional[str] = None
    host: Optional[str] = None
    port: Optional[int] = None
    ssh_user: Optional[str] = None
    ssh_key_path: Optional[str] = None
    agent_port: Optional[int] = None
    is_enabled: Optional[bool] = None
    max_containers: Optional[int] = None
    region: Optional[str] = None
    country: Optional[str] = None
    priority: Optional[int] = None


class VPSNodeResponse(VPSNodeBase):
    """Schema for VPS node response."""
    
    id: int
    is_enabled: bool
    is_online: bool
    max_containers: int
    current_containers: int
    
    total_ram_mb: int
    free_ram_mb: int
    cpu_usage_percent: float
    
    region: Optional[str] = None
    country: Optional[str] = None
    priority: int
    
    last_heartbeat: Optional[datetime] = None
    created_at: datetime
    
    class Config:
        from_attributes = True


class VPSNodeStats(BaseModel):
    """VPS node statistics for admin view."""
    
    id: int
    name: str
    status_emoji: str
    utilization_bar: str
    
    is_online: bool
    is_enabled: bool
    
    containers: str  # "5/20"
    ram: str  # "2.5/8 GB"
    cpu: str  # "45%"
    disk: str  # "50/100 GB"
    
    load_score: float


class VPSHeartbeat(BaseModel):
    """Heartbeat data from VPS agent."""
    
    node_id: int
    agent_secret: str
    
    total_ram_mb: int
    free_ram_mb: int
    cpu_usage_percent: float
    total_disk_gb: int
    free_disk_gb: int
    
    current_containers: int
    container_stats: dict  # Container ID -> stats
    
    docker_version: str
    os_info: str
