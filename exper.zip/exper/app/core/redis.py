"""
Redis Configuration Module

Provides async Redis client for caching and queue operations.
"""

import json
from typing import Any, Optional, List
from datetime import timedelta
import redis.asyncio as redis
from redis.asyncio import Redis

from app.config import settings


class RedisClient:
    """Async Redis client wrapper with utility methods."""
    
    def __init__(self):
        self._client: Optional[Redis] = None
        self._queue_client: Optional[Redis] = None
    
    async def init(self) -> None:
        """Initialize Redis connections."""
        self._client = redis.from_url(
            settings.redis_url,
            encoding="utf-8",
            decode_responses=True
        )
        self._queue_client = redis.from_url(
            f"{settings.redis_url.rsplit('/', 1)[0]}/{settings.redis_queue_db}",
            encoding="utf-8",
            decode_responses=True
        )
    
    async def close(self) -> None:
        """Close Redis connections."""
        if self._client:
            await self._client.close()
        if self._queue_client:
            await self._queue_client.close()
    
    @property
    def client(self) -> Redis:
        """Get main Redis client."""
        if not self._client:
            raise RuntimeError("Redis not initialized. Call init() first.")
        return self._client
    
    @property
    def queue(self) -> Redis:
        """Get queue Redis client."""
        if not self._queue_client:
            raise RuntimeError("Redis not initialized. Call init() first.")
        return self._queue_client
    
    # Cache operations
    async def get(self, key: str) -> Optional[str]:
        """Get value from cache."""
        return await self.client.get(key)
    
    async def set(
        self,
        key: str,
        value: str,
        expire: Optional[int] = None
    ) -> bool:
        """Set value in cache with optional expiration."""
        return await self.client.set(key, value, ex=expire)
    
    async def delete(self, key: str) -> int:
        """Delete key from cache."""
        return await self.client.delete(key)
    
    async def exists(self, key: str) -> bool:
        """Check if key exists."""
        return await self.client.exists(key) > 0
    
    async def set_json(
        self,
        key: str,
        data: Any,
        expire: Optional[int] = None
    ) -> bool:
        """Set JSON data in cache."""
        return await self.set(key, json.dumps(data), expire)
    
    async def get_json(self, key: str) -> Optional[Any]:
        """Get JSON data from cache."""
        data = await self.get(key)
        return json.loads(data) if data else None
    
    # Queue operations
    async def enqueue(self, queue_name: str, task_data: dict) -> int:
        """Add task to queue."""
        return await self.queue.rpush(queue_name, json.dumps(task_data))
    
    async def dequeue(
        self,
        queue_name: str,
        timeout: int = 0
    ) -> Optional[dict]:
        """Get task from queue (blocking)."""
        result = await self.queue.blpop(queue_name, timeout=timeout)
        if result:
            _, data = result
            return json.loads(data)
        return None
    
    async def queue_length(self, queue_name: str) -> int:
        """Get queue length."""
        return await self.queue.llen(queue_name)
    
    # Pub/Sub
    async def publish(self, channel: str, message: dict) -> int:
        """Publish message to channel."""
        return await self.client.publish(channel, json.dumps(message))
    
    def pubsub(self):
        """Get pub/sub instance."""
        return self.client.pubsub()


# Global Redis client instance
redis_client = RedisClient()


async def get_redis() -> RedisClient:
    """Dependency to get Redis client."""
    return redis_client
