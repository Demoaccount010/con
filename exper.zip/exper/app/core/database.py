"""
Database Configuration Module

Provides async SQLAlchemy engine, session management, and base model for SQLite.
"""

from typing import AsyncGenerator
from sqlalchemy.ext.asyncio import (
    AsyncSession,
    AsyncEngine,
    create_async_engine,
    async_sessionmaker
)
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.pool import NullPool

from app.config import settings


class Base(DeclarativeBase):
    """Base class for all database models."""
    pass


# Create async engine with NullPool for SQLite compatibility
engine: AsyncEngine = create_async_engine(
    settings.database_url,
    echo=settings.debug,
    # NullPool is required for SQLite with multiple connections in asyncio
    poolclass=NullPool,
)

# Session factory
async_session_maker = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autocommit=False,
    autoflush=False
)


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """
    Dependency that provides a database session.
    """
    async with async_session_maker() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


async def init_db() -> None:
    """
    Initialize database tables.
    Automatically creates all tables if they don't exist.
    """
    import app.models.user  # noqa
    import app.models.plan  # noqa
    import app.models.vps_node  # noqa
    import app.models.deployment  # noqa
    import app.models.payment  # noqa
    
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def close_db() -> None:
    """Close database connections."""
    await engine.dispose()
