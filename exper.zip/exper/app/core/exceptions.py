"""
Custom Exception Classes

Provides structured error handling with error codes and suggested fixes.
"""

from typing import Optional
from datetime import datetime


class AppException(Exception):
    """Base exception for all application errors."""
    
    error_code: str = "APP_001"
    http_status: int = 500
    
    def __init__(
        self,
        reason: str,
        suggested_fix: Optional[str] = None,
        details: Optional[dict] = None
    ):
        self.reason = reason
        self.suggested_fix = suggested_fix
        self.details = details or {}
        self.timestamp = datetime.utcnow().isoformat() + "Z"
        super().__init__(reason)
    
    def to_dict(self) -> dict:
        """Convert exception to structured response."""
        response = {
            "error_code": self.error_code,
            "reason": self.reason,
            "timestamp": self.timestamp
        }
        if self.suggested_fix:
            response["suggested_fix"] = self.suggested_fix
        if self.details:
            response["details"] = self.details
        return response


# Deployment Errors (DEPLOY_001 - DEPLOY_099)
class DeploymentError(AppException):
    """Base deployment error."""
    error_code = "DEPLOY_001"
    http_status = 400


class DeploymentNotFoundError(DeploymentError):
    """Deployment not found."""
    error_code = "DEPLOY_002"
    http_status = 404
    
    def __init__(self, deployment_id: str):
        super().__init__(
            reason=f"Deployment with ID '{deployment_id}' not found",
            suggested_fix="Check the deployment ID and try again"
        )


class DeploymentLimitReachedError(DeploymentError):
    """User has reached their deployment limit."""
    error_code = "DEPLOY_003"
    http_status = 403
    
    def __init__(self, current: int, limit: int):
        super().__init__(
            reason=f"Deployment limit reached ({current}/{limit})",
            suggested_fix="Upgrade your plan or delete existing deployments",
            details={"current": current, "limit": limit}
        )


class DeploymentBuildError(DeploymentError):
    """Build process failed."""
    error_code = "DEPLOY_004"
    http_status = 400
    
    def __init__(self, reason: str, build_log: Optional[str] = None):
        super().__init__(
            reason=f"Build failed: {reason}",
            suggested_fix="Check your Dockerfile and dependencies",
            details={"build_log": build_log} if build_log else {}
        )


class MissingEnvVarError(DeploymentError):
    """Required environment variable is missing."""
    error_code = "DEPLOY_005"
    http_status = 400
    
    def __init__(self, var_name: str):
        super().__init__(
            reason=f"Required environment variable '{var_name}' is missing",
            suggested_fix=f"Provide a value for '{var_name}' before building"
        )


# Build Errors (BUILD_001 - BUILD_099)
class BuildError(AppException):
    """Base build error."""
    error_code = "BUILD_001"
    http_status = 400


class DockerfileNotFoundError(BuildError):
    """No Dockerfile in repository."""
    error_code = "BUILD_002"
    
    def __init__(self):
        super().__init__(
            reason="No Dockerfile found in repository",
            suggested_fix="Add a Dockerfile to your repository root"
        )


class DependencyError(BuildError):
    """Missing dependency during build."""
    error_code = "BUILD_003"
    
    def __init__(self, dependency: str):
        super().__init__(
            reason=f"Missing dependency: {dependency}",
            suggested_fix=f"Add '{dependency}' to your Dockerfile or requirements"
        )


# Resource Errors (RESOURCE_001 - RESOURCE_099)
class ResourceLimitError(AppException):
    """Base resource limit error."""
    error_code = "RESOURCE_001"
    http_status = 507


class MemoryLimitExceededError(ResourceLimitError):
    """Container exceeded memory limit."""
    error_code = "RESOURCE_002"
    
    def __init__(self, used: str, limit: str):
        super().__init__(
            reason=f"Memory limit exceeded ({used} > {limit})",
            suggested_fix="Optimize your application or upgrade your plan",
            details={"used": used, "limit": limit}
        )


class PortConflictError(ResourceLimitError):
    """Port already in use."""
    error_code = "RESOURCE_003"
    
    def __init__(self, port: int):
        super().__init__(
            reason=f"Port {port} is already in use",
            suggested_fix="Use a different port or stop the conflicting service",
            details={"port": port}
        )


class NoAvailableVPSError(ResourceLimitError):
    """No VPS nodes available for deployment."""
    error_code = "RESOURCE_004"
    http_status = 503
    
    def __init__(self):
        super().__init__(
            reason="No VPS nodes available for deployment",
            suggested_fix="Try again later or contact support"
        )


# Payment Errors (PAYMENT_001 - PAYMENT_099)
class PaymentError(AppException):
    """Base payment error."""
    error_code = "PAYMENT_001"
    http_status = 402


class PaymentVerificationError(PaymentError):
    """Payment verification failed."""
    error_code = "PAYMENT_002"
    
    def __init__(self, reason: str = "Invalid payment signature"):
        super().__init__(
            reason=reason,
            suggested_fix="Contact support if payment was deducted"
        )


class SubscriptionExpiredError(PaymentError):
    """User subscription has expired."""
    error_code = "PAYMENT_003"
    
    def __init__(self):
        super().__init__(
            reason="Your subscription has expired",
            suggested_fix="Renew your subscription to continue using the service"
        )


class InsufficientBalanceError(PaymentError):
    """Insufficient balance for operation."""
    error_code = "PAYMENT_004"
    
    def __init__(self, required: float, available: float):
        super().__init__(
            reason=f"Insufficient balance (required: ₹{required}, available: ₹{available})",
            suggested_fix="Add funds to your account",
            details={"required": required, "available": available}
        )


# VPS Errors (VPS_001 - VPS_099)
class VPSError(AppException):
    """Base VPS error."""
    error_code = "VPS_001"
    http_status = 503


class VPSConnectionError(VPSError):
    """Cannot connect to VPS node."""
    error_code = "VPS_002"
    
    def __init__(self, vps_name: str):
        super().__init__(
            reason=f"Cannot connect to VPS node '{vps_name}'",
            suggested_fix="The node may be temporarily unavailable. Try again later."
        )


class VPSNotFoundError(VPSError):
    """VPS node not found."""
    error_code = "VPS_003"
    http_status = 404
    
    def __init__(self, vps_id: int):
        super().__init__(
            reason=f"VPS node with ID {vps_id} not found",
            suggested_fix="Check the VPS ID and try again"
        )


class ContainerStartError(VPSError):
    """Container failed to start."""
    error_code = "VPS_004"
    http_status = 500
    
    def __init__(self, container_id: str, reason: str):
        super().__init__(
            reason=f"Container failed to start: {reason}",
            suggested_fix="Check your application logs for errors",
            details={"container_id": container_id}
        )


# Authentication Errors (AUTH_001 - AUTH_099)
class AuthenticationError(AppException):
    """Base authentication error."""
    error_code = "AUTH_001"
    http_status = 401


class InvalidTokenError(AuthenticationError):
    """Invalid or expired token."""
    error_code = "AUTH_002"
    
    def __init__(self):
        super().__init__(
            reason="Invalid or expired authentication token",
            suggested_fix="Please log in again"
        )


class UnauthorizedError(AuthenticationError):
    """User not authorized for this action."""
    error_code = "AUTH_003"
    http_status = 403
    
    def __init__(self, action: str = "perform this action"):
        super().__init__(
            reason=f"You are not authorized to {action}",
            suggested_fix="Contact an administrator for access"
        )


class AdminRequiredError(AuthenticationError):
    """Admin privileges required."""
    error_code = "AUTH_004"
    http_status = 403
    
    def __init__(self):
        super().__init__(
            reason="Admin privileges required for this action",
            suggested_fix="This action is restricted to administrators"
        )
