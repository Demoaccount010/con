"""
Application Configuration Module

Handles all environment variables and application settings using Pydantic Settings.
"""

from typing import List
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore"
    )
    
    # Application
    app_name: str = Field(default="BotHostingPlatform")
    app_env: str = Field(default="development")
    debug: bool = Field(default=False)
    secret_key: str = Field(default="change-me-in-production")
    
    # Database
    database_url: str = Field(
        default="postgresql+asyncpg://postgres:postgres@localhost:5432/bot_hosting"
    )
    database_pool_size: int = Field(default=20)
    database_max_overflow: int = Field(default=10)
    
    # Redis
    redis_url: str = Field(default="redis://localhost:6379/0")
    redis_queue_db: int = Field(default=1)
    
    # Telegram Bot
    bot_token: str = Field(default="")
    admin_ids: str = Field(default="")
    
    @property
    def admin_id_list(self) -> List[int]:
        """Parse admin IDs from comma-separated string."""
        if not self.admin_ids:
            return []
        return [int(id.strip()) for id in self.admin_ids.split(",") if id.strip()]
    
    # Razorpay
    razorpay_key_id: str = Field(default="")
    razorpay_key_secret: str = Field(default="")
    razorpay_webhook_secret: str = Field(default="")
    
    # VPS Agent
    agent_secret_key: str = Field(default="")
    master_ws_url: str = Field(default="ws://localhost:8000/ws/agent")
    
    # Docker Defaults
    default_memory_limit: str = Field(default="512m")
    default_cpu_limit: float = Field(default=0.5)
    default_pids_limit: int = Field(default=100)
    
    # Domain
    base_domain: str = Field(default="localhost")
    subdomain_suffix: str = Field(default=".bot.localhost")
    
    # GitHub
    github_webhook_secret: str = Field(default="")
    
    # Monitoring
    health_check_interval: int = Field(default=30)
    idle_shutdown_minutes: int = Field(default=60)


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()


settings = get_settings()
