"""
Plans API Endpoints
"""

from typing import List
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.models.plan import Plan
from app.schemas.plan import PlanCreate, PlanUpdate, PlanResponse


router = APIRouter()


@router.get("/", response_model=List[PlanResponse])
async def get_all_plans(
    active_only: bool = True,
    db: AsyncSession = Depends(get_db)
):
    """Get all plans."""
    query = select(Plan)
    
    if active_only:
        query = query.where(Plan.is_active == True)
    
    query = query.order_by(Plan.sort_order, Plan.price)
    
    result = await db.execute(query)
    plans = list(result.scalars().all())
    
    # Add computed fields
    return [
        PlanResponse(
            **{k: v for k, v in plan.__dict__.items() if not k.startswith('_')},
            formatted_price=plan.formatted_price,
            ram_display=plan.ram_display,
            storage_display=plan.storage_display,
            is_free=plan.is_free
        )
        for plan in plans
    ]


@router.get("/{plan_id}", response_model=PlanResponse)
async def get_plan(
    plan_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Get plan by ID."""
    plan = await db.get(Plan, plan_id)
    
    if not plan:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Plan not found"
        )
    
    return PlanResponse(
        **{k: v for k, v in plan.__dict__.items() if not k.startswith('_')},
        formatted_price=plan.formatted_price,
        ram_display=plan.ram_display,
        storage_display=plan.storage_display,
        is_free=plan.is_free
    )


@router.post("/", response_model=PlanResponse, status_code=status.HTTP_201_CREATED)
async def create_plan(
    data: PlanCreate,
    db: AsyncSession = Depends(get_db)
):
    """Create a new plan (admin only)."""
    # Check for duplicate name
    result = await db.execute(
        select(Plan).where(Plan.name == data.name)
    )
    existing = result.scalar_one_or_none()
    
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Plan with this name already exists"
        )
    
    plan = Plan(**data.model_dump())
    db.add(plan)
    await db.commit()
    await db.refresh(plan)
    
    return PlanResponse(
        **{k: v for k, v in plan.__dict__.items() if not k.startswith('_')},
        formatted_price=plan.formatted_price,
        ram_display=plan.ram_display,
        storage_display=plan.storage_display,
        is_free=plan.is_free
    )


@router.patch("/{plan_id}", response_model=PlanResponse)
async def update_plan(
    plan_id: int,
    data: PlanUpdate,
    db: AsyncSession = Depends(get_db)
):
    """Update a plan (admin only)."""
    plan = await db.get(Plan, plan_id)
    
    if not plan:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Plan not found"
        )
    
    update_data = data.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(plan, key, value)
    
    await db.commit()
    await db.refresh(plan)
    
    return PlanResponse(
        **{k: v for k, v in plan.__dict__.items() if not k.startswith('_')},
        formatted_price=plan.formatted_price,
        ram_display=plan.ram_display,
        storage_display=plan.storage_display,
        is_free=plan.is_free
    )


@router.delete("/{plan_id}")
async def delete_plan(
    plan_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Delete a plan (admin only). Marks as inactive instead of hard delete."""
    plan = await db.get(Plan, plan_id)
    
    if not plan:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Plan not found"
        )
    
    # Soft delete - mark as inactive
    plan.is_active = False
    await db.commit()
    
    return {"message": "Plan deactivated successfully"}


@router.post("/{plan_id}/set-price")
async def set_plan_price(
    plan_id: int,
    price: Decimal,
    db: AsyncSession = Depends(get_db)
):
    """Set plan price (admin only)."""
    plan = await db.get(Plan, plan_id)
    
    if not plan:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Plan not found"
        )
    
    if price < 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Price cannot be negative"
        )
    
    plan.price = price
    await db.commit()
    
    return {
        "message": f"Price updated to ₹{price}",
        "plan_id": plan.id,
        "price": str(plan.price)
    }


@router.post("/{plan_id}/set-resources")
async def set_plan_resources(
    plan_id: int,
    ram_limit_mb: int = None,
    cpu_limit: float = None,
    storage_limit_mb: int = None,
    max_deployments: int = None,
    db: AsyncSession = Depends(get_db)
):
    """Set plan resource limits (admin only)."""
    plan = await db.get(Plan, plan_id)
    
    if not plan:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Plan not found"
        )
    
    if ram_limit_mb is not None:
        plan.ram_limit_mb = ram_limit_mb
    if cpu_limit is not None:
        plan.cpu_limit = cpu_limit
    if storage_limit_mb is not None:
        plan.storage_limit_mb = storage_limit_mb
    if max_deployments is not None:
        plan.max_deployments = max_deployments
    
    await db.commit()
    
    return {
        "message": "Resources updated",
        "plan_id": plan.id,
        "ram": plan.ram_display,
        "cpu": f"{plan.cpu_limit} vCPU",
        "storage": plan.storage_display,
        "deployments": plan.max_deployments
    }
