"""
API Router

Combines all API endpoints.
"""

from fastapi import APIRouter

from app.api.users import router as users_router
from app.api.deployments import router as deployments_router
from app.api.vps import router as vps_router
from app.api.plans import router as plans_router
from app.api.webhooks import router as webhooks_router


api_router = APIRouter()

# Include all routers
api_router.include_router(users_router, prefix="/users", tags=["Users"])
api_router.include_router(deployments_router, prefix="/deployments", tags=["Deployments"])
api_router.include_router(vps_router, prefix="/vps", tags=["VPS Nodes"])
api_router.include_router(plans_router, prefix="/plans", tags=["Plans"])
api_router.include_router(webhooks_router, prefix="/webhooks", tags=["Webhooks"])
