"""
Users API Endpoints
"""

from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.schemas.user import UserCreate, UserResponse, UserUpdate, UserWithPlan
from app.services.user_service import UserService


router = APIRouter()


@router.post("/", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def create_user(
    user_in: UserCreate,
    db: AsyncSession = Depends(get_db)
):
    """Create a new user."""
    service = UserService(db)
    user = await service.get_or_create(
        telegram_id=user_in.telegram_id,
        username=user_in.username,
        first_name=user_in.first_name,
        last_name=user_in.last_name
    )
    return service.to_display(user)


@router.get("/{telegram_id}", response_model=UserWithPlan)
async def get_user_by_telegram_id(
    telegram_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Get user by Telegram ID."""
    service = UserService(db)
    user = await service.get_by_telegram_id(telegram_id)
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    return service.to_display(user)


@router.get("/", response_model=List[UserResponse])
async def get_all_users(
    skip: int = 0,
    limit: int = 100,
    active_only: bool = False,
    db: AsyncSession = Depends(get_db)
):
    """Get all users with pagination (admin only)."""
    service = UserService(db)
    users = await service.get_all_users(skip, limit, active_only)
    return users


@router.patch("/{user_id}", response_model=UserResponse)
async def update_user(
    user_id: int,
    data: UserUpdate,
    db: AsyncSession = Depends(get_db)
):
    """Update user (admin only)."""
    service = UserService(db)
    user = await service.update(user_id, data)
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    return user


@router.post("/{telegram_id}/ban")
async def ban_user(
    telegram_id: int,
    reason: str = None,
    db: AsyncSession = Depends(get_db)
):
    """Ban a user (admin only)."""
    service = UserService(db)
    success = await service.ban_user(telegram_id, reason)
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    return {"message": "User banned successfully"}


@router.post("/{telegram_id}/unban")
async def unban_user(
    telegram_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Unban a user (admin only)."""
    service = UserService(db)
    success = await service.unban_user(telegram_id)
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    return {"message": "User unbanned successfully"}


@router.get("/stats/count")
async def get_user_count(db: AsyncSession = Depends(get_db)):
    """Get total user count."""
    service = UserService(db)
    count = await service.get_user_count()
    return {"count": count}
