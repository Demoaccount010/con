"""
Webhooks API Endpoints

Handles callbacks from Razorpay and GitHub.
"""

import hmac
import hashlib
from fastapi import APIRouter, Depends, HTTPException, status, Request, Header
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import verify_github_signature
from app.config import settings
from app.services.payment_service import PaymentService
from app.services.deployment_service import DeploymentService


router = APIRouter()


@router.post("/razorpay")
async def razorpay_webhook(
    request: Request,
    db: AsyncSession = Depends(get_db)
):
    """
    Handle Razorpay webhook events.
    
    Events handled:
    - payment.captured
    - payment.failed
    - subscription.charged
    - subscription.cancelled
    """
    # Get raw body for signature verification
    body = await request.body()
    
    # Verify webhook signature
    signature = request.headers.get("X-Razorpay-Signature", "")
    
    if settings.razorpay_webhook_secret:
        expected_signature = hmac.new(
            settings.razorpay_webhook_secret.encode(),
            body,
            hashlib.sha256
        ).hexdigest()
        
        if not hmac.compare_digest(expected_signature, signature):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid webhook signature"
            )
    
    # Parse payload
    import json
    payload = json.loads(body)
    
    from app.schemas.payment import PaymentWebhook
    webhook = PaymentWebhook(
        event=payload.get("event", ""),
        payload=payload.get("payload", {})
    )
    
    # Process webhook
    service = PaymentService(db)
    payment = await service.process_webhook(webhook)
    
    return {"status": "ok", "processed": payment is not None}


@router.get("/razorpay/callback")
async def razorpay_callback(
    razorpay_order_id: str,
    razorpay_payment_id: str,
    razorpay_signature: str,
    db: AsyncSession = Depends(get_db)
):
    """
    Handle Razorpay payment callback.
    
    Called after user completes payment.
    """
    service = PaymentService(db)
    
    try:
        payment = await service.verify_payment(
            razorpay_order_id,
            razorpay_payment_id,
            razorpay_signature
        )
        
        # Return HTML page that closes the window and sends message to bot
        return {
            "status": "success",
            "message": "Payment successful! You can close this window.",
            "payment_id": str(payment.id),
            "plan_name": payment.plan_name
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.post("/github/{deployment_id}")
async def github_webhook(
    deployment_id: str,
    request: Request,
    x_hub_signature_256: str = Header(None),
    x_github_event: str = Header(None),
    db: AsyncSession = Depends(get_db)
):
    """
    Handle GitHub webhook for auto-deploy.
    
    Events handled:
    - push (triggers redeploy)
    """
    # Get raw body for signature verification
    body = await request.body()
    
    # Verify signature if configured
    if settings.github_webhook_secret:
        if not x_hub_signature_256:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Missing signature"
            )
        
        if not verify_github_signature(body, x_hub_signature_256):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid signature"
            )
    
    # Only handle push events
    if x_github_event != "push":
        return {"status": "ignored", "reason": f"Event {x_github_event} not handled"}
    
    # Parse payload
    import json
    import uuid
    payload = json.loads(body)
    
    # Get deployment
    try:
        dep_uuid = uuid.UUID(deployment_id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid deployment ID"
        )
    
    service = DeploymentService(db)
    deployment = await service.get_by_id(dep_uuid)
    
    if not deployment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Deployment not found"
        )
    
    # Check if auto-deploy is enabled
    if not deployment.auto_deploy:
        return {"status": "ignored", "reason": "Auto-deploy is disabled"}
    
    # Check branch matches
    pushed_branch = payload.get("ref", "").replace("refs/heads/", "")
    if pushed_branch != deployment.branch:
        return {
            "status": "ignored",
            "reason": f"Push to {pushed_branch}, not {deployment.branch}"
        }
    
    # Update commit hash
    after_commit = payload.get("after", "")[:7]
    deployment.commit_hash = after_commit
    await db.commit()
    
    # Queue rebuild
    from app.services.queue_service import QueueService
    env_vars = await service.get_decrypted_env(dep_uuid)
    
    await QueueService.enqueue_deployment(
        deployment_id=dep_uuid,
        action="build",
        repo_url=deployment.repo_url,
        branch=deployment.branch,
        env_vars=env_vars,
        memory_limit=deployment.memory_limit,
        cpu_limit=deployment.cpu_limit
    )
    
    return {
        "status": "queued",
        "deployment_id": str(dep_uuid),
        "commit": after_commit,
        "message": "Rebuild triggered"
    }
