"""
VPS Nodes API Endpoints
"""

from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.schemas.vps import (
    VPSNodeCreate,
    VPSNodeUpdate,
    VPSNodeResponse,
    VPSNodeStats,
    VPSHeartbeat
)
from app.services.vps_service import VPSService


router = APIRouter()


@router.get("/", response_model=List[VPSNodeResponse])
async def get_all_vps_nodes(
    enabled_only: bool = False,
    online_only: bool = False,
    db: AsyncSession = Depends(get_db)
):
    """Get all VPS nodes (admin only)."""
    service = VPSService(db)
    nodes = await service.get_all(enabled_only, online_only)
    return nodes


@router.get("/stats", response_model=List[VPSNodeStats])
async def get_vps_stats(db: AsyncSession = Depends(get_db)):
    """Get VPS node statistics (admin only)."""
    service = VPSService(db)
    stats = await service.get_stats()
    return stats


@router.get("/{vps_id}", response_model=VPSNodeResponse)
async def get_vps_node(
    vps_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Get VPS node by ID."""
    service = VPSService(db)
    node = await service.get_by_id(vps_id)
    
    if not node:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="VPS node not found"
        )
    
    return node


@router.post("/", response_model=VPSNodeResponse, status_code=status.HTTP_201_CREATED)
async def create_vps_node(
    data: VPSNodeCreate,
    db: AsyncSession = Depends(get_db)
):
    """Create a new VPS node (admin only)."""
    service = VPSService(db)
    
    # Check for duplicate name
    existing = await service.get_by_name(data.name)
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="VPS node with this name already exists"
        )
    
    node = await service.create(data)
    return node


@router.patch("/{vps_id}", response_model=VPSNodeResponse)
async def update_vps_node(
    vps_id: int,
    data: VPSNodeUpdate,
    db: AsyncSession = Depends(get_db)
):
    """Update a VPS node (admin only)."""
    service = VPSService(db)
    node = await service.update(vps_id, data)
    return node


@router.delete("/{vps_id}")
async def delete_vps_node(
    vps_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Delete a VPS node (admin only)."""
    service = VPSService(db)
    
    try:
        await service.delete(vps_id)
        return {"message": "VPS node deleted successfully"}
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.post("/{vps_id}/enable")
async def enable_vps_node(
    vps_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Enable a VPS node (admin only)."""
    service = VPSService(db)
    await service.enable(vps_id)
    return {"message": "VPS node enabled"}


@router.post("/{vps_id}/disable")
async def disable_vps_node(
    vps_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Disable a VPS node (admin only)."""
    service = VPSService(db)
    await service.disable(vps_id)
    return {"message": "VPS node disabled"}


@router.post("/{vps_id}/container-limit")
async def set_container_limit(
    vps_id: int,
    max_containers: int,
    db: AsyncSession = Depends(get_db)
):
    """Set max container limit for VPS (admin only)."""
    if max_containers < 1 or max_containers > 100:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Max containers must be between 1 and 100"
        )
    
    service = VPSService(db)
    node = await service.set_container_limit(vps_id, max_containers)
    
    return {
        "message": f"Container limit set to {max_containers}",
        "node_id": node.id,
        "max_containers": node.max_containers
    }


@router.post("/heartbeat")
async def receive_heartbeat(
    data: VPSHeartbeat,
    db: AsyncSession = Depends(get_db)
):
    """Receive heartbeat from VPS agent."""
    service = VPSService(db)
    
    try:
        node = await service.process_heartbeat(data)
        return {
            "status": "ok",
            "node_id": node.id,
            "message": "Heartbeat received"
        }
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(e)
        )


@router.get("/best-available", response_model=VPSNodeResponse)
async def get_best_available_node(db: AsyncSession = Depends(get_db)):
    """Get the best available VPS node for new deployment."""
    service = VPSService(db)
    node = await service.get_best_node()
    
    if not node:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="No VPS nodes available"
        )
    
    return node
