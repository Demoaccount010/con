"""
Deployments API Endpoints
"""

import uuid
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.schemas.deployment import (
    DeploymentCreate,
    DeploymentUpdate,
    DeploymentResponse,
    DeploymentWithLogs,
    EnvDetectionResult,
    EnvVarInput
)
from app.services.deployment_service import DeploymentService
from app.services.user_service import UserService
from app.services.queue_service import QueueService


router = APIRouter()


@router.post("/", response_model=DeploymentResponse, status_code=status.HTTP_201_CREATED)
async def create_deployment(
    data: DeploymentCreate,
    telegram_id: int = Query(..., description="User's Telegram ID"),
    db: AsyncSession = Depends(get_db)
):
    """Create a new deployment."""
    user_service = UserService(db)
    user = await user_service.get_by_telegram_id(telegram_id)
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    if user.is_banned:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User is banned"
        )
    
    deployment_service = DeploymentService(db)
    deployment = await deployment_service.create(user, data)
    
    return deployment


@router.get("/{deployment_id}", response_model=DeploymentWithLogs)
async def get_deployment(
    deployment_id: uuid.UUID,
    db: AsyncSession = Depends(get_db)
):
    """Get deployment by ID with recent logs."""
    service = DeploymentService(db)
    deployment = await service.get_by_id(deployment_id)
    
    if not deployment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Deployment not found"
        )
    
    logs = await service.get_logs(deployment_id, limit=20)
    
    return DeploymentWithLogs(
        **DeploymentResponse.model_validate(deployment).model_dump(),
        logs=[{
            "id": log.id,
            "level": log.level,
            "source": log.source,
            "message": log.message,
            "created_at": log.created_at.isoformat()
        } for log in logs]
    )


@router.get("/user/{telegram_id}", response_model=List[DeploymentResponse])
async def get_user_deployments(
    telegram_id: int,
    include_deleted: bool = False,
    db: AsyncSession = Depends(get_db)
):
    """Get all deployments for a user."""
    user_service = UserService(db)
    user = await user_service.get_by_telegram_id(telegram_id)
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    deployment_service = DeploymentService(db)
    deployments = await deployment_service.get_by_user(user.id, include_deleted)
    
    return deployments


@router.post("/{deployment_id}/detect-env", response_model=EnvDetectionResult)
async def detect_environment_variables(
    deployment_id: uuid.UUID,
    db: AsyncSession = Depends(get_db)
):
    """Detect environment variables from repository."""
    service = DeploymentService(db)
    result = await service.detect_env_vars(deployment_id)
    return result


@router.post("/{deployment_id}/configure")
async def configure_deployment(
    deployment_id: uuid.UUID,
    env_vars: List[EnvVarInput],
    db: AsyncSession = Depends(get_db)
):
    """Configure environment variables and queue build."""
    service = DeploymentService(db)
    
    # Convert to dict
    env_dict = {var.name: var.value for var in env_vars}
    
    deployment = await service.configure_env(deployment_id, env_dict)
    
    return {
        "message": "Deployment configured and queued for build",
        "deployment_id": str(deployment.id),
        "status": deployment.status.value
    }


@router.post("/{deployment_id}/start")
async def start_deployment(
    deployment_id: uuid.UUID,
    db: AsyncSession = Depends(get_db)
):
    """Start a stopped deployment."""
    service = DeploymentService(db)
    await service.start(deployment_id)
    return {"message": "Deployment start queued"}


@router.post("/{deployment_id}/stop")
async def stop_deployment(
    deployment_id: uuid.UUID,
    db: AsyncSession = Depends(get_db)
):
    """Stop a running deployment."""
    service = DeploymentService(db)
    await service.stop(deployment_id)
    return {"message": "Deployment stop queued"}


@router.post("/{deployment_id}/restart")
async def restart_deployment(
    deployment_id: uuid.UUID,
    db: AsyncSession = Depends(get_db)
):
    """Restart a deployment."""
    service = DeploymentService(db)
    await service.restart(deployment_id)
    return {"message": "Deployment restart queued"}


@router.delete("/{deployment_id}")
async def delete_deployment(
    deployment_id: uuid.UUID,
    db: AsyncSession = Depends(get_db)
):
    """Delete a deployment."""
    service = DeploymentService(db)
    await service.delete(deployment_id)
    return {"message": "Deployment deletion queued"}


@router.get("/{deployment_id}/logs")
async def get_deployment_logs(
    deployment_id: uuid.UUID,
    limit: int = 100,
    db: AsyncSession = Depends(get_db)
):
    """Get deployment logs."""
    service = DeploymentService(db)
    logs = await service.get_logs(deployment_id, limit)
    
    return {
        "deployment_id": str(deployment_id),
        "logs": [{
            "id": log.id,
            "level": log.level,
            "source": log.source,
            "message": log.message,
            "created_at": log.created_at.isoformat()
        } for log in logs]
    }


@router.get("/{deployment_id}/logs/stream")
async def stream_deployment_logs(
    deployment_id: uuid.UUID
):
    """Stream deployment status updates via SSE."""
    async def generate():
        async for update in QueueService.subscribe_to_deployment(str(deployment_id)):
            import json
            yield f"data: {json.dumps(update)}\n\n"
    
    return StreamingResponse(
        generate(),
        media_type="text/event-stream"
    )


@router.patch("/{deployment_id}", response_model=DeploymentResponse)
async def update_deployment(
    deployment_id: uuid.UUID,
    data: DeploymentUpdate,
    db: AsyncSession = Depends(get_db)
):
    """Update deployment settings."""
    service = DeploymentService(db)
    deployment = await service.get_by_id(deployment_id)
    
    if not deployment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Deployment not found"
        )
    
    update_data = data.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        if key != "env_vars":  # Handle env vars separately
            setattr(deployment, key, value)
    
    await db.commit()
    await db.refresh(deployment)
    
    return deployment
