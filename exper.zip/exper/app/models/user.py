"""
User Model

Represents users who interact with the bot hosting platform.
"""

from datetime import datetime
from typing import Optional, List, TYPE_CHECKING
from decimal import Decimal

from sqlalchemy import (
    Integer,
    BigInteger,
    String,
    Boolean,
    DateTime,
    Numeric,
    ForeignKey,
    Text
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base

if TYPE_CHECKING:
    from app.models.deployment import Deployment
    from app.models.plan import Plan
    from app.models.payment import Payment, Subscription


class User(Base):
    """
    User model for bot hosting platform.
    
    Users are identified by their Telegram ID and can have
    subscriptions, deployments, and payment history.
    """
    
    __tablename__ = "users"
    
    # Primary key
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    
    # Telegram information
    telegram_id: Mapped[int] = mapped_column(
        BigInteger,
        unique=True,
        nullable=False,
        index=True
    )
    username: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    first_name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    last_name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    
    # Plan and subscription
    plan_id: Mapped[Optional[int]] = mapped_column(
        Integer,
        ForeignKey("plans.id", ondelete="SET NULL"),
        nullable=True
    )
    
    # Account balance (for prepaid credits)
    balance: Mapped[Decimal] = mapped_column(
        Numeric(10, 2),
        default=Decimal("0.00")
    )
    
    # Admin status
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_banned: Mapped[bool] = mapped_column(Boolean, default=False)
    ban_reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )
    last_active_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    
    # Subscription expiry
    subscription_expires_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime,
        nullable=True
    )
    
    # Relationships
    plan: Mapped[Optional["Plan"]] = relationship(
        "Plan",
        back_populates="users",
        lazy="selectin"
    )
    deployments: Mapped[List["Deployment"]] = relationship(
        "Deployment",
        back_populates="user",
        lazy="selectin",
        cascade="all, delete-orphan"
    )
    payments: Mapped[List["Payment"]] = relationship(
        "Payment",
        back_populates="user",
        lazy="selectin"
    )
    subscriptions: Mapped[List["Subscription"]] = relationship(
        "Subscription",
        back_populates="user",
        lazy="selectin"
    )
    
    def __repr__(self) -> str:
        return f"<User(id={self.id}, telegram_id={self.telegram_id}, username={self.username})>"
    
    @property
    def display_name(self) -> str:
        """Get user display name."""
        if self.username:
            return f"@{self.username}"
        if self.first_name:
            return self.first_name
        return f"User {self.telegram_id}"
    
    @property
    def is_subscription_active(self) -> bool:
        """Check if subscription is still active."""
        if not self.subscription_expires_at:
            return False
        return datetime.utcnow() < self.subscription_expires_at
    
    @property
    def deployment_count(self) -> int:
        """Get number of active deployments."""
        return len([d for d in self.deployments if d.status.value not in ("stopped", "deleted")])
