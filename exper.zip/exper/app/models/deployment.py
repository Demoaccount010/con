"""
Deployment Model

Represents bot deployments on the platform.
"""

import uuid
from datetime import datetime
from typing import Optional, TYPE_CHECKING
from enum import Enum

from sqlalchemy import (
    Integer,
    String,
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Text,
    JSON,
    Enum as SQLEnum
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base

if TYPE_CHECKING:
    from app.models.user import User
    from app.models.vps_node import VPSNode


class DeploymentStatus(str, Enum):
    """Deployment status states."""
    
    PENDING = "pending"           # Waiting in queue
    CLONING = "cloning"           # Cloning repository
    DETECTING = "detecting"       # Detecting environment variables
    CONFIGURING = "configuring"   # Waiting for user config
    BUILDING = "building"         # Building Docker image
    STARTING = "starting"         # Starting container
    RUNNING = "running"           # Container is running
    STOPPED = "stopped"           # Container stopped by user
    FAILED = "failed"             # Deployment failed
    CRASHED = "crashed"           # Container crashed
    DELETED = "deleted"           # Deployment deleted


class Deployment(Base):
    """
    Deployment model for bot instances.
    
    Tracks the full lifecycle of a deployed bot from
    initial request through running/stopped states.
    """
    
    __tablename__ = "deployments"
    
    # Primary key (UUID for external references)
    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4
    )
    
    # Owner
    user_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        index=True
    )
    
    # VPS assignment
    vps_node_id: Mapped[Optional[int]] = mapped_column(
        Integer,
        ForeignKey("vps_nodes.id", ondelete="SET NULL"),
        nullable=True,
        index=True
    )
    
    # Docker container info
    container_id: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    image_id: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    
    # Deployment info
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    repo_url: Mapped[str] = mapped_column(String(500), nullable=False)
    branch: Mapped[str] = mapped_column(String(100), default="main")
    commit_hash: Mapped[Optional[str]] = mapped_column(String(40), nullable=True)
    
    # Status
    status: Mapped[DeploymentStatus] = mapped_column(
        SQLEnum(DeploymentStatus),
        default=DeploymentStatus.PENDING,
        index=True
    )
    status_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # Environment variables (encrypted JSON)
    env_vars_encrypted: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    detected_env_vars: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    
    # Resource limits
    memory_limit: Mapped[str] = mapped_column(String(20), default="512m")
    cpu_limit: Mapped[float] = mapped_column(Float, default=0.5)
    pids_limit: Mapped[int] = mapped_column(Integer, default=100)
    storage_used: Mapped[int] = mapped_column(Integer, default=0)  # MB
    
    # Networking
    subdomain: Mapped[Optional[str]] = mapped_column(
        String(50),
        unique=True,
        nullable=True,
        index=True
    )
    internal_port: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    external_port: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    
    # GitHub integration
    github_webhook_id: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    auto_deploy: Mapped[bool] = mapped_column(Boolean, default=False)
    
    # Monitoring
    restart_count: Mapped[int] = mapped_column(Integer, default=0)
    last_restart_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    last_health_check: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    is_healthy: Mapped[bool] = mapped_column(Boolean, default=True)
    
    # Idle detection
    last_activity_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    idle_shutdown_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    
    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )
    started_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    stopped_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    
    # Relationships
    user: Mapped["User"] = relationship(
        "User",
        back_populates="deployments",
        lazy="selectin"
    )
    vps_node: Mapped[Optional["VPSNode"]] = relationship(
        "VPSNode",
        back_populates="deployments",
        lazy="selectin"
    )
    logs: Mapped[list["DeploymentLog"]] = relationship(
        "DeploymentLog",
        back_populates="deployment",
        lazy="selectin",
        cascade="all, delete-orphan"
    )
    
    def __repr__(self) -> str:
        return f"<Deployment(id={self.id}, name={self.name}, status={self.status.value})>"
    
    @property
    def is_running(self) -> bool:
        """Check if deployment is running."""
        return self.status == DeploymentStatus.RUNNING
    
    @property
    def full_url(self) -> Optional[str]:
        """Get full URL for the deployment."""
        if self.subdomain:
            from app.config import settings
            return f"https://{self.subdomain}{settings.subdomain_suffix}"
        return None


class DeploymentLog(Base):
    """
    Deployment log entries.
    
    Tracks build logs, runtime logs, and system events.
    """
    
    __tablename__ = "deployment_logs"
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    
    deployment_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("deployments.id", ondelete="CASCADE"),
        nullable=False,
        index=True
    )
    
    level: Mapped[str] = mapped_column(String(20), default="info")  # info, warning, error
    source: Mapped[str] = mapped_column(String(50), default="system")  # system, build, runtime
    message: Mapped[str] = mapped_column(Text, nullable=False)
    
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        index=True
    )
    
    # Relationship
    deployment: Mapped["Deployment"] = relationship(
        "Deployment",
        back_populates="logs"
    )
    
    def __repr__(self) -> str:
        return f"<DeploymentLog(id={self.id}, level={self.level})>"
