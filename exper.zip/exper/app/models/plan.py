"""
Plan Model

Represents subscription plans with resource limits.
"""

from datetime import datetime
from typing import Optional, List, TYPE_CHECKING
from decimal import Decimal

from sqlalchemy import (
    Integer,
    String,
    Boolean,
    DateTime,
    Numeric,
    Float,
    Text
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base

if TYPE_CHECKING:
    from app.models.user import User


class Plan(Base):
    """
    Subscription plan model.
    
    Defines resource limits, pricing, and features
    for different subscription tiers.
    """
    
    __tablename__ = "plans"
    
    # Primary key
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    
    # Plan info
    name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    display_name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # Pricing (INR)
    price: Mapped[Decimal] = mapped_column(Numeric(10, 2), default=Decimal("0.00"))
    price_yearly: Mapped[Optional[Decimal]] = mapped_column(
        Numeric(10, 2),
        nullable=True
    )
    
    # Duration
    duration_days: Mapped[int] = mapped_column(Integer, default=30)
    
    # Resource limits
    max_deployments: Mapped[int] = mapped_column(Integer, default=1)
    ram_limit_mb: Mapped[int] = mapped_column(Integer, default=512)
    cpu_limit: Mapped[float] = mapped_column(Float, default=0.5)
    storage_limit_mb: Mapped[int] = mapped_column(Integer, default=1024)
    bandwidth_limit_gb: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    
    # Features
    custom_domain: Mapped[bool] = mapped_column(Boolean, default=False)
    auto_deploy: Mapped[bool] = mapped_column(Boolean, default=False)
    priority_support: Mapped[bool] = mapped_column(Boolean, default=False)
    analytics: Mapped[bool] = mapped_column(Boolean, default=False)
    
    # Status
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    is_featured: Mapped[bool] = mapped_column(Boolean, default=False)
    
    # Display order
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    
    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )
    
    # Relationships
    users: Mapped[List["User"]] = relationship(
        "User",
        back_populates="plan",
        lazy="selectin"
    )
    
    def __repr__(self) -> str:
        return f"<Plan(id={self.id}, name={self.name}, price={self.price})>"
    
    @property
    def is_free(self) -> bool:
        """Check if plan is free."""
        return self.price == Decimal("0.00")
    
    @property
    def formatted_price(self) -> str:
        """Get formatted price string."""
        if self.is_free:
            return "Free"
        return f"₹{self.price}/mo"
    
    @property
    def ram_display(self) -> str:
        """Get RAM limit display string."""
        if self.ram_limit_mb >= 1024:
            return f"{self.ram_limit_mb / 1024:.1f} GB"
        return f"{self.ram_limit_mb} MB"
    
    @property
    def storage_display(self) -> str:
        """Get storage limit display string."""
        if self.storage_limit_mb >= 1024:
            return f"{self.storage_limit_mb / 1024:.1f} GB"
        return f"{self.storage_limit_mb} MB"
    
    def to_display_dict(self) -> dict:
        """Convert to display dictionary for Telegram."""
        features = []
        if self.custom_domain:
            features.append("✅ Custom Domain")
        if self.auto_deploy:
            features.append("✅ Auto Deploy")
        if self.priority_support:
            features.append("✅ Priority Support")
        if self.analytics:
            features.append("✅ Analytics")
        
        return {
            "name": self.display_name,
            "price": self.formatted_price,
            "deployments": self.max_deployments,
            "ram": self.ram_display,
            "storage": self.storage_display,
            "cpu": f"{self.cpu_limit} vCPU",
            "features": features
        }
