"""
VPS Node Model

Represents worker VPS nodes that run deployments.
"""

from datetime import datetime
from typing import Optional, List, TYPE_CHECKING

from sqlalchemy import (
    Integer,
    String,
    Boolean,
    DateTime,
    Float,
    Text
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base

if TYPE_CHECKING:
    from app.models.deployment import Deployment


class VPSNode(Base):
    """
    VPS Node model for worker servers.
    
    Each VPS node runs an agent that manages Docker containers
    and reports resource usage back to the master server.
    """
    
    __tablename__ = "vps_nodes"
    
    # Primary key
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    
    # Node identification
    name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # Connection info
    host: Mapped[str] = mapped_column(String(255), nullable=False)
    port: Mapped[int] = mapped_column(Integer, default=22)
    ssh_user: Mapped[str] = mapped_column(String(100), default="root")
    ssh_key_path: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    
    # Agent connection
    agent_port: Mapped[int] = mapped_column(Integer, default=8080)
    agent_secret: Mapped[str] = mapped_column(String(100), nullable=False)
    
    # Status
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    is_online: Mapped[bool] = mapped_column(Boolean, default=False)
    last_heartbeat: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    
    # Container limits
    max_containers: Mapped[int] = mapped_column(Integer, default=20)
    current_containers: Mapped[int] = mapped_column(Integer, default=0)
    
    # Resource info (updated by agent)
    total_ram_mb: Mapped[int] = mapped_column(Integer, default=0)
    free_ram_mb: Mapped[int] = mapped_column(Integer, default=0)
    total_disk_gb: Mapped[int] = mapped_column(Integer, default=0)
    free_disk_gb: Mapped[int] = mapped_column(Integer, default=0)
    cpu_cores: Mapped[int] = mapped_column(Integer, default=1)
    cpu_usage_percent: Mapped[float] = mapped_column(Float, default=0.0)
    
    # Docker info
    docker_version: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    os_info: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    
    # Region/location (for future geo-distribution)
    region: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    country: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    
    # Priority (higher = preferred for new deployments)
    priority: Mapped[int] = mapped_column(Integer, default=0)
    
    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )
    
    # Relationships
    deployments: Mapped[List["Deployment"]] = relationship(
        "Deployment",
        back_populates="vps_node",
        lazy="selectin"
    )
    
    def __repr__(self) -> str:
        return f"<VPSNode(id={self.id}, name={self.name}, online={self.is_online})>"
    
    @property
    def can_accept_deployment(self) -> bool:
        """Check if node can accept new deployments."""
        return (
            self.is_enabled and
            self.is_online and
            self.current_containers < self.max_containers and
            self.free_ram_mb > 256  # At least 256MB free
        )
    
    @property
    def load_score(self) -> float:
        """
        Calculate load score for deployment selection.
        Lower score = preferred for new deployments.
        """
        if not self.can_accept_deployment:
            return float('inf')
        
        # Weight factors
        container_ratio = self.current_containers / max(self.max_containers, 1)
        ram_ratio = 1 - (self.free_ram_mb / max(self.total_ram_mb, 1))
        cpu_ratio = self.cpu_usage_percent / 100
        
        # Weighted score (lower is better)
        score = (
            container_ratio * 0.4 +
            ram_ratio * 0.4 +
            cpu_ratio * 0.2 -
            (self.priority * 0.01)  # Priority bonus
        )
        
        return score
    
    @property
    def status_emoji(self) -> str:
        """Get status emoji for display."""
        if not self.is_enabled:
            return "⚫"  # Disabled
        if not self.is_online:
            return "🔴"  # Offline
        if self.current_containers >= self.max_containers:
            return "🟡"  # At capacity
        return "🟢"  # Online and available
    
    @property
    def utilization_bar(self) -> str:
        """Get visual utilization bar."""
        ratio = self.current_containers / max(self.max_containers, 1)
        filled = int(ratio * 10)
        empty = 10 - filled
        return "█" * filled + "░" * empty
