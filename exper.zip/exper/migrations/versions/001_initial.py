"""Initial schema

Revision ID: 001_initial
Revises: 
Create Date: 2024-01-01 00:00:00.000000

"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = '001_initial'
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Create plans table
    op.create_table('plans',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('name', sa.String(length=100), nullable=False),
        sa.Column('display_name', sa.String(length=100), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('price', sa.Numeric(precision=10, scale=2), nullable=False, server_default='0.00'),
        sa.Column('price_yearly', sa.Numeric(precision=10, scale=2), nullable=True),
        sa.Column('duration_days', sa.Integer(), nullable=False, server_default='30'),
        sa.Column('max_deployments', sa.Integer(), nullable=False, server_default='1'),
        sa.Column('ram_limit_mb', sa.Integer(), nullable=False, server_default='512'),
        sa.Column('cpu_limit', sa.Float(), nullable=False, server_default='0.5'),
        sa.Column('storage_limit_mb', sa.Integer(), nullable=False, server_default='1024'),
        sa.Column('bandwidth_limit_gb', sa.Integer(), nullable=True),
        sa.Column('custom_domain', sa.Boolean(), nullable=False, server_default='false'),
        sa.Column('auto_deploy', sa.Boolean(), nullable=False, server_default='false'),
        sa.Column('priority_support', sa.Boolean(), nullable=False, server_default='false'),
        sa.Column('analytics', sa.Boolean(), nullable=False, server_default='false'),
        sa.Column('is_active', sa.Boolean(), nullable=False, server_default='true'),
        sa.Column('is_featured', sa.Boolean(), nullable=False, server_default='false'),
        sa.Column('sort_order', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('created_at', sa.DateTime(), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(), server_default=sa.text('now()'), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('name')
    )

    # Create VPS nodes table
    op.create_table('vps_nodes',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('name', sa.String(length=100), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('host', sa.String(length=255), nullable=False),
        sa.Column('port', sa.Integer(), nullable=False, server_default='22'),
        sa.Column('ssh_user', sa.String(length=100), nullable=False, server_default='root'),
        sa.Column('ssh_key_path', sa.String(length=500), nullable=True),
        sa.Column('agent_port', sa.Integer(), nullable=False, server_default='8080'),
        sa.Column('agent_secret', sa.String(length=100), nullable=False),
        sa.Column('is_enabled', sa.Boolean(), nullable=False, server_default='true'),
        sa.Column('is_online', sa.Boolean(), nullable=False, server_default='false'),
        sa.Column('last_heartbeat', sa.DateTime(), nullable=True),
        sa.Column('max_containers', sa.Integer(), nullable=False, server_default='20'),
        sa.Column('current_containers', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('total_ram_mb', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('free_ram_mb', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('total_disk_gb', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('free_disk_gb', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('cpu_cores', sa.Integer(), nullable=False, server_default='1'),
        sa.Column('cpu_usage_percent', sa.Float(), nullable=False, server_default='0.0'),
        sa.Column('docker_version', sa.String(length=50), nullable=True),
        sa.Column('os_info', sa.String(length=200), nullable=True),
        sa.Column('region', sa.String(length=50), nullable=True),
        sa.Column('country', sa.String(length=50), nullable=True),
        sa.Column('priority', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('created_at', sa.DateTime(), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(), server_default=sa.text('now()'), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('name')
    )

    # Create users table
    op.create_table('users',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('telegram_id', sa.BigInteger(), nullable=False),
        sa.Column('username', sa.String(length=255), nullable=True),
        sa.Column('first_name', sa.String(length=255), nullable=True),
        sa.Column('last_name', sa.String(length=255), nullable=True),
        sa.Column('is_admin', sa.Boolean(), nullable=False, server_default='false'),
        sa.Column('is_active', sa.Boolean(), nullable=False, server_default='true'),
        sa.Column('is_banned', sa.Boolean(), nullable=False, server_default='false'),
        sa.Column('ban_reason', sa.Text(), nullable=True),
        sa.Column('plan_id', sa.Integer(), nullable=True),
        sa.Column('balance', sa.Numeric(precision=10, scale=2), nullable=False, server_default='0.00'),
        sa.Column('subscription_expires_at', sa.DateTime(), nullable=True),
        sa.Column('created_at', sa.DateTime(), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(), server_default=sa.text('now()'), nullable=False),
        sa.Column('last_active_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['plan_id'], ['plans.id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('telegram_id')
    )

    # Create deployments table
    op.create_table('deployments',
        sa.Column('id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('vps_node_id', sa.Integer(), nullable=True),
        sa.Column('container_id', sa.String(length=64), nullable=True),
        sa.Column('image_id', sa.String(length=64), nullable=True),
        sa.Column('name', sa.String(length=100), nullable=False),
        sa.Column('repo_url', sa.String(length=500), nullable=False),
        sa.Column('branch', sa.String(length=100), nullable=False, server_default='main'),
        sa.Column('commit_hash', sa.String(length=40), nullable=True),
        sa.Column('status', sa.String(length=20), nullable=False, server_default='pending'),
        sa.Column('status_message', sa.Text(), nullable=True),
        sa.Column('env_vars_encrypted', sa.Text(), nullable=True),
        sa.Column('detected_env_vars', postgresql.JSON(astext_type=sa.Text()), nullable=True),
        sa.Column('memory_limit', sa.String(length=20), nullable=False, server_default='512m'),
        sa.Column('cpu_limit', sa.Float(), nullable=False, server_default='0.5'),
        sa.Column('pids_limit', sa.Integer(), nullable=False, server_default='100'),
        sa.Column('storage_used', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('subdomain', sa.String(length=50), nullable=True),
        sa.Column('internal_port', sa.Integer(), nullable=True),
        sa.Column('external_port', sa.Integer(), nullable=True),
        sa.Column('github_webhook_id', sa.String(length=100), nullable=True),
        sa.Column('auto_deploy', sa.Boolean(), nullable=False, server_default='false'),
        sa.Column('restart_count', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('last_restart_at', sa.DateTime(), nullable=True),
        sa.Column('last_health_check', sa.DateTime(), nullable=True),
        sa.Column('is_healthy', sa.Boolean(), nullable=False, server_default='true'),
        sa.Column('last_activity_at', sa.DateTime(), nullable=True),
        sa.Column('idle_shutdown_enabled', sa.Boolean(), nullable=False, server_default='true'),
        sa.Column('created_at', sa.DateTime(), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(), server_default=sa.text('now()'), nullable=False),
        sa.Column('started_at', sa.DateTime(), nullable=True),
        sa.Column('stopped_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['vps_node_id'], ['vps_nodes.id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('subdomain')
    )

    # Create deployment logs table
    op.create_table('deployment_logs',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('deployment_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('level', sa.String(length=20), nullable=False, server_default='info'),
        sa.Column('source', sa.String(length=50), nullable=False, server_default='system'),
        sa.Column('message', sa.Text(), nullable=False),
        sa.Column('created_at', sa.DateTime(), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['deployment_id'], ['deployments.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id')
    )

    # Create payments table
    op.create_table('payments',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('amount', sa.Numeric(precision=10, scale=2), nullable=False),
        sa.Column('currency', sa.String(length=10), nullable=False, server_default='INR'),
        sa.Column('razorpay_order_id', sa.String(length=100), nullable=False),
        sa.Column('razorpay_payment_id', sa.String(length=100), nullable=True),
        sa.Column('razorpay_signature', sa.String(length=200), nullable=True),
        sa.Column('payment_link_id', sa.String(length=100), nullable=True),
        sa.Column('payment_link_url', sa.String(length=500), nullable=True),
        sa.Column('status', sa.String(length=20), nullable=False, server_default='pending'),
        sa.Column('status_message', sa.Text(), nullable=True),
        sa.Column('plan_id', sa.Integer(), nullable=True),
        sa.Column('plan_name', sa.String(length=100), nullable=True),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(), server_default=sa.text('now()'), nullable=False),
        sa.Column('completed_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('razorpay_order_id')
    )

    # Create subscriptions table
    op.create_table('subscriptions',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('plan_id', sa.Integer(), nullable=False),
        sa.Column('razorpay_subscription_id', sa.String(length=100), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=False, server_default='true'),
        sa.Column('auto_renew', sa.Boolean(), nullable=False, server_default='true'),
        sa.Column('started_at', sa.DateTime(), server_default=sa.text('now()'), nullable=False),
        sa.Column('expires_at', sa.DateTime(), nullable=False),
        sa.Column('cancelled_at', sa.DateTime(), nullable=True),
        sa.Column('created_at', sa.DateTime(), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['plan_id'], ['plans.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('razorpay_subscription_id')
    )

    # Insert default plans
    op.execute("""
        INSERT INTO plans (name, display_name, price, duration_days, max_deployments, ram_limit_mb, cpu_limit, storage_limit_mb, custom_domain, is_active, sort_order)
        VALUES 
            ('free', 'Free Plan', 0.00, 3650, 1, 512, 0.5, 1024, false, true, 1),
            ('starter', 'Starter', 199.00, 30, 3, 1024, 1.0, 2048, false, true, 2),
            ('pro', 'Pro', 499.00, 30, 10, 2048, 2.0, 5120, true, true, 3),
            ('enterprise', 'Enterprise', 1499.00, 30, 50, 8192, 4.0, 20480, true, true, 4)
        ON CONFLICT (name) DO NOTHING;
    """)


def downgrade() -> None:
    op.drop_table('subscriptions')
    op.drop_table('payments')
    op.drop_table('deployment_logs')
    op.drop_table('deployments')
    op.drop_table('users')
    op.drop_table('vps_nodes')
    op.drop_table('plans')
