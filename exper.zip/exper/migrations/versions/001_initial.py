"""Initial schema

Revision ID: 001_initial
Revises: 
Create Date: 2024-01-01 00:00:00.000000

"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = '001_initial'
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Create plans table
    op.create_table('plans',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('name', sa.String(length=50), nullable=False),
        sa.Column('display_name', sa.String(length=100), nullable=True),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('price', sa.Numeric(precision=10, scale=2), nullable=False),
        sa.Column('currency', sa.String(length=3), nullable=False),
        sa.Column('duration_days', sa.Integer(), nullable=False),
        sa.Column('max_deployments', sa.Integer(), nullable=False),
        sa.Column('ram_limit_mb', sa.Integer(), nullable=False),
        sa.Column('cpu_limit', sa.Float(), nullable=False),
        sa.Column('storage_limit_mb', sa.Integer(), nullable=False),
        sa.Column('bandwidth_limit_gb', sa.Integer(), nullable=True),
        sa.Column('custom_domain', sa.Boolean(), nullable=False),
        sa.Column('priority_support', sa.Boolean(), nullable=False),
        sa.Column('auto_restart', sa.Boolean(), nullable=False),
        sa.Column('is_active', sa.Boolean(), nullable=False),
        sa.Column('is_featured', sa.Boolean(), nullable=False),
        sa.Column('sort_order', sa.Integer(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_plans_name'), 'plans', ['name'], unique=True)

    # Create VPS nodes table
    op.create_table('vps_nodes',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('name', sa.String(length=100), nullable=False),
        sa.Column('host', sa.String(length=255), nullable=False),
        sa.Column('agent_port', sa.Integer(), nullable=False),
        sa.Column('agent_secret', sa.Text(), nullable=False),
        sa.Column('agent_version', sa.String(length=20), nullable=True),
        sa.Column('is_enabled', sa.Boolean(), nullable=False),
        sa.Column('is_online', sa.Boolean(), nullable=False),
        sa.Column('status', sa.String(length=20), nullable=False),
        sa.Column('max_containers', sa.Integer(), nullable=False),
        sa.Column('current_containers', sa.Integer(), nullable=False),
        sa.Column('total_memory', sa.Integer(), nullable=False),
        sa.Column('memory_available', sa.Float(), nullable=False),
        sa.Column('memory_used', sa.Float(), nullable=False),
        sa.Column('cpu_usage', sa.Float(), nullable=False),
        sa.Column('disk_total', sa.Integer(), nullable=False),
        sa.Column('disk_free', sa.Integer(), nullable=False),
        sa.Column('docker_version', sa.String(length=50), nullable=True),
        sa.Column('os_info', sa.String(length=100), nullable=True),
        sa.Column('last_heartbeat', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_vps_nodes_name'), 'vps_nodes', ['name'], unique=True)

    # Create users table
    op.create_table('users',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('telegram_id', sa.BigInteger(), nullable=False),
        sa.Column('username', sa.String(length=100), nullable=True),
        sa.Column('first_name', sa.String(length=100), nullable=True),
        sa.Column('last_name', sa.String(length=100), nullable=True),
        sa.Column('language_code', sa.String(length=10), nullable=True),
        sa.Column('is_admin', sa.Boolean(), nullable=False),
        sa.Column('is_banned', sa.Boolean(), nullable=False),
        sa.Column('ban_reason', sa.Text(), nullable=True),
        sa.Column('plan_id', sa.Integer(), nullable=True),
        sa.Column('balance', sa.Numeric(precision=10, scale=2), nullable=False),
        sa.Column('subscription_expires_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('last_activity_at', sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(['plan_id'], ['plans.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_users_telegram_id'), 'users', ['telegram_id'], unique=True)

    # Create deployments table
    op.create_table('deployments',
        sa.Column('id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('vps_node_id', sa.Integer(), nullable=True),
        sa.Column('name', sa.String(length=100), nullable=False),
        sa.Column('status', sa.String(length=20), nullable=False),
        sa.Column('status_message', sa.Text(), nullable=True),
        sa.Column('repo_url', sa.String(length=500), nullable=False),
        sa.Column('branch', sa.String(length=100), nullable=False),
        sa.Column('commit_hash', sa.String(length=40), nullable=True),
        sa.Column('env_vars_encrypted', sa.Text(), nullable=True),
        sa.Column('container_id', sa.String(length=64), nullable=True),
        sa.Column('image_id', sa.String(length=64), nullable=True),
        sa.Column('subdomain', sa.String(length=100), nullable=True),
        sa.Column('port', sa.Integer(), nullable=True),
        sa.Column('memory_limit', sa.String(length=20), nullable=False),
        sa.Column('cpu_limit', sa.Float(), nullable=False),
        sa.Column('memory_used', sa.Float(), nullable=False),
        sa.Column('cpu_used', sa.Float(), nullable=False),
        sa.Column('auto_deploy', sa.Boolean(), nullable=False),
        sa.Column('auto_restart', sa.Boolean(), nullable=False),
        sa.Column('health_status', sa.String(length=20), nullable=False),
        sa.Column('last_health_check', sa.DateTime(timezone=True), nullable=True),
        sa.Column('restart_count', sa.Integer(), nullable=False),
        sa.Column('started_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('stopped_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('last_activity_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('deleted_at', sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.ForeignKeyConstraint(['vps_node_id'], ['vps_nodes.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_deployments_subdomain'), 'deployments', ['subdomain'], unique=True)
    op.create_index(op.f('ix_deployments_container_id'), 'deployments', ['container_id'], unique=False)

    # Create deployment logs table
    op.create_table('deployment_logs',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('deployment_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('level', sa.String(length=10), nullable=False),
        sa.Column('source', sa.String(length=20), nullable=False),
        sa.Column('message', sa.Text(), nullable=False),
        sa.Column('metadata', postgresql.JSON(astext_type=sa.Text()), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['deployment_id'], ['deployments.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_deployment_logs_deployment_id'), 'deployment_logs', ['deployment_id'], unique=False)

    # Create payments table
    op.create_table('payments',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('plan_id', sa.Integer(), nullable=True),
        sa.Column('amount', sa.Numeric(precision=10, scale=2), nullable=False),
        sa.Column('currency', sa.String(length=3), nullable=False),
        sa.Column('status', sa.String(length=20), nullable=False),
        sa.Column('razorpay_order_id', sa.String(length=100), nullable=True),
        sa.Column('razorpay_payment_id', sa.String(length=100), nullable=True),
        sa.Column('razorpay_signature', sa.String(length=200), nullable=True),
        sa.Column('payment_link_id', sa.String(length=100), nullable=True),
        sa.Column('payment_link_url', sa.String(length=500), nullable=True),
        sa.Column('notes', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('completed_at', sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(['plan_id'], ['plans.id'], ),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )

    # Create subscriptions table
    op.create_table('subscriptions',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('plan_id', sa.Integer(), nullable=False),
        sa.Column('status', sa.String(length=20), nullable=False),
        sa.Column('razorpay_subscription_id', sa.String(length=100), nullable=True),
        sa.Column('razorpay_plan_id', sa.String(length=100), nullable=True),
        sa.Column('current_start', sa.DateTime(timezone=True), nullable=True),
        sa.Column('current_end', sa.DateTime(timezone=True), nullable=True),
        sa.Column('next_billing_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('cancelled_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(['plan_id'], ['plans.id'], ),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )

    # Insert default plans
    op.execute("""
        INSERT INTO plans (name, display_name, price, currency, duration_days, max_deployments, 
            ram_limit_mb, cpu_limit, storage_limit_mb, custom_domain, priority_support, 
            auto_restart, is_active, is_featured, sort_order)
        VALUES 
            ('free', 'Free Plan', 0, 'INR', 0, 1, 512, 0.5, 1024, false, false, false, true, false, 1),
            ('starter', 'Starter', 99, 'INR', 30, 3, 1024, 1, 2048, false, false, true, true, false, 2),
            ('pro', 'Pro', 299, 'INR', 30, 10, 2048, 2, 5120, true, true, true, true, true, 3),
            ('enterprise', 'Enterprise', 999, 'INR', 30, 50, 4096, 4, 10240, true, true, true, true, false, 4)
    """)


def downgrade() -> None:
    op.drop_table('subscriptions')
    op.drop_table('payments')
    op.drop_index(op.f('ix_deployment_logs_deployment_id'), table_name='deployment_logs')
    op.drop_table('deployment_logs')
    op.drop_index(op.f('ix_deployments_container_id'), table_name='deployments')
    op.drop_index(op.f('ix_deployments_subdomain'), table_name='deployments')
    op.drop_table('deployments')
    op.drop_index(op.f('ix_users_telegram_id'), table_name='users')
    op.drop_table('users')
    op.drop_index(op.f('ix_vps_nodes_name'), table_name='vps_nodes')
    op.drop_table('vps_nodes')
    op.drop_index(op.f('ix_plans_name'), table_name='plans')
    op.drop_table('plans')
