#!/usr/bin/env python3
"""
SMILE AI Agent - Test Suite

Comprehensive tests for all agent components.
"""

import asyncio
import pytest
import json
import tempfile
import shutil
from pathlib import Path
from datetime import datetime
from unittest.mock import Mock, AsyncMock, patch

# Test fixtures directory
TEST_DIR = Path(__file__).parent
PROJECT_DIR = TEST_DIR.parent


# ═══════════════════════════════════════════════════════════════════════════════
# FIXTURES
# ═══════════════════════════════════════════════════════════════════════════════

@pytest.fixture
def temp_dir():
    """Create temporary directory for tests"""
    temp = tempfile.mkdtemp()
    yield Path(temp)
    shutil.rmtree(temp)


@pytest.fixture
def mock_agent():
    """Create a mock agent for testing"""
    agent = Mock()
    agent.identity = Mock()
    agent.identity.name = "TestSmile"
    agent.identity.version = "1.0.0-test"
    agent.identity.owner = Mock()
    agent.identity.owner.name = "TestUser"
    agent.identity.owner.relationship = "tester"
    agent.identity.owner.preferences = {"communication_style": "casual"}
    agent.identity.owner.permission_levels = {
        "web_access": True,
        "file_read": True,
        "file_write": True,
        "execute_code": False
    }
    agent.loaded_tools = {}
    agent.active_plugins = {}
    return agent


@pytest.fixture
async def memory_system(temp_dir):
    """Create a real memory system for testing"""
    import sys
    sys.path.insert(0, str(PROJECT_DIR))
    
    from core.memory_system import MemorySystem
    
    mem = MemorySystem(temp_dir / "memory")
    await mem.initialize()
    yield mem


# ═══════════════════════════════════════════════════════════════════════════════
# MEMORY SYSTEM TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestMemorySystem:
    """Tests for the memory system"""
    
    @pytest.mark.asyncio
    async def test_short_term_memory(self, memory_system):
        """Test short-term memory operations"""
        # Store message
        await memory_system.store_short_term({
            "role": "user",
            "content": "Hello, this is a test"
        })
        
        # Retrieve
        context = await memory_system.get_short_term_context(10)
        
        assert len(context) == 1
        assert context[0]["role"] == "user"
        assert "test" in context[0]["content"]
    
    @pytest.mark.asyncio
    async def test_long_term_memory(self, memory_system):
        """Test long-term memory operations"""
        # Store
        key = await memory_system.store_long_term(
            "test_fact",
            {"fact": "The sky is blue"},
            importance=0.8,
            tags=["science", "nature"]
        )
        
        assert key == "test_fact"
        
        # Retrieve
        content = await memory_system.retrieve_long_term("test_fact")
        
        assert content["fact"] == "The sky is blue"
    
    @pytest.mark.asyncio
    async def test_memory_search(self, memory_system):
        """Test memory search functionality"""
        # Store some memories
        await memory_system.store_long_term("python_info", {"topic": "Python programming language"})
        await memory_system.store_long_term("java_info", {"topic": "Java programming language"})
        await memory_system.store_long_term("cooking_info", {"topic": "Italian cooking recipes"})
        
        # Search
        results = await memory_system.search_relevant("programming", limit=5)
        
        assert len(results) >= 1
        # Should find programming-related memories
        topics = [r.get("content", {}).get("topic", "") for r in results]
        assert any("programming" in t.lower() for t in topics)
    
    @pytest.mark.asyncio
    async def test_skill_memory(self, memory_system):
        """Test skill memory operations"""
        skill_data = {
            "name": "test_skill",
            "description": "A test skill",
            "function": "def test(): pass"
        }
        
        await memory_system.store_skill("skill_1", skill_data)
        
        # List skills
        skills = await memory_system.list_skills()
        
        assert len(skills) == 1
        assert skills[0]["name"] == "test_skill"
    
    @pytest.mark.asyncio
    async def test_goal_memory(self, memory_system):
        """Test goal memory operations"""
        goal_id = await memory_system.store_goal(
            "Learn to cook",
            priority=4,
            subtasks=[{"name": "Buy ingredients"}, {"name": "Follow recipe"}]
        )
        
        assert goal_id is not None
        
        # Get pending goals
        goals = await memory_system.get_pending_goals()
        
        assert len(goals) == 1
        assert goals[0].description == "Learn to cook"
    
    @pytest.mark.asyncio
    async def test_memory_persistence(self, temp_dir):
        """Test that memory persists across restarts"""
        import sys
        sys.path.insert(0, str(PROJECT_DIR))
        from core.memory_system import MemorySystem
        
        # First session
        mem1 = MemorySystem(temp_dir / "memory")
        await mem1.initialize()
        await mem1.store_long_term("persistent_key", {"value": "persistent_data"})
        await mem1.persist_all()
        
        # Second session
        mem2 = MemorySystem(temp_dir / "memory")
        await mem2.initialize()
        
        result = await mem2.retrieve_long_term("persistent_key")
        
        assert result is not None
        assert result["value"] == "persistent_data"


# ═══════════════════════════════════════════════════════════════════════════════
# ROUTER ENGINE TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestRouterEngine:
    """Tests for the router engine"""
    
    @pytest.mark.asyncio
    async def test_greeting_routing(self, mock_agent):
        """Test that greetings are routed correctly"""
        import sys
        sys.path.insert(0, str(PROJECT_DIR))
        from core.router_engine import RouterEngine
        
        router = RouterEngine(mock_agent)
        await router.initialize()
        
        route = await router.route("Hello!")
        
        assert route.route_type.value == "instant"
        assert route.category.value == "greeting"
    
    @pytest.mark.asyncio
    async def test_code_routing(self, mock_agent):
        """Test that code requests are routed to thinking"""
        import sys
        sys.path.insert(0, str(PROJECT_DIR))
        from core.router_engine import RouterEngine
        
        router = RouterEngine(mock_agent)
        await router.initialize()
        
        route = await router.route("Write a Python function to sort a list")
        
        assert route.route_type.value == "thinking"
        assert route.category.value == "code"
    
    @pytest.mark.asyncio
    async def test_search_routing(self, mock_agent):
        """Test that search requests are routed correctly"""
        import sys
        sys.path.insert(0, str(PROJECT_DIR))
        from core.router_engine import RouterEngine
        
        router = RouterEngine(mock_agent)
        await router.initialize()
        
        route = await router.route("Search for the latest AI news")
        
        assert route.route_type.value == "tool_call"
        assert route.category.value == "search"


# ═══════════════════════════════════════════════════════════════════════════════
# THINKING ENGINE TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestThinkingEngine:
    """Tests for the thinking engine"""
    
    @pytest.mark.asyncio
    async def test_thought_chain_creation(self, mock_agent):
        """Test that thought chains are created"""
        import sys
        sys.path.insert(0, str(PROJECT_DIR))
        from core.thinking_engine import ThinkingEngine
        
        mock_agent.memory_system = None
        mock_agent.api_manager = None
        
        thinking = ThinkingEngine(mock_agent)
        await thinking.initialize()
        
        # This will fail at API call but should create chain structure
        result = await thinking.think("What is 2+2?", depth=1)
        
        assert "confidence" in result
        assert "reasoning_mode" in result
    
    @pytest.mark.asyncio
    async def test_reasoning_mode_selection(self, mock_agent):
        """Test that appropriate reasoning modes are selected"""
        import sys
        sys.path.insert(0, str(PROJECT_DIR))
        from core.thinking_engine import ThinkingEngine, ReasoningMode
        
        thinking = ThinkingEngine(mock_agent)
        
        # Comparative
        mode = await thinking._select_reasoning_mode("Compare Python and Java")
        assert mode == ReasoningMode.COMPARATIVE
        
        # Causal
        mode = await thinking._select_reasoning_mode("Why does the sun rise in the east?")
        assert mode == ReasoningMode.CAUSAL
        
        # Analytical
        mode = await thinking._select_reasoning_mode("Analyze this complex problem with many factors")
        assert mode == ReasoningMode.ANALYTICAL


# ═══════════════════════════════════════════════════════════════════════════════
# TOOL MANAGER TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestToolManager:
    """Tests for the tool manager"""
    
    @pytest.mark.asyncio
    async def test_tool_registration(self, mock_agent):
        """Test tool registration"""
        import sys
        sys.path.insert(0, str(PROJECT_DIR))
        from core.tool_manager import ToolManager, ToolDefinition, ToolCategory
        
        mock_agent.plugin_system = None
        
        manager = ToolManager(mock_agent)
        await manager.initialize()
        
        # Register a custom tool
        async def my_tool(x: int, y: int) -> int:
            return x + y
        
        manager.register_tool(ToolDefinition(
            name="add_numbers",
            description="Add two numbers",
            function=my_tool,
            category=ToolCategory.MATH,
            parameters={
                "x": {"type": "int", "required": True},
                "y": {"type": "int", "required": True}
            },
            returns={"type": "int"}
        ))
        
        # Check it's registered
        tools = manager.list_tools()
        names = [t["name"] for t in tools]
        
        assert "add_numbers" in names
    
    @pytest.mark.asyncio
    async def test_tool_execution(self, mock_agent):
        """Test tool execution"""
        import sys
        sys.path.insert(0, str(PROJECT_DIR))
        from core.tool_manager import ToolManager, ToolDefinition, ToolCategory
        
        mock_agent.plugin_system = None
        
        manager = ToolManager(mock_agent)
        await manager.initialize()
        
        # Use built-in echo tool
        result = await manager.call_tool("echo", {"message": "test"})
        
        assert result.status.value == "success"
        assert "test" in result.result
    
    @pytest.mark.asyncio
    async def test_tool_caching(self, mock_agent):
        """Test tool result caching"""
        import sys
        sys.path.insert(0, str(PROJECT_DIR))
        from core.tool_manager import ToolManager
        
        mock_agent.plugin_system = None
        
        manager = ToolManager(mock_agent)
        await manager.initialize()
        
        # Call get_time twice
        result1 = await manager.call_tool("get_time", {})
        result2 = await manager.call_tool("get_time", {})
        
        # Second should be cached
        assert result2.cached == True


# ═══════════════════════════════════════════════════════════════════════════════
# PLUGIN SYSTEM TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestPluginSystem:
    """Tests for the plugin system"""
    
    @pytest.mark.asyncio
    async def test_plugin_discovery(self, mock_agent, temp_dir):
        """Test plugin discovery"""
        import sys
        sys.path.insert(0, str(PROJECT_DIR))
        from core.plugin_system import PluginSystem
        
        plugins_dir = temp_dir / "plugins"
        plugins_dir.mkdir()
        
        # Create a test plugin
        test_plugin_dir = plugins_dir / "test_plugin"
        test_plugin_dir.mkdir()
        
        (test_plugin_dir / "plugin.json").write_text(json.dumps({
            "name": "test_plugin",
            "version": "1.0.0",
            "description": "Test plugin",
            "author": "Test",
            "plugin_type": "utility",
            "dependencies": [],
            "permissions": [],
            "entry_point": "plugin"
        }))
        
        (test_plugin_dir / "__init__.py").write_text("")
        (test_plugin_dir / "plugin.py").write_text("""
from core.plugin_system import BasePlugin, PluginMetadata, PluginType

class TestPlugin(BasePlugin):
    METADATA = PluginMetadata(
        name="test_plugin",
        version="1.0.0",
        description="Test plugin",
        author="Test",
        plugin_type=PluginType.UTILITY
    )
    
    async def initialize(self):
        self._initialized = True
        return True
    
    async def shutdown(self):
        return True
""")
        
        system = PluginSystem(plugins_dir, mock_agent)
        await system.initialize()
        
        # Should discover the plugin
        assert "test_plugin" in system.plugins


# ═══════════════════════════════════════════════════════════════════════════════
# INTEGRATION TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestIntegration:
    """Integration tests for complete workflows"""
    
    @pytest.mark.asyncio
    async def test_memory_and_search_integration(self, temp_dir):
        """Test memory storage and search together"""
        import sys
        sys.path.insert(0, str(PROJECT_DIR))
        from core.memory_system import MemorySystem
        
        mem = MemorySystem(temp_dir / "memory")
        await mem.initialize()
        
        # Store various memories
        await mem.store_long_term("fact1", {"topic": "Python", "info": "Python is a programming language"})
        await mem.store_long_term("fact2", {"topic": "Machine Learning", "info": "ML uses algorithms to learn"})
        await mem.store_long_term("fact3", {"topic": "Python ML", "info": "Python is used for ML"})
        
        # Search should find relevant memories
        results = await mem.search_relevant("Python machine learning")
        
        assert len(results) >= 1
    
    @pytest.mark.asyncio
    async def test_full_conversation_flow(self, temp_dir, mock_agent):
        """Test a full conversation flow"""
        import sys
        sys.path.insert(0, str(PROJECT_DIR))
        from core.memory_system import MemorySystem
        from core.router_engine import RouterEngine
        
        # Setup memory
        mem = MemorySystem(temp_dir / "memory")
        await mem.initialize()
        mock_agent.memory_system = mem
        
        # Setup router
        router = RouterEngine(mock_agent)
        await router.initialize()
        
        # Simulate conversation
        messages = [
            "Hello!",
            "What can you help me with?",
            "Thanks!"
        ]
        
        for msg in messages:
            # Store in memory
            await mem.store_short_term({"role": "user", "content": msg})
            
            # Route
            route = await router.route(msg)
            
            # Simulate response
            await mem.store_short_term({"role": "assistant", "content": f"Response to: {msg}"})
        
        # Check conversation history
        context = await mem.get_short_term_context(10)
        
        assert len(context) == 6  # 3 user + 3 assistant


# ═══════════════════════════════════════════════════════════════════════════════
# RUN TESTS
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    pytest.main([__file__, "-v", "--asyncio-mode=auto"])