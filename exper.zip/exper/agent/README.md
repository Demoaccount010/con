# VPS Agent Worker
This folder contains the code for the worker agent that runs on your VPS nodes to manage Docker containers.

## Prerequisites
- A VPS with Ubuntu/Debian (recommended)
- Root access (or sudo)
- Port 8000 (or your chosen port) open

## Deployment Steps

### 1. Prepare the Files
Zip the contents of this `agent/` folder (including `deploy_worker.sh` and `requirements.txt`).
```bash
# Example if you are on Linux/Mac
zip -r agent.zip agent/
```

### 2. Upload to VPS
Upload the zip file to your VPS server.
```bash
scp agent.zip root@your-vps-ip:/root/
```

### 3. Run Deployment Script
SSH into your VPS and run the script.
```bash
# Unzip
unzip agent.zip
cd agent

# Make script executable
chmod +x deploy_worker.sh

# Run (Replace placeholders)
# Format: ./deploy_worker.sh <API_URL> <SECRET_KEY> [NODE_NAME]
./deploy_worker.sh "http://YOUR_MAIN_SERVER_IP:8000" "YOUR_SECRET_KEY" "vps-01"
```

### 4. Verify
After the script finishes:
```bash
systemctl status vps-agent
```
It should be "active (running)". The main bot should now see this node as "Online" in the Admin Panel.

## Troubleshooting
- **Logs:** `journalctl -u vps-agent -f`
- **Docker:** Ensure Docker is running `systemctl status docker`
- **Connection:** Check if VPS can reach Main Server `curl http://YOUR_MAIN_SERVER_IP:8000/docs`
