"""
VPS Agent Main Entry Point

Runs on each VPS node to:
- Send heartbeats to master
- Process deployment tasks
- Manage Docker containers
- Monitor resources
"""

import asyncio
import logging
import signal
import sys
from datetime import datetime

import httpx
import psutil

from agent.config import agent_settings
from agent.docker_manager import DockerManager
from agent.task_processor import TaskProcessor


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class VPSAgent:
    """Main VPS Agent class."""
    
    def __init__(self):
        self.running = True
        self.docker = DockerManager()
        self.processor = TaskProcessor(self.docker)
        self.http_client: httpx.AsyncClient | None = None
    
    async def start(self):
        """Start the agent."""
        logger.info(f"Starting VPS Agent: {agent_settings.agent_name}")
        
        # Initialize HTTP client
        self.http_client = httpx.AsyncClient(
            base_url=agent_settings.master_api_url,
            timeout=30.0
        )
        
        # Initialize Docker
        self.docker.connect()
        logger.info("Docker connected")
        
        # Ensure network exists
        self.docker.ensure_network(agent_settings.container_network)
        
        # Start tasks
        await asyncio.gather(
            self.heartbeat_loop(),
            self.task_processing_loop(),
            self.health_check_loop()
        )
    
    async def stop(self):
        """Stop the agent gracefully."""
        logger.info("Stopping agent...")
        self.running = False
        
        if self.http_client:
            await self.http_client.aclose()
    
    async def heartbeat_loop(self):
        """Send periodic heartbeats to master."""
        while self.running:
            try:
                await self.send_heartbeat()
            except Exception as e:
                logger.error(f"Heartbeat failed: {e}")
            
            await asyncio.sleep(agent_settings.heartbeat_interval)
    
    async def send_heartbeat(self):
        """Send heartbeat with current stats."""
        # Gather stats
        memory = psutil.virtual_memory()
        cpu_percent = psutil.cpu_percent(interval=1)
        disk = psutil.disk_usage('/')
        
        # Get container info
        containers = self.docker.list_containers()
        running_containers = [c for c in containers if c.get("status") == "running"]
        
        heartbeat_data = {
            "node_id": 1,  # Default node ID for first VPS
            "agent_secret": agent_settings.agent_secret,
            "total_ram_mb": memory.total // (1024 * 1024),
            "free_ram_mb": memory.available // (1024 * 1024),
            "cpu_usage_percent": cpu_percent,
            "total_disk_gb": disk.total // (1024 * 1024 * 1024),
            "free_disk_gb": disk.free // (1024 * 1024 * 1024),
            "current_containers": len(running_containers),
            "container_stats": {},  # Required by schema
            "docker_version": self.docker.client.version().get("Version", "unknown"),
            "os_info": f"{sys.platform} {psutil.cpu_count()} cores"
        }
        
        response = await self.http_client.post(
            "/api/vps/heartbeat",
            json=heartbeat_data
        )
        
        if response.status_code == 200:
            logger.debug(f"Heartbeat sent: {len(running_containers)} containers")
        else:
            logger.warning(f"Heartbeat response: {response.status_code}")
    
    async def task_processing_loop(self):
        """Process deployment tasks from queue."""
        while self.running:
            try:
                # Poll for tasks
                response = await self.http_client.get(
                    f"/api/queue/dequeue",
                    params={"agent_name": agent_settings.agent_name}
                )
                
                if response.status_code == 200:
                    task = response.json()
                    if task:
                        logger.info(f"Processing task: {task.get('deployment_id')}")
                        await self.processor.process_task(task, self.http_client)
                
            except Exception as e:
                logger.error(f"Task processing error: {e}")
            
            await asyncio.sleep(5)  # Poll every 5 seconds
    
    async def health_check_loop(self):
        """Periodic health checks for containers."""
        while self.running:
            try:
                await self.check_container_health()
            except Exception as e:
                logger.error(f"Health check error: {e}")
            
            await asyncio.sleep(60)  # Check every minute
    
    async def check_container_health(self):
        """Check health of all managed containers."""
        containers = self.docker.list_containers()
        
        for container in containers:
            container_id = container.get("id")
            name = container.get("name")
            status = container.get("status")
            
            # Check if container crashed
            if status == "exited":
                # Get exit code
                exit_code = container.get("exit_code", 0)
                
                if exit_code != 0:
                    logger.warning(f"Container {name} exited with code {exit_code}")
                    
                    # Check if auto-restart is enabled
                    # (Would need to query master for deployment settings)
                    # For now, just log it
            
            elif status == "running":
                # Get container stats
                stats = self.docker.get_container_stats(container_id)
                
                if stats:
                    # Report stats to master
                    await self.http_client.patch(
                        f"/api/deployments/{name}/stats",
                        json={
                            "memory_used": stats.get("memory_usage", 0),
                            "cpu_used": stats.get("cpu_percent", 0),
                            "health_status": "healthy"
                        }
                    )


def signal_handler(agent: VPSAgent):
    """Handle shutdown signals."""
    def handler(signum, frame):
        logger.info(f"Received signal {signum}")
        asyncio.create_task(agent.stop())
    return handler


async def main():
    """Main entry point."""
    agent = VPSAgent()
    
    # Setup signal handlers
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, signal_handler(agent))
    
    await agent.start()


if __name__ == "__main__":
    asyncio.run(main())
