"""
VPS Agent Configuration
"""

from pydantic_settings import BaseSettings, SettingsConfigDict


class AgentSettings(BaseSettings):
    """Agent configuration from environment."""
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore"
    )
    
    # Agent Identity
    agent_name: str = "vps-agent-1"
    agent_secret: str = ""
    
    # Master API
    master_api_url: str = "http://localhost:8000"
    
    # Heartbeat
    heartbeat_interval: int = 30  # seconds
    
    # Docker
    docker_socket: str = "unix:///var/run/docker.sock"
    
    # Resource Limits
    max_containers: int = 10
    container_network: str = "bot_network"
    
    # Build
    build_timeout: int = 600  # 10 minutes
    clone_timeout: int = 120  # 2 minutes
    
    # Storage
    workspace_path: str = "/opt/bothost/workspaces"
    logs_path: str = "/opt/bothost/logs"


agent_settings = AgentSettings()
