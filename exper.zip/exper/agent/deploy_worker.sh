#!/bin/bash

# VPS Worker Deployment Script
# Usage: ./deploy_worker.sh <MASTER_API_URL> <AGENT_SECRET> [AGENT_NAME]

set -e

# Configuration
MASTER_API_URL=$1
AGENT_SECRET=$2
AGENT_NAME=${3:-"vps-node-$(hostname)"}
INSTALL_DIR="/opt/bothost"
USER="root"

# Colors
GREEN='\033[0;32m'
NC='\033[0m'

echo -e "${GREEN}Starting VPS Worker Deployment...${NC}"

if [ -z "$MASTER_API_URL" ] || [ -z "$AGENT_SECRET" ]; then
    echo "Usage: $0 <MASTER_API_URL> <AGENT_SECRET> [AGENT_NAME]"
    exit 1
fi

# 1. Install System Dependencies
echo -e "${GREEN}Installing dependencies...${NC}"
apt-get update
apt-get install -y python3 python3-pip python3-venv docker.io git

# 2. Setup Directory Structure
echo -e "${GREEN}Setting up directories...${NC}"
mkdir -p "$INSTALL_DIR"
mkdir -p "$INSTALL_DIR/workspaces"
mkdir -p "$INSTALL_DIR/logs"

# 3. Copy Agent Code
echo -e "${GREEN}Copying agent code...${NC}"
# Setup agent directory
mkdir -p "$INSTALL_DIR/agent"
cp -r . "$INSTALL_DIR/agent/"
# If running from a zip extract, ensure structure is correct

# 4. Create Virtual Environment
echo -e "${GREEN}Creating virtual environment...${NC}"
cd "$INSTALL_DIR"
python3 -m venv venv
source venv/bin/activate

# Install requirements
if [ -f "agent/requirements.txt" ]; then
    pip install -r agent/requirements.txt
else
    pip install docker httpx pydantic pydantic-settings python-dotenv psutil
fi

# 5. Configure Agent
echo -e "${GREEN}Configuring agent...${NC}"
cat > .env <<EOF
AGENT_NAME=$AGENT_NAME
AGENT_SECRET=$AGENT_SECRET
MASTER_API_URL=$MASTER_API_URL
HEARTBEAT_INTERVAL=30
DOCKER_SOCKET=unix:///var/run/docker.sock
MAX_CONTAINERS=20
CONTAINER_NETWORK=bot_network
BUILD_TIMEOUT=600
CLONE_TIMEOUT=120
WORKSPACE_PATH=$INSTALL_DIR/workspaces
LOGS_PATH=$INSTALL_DIR/logs
EOF

# 6. Create Systemd Service
echo -e "${GREEN}Creating systemd service...${NC}"
cat > /etc/systemd/system/vps-agent.service <<EOF
[Unit]
Description=VPS Agent Service
After=network.target docker.service
Requires=docker.service

[Service]
User=$USER
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/venv/bin/python -m agent.main
Restart=always
EnvironmentFile=$INSTALL_DIR/.env

[Install]
WantedBy=multi-user.target
EOF

# 7. Start Service
echo -e "${GREEN}Starting service...${NC}"
systemctl daemon-reload
systemctl enable vps-agent
systemctl restart vps-agent

echo -e "${GREEN}Deployment Complete! Agent '$AGENT_NAME' is running.${NC}"
echo -e "${GREEN}Check status with: systemctl status vps-agent${NC}"
