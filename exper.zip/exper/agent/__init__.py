"""
VPS Agent Package

Agent that runs on each VPS node for container management.
"""

__version__ = "1.0.0"
