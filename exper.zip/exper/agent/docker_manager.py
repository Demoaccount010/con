"""
Docker Manager

Handles all Docker operations for the VPS agent.
"""

import logging
from typing import Dict, List, Optional
import docker
from docker.errors import DockerException, NotFound, APIError

from agent.config import agent_settings


logger = logging.getLogger(__name__)


class DockerManager:
    """Manages Docker containers for deployments."""
    
    def __init__(self):
        self.client: docker.DockerClient | None = None
    
    def connect(self):
        """Connect to Docker daemon."""
        try:
            self.client = docker.from_env()
            self.client.ping()
            logger.info("Connected to Docker daemon")
        except DockerException as e:
            logger.error(f"Failed to connect to Docker: {e}")
            raise
    
    def ensure_network(self, network_name: str):
        """Ensure Docker network exists."""
        try:
            self.client.networks.get(network_name)
            logger.info(f"Network {network_name} exists")
        except NotFound:
            self.client.networks.create(
                network_name,
                driver="bridge"
            )
            logger.info(f"Created network {network_name}")
    
    def list_containers(self, all: bool = True) -> List[Dict]:
        """List all containers managed by this agent."""
        containers = self.client.containers.list(all=all)
        
        result = []
        for container in containers:
            # Only include containers we manage (by label)
            labels = container.labels or {}
            if labels.get("bothost.managed") == "true":
                result.append({
                    "id": container.id[:12],
                    "name": container.name,
                    "status": container.status,
                    "image": container.image.tags[0] if container.image.tags else "",
                    "created": container.attrs.get("Created", ""),
                    "exit_code": container.attrs.get("State", {}).get("ExitCode", 0),
                    "labels": labels
                })
        
        return result
    
    def get_container(self, container_id: str):
        """Get container by ID or name."""
        try:
            return self.client.containers.get(container_id)
        except NotFound:
            return None
    
    def get_container_stats(self, container_id: str) -> Optional[Dict]:
        """Get container resource stats."""
        container = self.get_container(container_id)
        if not container or container.status != "running":
            return None
        
        try:
            stats = container.stats(stream=False)
            
            # Calculate memory usage
            memory_stats = stats.get("memory_stats", {})
            memory_usage = memory_stats.get("usage", 0) // (1024 * 1024)  # MB
            memory_limit = memory_stats.get("limit", 1) // (1024 * 1024)  # MB
            
            # Calculate CPU usage
            cpu_stats = stats.get("cpu_stats", {})
            precpu_stats = stats.get("precpu_stats", {})
            
            cpu_delta = cpu_stats.get("cpu_usage", {}).get("total_usage", 0) - \
                       precpu_stats.get("cpu_usage", {}).get("total_usage", 0)
            system_delta = cpu_stats.get("system_cpu_usage", 0) - \
                          precpu_stats.get("system_cpu_usage", 0)
            
            num_cpus = len(cpu_stats.get("cpu_usage", {}).get("percpu_usage", [1]))
            
            if system_delta > 0:
                cpu_percent = (cpu_delta / system_delta) * num_cpus * 100
            else:
                cpu_percent = 0
            
            return {
                "memory_usage": memory_usage,
                "memory_limit": memory_limit,
                "memory_percent": (memory_usage / memory_limit * 100) if memory_limit > 0 else 0,
                "cpu_percent": round(cpu_percent, 2)
            }
            
        except Exception as e:
            logger.error(f"Failed to get stats for {container_id}: {e}")
            return None
    
    def build_image(
        self,
        path: str,
        tag: str,
        dockerfile: str = "Dockerfile",
        build_args: Dict = None
    ) -> tuple[bool, str]:
        """
        Build Docker image from path.
        
        Returns:
            Tuple of (success, message/logs)
        """
        try:
            logger.info(f"Building image {tag} from {path}")
            
            image, logs = self.client.images.build(
                path=path,
                tag=tag,
                dockerfile=dockerfile,
                buildargs=build_args or {},
                rm=True,
                forcerm=True,
                timeout=agent_settings.build_timeout
            )
            
            log_output = []
            for log in logs:
                if "stream" in log:
                    log_output.append(log["stream"].strip())
                elif "error" in log:
                    log_output.append(f"ERROR: {log['error']}")
            
            logger.info(f"Successfully built image {tag}")
            return True, "\n".join(log_output)
            
        except docker.errors.BuildError as e:
            logger.error(f"Build failed: {e}")
            return False, str(e)
        except Exception as e:
            logger.error(f"Build error: {e}")
            return False, str(e)
    
    def run_container(
        self,
        image: str,
        name: str,
        env_vars: Dict[str, str] = None,
        memory_limit: str = "256m",
        cpu_limit: float = 0.5,
        port: int = None,
        deployment_id: str = None
    ) -> tuple[bool, str]:
        """
        Run a container from image.
        
        Returns:
            Tuple of (success, container_id or error message)
        """
        try:
            # Prepare labels
            labels = {
                "bothost.managed": "true",
                "bothost.agent": agent_settings.agent_name,
            }
            if deployment_id:
                labels["bothost.deployment_id"] = deployment_id
            
            # Prepare port bindings
            ports = {}
            if port:
                ports[f"{port}/tcp"] = port
            
            # Security options
            security_opt = ["no-new-privileges"]
            
            container = self.client.containers.run(
                image=image,
                name=name,
                detach=True,
                environment=env_vars or {},
                labels=labels,
                mem_limit=memory_limit,
                nano_cpus=int(cpu_limit * 1e9),
                network=agent_settings.container_network,
                ports=ports,
                restart_policy={"Name": "unless-stopped"},
                cap_drop=["ALL"],
                security_opt=security_opt,
                pids_limit=100,
                read_only=False  # Some bots need to write temp files
            )
            
            logger.info(f"Started container {name}: {container.id[:12]}")
            return True, container.id[:12]
            
        except docker.errors.ContainerError as e:
            logger.error(f"Container error: {e}")
            return False, str(e)
        except docker.errors.ImageNotFound as e:
            logger.error(f"Image not found: {e}")
            return False, f"Image not found: {image}"
        except Exception as e:
            logger.error(f"Run error: {e}")
            return False, str(e)
    
    def stop_container(self, container_id: str, timeout: int = 10) -> bool:
        """Stop a container."""
        container = self.get_container(container_id)
        if not container:
            return False
        
        try:
            container.stop(timeout=timeout)
            logger.info(f"Stopped container {container_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to stop {container_id}: {e}")
            return False
    
    def start_container(self, container_id: str) -> bool:
        """Start a stopped container."""
        container = self.get_container(container_id)
        if not container:
            return False
        
        try:
            container.start()
            logger.info(f"Started container {container_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to start {container_id}: {e}")
            return False
    
    def restart_container(self, container_id: str, timeout: int = 10) -> bool:
        """Restart a container."""
        container = self.get_container(container_id)
        if not container:
            return False
        
        try:
            container.restart(timeout=timeout)
            logger.info(f"Restarted container {container_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to restart {container_id}: {e}")
            return False
    
    def remove_container(self, container_id: str, force: bool = True) -> bool:
        """Remove a container."""
        container = self.get_container(container_id)
        if not container:
            return True  # Already gone
        
        try:
            container.remove(force=force)
            logger.info(f"Removed container {container_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to remove {container_id}: {e}")
            return False
    
    def get_logs(
        self,
        container_id: str,
        tail: int = 100,
        since: int = None
    ) -> str:
        """Get container logs."""
        container = self.get_container(container_id)
        if not container:
            return ""
        
        try:
            logs = container.logs(
                tail=tail,
                since=since,
                timestamps=True
            )
            return logs.decode("utf-8", errors="replace")
        except Exception as e:
            logger.error(f"Failed to get logs for {container_id}: {e}")
            return ""
    
    def remove_image(self, image: str, force: bool = False) -> bool:
        """Remove an image."""
        try:
            self.client.images.remove(image, force=force)
            logger.info(f"Removed image {image}")
            return True
        except Exception as e:
            logger.error(f"Failed to remove image {image}: {e}")
            return False
    
    def prune_images(self) -> int:
        """Remove unused images."""
        try:
            result = self.client.images.prune(filters={"dangling": True})
            deleted = result.get("ImagesDeleted", [])
            logger.info(f"Pruned {len(deleted) if deleted else 0} images")
            return len(deleted) if deleted else 0
        except Exception as e:
            logger.error(f"Failed to prune images: {e}")
            return 0
