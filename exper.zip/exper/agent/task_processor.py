"""
Task Processor

Processes deployment tasks received from the master.
"""

import asyncio
import logging
import os
import shutil
import subprocess
from pathlib import Path
from typing import Dict, Optional
import httpx

from agent.config import agent_settings
from agent.docker_manager import DockerManager


logger = logging.getLogger(__name__)


class TaskProcessor:
    """Processes deployment tasks."""
    
    def __init__(self, docker: DockerManager):
        self.docker = docker
    
    async def process_task(self, task: Dict, http_client: httpx.AsyncClient):
        """
        Process a deployment task.
        
        Task structure:
        {
            "deployment_id": str,
            "action": "build" | "start" | "stop" | "restart" | "delete",
            "repo_url": str,
            "branch": str,
            "env_vars": dict,
            "memory_limit": str,
            "cpu_limit": float
        }
        """
        deployment_id = task.get("deployment_id")
        action = task.get("action")
        
        logger.info(f"Processing task: {action} for {deployment_id}")
        
        try:
            if action == "build":
                await self.build_deployment(task, http_client)
            elif action == "start":
                await self.start_deployment(task, http_client)
            elif action == "stop":
                await self.stop_deployment(task, http_client)
            elif action == "restart":
                await self.restart_deployment(task, http_client)
            elif action == "delete":
                await self.delete_deployment(task, http_client)
            elif action == "fetch_logs":
                await self.fetch_logs(task, http_client)
            else:
                logger.warning(f"Unknown action: {action}")
                
        except Exception as e:
            logger.error(f"Task processing failed: {e}")
            await self.report_status(
                http_client,
                deployment_id,
                "failed",
                str(e)
            )
    
    async def build_deployment(self, task: Dict, http_client: httpx.AsyncClient):
        """Build and run a new deployment."""
        deployment_id = task["deployment_id"]
        repo_url = task["repo_url"]
        branch = task.get("branch", "main")
        env_vars = task.get("env_vars", {})
        memory_limit = task.get("memory_limit", "256m")
        cpu_limit = task.get("cpu_limit", 0.5)
        
        # Report building status
        await self.report_status(http_client, deployment_id, "building", "Cloning repository...")
        
        # Prepare workspace
        workspace = Path(agent_settings.workspace_path) / deployment_id
        workspace.mkdir(parents=True, exist_ok=True)
        
        try:
            # Clone repository
            success = await self.clone_repo(repo_url, branch, workspace)
            if not success:
                raise Exception("Failed to clone repository")
            
            await self.report_status(http_client, deployment_id, "building", "Building Docker image...")
            
            # Check for Dockerfile
            dockerfile_path = workspace / "Dockerfile"
            if not dockerfile_path.exists():
                # Try to generate one
                generated = await self.generate_dockerfile(workspace)
                if not generated:
                    raise Exception("No Dockerfile found and could not generate one")
            
            # Build image
            image_tag = f"bothost/{deployment_id}:latest"
            success, logs = self.docker.build_image(
                path=str(workspace),
                tag=image_tag
            )
            
            if not success:
                raise Exception(f"Build failed: {logs}")
            
            await self.report_status(http_client, deployment_id, "building", "Starting container...")
            
            # Run container
            container_name = f"bot-{deployment_id[:8]}"
            success, result = self.docker.run_container(
                image=image_tag,
                name=container_name,
                env_vars=env_vars,
                memory_limit=memory_limit,
                cpu_limit=cpu_limit,
                deployment_id=deployment_id
            )
            
            if not success:
                raise Exception(f"Failed to start container: {result}")
            
            container_id = result
            
            # Report success
            await self.report_status(
                http_client,
                deployment_id,
                "running",
                "Deployment successful",
                container_id=container_id
            )
            
            logger.info(f"Deployment {deployment_id} successful: {container_id}")
            
        except Exception as e:
            logger.error(f"Build failed for {deployment_id}: {e}")
            await self.report_status(http_client, deployment_id, "failed", str(e))
            
        finally:
            # Cleanup workspace
            if workspace.exists():
                shutil.rmtree(workspace, ignore_errors=True)
    
    async def clone_repo(self, repo_url: str, branch: str, dest: Path) -> bool:
        """Clone a git repository."""
        try:
            # Clean destination
            if dest.exists():
                shutil.rmtree(dest)
            dest.mkdir(parents=True)
            
            # Clone
            process = await asyncio.create_subprocess_exec(
                "git", "clone",
                "--depth", "1",
                "--branch", branch,
                repo_url,
                str(dest),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await asyncio.wait_for(
                process.communicate(),
                timeout=agent_settings.clone_timeout
            )
            
            if process.returncode != 0:
                logger.error(f"Git clone failed: {stderr.decode()}")
                return False
            
            return True
            
        except asyncio.TimeoutError:
            logger.error("Git clone timed out")
            return False
        except Exception as e:
            logger.error(f"Clone error: {e}")
            return False
    
    async def generate_dockerfile(self, workspace: Path) -> bool:
        """Generate Dockerfile for common project types."""
        # Check for package.json (Node.js)
        if (workspace / "package.json").exists():
            dockerfile = """FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
CMD ["npm", "start"]
"""
            (workspace / "Dockerfile").write_text(dockerfile)
            return True
        
        # Check for requirements.txt (Python)
        if (workspace / "requirements.txt").exists():
            # Find main entry point
            entry = "main.py"
            for candidate in ["main.py", "bot.py", "app.py", "run.py"]:
                if (workspace / candidate).exists():
                    entry = candidate
                    break
            
            dockerfile = f"""FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
CMD ["python", "{entry}"]
"""
            (workspace / "Dockerfile").write_text(dockerfile)
            return True
        
        # Check for go.mod (Go)
        if (workspace / "go.mod").exists():
            dockerfile = """FROM golang:1.21-alpine AS builder
WORKDIR /app
COPY go.* ./
RUN go mod download
COPY . .
RUN CGO_ENABLED=0 go build -o /app/main .

FROM alpine:latest
COPY --from=builder /app/main /main
CMD ["/main"]
"""
            (workspace / "Dockerfile").write_text(dockerfile)
            return True
        
        return False
    
    async def start_deployment(self, task: Dict, http_client: httpx.AsyncClient):
        """Start a stopped deployment."""
        deployment_id = task["deployment_id"]
        container_id = task.get("container_id")
        
        if not container_id:
            # Try to find by name
            container_id = f"bot-{deployment_id[:8]}"
        
        success = self.docker.start_container(container_id)
        
        if success:
            await self.report_status(http_client, deployment_id, "running", "Container started")
        else:
            await self.report_status(http_client, deployment_id, "failed", "Failed to start container")
    
    async def stop_deployment(self, task: Dict, http_client: httpx.AsyncClient):
        """Stop a running deployment."""
        deployment_id = task["deployment_id"]
        container_id = task.get("container_id")
        
        if not container_id:
            container_id = f"bot-{deployment_id[:8]}"
        
        success = self.docker.stop_container(container_id)
        
        if success:
            await self.report_status(http_client, deployment_id, "stopped", "Container stopped")
        else:
            await self.report_status(http_client, deployment_id, "failed", "Failed to stop container")
    
    async def restart_deployment(self, task: Dict, http_client: httpx.AsyncClient):
        """Restart a deployment."""
        deployment_id = task["deployment_id"]
        container_id = task.get("container_id")
        
        if not container_id:
            container_id = f"bot-{deployment_id[:8]}"
        
        success = self.docker.restart_container(container_id)
        
        if success:
            await self.report_status(http_client, deployment_id, "running", "Container restarted")
        else:
            await self.report_status(http_client, deployment_id, "failed", "Failed to restart container")
    
    async def delete_deployment(self, task: Dict, http_client: httpx.AsyncClient):
        """Delete a deployment completely."""
        deployment_id = task["deployment_id"]
        container_id = task.get("container_id")
        
        if not container_id:
            container_id = f"bot-{deployment_id[:8]}"
        
        # Remove container
        self.docker.remove_container(container_id)
        
        # Remove image
        image_tag = f"bothost/{deployment_id}:latest"
        self.docker.remove_image(image_tag)
        
        await self.report_status(http_client, deployment_id, "deleted", "Deployment deleted")
    
    async def fetch_logs(self, task: Dict, http_client: httpx.AsyncClient):
        """Fetch logs from container and push to API."""
        deployment_id = task["deployment_id"]
        container_id = task.get("container_id")
        
        if not container_id:
            container_id = f"bot-{deployment_id[:8]}"
        
        # Get logs from Docker
        logs = self.docker.get_logs(container_id, tail=100)
        
        if not logs:
            logs = "No logs found or container not running."
            
        # Push logs to API (we need a new endpoint for this or reuse status update)
        # Since we don't have a direct log push endpoint in API yet, we can use a clever trick
        # or just add the endpoint. I added GET /logs but not POST /logs ingest.
        # Wait, the plan said "Save to DeploymentLog".
        # I need to add an endpoint to ingest logs or use a flexible status update.
        # Let's add a specific log ingestion endpoint to API first? 
        # Actually, let's just use the status endpoint if we can, 
        # BUT `DeploymentLog` is a separate table. 
        # I should have added an endpoint to SAVE logs in `api/deployments.py`.
        # Let's assume I will add `POST /api/deployments/{id}/logs` next.
        
        try:
            await http_client.post(
                f"/api/deployments/{deployment_id}/logs",
                json={"logs": logs, "source": "agent"}
            )
        except Exception as e:
            logger.error(f"Failed to push logs: {e}")

    async def report_status(
        self,
        http_client: httpx.AsyncClient,
        deployment_id: str,
        status: str,
        message: str,
        container_id: str = None
    ):
        """Report deployment status to master."""
        try:
            data = {
                "status": status,
                "status_message": message
            }
            
            if container_id:
                data["container_id"] = container_id
            
            await http_client.patch(
                f"/api/deployments/{deployment_id}/status",
                json=data
            )
        except Exception as e:
            logger.error(f"Failed to report status: {e}")
