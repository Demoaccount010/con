# 🖧 VPS Worker Agent Environment Variables

This file explains ALL environment variables needed for **VPS Worker Agents** (the servers that run Docker containers).

---

## 📋 Complete `.env` File Template for VPS Workers

```env
# ═══════════════════════════════════════════════════════════════════════════════
# AGENT IDENTITY
# ═══════════════════════════════════════════════════════════════════════════════

AGENT_NAME=vps-worker-1
AGENT_REGION=us-east
AGENT_PROVIDER=digitalocean

# ═══════════════════════════════════════════════════════════════════════════════
# MASTER SERVER CONNECTION
# ═══════════════════════════════════════════════════════════════════════════════

MASTER_WS_URL=wss://api.yourdomain.com/ws/agent
MASTER_API_URL=https://api.yourdomain.com
AGENT_SECRET_KEY=your-agent-secret-key-must-match-main-server

# ═══════════════════════════════════════════════════════════════════════════════
# DOCKER CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

DOCKER_SOCKET=/var/run/docker.sock
DEFAULT_MEMORY_LIMIT=512m
DEFAULT_CPU_LIMIT=0.5
DEFAULT_PIDS_LIMIT=100

# ═══════════════════════════════════════════════════════════════════════════════
# RESOURCE LIMITS
# ═══════════════════════════════════════════════════════════════════════════════

MAX_CONTAINERS=50
MAX_MEMORY_GB=32
MAX_CPU_CORES=8

# ═══════════════════════════════════════════════════════════════════════════════
# NETWORKING
# ═══════════════════════════════════════════════════════════════════════════════

AGENT_PORT=8080
PUBLIC_IP=auto
INTERNAL_IP=auto

# ═══════════════════════════════════════════════════════════════════════════════
# STORAGE
# ═══════════════════════════════════════════════════════════════════════════════

DEPLOYMENTS_DIR=/opt/bot-hosting/deployments
LOGS_DIR=/opt/bot-hosting/logs
TEMP_DIR=/opt/bot-hosting/temp

# ═══════════════════════════════════════════════════════════════════════════════
# MONITORING
# ═══════════════════════════════════════════════════════════════════════════════

HEALTH_CHECK_INTERVAL=30
METRICS_ENABLED=true
LOG_LEVEL=INFO

# ═══════════════════════════════════════════════════════════════════════════════
# SECURITY
# ═══════════════════════════════════════════════════════════════════════════════

ENABLE_SECCOMP=true
DROP_CAPABILITIES=true
NO_NEW_PRIVILEGES=true
```

---

## 📖 Detailed Explanation

---

### 🎫 AGENT IDENTITY

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `AGENT_NAME` | ✅ | - | Unique name for this VPS worker (shown in admin panel) |
| `AGENT_REGION` | ❌ | `unknown` | Geographic region (for load balancing) |
| `AGENT_PROVIDER` | ❌ | `unknown` | Cloud provider name (for tracking) |

**Naming Convention Examples:**
```env
# By region
AGENT_NAME=vps-mumbai-1
AGENT_NAME=vps-singapore-2

# By purpose
AGENT_NAME=production-worker-1
AGENT_NAME=free-tier-worker-1

# By provider
AGENT_NAME=do-blr1-node1
AGENT_NAME=aws-ap-south-1a
```

**Region Examples:**
```env
AGENT_REGION=ap-south-1        # Mumbai
AGENT_REGION=ap-southeast-1    # Singapore
AGENT_REGION=us-east-1         # Virginia
AGENT_REGION=eu-west-1         # Ireland
```

**Provider Examples:**
```env
AGENT_PROVIDER=digitalocean
AGENT_PROVIDER=aws
AGENT_PROVIDER=google-cloud
AGENT_PROVIDER=vultr
AGENT_PROVIDER=linode
AGENT_PROVIDER=hetzner
AGENT_PROVIDER=self-hosted
```

---

### 🔌 MASTER SERVER CONNECTION

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `MASTER_WS_URL` | ✅ | - | WebSocket URL of main server for real-time communication |
| `MASTER_API_URL` | ✅ | - | HTTP API URL of main server for REST calls |
| `AGENT_SECRET_KEY` | ✅ | - | **MUST match** the `AGENT_SECRET_KEY` on main server! |

**⚠️ IMPORTANT:** The `AGENT_SECRET_KEY` must be **IDENTICAL** to the one on your main server. This is how the main server authenticates VPS workers.

**Examples:**
```env
# Development (main server on localhost)
MASTER_WS_URL=ws://localhost:8000/ws/agent
MASTER_API_URL=http://localhost:8000

# Production (secure connection)
MASTER_WS_URL=wss://api.yourdomain.com/ws/agent
MASTER_API_URL=https://api.yourdomain.com

# With port number
MASTER_WS_URL=wss://api.yourdomain.com:8443/ws/agent
```

**Generate a secure secret:**
```bash
python -c "import secrets; print(secrets.token_urlsafe(32))"
# Example output: kX9vM2nE7wQ4rY8tU1pL3zS6cA0fJ5bH
```

---

### 🐳 DOCKER CONFIGURATION

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `DOCKER_SOCKET` | ❌ | `/var/run/docker.sock` | Path to Docker socket |
| `DEFAULT_MEMORY_LIMIT` | ❌ | `512m` | Default RAM per container |
| `DEFAULT_CPU_LIMIT` | ❌ | `0.5` | Default CPU cores per container |
| `DEFAULT_PIDS_LIMIT` | ❌ | `100` | Max processes per container |

**Memory Limit Examples:**
```env
DEFAULT_MEMORY_LIMIT=256m    # 256 MB (for free tier)
DEFAULT_MEMORY_LIMIT=512m    # 512 MB (starter)
DEFAULT_MEMORY_LIMIT=1g      # 1 GB (pro)
DEFAULT_MEMORY_LIMIT=2g      # 2 GB (enterprise)
```

**CPU Limit Examples:**
```env
DEFAULT_CPU_LIMIT=0.25    # 25% of one core
DEFAULT_CPU_LIMIT=0.5     # 50% of one core
DEFAULT_CPU_LIMIT=1       # 1 full core
DEFAULT_CPU_LIMIT=2       # 2 cores
```

---

### 📊 RESOURCE LIMITS

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `MAX_CONTAINERS` | ❌ | `50` | Maximum containers this VPS can run |
| `MAX_MEMORY_GB` | ❌ | Auto-detect | Total RAM available for containers |
| `MAX_CPU_CORES` | ❌ | Auto-detect | Total CPU cores available |

**Calculate based on your VPS:**

| VPS RAM | VPS CPU | Recommended Settings |
|---------|---------|---------------------|
| 2 GB | 1 vCPU | `MAX_CONTAINERS=4`, `MAX_MEMORY_GB=1.5`, `MAX_CPU_CORES=1` |
| 4 GB | 2 vCPU | `MAX_CONTAINERS=8`, `MAX_MEMORY_GB=3`, `MAX_CPU_CORES=2` |
| 8 GB | 4 vCPU | `MAX_CONTAINERS=16`, `MAX_MEMORY_GB=6`, `MAX_CPU_CORES=4` |
| 16 GB | 8 vCPU | `MAX_CONTAINERS=32`, `MAX_MEMORY_GB=12`, `MAX_CPU_CORES=8` |

**Reserve 1-2 GB RAM and 1 core for the OS and agent!**

---

### 🌐 NETWORKING

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `AGENT_PORT` | ❌ | `8080` | Port for agent's health endpoint |
| `PUBLIC_IP` | ❌ | `auto` | Public IP address (auto-detected) |
| `INTERNAL_IP` | ❌ | `auto` | Private/internal IP (auto-detected) |

**Manual IP Configuration:**
```env
# For VPS with known IPs
PUBLIC_IP=203.0.113.50
INTERNAL_IP=10.0.0.5

# Let agent auto-detect (recommended)
PUBLIC_IP=auto
INTERNAL_IP=auto
```

---

### 📁 STORAGE

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `DEPLOYMENTS_DIR` | ❌ | `/opt/bot-hosting/deployments` | Where cloned repos are stored |
| `LOGS_DIR` | ❌ | `/opt/bot-hosting/logs` | Where container logs are stored |
| `TEMP_DIR` | ❌ | `/opt/bot-hosting/temp` | Temporary build files |

**Create directories before running:**
```bash
sudo mkdir -p /opt/bot-hosting/{deployments,logs,temp}
sudo chown -R $USER:$USER /opt/bot-hosting
```

---

### 📈 MONITORING

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `HEALTH_CHECK_INTERVAL` | ❌ | `30` | Seconds between health reports to main server |
| `METRICS_ENABLED` | ❌ | `true` | Send CPU/RAM metrics to main server |
| `LOG_LEVEL` | ❌ | `INFO` | Logging verbosity: `DEBUG`, `INFO`, `WARNING`, `ERROR` |

**Log Level Guide:**
- `DEBUG` - Everything (very verbose, for troubleshooting)
- `INFO` - Normal operations
- `WARNING` - Only warnings and errors
- `ERROR` - Only errors

---

### 🔒 SECURITY

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `ENABLE_SECCOMP` | ❌ | `true` | Enable syscall filtering (recommended) |
| `DROP_CAPABILITIES` | ❌ | `true` | Drop all Linux capabilities from containers |
| `NO_NEW_PRIVILEGES` | ❌ | `true` | Prevent privilege escalation |

**⚠️ WARNING:** Keep all security options `true` in production! Only disable for debugging.

---

## 🚀 Quick Setup for New VPS

### 1. Install Prerequisites

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER

# Install Python dependencies
pip3 install docker psutil httpx websockets
```

### 2. Create Directory Structure

```bash
sudo mkdir -p /opt/bot-hosting/{deployments,logs,temp}
sudo chown -R $USER:$USER /opt/bot-hosting
```

### 3. Create `.env` File

```bash
cd /opt/bot-hosting
nano .env
```

Paste your configuration and save.

### 4. Copy Agent Code

```bash
# Copy from your main server or git clone
scp -r your-server:/path/to/agent /opt/bot-hosting/
```

### 5. Start the Agent

```bash
cd /opt/bot-hosting
python3 -m agent.main
```

### 6. Run as Service (Recommended)

Create `/etc/systemd/system/bot-agent.service`:

```ini
[Unit]
Description=Bot Hosting VPS Agent
After=network.target docker.service
Requires=docker.service

[Service]
Type=simple
User=your-username
WorkingDirectory=/opt/bot-hosting
EnvironmentFile=/opt/bot-hosting/.env
ExecStart=/usr/bin/python3 -m agent.main
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl daemon-reload
sudo systemctl enable bot-agent
sudo systemctl start bot-agent
sudo systemctl status bot-agent
```

---

## 🔧 Multiple VPS Workers - Example Configs

### VPS Worker 1 (Mumbai - Free Tier)
```env
AGENT_NAME=vps-mumbai-free
AGENT_REGION=ap-south-1
AGENT_PROVIDER=digitalocean
MASTER_WS_URL=wss://api.bothosting.com/ws/agent
MASTER_API_URL=https://api.bothosting.com
AGENT_SECRET_KEY=kX9vM2nE7wQ4rY8tU1pL3zS6cA0fJ5bH
MAX_CONTAINERS=20
MAX_MEMORY_GB=3
DEFAULT_MEMORY_LIMIT=256m
```

### VPS Worker 2 (Singapore - Premium)
```env
AGENT_NAME=vps-singapore-premium
AGENT_REGION=ap-southeast-1
AGENT_PROVIDER=aws
MASTER_WS_URL=wss://api.bothosting.com/ws/agent
MASTER_API_URL=https://api.bothosting.com
AGENT_SECRET_KEY=kX9vM2nE7wQ4rY8tU1pL3zS6cA0fJ5bH
MAX_CONTAINERS=50
MAX_MEMORY_GB=14
DEFAULT_MEMORY_LIMIT=512m
```

### VPS Worker 3 (US - Enterprise)
```env
AGENT_NAME=vps-us-enterprise
AGENT_REGION=us-east-1
AGENT_PROVIDER=hetzner
MASTER_WS_URL=wss://api.bothosting.com/ws/agent
MASTER_API_URL=https://api.bothosting.com
AGENT_SECRET_KEY=kX9vM2nE7wQ4rY8tU1pL3zS6cA0fJ5bH
MAX_CONTAINERS=100
MAX_MEMORY_GB=30
DEFAULT_MEMORY_LIMIT=1g
```

---

## ✅ Production Checklist for VPS Workers

- [ ] `AGENT_NAME` is unique across all workers
- [ ] `AGENT_SECRET_KEY` matches main server exactly
- [ ] Docker is installed and running
- [ ] User has Docker permissions (`docker ps` works without sudo)
- [ ] Storage directories exist with proper permissions
- [ ] Firewall allows outbound to main server
- [ ] Running as systemd service for auto-restart
- [ ] All security options are `true`
- [ ] Resource limits are set appropriately for VPS size
