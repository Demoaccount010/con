# 🖥️ Main Server Environment Variables

This file explains ALL environment variables needed for the **Main Server** (API + Telegram Bot).

---

## 📋 Complete `.env` File Template

```env
# ═══════════════════════════════════════════════════════════════════════════════
# APPLICATION SETTINGS
# ═══════════════════════════════════════════════════════════════════════════════

APP_NAME=BotHostingPlatform
APP_ENV=development
DEBUG=true
SECRET_KEY=your-super-secret-key-minimum-32-characters

# ═══════════════════════════════════════════════════════════════════════════════
# DATABASE (PostgreSQL)
# ═══════════════════════════════════════════════════════════════════════════════

DATABASE_URL=postgresql+asyncpg://postgres:your_password@localhost:5432/bot_hosting
DATABASE_POOL_SIZE=20
DATABASE_MAX_OVERFLOW=10

# ═══════════════════════════════════════════════════════════════════════════════
# REDIS
# ═══════════════════════════════════════════════════════════════════════════════

REDIS_URL=redis://localhost:6379/0
REDIS_QUEUE_DB=1

# ═══════════════════════════════════════════════════════════════════════════════
# TELEGRAM BOT
# ═══════════════════════════════════════════════════════════════════════════════

BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrSTUvwxYZ
ADMIN_IDS=123456789,987654321

# ═══════════════════════════════════════════════════════════════════════════════
# RAZORPAY PAYMENT GATEWAY
# ═══════════════════════════════════════════════════════════════════════════════

RAZORPAY_KEY_ID=rzp_test_xxxxxxxxxxxx
RAZORPAY_KEY_SECRET=xxxxxxxxxxxxxxxxxxxxxxxx
RAZORPAY_WEBHOOK_SECRET=your-webhook-secret

# ═══════════════════════════════════════════════════════════════════════════════
# VPS AGENT CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

AGENT_SECRET_KEY=your-agent-secret-key-for-authentication
MASTER_WS_URL=ws://localhost:8000/ws/agent

# ═══════════════════════════════════════════════════════════════════════════════
# DOCKER DEFAULTS
# ═══════════════════════════════════════════════════════════════════════════════

DEFAULT_MEMORY_LIMIT=512m
DEFAULT_CPU_LIMIT=0.5
DEFAULT_PIDS_LIMIT=100

# ═══════════════════════════════════════════════════════════════════════════════
# DOMAIN SETTINGS
# ═══════════════════════════════════════════════════════════════════════════════

BASE_DOMAIN=yourdomain.com
SUBDOMAIN_SUFFIX=.bot.yourdomain.com

# ═══════════════════════════════════════════════════════════════════════════════
# GITHUB (Auto-Deploy)
# ═══════════════════════════════════════════════════════════════════════════════

GITHUB_WEBHOOK_SECRET=your-github-webhook-secret

# ═══════════════════════════════════════════════════════════════════════════════
# MONITORING
# ═══════════════════════════════════════════════════════════════════════════════

HEALTH_CHECK_INTERVAL=30
IDLE_SHUTDOWN_MINUTES=60
```

---

## 📖 Detailed Explanation

---

### 🔧 APPLICATION SETTINGS

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `APP_NAME` | ❌ | `BotHostingPlatform` | Display name of your application |
| `APP_ENV` | ❌ | `development` | Environment: `development`, `staging`, `production` |
| `DEBUG` | ❌ | `false` | Enable debug mode (shows detailed errors). Set to `false` in production! |
| `SECRET_KEY` | ✅ | - | **CRITICAL!** Used for JWT tokens and encryption. Must be at least 32 random characters. Generate with: `python -c "import secrets; print(secrets.token_urlsafe(32))"` |

---

### 🗄️ DATABASE (PostgreSQL)

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `DATABASE_URL` | ✅ | - | PostgreSQL connection string |
| `DATABASE_POOL_SIZE` | ❌ | `20` | Maximum database connections in pool |
| `DATABASE_MAX_OVERFLOW` | ❌ | `10` | Extra connections allowed beyond pool size |

**DATABASE_URL Format:**
```
postgresql+asyncpg://USERNAME:PASSWORD@HOST:PORT/DATABASE_NAME
```

**Examples:**
```env
# Local PostgreSQL
DATABASE_URL=postgresql+asyncpg://postgres:mypassword@localhost:5432/bot_hosting

# Docker PostgreSQL
DATABASE_URL=postgresql+asyncpg://postgres:mypassword@postgres:5432/bot_hosting

# Remote PostgreSQL (Railway, Supabase, etc.)
DATABASE_URL=postgresql+asyncpg://user:pass@your-host.com:5432/dbname
```

---

### 🔴 REDIS

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `REDIS_URL` | ✅ | - | Redis connection string for caching |
| `REDIS_QUEUE_DB` | ❌ | `1` | Separate Redis database for task queues (0-15) |

**REDIS_URL Format:**
```
redis://[:PASSWORD@]HOST:PORT/DB_NUMBER
```

**Examples:**
```env
# Local Redis (no password)
REDIS_URL=redis://localhost:6379/0

# Redis with password
REDIS_URL=redis://:mypassword@localhost:6379/0

# Docker Redis
REDIS_URL=redis://redis:6379/0

# Remote Redis (Upstash, Redis Cloud)
REDIS_URL=redis://:password@your-redis-host.com:6379/0
```

---

### 🤖 TELEGRAM BOT

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `BOT_TOKEN` | ✅ | - | Bot token from @BotFather |
| `ADMIN_IDS` | ✅ | - | Comma-separated Telegram user IDs with admin access |

**How to get BOT_TOKEN:**
1. Open Telegram and message [@BotFather](https://t.me/BotFather)
2. Send `/newbot`
3. Follow prompts to name your bot
4. Copy the token (looks like: `1234567890:ABCdefGHIjklMNOpqrSTUvwxYZ`)

**How to get your ADMIN_ID:**
1. Message [@userinfobot](https://t.me/userinfobot) on Telegram
2. It will reply with your user ID

**Examples:**
```env
# Single admin
ADMIN_IDS=123456789

# Multiple admins
ADMIN_IDS=123456789,987654321,555555555
```

---

### 💳 RAZORPAY PAYMENT GATEWAY

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `RAZORPAY_KEY_ID` | ✅* | - | Razorpay API Key ID |
| `RAZORPAY_KEY_SECRET` | ✅* | - | Razorpay API Key Secret |
| `RAZORPAY_WEBHOOK_SECRET` | ✅* | - | Secret for verifying webhook signatures |

*Required only if you want to enable payments

**How to get Razorpay credentials:**
1. Sign up at [razorpay.com](https://razorpay.com)
2. Go to Dashboard → Settings → API Keys
3. Generate new API keys
4. For webhook: Settings → Webhooks → Add Webhook → Copy secret

**Test Mode Keys:**
- Start with `rzp_test_` for testing
- Start with `rzp_live_` for production

**Examples:**
```env
# Test mode
RAZORPAY_KEY_ID=rzp_test_1234567890abcdef
RAZORPAY_KEY_SECRET=abcdefghijklmnopqrstuvwxyz123456

# Live mode (production)
RAZORPAY_KEY_ID=rzp_live_1234567890abcdef
RAZORPAY_KEY_SECRET=abcdefghijklmnopqrstuvwxyz123456
```

---

### 🖧 VPS AGENT CONFIGURATION

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `AGENT_SECRET_KEY` | ✅ | - | Shared secret for VPS agents to authenticate |
| `MASTER_WS_URL` | ❌ | `ws://localhost:8000/ws/agent` | WebSocket URL where agents connect |

**Important:** This `AGENT_SECRET_KEY` must match on ALL VPS workers!

**Examples:**
```env
# For development (localhost)
MASTER_WS_URL=ws://localhost:8000/ws/agent

# For production (your server's public URL)
MASTER_WS_URL=wss://api.yourdomain.com/ws/agent
```

---

### 🐳 DOCKER DEFAULTS

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `DEFAULT_MEMORY_LIMIT` | ❌ | `512m` | Default RAM limit per container |
| `DEFAULT_CPU_LIMIT` | ❌ | `0.5` | Default CPU cores per container (0.5 = 50% of one core) |
| `DEFAULT_PIDS_LIMIT` | ❌ | `100` | Max processes per container (security) |

**Memory Format:** `256m`, `512m`, `1g`, `2g`
**CPU Format:** `0.5` = half core, `1` = one core, `2` = two cores

---

### 🌐 DOMAIN SETTINGS

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `BASE_DOMAIN` | ❌ | `localhost` | Your main domain |
| `SUBDOMAIN_SUFFIX` | ❌ | `.bot.localhost` | Suffix for deployed bot subdomains |

**Example:** If user deploys bot named "mybot":
- `BASE_DOMAIN=yourdomain.com`
- `SUBDOMAIN_SUFFIX=.bot.yourdomain.com`
- Bot URL becomes: `mybot.bot.yourdomain.com`

---

### 🔗 GITHUB (Auto-Deploy)

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `GITHUB_WEBHOOK_SECRET` | ❌ | - | Secret for verifying GitHub webhook signatures |

**Setup:** In your GitHub repo → Settings → Webhooks → Add webhook:
- Payload URL: `https://your-api.com/api/webhooks/github`
- Content type: `application/json`
- Secret: Same as `GITHUB_WEBHOOK_SECRET`
- Events: Just the `push` event

---

### 📊 MONITORING

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `HEALTH_CHECK_INTERVAL` | ❌ | `30` | Seconds between health checks |
| `IDLE_SHUTDOWN_MINUTES` | ❌ | `60` | Shutdown idle bots after X minutes (0 = never) |

---

## 🚀 Production Checklist

Before going to production, ensure:

- [ ] `DEBUG=false`
- [ ] `APP_ENV=production`
- [ ] `SECRET_KEY` is a strong random string (32+ characters)
- [ ] Database has strong password
- [ ] Redis has password if exposed
- [ ] Using `https://` and `wss://` for URLs
- [ ] Razorpay is using live keys (not test)
- [ ] All secrets are unique and secure
