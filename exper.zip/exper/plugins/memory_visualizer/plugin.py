#!/usr/bin/env python3
"""
Memory Visualizer Plugin for SMILE Agent

Provides visualization and analysis of the agent's memory system.
"""

import json
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from collections import defaultdict

from core.plugin_system import BasePlugin, PluginMetadata, PluginType


class MemoryVisualizerPlugin(BasePlugin):
    """Plugin for visualizing and analyzing agent memory"""
    
    METADATA = PluginMetadata(
        name="memory_visualizer",
        version="1.0.0",
        description="Visualize and analyze agent memory",
        author="SMILE",
        plugin_type=PluginType.UTILITY,
        permissions=[]
    )
    
    async def initialize(self) -> bool:
        """Initialize the memory visualizer"""
        self.register_tool("memory_stats", self.get_memory_stats,
                          "Get memory system statistics")
        self.register_tool("memory_timeline", self.get_memory_timeline,
                          "Get memory timeline visualization")
        self.register_tool("memory_search", self.search_memory,
                          "Search through memories")
        self.register_tool("memory_graph", self.get_memory_graph,
                          "Get memory relationship graph")
        self.register_tool("conversation_summary", self.get_conversation_summary,
                          "Summarize recent conversations")
        self.register_tool("learning_report", self.get_learning_report,
                          "Get learning and improvement report")
        self.register_tool("memory_export", self.export_memories,
                          "Export memories to JSON")
        
        self._initialized = True
        self.logger.info("Memory Visualizer Plugin initialized")
        return True
    
    async def shutdown(self) -> bool:
        return True
    
    async def get_memory_stats(self) -> Dict[str, Any]:
        """
        Get comprehensive memory statistics
        
        Returns:
            Memory statistics dict
        """
        if not hasattr(self.agent, 'memory_system') or not self.agent.memory_system:
            return {"success": False, "error": "Memory system not available"}
        
        mem = self.agent.memory_system
        
        stats = {
            "success": True,
            "overview": mem.get_stats(),
            "short_term": {
                "count": len(mem.short_term),
                "max_size": mem.short_term.maxlen if hasattr(mem.short_term, 'maxlen') else "unknown"
            },
            "long_term": {
                "count": len(mem.long_term_cache),
                "categories": self._categorize_memories(mem.long_term_cache)
            },
            "skills": {
                "count": len(mem.skill_cache),
                "list": [
                    {"id": k, "name": v.content.get("name", k)}
                    for k, v in list(mem.skill_cache.items())[:10]
                ]
            },
            "learnings": {
                "count": len(mem.learning_cache),
                "by_category": self._group_learnings(mem.learning_cache)
            },
            "goals": await mem.get_goals_summary()
        }
        
        return stats
    
    def _categorize_memories(self, memories: Dict) -> Dict[str, int]:
        """Categorize memories by type"""
        categories = defaultdict(int)
        for entry in memories.values():
            mem_type = entry.memory_type if hasattr(entry, 'memory_type') else 'unknown'
            categories[mem_type] += 1
        return dict(categories)
    
    def _group_learnings(self, learnings: Dict) -> Dict[str, int]:
        """Group learnings by category"""
        groups = defaultdict(int)
        for entry in learnings.values():
            category = entry.category if hasattr(entry, 'category') else 'unknown'
            groups[category] += 1
        return dict(groups)
    
    async def get_memory_timeline(self, days: int = 7) -> Dict[str, Any]:
        """
        Get memory timeline for visualization
        
        Args:
            days: Number of days to include
            
        Returns:
            Timeline data
        """
        if not hasattr(self.agent, 'memory_system'):
            return {"success": False, "error": "Memory system not available"}
        
        mem = self.agent.memory_system
        cutoff = datetime.now() - timedelta(days=days)
        
        timeline = defaultdict(lambda: {"count": 0, "types": defaultdict(int)})
        
        # Process long-term memories
        for entry in mem.long_term_cache.values():
            created = datetime.fromisoformat(entry.created_at) if hasattr(entry, 'created_at') else None
            if created and created > cutoff:
                day_key = created.strftime("%Y-%m-%d")
                timeline[day_key]["count"] += 1
                timeline[day_key]["types"]["long_term"] += 1
        
        # Process learnings
        for entry in mem.learning_cache.values():
            created = datetime.fromisoformat(entry.created_at) if hasattr(entry, 'created_at') else None
            if created and created > cutoff:
                day_key = created.strftime("%Y-%m-%d")
                timeline[day_key]["count"] += 1
                timeline[day_key]["types"]["learning"] += 1
        
        # Convert to list sorted by date
        timeline_list = [
            {"date": date, **data}
            for date, data in sorted(timeline.items())
        ]
        
        return {
            "success": True,
            "days": days,
            "timeline": timeline_list,
            "total_entries": sum(d["count"] for d in timeline_list)
        }
    
    async def search_memory(self, query: str, limit: int = 20) -> Dict[str, Any]:
        """
        Search through memories
        
        Args:
            query: Search query
            limit: Maximum results
            
        Returns:
            Search results
        """
        if not hasattr(self.agent, 'memory_system'):
            return {"success": False, "error": "Memory system not available"}
        
        mem = self.agent.memory_system
        
        results = await mem.search_relevant(query, limit=limit)
        
        return {
            "success": True,
            "query": query,
            "results": results,
            "count": len(results)
        }
    
    async def get_memory_graph(self) -> Dict[str, Any]:
        """
        Get memory relationship graph
        
        Returns:
            Graph data with nodes and edges
        """
        if not hasattr(self.agent, 'memory_system'):
            return {"success": False, "error": "Memory system not available"}
        
        mem = self.agent.memory_system
        
        nodes = []
        edges = []
        
        # Add memory nodes
        for entry_id, entry in list(mem.long_term_cache.items())[:50]:
            nodes.append({
                "id": entry_id,
                "type": "memory",
                "label": str(entry.content)[:50] if hasattr(entry, 'content') else entry_id,
                "importance": entry.importance if hasattr(entry, 'importance') else 0.5
            })
        
        # Add skill nodes
        for skill_id, skill in list(mem.skill_cache.items())[:20]:
            nodes.append({
                "id": skill_id,
                "type": "skill",
                "label": skill.content.get("name", skill_id) if hasattr(skill, 'content') else skill_id
            })
        
        # Add goal nodes
        for goal_id, goal in list(mem.goal_cache.items())[:10]:
            nodes.append({
                "id": goal_id,
                "type": "goal",
                "label": goal.description[:50] if hasattr(goal, 'description') else goal_id
            })
        
        # Build edges based on keyword similarity
        # (Simplified - in production, use better similarity measures)
        keyword_index = mem.keyword_index
        for keyword, memory_refs in list(keyword_index.items())[:100]:
            if len(memory_refs) > 1:
                for i, ref1 in enumerate(memory_refs[:5]):
                    for ref2 in memory_refs[i+1:5]:
                        edges.append({
                            "source": f"{ref1[0]}:{ref1[1]}",
                            "target": f"{ref2[0]}:{ref2[1]}",
                            "keyword": keyword
                        })
        
        return {
            "success": True,
            "nodes": nodes,
            "edges": edges[:100],  # Limit edges
            "node_count": len(nodes),
            "edge_count": len(edges)
        }
    
    async def get_conversation_summary(self, limit: int = 50) -> Dict[str, Any]:
        """
        Get summary of recent conversations
        
        Args:
            limit: Number of turns to analyze
            
        Returns:
            Conversation summary
        """
        if not hasattr(self.agent, 'memory_system'):
            return {"success": False, "error": "Memory system not available"}
        
        mem = self.agent.memory_system
        
        recent = list(mem.short_term)[-limit:]
        
        # Analyze conversations
        user_messages = [t for t in recent if hasattr(t, 'role') and t.role == 'user']
        assistant_messages = [t for t in recent if hasattr(t, 'role') and t.role == 'assistant']
        
        # Extract topics (simple keyword extraction)
        all_text = " ".join(
            t.content for t in recent if hasattr(t, 'content')
        )
        words = all_text.lower().split()
        word_freq = defaultdict(int)
        stop_words = {'the', 'a', 'an', 'is', 'are', 'was', 'were', 'i', 'you', 'it', 'to', 'and', 'of', 'in', 'for', 'on', 'with'}
        for word in words:
            if word not in stop_words and len(word) > 3:
                word_freq[word] += 1
        
        top_topics = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)[:10]
        
        return {
            "success": True,
            "total_turns": len(recent),
            "user_messages": len(user_messages),
            "assistant_messages": len(assistant_messages),
            "top_topics": [{"word": w, "count": c} for w, c in top_topics],
            "avg_message_length": sum(len(t.content) for t in recent if hasattr(t, 'content')) / max(len(recent), 1),
            "time_range": {
                "start": recent[0].timestamp if recent and hasattr(recent[0], 'timestamp') else None,
                "end": recent[-1].timestamp if recent and hasattr(recent[-1], 'timestamp') else None
            }
        }
    
    async def get_learning_report(self) -> Dict[str, Any]:
        """
        Generate a learning and improvement report
        
        Returns:
            Learning report
        """
        if not hasattr(self.agent, 'memory_system'):
            return {"success": False, "error": "Memory system not available"}
        
        mem = self.agent.memory_system
        
        learnings = list(mem.learning_cache.values())
        
        # Group by category
        by_category = defaultdict(list)
        for learning in learnings:
            cat = learning.category if hasattr(learning, 'category') else 'unknown'
            by_category[cat].append(learning)
        
        # Calculate application rates
        applied_learnings = [l for l in learnings if hasattr(l, 'applied_count') and l.applied_count > 0]
        
        report = {
            "success": True,
            "total_learnings": len(learnings),
            "by_category": {
                cat: {
                    "count": len(items),
                    "recent": [
                        {
                            "pattern": l.learned_pattern[:100] if hasattr(l, 'learned_pattern') else "",
                            "applied": l.applied_count if hasattr(l, 'applied_count') else 0
                        }
                        for l in sorted(items, key=lambda x: x.created_at if hasattr(x, 'created_at') else '', reverse=True)[:3]
                    ]
                }
                for cat, items in by_category.items()
            },
            "application_rate": len(applied_learnings) / max(len(learnings), 1),
            "most_applied": sorted(
                [{"pattern": l.learned_pattern[:50], "count": l.applied_count} 
                 for l in learnings if hasattr(l, 'applied_count')],
                key=lambda x: x["count"],
                reverse=True
            )[:5]
        }
        
        return report
    
    async def export_memories(self, include_all: bool = False) -> Dict[str, Any]:
        """
        Export memories to JSON format
        
        Args:
            include_all: Include all memory types
            
        Returns:
            Exportable memory data
        """
        if not hasattr(self.agent, 'memory_system'):
            return {"success": False, "error": "Memory system not available"}
        
        mem = self.agent.memory_system
        
        export_data = {
            "exported_at": datetime.now().isoformat(),
            "agent_name": self.agent.identity.name if hasattr(self.agent, 'identity') else "SMILE",
            "stats": mem.get_stats()
        }
        
        if include_all:
            export_data["long_term"] = {
                k: v.to_dict() if hasattr(v, 'to_dict') else str(v)
                for k, v in mem.long_term_cache.items()
            }
            export_data["skills"] = {
                k: v.to_dict() if hasattr(v, 'to_dict') else str(v)
                for k, v in mem.skill_cache.items()
            }
        
        return {
            "success": True,
            "data": export_data,
            "size_estimate": len(json.dumps(export_data))
        }