#!/usr/bin/env python3
"""
GitHub Integration Plugin for SMILE Agent

Provides GitHub API integration for repository management,
issue tracking, and code operations.
"""

import aiohttp
import base64
import json
from typing import Dict, Any, List, Optional
from datetime import datetime
from core.plugin_system import BasePlugin, PluginMetadata, PluginType


class GitHubPlugin(BasePlugin):
    """Plugin providing GitHub integration capabilities"""
    
    METADATA = PluginMetadata(
        name="github_integration",
        version="1.0.0",
        description="GitHub API integration for repository management",
        author="SMILE",
        plugin_type=PluginType.INTEGRATION,
        permissions=["network"],
        config_schema={
            "token": {"type": "string", "required": True, "description": "GitHub Personal Access Token"},
            "default_owner": {"type": "string", "required": False, "description": "Default repository owner"}
        }
    )
    
    def __init__(self, agent, config=None):
        super().__init__(agent, config)
        self.base_url = "https://api.github.com"
        self.token = config.get("token", "") if config else ""
        self.default_owner = config.get("default_owner", "") if config else ""
        self.session: Optional[aiohttp.ClientSession] = None
    
    async def initialize(self) -> bool:
        """Initialize the GitHub plugin"""
        # Check for token in config or environment
        import os
        if not self.token:
            self.token = os.environ.get("GITHUB_TOKEN", "")
        
        if not self.token:
            self.logger.warning("No GitHub token configured. Some features will be limited.")
        
        # Create session
        headers = {
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "SMILE-Agent/1.0"
        }
        if self.token:
            headers["Authorization"] = f"token {self.token}"
        
        self.session = aiohttp.ClientSession(headers=headers)
        
        # Register tools
        self.register_tool("get_repo", self.get_repo, "Get repository information")
        self.register_tool("list_repos", self.list_repos, "List user repositories")
        self.register_tool("get_file", self.get_file_content, "Get file content from repo")
        self.register_tool("create_issue", self.create_issue, "Create a new issue")
        self.register_tool("list_issues", self.list_issues, "List repository issues")
        self.register_tool("search_repos", self.search_repos, "Search GitHub repositories")
        self.register_tool("get_user", self.get_user, "Get user information")
        self.register_tool("list_commits", self.list_commits, "List repository commits")
        self.register_tool("get_readme", self.get_readme, "Get repository README")
        
        self._initialized = True
        self.logger.info("GitHub Integration Plugin initialized")
        return True
    
    async def shutdown(self) -> bool:
        """Shutdown the plugin"""
        if self.session:
            await self.session.close()
        return True
    
    async def _request(self, method: str, endpoint: str, 
                      data: Dict = None) -> Dict[str, Any]:
        """Make API request to GitHub"""
        url = f"{self.base_url}{endpoint}"
        
        try:
            async with self.session.request(method, url, json=data) as resp:
                if resp.status == 200 or resp.status == 201:
                    return {"success": True, "data": await resp.json()}
                elif resp.status == 404:
                    return {"success": False, "error": "Not found"}
                elif resp.status == 401:
                    return {"success": False, "error": "Authentication required"}
                elif resp.status == 403:
                    error_data = await resp.json()
                    return {"success": False, "error": error_data.get("message", "Forbidden")}
                else:
                    return {"success": False, "error": f"HTTP {resp.status}"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def get_repo(self, owner: str, repo: str) -> Dict[str, Any]:
        """
        Get repository information
        
        Args:
            owner: Repository owner (username or organization)
            repo: Repository name
            
        Returns:
            Repository information dict
        """
        result = await self._request("GET", f"/repos/{owner}/{repo}")
        
        if result["success"]:
            data = result["data"]
            return {
                "success": True,
                "name": data["name"],
                "full_name": data["full_name"],
                "description": data.get("description", ""),
                "url": data["html_url"],
                "stars": data["stargazers_count"],
                "forks": data["forks_count"],
                "language": data.get("language", "Unknown"),
                "open_issues": data["open_issues_count"],
                "created_at": data["created_at"],
                "updated_at": data["updated_at"],
                "default_branch": data["default_branch"],
                "is_private": data["private"]
            }
        return result
    
    async def list_repos(self, username: str = None, 
                        sort: str = "updated",
                        limit: int = 10) -> Dict[str, Any]:
        """
        List repositories for a user
        
        Args:
            username: GitHub username (uses authenticated user if not provided)
            sort: Sort by (created, updated, pushed, full_name)
            limit: Maximum number of repos to return
            
        Returns:
            List of repositories
        """
        if username:
            endpoint = f"/users/{username}/repos"
        else:
            endpoint = "/user/repos"
        
        endpoint += f"?sort={sort}&per_page={limit}"
        
        result = await self._request("GET", endpoint)
        
        if result["success"]:
            repos = []
            for repo in result["data"][:limit]:
                repos.append({
                    "name": repo["name"],
                    "full_name": repo["full_name"],
                    "description": repo.get("description", ""),
                    "url": repo["html_url"],
                    "stars": repo["stargazers_count"],
                    "language": repo.get("language", ""),
                    "updated_at": repo["updated_at"]
                })
            return {"success": True, "repos": repos, "count": len(repos)}
        return result
    
    async def get_file_content(self, owner: str, repo: str, 
                               path: str, branch: str = None) -> Dict[str, Any]:
        """
        Get file content from a repository
        
        Args:
            owner: Repository owner
            repo: Repository name
            path: File path in repository
            branch: Branch name (uses default if not specified)
            
        Returns:
            File content
        """
        endpoint = f"/repos/{owner}/{repo}/contents/{path}"
        if branch:
            endpoint += f"?ref={branch}"
        
        result = await self._request("GET", endpoint)
        
        if result["success"]:
            data = result["data"]
            
            if data.get("type") == "file":
                content = data.get("content", "")
                if content:
                    # Decode base64 content
                    try:
                        decoded = base64.b64decode(content).decode('utf-8')
                        return {
                            "success": True,
                            "path": path,
                            "content": decoded,
                            "size": data.get("size", 0),
                            "sha": data.get("sha", "")
                        }
                    except Exception as e:
                        return {"success": False, "error": f"Failed to decode: {e}"}
            else:
                # It's a directory
                return {
                    "success": True,
                    "type": "directory",
                    "files": [f["name"] for f in data]
                }
        return result
    
    async def get_readme(self, owner: str, repo: str) -> Dict[str, Any]:
        """
        Get repository README content
        
        Args:
            owner: Repository owner
            repo: Repository name
            
        Returns:
            README content
        """
        result = await self._request("GET", f"/repos/{owner}/{repo}/readme")
        
        if result["success"]:
            data = result["data"]
            content = data.get("content", "")
            if content:
                try:
                    decoded = base64.b64decode(content).decode('utf-8')
                    return {
                        "success": True,
                        "name": data.get("name", "README.md"),
                        "content": decoded
                    }
                except:
                    pass
        return {"success": False, "error": "README not found or could not be decoded"}
    
    async def create_issue(self, owner: str, repo: str, 
                          title: str, body: str = "",
                          labels: List[str] = None) -> Dict[str, Any]:
        """
        Create a new issue
        
        Args:
            owner: Repository owner
            repo: Repository name
            title: Issue title
            body: Issue body/description
            labels: List of label names
            
        Returns:
            Created issue information
        """
        if not self.token:
            return {"success": False, "error": "Authentication required to create issues"}
        
        data = {
            "title": title,
            "body": body
        }
        if labels:
            data["labels"] = labels
        
        result = await self._request("POST", f"/repos/{owner}/{repo}/issues", data)
        
        if result["success"]:
            issue = result["data"]
            return {
                "success": True,
                "number": issue["number"],
                "title": issue["title"],
                "url": issue["html_url"],
                "state": issue["state"]
            }
        return result
    
    async def list_issues(self, owner: str, repo: str,
                         state: str = "open",
                         limit: int = 10) -> Dict[str, Any]:
        """
        List repository issues
        
        Args:
            owner: Repository owner
            repo: Repository name
            state: Issue state (open, closed, all)
            limit: Maximum number of issues
            
        Returns:
            List of issues
        """
        endpoint = f"/repos/{owner}/{repo}/issues?state={state}&per_page={limit}"
        result = await self._request("GET", endpoint)
        
        if result["success"]:
            issues = []
            for issue in result["data"][:limit]:
                # Skip pull requests (they appear in issues API)
                if "pull_request" in issue:
                    continue
                issues.append({
                    "number": issue["number"],
                    "title": issue["title"],
                    "state": issue["state"],
                    "url": issue["html_url"],
                    "created_at": issue["created_at"],
                    "labels": [l["name"] for l in issue.get("labels", [])],
                    "comments": issue["comments"]
                })
            return {"success": True, "issues": issues, "count": len(issues)}
        return result
    
    async def search_repos(self, query: str, 
                          language: str = None,
                          sort: str = "stars",
                          limit: int = 10) -> Dict[str, Any]:
        """
        Search GitHub repositories
        
        Args:
            query: Search query
            language: Filter by programming language
            sort: Sort by (stars, forks, updated)
            limit: Maximum results
            
        Returns:
            Search results
        """
        search_query = query
        if language:
            search_query += f" language:{language}"
        
        import urllib.parse
        encoded_query = urllib.parse.quote(search_query)
        
        endpoint = f"/search/repositories?q={encoded_query}&sort={sort}&per_page={limit}"
        result = await self._request("GET", endpoint)
        
        if result["success"]:
            repos = []
            for repo in result["data"].get("items", [])[:limit]:
                repos.append({
                    "name": repo["name"],
                    "full_name": repo["full_name"],
                    "description": repo.get("description", ""),
                    "url": repo["html_url"],
                    "stars": repo["stargazers_count"],
                    "language": repo.get("language", ""),
                    "owner": repo["owner"]["login"]
                })
            return {
                "success": True,
                "total_count": result["data"].get("total_count", 0),
                "repos": repos
            }
        return result
    
    async def get_user(self, username: str = None) -> Dict[str, Any]:
        """
        Get user information
        
        Args:
            username: GitHub username (uses authenticated user if not provided)
            
        Returns:
            User information
        """
        if username:
            endpoint = f"/users/{username}"
        else:
            endpoint = "/user"
        
        result = await self._request("GET", endpoint)
        
        if result["success"]:
            user = result["data"]
            return {
                "success": True,
                "login": user["login"],
                "name": user.get("name", ""),
                "bio": user.get("bio", ""),
                "company": user.get("company", ""),
                "location": user.get("location", ""),
                "email": user.get("email", ""),
                "public_repos": user["public_repos"],
                "followers": user["followers"],
                "following": user["following"],
                "created_at": user["created_at"],
                "url": user["html_url"],
                "avatar_url": user["avatar_url"]
            }
        return result
    
    async def list_commits(self, owner: str, repo: str,
                          branch: str = None,
                          limit: int = 10) -> Dict[str, Any]:
        """
        List repository commits
        
        Args:
            owner: Repository owner
            repo: Repository name
            branch: Branch name
            limit: Maximum commits
            
        Returns:
            List of commits
        """
        endpoint = f"/repos/{owner}/{repo}/commits?per_page={limit}"
        if branch:
            endpoint += f"&sha={branch}"
        
        result = await self._request("GET", endpoint)
        
        if result["success"]:
            commits = []
            for commit in result["data"][:limit]:
                commit_data = commit["commit"]
                commits.append({
                    "sha": commit["sha"][:7],
                    "message": commit_data["message"].split('\n')[0],
                    "author": commit_data["author"]["name"],
                    "date": commit_data["author"]["date"],
                    "url": commit["html_url"]
                })
            return {"success": True, "commits": commits, "count": len(commits)}
        return result