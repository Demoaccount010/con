#!/usr/bin/env python3
"""
Task Scheduler Plugin for SMILE Agent

Provides scheduled task execution, reminders, and recurring jobs.
"""

import asyncio
import json
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Callable
from dataclasses import dataclass, field, asdict
from enum import Enum
import uuid
from pathlib import Path

from core.plugin_system import BasePlugin, PluginMetadata, PluginType


class TaskStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class RecurrenceType(Enum):
    ONCE = "once"
    HOURLY = "hourly"
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    CUSTOM = "custom"

@dataclass
class ScheduledTask:
    id: str
    name: str
    description: str
    action: str  # Tool or command to execute
    parameters: Dict[str, Any]
    scheduled_time: datetime
    recurrence: RecurrenceType
    recurrence_interval: int = 1  # e.g., every 2 days
    status: TaskStatus = TaskStatus.PENDING
    created_at: datetime = field(default_factory=datetime.now)
    last_run: Optional[datetime] = None
    next_run: Optional[datetime] = None
    run_count: int = 0
    max_runs: Optional[int] = None  # None = unlimited
    enabled: bool = True
    
    def to_dict(self) -> Dict:
        data = asdict(self)
        data['scheduled_time'] = self.scheduled_time.isoformat()
        data['created_at'] = self.created_at.isoformat()
        data['last_run'] = self.last_run.isoformat() if self.last_run else None
        data['next_run'] = self.next_run.isoformat() if self.next_run else None
        data['status'] = self.status.value
        data['recurrence'] = self.recurrence.value
        return data
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'ScheduledTask':
        data['scheduled_time'] = datetime.fromisoformat(data['scheduled_time'])
        data['created_at'] = datetime.fromisoformat(data['created_at'])
        data['last_run'] = datetime.fromisoformat(data['last_run']) if data['last_run'] else None
        data['next_run'] = datetime.fromisoformat(data['next_run']) if data['next_run'] else None
        data['status'] = TaskStatus(data['status'])
        data['recurrence'] = RecurrenceType(data['recurrence'])
        return cls(**data)


class TaskSchedulerPlugin(BasePlugin):
    """Plugin providing task scheduling capabilities"""
    
    METADATA = PluginMetadata(
        name="task_scheduler",
        version="1.0.0",
        description="Schedule tasks, reminders, and recurring jobs",
        author="SMILE",
        plugin_type=PluginType.UTILITY,
        permissions=[]
    )
    
    def __init__(self, agent, config=None):
        super().__init__(agent, config)
        self.tasks: Dict[str, ScheduledTask] = {}
        self.task_file: Optional[Path] = None
        self._scheduler_task: Optional[asyncio.Task] = None
        self._running = False
        self.check_interval = 30  # seconds
    
    async def initialize(self) -> bool:
        """Initialize the scheduler plugin"""
        # Setup task storage
        if hasattr(self.agent, 'memory_dir'):
            self.task_file = Path(self.agent.memory_dir) / "scheduled_tasks.json"
        else:
            self.task_file = Path("memory") / "scheduled_tasks.json"
        
        # Load existing tasks
        await self._load_tasks()
        
        # Register tools
        self.register_tool("schedule_task", self.schedule_task, 
                          "Schedule a new task")
        self.register_tool("schedule_reminder", self.schedule_reminder,
                          "Set a reminder")
        self.register_tool("list_tasks", self.list_tasks,
                          "List all scheduled tasks")
        self.register_tool("cancel_task", self.cancel_task,
                          "Cancel a scheduled task")
        self.register_tool("get_task", self.get_task_info,
                          "Get task details")
        self.register_tool("pause_task", self.pause_task,
                          "Pause a recurring task")
        self.register_tool("resume_task", self.resume_task,
                          "Resume a paused task")
        
        # Start scheduler loop
        self._running = True
        self._scheduler_task = asyncio.create_task(self._scheduler_loop())
        
        self._initialized = True
        self.logger.info(f"Task Scheduler initialized with {len(self.tasks)} tasks")
        return True
    
    async def shutdown(self) -> bool:
        """Shutdown the scheduler"""
        self._running = False
        
        if self._scheduler_task:
            self._scheduler_task.cancel()
            try:
                await self._scheduler_task
            except asyncio.CancelledError:
                pass
        
        await self._save_tasks()
        return True
    
    async def _load_tasks(self):
        """Load tasks from file"""
        if self.task_file and self.task_file.exists():
            try:
                with open(self.task_file) as f:
                    data = json.load(f)
                    for task_data in data.get("tasks", []):
                        task = ScheduledTask.from_dict(task_data)
                        self.tasks[task.id] = task
                self.logger.info(f"Loaded {len(self.tasks)} scheduled tasks")
            except Exception as e:
                self.logger.error(f"Failed to load tasks: {e}")
    
    async def _save_tasks(self):
        """Save tasks to file"""
        if self.task_file:
            try:
                self.task_file.parent.mkdir(parents=True, exist_ok=True)
                data = {"tasks": [t.to_dict() for t in self.tasks.values()]}
                with open(self.task_file, 'w') as f:
                    json.dump(data, f, indent=2)
            except Exception as e:
                self.logger.error(f"Failed to save tasks: {e}")
    
    async def _scheduler_loop(self):
        """Main scheduler loop"""
        while self._running:
            try:
                await self._check_and_run_tasks()
                await asyncio.sleep(self.check_interval)
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Scheduler error: {e}")
                await asyncio.sleep(self.check_interval)
    
    async def _check_and_run_tasks(self):
        """Check for due tasks and execute them"""
        now = datetime.now()
        
        for task_id, task in list(self.tasks.items()):
            if not task.enabled:
                continue
            
            if task.status != TaskStatus.PENDING:
                continue
            
            # Check if task is due
            run_time = task.next_run or task.scheduled_time
            
            if now >= run_time:
                await self._execute_task(task)
    
    async def _execute_task(self, task: ScheduledTask):
        """Execute a scheduled task"""
        self.logger.info(f"Executing task: {task.name}")
        task.status = TaskStatus.RUNNING
        
        try:
            # Execute the action
            if task.action == "reminder":
                # Send reminder through initiative engine
                if hasattr(self.agent, 'initiative_engine'):
                    await self.agent.initiative_engine.create_initiative(
                        initiative_type="reminder",
                        message=task.description,
                        priority="medium"
                    )
                result = {"success": True, "message": "Reminder sent"}
            
            elif task.action.startswith("tool:"):
                # Execute a tool
                tool_name = task.action.replace("tool:", "")
                if hasattr(self.agent, 'tool_manager'):
                    result = await self.agent.tool_manager.call_tool(
                        tool_name, task.parameters
                    )
                else:
                    result = {"success": False, "error": "Tool manager not available"}
            
            else:
                # Try to process as a command
                if hasattr(self.agent, 'process_input'):
                    result = await self.agent.process_input(task.action)
                else:
                    result = {"success": False, "error": "Unknown action type"}
            
            task.status = TaskStatus.COMPLETED
            task.last_run = datetime.now()
            task.run_count += 1
            
            self.logger.info(f"Task {task.name} completed successfully")
            
        except Exception as e:
            task.status = TaskStatus.FAILED
            self.logger.error(f"Task {task.name} failed: {e}")
        
        # Handle recurrence
        if task.recurrence != RecurrenceType.ONCE:
            if task.max_runs is None or task.run_count < task.max_runs:
                task.next_run = self._calculate_next_run(task)
                task.status = TaskStatus.PENDING
            else:
                task.status = TaskStatus.COMPLETED
        
        await self._save_tasks()
    
    def _calculate_next_run(self, task: ScheduledTask) -> datetime:
        """Calculate next run time for recurring task"""
        base_time = task.last_run or task.scheduled_time
        interval = task.recurrence_interval
        
        if task.recurrence == RecurrenceType.HOURLY:
            return base_time + timedelta(hours=interval)
        elif task.recurrence == RecurrenceType.DAILY:
            return base_time + timedelta(days=interval)
        elif task.recurrence == RecurrenceType.WEEKLY:
            return base_time + timedelta(weeks=interval)
        elif task.recurrence == RecurrenceType.MONTHLY:
            # Approximate month as 30 days
            return base_time + timedelta(days=30 * interval)
        else:
            return base_time + timedelta(hours=interval)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PUBLIC TOOLS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def schedule_task(self, name: str, action: str,
                           when: str,
                           description: str = "",
                           recurrence: str = "once",
                           parameters: Dict = None) -> Dict[str, Any]:
        """
        Schedule a new task
        
        Args:
            name: Task name
            action: Action to perform (tool:name, reminder, or command)
            when: When to run (e.g., "in 5 minutes", "at 14:00", "tomorrow 9am")
            description: Task description
            recurrence: once, hourly, daily, weekly, monthly
            parameters: Parameters for the action
            
        Returns:
            Task creation result
        """
        # Parse when string
        scheduled_time = self._parse_time(when)
        if not scheduled_time:
            return {"success": False, "error": f"Could not parse time: {when}"}
        
        # Parse recurrence
        try:
            recurrence_type = RecurrenceType(recurrence.lower())
        except ValueError:
            recurrence_type = RecurrenceType.ONCE
        
        # Create task
        task = ScheduledTask(
            id=str(uuid.uuid4())[:8],
            name=name,
            description=description or name,
            action=action,
            parameters=parameters or {},
            scheduled_time=scheduled_time,
            recurrence=recurrence_type,
            next_run=scheduled_time
        )
        
        self.tasks[task.id] = task
        await self._save_tasks()
        
        return {
            "success": True,
            "task_id": task.id,
            "name": task.name,
            "scheduled_for": scheduled_time.isoformat(),
            "recurrence": recurrence_type.value
        }
    
    async def schedule_reminder(self, message: str, when: str) -> Dict[str, Any]:
        """
        Set a reminder
        
        Args:
            message: Reminder message
            when: When to remind (e.g., "in 30 minutes", "at 3pm")
            
        Returns:
            Reminder creation result
        """
        return await self.schedule_task(
            name=f"Reminder: {message[:30]}",
            action="reminder",
            when=when,
            description=message,
            recurrence="once"
        )
    
    async def list_tasks(self, include_completed: bool = False) -> Dict[str, Any]:
        """
        List all scheduled tasks
        
        Args:
            include_completed: Include completed tasks
            
        Returns:
            List of tasks
        """
        tasks = []
        
        for task in self.tasks.values():
            if not include_completed and task.status == TaskStatus.COMPLETED:
                continue
            
            tasks.append({
                "id": task.id,
                "name": task.name,
                "status": task.status.value,
                "scheduled_for": (task.next_run or task.scheduled_time).isoformat(),
                "recurrence": task.recurrence.value,
                "enabled": task.enabled,
                "run_count": task.run_count
            })
        
        # Sort by next run time
        tasks.sort(key=lambda t: t["scheduled_for"])
        
        return {
            "success": True,
            "tasks": tasks,
            "count": len(tasks)
        }
    
    async def cancel_task(self, task_id: str) -> Dict[str, Any]:
        """
        Cancel a scheduled task
        
        Args:
            task_id: Task ID to cancel
            
        Returns:
            Cancellation result
        """
        if task_id not in self.tasks:
            return {"success": False, "error": "Task not found"}
        
        task = self.tasks[task_id]
        task.status = TaskStatus.CANCELLED
        task.enabled = False
        
        await self._save_tasks()
        
        return {
            "success": True,
            "task_id": task_id,
            "name": task.name,
            "status": "cancelled"
        }
    
    async def get_task_info(self, task_id: str) -> Dict[str, Any]:
        """
        Get detailed task information
        
        Args:
            task_id: Task ID
            
        Returns:
            Task details
        """
        if task_id not in self.tasks:
            return {"success": False, "error": "Task not found"}
        
        task = self.tasks[task_id]
        
        return {
            "success": True,
            "task": task.to_dict()
        }
    
    async def pause_task(self, task_id: str) -> Dict[str, Any]:
        """Pause a recurring task"""
        if task_id not in self.tasks:
            return {"success": False, "error": "Task not found"}
        
        self.tasks[task_id].enabled = False
        await self._save_tasks()
        
        return {"success": True, "task_id": task_id, "status": "paused"}
    
    async def resume_task(self, task_id: str) -> Dict[str, Any]:
        """Resume a paused task"""
        if task_id not in self.tasks:
            return {"success": False, "error": "Task not found"}
        
        task = self.tasks[task_id]
        task.enabled = True
        task.status = TaskStatus.PENDING
        
        # Recalculate next run if in the past
        if task.next_run and task.next_run < datetime.now():
            task.next_run = self._calculate_next_run(task)
        
        await self._save_tasks()
        
        return {"success": True, "task_id": task_id, "status": "resumed"}
    
    def _parse_time(self, when: str) -> Optional[datetime]:
        """Parse natural language time string"""
        now = datetime.now()
        when_lower = when.lower().strip()
        
        # Handle relative times
        if when_lower.startswith("in "):
            parts = when_lower[3:].split()
            if len(parts) >= 2:
                try:
                    amount = int(parts[0])
                    unit = parts[1].rstrip('s')  # Remove plural
                    
                    if unit in ["minute", "min", "m"]:
                        return now + timedelta(minutes=amount)
                    elif unit in ["hour", "hr", "h"]:
                        return now + timedelta(hours=amount)
                    elif unit in ["day", "d"]:
                        return now + timedelta(days=amount)
                    elif unit in ["week", "wk", "w"]:
                        return now + timedelta(weeks=amount)
                except ValueError:
                    pass
        
        # Handle "at HH:MM"
        if when_lower.startswith("at "):
            time_str = when_lower[3:].strip()
            try:
                # Try 24h format
                if ":" in time_str:
                    parts = time_str.replace("am", "").replace("pm", "").split(":")
                    hour = int(parts[0])
                    minute = int(parts[1]) if len(parts) > 1 else 0
                    
                    if "pm" in when_lower and hour < 12:
                        hour += 12
                    
                    scheduled = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
                    if scheduled <= now:
                        scheduled += timedelta(days=1)
                    return scheduled
            except ValueError:
                pass
        
        # Handle "tomorrow"
        if "tomorrow" in when_lower:
            tomorrow = now + timedelta(days=1)
            # Check for time
            if "at" in when_lower or any(c.isdigit() for c in when_lower):
                time_part = when_lower.split("tomorrow")[-1].strip()
                return self._parse_time(f"at {time_part}") or tomorrow.replace(hour=9, minute=0)
            return tomorrow.replace(hour=9, minute=0, second=0)
        
        # Default: try to parse as datetime
        from dateutil import parser
        try:
            return parser.parse(when, fuzzy=True)
        except:
            return None