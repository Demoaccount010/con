#!/usr/bin/env python3
"""
SMILE AI Agent - Plugins Package

This package contains all plugins that extend SMILE's capabilities.
"""

__all__ = []
__version__ = "1.0.0"