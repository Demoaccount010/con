"""
Admin Logger Utility

Logs important events (deployments, errors, builds) to a configured log channel.
"""

import logging
from typing import Optional
from aiogram import Bot
from bot.config import bot_settings
from bot.utils.messages import Messages

logger = logging.getLogger(__name__)

class AdminLogger:
    """Helper to send logs to admin channel."""
    
    @staticmethod
    async def log(bot: Bot, message: str):
        """Send a simple log message."""
        if not bot_settings.log_channel_id:
            return
            
        try:
            await bot.send_message(
                chat_id=bot_settings.log_channel_id,
                text=message
            )
        except Exception as e:
            logger.error(f"Failed to send admin log: {e}")

    @staticmethod
    async def log_deployment(
        bot: Bot, 
        user_id: int, 
        user_name: str,
        deployment_name: str, 
        repo_url: str,
        status: str = "Started"
    ) -> Optional[int]:
        """
        Log a new deployment event.
        Returns message_id if successful, to allow updating later.
        """
        if not bot_settings.log_channel_id:
            return None
            
        text = (
            f"🚀 <b>New Deployment {status}</b>\n\n"
            f"<b>User:</b> {user_name} (<code>{user_id}</code>)\n"
            f"<b>Name:</b> {deployment_name}\n"
            f"<b>Repo:</b> {repo_url}\n"
        )
        
        try:
            msg = await bot.send_message(
                chat_id=bot_settings.log_channel_id,
                text=text,
                disable_web_page_preview=True
            )
            return msg.message_id
        except Exception as e:
            logger.error(f"Failed to log deployment: {e}")
            return None

    @staticmethod
    async def update_log(bot: Bot, message_id: int, text: str):
        """Update an existing log message."""
        if not bot_settings.log_channel_id or not message_id:
            return
            
        try:
            await bot.edit_message_text(
                chat_id=bot_settings.log_channel_id,
                message_id=message_id,
                text=text,
                disable_web_page_preview=True
            )
        except Exception as e:
            logger.error(f"Failed to update log {message_id}: {e}")
