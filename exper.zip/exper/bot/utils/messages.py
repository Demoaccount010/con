"""
Message Templates

Pre-formatted messages for consistent UX.
"""


class Messages:
    """Collection of bot message templates."""
    
    # Welcome messages
    WELCOME = """
🚀 <b>Welcome to Bot Hosting Platform!</b>

Deploy and manage your Telegram bots with ease.

<b>Your Account:</b>
├ Plan: {plan_name}
├ Deployments: {deployment_count}/{max_deployments}
└ Status: {status}

Use the buttons below to get started!
"""

    WELCOME_NEW = """
🎉 <b>Welcome aboard!</b>

You've been registered with our <b>Free Plan</b>.

Deploy your first bot now!
"""

    FORCE_SUB_TEXT = """
🔒 <b>Access Denied</b>

You must join our channel to use this bot.
Please join {channel} and click "Check Subscription".
"""

    # Deployment messages
    DEPLOY_START = """
🔧 <b>Deploy New Bot</b>

Please send me your GitHub repository URL.

<b>Supported formats:</b>
• https://github.com/user/repo
• git@github.com:user/repo.git

<i>Tip: Make sure your repo has a Dockerfile!</i>
"""

    DEPLOY_DETECTING = """
🔍 <b>Scanning Repository...</b>

Looking for environment variables in:
• .env.example
• config files
• Dockerfile
• Source code

Please wait...
"""

    DEPLOY_CONFIG = """
⚙️ <b>Environment Configuration</b>

I found <b>{count}</b> environment variables:

{variables}

Please provide values for each variable.
Send them one at a time.

Currently configuring: <code>{current_var}</code>
{example}
"""

    DEPLOY_CONFIG_DONE = """
✅ <b>Configuration Complete!</b>

All {count} variables configured.

<b>Summary:</b>
{summary}

Ready to build?
"""

    DEPLOY_BUILDING = """
🏗️ <b>Building Deployment...</b>

<b>Status:</b> {status}
<b>Progress:</b> {progress}

<i>This may take a few minutes...</i>
"""

    DEPLOY_SUCCESS = """
🎊 <b>Deployment Successful!</b>

<b>Name:</b> {name}
<b>Status:</b> 🟢 Running
<b>URL:</b> <code>{url}</code>
<b>VPS:</b> {vps_name}

Your bot is now live!
"""

    DEPLOY_FAILED = """
❌ <b>Deployment Failed</b>

<b>Error Code:</b> <code>{error_code}</code>
<b>Reason:</b> {reason}

<b>Suggested Fix:</b>
{suggested_fix}

Try again or contact support.
"""

    # Status messages
    STATUS_LIST = """
📊 <b>Your Deployments</b>

{deployments}

Select a deployment for details.
"""

    STATUS_ITEM = """
{emoji} <b>{name}</b>
├ Status: {status}
├ RAM: {ram}
├ CPU: {cpu}
├ Restarts: {restarts}
└ Created: {created}
"""

    STATUS_DETAIL = """
📦 <b>Deployment Details</b>

<b>Name:</b> {name}
<b>Status:</b> {status_emoji} {status}
<b>Container:</b> <code>{container_id}</code>

<b>Resources:</b>
├ RAM: {memory_limit}
├ CPU: {cpu_limit} vCPU
└ Storage: {storage_used}

<b>Network:</b>
├ URL: {url}
└ Port: {port}

<b>Repository:</b>
├ URL: {repo_url}
├ Branch: {branch}
└ Commit: <code>{commit}</code>

<b>Health:</b>
├ Status: {health_emoji} {health}
├ Restarts: {restarts}
└ Last Check: {last_check}

<b>Timestamps:</b>
├ Created: {created}
├ Started: {started}
└ Last Activity: {activity}
"""

    # Plans messages
    PLANS_LIST = """
💎 <b>Available Plans</b>

{plans}

<b>Your Current Plan:</b> {current_plan}
{expires}

Select a plan to upgrade!
"""

    PLAN_ITEM = """
{featured}<b>{name}</b> - {price}
├ Deployments: {deployments}
├ RAM: {ram}
├ CPU: {cpu}
├ Storage: {storage}
{features}
"""

    PLAN_UPGRADE = """
💳 <b>Upgrade to {plan_name}</b>

<b>Price:</b> {price}
<b>Duration:</b> {duration} days

<b>Includes:</b>
{features}

Click below to proceed to payment.
"""

    PAYMENT_SUCCESS = """
🎉 <b>Payment Successful!</b>

You've been upgraded to <b>{plan_name}</b>!

Your subscription is active until: {expires}

Enjoy your new features!
"""

    # Logs messages
    LOGS_VIEW = """
📄 <b>Logs: {name}</b>

{logs}

<i>Showing last {count} entries</i>
"""

    LOG_ENTRY = "<code>[{time}]</code> [{level}] {message}"

    # Admin messages
    ADMIN_PANEL = """
👑 <b>Admin Panel</b>

<b>System Stats:</b>
├ Users: {user_count}
├ Deployments: {deployment_count}
├ VPS Nodes: {vps_count}
└ Queue: {queue_length}

<b>Active VPS Nodes:</b>
{vps_stats}

Select an action below.
"""

    VPS_STATS = """
{emoji} <b>{name}</b>
├ Containers: {containers}
├ RAM: {ram}
├ CPU: {cpu}
└ {status}
"""

    # Error messages
    NOT_AUTHORIZED = "❌ You are not authorized to perform this action."
    NOT_FOUND = "❌ Not found. Please try again."
    INVALID_INPUT = "❌ Invalid input. {reason}"
    RATE_LIMITED = "⏳ Too many requests. Please wait {seconds} seconds."
    BANNED = "🚫 Your account has been suspended. Reason: {reason}"
    SUBSCRIPTION_EXPIRED = "⚠️ Your subscription has expired. Upgrade to continue using premium features."

    # Success messages
    STOPPED = "⏹️ Deployment <b>{name}</b> has been stopped."
    STARTED = "▶️ Deployment <b>{name}</b> is starting..."
    RESTARTED = "🔄 Deployment <b>{name}</b> is restarting..."
    DELETED = "🗑️ Deployment <b>{name}</b> has been deleted."

    # Confirmation messages
    CONFIRM_DELETE = """
⚠️ <b>Confirm Deletion</b>

Are you sure you want to delete <b>{name}</b>?

This action cannot be undone.
"""

    CONFIRM_STOP = """
⚠️ <b>Confirm Stop</b>

Stop deployment <b>{name}</b>?

The container will be stopped but not deleted.
"""

    # Broadcast
    BROADCAST_PROMPT = "📢 Send the message you want to broadcast to all users:"
    BROADCAST_CONFIRM = "📢 Broadcast this message to {count} users?"
    BROADCAST_SENT = "✅ Broadcast sent to {count} users!"
