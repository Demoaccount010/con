from aiogram import Bot
from aiogram.types import BotCommand, BotCommandScopeDefault, BotCommandScopeChat

async def set_bot_commands(bot: Bot):
    """Set bot commands for different scopes."""
    
    # Default commands (User)
    user_commands = [
        BotCommand(command="start", description="🏠 Main Menu"),
        BotCommand(command="deploy", description="🚀 Deploy New Bot"),
        BotCommand(command="status", description="📊 My Deployments"),
        BotCommand(command="logs", description="📝 View Logs"),
        BotCommand(command="plans", description="💎 View Plans"),
        BotCommand(command="account", description="👤 My Account"),
        BotCommand(command="help", description="❓ Help & Support"),
    ]
    
    await bot.set_my_commands(user_commands, scope=BotCommandScopeDefault())
    
    # We can also set admin specific commands if we have the list of admin IDs
    # But for now, general commands are enough. Admins can just type /admin
    # or use the hidden command.
