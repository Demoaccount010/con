"""
Input Validators

Validation functions for user input.
"""

import re
from typing import Optional, Tuple


def validate_github_url(url: str) -> Tuple[bool, Optional[str]]:
    """
    Validate GitHub repository URL.
    
    Args:
        url: URL to validate
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    # Clean whitespace
    url = url.strip()
    
    # HTTPS format
    https_pattern = r'^https?://github\.com/[\w\-\.]+/[\w\-\.]+(?:\.git)?/?$'
    
    # SSH format
    ssh_pattern = r'^git@github\.com:[\w\-\.]+/[\w\-\.]+(?:\.git)?$'
    
    if re.match(https_pattern, url):
        return True, None
    
    if re.match(ssh_pattern, url):
        return True, None
    
    return False, "Invalid GitHub URL. Use format: https://github.com/user/repo"


def validate_env_var_name(name: str) -> Tuple[bool, Optional[str]]:
    """
    Validate environment variable name.
    
    Args:
        name: Variable name to validate
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    # Must start with letter or underscore
    # Can contain letters, numbers, underscores
    pattern = r'^[A-Za-z_][A-Za-z0-9_]*$'
    
    if not name:
        return False, "Variable name cannot be empty"
    
    if len(name) > 100:
        return False, "Variable name too long (max 100 characters)"
    
    if not re.match(pattern, name):
        return False, "Invalid variable name. Use only letters, numbers, and underscores"
    
    return True, None


def validate_env_var_value(value: str, var_name: str = "") -> Tuple[bool, Optional[str]]:
    """
    Validate environment variable value.
    
    Args:
        value: Variable value to validate
        var_name: Variable name for context
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    # Allow empty values (some vars have defaults)
    if not value:
        return True, None
    
    # Check for common issues
    if len(value) > 5000:
        return False, "Value too long (max 5000 characters)"
    
    # Warn about potential secrets in logs
    # (actual validation, not blocking)
    
    return True, None


def validate_deployment_name(name: str) -> Tuple[bool, Optional[str]]:
    """
    Validate deployment name.
    
    Args:
        name: Deployment name to validate
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    if not name:
        return False, "Deployment name cannot be empty"
    
    if len(name) > 50:
        return False, "Name too long (max 50 characters)"
    
    if len(name) < 3:
        return False, "Name too short (min 3 characters)"
    
    # Allow letters, numbers, hyphens, underscores
    pattern = r'^[a-zA-Z0-9][a-zA-Z0-9\-_]*[a-zA-Z0-9]$|^[a-zA-Z0-9]{1,2}$'
    
    if not re.match(pattern, name):
        return False, "Invalid name. Use only letters, numbers, hyphens, and underscores"
    
    return True, None


def validate_memory_limit(limit: str) -> Tuple[bool, Optional[str]]:
    """
    Validate Docker memory limit format.
    
    Args:
        limit: Memory limit string (e.g., "512m", "1g")
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    pattern = r'^(\d+)(m|g|mb|gb)$'
    match = re.match(pattern, limit.lower())
    
    if not match:
        return False, "Invalid format. Use like: 512m or 1g"
    
    value = int(match.group(1))
    unit = match.group(2)
    
    # Convert to MB for validation
    if unit in ('g', 'gb'):
        value *= 1024
    
    if value < 128:
        return False, "Minimum memory is 128m"
    
    if value > 8192:
        return False, "Maximum memory is 8g"
    
    return True, None


def validate_cpu_limit(limit: str) -> Tuple[bool, Optional[str]]:
    """
    Validate CPU limit.
    
    Args:
        limit: CPU limit string (e.g., "0.5", "2")
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    try:
        value = float(limit)
    except ValueError:
        return False, "Invalid CPU limit. Use a number like 0.5 or 2"
    
    if value < 0.1:
        return False, "Minimum CPU is 0.1"
    
    if value > 8:
        return False, "Maximum CPU is 8"
    
    return True, None


def parse_github_url(url: str) -> Tuple[str, str]:
    """
    Parse GitHub URL to extract owner and repo.
    
    Args:
        url: GitHub URL
    
    Returns:
        Tuple of (owner, repo)
    """
    # Clean URL
    url = url.strip()
    url = url.rstrip('/')
    url = url.replace('.git', '')
    
    # Handle SSH format
    if url.startswith('git@'):
        parts = url.split(':')[1].split('/')
        return parts[0], parts[1]
    
    # Handle HTTPS format
    parts = url.split('/')
    return parts[-2], parts[-1]
