"""
Subscription Utility

Checks if a user is subscribed to the force subscribe channel.
"""

from typing import Union
from aiogram import Bot
from aiogram.enums import ChatMemberStatus
from bot.config import bot_settings

async def check_subscription(user_id: int, bot: Bot) -> bool:
    """
    Check if user is subscribed to the force sub channel.
    
    Args:
        user_id: The user's Telegram ID
        bot: The bot instance
        
    Returns:
        bool: True if subscribed or no channel set, False otherwise
    """
    if not bot_settings.force_sub_channel_id:
        return True
        
    try:
        member = await bot.get_chat_member(
            chat_id=bot_settings.force_sub_channel_id,
            user_id=user_id
        )
        
        # Check status
        if member.status in [
            ChatMemberStatus.CREATOR,
            ChatMemberStatus.ADMINISTRATOR,
            ChatMemberStatus.MEMBER,
            ChatMemberStatus.RESTRICTED  # Restricted members are still in the chat
        ]:
            return True
            
        return False
        
    except Exception:
        # If we can't check (e.g. bot not admin), allow access to avoid blocking
        # But logging this would be good
        return True
