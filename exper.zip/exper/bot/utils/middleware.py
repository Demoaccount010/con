"""
Bot Middleware

Database and user middleware for handlers.
"""

from typing import Any, Awaitable, Callable, Dict
from aiogram import BaseMiddleware
from aiogram.types import Message, CallbackQuery, TelegramObject
import httpx

from bot.config import bot_settings


class DatabaseMiddleware(BaseMiddleware):
    """Middleware to inject database session into handlers."""
    
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any]
    ) -> Any:
        # Create HTTP client for API calls
        async with httpx.AsyncClient(base_url=bot_settings.api_base_url) as client:
            data["api_client"] = client
            return await handler(event, data)


class UserMiddleware(BaseMiddleware):
    """Middleware to load/create user and check permissions."""
    
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any]
    ) -> Any:
        # Get telegram user
        if isinstance(event, Message):
            tg_user = event.from_user
        elif isinstance(event, CallbackQuery):
            tg_user = event.from_user
        else:
            return await handler(event, data)
        
        if not tg_user:
            return await handler(event, data)
        
        # Get or create user via API
        api_client: httpx.AsyncClient = data.get("api_client")
        
        if api_client:
            try:
                # Try to get existing user
                response = await api_client.get(f"/api/users/{tg_user.id}")
                
                if response.status_code == 200:
                    user_data = response.json()
                else:
                    # Create new user (via start handler)
                    user_data = None
                
                data["user_data"] = user_data
                
                # Check if admin
                data["is_admin"] = tg_user.id in bot_settings.admin_id_list
                
            except Exception:
                data["user_data"] = None
                data["is_admin"] = False
        
        return await handler(event, data)


class RateLimitMiddleware(BaseMiddleware):
    """Middleware to rate limit requests."""
    
    def __init__(self, limit: int = 30, period: int = 60):
        self.limit = limit
        self.period = period
        self.requests: Dict[int, list] = {}
    
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any]
    ) -> Any:
        import time
        
        # Get user ID
        user_id = None
        if isinstance(event, Message):
            user_id = event.from_user.id if event.from_user else None
        elif isinstance(event, CallbackQuery):
            user_id = event.from_user.id if event.from_user else None
        
        if not user_id:
            return await handler(event, data)
        
        # Check rate limit
        now = time.time()
        
        if user_id not in self.requests:
            self.requests[user_id] = []
        
        # Remove old requests
        self.requests[user_id] = [
            t for t in self.requests[user_id]
            if now - t < self.period
        ]
        
        if len(self.requests[user_id]) >= self.limit:
            # Rate limited
            if isinstance(event, Message):
                from bot.utils.messages import Messages
                await event.answer(
                    Messages.RATE_LIMITED.format(seconds=self.period)
                )
            return None
        
        # Record request
        self.requests[user_id].append(now)
        
        return await handler(event, data)


class AdminMiddleware(BaseMiddleware):
    """Middleware to check admin access."""
    
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any]
    ) -> Any:
        # Get user ID
        user_id = None
        if isinstance(event, Message):
            user_id = event.from_user.id if event.from_user else None
        elif isinstance(event, CallbackQuery):
            user_id = event.from_user.id if event.from_user else None
        
        if not user_id:
            return None
        
        # Check if admin
        if user_id not in bot_settings.admin_id_list:
            if isinstance(event, Message):
                from bot.utils.messages import Messages
                await event.answer(Messages.NOT_AUTHORIZED)
            elif isinstance(event, CallbackQuery):
                from bot.utils.messages import Messages
                await event.answer(Messages.NOT_AUTHORIZED, show_alert=True)
            return None
        
        return await handler(event, data)
