"""
Bot Configuration

Telegram bot settings.
"""

from typing import List
from pydantic_settings import BaseSettings, SettingsConfigDict


class BotSettings(BaseSettings):
    """Bot configuration from environment."""
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore"
    )
    
    # Bot
    bot_token: str = ""
    admin_ids: str = ""
    force_sub_channel_id: int | None = None
    log_channel_id: int | None = None
    tutorial_link_key: str = "bot:config:tutorial_link"
    
    # API
    api_base_url: str = "http://localhost:8000"
    
    # Redis
    redis_url: str = "redis://localhost:6379/0"
    
    @property
    def admin_id_list(self) -> List[int]:
        """Parse admin IDs from comma-separated string."""
        if not self.admin_ids:
            return []
        return [int(id.strip()) for id in self.admin_ids.split(",") if id.strip()]


bot_settings = BotSettings()
