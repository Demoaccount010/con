"""
Admin Flow States

FSM states for admin operations.
"""

from aiogram.fsm.state import State, StatesGroup


class AdminStates(StatesGroup):
    """States for admin operations."""
    
    # VPS Management
    waiting_vps_name = State()
    waiting_vps_host = State()
    waiting_vps_port = State()
    waiting_vps_secret = State()
    waiting_vps_max_containers = State()
    
    # Plan Management  
    waiting_plan_name = State()
    waiting_plan_price = State()
    waiting_plan_ram = State()
    waiting_plan_cpu = State()
    waiting_plan_storage = State()
    waiting_plan_deployments = State()
    
    # User Management
    waiting_user_search = State()
    waiting_ban_reason = State()
    
    # Broadcast
    waiting_broadcast_message = State()
    confirming_broadcast = State()
    
    # Force stop
    waiting_container_id = State()
