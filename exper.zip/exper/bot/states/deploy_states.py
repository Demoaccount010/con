"""
Deploy Flow States

FSM states for deployment wizard.
"""

from aiogram.fsm.state import State, StatesGroup


class DeployStates(StatesGroup):
    """States for deployment flow."""
    
    # Initial state - waiting for repo URL
    waiting_repo_url = State()
    
    # Waiting for deployment name
    waiting_name = State()
    
    # Scanning repository for env vars
    scanning = State()
    
    # Configuring environment variables
    configuring_env = State()
    
    # Waiting for specific env var value
    waiting_env_value = State()
    
    # Reviewing configuration before build
    reviewing = State()
    
    # Building in progress
    building = State()
    
    # Edit mode - editing existing deployment
    editing = State()
