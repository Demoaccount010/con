"""
Telegram Bot Main Entry Point

Initializes the bot with handlers and starts polling.
"""

import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.fsm.storage.redis import RedisStorage
from aiogram.client.default import DefaultBotProperties

from bot.config import bot_settings
from bot.handlers import start, deploy, status, logs, plans, admin
from bot.utils.middleware import DatabaseMiddleware, UserMiddleware


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


async def main():
    """Main entry point."""
    logger.info("Starting Telegram Bot...")
    
    # Validate token
    if not bot_settings.bot_token:
        logger.error("BOT_TOKEN is not set!")
        return
    
    # Initialize bot
    bot = Bot(
        token=bot_settings.bot_token,
        default=DefaultBotProperties(
            parse_mode=ParseMode.HTML
        )
    )
    
    # Initialize Redis storage for FSM
    storage = RedisStorage.from_url(bot_settings.redis_url)
    
    # Initialize dispatcher
    dp = Dispatcher(storage=storage)
    
    # Register middleware
    dp.message.middleware(DatabaseMiddleware())
    dp.message.middleware(UserMiddleware())
    dp.callback_query.middleware(DatabaseMiddleware())
    dp.callback_query.middleware(UserMiddleware())
    
    # Register handlers
    dp.include_router(start.router)
    dp.include_router(deploy.router)
    dp.include_router(status.router)
    dp.include_router(logs.router)
    dp.include_router(plans.router)
    dp.include_router(admin.router)
    
    # Start polling
    logger.info("Bot started successfully!")
    
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        await bot.session.close()
        logger.info("Bot stopped")


if __name__ == "__main__":
    asyncio.run(main())
