"""
Main Menu Keyboards

Common keyboards used throughout the bot.
"""

from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder


def get_main_menu(is_admin: bool = False) -> InlineKeyboardMarkup:
    """Get main menu keyboard."""
    builder = InlineKeyboardBuilder()
    
    # Row 1: Main actions
    builder.row(
        InlineKeyboardButton(text="🚀 Deploy New Bot", callback_data="deploy:start"),
        InlineKeyboardButton(text="📊 My Deployments", callback_data="status:list")
    )
    
    # Row 2: Secondary actions
    builder.row(
        InlineKeyboardButton(text="💎 Plans", callback_data="plans:list"),
        InlineKeyboardButton(text="📄 Logs", callback_data="logs:select")
    )
    
    # Row 3: Account
    builder.row(
        InlineKeyboardButton(text="👤 My Account", callback_data="account:view"),
        InlineKeyboardButton(text="❓ Help", callback_data="help:main")
    )
    
    # Admin button
    if is_admin:
        builder.row(
            InlineKeyboardButton(text="👑 Admin Panel", callback_data="admin:panel")
        )
    
    return builder.as_markup()


def get_back_button(callback_data: str = "menu:main") -> InlineKeyboardMarkup:
    """Get simple back button."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="◀️ Back", callback_data=callback_data)]
    ])


def get_deployment_actions(deployment_id: str, is_running: bool = True) -> InlineKeyboardMarkup:
    """Get keyboard with deployment actions."""
    builder = InlineKeyboardBuilder()
    
    if is_running:
        # Running deployment actions
        builder.row(
            InlineKeyboardButton(text="⏹️ Stop", callback_data=f"deploy:stop:{deployment_id}"),
            InlineKeyboardButton(text="🔄 Restart", callback_data=f"deploy:restart:{deployment_id}")
        )
    else:
        # Stopped deployment actions
        builder.row(
            InlineKeyboardButton(text="▶️ Start", callback_data=f"deploy:start_container:{deployment_id}")
        )
    
    # Common actions
    builder.row(
        InlineKeyboardButton(text="📄 Logs", callback_data=f"logs:view:{deployment_id}"),
        InlineKeyboardButton(text="⚙️ Settings", callback_data=f"deploy:settings:{deployment_id}")
    )
    
    builder.row(
        InlineKeyboardButton(text="🗑️ Delete", callback_data=f"deploy:delete_confirm:{deployment_id}")
    )
    
    builder.row(
        InlineKeyboardButton(text="◀️ Back", callback_data="status:list")
    )
    
    return builder.as_markup()


def get_confirmation_keyboard(
    confirm_callback: str,
    cancel_callback: str = "menu:main"
) -> InlineKeyboardMarkup:
    """Get confirmation keyboard."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ Confirm", callback_data=confirm_callback),
            InlineKeyboardButton(text="❌ Cancel", callback_data=cancel_callback)
        ]
    ])


def get_deployments_list(deployments: list) -> InlineKeyboardMarkup:
    """Get keyboard with list of deployments."""
    builder = InlineKeyboardBuilder()
    
    for dep in deployments[:10]:  # Limit to 10
        status_emoji = "🟢" if dep.get("status") == "running" else "🔴"
        builder.row(
            InlineKeyboardButton(
                text=f"{status_emoji} {dep['name']}",
                callback_data=f"status:detail:{dep['id']}"
            )
        )
    
    builder.row(
        InlineKeyboardButton(text="🚀 Deploy New", callback_data="deploy:start"),
        InlineKeyboardButton(text="◀️ Back", callback_data="menu:main")
    )
    
    return builder.as_markup()


def get_pagination_keyboard(
    current_page: int,
    total_pages: int,
    callback_prefix: str
) -> InlineKeyboardMarkup:
    """Get pagination keyboard."""
    builder = InlineKeyboardBuilder()
    
    buttons = []
    
    if current_page > 1:
        buttons.append(
            InlineKeyboardButton(text="◀️", callback_data=f"{callback_prefix}:{current_page - 1}")
        )
    
    buttons.append(
        InlineKeyboardButton(text=f"{current_page}/{total_pages}", callback_data="noop")
    )
    
    if current_page < total_pages:
        buttons.append(
            InlineKeyboardButton(text="▶️", callback_data=f"{callback_prefix}:{current_page + 1}")
        )
    
    builder.row(*buttons)
    
    return builder.as_markup()
