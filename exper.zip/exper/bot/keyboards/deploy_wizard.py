"""
Deploy Wizard Keyboards

Keyboards for the deployment flow.
"""

from typing import List, Dict
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder


def get_deploy_confirm_keyboard(repo_url: str) -> InlineKeyboardMarkup:
    """Get confirmation keyboard for deployment."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ Continue", callback_data="deploy:scan"),
            InlineKeyboardButton(text="❌ Cancel", callback_data="menu:main")
        ]
    ])


def get_env_config_keyboard(
    vars_list: List[Dict],
    current_index: int
) -> InlineKeyboardMarkup:
    """Get keyboard for environment variable configuration."""
    builder = InlineKeyboardBuilder()
    
    total = len(vars_list)
    current_var = vars_list[current_index] if current_index < total else None
    
    # Progress indicator
    filled = "●" * (current_index + 1)
    empty = "○" * (total - current_index - 1)
    progress = f"{filled}{empty} ({current_index + 1}/{total})"
    
    # Skip button (if not required)
    if current_var and not current_var.get("required", True):
        builder.row(
            InlineKeyboardButton(
                text="⏭️ Skip (use default)", 
                callback_data=f"deploy:env_skip:{current_index}"
            )
        )
    
    # Navigation
    nav_buttons = []
    if current_index > 0:
        nav_buttons.append(
            InlineKeyboardButton(text="◀️ Previous", callback_data=f"deploy:env_prev:{current_index}")
        )
    
    nav_buttons.append(
        InlineKeyboardButton(text="❌ Cancel", callback_data="deploy:cancel")
    )
    
    builder.row(*nav_buttons)
    
    return builder.as_markup()


def get_env_review_keyboard(deployment_id: str) -> InlineKeyboardMarkup:
    """Get keyboard for reviewing env configuration."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✏️ Edit Variables", callback_data=f"deploy:env_edit:{deployment_id}"),
        ],
        [
            InlineKeyboardButton(text="🚀 Build & Deploy", callback_data=f"deploy:build:{deployment_id}"),
        ],
        [
            InlineKeyboardButton(text="❌ Cancel", callback_data="deploy:cancel")
        ]
    ])


def get_build_progress_keyboard(deployment_id: str) -> InlineKeyboardMarkup:
    """Get keyboard during build progress."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🔄 Refresh", callback_data=f"deploy:refresh:{deployment_id}")
        ],
        [
            InlineKeyboardButton(text="❌ Cancel Build", callback_data=f"deploy:cancel_build:{deployment_id}")
        ]
    ])


def get_build_complete_keyboard(deployment_id: str) -> InlineKeyboardMarkup:
    """Get keyboard after successful build."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="📊 View Status", callback_data=f"status:detail:{deployment_id}"),
            InlineKeyboardButton(text="📄 View Logs", callback_data=f"logs:view:{deployment_id}")
        ],
        [
            InlineKeyboardButton(text="🚀 Deploy Another", callback_data="deploy:start"),
            InlineKeyboardButton(text="🏠 Main Menu", callback_data="menu:main")
        ]
    ])


def get_build_failed_keyboard(deployment_id: str) -> InlineKeyboardMarkup:
    """Get keyboard after failed build."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="📄 View Logs", callback_data=f"logs:view:{deployment_id}")
        ],
        [
            InlineKeyboardButton(text="🔄 Retry Build", callback_data=f"deploy:retry:{deployment_id}"),
            InlineKeyboardButton(text="✏️ Edit Config", callback_data=f"deploy:env_edit:{deployment_id}")
        ],
        [
            InlineKeyboardButton(text="🗑️ Delete", callback_data=f"deploy:delete_confirm:{deployment_id}"),
            InlineKeyboardButton(text="🏠 Main Menu", callback_data="menu:main")
        ]
    ])


def get_variable_input_example(var: Dict) -> str:
    """Format variable input example."""
    example = var.get("example", "")
    default = var.get("default", "")
    description = var.get("description", "")
    
    lines = []
    
    if description:
        lines.append(f"<i>{description}</i>")
    
    if example:
        lines.append(f"Example: <code>{example}</code>")
    
    if default:
        lines.append(f"Default: <code>{default}</code>")
    
    return "\n".join(lines) if lines else ""
