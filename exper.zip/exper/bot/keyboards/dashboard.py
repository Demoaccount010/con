from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder

def get_dashboard_keyboard(deployment_id: str, status: str) -> InlineKeyboardMarkup:
    """
    Get dashboard keyboard with control buttons.
    Status: running, stopped, building, failed, etc.
    """
    builder = InlineKeyboardBuilder()
    
    is_running = status == "running"
    is_stopped = status == "stopped" or status == "failed"
    
    # Row 1: Controls
    if is_running:
        builder.row(
            InlineKeyboardButton(text="🔄 Restart", callback_data=f"deploy:restart:{deployment_id}"),
            InlineKeyboardButton(text="⏹️ Stop", callback_data=f"deploy:stop:{deployment_id}")
        )
    elif is_stopped:
        builder.row(
            InlineKeyboardButton(text="▶️ Start", callback_data=f"deploy:start:{deployment_id}"),
            InlineKeyboardButton(text="🔄 Restart", callback_data=f"deploy:restart:{deployment_id}")
        )
    else:
        # Building or pending - show refresh
        builder.row(
            InlineKeyboardButton(text="🔄 Refresh Status", callback_data=f"status:detail:{deployment_id}")
        )
        
    # Row 2: Management
    builder.row(
        InlineKeyboardButton(text="📝 Logs", callback_data=f"deploy:logs:{deployment_id}"),
        InlineKeyboardButton(text="⚙️ Env Vars", callback_data=f"deploy:env:{deployment_id}")
    )
    
    # Row 3: Danger Zone & Nav
    builder.row(
        InlineKeyboardButton(text="🗑️ Delete", callback_data=f"deploy:delete_confirm:{deployment_id}"),
        InlineKeyboardButton(text="🔙 Back", callback_data="status:list")
    )
    
    return builder.as_markup()

def get_logs_keyboard(deployment_id: str) -> InlineKeyboardMarkup:
    """Keyboard for logs view."""
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🔄 Refresh Users", callback_data=f"deploy:logs:{deployment_id}"),
        InlineKeyboardButton(text="🔙 Dashboard", callback_data=f"status:detail:{deployment_id}")
    )
    return builder.as_markup()
