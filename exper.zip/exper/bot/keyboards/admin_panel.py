"""
Admin Panel Keyboards

Keyboards for admin functionality.
"""

from typing import List
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder


def get_admin_panel_keyboard() -> InlineKeyboardMarkup:
    """Get main admin panel keyboard."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🖥️ VPS Nodes", callback_data="admin:vps_list"),
            InlineKeyboardButton(text="💎 Plans", callback_data="admin:plans_list")
        ],
        [
            InlineKeyboardButton(text="👥 Users", callback_data="admin:users"),
            InlineKeyboardButton(text="📊 Stats", callback_data="admin:stats")
        ],
        [
            InlineKeyboardButton(text="📢 Broadcast", callback_data="admin:broadcast"),
            InlineKeyboardButton(text="🔧 System", callback_data="admin:system")
        ],
        [
            InlineKeyboardButton(text="🏠 Main Menu", callback_data="menu:main")
        ]
    ])


def get_vps_management_keyboard(vps_nodes: List = None) -> InlineKeyboardMarkup:
    """Get VPS management keyboard."""
    builder = InlineKeyboardBuilder()
    
    # List VPS nodes
    if vps_nodes:
        for node in vps_nodes[:10]:
            status = node.get("status_emoji", "⚫")
            name = node.get("name", "Unknown")
            builder.row(
                InlineKeyboardButton(
                    text=f"{status} {name}",
                    callback_data=f"admin:vps_detail:{node['id']}"
                )
            )
    
    # Actions
    builder.row(
        InlineKeyboardButton(text="➕ Add VPS", callback_data="admin:vps_add"),
        InlineKeyboardButton(text="🔄 Refresh", callback_data="admin:vps_list")
    )
    
    builder.row(
        InlineKeyboardButton(text="◀️ Back", callback_data="admin:panel")
    )
    
    return builder.as_markup()


def get_vps_detail_keyboard(vps_id: int, is_enabled: bool = True) -> InlineKeyboardMarkup:
    """Get VPS detail/actions keyboard."""
    builder = InlineKeyboardBuilder()
    
    if is_enabled:
        builder.row(
            InlineKeyboardButton(text="🔴 Disable", callback_data=f"admin:vps_disable:{vps_id}")
        )
    else:
        builder.row(
            InlineKeyboardButton(text="🟢 Enable", callback_data=f"admin:vps_enable:{vps_id}")
        )
    
    builder.row(
        InlineKeyboardButton(text="📊 Containers", callback_data=f"admin:vps_containers:{vps_id}"),
        InlineKeyboardButton(text="⚙️ Settings", callback_data=f"admin:vps_settings:{vps_id}")
    )
    
    builder.row(
        InlineKeyboardButton(text="🗑️ Remove", callback_data=f"admin:vps_remove_confirm:{vps_id}")
    )
    
    builder.row(
        InlineKeyboardButton(text="◀️ Back", callback_data="admin:vps_list")
    )
    
    return builder.as_markup()


def get_plan_management_keyboard(plans: List = None) -> InlineKeyboardMarkup:
    """Get plan management keyboard."""
    builder = InlineKeyboardBuilder()
    
    # List plans
    if plans:
        for plan in plans:
            featured = "⭐ " if plan.get("is_featured") else ""
            name = plan.get("display_name", plan.get("name", "Unknown"))
            price = plan.get("formatted_price", "₹0")
            builder.row(
                InlineKeyboardButton(
                    text=f"{featured}{name} - {price}",
                    callback_data=f"admin:plan_detail:{plan['id']}"
                )
            )
    
    # Actions
    builder.row(
        InlineKeyboardButton(text="➕ Create Plan", callback_data="admin:plan_create"),
        InlineKeyboardButton(text="🔄 Refresh", callback_data="admin:plans_list")
    )
    
    builder.row(
        InlineKeyboardButton(text="◀️ Back", callback_data="admin:panel")
    )
    
    return builder.as_markup()


def get_plan_detail_keyboard(plan_id: int) -> InlineKeyboardMarkup:
    """Get plan detail/actions keyboard."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="💰 Set Price", callback_data=f"admin:plan_price:{plan_id}"),
            InlineKeyboardButton(text="📊 Set Resources", callback_data=f"admin:plan_resources:{plan_id}")
        ],
        [
            InlineKeyboardButton(text="✏️ Edit", callback_data=f"admin:plan_edit:{plan_id}"),
            InlineKeyboardButton(text="⭐ Toggle Featured", callback_data=f"admin:plan_featured:{plan_id}")
        ],
        [
            InlineKeyboardButton(text="🗑️ Deactivate", callback_data=f"admin:plan_deactivate:{plan_id}")
        ],
        [
            InlineKeyboardButton(text="◀️ Back", callback_data="admin:plans_list")
        ]
    ])


def get_user_management_keyboard() -> InlineKeyboardMarkup:
    """Get user management keyboard."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🔍 Search User", callback_data="admin:user_search"),
            InlineKeyboardButton(text="📊 Stats", callback_data="admin:user_stats")
        ],
        [
            InlineKeyboardButton(text="🚫 Banned Users", callback_data="admin:users_banned"),
            InlineKeyboardButton(text="👑 Admins", callback_data="admin:users_admins")
        ],
        [
            InlineKeyboardButton(text="◀️ Back", callback_data="admin:panel")
        ]
    ])


def get_broadcast_confirm_keyboard() -> InlineKeyboardMarkup:
    """Get broadcast confirmation keyboard."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="📢 Send to All", callback_data="admin:broadcast_confirm"),
            InlineKeyboardButton(text="❌ Cancel", callback_data="admin:panel")
        ]
    ])


def get_system_keyboard() -> InlineKeyboardMarkup:
    """Get system management keyboard."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🔄 Check Offline Nodes", callback_data="admin:check_offline"),
            InlineKeyboardButton(text="📊 Queue Status", callback_data="admin:queue_status")
        ],
        [
            InlineKeyboardButton(text="🧹 Clear Queue", callback_data="admin:clear_queue"),
            InlineKeyboardButton(text="⏰ Check Expired", callback_data="admin:check_expired")
        ],
        [
            InlineKeyboardButton(text="◀️ Back", callback_data="admin:panel")
        ]
    ])
