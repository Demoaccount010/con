"""
Start Handler

Handles /start command and main menu.
"""

from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
import httpx

from bot.utils.messages import Messages
from bot.keyboards.main_menu import get_main_menu
from bot.config import bot_settings


router = Router()


@router.message(Command("start"))
async def cmd_start(
    message: Message,
    api_client: httpx.AsyncClient,
    user_data: dict = None,
    is_admin: bool = False
):
    """Handle /start command."""
    user = message.from_user
    
    # Register/update user via API
    try:
        response = await api_client.get(f"/api/users/{user.id}")
        
        if response.status_code == 200:
            user_data = response.json()
        else:
            # New user - will be created on first action
            user_data = None
    except Exception:
        user_data = None
    
    if user_data:
        # Existing user
        plan_name = user_data.get("plan_name", "Free")
        deployment_count = user_data.get("deployment_count", 0)
        max_deployments = user_data.get("max_deployments", 1)
        
        status = "🟢 Active" if user_data.get("is_subscription_active") else "⚪ Free"
        
        text = Messages.WELCOME.format(
            plan_name=plan_name,
            deployment_count=deployment_count,
            max_deployments=max_deployments,
            status=status
        )
    else:
        # New user
        text = Messages.WELCOME_NEW
    
    await message.answer(
        text,
        reply_markup=get_main_menu(is_admin)
    )


@router.callback_query(F.data == "menu:main")
async def callback_main_menu(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient,
    is_admin: bool = False
):
    """Handle main menu callback."""
    user = callback.from_user
    
    try:
        response = await api_client.get(f"/api/users/{user.id}")
        user_data = response.json() if response.status_code == 200 else None
    except Exception:
        user_data = None
    
    if user_data:
        plan_name = user_data.get("plan_name", "Free")
        deployment_count = user_data.get("deployment_count", 0)
        max_deployments = user_data.get("max_deployments", 1)
        status = "🟢 Active" if user_data.get("is_subscription_active") else "⚪ Free"
        
        text = Messages.WELCOME.format(
            plan_name=plan_name,
            deployment_count=deployment_count,
            max_deployments=max_deployments,
            status=status
        )
    else:
        text = Messages.WELCOME_NEW
    
    await callback.message.edit_text(
        text,
        reply_markup=get_main_menu(is_admin)
    )
    await callback.answer()


@router.callback_query(F.data == "help:main")
async def callback_help(callback: CallbackQuery):
    """Handle help callback."""
    help_text = """
❓ <b>Help & Commands</b>

<b>User Commands:</b>
• /start - Main menu
• /deploy - Deploy a new bot
• /status - View your deployments
• /logs - View deployment logs
• /plans - View available plans
• /upgrade - Upgrade your plan

<b>Deployment Actions:</b>
• Start/Stop/Restart containers
• View real-time logs
• Update environment variables
• Delete deployments

<b>How to Deploy:</b>
1. Send your GitHub repo URL
2. Configure environment variables
3. Click Build & Deploy
4. Your bot goes live!

<b>Requirements:</b>
• Repository must have a Dockerfile
• Or we'll generate one for common stacks

Need help? Contact @support
"""
    
    from bot.keyboards.main_menu import get_back_button
    
    await callback.message.edit_text(
        help_text,
        reply_markup=get_back_button()
    )
    await callback.answer()


@router.callback_query(F.data == "account:view")
async def callback_account(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Handle account view callback."""
    user = callback.from_user
    
    try:
        response = await api_client.get(f"/api/users/{user.id}")
        user_data = response.json() if response.status_code == 200 else None
    except Exception:
        user_data = None
    
    if not user_data:
        await callback.answer("Could not load account data", show_alert=True)
        return
    
    expires = user_data.get("subscription_expires_at", "")
    if expires:
        from datetime import datetime
        exp_date = datetime.fromisoformat(expires.replace("Z", "+00:00"))
        expires_str = exp_date.strftime("%Y-%m-%d")
    else:
        expires_str = "N/A"
    
    account_text = f"""
👤 <b>Your Account</b>

<b>Telegram:</b> @{user.username or 'N/A'}
<b>User ID:</b> <code>{user.id}</code>

<b>Current Plan:</b> {user_data.get('plan_name', 'Free')}
<b>Expires:</b> {expires_str}

<b>Usage:</b>
├ Deployments: {user_data.get('deployment_count', 0)}/{user_data.get('max_deployments', 1)}
├ RAM Limit: {user_data.get('ram_limit_mb', 512)} MB
└ Balance: ₹{user_data.get('balance', '0.00')}

<b>Member Since:</b> {user_data.get('created_at', '')[:10]}
"""
    
    from bot.keyboards.main_menu import get_back_button
    
    await callback.message.edit_text(
        account_text,
        reply_markup=get_back_button()
    )
    await callback.answer()


@router.callback_query(F.data == "noop")
async def callback_noop(callback: CallbackQuery):
    """Handle no-operation callback."""
    await callback.answer()
