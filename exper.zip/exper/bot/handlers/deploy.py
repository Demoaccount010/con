"""
Deploy Handler

Handles deployment flow with env detection wizard.
"""

from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
import httpx

from bot.utils.messages import Messages
from bot.utils.validators import validate_github_url, validate_deployment_name
from bot.keyboards.main_menu import get_back_button
from bot.keyboards.deploy_wizard import (
    get_deploy_confirm_keyboard,
    get_env_config_keyboard,
    get_env_review_keyboard,
    get_build_progress_keyboard,
    get_build_complete_keyboard,
    get_build_failed_keyboard,
    get_variable_input_example
)
from bot.states.deploy_states import DeployStates


router = Router()


@router.message(Command("deploy"))
async def cmd_deploy(message: Message, state: FSMContext):
    """Handle /deploy command."""
    await state.set_state(DeployStates.waiting_repo_url)
    await message.answer(Messages.DEPLOY_START)


@router.callback_query(F.data == "deploy:start")
async def callback_deploy_start(callback: CallbackQuery, state: FSMContext):
    """Handle deploy start callback."""
    await state.set_state(DeployStates.waiting_repo_url)
    await callback.message.edit_text(Messages.DEPLOY_START)
    await callback.answer()


@router.message(DeployStates.waiting_repo_url)
async def process_repo_url(
    message: Message,
    state: FSMContext,
    api_client: httpx.AsyncClient
):
    """Process repository URL input."""
    url = message.text.strip()
    
    # Validate URL
    is_valid, error = validate_github_url(url)
    if not is_valid:
        await message.answer(Messages.INVALID_INPUT.format(reason=error))
        return
    
    # Store URL and ask for name
    await state.update_data(repo_url=url)
    await state.set_state(DeployStates.waiting_name)
    
    # Extract suggested name from URL
    parts = url.rstrip('/').split('/')
    suggested_name = parts[-1].replace('.git', '')
    
    await message.answer(
        f"📝 <b>Deployment Name</b>\n\n"
        f"Enter a name for this deployment.\n\n"
        f"Suggested: <code>{suggested_name}</code>\n\n"
        f"<i>3-50 characters, letters, numbers, hyphens, underscores</i>"
    )


@router.message(DeployStates.waiting_name)
async def process_deployment_name(
    message: Message,
    state: FSMContext,
    api_client: httpx.AsyncClient
):
    """Process deployment name input."""
    name = message.text.strip()
    
    # Validate name
    is_valid, error = validate_deployment_name(name)
    if not is_valid:
        await message.answer(Messages.INVALID_INPUT.format(reason=error))
        return
    
    # Store name and start scanning
    await state.update_data(name=name)
    
    # Show scanning message
    scanning_msg = await message.answer(Messages.DEPLOY_DETECTING)
    
    # Create deployment and detect env vars
    data = await state.get_data()
    
    try:
        # Create deployment
        response = await api_client.post(
            "/api/deployments/",
            params={"telegram_id": message.from_user.id},
            json={
                "name": name,
                "repo_url": data["repo_url"],
                "branch": "main"
            }
        )
        
        if response.status_code != 201:
            error_data = response.json()
            await scanning_msg.edit_text(
                Messages.DEPLOY_FAILED.format(
                    error_code=error_data.get("error_code", "UNKNOWN"),
                    reason=error_data.get("reason", "Failed to create deployment"),
                    suggested_fix=error_data.get("suggested_fix", "Please try again")
                )
            )
            await state.clear()
            return
        
        deployment = response.json()
        deployment_id = deployment["id"]
        
        # Detect environment variables
        detect_response = await api_client.post(
            f"/api/deployments/{deployment_id}/detect-env"
        )
        
        if detect_response.status_code != 200:
            # Failed to detect, but continue
            detected = {"detected_vars": [], "source_files": []}
        else:
            detected = detect_response.json()
        
        detected_vars = detected.get("detected_vars", [])
        
        # Store deployment ID and vars
        await state.update_data(
            deployment_id=deployment_id,
            detected_vars=detected_vars,
            env_values={},
            current_var_index=0
        )
        
        if detected_vars:
            # Start env configuration
            await state.set_state(DeployStates.waiting_env_value)
            
            first_var = detected_vars[0]
            required = "🔴 Required" if first_var.get("required", True) else "🟢 Optional"
            example = get_variable_input_example(first_var)
            
            var_list = "\n".join([
                f"• <code>{v['name']}</code>" + (" ⚠️" if v.get("required") else "")
                for v in detected_vars
            ])
            
            await scanning_msg.edit_text(
                Messages.DEPLOY_CONFIG.format(
                    count=len(detected_vars),
                    variables=var_list,
                    current_var=first_var["name"],
                    example=f"\n{example}" if example else ""
                ) + f"\n\n{required}",
                reply_markup=get_env_config_keyboard(detected_vars, 0)
            )
        else:
            # No env vars detected, go straight to build
            await state.set_state(DeployStates.reviewing)
            await scanning_msg.edit_text(
                "✅ <b>No environment variables detected!</b>\n\n"
                "Ready to build your deployment?",
                reply_markup=get_env_review_keyboard(deployment_id)
            )
            
    except Exception as e:
        await scanning_msg.edit_text(
            Messages.DEPLOY_FAILED.format(
                error_code="SCAN_001",
                reason=str(e),
                suggested_fix="Please check your repository and try again"
            )
        )
        await state.clear()


@router.message(DeployStates.waiting_env_value)
async def process_env_value(
    message: Message,
    state: FSMContext
):
    """Process environment variable value input."""
    value = message.text.strip()
    data = await state.get_data()
    
    detected_vars = data.get("detected_vars", [])
    current_index = data.get("current_var_index", 0)
    env_values = data.get("env_values", {})
    
    if current_index >= len(detected_vars):
        return
    
    current_var = detected_vars[current_index]
    var_name = current_var["name"]
    
    # Check if required and empty
    if current_var.get("required", True) and not value:
        await message.answer(
            f"⚠️ <code>{var_name}</code> is required. Please provide a value."
        )
        return
    
    # Store value
    if value:
        env_values[var_name] = value
    
    # Move to next var
    next_index = current_index + 1
    
    if next_index >= len(detected_vars):
        # All vars configured, show review
        await state.update_data(env_values=env_values)
        await state.set_state(DeployStates.reviewing)
        
        summary = "\n".join([
            f"• <code>{name}</code> = {'***' if 'secret' in name.lower() or 'key' in name.lower() or 'token' in name.lower() else value[:20] + '...' if len(value) > 20 else value}"
            for name, value in env_values.items()
        ])
        
        deployment_id = data.get("deployment_id")
        
        await message.answer(
            Messages.DEPLOY_CONFIG_DONE.format(
                count=len(env_values),
                summary=summary or "No variables configured"
            ),
            reply_markup=get_env_review_keyboard(deployment_id)
        )
    else:
        # Show next var
        await state.update_data(env_values=env_values, current_var_index=next_index)
        
        next_var = detected_vars[next_index]
        required = "🔴 Required" if next_var.get("required", True) else "🟢 Optional"
        example = get_variable_input_example(next_var)
        
        await message.answer(
            f"✅ <code>{var_name}</code> saved!\n\n"
            f"Now configure: <code>{next_var['name']}</code>\n"
            f"{required}\n"
            f"{example}",
            reply_markup=get_env_config_keyboard(detected_vars, next_index)
        )


@router.callback_query(F.data.startswith("deploy:env_skip:"))
async def callback_skip_env(callback: CallbackQuery, state: FSMContext):
    """Skip optional environment variable."""
    index = int(callback.data.split(":")[-1])
    data = await state.get_data()
    
    detected_vars = data.get("detected_vars", [])
    next_index = index + 1
    
    if next_index >= len(detected_vars):
        # All done
        await state.update_data(current_var_index=next_index)
        await state.set_state(DeployStates.reviewing)
        
        env_values = data.get("env_values", {})
        summary = "\n".join([
            f"• <code>{name}</code> = {'***' if 'secret' in name.lower() else value[:20]}"
            for name, value in env_values.items()
        ]) or "No variables configured"
        
        deployment_id = data.get("deployment_id")
        
        await callback.message.edit_text(
            Messages.DEPLOY_CONFIG_DONE.format(
                count=len(env_values),
                summary=summary
            ),
            reply_markup=get_env_review_keyboard(deployment_id)
        )
    else:
        # Next var
        await state.update_data(current_var_index=next_index)
        
        next_var = detected_vars[next_index]
        required = "🔴 Required" if next_var.get("required", True) else "🟢 Optional"
        example = get_variable_input_example(next_var)
        
        await callback.message.edit_text(
            f"⏭️ Skipped!\n\n"
            f"Now configure: <code>{next_var['name']}</code>\n"
            f"{required}\n"
            f"{example}",
            reply_markup=get_env_config_keyboard(detected_vars, next_index)
        )
    
    await callback.answer()


@router.callback_query(F.data.startswith("deploy:build:"))
async def callback_build(
    callback: CallbackQuery,
    state: FSMContext,
    api_client: httpx.AsyncClient
):
    """Start build process."""
    deployment_id = callback.data.split(":")[-1]
    data = await state.get_data()
    env_values = data.get("env_values", {})
    
    # Show building message
    await callback.message.edit_text(
        Messages.DEPLOY_BUILDING.format(
            status="Queued",
            progress="⏳ Waiting..."
        ),
        reply_markup=get_build_progress_keyboard(deployment_id)
    )
    
    # Configure and start build via API
    try:
        env_vars = [{"name": k, "value": v, "is_secret": False} for k, v in env_values.items()]
        
        response = await api_client.post(
            f"/api/deployments/{deployment_id}/configure",
            json=env_vars
        )
        
        if response.status_code != 200:
            error_data = response.json()
            await callback.message.edit_text(
                Messages.DEPLOY_FAILED.format(
                    error_code=error_data.get("error_code", "BUILD_001"),
                    reason=error_data.get("reason", "Failed to start build"),
                    suggested_fix=error_data.get("suggested_fix", "Please try again")
                ),
                reply_markup=get_build_failed_keyboard(deployment_id)
            )
            return
        
        await callback.message.edit_text(
            Messages.DEPLOY_BUILDING.format(
                status="Building",
                progress="🔨 Build started..."
            ),
            reply_markup=get_build_progress_keyboard(deployment_id)
        )
        
    except Exception as e:
        await callback.message.edit_text(
            Messages.DEPLOY_FAILED.format(
                error_code="BUILD_002",
                reason=str(e),
                suggested_fix="Please check your configuration and try again"
            ),
            reply_markup=get_build_failed_keyboard(deployment_id)
        )
    
    await state.clear()
    await callback.answer()


@router.callback_query(F.data.startswith("deploy:refresh:"))
async def callback_refresh_status(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Refresh deployment status."""
    deployment_id = callback.data.split(":")[-1]
    
    try:
        response = await api_client.get(f"/api/deployments/{deployment_id}")
        
        if response.status_code == 200:
            deployment = response.json()
            status = deployment.get("status", "unknown")
            
            if status == "running":
                await callback.message.edit_text(
                    Messages.DEPLOY_SUCCESS.format(
                        name=deployment.get("name", "Unknown"),
                        url=deployment.get("full_url", "N/A"),
                        vps_name=f"VPS-{deployment.get('vps_node_id', 'N/A')}"
                    ),
                    reply_markup=get_build_complete_keyboard(deployment_id)
                )
            elif status == "failed":
                await callback.message.edit_text(
                    Messages.DEPLOY_FAILED.format(
                        error_code="BUILD_FAIL",
                        reason=deployment.get("status_message", "Build failed"),
                        suggested_fix="Check logs for details"
                    ),
                    reply_markup=get_build_failed_keyboard(deployment_id)
                )
            else:
                await callback.message.edit_text(
                    Messages.DEPLOY_BUILDING.format(
                        status=status.title(),
                        progress=deployment.get("status_message", "Processing...")
                    ),
                    reply_markup=get_build_progress_keyboard(deployment_id)
                )
    except Exception:
        pass
    
    await callback.answer("Refreshed!")


@router.callback_query(F.data == "deploy:cancel")
async def callback_cancel_deploy(callback: CallbackQuery, state: FSMContext):
    """Cancel deployment process."""
    await state.clear()
    
    from bot.keyboards.main_menu import get_main_menu
    
    await callback.message.edit_text(
        "❌ Deployment cancelled.",
        reply_markup=get_main_menu()
    )
    await callback.answer()
