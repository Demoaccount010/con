"""
Plans Handler

Handles plan viewing and upgrades.
"""

from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
import httpx

from bot.utils.messages import Messages
from bot.keyboards.main_menu import get_back_button
from bot.config import bot_settings


router = Router()


@router.message(Command("plans"))
async def cmd_plans(
    message: Message,
    api_client: httpx.AsyncClient
):
    """Handle /plans command."""
    await show_plans(message, api_client)


@router.callback_query(F.data == "plans:list")
async def callback_plans_list(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Show plans list."""
    await show_plans(callback, api_client)
    await callback.answer()


async def show_plans(
    event: Message | CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Show available plans."""
    user = event.from_user if isinstance(event, Message) else event.from_user
    
    try:
        # Get plans
        plans_response = await api_client.get("/api/plans/")
        plans = plans_response.json() if plans_response.status_code == 200 else []
        
        # Get user info
        user_response = await api_client.get(f"/api/users/{user.id}")
        user_data = user_response.json() if user_response.status_code == 200 else {}
        
    except Exception:
        plans = []
        user_data = {}
    
    current_plan = user_data.get("plan_name", "Free")
    expires = user_data.get("subscription_expires_at")
    
    if expires:
        from datetime import datetime
        exp_date = datetime.fromisoformat(expires.replace("Z", "+00:00"))
        expires_str = f"Expires: {exp_date.strftime('%Y-%m-%d')}"
    else:
        expires_str = ""
    
    plan_items = []
    for plan in plans:
        is_featured = plan.get("is_featured", False)
        featured = "⭐ " if is_featured else ""
        
        features = []
        if plan.get("custom_domain"):
            features.append("├ ✅ Custom Domain")
        if plan.get("priority_support"):
            features.append("├ ✅ Priority Support")
        if plan.get("auto_restart"):
            features.append("├ ✅ Auto Restart")
        
        features_str = "\n".join(features) if features else ""
        
        plan_items.append(Messages.PLAN_ITEM.format(
            featured=featured,
            name=plan.get("display_name", plan.get("name")),
            price=plan.get("formatted_price", "Free"),
            deployments=plan.get("max_deployments", 1),
            ram=plan.get("ram_display", "512MB"),
            cpu=f"{plan.get('cpu_limit', 0.5)} vCPU",
            storage=plan.get("storage_display", "1GB"),
            features=features_str
        ))
    
    text = Messages.PLANS_LIST.format(
        plans="\n\n━━━━━━━━━━━━━━━━━━━\n\n".join(plan_items) if plan_items else "No plans available",
        current_plan=current_plan,
        expires=expires_str
    )
    
    # Build keyboard
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    
    builder = InlineKeyboardBuilder()
    
    for plan in plans:
        if plan.get("price", 0) > 0:  # Only paid plans
            builder.row(
                InlineKeyboardButton(
                    text=f"💳 Upgrade to {plan.get('display_name', plan.get('name'))}",
                    callback_data=f"plans:upgrade:{plan['id']}"
                )
            )
    
    builder.row(InlineKeyboardButton(text="◀️ Back", callback_data="menu:main"))
    keyboard = builder.as_markup()
    
    if isinstance(event, Message):
        await event.answer(text, reply_markup=keyboard)
    else:
        await event.message.edit_text(text, reply_markup=keyboard)


@router.callback_query(F.data.startswith("plans:upgrade:"))
async def callback_upgrade_plan(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Show upgrade details and payment link."""
    plan_id = callback.data.split(":")[-1]
    user = callback.from_user
    
    try:
        # Get plan details
        response = await api_client.get(f"/api/plans/{plan_id}")
        
        if response.status_code != 200:
            await callback.answer("Plan not found", show_alert=True)
            return
        
        plan = response.json()
        
    except Exception as e:
        await callback.answer(f"Error: {e}", show_alert=True)
        return
    
    features = []
    if plan.get("max_deployments"):
        features.append(f"• {plan['max_deployments']} Deployments")
    if plan.get("ram_display"):
        features.append(f"• {plan['ram_display']} RAM per deployment")
    if plan.get("cpu_limit"):
        features.append(f"• {plan['cpu_limit']} vCPU")
    if plan.get("custom_domain"):
        features.append("• Custom Domain")
    if plan.get("priority_support"):
        features.append("• Priority Support")
    if plan.get("auto_restart"):
        features.append("• Auto Restart")
    
    text = Messages.PLAN_UPGRADE.format(
        plan_name=plan.get("display_name", plan.get("name")),
        price=plan.get("formatted_price", "₹0"),
        duration=plan.get("duration_days", 30),
        features="\n".join(features)
    )
    
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
    
    # Create payment link button
    # In real implementation, this would create a Razorpay payment link via API
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(
                text="💳 Pay Now",
                callback_data=f"plans:pay:{plan_id}"
            )
        ],
        [
            InlineKeyboardButton(text="◀️ Back", callback_data="plans:list")
        ]
    ])
    
    await callback.message.edit_text(text, reply_markup=keyboard)
    await callback.answer()


@router.callback_query(F.data.startswith("plans:pay:"))
async def callback_pay(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Create payment link and redirect."""
    plan_id = callback.data.split(":")[-1]
    user = callback.from_user
    
    try:
        # Create payment link via API
        response = await api_client.post(
            "/api/payments/create-link",
            json={
                "telegram_id": user.id,
                "plan_id": int(plan_id),
                "currency": "INR"
            }
        )
        
        if response.status_code == 200:
            data = response.json()
            payment_url = data.get("payment_url")
            
            from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
            
            keyboard = InlineKeyboardMarkup(inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="🔗 Open Payment Page",
                        url=payment_url
                    )
                ],
                [
                    InlineKeyboardButton(text="✅ I've Paid", callback_data=f"plans:verify:{data.get('payment_id')}"),
                    InlineKeyboardButton(text="❌ Cancel", callback_data="plans:list")
                ]
            ])
            
            await callback.message.edit_text(
                "💳 <b>Complete Payment</b>\n\n"
                "Click below to open the payment page.\n\n"
                "After payment, click 'I've Paid' to activate your plan.",
                reply_markup=keyboard
            )
        else:
            await callback.answer("Failed to create payment link", show_alert=True)
            
    except Exception as e:
        await callback.answer(f"Error: {e}", show_alert=True)
    
    await callback.answer()


@router.callback_query(F.data.startswith("plans:verify:"))
async def callback_verify_payment(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Verify payment completion."""
    payment_id = callback.data.split(":")[-1]
    
    try:
        # Check payment status
        response = await api_client.get(f"/api/payments/{payment_id}")
        
        if response.status_code == 200:
            payment = response.json()
            status = payment.get("status")
            
            if status == "completed":
                await callback.message.edit_text(
                    Messages.PAYMENT_SUCCESS.format(
                        plan_name=payment.get("plan_name", "Premium"),
                        expires=payment.get("expires_at", "N/A")[:10]
                    ),
                    reply_markup=get_back_button()
                )
            elif status == "pending":
                await callback.answer("Payment still pending. Please complete payment.", show_alert=True)
            else:
                await callback.answer("Payment failed or cancelled.", show_alert=True)
        else:
            await callback.answer("Could not verify payment", show_alert=True)
            
    except Exception as e:
        await callback.answer(f"Error: {e}", show_alert=True)
