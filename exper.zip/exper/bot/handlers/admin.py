"""
Admin Handler

Handles admin panel and management commands.
"""

from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
import httpx

from bot.utils.messages import Messages
from bot.keyboards.admin_panel import (
    get_admin_panel_keyboard,
    get_vps_management_keyboard,
    get_vps_detail_keyboard,
    get_plan_management_keyboard,
    get_plan_detail_keyboard,
    get_user_management_keyboard,
    get_broadcast_confirm_keyboard,
    get_system_keyboard
)
from bot.states.admin_states import AdminStates
from bot.config import bot_settings


router = Router()


def is_admin(user_id: int) -> bool:
    """Check if user is admin."""
    return user_id in bot_settings.admin_id_list


@router.message(Command("admin"))
async def cmd_admin(
    message: Message,
    api_client: httpx.AsyncClient
):
    """Handle /admin command."""
    if not is_admin(message.from_user.id):
        await message.answer(Messages.NOT_AUTHORIZED)
        return
    
    await show_admin_panel(message, api_client)


@router.callback_query(F.data == "admin:panel")
async def callback_admin_panel(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Show admin panel."""
    if not is_admin(callback.from_user.id):
        await callback.answer(Messages.NOT_AUTHORIZED, show_alert=True)
        return
    
    await show_admin_panel(callback, api_client)
    await callback.answer()


async def show_admin_panel(
    event: Message | CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Display admin panel with stats."""
    try:
        # Get stats
        user_count = (await api_client.get("/api/users/stats/count")).json().get("count", 0)
        
        # Get VPS stats
        vps_response = await api_client.get("/api/vps/stats")
        vps_stats = vps_response.json() if vps_response.status_code == 200 else []
        
        vps_count = len(vps_stats)
        deployment_count = sum(v.get("container_count", 0) for v in vps_stats)
        
    except Exception:
        user_count = 0
        vps_count = 0
        deployment_count = 0
        vps_stats = []
    
    # Format VPS stats
    vps_items = []
    for vps in vps_stats[:5]:
        emoji = "🟢" if vps.get("is_online") else "🔴"
        vps_items.append(Messages.VPS_STATS.format(
            emoji=emoji,
            name=vps.get("name", "Unknown"),
            containers=f"{vps.get('container_count', 0)}/{vps.get('max_containers', 10)}",
            ram=f"{vps.get('memory_available', 0):.0f} MB free",
            cpu=f"{vps.get('cpu_usage', 0):.1f}%",
            status=vps.get("status", "unknown")
        ))
    
    text = Messages.ADMIN_PANEL.format(
        user_count=user_count,
        deployment_count=deployment_count,
        vps_count=vps_count,
        queue_length=0,
        vps_stats="\n".join(vps_items) if vps_items else "No VPS nodes configured"
    )
    
    keyboard = get_admin_panel_keyboard()
    
    if isinstance(event, Message):
        await event.answer(text, reply_markup=keyboard)
    else:
        await event.message.edit_text(text, reply_markup=keyboard)


# VPS Management
@router.callback_query(F.data == "admin:vps_list")
async def callback_vps_list(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Show VPS list."""
    if not is_admin(callback.from_user.id):
        await callback.answer(Messages.NOT_AUTHORIZED, show_alert=True)
        return
    
    try:
        response = await api_client.get("/api/vps/")
        vps_nodes = response.json() if response.status_code == 200 else []
    except Exception:
        vps_nodes = []
    
    # Add status emoji
    for node in vps_nodes:
        node["status_emoji"] = "🟢" if node.get("is_online") else "🔴"
    
    text = "🖥️ <b>VPS Node Management</b>\n\nSelect a node to manage:"
    keyboard = get_vps_management_keyboard(vps_nodes)
    
    await callback.message.edit_text(text, reply_markup=keyboard)
    await callback.answer()


@router.callback_query(F.data.startswith("admin:vps_detail:"))
async def callback_vps_detail(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Show VPS details."""
    vps_id = int(callback.data.split(":")[-1])
    
    try:
        response = await api_client.get(f"/api/vps/{vps_id}")
        vps = response.json() if response.status_code == 200 else None
    except Exception:
        vps = None
    
    if not vps:
        await callback.answer("VPS not found", show_alert=True)
        return
    
    status = "🟢 Online" if vps.get("is_online") else "🔴 Offline"
    enabled = "✅ Enabled" if vps.get("is_enabled") else "❌ Disabled"
    
    text = f"""
🖥️ <b>{vps.get('name', 'Unknown')}</b>

<b>Status:</b> {status}
<b>Enabled:</b> {enabled}

<b>Connection:</b>
├ Host: <code>{vps.get('host', 'N/A')}</code>
├ Port: {vps.get('agent_port', 'N/A')}
└ Last Heartbeat: {vps.get('last_heartbeat', 'Never')[:16] if vps.get('last_heartbeat') else 'Never'}

<b>Resources:</b>
├ Containers: {vps.get('current_containers', 0)}/{vps.get('max_containers', 10)}
├ RAM: {vps.get('total_memory', 0)} MB total
├ RAM Free: {vps.get('memory_available', 0):.0f} MB
├ CPU: {vps.get('cpu_usage', 0):.1f}%
└ Load Score: {vps.get('load_score', 0):.2f}

<b>Created:</b> {vps.get('created_at', 'N/A')[:10]}
"""
    
    keyboard = get_vps_detail_keyboard(vps_id, vps.get("is_enabled", True))
    
    await callback.message.edit_text(text, reply_markup=keyboard)
    await callback.answer()


@router.callback_query(F.data.startswith("admin:vps_enable:"))
async def callback_vps_enable(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Enable VPS node."""
    vps_id = int(callback.data.split(":")[-1])
    
    try:
        await api_client.post(f"/api/vps/{vps_id}/enable")
        await callback.answer("✅ VPS enabled", show_alert=True)
    except Exception as e:
        await callback.answer(f"Error: {e}", show_alert=True)


@router.callback_query(F.data.startswith("admin:vps_disable:"))
async def callback_vps_disable(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Disable VPS node."""
    vps_id = int(callback.data.split(":")[-1])
    
    try:
        await api_client.post(f"/api/vps/{vps_id}/disable")
        await callback.answer("❌ VPS disabled", show_alert=True)
    except Exception as e:
        await callback.answer(f"Error: {e}", show_alert=True)


# Plan Management
@router.callback_query(F.data == "admin:plans_list")
async def callback_plans_list(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Show plans list."""
    if not is_admin(callback.from_user.id):
        await callback.answer(Messages.NOT_AUTHORIZED, show_alert=True)
        return
    
    try:
        response = await api_client.get("/api/plans/", params={"active_only": False})
        plans = response.json() if response.status_code == 200 else []
    except Exception:
        plans = []
    
    text = "💎 <b>Plan Management</b>\n\nSelect a plan to edit:"
    keyboard = get_plan_management_keyboard(plans)
    
    await callback.message.edit_text(text, reply_markup=keyboard)
    await callback.answer()


@router.callback_query(F.data.startswith("admin:plan_detail:"))
async def callback_plan_detail(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Show plan details."""
    plan_id = int(callback.data.split(":")[-1])
    
    try:
        response = await api_client.get(f"/api/plans/{plan_id}")
        plan = response.json() if response.status_code == 200 else None
    except Exception:
        plan = None
    
    if not plan:
        await callback.answer("Plan not found", show_alert=True)
        return
    
    featured = "⭐ Featured" if plan.get("is_featured") else ""
    active = "✅ Active" if plan.get("is_active") else "❌ Inactive"
    
    text = f"""
💎 <b>{plan.get('display_name', plan.get('name'))}</b> {featured}

<b>Status:</b> {active}
<b>Price:</b> {plan.get('formatted_price', '₹0')}

<b>Resources:</b>
├ Max Deployments: {plan.get('max_deployments', 1)}
├ RAM: {plan.get('ram_display', '512MB')}
├ CPU: {plan.get('cpu_limit', 0.5)} vCPU
└ Storage: {plan.get('storage_display', '1GB')}

<b>Features:</b>
├ Custom Domain: {'✅' if plan.get('custom_domain') else '❌'}
├ Priority Support: {'✅' if plan.get('priority_support') else '❌'}
└ Auto Restart: {'✅' if plan.get('auto_restart') else '❌'}

<b>Duration:</b> {plan.get('duration_days', 30)} days
"""
    
    keyboard = get_plan_detail_keyboard(plan_id)
    
    await callback.message.edit_text(text, reply_markup=keyboard)
    await callback.answer()


# System Management
@router.callback_query(F.data == "admin:system")
async def callback_system(callback: CallbackQuery):
    """Show system management options."""
    if not is_admin(callback.from_user.id):
        await callback.answer(Messages.NOT_AUTHORIZED, show_alert=True)
        return
    
    text = "🔧 <b>System Management</b>\n\nSelect an action:"
    keyboard = get_system_keyboard()
    
    await callback.message.edit_text(text, reply_markup=keyboard)
    await callback.answer()


@router.callback_query(F.data == "admin:check_offline")
async def callback_check_offline(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Check for offline VPS nodes."""
    try:
        response = await api_client.get("/api/vps/", params={"online_only": False})
        nodes = response.json() if response.status_code == 200 else []
        
        offline = [n for n in nodes if not n.get("is_online")]
        
        if offline:
            names = ", ".join(n.get("name") for n in offline)
            await callback.answer(f"⚠️ Offline nodes: {names}", show_alert=True)
        else:
            await callback.answer("✅ All nodes online!", show_alert=True)
    except Exception as e:
        await callback.answer(f"Error: {e}", show_alert=True)


# Stats
@router.callback_query(F.data == "admin:stats")
async def callback_stats(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Show detailed stats."""
    if not is_admin(callback.from_user.id):
        await callback.answer(Messages.NOT_AUTHORIZED, show_alert=True)
        return
    
    try:
        user_count = (await api_client.get("/api/users/stats/count")).json().get("count", 0)
        vps_response = await api_client.get("/api/vps/stats")
        vps_stats = vps_response.json() if vps_response.status_code == 200 else []
    except Exception:
        user_count = 0
        vps_stats = []
    
    total_containers = sum(v.get("container_count", 0) for v in vps_stats)
    total_memory = sum(v.get("total_memory", 0) for v in vps_stats)
    used_memory = sum(v.get("memory_used", 0) for v in vps_stats)
    
    text = f"""
📊 <b>System Statistics</b>

<b>Users:</b>
├ Total: {user_count}
└ Premium: N/A

<b>Deployments:</b>
├ Total: {total_containers}
├ Running: N/A
└ Stopped: N/A

<b>VPS Nodes:</b>
├ Total: {len(vps_stats)}
├ Online: {sum(1 for v in vps_stats if v.get('is_online'))}
└ Offline: {sum(1 for v in vps_stats if not v.get('is_online'))}

<b>Resources:</b>
├ Total RAM: {total_memory} MB
├ Used RAM: {used_memory:.0f} MB
└ Free RAM: {total_memory - used_memory:.0f} MB
"""
    
    from bot.keyboards.main_menu import get_back_button
    
    await callback.message.edit_text(
        text,
        reply_markup=get_back_button("admin:panel")
    )
    await callback.answer()


# Users
@router.callback_query(F.data == "admin:users")
async def callback_users(callback: CallbackQuery):
    """Show user management."""
    if not is_admin(callback.from_user.id):
        await callback.answer(Messages.NOT_AUTHORIZED, show_alert=True)
        return
    
    text = "👥 <b>User Management</b>\n\nSelect an action:"
    keyboard = get_user_management_keyboard()
    
    await callback.message.edit_text(text, reply_markup=keyboard)
    await callback.answer()


# Broadcast
@router.callback_query(F.data == "admin:broadcast")
async def callback_broadcast(
    callback: CallbackQuery,
    state: FSMContext
):
    """Start broadcast flow."""
    if not is_admin(callback.from_user.id):
        await callback.answer(Messages.NOT_AUTHORIZED, show_alert=True)
        return
    
    await state.set_state(AdminStates.waiting_broadcast_message)
    
    await callback.message.edit_text(Messages.BROADCAST_PROMPT)
    await callback.answer()


@router.message(AdminStates.waiting_broadcast_message)
async def process_broadcast_message(
    message: Message,
    state: FSMContext,
    api_client: httpx.AsyncClient
):
    """Process broadcast message."""
    if not is_admin(message.from_user.id):
        return
    
    broadcast_text = message.text or message.caption or ""
    
    if not broadcast_text:
        await message.answer("Please send a text message.")
        return
    
    await state.update_data(broadcast_message=broadcast_text)
    await state.set_state(AdminStates.confirming_broadcast)
    
    try:
        user_count = (await api_client.get("/api/users/stats/count")).json().get("count", 0)
    except Exception:
        user_count = "?"
    
    await message.answer(
        f"📢 <b>Preview:</b>\n\n{broadcast_text}\n\n" +
        Messages.BROADCAST_CONFIRM.format(count=user_count),
        reply_markup=get_broadcast_confirm_keyboard()
    )


@router.callback_query(F.data == "admin:broadcast_confirm", AdminStates.confirming_broadcast)
async def callback_broadcast_confirm(
    callback: CallbackQuery,
    state: FSMContext,
    api_client: httpx.AsyncClient
):
    """Send broadcast to all users."""
    data = await state.get_data()
    broadcast_message = data.get("broadcast_message", "")
    
    await state.clear()
    
    # In production, this would iterate through users and send messages
    # For now, just acknowledge
    await callback.message.edit_text(
        Messages.BROADCAST_SENT.format(count="all"),
        reply_markup=get_admin_panel_keyboard()
    )
    await callback.answer()
