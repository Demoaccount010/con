"""
Admin Handler

Handles admin panel and management commands.
"""

from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
import httpx

from bot.utils.messages import Messages
from bot.keyboards.admin_panel import (
    get_admin_panel_keyboard,
    get_vps_management_keyboard,
    get_vps_detail_keyboard,
    get_plan_management_keyboard,
    get_plan_detail_keyboard,
    get_user_management_keyboard,
    get_broadcast_confirm_keyboard,
    get_system_keyboard
)
from bot.states.admin_states import AdminStates
from bot.config import bot_settings


router = Router()


def is_admin(user_id: int) -> bool:
    """Check if user is admin."""
    return user_id in bot_settings.admin_id_list


@router.message(Command("admin"))
async def cmd_admin(
    message: Message,
    api_client: httpx.AsyncClient
):
    """Handle /admin command."""
    if not is_admin(message.from_user.id):
        await message.answer(Messages.NOT_AUTHORIZED)
        return
    
    await show_admin_panel(message, api_client)


@router.message(Command("set_tutorial"))
async def cmd_set_tutorial(
    message: Message
):
    """Set tutorial link."""
    if not is_admin(message.from_user.id):
        return
        
    args = message.text.split(maxsplit=1)
    if len(args) >= 2:
        # Set new link
        url = args[1].strip()
        if not url.startswith("http"):
            await message.answer("❌ Invalid link. Must start with http/https.")
            return
            
        import redis.asyncio as redis
        from bot.config import bot_settings
        
        try:
            r = redis.from_url(bot_settings.redis_url, decode_responses=True)
            current = await r.get(bot_settings.tutorial_link_key)
            await r.set(bot_settings.tutorial_link_key, url)
            await r.aclose()
            
            if current:
                await message.answer(f"✅ Tutorial link updated!\nOld: {current}\nNew: {url}")
            else:
                await message.answer(f"✅ Tutorial link set to: {url}")
                
        except Exception as e:
            await message.answer(f"❌ Error: {e}")
    else:
        # Show current
        import redis.asyncio as redis
        from bot.config import bot_settings
        
        try:
            r = redis.from_url(bot_settings.redis_url, decode_responses=True)
            current = await r.get(bot_settings.tutorial_link_key)
            await r.aclose()
            
            if current:
                await message.answer(f"🔗 Current Tutorial Link: {current}\n\nUse `/set_tutorial <url>` to change.")
            else:
                await message.answer("⚠️ No tutorial link set.\nUse `/set_tutorial <url>` to set one.")
        except Exception as e:
            await message.answer(f"❌ Error: {e}")


@router.message(Command("broadcast"))
async def cmd_broadcast(
    message: Message,
    api_client: httpx.AsyncClient,
    bot: Bot
):
    """Broadcast message to all users."""
    if not is_admin(message.from_user.id):
        return

    # Check content
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.answer(
            "⚠️ <b>Usage:</b> `/broadcast <message>`\n\n"
            "Sends a message to ALL users who have deployed a bot.\n"
            "Supports HTML formatting.",
            parse_mode="HTML"
        )
        return

    content = args[1]
    
    # Confirm
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="✅ Yes, Send to All", callback_data="broadcast:confirm"),
        InlineKeyboardButton(text="❌ Cancel", callback_data="broadcast:cancel")
    )
    
    import redis.asyncio as redis
    from bot.config import bot_settings
    
    try:
        r = redis.from_url(bot_settings.redis_url, decode_responses=True)
        await r.setex(f"broadcast:{message.from_user.id}", 3600, content)
        await r.aclose()
        
        await message.answer(
             f"📢 <b>Broadcast Preview</b>\n\n{content}\n\n"
             "Are you sure you want to send this to ALL users?",
             reply_markup=builder.as_markup(),
             parse_mode="HTML"
        )
    except Exception as e:
        await message.answer(f"❌ Error saving broadcast: {e}")


@router.callback_query(F.data == "admin:panel")
async def callback_admin_panel(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Show admin panel."""
    if not is_admin(callback.from_user.id):
        await callback.answer(Messages.NOT_AUTHORIZED, show_alert=True)
        return
    
    await show_admin_panel(callback, api_client)
    await callback.answer()


async def show_admin_panel(
    event: Message | CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Display admin panel with stats."""
    try:
        # Get stats
        user_count = (await api_client.get("/api/users/stats/count")).json().get("count", 0)
        
        # Get VPS stats
        vps_response = await api_client.get("/api/vps/stats")
        vps_stats = vps_response.json() if vps_response.status_code == 200 else []
        
        vps_count = len(vps_stats)
        deployment_count = sum(v.get("container_count", 0) for v in vps_stats)
        
    except Exception:
        user_count = 0
        vps_count = 0
        deployment_count = 0
        vps_stats = []
    
    # Format VPS stats
    vps_items = []
    for vps in vps_stats[:5]:
        emoji = "🟢" if vps.get("is_online") else "🔴"
        vps_items.append(Messages.VPS_STATS.format(
            emoji=emoji,
            name=vps.get("name", "Unknown"),
            containers=f"{vps.get('container_count', 0)}/{vps.get('max_containers', 10)}",
            ram=f"{vps.get('memory_available', 0):.0f} MB free",
            cpu=f"{vps.get('cpu_usage', 0):.1f}%",
            status=vps.get("status", "unknown")
        ))
    
    text = Messages.ADMIN_PANEL.format(
        user_count=user_count,
        deployment_count=deployment_count,
        vps_count=vps_count,
        queue_length=0,
        vps_stats="\n".join(vps_items) if vps_items else "No VPS nodes configured"
    )
    
    keyboard = get_admin_panel_keyboard()
    
    if isinstance(event, Message):
        await event.answer(text, reply_markup=keyboard)
    else:
        await event.message.edit_text(text, reply_markup=keyboard)


# VPS Management
@router.callback_query(F.data == "admin:vps_list")
async def callback_vps_list(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Show VPS list."""
    if not is_admin(callback.from_user.id):
        await callback.answer(Messages.NOT_AUTHORIZED, show_alert=True)
        return
    
    try:
        response = await api_client.get("/api/vps/")
        vps_nodes = response.json() if response.status_code == 200 else []
    except Exception:
        vps_nodes = []
    
    # Add status emoji
    for node in vps_nodes:
        node["status_emoji"] = "🟢" if node.get("is_online") else "🔴"
    
    text = "🖥️ <b>VPS Node Management</b>\n\nSelect a node to manage:"
    keyboard = get_vps_management_keyboard(vps_nodes)
    
    await callback.message.edit_text(text, reply_markup=keyboard)
    await callback.answer()


@router.callback_query(F.data.startswith("admin:vps_detail:"))
async def callback_vps_detail(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Show VPS details."""
    vps_id = int(callback.data.split(":")[-1])
    
    try:
        response = await api_client.get(f"/api/vps/{vps_id}")
        vps = response.json() if response.status_code == 200 else None
    except Exception:
        vps = None
    
    if not vps:
        await callback.answer("VPS not found", show_alert=True)
        return
    
    status = "🟢 Online" if vps.get("is_online") else "🔴 Offline"
    enabled = "✅ Enabled" if vps.get("is_enabled") else "❌ Disabled"
    
    text = f"""
🖥️ <b>{vps.get('name', 'Unknown')}</b>

<b>Status:</b> {status}
<b>Enabled:</b> {enabled}

<b>Connection:</b>
├ Host: <code>{vps.get('host', 'N/A')}</code>
├ Port: {vps.get('agent_port', 'N/A')}
└ Last Heartbeat: {vps.get('last_heartbeat', 'Never')[:16] if vps.get('last_heartbeat') else 'Never'}

<b>Resources:</b>
├ Containers: {vps.get('current_containers', 0)}/{vps.get('max_containers', 10)}
├ RAM: {vps.get('total_memory', 0)} MB total
├ RAM Free: {vps.get('memory_available', 0):.0f} MB
├ CPU: {vps.get('cpu_usage', 0):.1f}%
└ Load Score: {vps.get('load_score', 0):.2f}

<b>Created:</b> {vps.get('created_at', 'N/A')[:10]}
"""
    
    keyboard = get_vps_detail_keyboard(vps_id, vps.get("is_enabled", True))
    
    await callback.message.edit_text(text, reply_markup=keyboard)
    await callback.answer()


# VPS Management
@router.callback_query(F.data == "admin:vps_add")
async def callback_vps_add(
    callback: CallbackQuery,
    state: FSMContext
):
    """Start VPS addition wizard."""
    if not is_admin(callback.from_user.id):
        await callback.answer(Messages.NOT_AUTHORIZED, show_alert=True)
        return
    
    await state.set_state(AdminStates.waiting_vps_name)
    await state.update_data(vps_data={})
    
    await callback.message.edit_text(
        "➕ <b>Add VPS Node</b>\n\n"
        "Step 1/5: Enter a friendly name for this node (e.g., 'US-East-1'):"
    )
    await callback.answer()


@router.message(AdminStates.waiting_vps_name)
async def process_vps_name(
    message: Message,
    state: FSMContext
):
    """Process VPS name."""
    if not is_admin(message.from_user.id):
        return
    
    name = message.text.strip()
    if len(name) < 2:
        await message.answer("❌ Name too short. Try again:")
        return
        
    await state.update_data(vps_name=name)
    await state.set_state(AdminStates.waiting_vps_host)
    
    await message.answer(
        f"✅ Name: <b>{name}</b>\n\n"
        "Step 2/5: Enter the IP address or Hostname (e.g., '192.168.1.10'):"
    )


@router.message(AdminStates.waiting_vps_host)
async def process_vps_host(
    message: Message,
    state: FSMContext
):
    """Process VPS host."""
    if not is_admin(message.from_user.id):
        return
    
    host = message.text.strip()
    # Simple validation
    if len(host) < 3:
        await message.answer("❌ Invalid host. Try again:")
        return
        
    await state.update_data(vps_host=host)
    await state.set_state(AdminStates.waiting_vps_port)
    
    await message.answer(
        f"✅ Host: <b>{host}</b>\n\n"
        "Step 3/5: Enter the Agent Port (default is 8000):"
    )


@router.message(AdminStates.waiting_vps_port)
async def process_vps_port(
    message: Message,
    state: FSMContext
):
    """Process VPS port."""
    if not is_admin(message.from_user.id):
        return
    
    try:
        port = int(message.text.strip())
        if port < 1 or port > 65535:
            raise ValueError
    except ValueError:
        await message.answer("❌ Invalid port. Enter a number between 1-65535:")
        return
        
    await state.update_data(vps_port=port)
    await state.set_state(AdminStates.waiting_vps_secret)
    
    await message.answer(
        f"✅ Port: <b>{port}</b>\n\n"
        "Step 4/5: Enter the Agent Secret Key (must match the one on the VPS):"
    )


@router.message(AdminStates.waiting_vps_secret)
async def process_vps_secret(
    message: Message,
    state: FSMContext
):
    """Process VPS secret."""
    if not is_admin(message.from_user.id):
        return
    
    secret = message.text.strip()
    if len(secret) < 1:
        await message.answer("❌ Secret cannot be empty. Try again:")
        return
        
    await state.update_data(vps_secret=secret)
    await state.set_state(AdminStates.waiting_vps_max_containers)
    
    await message.answer(
        "✅ Secret set.\n\n"
        "Step 5/5: Enter Max Containers allowed (e.g., 10, 20, 50):"
    )


@router.message(AdminStates.waiting_vps_max_containers)
async def process_vps_max_containers(
    message: Message,
    state: FSMContext,
    api_client: httpx.AsyncClient
):
    """Process max containers and create VPS."""
    if not is_admin(message.from_user.id):
        return
    
    try:
        max_c = int(message.text.strip())
        if max_c < 1:
            raise ValueError
    except ValueError:
        await message.answer("❌ Invalid number. Try again:")
        return
    
    data = await state.get_data()
    
    vps_payload = {
        "name": data.get("vps_name"),
        "host": data.get("vps_host"),
        "agent_port": data.get("vps_port"),
        "agent_secret": data.get("vps_secret"),
        "max_containers": max_c,
        "is_enabled": True
    }
    
    await state.clear()
    
    try:
        response = await api_client.post("/api/vps/", json=vps_payload)
        
        if response.status_code in [200, 201]:
            await message.answer(
                f"✅ <b>VPS Node Added Successfully!</b>\n\n"
                f"<b>Name:</b> {vps_payload['name']}\n"
                f"<b>Host:</b> {vps_payload['host']}:{vps_payload['agent_port']}\n"
                f"<b>Capacity:</b> {max_c} containers\n\n"
                "The system will attempt to connect to it shortly.",
                reply_markup=get_admin_panel_keyboard()
            )
        else:
            await message.answer(
                f"❌ Failed to add VPS: {response.text}",
                reply_markup=get_admin_panel_keyboard()
            )
    except Exception as e:
        await message.answer(
            f"❌ Error: {str(e)}",
            reply_markup=get_admin_panel_keyboard()
        )


@router.callback_query(F.data.startswith("admin:vps_containers:"))
async def callback_vps_containers(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Show containers on this VPS."""
    if not is_admin(callback.from_user.id):
        await callback.answer(Messages.NOT_AUTHORIZED, show_alert=True)
        return
        
    vps_id = int(callback.data.split(":")[-1])
    
    try:
        # This endpoint might need to be implemented in backend if not exists
        # For now assuming we can filter deployments by vps_id
        response = await api_client.get(f"/api/deployments/", params={"vps_id": vps_id})
        deployments = response.json() if response.status_code == 200 else []
        
        if not deployments:
            await callback.answer("No containers running on this node.", show_alert=True)
            return
            
        text = f"📦 <b>Containers on VPS #{vps_id}</b>\n\n"
        for d in deployments[:10]:
            text += f"• {d.get('name')} (User: {d.get('user_id')}) - {d.get('status')}\n"
            
        await callback.message.edit_text(
            text, 
            reply_markup=get_vps_detail_keyboard(vps_id, True)
        )
    except Exception as e:
        await callback.answer(f"Error: {e}", show_alert=True)


@router.callback_query(F.data.startswith("admin:vps_remove_confirm:"))
async def callback_vps_remove_confirm(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Confirm VPS removal."""
    if not is_admin(callback.from_user.id):
        await callback.answer(Messages.NOT_AUTHORIZED, show_alert=True)
        return
        
    vps_id = int(callback.data.split(":")[-1])
    
    # Simple confirmation - in prod use a dedicated confirmation keyboard
    try:
        await api_client.delete(f"/api/vps/{vps_id}")
        await callback.answer("✅ VPS Removed", show_alert=True)
        await callback_vps_list(callback, api_client)
    except Exception as e:
        await callback.answer(f"Error: {e}", show_alert=True)


@router.callback_query(F.data.startswith("admin:vps_enable:"))
async def callback_vps_enable(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Enable VPS node."""
    vps_id = int(callback.data.split(":")[-1])
    
    try:
        await api_client.post(f"/api/vps/{vps_id}/enable")
        await callback.answer("✅ VPS enabled", show_alert=True)
    except Exception as e:
        await callback.answer(f"Error: {e}", show_alert=True)


@router.callback_query(F.data.startswith("admin:vps_disable:"))
async def callback_vps_disable(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Disable VPS node."""
    vps_id = int(callback.data.split(":")[-1])
    
    try:
        await api_client.post(f"/api/vps/{vps_id}/disable")
        await callback.answer("❌ VPS disabled", show_alert=True)
    except Exception as e:
        await callback.answer(f"Error: {e}", show_alert=True)


# Plan Management
@router.callback_query(F.data == "admin:plans_list")
async def callback_plans_list(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Show plans list."""
    if not is_admin(callback.from_user.id):
        await callback.answer(Messages.NOT_AUTHORIZED, show_alert=True)
        return
    
    try:
        response = await api_client.get("/api/plans/", params={"active_only": False})
        plans = response.json() if response.status_code == 200 else []
    except Exception:
        plans = []
    
    text = "💎 <b>Plan Management</b>\n\nSelect a plan to edit:"
    keyboard = get_plan_management_keyboard(plans)
    
    await callback.message.edit_text(text, reply_markup=keyboard)
    await callback.answer()


@router.callback_query(F.data.startswith("admin:plan_detail:"))
async def callback_plan_detail(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Show plan details."""
    plan_id = int(callback.data.split(":")[-1])
    
    try:
        response = await api_client.get(f"/api/plans/{plan_id}")
        plan = response.json() if response.status_code == 200 else None
    except Exception:
        plan = None
    
    if not plan:
        await callback.answer("Plan not found", show_alert=True)
        return
    
    featured = "⭐ Featured" if plan.get("is_featured") else ""
    active = "✅ Active" if plan.get("is_active") else "❌ Inactive"
    
    text = f"""
💎 <b>{plan.get('display_name', plan.get('name'))}</b> {featured}

<b>Status:</b> {active}
<b>Price:</b> {plan.get('formatted_price', '₹0')}

<b>Resources:</b>
├ Max Deployments: {plan.get('max_deployments', 1)}
├ RAM: {plan.get('ram_display', '512MB')}
├ CPU: {plan.get('cpu_limit', 0.5)} vCPU
└ Storage: {plan.get('storage_display', '1GB')}

<b>Features:</b>
├ Custom Domain: {'✅' if plan.get('custom_domain') else '❌'}
├ Priority Support: {'✅' if plan.get('priority_support') else '❌'}
└ Auto Restart: {'✅' if plan.get('auto_restart') else '❌'}

<b>Duration:</b> {plan.get('duration_days', 30)} days
"""
    
    keyboard = get_plan_detail_keyboard(plan_id)
    
    await callback.message.edit_text(text, reply_markup=keyboard)
    await callback.answer()


# Plan Creation Flow
@router.callback_query(F.data == "admin:plan_create")
async def callback_plan_create(
    callback: CallbackQuery,
    state: FSMContext
):
    """Start plan creation flow."""
    if not is_admin(callback.from_user.id):
        await callback.answer(Messages.NOT_AUTHORIZED, show_alert=True)
        return
    
    await state.set_state(AdminStates.waiting_plan_name)
    await state.update_data(plan_data={})
    
    await callback.message.edit_text(
        "➕ <b>Create New Plan</b>\n\n"
        "Step 1/6: Enter the plan name (e.g., 'Pro', 'Enterprise'):"
    )
    await callback.answer()


@router.message(AdminStates.waiting_plan_name)
async def process_plan_name(
    message: Message,
    state: FSMContext
):
    """Process plan name input."""
    if not is_admin(message.from_user.id):
        return
    
    plan_name = message.text.strip()
    if len(plan_name) < 2 or len(plan_name) > 50:
        await message.answer("❌ Plan name must be 2-50 characters. Try again:")
        return
    
    data = await state.get_data()
    plan_data = data.get("plan_data", {})
    plan_data["name"] = plan_name
    plan_data["display_name"] = plan_name
    await state.update_data(plan_data=plan_data)
    
    await state.set_state(AdminStates.waiting_plan_price)
    await message.answer(
        f"✅ Plan name: <b>{plan_name}</b>\n\n"
        "Step 2/6: Enter the price in INR (e.g., 99, 199, 499):"
    )


@router.message(AdminStates.waiting_plan_price)
async def process_plan_price(
    message: Message,
    state: FSMContext
):
    """Process plan price input."""
    if not is_admin(message.from_user.id):
        return
    
    try:
        price = float(message.text.strip())
        if price < 0:
            raise ValueError("Price cannot be negative")
    except ValueError:
        await message.answer("❌ Invalid price. Enter a valid number (e.g., 99):")
        return
    
    data = await state.get_data()
    plan_data = data.get("plan_data", {})
    plan_data["price"] = price
    await state.update_data(plan_data=plan_data)
    
    await state.set_state(AdminStates.waiting_plan_ram)
    await message.answer(
        f"✅ Price: <b>₹{price:.0f}</b>\n\n"
        "Step 3/6: Enter RAM limit in MB (e.g., 512, 1024, 2048):"
    )


@router.message(AdminStates.waiting_plan_ram)
async def process_plan_ram(
    message: Message,
    state: FSMContext
):
    """Process plan RAM input."""
    if not is_admin(message.from_user.id):
        return
    
    try:
        ram = int(message.text.strip())
        if ram < 128 or ram > 16384:
            raise ValueError("RAM must be between 128-16384 MB")
    except ValueError:
        await message.answer("❌ Invalid RAM. Enter a valid number between 128-16384 MB:")
        return
    
    data = await state.get_data()
    plan_data = data.get("plan_data", {})
    plan_data["ram_limit_mb"] = ram
    await state.update_data(plan_data=plan_data)
    
    await state.set_state(AdminStates.waiting_plan_cpu)
    await message.answer(
        f"✅ RAM: <b>{ram} MB</b>\n\n"
        "Step 4/6: Enter CPU limit (e.g., 0.5, 1, 2):"
    )


@router.message(AdminStates.waiting_plan_cpu)
async def process_plan_cpu(
    message: Message,
    state: FSMContext
):
    """Process plan CPU input."""
    if not is_admin(message.from_user.id):
        return
    
    try:
        cpu = float(message.text.strip())
        if cpu < 0.1 or cpu > 8:
            raise ValueError("CPU must be between 0.1-8")
    except ValueError:
        await message.answer("❌ Invalid CPU. Enter a valid number between 0.1-8:")
        return
    
    data = await state.get_data()
    plan_data = data.get("plan_data", {})
    plan_data["cpu_limit"] = cpu
    await state.update_data(plan_data=plan_data)
    
    await state.set_state(AdminStates.waiting_plan_storage)
    await message.answer(
        f"✅ CPU: <b>{cpu} vCPU</b>\n\n"
        "Step 5/6: Enter storage limit in MB (e.g., 1024, 5120, 10240):"
    )


@router.message(AdminStates.waiting_plan_storage)
async def process_plan_storage(
    message: Message,
    state: FSMContext
):
    """Process plan storage input."""
    if not is_admin(message.from_user.id):
        return
    
    try:
        storage = int(message.text.strip())
        if storage < 512 or storage > 102400:
            raise ValueError("Storage must be between 512-102400 MB")
    except ValueError:
        await message.answer("❌ Invalid storage. Enter a valid number between 512-102400 MB:")
        return
    
    data = await state.get_data()
    plan_data = data.get("plan_data", {})
    plan_data["storage_limit_mb"] = storage
    await state.update_data(plan_data=plan_data)
    
    await state.set_state(AdminStates.waiting_plan_deployments)
    await message.answer(
        f"✅ Storage: <b>{storage} MB</b>\n\n"
        "Step 6/6: Enter max deployments allowed (e.g., 1, 3, 5, 10):"
    )


@router.message(AdminStates.waiting_plan_deployments)
async def process_plan_deployments(
    message: Message,
    state: FSMContext,
    api_client: httpx.AsyncClient
):
    """Process plan max deployments and create the plan."""
    if not is_admin(message.from_user.id):
        return
    
    try:
        max_deployments = int(message.text.strip())
        if max_deployments < 1 or max_deployments > 100:
            raise ValueError("Deployments must be between 1-100")
    except ValueError:
        await message.answer("❌ Invalid number. Enter a valid number between 1-100:")
        return
    
    data = await state.get_data()
    plan_data = data.get("plan_data", {})
    plan_data["max_deployments"] = max_deployments
    plan_data["duration_days"] = 30  # Default 30 days
    plan_data["is_active"] = True
    
    await state.clear()
    
    # Create plan via API
    try:
        response = await api_client.post("/api/plans/", json=plan_data)
        
        if response.status_code in [200, 201]:
            plan = response.json()
            await message.answer(
                f"✅ <b>Plan Created Successfully!</b>\n\n"
                f"<b>Name:</b> {plan_data.get('display_name')}\n"
                f"<b>Price:</b> ₹{plan_data.get('price', 0):.0f}\n"
                f"<b>RAM:</b> {plan_data.get('ram_limit_mb')} MB\n"
                f"<b>CPU:</b> {plan_data.get('cpu_limit')} vCPU\n"
                f"<b>Storage:</b> {plan_data.get('storage_limit_mb')} MB\n"
                f"<b>Max Deployments:</b> {max_deployments}\n\n"
                "Use /admin to manage plans.",
                reply_markup=get_admin_panel_keyboard()
            )
        else:
            error = response.json().get("detail", "Unknown error")
            await message.answer(
                f"❌ Failed to create plan: {error}\n\n"
                "Use /admin to try again.",
                reply_markup=get_admin_panel_keyboard()
            )
    except Exception as e:
        await message.answer(
            f"❌ Error creating plan: {str(e)}\n\n"
            "Use /admin to try again.",
            reply_markup=get_admin_panel_keyboard()
        )


@router.callback_query(F.data.startswith("admin:plan_edit:"))
async def callback_plan_edit(
    callback: CallbackQuery,
    state: FSMContext
):
    """Start plan edit flow."""
    if not is_admin(callback.from_user.id):
        await callback.answer(Messages.NOT_AUTHORIZED, show_alert=True)
        return
    
    plan_id = int(callback.data.split(":")[-1])
    await callback.answer("✏️ Edit feature coming soon!", show_alert=True)


@router.callback_query(F.data.startswith("admin:plan_price:"))
async def callback_plan_set_price(callback: CallbackQuery):
    """Set plan price."""
    if not is_admin(callback.from_user.id):
        await callback.answer(Messages.NOT_AUTHORIZED, show_alert=True)
        return
    
    await callback.answer("💰 Price editing coming soon!", show_alert=True)


@router.callback_query(F.data.startswith("admin:plan_resources:"))
async def callback_plan_set_resources(callback: CallbackQuery):
    """Set plan resources."""
    if not is_admin(callback.from_user.id):
        await callback.answer(Messages.NOT_AUTHORIZED, show_alert=True)
        return
    
    await callback.answer("📊 Resource editing coming soon!", show_alert=True)


@router.callback_query(F.data.startswith("admin:plan_featured:"))
async def callback_plan_toggle_featured(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Toggle plan featured status."""
    if not is_admin(callback.from_user.id):
        await callback.answer(Messages.NOT_AUTHORIZED, show_alert=True)
        return
    
    plan_id = int(callback.data.split(":")[-1])
    
    try:
        response = await api_client.post(f"/api/plans/{plan_id}/toggle-featured")
        if response.status_code == 200:
            await callback.answer("⭐ Featured status toggled!", show_alert=True)
        else:
            await callback.answer("❌ Failed to toggle featured", show_alert=True)
    except Exception as e:
        await callback.answer(f"Error: {e}", show_alert=True)


@router.callback_query(F.data.startswith("admin:plan_deactivate:"))
async def callback_plan_deactivate(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Deactivate a plan."""
    if not is_admin(callback.from_user.id):
        await callback.answer(Messages.NOT_AUTHORIZED, show_alert=True)
        return
    
    plan_id = int(callback.data.split(":")[-1])
    
    try:
        response = await api_client.delete(f"/api/plans/{plan_id}")
        if response.status_code == 200:
            await callback.answer("🗑️ Plan deactivated!", show_alert=True)
            # Refresh plans list
            await callback_plans_list(callback, api_client)
        else:
            await callback.answer("❌ Failed to deactivate", show_alert=True)
    except Exception as e:
        await callback.answer(f"Error: {e}", show_alert=True)


# System Management
@router.callback_query(F.data == "admin:system")
async def callback_system(callback: CallbackQuery):
    """Show system management options."""
    if not is_admin(callback.from_user.id):
        await callback.answer(Messages.NOT_AUTHORIZED, show_alert=True)
        return
    
    text = "🔧 <b>System Management</b>\n\nSelect an action:"
    keyboard = get_system_keyboard()
    
    await callback.message.edit_text(text, reply_markup=keyboard)
    await callback.answer()

@router.callback_query(F.data == "admin:queue_status")
async def callback_queue_status(callback: CallbackQuery):
    """Show queue status."""
    # Mock response for now
    await callback.answer("📊 Queue: 0 pending, 0 processing", show_alert=True)

@router.callback_query(F.data == "admin:clear_queue")
async def callback_clear_queue(callback: CallbackQuery):
    """Clear queue."""
    # Mock response
    await callback.answer("🧹 Queue cleared!", show_alert=True)

@router.callback_query(F.data == "admin:check_expired")
async def callback_check_expired(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Trigger expiration check."""
    try:
        await api_client.post("/api/system/sync")
        await callback.answer("✅ Sync triggered", show_alert=True)
    except Exception:
        await callback.answer("❌ Sync failed", show_alert=True)

@router.callback_query(F.data == "admin:check_offline")
async def callback_check_offline(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Check for offline VPS nodes."""
    try:
        response = await api_client.get("/api/vps/", params={"online_only": False})
        nodes = response.json() if response.status_code == 200 else []
        
        offline = [n for n in nodes if not n.get("is_online")]
        
        if offline:
            names = ", ".join(n.get("name") for n in offline)
            await callback.answer(f"⚠️ Offline nodes: {names}", show_alert=True)
        else:
            await callback.answer("✅ All nodes online!", show_alert=True)
    except Exception as e:
        await callback.answer(f"Error: {e}", show_alert=True)


# Stats
@router.callback_query(F.data == "admin:stats")
async def callback_stats(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Show detailed stats."""
    if not is_admin(callback.from_user.id):
        await callback.answer(Messages.NOT_AUTHORIZED, show_alert=True)
        return
    
    try:
        user_count = (await api_client.get("/api/users/stats/count")).json().get("count", 0)
        vps_response = await api_client.get("/api/vps/stats")
        vps_stats = vps_response.json() if vps_response.status_code == 200 else []
    except Exception:
        user_count = 0
        vps_stats = []
    
    total_containers = sum(v.get("container_count", 0) for v in vps_stats)
    total_memory = sum(v.get("total_memory", 0) for v in vps_stats)
    used_memory = sum(v.get("memory_used", 0) for v in vps_stats)
    
    text = f"""
📊 <b>System Statistics</b>

<b>Users:</b>
├ Total: {user_count}
└ Premium: N/A

<b>Deployments:</b>
├ Total: {total_containers}
├ Running: N/A
└ Stopped: N/A

<b>VPS Nodes:</b>
├ Total: {len(vps_stats)}
├ Online: {sum(1 for v in vps_stats if v.get('is_online'))}
└ Offline: {sum(1 for v in vps_stats if not v.get('is_online'))}

<b>Resources:</b>
├ Total RAM: {total_memory} MB
├ Used RAM: {used_memory:.0f} MB
└ Free RAM: {total_memory - used_memory:.0f} MB
"""
    
    from bot.keyboards.main_menu import get_back_button
    
    await callback.message.edit_text(
        text,
        reply_markup=get_back_button("admin:panel")
    )
    await callback.answer()


# Users
@router.callback_query(F.data == "admin:users")
async def callback_users(callback: CallbackQuery):
    """Show user management."""
    if not is_admin(callback.from_user.id):
        await callback.answer(Messages.NOT_AUTHORIZED, show_alert=True)
        return
    
    text = "👥 <b>User Management</b>\n\nSelect an action:"
    keyboard = get_user_management_keyboard()
    
    await callback.message.edit_text(text, reply_markup=keyboard)
    await callback.answer()


@router.callback_query(F.data == "admin:user_search")
async def callback_user_search(
    callback: CallbackQuery,
    state: FSMContext
):
    """Search for a user."""
    if not is_admin(callback.from_user.id):
        await callback.answer(Messages.NOT_AUTHORIZED, show_alert=True)
        return
        
    await state.set_state(AdminStates.waiting_user_search)
    await callback.message.edit_text(
        "🔍 <b>Search User</b>\n\n"
        "Enter User ID or Username (without @):"
    )
    await callback.answer()


@router.message(AdminStates.waiting_user_search)
async def process_user_search(
    message: Message,
    state: FSMContext,
    api_client: httpx.AsyncClient
):
    """Process user search."""
    if not is_admin(message.from_user.id):
        return
        
    query = message.text.strip()
    
    try:
        # Try ID first
        if query.isdigit():
            user_id = int(query)
            response = await api_client.get(f"/api/users/{user_id}")
        else:
            # Need an endpoint for username search, fallback to error for now
            await message.answer("❌ Only User ID search is currently supported via API.")
            return

        user_data = response.json() if response.status_code == 200 else None
        
        if user_data:
            from bot.keyboards.main_menu import get_back_button
            
            info = f"""
👤 <b>User Found</b>

<b>ID:</b> <code>{user_data.get('telegram_id')}</code>
<b>Plan:</b> {user_data.get('plan_name')}
<b>Deployments:</b> {user_data.get('deployment_count')}
<b>Balance:</b> ₹{user_data.get('balance')}
<b>Active:</b> {user_data.get('is_active')}
"""
            await message.answer(info, reply_markup=get_back_button("admin:users"))
        else:
            await message.answer("❌ User not found.")
            
    except Exception as e:
        await message.answer(f"❌ Error: {e}")
        
    await state.clear()


@router.callback_query(F.data == "admin:user_stats")
async def callback_user_stats(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Show detailed user stats."""
    try:
        # Get user count
        count_response = await api_client.get("/api/users/stats/count")
        user_count = count_response.json().get("count", 0) if count_response.status_code == 200 else 0
        
        # Get active users (approximate)
        users_response = await api_client.get("/api/users/", params={"limit": 1, "active_only": True})
        # This is not efficient for count, but we need an endpoint for active count.
        # For now, let's just show total.
        
        await callback.answer(f"📊 Total Users: {user_count}", show_alert=True)
        
    except Exception as e:
        await callback.answer(f"❌ Error: {e}", show_alert=True)


@router.callback_query(F.data == "admin:users_banned")
async def callback_users_banned(callback: CallbackQuery):
    """Show banned users."""
    await callback.answer("🚫 No banned users.", show_alert=True)
    
    
@router.callback_query(F.data == "admin:users_admins")
async def callback_users_admins(callback: CallbackQuery):
    """Show admins."""
    admins = ", ".join(str(aid) for aid in bot_settings.admin_id_list)
    await callback.answer(f"👑 Admins: {admins}", show_alert=True)


# Broadcast
@router.callback_query(F.data == "admin:broadcast")
async def callback_broadcast(
    callback: CallbackQuery,
    state: FSMContext
):
    """Start broadcast flow."""
    if not is_admin(callback.from_user.id):
        await callback.answer(Messages.NOT_AUTHORIZED, show_alert=True)
        return
    
    await state.set_state(AdminStates.waiting_broadcast_message)
    
    await callback.message.edit_text(Messages.BROADCAST_PROMPT)
    await callback.answer()


@router.message(AdminStates.waiting_broadcast_message)
async def process_broadcast_message(
    message: Message,
    state: FSMContext,
    api_client: httpx.AsyncClient
):
    """Process broadcast message."""
    if not is_admin(message.from_user.id):
        return
    
    broadcast_text = message.text or message.caption or ""
    
    if not broadcast_text:
        await message.answer("Please send a text message.")
        return
    
    await state.update_data(broadcast_message=broadcast_text)
    await state.set_state(AdminStates.confirming_broadcast)
    
    try:
        user_count = (await api_client.get("/api/users/stats/count")).json().get("count", 0)
    except Exception:
        user_count = "?"
    
    await message.answer(
        f"📢 <b>Preview:</b>\n\n{broadcast_text}\n\n" +
        Messages.BROADCAST_CONFIRM.format(count=user_count),
        reply_markup=get_broadcast_confirm_keyboard()
    )


@router.callback_query(F.data == "admin:broadcast_confirm", AdminStates.confirming_broadcast)
async def callback_broadcast_confirm(
    callback: CallbackQuery,
    state: FSMContext,
    api_client: httpx.AsyncClient
):
    """Send broadcast to all users."""
    data = await state.get_data()
    broadcast_message = data.get("broadcast_message", "")
    
    await state.clear()
    
    # In production, this would iterate through users and send messages
    # For now, just acknowledge
    await callback.message.edit_text(
        Messages.BROADCAST_SENT.format(count="all"),
        reply_markup=get_admin_panel_keyboard()
    )
    await callback.answer()
