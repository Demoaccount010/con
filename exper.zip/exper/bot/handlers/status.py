"""
Status Handler

Handles deployment status viewing.
"""

from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
import httpx

from bot.utils.messages import Messages
from bot.keyboards.main_menu import get_deployments_list, get_deployment_actions, get_back_button


router = Router()


@router.message(Command("status"))
async def cmd_status(
    message: Message,
    api_client: httpx.AsyncClient
):
    """Handle /status command."""
    await show_deployments_list(message, api_client)


@router.callback_query(F.data == "status:list")
async def callback_status_list(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Handle status list callback."""
    await show_deployments_list(callback, api_client)
    await callback.answer()


async def show_deployments_list(
    event: Message | CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Show list of user's deployments."""
    user = event.from_user if isinstance(event, Message) else event.from_user
    
    try:
        response = await api_client.get(
            f"/api/deployments/user/{user.id}"
        )
        
        if response.status_code != 200:
            deployments = []
        else:
            deployments = response.json()
    except Exception:
        deployments = []
    
    if not deployments:
        text = "📭 <b>No Deployments</b>\n\nYou haven't deployed any bots yet.\n\nClick below to deploy your first bot!"
    else:
        items = []
        for dep in deployments[:10]:
            status = dep.get("status", "unknown")
            emoji = {
                "running": "🟢",
                "stopped": "🔴",
                "building": "🟡",
                "pending": "⚪",
                "failed": "❌"
            }.get(status, "⚫")
            
            items.append(Messages.STATUS_ITEM.format(
                emoji=emoji,
                name=dep.get("name", "Unknown"),
                status=status.title(),
                ram=f"{dep.get('memory_used', 0)}/{dep.get('memory_limit','256M')}",
                cpu=f"{dep.get('cpu_used', 0):.1f}%",
                restarts=dep.get("restart_count", 0),
                created=dep.get("created_at", "")[:10]
            ))
        
        text = Messages.STATUS_LIST.format(
            deployments="\n".join(items)
        )
    
    keyboard = get_deployments_list(deployments)
    
    if isinstance(event, Message):
        await event.answer(text, reply_markup=keyboard)
    else:
        await event.message.edit_text(text, reply_markup=keyboard)


@router.callback_query(F.data.startswith("status:detail:"))
async def callback_status_detail(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Show deployment details."""
    deployment_id = callback.data.split(":")[-1]
    
    try:
        response = await api_client.get(f"/api/deployments/{deployment_id}")
        
        if response.status_code != 200:
            await callback.answer("Deployment not found", show_alert=True)
            return
        
        dep = response.json()
    except Exception as e:
        await callback.answer(f"Error: {e}", show_alert=True)
        return
    
    status = dep.get("status", "unknown")
    status_emoji = {
        "running": "🟢",
        "stopped": "🔴", 
        "building": "🟡",
        "pending": "⚪",
        "failed": "❌"
    }.get(status, "⚫")
    
    health = dep.get("health_status", "unknown")
    health_emoji = "✅" if health == "healthy" else "⚠️" if health == "degraded" else "❌"
    
    text = Messages.STATUS_DETAIL.format(
        name=dep.get("name", "Unknown"),
        status_emoji=status_emoji,
        status=status.title(),
        container_id=dep.get("container_id", "N/A")[:12] if dep.get("container_id") else "N/A",
        memory_limit=dep.get("memory_limit", "256M"),
        cpu_limit=dep.get("cpu_limit", "0.5"),
        storage_used="N/A",
        url=dep.get("full_url", "N/A"),
        port=dep.get("port", "N/A"),
        repo_url=dep.get("repo_url", "N/A"),
        branch=dep.get("branch", "main"),
        commit=dep.get("commit_hash", "N/A")[:7] if dep.get("commit_hash") else "N/A",
        health_emoji=health_emoji,
        health=health.title(),
        restarts=dep.get("restart_count", 0),
        last_check=dep.get("last_health_check", "N/A")[:16] if dep.get("last_health_check") else "N/A",
        created=dep.get("created_at", "N/A")[:10],
        started=dep.get("started_at", "N/A")[:16] if dep.get("started_at") else "N/A",
        activity=dep.get("last_activity_at", "N/A")[:16] if dep.get("last_activity_at") else "N/A"
    )
    
    is_running = status == "running"
    keyboard = get_deployment_actions(deployment_id, is_running)
    
    await callback.message.edit_text(text, reply_markup=keyboard)
    await callback.answer()


@router.callback_query(F.data.startswith("deploy:stop:"))
async def callback_stop_deployment(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Stop a deployment."""
    deployment_id = callback.data.split(":")[-1]
    
    try:
        response = await api_client.post(f"/api/deployments/{deployment_id}/stop")
        
        if response.status_code == 200:
            await callback.answer("⏹️ Stopping deployment...", show_alert=True)
        else:
            await callback.answer("Failed to stop deployment", show_alert=True)
    except Exception as e:
        await callback.answer(f"Error: {e}", show_alert=True)


@router.callback_query(F.data.startswith("deploy:start_container:"))
async def callback_start_deployment(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Start a deployment."""
    deployment_id = callback.data.split(":")[-1]
    
    try:
        response = await api_client.post(f"/api/deployments/{deployment_id}/start")
        
        if response.status_code == 200:
            await callback.answer("▶️ Starting deployment...", show_alert=True)
        else:
            await callback.answer("Failed to start deployment", show_alert=True)
    except Exception as e:
        await callback.answer(f"Error: {e}", show_alert=True)


@router.callback_query(F.data.startswith("deploy:restart:"))
async def callback_restart_deployment(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Restart a deployment."""
    deployment_id = callback.data.split(":")[-1]
    
    try:
        response = await api_client.post(f"/api/deployments/{deployment_id}/restart")
        
        if response.status_code == 200:
            await callback.answer("🔄 Restarting deployment...", show_alert=True)
        else:
            await callback.answer("Failed to restart deployment", show_alert=True)
    except Exception as e:
        await callback.answer(f"Error: {e}", show_alert=True)


@router.callback_query(F.data.startswith("deploy:delete_confirm:"))
async def callback_delete_confirm(callback: CallbackQuery):
    """Show delete confirmation."""
    deployment_id = callback.data.split(":")[-1]
    
    from bot.keyboards.main_menu import get_confirmation_keyboard
    
    await callback.message.edit_text(
        Messages.CONFIRM_DELETE.format(name="this deployment"),
        reply_markup=get_confirmation_keyboard(
            f"deploy:delete:{deployment_id}",
            f"status:detail:{deployment_id}"
        )
    )
    await callback.answer()


@router.callback_query(F.data.startswith("deploy:delete:"))
async def callback_delete_deployment(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Delete a deployment."""
    deployment_id = callback.data.split(":")[-1]
    
    try:
        response = await api_client.delete(f"/api/deployments/{deployment_id}")
        
        if response.status_code == 200:
            await callback.answer("🗑️ Deployment deleted", show_alert=True)
            
            # Return to list
            await show_deployments_list(callback, api_client)
        else:
            await callback.answer("Failed to delete deployment", show_alert=True)
    except Exception as e:
        await callback.answer(f"Error: {e}", show_alert=True)
