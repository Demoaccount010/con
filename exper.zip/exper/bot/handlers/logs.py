"""
Logs Handler

Handles deployment log viewing.
"""

from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
import httpx

from bot.utils.messages import Messages
from bot.keyboards.main_menu import get_back_button, get_deployments_list


router = Router()


@router.message(Command("logs"))
async def cmd_logs(
    message: Message,
    api_client: httpx.AsyncClient
):
    """Handle /logs command - show deployment selector."""
    await show_logs_selector(message, api_client)


@router.callback_query(F.data == "logs:select")
async def callback_logs_select(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Show deployment selector for logs."""
    await show_logs_selector(callback, api_client)
    await callback.answer()


async def show_logs_selector(
    event: Message | CallbackQuery,
    api_client: httpx.AsyncClient
):
    """Show list of deployments to select for logs."""
    user = event.from_user if isinstance(event, Message) else event.from_user
    
    try:
        response = await api_client.get(f"/api/deployments/user/{user.id}")
        deployments = response.json() if response.status_code == 200 else []
    except Exception:
        deployments = []
    
    if not deployments:
        text = "📭 No deployments found.\n\nDeploy a bot first to view logs."
        keyboard = get_back_button()
    else:
        text = "📄 <b>Select Deployment</b>\n\nChoose a deployment to view logs:"
        
        from aiogram.utils.keyboard import InlineKeyboardBuilder
        from aiogram.types import InlineKeyboardButton
        
        builder = InlineKeyboardBuilder()
        for dep in deployments[:10]:
            status = dep.get("status", "unknown")
            emoji = {"running": "🟢", "stopped": "🔴"}.get(status, "⚫")
            builder.row(
                InlineKeyboardButton(
                    text=f"{emoji} {dep['name']}",
                    callback_data=f"logs:view:{dep['id']}"
                )
            )
        builder.row(InlineKeyboardButton(text="◀️ Back", callback_data="menu:main"))
        keyboard = builder.as_markup()
    
    if isinstance(event, Message):
        await event.answer(text, reply_markup=keyboard)
    else:
        await event.message.edit_text(text, reply_markup=keyboard)


@router.callback_query(F.data.startswith("logs:view:"))
async def callback_view_logs(
    callback: CallbackQuery,
    api_client: httpx.AsyncClient
):
    """View deployment logs."""
    deployment_id = callback.data.split(":")[-1]
    
    try:
        # Get deployment info
        dep_response = await api_client.get(f"/api/deployments/{deployment_id}")
        deployment = dep_response.json() if dep_response.status_code == 200 else None
        
        # Get logs
        logs_response = await api_client.get(
            f"/api/deployments/{deployment_id}/logs",
            params={"limit": 30}
        )
        logs_data = logs_response.json() if logs_response.status_code == 200 else {"logs": []}
        
    except Exception as e:
        await callback.answer(f"Error: {e}", show_alert=True)
        return
    
    deployment_name = deployment.get("name", "Unknown") if deployment else "Unknown"
    logs = logs_data.get("logs", [])
    
    if not logs:
        log_text = "<i>No logs available</i>"
    else:
        log_entries = []
        for log in logs[-20:]:  # Limit display
            time = log.get("created_at", "")[:19].replace("T", " ")
            level = log.get("level", "INFO")[:4].upper()
            message = log.get("message", "")[:100]
            
            # Color code by level
            level_emoji = {
                "INFO": "ℹ️",
                "WARN": "⚠️",
                "ERRO": "❌",
                "DEBU": "🔍"
            }.get(level, "•")
            
            log_entries.append(
                f"{level_emoji} <code>[{time}]</code> {message}"
            )
        
        log_text = "\n".join(log_entries)
    
    text = Messages.LOGS_VIEW.format(
        name=deployment_name,
        logs=log_text,
        count=len(logs)
    )
    
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🔄 Refresh", callback_data=f"logs:view:{deployment_id}"),
            InlineKeyboardButton(text="📊 Status", callback_data=f"status:detail:{deployment_id}")
        ],
        [
            InlineKeyboardButton(text="◀️ Back", callback_data="logs:select")
        ]
    ])
    
    await callback.message.edit_text(text, reply_markup=keyboard)
    await callback.answer()
