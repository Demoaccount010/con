# 🚀 Telegram Bot Hosting Platform

A production-ready, SaaS-like platform for deploying and managing Telegram bots via Docker containers across multiple VPS nodes.

## ✨ Features

- **Telegram-Based Control** - Deploy and manage bots entirely through Telegram
- **Multi-VPS Orchestration** - Distribute containers across multiple servers
- **Smart Env Detection** - Automatically detects environment variables from repos
- **Secure Docker Isolation** - Hardened containers with resource limits
- **Razorpay Payments** - Subscription plans with automatic upgrades
- **GitHub Auto-Deploy** - Webhook-triggered rebuilds on push
- **Admin Dashboard** - Complete Telegram-based admin panel

## 🏗️ Architecture

```
┌─────────────────┐     ┌──────────────────┐     ┌─────────────────┐
│  Telegram Bot   │────▶│    FastAPI       │────▶│   PostgreSQL    │
│  (Aiogram 3.x)  │     │    Backend       │     │   + Redis       │
└─────────────────┘     └──────────────────┘     └─────────────────┘
                               │
                    ┌──────────┴──────────┐
                    ▼                     ▼
            ┌──────────────┐      ┌──────────────┐
            │  VPS Agent 1 │      │  VPS Agent 2 │
            │  (Docker)    │      │  (Docker)    │
            └──────────────┘      └──────────────┘
```

## 🚀 Quick Start

### 1. Clone and Configure

```bash
# Copy environment template
cp .env.example .env

# Edit with your values:
# - BOT_TOKEN: Get from @BotFather
# - DATABASE_URL: PostgreSQL connection string
# - REDIS_URL: Redis connection string
# - ADMIN_IDS: Comma-separated Telegram user IDs
# - RAZORPAY_KEY_ID/SECRET: Payment credentials
```

### 2. Start Services

```bash
# Build and start all services
docker-compose up -d

# Run database migrations
docker-compose exec api alembic upgrade head
```

### 3. Start Using

Open Telegram and message your bot with `/start`!

## 📁 Project Structure

```
├── app/                    # FastAPI Backend
│   ├── api/               # API endpoints
│   ├── core/              # Utilities (DB, Redis, Security)
│   ├── models/            # SQLAlchemy models
│   ├── schemas/           # Pydantic schemas
│   ├── services/          # Business logic
│   └── main.py
├── bot/                    # Telegram Bot
│   ├── handlers/          # Command handlers
│   ├── keyboards/         # Inline keyboards
│   ├── states/            # FSM states
│   └── main.py
├── agent/                  # VPS Agent
│   ├── docker_manager.py  # Container operations
│   ├── task_processor.py  # Deployment tasks
│   └── main.py
├── migrations/             # Alembic migrations
├── docker-compose.yml
└── requirements.txt
```

## 🤖 Bot Commands

### User Commands
| Command | Description |
|---------|-------------|
| `/start` | Main menu with account info |
| `/deploy` | Deploy a new bot from GitHub |
| `/status` | View your deployments |
| `/logs` | View deployment logs |
| `/plans` | View and upgrade plans |

### Admin Commands
| Command | Description |
|---------|-------------|
| `/admin` | Admin panel |
| VPS Management | Add/remove/monitor VPS nodes |
| Plan Management | Edit pricing and resources |
| User Management | Ban/unban, view stats |
| Broadcast | Send messages to all users |

## 💎 Default Plans

| Plan | Price | Deployments | RAM | CPU |
|------|-------|-------------|-----|-----|
| Free | ₹0 | 1 | 512MB | 0.5 |
| Starter | ₹99/mo | 3 | 1GB | 1 |
| Pro | ₹299/mo | 10 | 2GB | 2 |
| Enterprise | ₹999/mo | 50 | 4GB | 4 |

## 🔒 Security Features

- JWT authentication
- Encrypted environment variables (AES-256)
- Docker container hardening:
  - `cap-drop ALL`
  - `no-new-privileges`
  - `pids-limit`
  - Memory/CPU limits
- Webhook signature verification (Razorpay, GitHub)

## 🛠️ VPS Agent Setup

Install the agent on each VPS node:

```bash
# On VPS server
pip install docker psutil httpx

# Configure and run
export AGENT_NAME="vps-1"
export AGENT_SECRET="your-secret"
export MASTER_API_URL="https://your-master-server.com"

python -m agent.main
```

## 📝 License

MIT
