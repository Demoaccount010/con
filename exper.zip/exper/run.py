#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                           SMILE AI Agent - Launcher                          ║
║                    Easy startup script with configuration                    ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import sys
import asyncio
import argparse
from pathlib import Path

# Ensure we're in the right directory
BASE_DIR = Path(__file__).parent.absolute()
os.chdir(BASE_DIR)
sys.path.insert(0, str(BASE_DIR))

def print_banner():
    """Print startup banner"""
    banner = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║   ███████╗███╗   ███╗██╗██╗     ███████╗                                    ║
║   ██╔════╝████╗ ████║██║██║     ██╔════╝                                    ║
║   ███████╗██╔████╔██║██║██║     █████╗                                      ║
║   ╚════██║██║╚██╔╝██║██║██║     ██╔══╝                                      ║
║   ███████║██║ ╚═╝ ██║██║███████╗███████╗                                    ║
║   ╚══════╝╚═╝     ╚═╝╚═╝╚══════╝╚══════╝                                    ║
║                                                                              ║
║   Self-evolving Modular Intelligence Layer Engine                           ║
║   Version 1.0.0                                                             ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
    """
    print(banner)

def check_requirements():
    """Check if required packages are installed"""
    required = ['aiohttp', 'aiosqlite']
    missing = []
    
    for package in required:
        try:
            __import__(package)
        except ImportError:
            missing.append(package)
    
    if missing:
        print(f"⚠️  Missing required packages: {', '.join(missing)}")
        print("   Install with: pip install -r requirements.txt")
        return False
    
    return True

def setup_directories():
    """Ensure all required directories exist"""
    directories = [
        'core', 'plugins', 'memory', 'config', 
        'tools', 'sandbox', 'logs', 'backups',
        'backups/plugins', 'backups/memory'
    ]
    
    for dir_name in directories:
        dir_path = BASE_DIR / dir_name
        dir_path.mkdir(parents=True, exist_ok=True)
    
    # Create .gitkeep files
    for dir_name in ['sandbox', 'logs']:
        gitkeep = BASE_DIR / dir_name / '.gitkeep'
        if not gitkeep.exists():
            gitkeep.touch()

def load_env():
    """Load environment variables from .env file"""
    env_file = BASE_DIR / '.env'
    
    if env_file.exists():
        try:
            from dotenv import load_dotenv
            load_dotenv(env_file)
            print("✓ Loaded environment from .env")
        except ImportError:
            # Manual parsing if python-dotenv not installed
            with open(env_file) as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#') and '=' in line:
                        key, value = line.split('=', 1)
                        os.environ[key.strip()] = value.strip().strip('"\'')

async def run_agent(args):
    """Run the SMILE agent"""
    from main import SmileAgent, main
    
    if args.interactive:
        # Run interactive mode
        await main()
    else:
        # Single command mode
        agent = SmileAgent()
        success = await agent.initialize()
        
        if success and args.command:
            response = await agent.process_input(args.command)
            print(f"\n{response.get('response', 'No response')}\n")
        
        await agent.shutdown()

async def run_tests():
    """Run test suite"""
    import pytest
    
    test_dir = BASE_DIR / 'tests'
    if test_dir.exists():
        sys.exit(pytest.main([str(test_dir), '-v']))
    else:
        print("⚠️  No tests directory found")

async def show_status():
    """Show agent status"""
    from main import SmileAgent
    
    agent = SmileAgent()
    
    # Quick initialization check
    memory_file = BASE_DIR / 'memory' / 'owner_profile.json'
    config_file = BASE_DIR / 'config' / 'api_config.json'
    
    print("\n📊 SMILE Agent Status")
    print("─" * 50)
    print(f"  Base Directory: {BASE_DIR}")
    print(f"  Owner Profile: {'✓ Found' if memory_file.exists() else '✗ Not configured'}")
    print(f"  API Config: {'✓ Found' if config_file.exists() else '✗ Not configured'}")
    
    # Count plugins
    plugins_dir = BASE_DIR / 'plugins'
    plugin_count = sum(1 for p in plugins_dir.iterdir() 
                      if p.is_dir() and not p.name.startswith('_'))
    print(f"  Plugins: {plugin_count} found")
    
    # Check logs
    logs_dir = BASE_DIR / 'logs'
    log_count = sum(1 for f in logs_dir.glob('*.log'))
    print(f"  Log Files: {log_count}")
    
    print("─" * 50)

def main_cli():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description='SMILE AI Agent - Self-evolving Modular Intelligence Layer Engine',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python run.py                    Start interactive mode
  python run.py -c "Hello"         Run single command
  python run.py --status           Show agent status
  python run.py --test             Run test suite
  python run.py --reset            Reset agent (clear memory)
        """
    )
    
    parser.add_argument(
        '-c', '--command',
        type=str,
        help='Run a single command and exit'
    )
    
    parser.add_argument(
        '-i', '--interactive',
        action='store_true',
        default=True,
        help='Run in interactive mode (default)'
    )
    
    parser.add_argument(
        '--status',
        action='store_true',
        help='Show agent status'
    )
    
    parser.add_argument(
        '--test',
        action='store_true',
        help='Run test suite'
    )
    
    parser.add_argument(
        '--reset',
        action='store_true',
        help='Reset agent (clear all memory)'
    )
    
    parser.add_argument(
        '--no-banner',
        action='store_true',
        help='Skip startup banner'
    )
    
    parser.add_argument(
        '--debug',
        action='store_true',
        help='Enable debug logging'
    )
    
    args = parser.parse_args()
    
    # Print banner
    if not args.no_banner:
        print_banner()
    
    # Setup
    setup_directories()
    load_env()
    
    # Check requirements
    if not check_requirements():
        sys.exit(1)
    
    # Debug mode
    if args.debug:
        import logging
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Handle commands
    if args.status:
        asyncio.run(show_status())
    elif args.test:
        asyncio.run(run_tests())
    elif args.reset:
        confirm = input("⚠️  This will delete all memory. Are you sure? (yes/no): ")
        if confirm.lower() == 'yes':
            import shutil
            memory_dir = BASE_DIR / 'memory'
            if memory_dir.exists():
                shutil.rmtree(memory_dir)
                memory_dir.mkdir()
            print("✓ Agent memory reset")
        else:
            print("Reset cancelled")
    else:
        # Set interactive mode if command provided
        if args.command:
            args.interactive = False
        
        asyncio.run(run_agent(args))

if __name__ == "__main__":
    main_cli()