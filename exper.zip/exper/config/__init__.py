#!/usr/bin/env python3
"""
SMILE AI Agent - Configuration Package
"""

import json
from pathlib import Path

CONFIG_DIR = Path(__file__).parent

def load_settings() -> dict:
    """Load general settings"""
    settings_file = CONFIG_DIR / "settings.json"
    if settings_file.exists():
        with open(settings_file) as f:
            return json.load(f)
    return {}

def load_prompts() -> dict:
    """Load system prompts"""
    prompts_file = CONFIG_DIR / "prompts.json"
    if prompts_file.exists():
        with open(prompts_file) as f:
            return json.load(f)
    return {}

__all__ = ['load_settings', 'load_prompts', 'CONFIG_DIR']