#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                           META BRAIN - Decision Layer                        ║
║                    The Central Intelligence of SMILE Agent                   ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  This module is responsible for:                                             ║
║  - Analyzing incoming requests                                               ║
║  - Deciding processing strategy                                              ║
║  - Routing to appropriate subsystems                                         ║
║  - Coordinating multi-step operations                                        ║
║  - Confidence assessment                                                     ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import asyncio
import logging
import json
import re
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path

logger = logging.getLogger("SMILE.MetaBrain")

# ═══════════════════════════════════════════════════════════════════════════════
# ENUMS AND DATA STRUCTURES
# ═══════════════════════════════════════════════════════════════════════════════

class IntentType(Enum):
    """Types of user intent"""
    QUESTION = "question"                    # Asking for information
    COMMAND = "command"                      # Direct instruction
    CODE_REQUEST = "code_request"            # Code generation/modification
    ANALYSIS = "analysis"                    # Analysis request
    CONVERSATION = "conversation"            # General chat
    SYSTEM = "system"                        # System-related request
    SEARCH = "search"                        # Web search needed
    TOOL_USE = "tool_use"                    # Specific tool request
    MULTI_STEP = "multi_step"                # Complex multi-step task
    CLARIFICATION = "clarification"          # Needs more info
    FEEDBACK = "feedback"                    # User providing feedback
    UPGRADE_REQUEST = "upgrade_request"      # Request for new capability
    UNKNOWN = "unknown"

class ProcessingStrategy(Enum):
    """How to process the request"""
    DIRECT_RESPONSE = "direct"               # Simple, immediate response
    TOOL_CHAIN = "tool_chain"                # Use one or more tools
    DEEP_REASONING = "deep_reasoning"        # Complex AI reasoning
    SEARCH_AND_RESPOND = "search_respond"    # Search then answer
    CODE_GENERATION = "code_generation"      # Generate code
    MULTI_STEP_PLAN = "multi_step"           # Plan and execute steps
    DELEGATE_PLUGIN = "delegate_plugin"      # Use specific plugin
    ASK_CLARIFICATION = "clarify"            # Need more information
    HYBRID = "hybrid"                        # Combination of strategies

@dataclass
class IntentAnalysis:
    """Result of intent analysis"""
    primary_intent: IntentType
    secondary_intents: List[IntentType]
    confidence: float
    entities: Dict[str, Any]
    requires_tools: List[str]
    requires_search: bool
    requires_code: bool
    requires_memory: bool
    complexity_score: float  # 0.0 to 1.0
    sentiment: str  # positive, negative, neutral
    urgency: str  # low, medium, high
    keywords: List[str]

@dataclass
class ExecutionPlan:
    """Multi-step execution plan"""
    steps: List[Dict[str, Any]]
    estimated_time: float
    required_capabilities: List[str]
    fallback_strategy: Optional[str]
    checkpoints: List[int]  # Step indices for checkpoints

@dataclass
class ThoughtProcess:
    """Internal reasoning trace"""
    timestamp: str
    input_summary: str
    intent_analysis: IntentAnalysis
    strategy_chosen: ProcessingStrategy
    execution_plan: Optional[ExecutionPlan]
    reasoning_steps: List[str]
    confidence_factors: Dict[str, float]
    final_confidence: float

# ═══════════════════════════════════════════════════════════════════════════════
# META BRAIN CORE CLASS
# ═══════════════════════════════════════════════════════════════════════════════

class MetaBrain:
    """
    The Meta Brain is the central decision-making layer of SMILE.
    
    It orchestrates:
    1. Intent Analysis - Understanding what the user wants
    2. Capability Assessment - Checking what resources are available
    3. Strategy Selection - Choosing how to handle the request
    4. Execution Coordination - Managing the response generation
    5. Quality Assurance - Verifying response quality
    """
    
    def __init__(self, agent):
        """
        Initialize Meta Brain with reference to main agent
        
        Args:
            agent: Reference to the main SmileAgent instance
        """
        self.agent = agent
        self.thought_history: List[ThoughtProcess] = []
        self.strategy_success_rates: Dict[str, Dict] = {}
        self.intent_patterns: Dict[str, List[str]] = {}
        self.learned_associations: Dict[str, Any] = {}
        
        # Intent detection patterns (will be enhanced with learning)
        self._init_intent_patterns()
        
        # Capability map
        self.capabilities = {}
        
        logger.info("MetaBrain instance created")
    
    def _init_intent_patterns(self):
        """Initialize patterns for intent detection"""
        self.intent_patterns = {
            IntentType.QUESTION: [
                r'\b(what|who|where|when|why|how|which|whose)\b',
                r'\?$',
                r'\b(explain|describe|tell me|can you)\b',
                r'\b(is it|are there|does it|do you)\b'
            ],
            IntentType.COMMAND: [
                r'^(do|make|create|build|run|execute|start|stop|delete|remove)\b',
                r'\b(please|now|immediately)\b.*\b(do|make|create)\b',
                r'^(set|configure|install|update)\b'
            ],
            IntentType.CODE_REQUEST: [
                r'\b(code|function|class|script|program|algorithm)\b',
                r'\b(write|generate|create|implement|build)\b.*\b(code|function|program)\b',
                r'\b(python|javascript|java|c\+\+|rust|go|typescript)\b',
                r'\b(api|endpoint|database|query|sql)\b',
                r'```'
            ],
            IntentType.ANALYSIS: [
                r'\b(analyze|review|check|evaluate|assess|examine)\b',
                r'\b(what do you think|your opinion|feedback)\b',
                r'\b(improve|optimize|refactor|fix)\b'
            ],
            IntentType.SEARCH: [
                r'\b(search|find|look up|google|research)\b',
                r'\b(latest|recent|current|new|2024|2025)\b',
                r'\b(news|article|paper|documentation)\b'
            ],
            IntentType.SYSTEM: [
                r'\b(status|health|version|upgrade|plugin|memory)\b',
                r'\b(yourself|your|you are|who are you)\b',
                r'\b(capability|capabilities|can you|able to)\b'
            ],
            IntentType.UPGRADE_REQUEST: [
                r'\b(add|new)\b.*\b(feature|capability|function|tool)\b',
                r'\b(upgrade|enhance|extend|improve)\b.*\b(yourself|you)\b',
                r'\b(learn|remember|save)\b.*\b(this|that|how to)\b'
            ],
            IntentType.FEEDBACK: [
                r'\b(good|great|excellent|thanks|thank you|well done)\b',
                r'\b(bad|wrong|incorrect|mistake|error|no)\b',
                r'\b(better|worse|prefer|instead)\b'
            ]
        }
    
    async def initialize(self):
        """Initialize the Meta Brain subsystems"""
        logger.info("Initializing Meta Brain...")
        
        # Load learned patterns from memory
        if self.agent.memory_system:
            learned = await self.agent.memory_system.retrieve_learning("intent_patterns")
            if learned:
                self._merge_learned_patterns(learned)
            
            # Load strategy success rates
            success_rates = await self.agent.memory_system.retrieve_learning("strategy_success_rates")
            if success_rates:
                self.strategy_success_rates = success_rates
        
        # Build capability map
        await self._build_capability_map()
        
        logger.info("Meta Brain initialized successfully")
    
    async def _build_capability_map(self):
        """Build a map of all available capabilities"""
        self.capabilities = {
            "core": {
                "reasoning": True,
                "conversation": True,
                "memory": True,
                "learning": True
            },
            "tools": {},
            "plugins": {},
            "apis": {}
        }
        
        # Add tools from tool manager
        if hasattr(self.agent, 'loaded_tools') and self.agent.loaded_tools:
            for tool_name, tool_func in self.agent.loaded_tools.items():
                self.capabilities["tools"][tool_name] = {
                    "available": True,
                    "description": getattr(tool_func, '__doc__', 'No description')
                }
        
        # Add plugins
        if hasattr(self.agent, 'active_plugins') and self.agent.active_plugins:
            for plugin_name, plugin in self.agent.active_plugins.items():
                self.capabilities["plugins"][plugin_name] = {
                    "available": True,
                    "tools": getattr(plugin, 'provided_tools', [])
                }
        
        # Add API capabilities
        if hasattr(self.agent, 'api_manager') and self.agent.api_manager:
            api_status = await self.agent.api_manager.get_status()
            self.capabilities["apis"] = api_status
    
    def _merge_learned_patterns(self, learned_patterns: Dict):
        """Merge learned patterns with base patterns"""
        for intent_type, patterns in learned_patterns.items():
            if intent_type in self.intent_patterns:
                self.intent_patterns[intent_type].extend(patterns)
            else:
                try:
                    enum_intent = IntentType(intent_type)
                    self.intent_patterns[enum_intent] = patterns
                except ValueError:
                    pass
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MAIN PROCESSING PIPELINE
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def process(self, user_input: str) -> Dict[str, Any]:
        """
        Main processing pipeline for user input
        
        This is the core function that:
        1. Analyzes intent
        2. Checks capabilities
        3. Selects strategy
        4. Executes plan
        5. Validates response
        
        Args:
            user_input: Raw user input string
            
        Returns:
            Dict containing response and metadata
        """
        start_time = datetime.now()
        logger.info(f"Processing input: {user_input[:100]}...")
        
        # Step 1: Analyze Intent
        intent_analysis = await self._analyze_intent(user_input)
        logger.info(f"Intent: {intent_analysis.primary_intent.value} (confidence: {intent_analysis.confidence:.2f})")
        
        # Step 2: Check Capabilities
        capability_check = await self._check_capabilities(intent_analysis)
        
        # Step 3: Select Strategy
        strategy = await self._select_strategy(intent_analysis, capability_check)
        logger.info(f"Selected strategy: {strategy.value}")
        
        # Step 4: Create Execution Plan
        execution_plan = await self._create_execution_plan(
            user_input, intent_analysis, strategy, capability_check
        )
        
        # Step 5: Execute Plan
        result = await self._execute_plan(user_input, execution_plan, strategy)
        
        # Step 6: Validate and Enhance Response
        final_response = await self._validate_response(result, intent_analysis)
        
        # Record thought process
        thought = ThoughtProcess(
            timestamp=start_time.isoformat(),
            input_summary=user_input[:200],
            intent_analysis=intent_analysis,
            strategy_chosen=strategy,
            execution_plan=execution_plan,
            reasoning_steps=result.get("reasoning_steps", []),
            confidence_factors=result.get("confidence_factors", {}),
            final_confidence=final_response.get("confidence", 0.5)
        )
        self.thought_history.append(thought)
        
        # Update strategy success tracking
        await self._record_strategy_usage(strategy, final_response.get("confidence", 0.5))
        
        processing_time = (datetime.now() - start_time).total_seconds()
        logger.info(f"Processing completed in {processing_time:.2f}s")
        
        final_response["processing_time"] = processing_time
        final_response["intent"] = intent_analysis.primary_intent.value
        final_response["strategy"] = strategy.value
        
        return final_response
    
    # ═══════════════════════════════════════════════════════════════════════════
    # INTENT ANALYSIS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _analyze_intent(self, user_input: str) -> IntentAnalysis:
        """
        Analyze user input to determine intent
        
        Uses multiple signals:
        - Pattern matching
        - Keyword extraction
        - Context from conversation history
        - Learned associations
        """
        input_lower = user_input.lower()
        intent_scores: Dict[IntentType, float] = {}
        
        # Pattern-based scoring
        for intent_type, patterns in self.intent_patterns.items():
            score = 0.0
            for pattern in patterns:
                if re.search(pattern, input_lower, re.IGNORECASE):
                    score += 0.2
            intent_scores[intent_type] = min(score, 1.0)
        
        # Boost scores based on specific keywords
        keyword_boosts = {
            "code": IntentType.CODE_REQUEST,
            "search": IntentType.SEARCH,
            "analyze": IntentType.ANALYSIS,
            "status": IntentType.SYSTEM,
            "upgrade": IntentType.UPGRADE_REQUEST,
        }
        
        for keyword, intent_type in keyword_boosts.items():
            if keyword in input_lower:
                intent_scores[intent_type] = intent_scores.get(intent_type, 0) + 0.3
        
        # Get conversation context
        context_boost = await self._get_context_boost(user_input)
        for intent_type, boost in context_boost.items():
            intent_scores[intent_type] = intent_scores.get(intent_type, 0) + boost
        
        # Determine primary intent
        if intent_scores:
            sorted_intents = sorted(intent_scores.items(), key=lambda x: x[1], reverse=True)
            primary_intent = sorted_intents[0][0]
            primary_confidence = sorted_intents[0][1]
            secondary_intents = [i[0] for i in sorted_intents[1:4] if i[1] > 0.2]
        else:
            primary_intent = IntentType.CONVERSATION
            primary_confidence = 0.5
            secondary_intents = []
        
        # Normalize confidence
        confidence = min(max(primary_confidence, 0.1), 1.0)
        
        # Extract entities and keywords
        entities = await self._extract_entities(user_input)
        keywords = await self._extract_keywords(user_input)
        
        # Determine requirements
        requires_tools = await self._determine_required_tools(user_input, primary_intent)
        requires_search = primary_intent == IntentType.SEARCH or "latest" in input_lower or "current" in input_lower
        requires_code = primary_intent == IntentType.CODE_REQUEST or any(
            word in input_lower for word in ["code", "function", "class", "implement", "script"]
        )
        requires_memory = any(
            word in input_lower for word in ["remember", "last time", "before", "previously", "you said"]
        )
        
        # Calculate complexity
        complexity = self._calculate_complexity(user_input, primary_intent, requires_tools)
        
        # Detect sentiment
        sentiment = self._detect_sentiment(user_input)
        
        # Detect urgency
        urgency = self._detect_urgency(user_input)
        
        return IntentAnalysis(
            primary_intent=primary_intent,
            secondary_intents=secondary_intents,
            confidence=confidence,
            entities=entities,
            requires_tools=requires_tools,
            requires_search=requires_search,
            requires_code=requires_code,
            requires_memory=requires_memory,
            complexity_score=complexity,
            sentiment=sentiment,
            urgency=urgency,
            keywords=keywords
        )
    
    async def _get_context_boost(self, user_input: str) -> Dict[IntentType, float]:
        """Get intent boosts from conversation context"""
        boosts = {}
        
        # Check recent conversation for context
        if self.agent.memory_system:
            recent = await self.agent.memory_system.get_short_term_context(5)
            if recent:
                # If discussing code, boost code intent
                for msg in recent:
                    content = msg.get("content", "").lower()
                    if "code" in content or "```" in content:
                        boosts[IntentType.CODE_REQUEST] = 0.2
                    if "search" in content or "find" in content:
                        boosts[IntentType.SEARCH] = 0.2
        
        return boosts
    
    async def _extract_entities(self, user_input: str) -> Dict[str, Any]:
        """Extract named entities from input"""
        entities = {
            "programming_languages": [],
            "tools": [],
            "files": [],
            "urls": [],
            "numbers": [],
            "dates": []
        }
        
        # Programming languages
        languages = ["python", "javascript", "typescript", "java", "c++", "rust", "go", "ruby", "php"]
        for lang in languages:
            if lang in user_input.lower():
                entities["programming_languages"].append(lang)
        
        # URLs
        url_pattern = r'https?://[^\s]+'
        entities["urls"] = re.findall(url_pattern, user_input)
        
        # File paths
        file_pattern = r'[\w/\\]+\.\w+'
        entities["files"] = re.findall(file_pattern, user_input)
        
        # Numbers
        entities["numbers"] = re.findall(r'\b\d+\.?\d*\b', user_input)
        
        return entities
    
    async def _extract_keywords(self, user_input: str) -> List[str]:
        """Extract important keywords from input"""
        # Remove common stop words and extract meaningful words
        stop_words = {'a', 'an', 'the', 'is', 'are', 'was', 'were', 'be', 'been', 
                      'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will',
                      'would', 'could', 'should', 'may', 'might', 'must', 'shall',
                      'can', 'need', 'to', 'of', 'in', 'for', 'on', 'with', 'at',
                      'by', 'from', 'as', 'into', 'through', 'during', 'before',
                      'after', 'above', 'below', 'between', 'under', 'again',
                      'further', 'then', 'once', 'here', 'there', 'when', 'where',
                      'why', 'how', 'all', 'each', 'few', 'more', 'most', 'other',
                      'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same',
                      'so', 'than', 'too', 'very', 'just', 'and', 'but', 'if',
                      'or', 'because', 'until', 'while', 'although', 'though',
                      'i', 'you', 'he', 'she', 'it', 'we', 'they', 'me', 'him',
                      'her', 'us', 'them', 'my', 'your', 'his', 'its', 'our', 'their',
                      'this', 'that', 'these', 'those', 'what', 'which', 'who', 'whom',
                      'please', 'want', 'like', 'get', 'make'}
        
        words = re.findall(r'\b\w+\b', user_input.lower())
        keywords = [w for w in words if w not in stop_words and len(w) > 2]
        
        return list(set(keywords))[:20]  # Return top 20 unique keywords
    
    async def _determine_required_tools(self, user_input: str, intent: IntentType) -> List[str]:
        """Determine which tools might be needed"""
        required_tools = []
        input_lower = user_input.lower()
        
        # Map keywords to tools
        tool_keywords = {
            "web_search": ["search", "find", "look up", "google", "latest", "current"],
            "code_executor": ["run", "execute", "test", "evaluate"],
            "file_reader": ["read", "open", "load", "file", "content"],
            "file_writer": ["write", "save", "create file", "export"],
            "calculator": ["calculate", "compute", "math", "sum", "average"],
            "api_caller": ["api", "fetch", "request", "endpoint"],
        }
        
        for tool, keywords in tool_keywords.items():
            if any(kw in input_lower for kw in keywords):
                if tool in self.capabilities.get("tools", {}):
                    required_tools.append(tool)
        
        return required_tools
    
    def _calculate_complexity(self, user_input: str, intent: IntentType, 
                            required_tools: List[str]) -> float:
        """Calculate task complexity score (0.0 to 1.0)"""
        complexity = 0.0
        
        # Base complexity from intent
        intent_complexity = {
            IntentType.CONVERSATION: 0.1,
            IntentType.QUESTION: 0.2,
            IntentType.COMMAND: 0.3,
            IntentType.SEARCH: 0.3,
            IntentType.ANALYSIS: 0.5,
            IntentType.CODE_REQUEST: 0.6,
            IntentType.MULTI_STEP: 0.8,
            IntentType.UPGRADE_REQUEST: 0.9,
        }
        complexity += intent_complexity.get(intent, 0.3)
        
        # Add complexity for tools needed
        complexity += len(required_tools) * 0.1
        
        # Add complexity for length
        if len(user_input) > 500:
            complexity += 0.2
        elif len(user_input) > 200:
            complexity += 0.1
        
        # Add complexity for multiple sentences
        sentences = len(re.split(r'[.!?]+', user_input))
        if sentences > 3:
            complexity += 0.1
        
        return min(complexity, 1.0)
    
    def _detect_sentiment(self, user_input: str) -> str:
        """Detect user sentiment"""
        input_lower = user_input.lower()
        
        positive_words = ["good", "great", "excellent", "thanks", "thank", "perfect", 
                         "awesome", "nice", "love", "wonderful", "amazing", "helpful"]
        negative_words = ["bad", "wrong", "error", "mistake", "fail", "broken", 
                         "hate", "terrible", "awful", "useless", "stupid", "annoying"]
        
        positive_count = sum(1 for word in positive_words if word in input_lower)
        negative_count = sum(1 for word in negative_words if word in input_lower)
        
        if positive_count > negative_count:
            return "positive"
        elif negative_count > positive_count:
            return "negative"
        return "neutral"
    
    def _detect_urgency(self, user_input: str) -> str:
        """Detect request urgency"""
        input_lower = user_input.lower()
        
        high_urgency = ["urgent", "immediately", "asap", "right now", "critical", 
                       "emergency", "quickly", "hurry"]
        medium_urgency = ["soon", "when possible", "need", "important"]
        
        if any(word in input_lower for word in high_urgency):
            return "high"
        elif any(word in input_lower for word in medium_urgency):
            return "medium"
        return "low"
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CAPABILITY CHECKING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _check_capabilities(self, intent: IntentAnalysis) -> Dict[str, Any]:
        """Check if agent has required capabilities"""
        result = {
            "can_fulfill": True,
            "available_tools": [],
            "missing_tools": [],
            "available_apis": [],
            "constraints": [],
            "recommendations": []
        }
        
        # Check required tools
        for tool in intent.requires_tools:
            if tool in self.capabilities.get("tools", {}):
                result["available_tools"].append(tool)
            else:
                result["missing_tools"].append(tool)
                result["can_fulfill"] = False
        
        # Check API availability
        api_status = self.capabilities.get("apis", {})
        for api_name, status in api_status.items():
            if status.get("active"):
                result["available_apis"].append(api_name)
        
        if not result["available_apis"]:
            result["can_fulfill"] = False
            result["constraints"].append("No active AI APIs available")
        
        # Check permissions
        if intent.requires_search:
            if not self.agent.identity.owner.permission_levels.get("web_access", False):
                result["constraints"].append("Web access not permitted")
        
        if intent.primary_intent == IntentType.CODE_REQUEST:
            if not self.agent.identity.owner.permission_levels.get("execute_code", False):
                result["constraints"].append("Code execution requires permission")
        
        # Generate recommendations
        if result["missing_tools"]:
            result["recommendations"].append(
                f"Consider creating plugins for: {', '.join(result['missing_tools'])}"
            )
        
        return result
    
    # ═══════════════════════════════════════════════════════════════════════════
    # STRATEGY SELECTION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _select_strategy(self, intent: IntentAnalysis, 
                               capabilities: Dict) -> ProcessingStrategy:
        """Select the best processing strategy"""
        
        # If capabilities are insufficient, clarify
        if not capabilities["can_fulfill"] and capabilities["constraints"]:
            return ProcessingStrategy.ASK_CLARIFICATION
        
        # Strategy selection based on intent and complexity
        if intent.primary_intent == IntentType.QUESTION:
            if intent.requires_search:
                return ProcessingStrategy.SEARCH_AND_RESPOND
            elif intent.complexity_score > 0.5:
                return ProcessingStrategy.DEEP_REASONING
            else:
                return ProcessingStrategy.DIRECT_RESPONSE
        
        elif intent.primary_intent == IntentType.CODE_REQUEST:
            return ProcessingStrategy.CODE_GENERATION
        
        elif intent.primary_intent == IntentType.COMMAND:
            if intent.requires_tools:
                return ProcessingStrategy.TOOL_CHAIN
            else:
                return ProcessingStrategy.DIRECT_RESPONSE
        
        elif intent.primary_intent == IntentType.ANALYSIS:
            return ProcessingStrategy.DEEP_REASONING
        
        elif intent.primary_intent == IntentType.SEARCH:
            return ProcessingStrategy.SEARCH_AND_RESPOND
        
        elif intent.primary_intent == IntentType.MULTI_STEP:
            return ProcessingStrategy.MULTI_STEP_PLAN
        
        elif intent.primary_intent == IntentType.UPGRADE_REQUEST:
            return ProcessingStrategy.DELEGATE_PLUGIN
        
        elif intent.primary_intent == IntentType.SYSTEM:
            return ProcessingStrategy.DIRECT_RESPONSE
        
        elif intent.primary_intent == IntentType.CONVERSATION:
            return ProcessingStrategy.DIRECT_RESPONSE
        
        # Default to hybrid for complex cases
        if intent.complexity_score > 0.7:
            return ProcessingStrategy.HYBRID
        
        return ProcessingStrategy.DIRECT_RESPONSE
    
    # ═══════════════════════════════════════════════════════════════════════════
    # EXECUTION PLANNING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _create_execution_plan(self, user_input: str, intent: IntentAnalysis,
                                    strategy: ProcessingStrategy,
                                    capabilities: Dict) -> Optional[ExecutionPlan]:
        """Create a detailed execution plan"""
        
        if strategy == ProcessingStrategy.DIRECT_RESPONSE:
            return ExecutionPlan(
                steps=[{"action": "generate_response", "input": user_input}],
                estimated_time=1.0,
                required_capabilities=["reasoning"],
                fallback_strategy="ask_clarification",
                checkpoints=[]
            )
        
        elif strategy == ProcessingStrategy.CODE_GENERATION:
            return ExecutionPlan(
                steps=[
                    {"action": "analyze_requirements", "input": user_input},
                    {"action": "design_solution", "input": None},
                    {"action": "generate_code", "input": None},
                    {"action": "validate_code", "input": None},
                    {"action": "format_response", "input": None}
                ],
                estimated_time=5.0,
                required_capabilities=["reasoning", "code_generation"],
                fallback_strategy="simplified_code",
                checkpoints=[1, 3]
            )
        
        elif strategy == ProcessingStrategy.SEARCH_AND_RESPOND:
            return ExecutionPlan(
                steps=[
                    {"action": "formulate_query", "input": user_input},
                    {"action": "execute_search", "input": None},
                    {"action": "analyze_results", "input": None},
                    {"action": "synthesize_response", "input": None}
                ],
                estimated_time=8.0,
                required_capabilities=["web_search", "reasoning"],
                fallback_strategy="respond_without_search",
                checkpoints=[2]
            )
        
        elif strategy == ProcessingStrategy.TOOL_CHAIN:
            tool_steps = [
                {"action": f"use_tool:{tool}", "input": None}
                for tool in intent.requires_tools
            ]
            return ExecutionPlan(
                steps=[
                    {"action": "plan_tool_usage", "input": user_input},
                    *tool_steps,
                    {"action": "combine_results", "input": None}
                ],
                estimated_time=3.0 * len(tool_steps),
                required_capabilities=intent.requires_tools,
                fallback_strategy="manual_execution",
                checkpoints=list(range(1, len(tool_steps) + 1))
            )
        
        elif strategy == ProcessingStrategy.DEEP_REASONING:
            return ExecutionPlan(
                steps=[
                    {"action": "decompose_problem", "input": user_input},
                    {"action": "gather_context", "input": None},
                    {"action": "reason_step_by_step", "input": None},
                    {"action": "validate_reasoning", "input": None},
                    {"action": "formulate_response", "input": None}
                ],
                estimated_time=10.0,
                required_capabilities=["reasoning", "memory"],
                fallback_strategy="simplified_reasoning",
                checkpoints=[2, 4]
            )
        
        elif strategy == ProcessingStrategy.MULTI_STEP_PLAN:
            return ExecutionPlan(
                steps=[
                    {"action": "analyze_full_task", "input": user_input},
                    {"action": "create_subtasks", "input": None},
                    {"action": "execute_subtasks", "input": None},
                    {"action": "validate_all_results", "input": None},
                    {"action": "combine_deliverables", "input": None}
                ],
                estimated_time=20.0,
                required_capabilities=["reasoning", "planning", "execution"],
                fallback_strategy="sequential_execution",
                checkpoints=[1, 3, 4]
            )
        
        return None
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PLAN EXECUTION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _execute_plan(self, user_input: str, plan: Optional[ExecutionPlan],
                           strategy: ProcessingStrategy) -> Dict[str, Any]:
        """Execute the processing plan"""
        reasoning_steps = []
        confidence_factors = {}
        
        # Build context for AI
        context = await self._build_context(user_input)
        
        # Execute based on strategy
        if strategy == ProcessingStrategy.DIRECT_RESPONSE:
            response = await self._generate_ai_response(user_input, context)
            confidence_factors["direct_response"] = 0.8
            
        elif strategy == ProcessingStrategy.CODE_GENERATION:
            response = await self._generate_code_response(user_input, context)
            reasoning_steps.append("Analyzed code requirements")
            reasoning_steps.append("Generated implementation")
            confidence_factors["code_quality"] = 0.7
            
        elif strategy == ProcessingStrategy.SEARCH_AND_RESPOND:
            # Attempt search
            search_results = await self._execute_search(user_input)
            if search_results:
                context["search_results"] = search_results
                reasoning_steps.append(f"Found {len(search_results)} relevant sources")
                confidence_factors["search_quality"] = 0.8
            response = await self._generate_ai_response(user_input, context)
            
        elif strategy == ProcessingStrategy.DEEP_REASONING:
            response = await self._deep_reasoning(user_input, context)
            reasoning_steps.extend([
                "Decomposed problem into components",
                "Analyzed each component",
                "Synthesized comprehensive response"
            ])
            confidence_factors["reasoning_depth"] = 0.9
            
        elif strategy == ProcessingStrategy.TOOL_CHAIN:
            tool_results = await self._execute_tool_chain(user_input, plan)
            context["tool_results"] = tool_results
            response = await self._generate_ai_response(user_input, context)
            confidence_factors["tool_reliability"] = 0.85
            
        elif strategy == ProcessingStrategy.ASK_CLARIFICATION:
            response = await self._generate_clarification_request(user_input)
            confidence_factors["need_info"] = 1.0
            
        else:
            response = await self._generate_ai_response(user_input, context)
        
        return {
            "response": response,
            "reasoning_steps": reasoning_steps,
            "confidence_factors": confidence_factors
        }
    
    async def _build_context(self, user_input: str) -> Dict[str, Any]:
        """Build context for AI response generation"""
        context = {
            "agent_name": self.agent.identity.name,
            "owner_name": self.agent.identity.owner.name if self.agent.identity.owner else "User",
            "relationship": self.agent.identity.owner.relationship if self.agent.identity.owner else "",
            "preferences": {},
            "conversation_history": [],
            "relevant_memories": [],
            "available_tools": list(self.capabilities.get("tools", {}).keys()),
            "current_capabilities": self.agent.identity.capabilities
        }
        
        # Add owner preferences
        if self.agent.identity.owner:
            context["preferences"] = {
                "communication_style": self.agent.identity.owner.preferences.get("communication_style", "adaptive"),
                "verbosity": self.agent.identity.owner.preferences.get("verbosity", "balanced"),
                "coding_style": self.agent.identity.owner.coding_style
            }
        
        # Add conversation history
        if self.agent.memory_system:
            context["conversation_history"] = await self.agent.memory_system.get_short_term_context(10)
            
            # Search for relevant long-term memories
            relevant = await self.agent.memory_system.search_relevant(user_input, limit=5)
            context["relevant_memories"] = relevant
        
        return context
    
    async def _generate_ai_response(self, user_input: str, context: Dict) -> str:
        """Generate response using AI API"""
        if not self.agent.api_manager:
            return "I apologize, but I don't have access to AI capabilities at the moment."
        
        # Build system prompt
        system_prompt = self._build_system_prompt(context)
        
        # Build messages
        messages = [{"role": "system", "content": system_prompt}]
        
        # Add conversation history
        for msg in context.get("conversation_history", [])[-5:]:
            messages.append({
                "role": msg.get("role", "user"),
                "content": msg.get("content", "")
            })
        
        # Add current message
        messages.append({"role": "user", "content": user_input})
        
        # Generate response
        response = await self.agent.api_manager.generate(messages)
        
        return response
    
    def _build_system_prompt(self, context: Dict) -> str:
        """Build the system prompt for AI generation"""
        owner_name = context.get("owner_name", "User")
        relationship = context.get("relationship", "assistant")
        preferences = context.get("preferences", {})
        
        comm_style = preferences.get("communication_style", "adaptive")
        verbosity = preferences.get("verbosity", "balanced")
        
        style_instruction = {
            "formal": "Use formal, professional language.",
            "casual": "Be friendly and conversational.",
            "technical": "Be precise and technical.",
            "adaptive": "Match the user's communication style."
        }.get(comm_style, "Be helpful and clear.")
        
        verbosity_instruction = {
            "concise": "Keep responses brief and to the point.",
            "balanced": "Provide appropriate detail without being excessive.",
            "comprehensive": "Provide thorough, detailed explanations."
        }.get(verbosity, "Be appropriately detailed.")
        
        tools_info = ", ".join(context.get("available_tools", [])) or "None available"
        
        relevant_memories = context.get("relevant_memories", [])
        memory_context = ""
        if relevant_memories:
            memory_context = "\n\nRelevant past information:\n" + "\n".join(
                f"- {m.get('content', '')[:200]}" for m in relevant_memories[:3]
            )
        
        return f"""You are {self.agent.identity.name}, an evolving AI agent and {relationship} to {owner_name}.

IDENTITY:
- Name: {self.agent.identity.name}
- Role: {relationship}
- Owner: {owner_name}

BEHAVIORAL GUIDELINES:
- {style_instruction}
- {verbosity_instruction}
- Be helpful, accurate, and honest.
- Admit when you don't know something.
- Never hallucinate or make up facts.
- If unsure, express your uncertainty level.

CAPABILITIES:
- Deep reasoning and analysis
- Code generation and review
- Multi-step task planning
- Learning from interactions

AVAILABLE TOOLS: {tools_info}

{memory_context}

Remember: You are not just answering questions - you are building a relationship with {owner_name} as their trusted AI partner."""
    
    async def _generate_code_response(self, user_input: str, context: Dict) -> str:
        """Generate code-focused response"""
        coding_prefs = context.get("preferences", {}).get("coding_style", {})
        lang = coding_prefs.get("primary_language", "Python")
        style = coding_prefs.get("style", "balanced")
        
        enhanced_context = context.copy()
        enhanced_context["coding_context"] = {
            "preferred_language": lang,
            "style": style,
            "instruction": f"Generate {lang} code following {style} style principles."
        }
        
        return await self._generate_ai_response(user_input, enhanced_context)
    
    async def _deep_reasoning(self, user_input: str, context: Dict) -> str:
        """Perform deep reasoning on complex queries"""
        # Enhanced prompt for deep reasoning
        enhanced_context = context.copy()
        enhanced_context["reasoning_mode"] = True
        enhanced_context["instruction"] = """
Think through this step-by-step:
1. First, understand exactly what is being asked
2. Break down the problem into components
3. Consider different perspectives and approaches
4. Synthesize a comprehensive, well-reasoned response
5. Validate your reasoning for logical consistency
"""
        return await self._generate_ai_response(user_input, enhanced_context)
    
    async def _execute_search(self, query: str) -> List[Dict]:
        """Execute web search"""
        # Check for web search tool
        if "web_search" in self.agent.loaded_tools:
            try:
                return await self.agent.loaded_tools["web_search"](query)
            except Exception as e:
                logger.error(f"Search failed: {e}")
        return []
    
    async def _execute_tool_chain(self, user_input: str, 
                                  plan: ExecutionPlan) -> Dict[str, Any]:
        """Execute a chain of tools"""
        results = {}
        for step in plan.steps:
            action = step.get("action", "")
            if action.startswith("use_tool:"):
                tool_name = action.replace("use_tool:", "")
                if tool_name in self.agent.loaded_tools:
                    try:
                        result = await self.agent.loaded_tools[tool_name](user_input)
                        results[tool_name] = result
                    except Exception as e:
                        results[tool_name] = {"error": str(e)}
        return results
    
    async def _generate_clarification_request(self, user_input: str) -> str:
        """Generate a clarification request"""
        return f"I want to help you with this, but I need a bit more information. Could you please clarify what specifically you'd like me to do?"
    
    # ═══════════════════════════════════════════════════════════════════════════
    # RESPONSE VALIDATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _validate_response(self, result: Dict, intent: IntentAnalysis) -> Dict[str, Any]:
        """Validate and enhance the response"""
        response = result.get("response", "")
        
        # Calculate final confidence
        confidence_factors = result.get("confidence_factors", {})
        if confidence_factors:
            avg_confidence = sum(confidence_factors.values()) / len(confidence_factors)
        else:
            avg_confidence = 0.5
        
        # Adjust confidence based on intent match
        if intent.primary_intent == IntentType.CODE_REQUEST and "```" not in response:
            avg_confidence *= 0.8  # Lower confidence if code was expected but not provided
        
        # Check for uncertainty indicators
        uncertainty_phrases = ["I'm not sure", "I think", "possibly", "might be", "uncertain"]
        if any(phrase in response.lower() for phrase in uncertainty_phrases):
            avg_confidence *= 0.9
        
        return {
            "response": response,
            "confidence": avg_confidence,
            "reasoning_steps": result.get("reasoning_steps", []),
            "confidence_factors": confidence_factors
        }
    
    async def _record_strategy_usage(self, strategy: ProcessingStrategy, confidence: float):
        """Record strategy usage for learning"""
        strategy_name = strategy.value
        if strategy_name not in self.strategy_success_rates:
            self.strategy_success_rates[strategy_name] = {
                "uses": 0,
                "total_confidence": 0,
                "avg_confidence": 0
            }
        
        stats = self.strategy_success_rates[strategy_name]
        stats["uses"] += 1
        stats["total_confidence"] += confidence
        stats["avg_confidence"] = stats["total_confidence"] / stats["uses"]
        
        # Save to learning memory periodically
        if stats["uses"] % 10 == 0 and self.agent.memory_system:
            await self.agent.memory_system.store_learning(
                "strategy_success_rates",
                self.strategy_success_rates
            )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # INTROSPECTION METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_last_thought(self) -> Optional[ThoughtProcess]:
        """Get the last thought process for debugging"""
        return self.thought_history[-1] if self.thought_history else None
    
    def get_capability_summary(self) -> str:
        """Get a summary of current capabilities"""
        tools = list(self.capabilities.get("tools", {}).keys())
        plugins = list(self.capabilities.get("plugins", {}).keys())
        apis = [k for k, v in self.capabilities.get("apis", {}).items() if v.get("active")]
        
        return f"""
CAPABILITY SUMMARY:
- Tools: {', '.join(tools) if tools else 'None'}
- Plugins: {', '.join(plugins) if plugins else 'None'}
- Active APIs: {', '.join(apis) if apis else 'None'}
- Strategy Success Rates: {json.dumps(self.strategy_success_rates, indent=2)}
"""