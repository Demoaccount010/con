#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                         TOOL MANAGER - Tool Orchestration                    ║
║                   Unified Tool Management for SMILE Agent                    ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Features:                                                                   ║
║  - Unified tool interface                                                    ║
║  - Tool chain execution                                                      ║
║  - Parameter validation                                                      ║
║  - Result caching                                                            ║
║  - Error handling and retry                                                  ║
║  - Usage analytics                                                           ║
║  - Tool recommendations                                                      ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import asyncio
import logging
import json
import time
import inspect
from datetime import datetime
from typing import Dict, Any, List, Optional, Callable, Union
from dataclasses import dataclass, field
from enum import Enum, auto
from collections import defaultdict
import traceback
import hashlib

logger = logging.getLogger("SMILE.ToolManager")

# ═══════════════════════════════════════════════════════════════════════════════
# ENUMS AND DATA STRUCTURES
# ═══════════════════════════════════════════════════════════════════════════════

class ToolCategory(Enum):
    """Categories of tools"""
    SEARCH = "search"
    FILE = "file"
    CODE = "code"
    MATH = "math"
    DATA = "data"
    NETWORK = "network"
    SYSTEM = "system"
    UTILITY = "utility"
    CUSTOM = "custom"

class ToolStatus(Enum):
    """Tool operational status"""
    AVAILABLE = "available"
    BUSY = "busy"
    DISABLED = "disabled"
    ERROR = "error"
    RATE_LIMITED = "rate_limited"

class ExecutionStatus(Enum):
    """Tool execution status"""
    SUCCESS = "success"
    FAILURE = "failure"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"
    PARTIAL = "partial"

@dataclass
class ToolDefinition:
    """Definition of a tool"""
    name: str
    description: str
    function: Callable
    category: ToolCategory
    parameters: Dict[str, Dict[str, Any]]  # param_name -> {type, required, default, description}
    returns: Dict[str, Any]
    requires_confirmation: bool = False
    timeout_seconds: int = 30
    retry_count: int = 2
    cache_ttl_seconds: int = 0  # 0 = no caching
    tags: List[str] = field(default_factory=list)
    examples: List[Dict[str, Any]] = field(default_factory=list)
    
    def get_signature(self) -> str:
        """Get human-readable signature"""
        params = []
        for name, spec in self.parameters.items():
            type_str = spec.get('type', 'any')
            if spec.get('required', True):
                params.append(f"{name}: {type_str}")
            else:
                default = spec.get('default', 'None')
                params.append(f"{name}: {type_str} = {default}")
        
        return f"{self.name}({', '.join(params)})"

@dataclass
class ToolCall:
    """Represents a single tool call"""
    id: str
    tool_name: str
    parameters: Dict[str, Any]
    timestamp: datetime
    status: ExecutionStatus = ExecutionStatus.SUCCESS
    result: Any = None
    error: Optional[str] = None
    execution_time_ms: float = 0.0
    cached: bool = False
    retry_count: int = 0

@dataclass
class ToolChain:
    """A chain of tool calls"""
    id: str
    calls: List[ToolCall]
    created_at: datetime
    completed_at: Optional[datetime] = None
    status: ExecutionStatus = ExecutionStatus.SUCCESS
    final_result: Any = None

@dataclass
class ToolUsageStats:
    """Usage statistics for a tool"""
    call_count: int = 0
    success_count: int = 0
    failure_count: int = 0
    total_time_ms: float = 0.0
    avg_time_ms: float = 0.0
    cache_hits: int = 0
    last_used: Optional[datetime] = None
    last_error: Optional[str] = None

# ═══════════════════════════════════════════════════════════════════════════════
# TOOL MANAGER CORE
# ═══════════════════════════════════════════════════════════════════════════════

class ToolManager:
    """
    Unified Tool Management System
    
    Provides:
    - Tool registration and discovery
    - Parameter validation
    - Execution with retry
    - Result caching
    - Chain execution
    - Usage analytics
    """
    
    def __init__(self, agent):
        """
        Initialize Tool Manager
        
        Args:
            agent: Reference to main SMILE agent
        """
        self.agent = agent
        
        # Tool registry
        self.tools: Dict[str, ToolDefinition] = {}
        self.tool_status: Dict[str, ToolStatus] = {}
        
        # Execution tracking
        self.call_history: List[ToolCall] = []
        self.max_history = 500
        
        # Usage statistics
        self.usage_stats: Dict[str, ToolUsageStats] = defaultdict(ToolUsageStats)
        
        # Result cache
        self.result_cache: Dict[str, Any] = {}
        self.cache_timestamps: Dict[str, float] = {}
        self.cache_max_size = 200
        
        # Active executions
        self.active_executions: Dict[str, asyncio.Task] = {}
        
        # Tool recommendations based on context
        self.context_tool_map: Dict[str, List[str]] = {}
        
        logger.info("ToolManager instance created")
    
    async def initialize(self):
        """Initialize the tool manager"""
        logger.info("Initializing Tool Manager...")
        
        # Register core tools
        await self._register_core_tools()
        
        # Load tools from plugins
        await self._load_plugin_tools()
        
        # Build context mapping
        self._build_context_map()
        
        logger.info(f"Tool Manager initialized with {len(self.tools)} tools")
    
    async def _register_core_tools(self):
        """Register built-in core tools"""
        
        # Echo tool (for testing)
        self.register_tool(ToolDefinition(
            name="echo",
            description="Echo back the input (for testing)",
            function=self._tool_echo,
            category=ToolCategory.UTILITY,
            parameters={
                "message": {
                    "type": "string",
                    "required": True,
                    "description": "Message to echo"
                }
            },
            returns={"type": "string", "description": "Echoed message"},
            tags=["test", "utility"]
        ))
        
        # Get current time
        self.register_tool(ToolDefinition(
            name="get_time",
            description="Get current date and time",
            function=self._tool_get_time,
            category=ToolCategory.UTILITY,
            parameters={
                "timezone": {
                    "type": "string",
                    "required": False,
                    "default": "UTC",
                    "description": "Timezone (e.g., 'UTC', 'US/Eastern')"
                }
            },
            returns={"type": "dict", "description": "Current datetime info"},
            cache_ttl_seconds=1,
            tags=["time", "utility"]
        ))
        
        # JSON parser
        self.register_tool(ToolDefinition(
            name="parse_json",
            description="Parse a JSON string into a dictionary",
            function=self._tool_parse_json,
            category=ToolCategory.DATA,
            parameters={
                "json_string": {
                    "type": "string",
                    "required": True,
                    "description": "JSON string to parse"
                }
            },
            returns={"type": "dict", "description": "Parsed JSON data"},
            tags=["json", "data", "parsing"]
        ))
        
        # Text analyzer
        self.register_tool(ToolDefinition(
            name="analyze_text",
            description="Analyze text for word count, characters, etc.",
            function=self._tool_analyze_text,
            category=ToolCategory.DATA,
            parameters={
                "text": {
                    "type": "string",
                    "required": True,
                    "description": "Text to analyze"
                }
            },
            returns={"type": "dict", "description": "Text analysis results"},
            tags=["text", "analysis", "utility"]
        ))
    
    async def _tool_echo(self, message: str) -> str:
        """Echo tool implementation"""
        return f"Echo: {message}"
    
    async def _tool_get_time(self, timezone: str = "UTC") -> Dict[str, Any]:
        """Get time tool implementation"""
        from datetime import datetime, timezone as tz
        
        now = datetime.now(tz.utc)
        
        return {
            "datetime": now.isoformat(),
            "date": now.strftime("%Y-%m-%d"),
            "time": now.strftime("%H:%M:%S"),
            "timezone": timezone,
            "timestamp": now.timestamp()
        }
    
    async def _tool_parse_json(self, json_string: str) -> Dict[str, Any]:
        """Parse JSON tool implementation"""
        try:
            return {"success": True, "data": json.loads(json_string)}
        except json.JSONDecodeError as e:
            return {"success": False, "error": str(e)}
    
    async def _tool_analyze_text(self, text: str) -> Dict[str, Any]:
        """Analyze text tool implementation"""
        words = text.split()
        sentences = text.count('.') + text.count('!') + text.count('?')
        
        return {
            "character_count": len(text),
            "word_count": len(words),
            "sentence_count": max(sentences, 1),
            "avg_word_length": sum(len(w) for w in words) / max(len(words), 1),
            "paragraph_count": text.count('\n\n') + 1
        }
    
    async def _load_plugin_tools(self):
        """Load tools from plugins"""
        if hasattr(self.agent, 'plugin_system') and self.agent.plugin_system:
            plugin_tools = self.agent.plugin_system.get_all_tools()
            
            for full_name, func in plugin_tools.items():
                # Parse plugin.tool_name format
                parts = full_name.split('.')
                if len(parts) >= 2:
                    plugin_name = parts[0]
                    tool_name = '.'.join(parts[1:])
                else:
                    tool_name = full_name
                
                # Extract parameters from function signature
                sig = inspect.signature(func)
                parameters = {}
                
                for param_name, param in sig.parameters.items():
                    if param_name == 'self':
                        continue
                    
                    param_info = {
                        "type": "any",
                        "required": param.default == inspect.Parameter.empty,
                        "description": ""
                    }
                    
                    if param.default != inspect.Parameter.empty:
                        param_info["default"] = param.default
                    
                    if param.annotation != inspect.Parameter.empty:
                        param_info["type"] = param.annotation.__name__ if hasattr(param.annotation, '__name__') else str(param.annotation)
                    
                    parameters[param_name] = param_info
                
                # Create tool definition
                tool_def = ToolDefinition(
                    name=full_name,
                    description=func.__doc__ or f"Tool from {plugin_name} plugin",
                    function=func,
                    category=ToolCategory.CUSTOM,
                    parameters=parameters,
                    returns={"type": "any", "description": "Tool result"},
                    tags=[plugin_name, "plugin"]
                )
                
                self.register_tool(tool_def)
    
    def _build_context_map(self):
        """Build mapping of contexts to recommended tools"""
        self.context_tool_map = {
            "search": ["web_search.search", "web_search.search_news"],
            "file": ["file_manager.read_file", "file_manager.write_file", 
                    "file_manager.list_directory"],
            "code": ["code_executor.execute_python", "code_executor.execute_shell"],
            "math": ["calculator.calculate", "calculator.convert_units"],
            "time": ["get_time"],
            "data": ["parse_json", "analyze_text"]
        }
    
    # ═══════════════════════════════════════════════════════════════════════════
    # TOOL REGISTRATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    def register_tool(self, tool_def: ToolDefinition):
        """
        Register a new tool
        
        Args:
            tool_def: Tool definition
        """
        self.tools[tool_def.name] = tool_def
        self.tool_status[tool_def.name] = ToolStatus.AVAILABLE
        self.usage_stats[tool_def.name] = ToolUsageStats()
        
        logger.debug(f"Registered tool: {tool_def.name}")
    
    def unregister_tool(self, tool_name: str) -> bool:
        """
        Unregister a tool
        
        Args:
            tool_name: Name of tool to remove
            
        Returns:
            True if removed
        """
        if tool_name in self.tools:
            del self.tools[tool_name]
            del self.tool_status[tool_name]
            logger.info(f"Unregistered tool: {tool_name}")
            return True
        return False
    
    def get_tool(self, tool_name: str) -> Optional[ToolDefinition]:
        """Get tool definition by name"""
        return self.tools.get(tool_name)
    
    def list_tools(self, category: ToolCategory = None) -> List[Dict[str, Any]]:
        """
        List available tools
        
        Args:
            category: Optional category filter
            
        Returns:
            List of tool info dicts
        """
        tools_list = []
        
        for name, tool_def in self.tools.items():
            if category and tool_def.category != category:
                continue
            
            tools_list.append({
                "name": name,
                "description": tool_def.description,
                "category": tool_def.category.value,
                "signature": tool_def.get_signature(),
                "status": self.tool_status.get(name, ToolStatus.AVAILABLE).value,
                "tags": tool_def.tags
            })
        
        return tools_list
    
    # ═══════════════════════════════════════════════════════════════════════════
    # TOOL EXECUTION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def call_tool(self, tool_name: str, 
                       parameters: Dict[str, Any] = None,
                       timeout: int = None) -> ToolCall:
        """
        Execute a tool call
        
        Args:
            tool_name: Name of tool to call
            parameters: Parameters to pass
            timeout: Override default timeout
            
        Returns:
            ToolCall with results
        """
        call_id = self._generate_call_id()
        start_time = time.time()
        parameters = parameters or {}
        
        # Create call record
        call = ToolCall(
            id=call_id,
            tool_name=tool_name,
            parameters=parameters,
            timestamp=datetime.now()
        )
        
        try:
            # Get tool definition
            tool_def = self.tools.get(tool_name)
            if not tool_def:
                raise ValueError(f"Unknown tool: {tool_name}")
            
            # Check tool status
            status = self.tool_status.get(tool_name, ToolStatus.AVAILABLE)
            if status not in [ToolStatus.AVAILABLE]:
                raise RuntimeError(f"Tool {tool_name} is {status.value}")
            
            # Validate parameters
            validated_params = self._validate_parameters(tool_def, parameters)
            
            # Check cache
            if tool_def.cache_ttl_seconds > 0:
                cached = self._get_cached_result(tool_name, validated_params)
                if cached is not None:
                    call.result = cached
                    call.cached = True
                    call.status = ExecutionStatus.SUCCESS
                    call.execution_time_ms = (time.time() - start_time) * 1000
                    self._update_stats(tool_name, call)
                    logger.debug(f"Cache hit for {tool_name}")
                    return call
            
            # Set tool as busy
            self.tool_status[tool_name] = ToolStatus.BUSY
            
            # Execute with timeout and retry
            timeout_val = timeout or tool_def.timeout_seconds
            retry_count = 0
            last_error = None
            
            while retry_count <= tool_def.retry_count:
                try:
                    # Create task
                    task = asyncio.create_task(
                        self._execute_tool(tool_def, validated_params)
                    )
                    self.active_executions[call_id] = task
                    
                    # Wait with timeout
                    result = await asyncio.wait_for(task, timeout=timeout_val)
                    
                    # Success
                    call.result = result
                    call.status = ExecutionStatus.SUCCESS
                    call.retry_count = retry_count
                    
                    # Cache result if applicable
                    if tool_def.cache_ttl_seconds > 0:
                        self._cache_result(tool_name, validated_params, result, 
                                         tool_def.cache_ttl_seconds)
                    
                    break
                    
                except asyncio.TimeoutError:
                    last_error = f"Timeout after {timeout_val}s"
                    retry_count += 1
                    logger.warning(f"Tool {tool_name} timeout, retry {retry_count}")
                    
                except Exception as e:
                    last_error = str(e)
                    retry_count += 1
                    logger.warning(f"Tool {tool_name} error: {e}, retry {retry_count}")
            
            # If we exhausted retries
            if retry_count > tool_def.retry_count:
                call.status = ExecutionStatus.FAILURE
                call.error = last_error
                self.tool_status[tool_name] = ToolStatus.ERROR
            
        except Exception as e:
            call.status = ExecutionStatus.FAILURE
            call.error = str(e)
            logger.error(f"Tool call failed: {e}")
            
        finally:
            # Cleanup
            if call_id in self.active_executions:
                del self.active_executions[call_id]
            
            # Reset status
            if self.tool_status.get(tool_name) == ToolStatus.BUSY:
                self.tool_status[tool_name] = ToolStatus.AVAILABLE
            
            # Record execution time
            call.execution_time_ms = (time.time() - start_time) * 1000
            
            # Update statistics
            self._update_stats(tool_name, call)
            
            # Store in history
            self._record_call(call)
        
        return call
    
    async def _execute_tool(self, tool_def: ToolDefinition, 
                           parameters: Dict[str, Any]) -> Any:
        """Execute a tool function"""
        func = tool_def.function
        
        # Check if async
        if asyncio.iscoroutinefunction(func):
            return await func(**parameters)
        else:
            # Run sync function in executor
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(None, lambda: func(**parameters))
    
    def _validate_parameters(self, tool_def: ToolDefinition,
                            parameters: Dict[str, Any]) -> Dict[str, Any]:
        """Validate and normalize parameters"""
        validated = {}
        
        for param_name, param_spec in tool_def.parameters.items():
            if param_name in parameters:
                value = parameters[param_name]
                
                # Type validation (basic)
                expected_type = param_spec.get('type', 'any')
                if expected_type != 'any':
                    # Simple type check
                    type_map = {
                        'string': str,
                        'str': str,
                        'int': int,
                        'integer': int,
                        'float': float,
                        'bool': bool,
                        'boolean': bool,
                        'list': list,
                        'dict': dict
                    }
                    
                    expected = type_map.get(expected_type.lower())
                    if expected and not isinstance(value, expected):
                        # Try to convert
                        try:
                            value = expected(value)
                        except (ValueError, TypeError):
                            raise TypeError(
                                f"Parameter '{param_name}' expected {expected_type}, "
                                f"got {type(value).__name__}"
                            )
                
                validated[param_name] = value
                
            elif param_spec.get('required', True):
                raise ValueError(f"Missing required parameter: {param_name}")
            
            elif 'default' in param_spec:
                validated[param_name] = param_spec['default']
        
        return validated
    
    # ═══════════════════════════════════════════════════════════════════════════
    # TOOL CHAINS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def execute_chain(self, chain_spec: List[Dict[str, Any]],
                           stop_on_error: bool = True) -> ToolChain:
        """
        Execute a chain of tool calls
        
        Args:
            chain_spec: List of {tool: name, params: {...}, uses_previous: bool}
            stop_on_error: Stop chain on first error
            
        Returns:
            ToolChain with all results
        """
        chain_id = self._generate_call_id()
        chain = ToolChain(
            id=chain_id,
            calls=[],
            created_at=datetime.now()
        )
        
        previous_result = None
        
        for i, step in enumerate(chain_spec):
            tool_name = step.get('tool')
            params = step.get('params', {}).copy()
            uses_previous = step.get('uses_previous', False)
            
            # Inject previous result if requested
            if uses_previous and previous_result is not None:
                if 'previous_result' in params:
                    params[params['previous_result']] = previous_result
                else:
                    params['input'] = previous_result
            
            # Execute step
            call = await self.call_tool(tool_name, params)
            chain.calls.append(call)
            
            if call.status == ExecutionStatus.SUCCESS:
                previous_result = call.result
            else:
                if stop_on_error:
                    chain.status = ExecutionStatus.PARTIAL
                    break
        
        chain.completed_at = datetime.now()
        chain.final_result = previous_result
        
        if all(c.status == ExecutionStatus.SUCCESS for c in chain.calls):
            chain.status = ExecutionStatus.SUCCESS
        
        return chain
    
    async def execute_parallel(self, calls: List[Dict[str, Any]],
                              max_concurrent: int = 5) -> List[ToolCall]:
        """
        Execute multiple tool calls in parallel
        
        Args:
            calls: List of {tool: name, params: {...}}
            max_concurrent: Maximum concurrent executions
            
        Returns:
            List of ToolCall results
        """
        semaphore = asyncio.Semaphore(max_concurrent)
        
        async def limited_call(call_spec):
            async with semaphore:
                return await self.call_tool(
                    call_spec.get('tool'),
                    call_spec.get('params', {})
                )
        
        tasks = [limited_call(c) for c in calls]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Convert exceptions to failed calls
        processed = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                call = ToolCall(
                    id=self._generate_call_id(),
                    tool_name=calls[i].get('tool', 'unknown'),
                    parameters=calls[i].get('params', {}),
                    timestamp=datetime.now(),
                    status=ExecutionStatus.FAILURE,
                    error=str(result)
                )
                processed.append(call)
            else:
                processed.append(result)
        
        return processed
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CACHING
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _generate_cache_key(self, tool_name: str, params: Dict) -> str:
        """Generate cache key for tool call"""
        param_str = json.dumps(params, sort_keys=True)
        content = f"{tool_name}:{param_str}"
        return hashlib.md5(content.encode()).hexdigest()
    
    def _get_cached_result(self, tool_name: str, params: Dict) -> Optional[Any]:
        """Get cached result if valid"""
        key = self._generate_cache_key(tool_name, params)
        
        if key not in self.result_cache:
            return None
        
        timestamp = self.cache_timestamps.get(key, 0)
        tool_def = self.tools.get(tool_name)
        ttl = tool_def.cache_ttl_seconds if tool_def else 0
        
        if time.time() - timestamp > ttl:
            del self.result_cache[key]
            del self.cache_timestamps[key]
            return None
        
        self.usage_stats[tool_name].cache_hits += 1
        return self.result_cache[key]
    
    def _cache_result(self, tool_name: str, params: Dict, 
                     result: Any, ttl: int):
        """Cache a tool result"""
        # Evict if full
        if len(self.result_cache) >= self.cache_max_size:
            oldest = min(self.cache_timestamps.keys(),
                        key=lambda k: self.cache_timestamps[k])
            del self.result_cache[oldest]
            del self.cache_timestamps[oldest]
        
        key = self._generate_cache_key(tool_name, params)
        self.result_cache[key] = result
        self.cache_timestamps[key] = time.time()
    
    def clear_cache(self, tool_name: str = None):
        """Clear cache for a tool or all tools"""
        if tool_name:
            keys_to_remove = [
                k for k in self.result_cache.keys()
                if k.startswith(self._generate_cache_key(tool_name, {})[:8])
            ]
            for k in keys_to_remove:
                del self.result_cache[k]
                del self.cache_timestamps[k]
        else:
            self.result_cache.clear()
            self.cache_timestamps.clear()
        
        logger.info(f"Cache cleared for {'all tools' if not tool_name else tool_name}")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # STATISTICS AND MONITORING
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _generate_call_id(self) -> str:
        """Generate unique call ID"""
        return f"call_{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
    
    def _record_call(self, call: ToolCall):
        """Record call in history"""
        self.call_history.append(call)
        
        if len(self.call_history) > self.max_history:
            self.call_history = self.call_history[-self.max_history:]
    
    def _update_stats(self, tool_name: str, call: ToolCall):
        """Update usage statistics"""
        stats = self.usage_stats[tool_name]
        stats.call_count += 1
        stats.total_time_ms += call.execution_time_ms
        stats.avg_time_ms = stats.total_time_ms / stats.call_count
        stats.last_used = datetime.now()
        
        if call.status == ExecutionStatus.SUCCESS:
            stats.success_count += 1
        else:
            stats.failure_count += 1
            stats.last_error = call.error
    
    def get_tool_stats(self, tool_name: str = None) -> Dict[str, Any]:
        """Get usage statistics"""
        if tool_name:
            stats = self.usage_stats.get(tool_name)
            if not stats:
                return {}
            
            return {
                "tool": tool_name,
                "call_count": stats.call_count,
                "success_rate": stats.success_count / max(stats.call_count, 1),
                "avg_time_ms": round(stats.avg_time_ms, 2),
                "cache_hits": stats.cache_hits,
                "last_used": stats.last_used.isoformat() if stats.last_used else None,
                "last_error": stats.last_error
            }
        
        # All tools
        return {
            name: {
                "call_count": s.call_count,
                "success_rate": round(s.success_count / max(s.call_count, 1), 2),
                "avg_time_ms": round(s.avg_time_ms, 2)
            }
            for name, s in self.usage_stats.items()
            if s.call_count > 0
        }
    
    def get_recent_calls(self, limit: int = 20) -> List[Dict[str, Any]]:
        """Get recent tool calls"""
        recent = self.call_history[-limit:]
        
        return [
            {
                "id": call.id,
                "tool": call.tool_name,
                "status": call.status.value,
                "time_ms": round(call.execution_time_ms, 2),
                "timestamp": call.timestamp.isoformat(),
                "cached": call.cached,
                "error": call.error
            }
            for call in reversed(recent)
        ]
    
    # ═══════════════════════════════════════════════════════════════════════════
    # TOOL RECOMMENDATIONS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def recommend_tools(self, context: str, query: str = None) -> List[str]:
        """
        Recommend tools based on context
        
        Args:
            context: Context keyword (e.g., "search", "file", "code")
            query: Optional query for more specific matching
            
        Returns:
            List of recommended tool names
        """
        recommendations = []
        
        # Get from context map
        context_lower = context.lower()
        for key, tools in self.context_tool_map.items():
            if key in context_lower or context_lower in key:
                recommendations.extend(tools)
        
        # Filter to available tools
        recommendations = [
            t for t in recommendations
            if t in self.tools and 
            self.tool_status.get(t) == ToolStatus.AVAILABLE
        ]
        
        # Add query-based matching
        if query:
            query_lower = query.lower()
            for name, tool_def in self.tools.items():
                if name in recommendations:
                    continue
                
                # Check description and tags
                if any(term in tool_def.description.lower() for term in query_lower.split()):
                    recommendations.append(name)
                elif any(term in tag for term in query_lower.split() for tag in tool_def.tags):
                    recommendations.append(name)
        
        return list(dict.fromkeys(recommendations))[:5]  # Top 5, no duplicates
    
    def find_tool(self, capability: str) -> Optional[str]:
        """
        Find a tool that provides a specific capability
        
        Args:
            capability: Description of needed capability
            
        Returns:
            Tool name if found
        """
        capability_lower = capability.lower()
        
        # Exact match
        if capability_lower in self.tools:
            return capability_lower
        
        # Search in descriptions
        best_match = None
        best_score = 0
        
        for name, tool_def in self.tools.items():
            score = 0
            
            # Check name
            if capability_lower in name.lower():
                score += 2
            
            # Check description
            desc_words = tool_def.description.lower().split()
            cap_words = capability_lower.split()
            matching_words = sum(1 for w in cap_words if w in desc_words)
            score += matching_words
            
            # Check tags
            if any(capability_lower in tag for tag in tool_def.tags):
                score += 1
            
            if score > best_score:
                best_score = score
                best_match = name
        
        return best_match if best_score > 0 else None
    
    # ═══════════════════════════════════════════════════════════════════════════
    # STATUS AND CONTROL
    # ═══════════════════════════════════════════════════════════════════════════
    
    def set_tool_status(self, tool_name: str, status: ToolStatus):
        """Set tool status"""
        if tool_name in self.tools:
            self.tool_status[tool_name] = status
            logger.info(f"Tool {tool_name} status set to {status.value}")
    
    def enable_tool(self, tool_name: str):
        """Enable a disabled tool"""
        self.set_tool_status(tool_name, ToolStatus.AVAILABLE)
    
    def disable_tool(self, tool_name: str):
        """Disable a tool"""
        self.set_tool_status(tool_name, ToolStatus.DISABLED)
    
    async def cancel_execution(self, call_id: str) -> bool:
        """Cancel an active execution"""
        if call_id in self.active_executions:
            task = self.active_executions[call_id]
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
            del self.active_executions[call_id]
            logger.info(f"Cancelled execution: {call_id}")
            return True
        return False
    
    def get_overall_stats(self) -> Dict[str, Any]:
        """Get overall tool manager statistics"""
        total_calls = sum(s.call_count for s in self.usage_stats.values())
        total_success = sum(s.success_count for s in self.usage_stats.values())
        total_cache_hits = sum(s.cache_hits for s in self.usage_stats.values())
        
        return {
            "total_tools": len(self.tools),
            "available_tools": sum(
                1 for s in self.tool_status.values() 
                if s == ToolStatus.AVAILABLE
            ),
            "total_calls": total_calls,
            "success_rate": round(total_success / max(total_calls, 1), 3),
            "cache_hit_rate": round(total_cache_hits / max(total_calls, 1), 3),
            "cache_size": len(self.result_cache),
            "active_executions": len(self.active_executions),
            "history_size": len(self.call_history)
        }