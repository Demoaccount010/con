#!/usr/bin/env python3
"""
SMILE AI Agent - Core Package

This package contains all core system modules for the SMILE agent.
"""

from .meta_brain import MetaBrain
from .memory_system import MemorySystem
from .api_manager import APIManager
from .plugin_system import PluginSystem, BasePlugin, PluginMetadata, PluginType
from .initiative_engine import InitiativeEngine
from .reflection_engine import ReflectionEngine
from .upgrade_engine import UpgradeEngine
from .code_index import CodeIndex
from .thinking_engine import ThinkingEngine
from .router_engine import RouterEngine
from .tool_manager import ToolManager

__all__ = [
    'MetaBrain',
    'MemorySystem', 
    'APIManager',
    'PluginSystem',
    'BasePlugin',
    'PluginMetadata',
    'PluginType',
    'InitiativeEngine',
    'ReflectionEngine',
    'UpgradeEngine',
    'CodeIndex',
    'ThinkingEngine',
    'RouterEngine',
    'ToolManager'
]

__version__ = "1.0.0"