#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                      INITIATIVE ENGINE - Proactive Messaging                 ║
║                   Autonomous Communication for SMILE Agent                   ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Features:                                                                   ║
║  - Proactive message generation                                              ║
║  - Context-aware timing                                                      ║
║  - Learning from interaction patterns                                        ║
║  - Rate limiting to avoid spam                                               ║
║  - Priority-based message queuing                                            ║
║  - Trigger-based notifications                                               ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum, auto
from collections import deque
import json
import random

logger = logging.getLogger("SMILE.InitiativeEngine")

# ═══════════════════════════════════════════════════════════════════════════════
# ENUMS AND DATA STRUCTURES
# ═══════════════════════════════════════════════════════════════════════════════

class InitiativeType(Enum):
    """Types of proactive messages"""
    CLARIFICATION = "clarification"      # Ask for clarification
    SUGGESTION = "suggestion"            # Suggest improvement
    REMINDER = "reminder"                # Remind about something
    LEARNING = "learning"                # Share learned insight
    UPGRADE = "upgrade"                  # Propose upgrade
    STATUS = "status"                    # Status update
    GREETING = "greeting"                # Time-based greeting
    FOLLOWUP = "followup"                # Follow-up on previous task
    DISCOVERY = "discovery"              # Share a discovery
    WARNING = "warning"                  # Important warning

class InitiativePriority(Enum):
    """Priority levels for initiatives"""
    CRITICAL = 1      # Must send immediately
    HIGH = 2          # Send soon
    MEDIUM = 3        # Send when appropriate
    LOW = 4           # Send when idle
    BACKGROUND = 5    # Only if nothing else

@dataclass
class Initiative:
    """Represents a proactive message initiative"""
    id: str
    type: InitiativeType
    priority: InitiativePriority
    message: str
    context: Dict[str, Any]
    created_at: datetime
    expires_at: Optional[datetime] = None
    conditions: Dict[str, Any] = field(default_factory=dict)
    sent: bool = False
    sent_at: Optional[datetime] = None
    response_received: bool = False
    
    def is_expired(self) -> bool:
        if self.expires_at is None:
            return False
        return datetime.now() > self.expires_at
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "type": self.type.value,
            "priority": self.priority.value,
            "message": self.message,
            "created_at": self.created_at.isoformat(),
            "sent": self.sent
        }

@dataclass
class InteractionPattern:
    """Learned interaction pattern"""
    pattern_type: str
    frequency: int
    last_occurrence: datetime
    typical_time: Optional[str] = None  # e.g., "09:00", "afternoon"
    typical_context: Dict[str, Any] = field(default_factory=dict)
    success_rate: float = 0.5

# ═══════════════════════════════════════════════════════════════════════════════
# TRIGGER SYSTEM
# ═══════════════════════════════════════════════════════════════════════════════

class TriggerType(Enum):
    """Types of triggers for initiatives"""
    TIME_BASED = "time_based"           # Specific time
    IDLE_TIMEOUT = "idle_timeout"       # After period of no activity
    PATTERN_MATCH = "pattern_match"     # Matches interaction pattern
    GOAL_PROGRESS = "goal_progress"     # Goal milestone reached
    ERROR_DETECTED = "error_detected"   # Error in system
    LEARNING_COMPLETE = "learning"      # Finished learning something
    UPGRADE_AVAILABLE = "upgrade"       # New capability available
    MEMORY_TRIGGER = "memory"           # Memory-based trigger

@dataclass
class Trigger:
    """Trigger configuration"""
    trigger_type: TriggerType
    condition: Dict[str, Any]
    initiative_template: Dict[str, Any]
    cooldown_minutes: int = 60
    last_fired: Optional[datetime] = None
    enabled: bool = True

# ═══════════════════════════════════════════════════════════════════════════════
# INITIATIVE ENGINE CORE
# ═══════════════════════════════════════════════════════════════════════════════

class InitiativeEngine:
    """
    Proactive Messaging Engine
    
    Enables SMILE to initiate conversations based on:
    - Learned patterns
    - System events
    - Time-based triggers
    - Goal progress
    - Discovered insights
    """
    
    def __init__(self, agent):
        """
        Initialize Initiative Engine
        
        Args:
            agent: Reference to main SMILE agent
        """
        self.agent = agent
        
        # Initiative queue (priority queue using sorted list)
        self.pending_initiatives: List[Initiative] = []
        
        # Sent initiatives history
        self.sent_history: deque = deque(maxlen=100)
        
        # Learned patterns
        self.patterns: Dict[str, InteractionPattern] = {}
        
        # Active triggers
        self.triggers: Dict[str, Trigger] = {}
        
        # Rate limiting
        self.messages_per_hour = 5
        self.messages_this_hour: List[datetime] = []
        
        # Timing configuration
        self.min_interval_seconds = 300  # 5 minutes between messages
        self.last_message_time: Optional[datetime] = None
        
        # Owner activity tracking
        self.last_owner_activity: Optional[datetime] = None
        self.idle_threshold_minutes = 30
        
        # Background task
        self._background_task: Optional[asyncio.Task] = None
        self._running = False
        
        logger.info("InitiativeEngine instance created")
    
    async def initialize(self):
        """Initialize the initiative engine"""
        logger.info("Initializing Initiative Engine...")
        
        # Load patterns from memory
        await self._load_patterns()
        
        # Setup default triggers
        self._setup_default_triggers()
        
        # Start background task
        self._running = True
        self._background_task = asyncio.create_task(self._background_loop())
        
        logger.info("Initiative Engine initialized")
    
    async def shutdown(self):
        """Shutdown the initiative engine"""
        logger.info("Shutting down Initiative Engine...")
        
        self._running = False
        if self._background_task:
            self._background_task.cancel()
            try:
                await self._background_task
            except asyncio.CancelledError:
                pass
        
        # Save patterns
        await self._save_patterns()
        
        logger.info("Initiative Engine shutdown complete")
    
    async def _load_patterns(self):
        """Load learned patterns from memory"""
        if self.agent.memory_system:
            patterns = await self.agent.memory_system.retrieve_learning("interaction_patterns")
            if patterns and isinstance(patterns, dict):
                for key, data in patterns.items():
                    self.patterns[key] = InteractionPattern(
                        pattern_type=data.get("pattern_type", "unknown"),
                        frequency=data.get("frequency", 0),
                        last_occurrence=datetime.fromisoformat(data.get("last_occurrence", datetime.now().isoformat())),
                        typical_time=data.get("typical_time"),
                        typical_context=data.get("typical_context", {}),
                        success_rate=data.get("success_rate", 0.5)
                    )
    
    async def _save_patterns(self):
        """Save learned patterns to memory"""
        if self.agent.memory_system:
            patterns_dict = {}
            for key, pattern in self.patterns.items():
                patterns_dict[key] = {
                    "pattern_type": pattern.pattern_type,
                    "frequency": pattern.frequency,
                    "last_occurrence": pattern.last_occurrence.isoformat(),
                    "typical_time": pattern.typical_time,
                    "typical_context": pattern.typical_context,
                    "success_rate": pattern.success_rate
                }
            await self.agent.memory_system.store_learning(
                "interaction_patterns",
                patterns_dict
            )
    
    def _setup_default_triggers(self):
        """Setup default initiative triggers"""
        # Morning greeting
        self.triggers["morning_greeting"] = Trigger(
            trigger_type=TriggerType.TIME_BASED,
            condition={"hour_range": (8, 10)},
            initiative_template={
                "type": InitiativeType.GREETING,
                "priority": InitiativePriority.LOW,
                "message_template": "Good morning, {owner_name}! Ready to help you with anything today."
            },
            cooldown_minutes=720  # 12 hours
        )
        
        # Idle check-in
        self.triggers["idle_checkin"] = Trigger(
            trigger_type=TriggerType.IDLE_TIMEOUT,
            condition={"idle_minutes": 60},
            initiative_template={
                "type": InitiativeType.FOLLOWUP,
                "priority": InitiativePriority.LOW,
                "message_template": "Just checking in - is there anything I can help you with?"
            },
            cooldown_minutes=180  # 3 hours
        )
        
        # Goal reminder
        self.triggers["goal_reminder"] = Trigger(
            trigger_type=TriggerType.GOAL_PROGRESS,
            condition={"check_pending_goals": True},
            initiative_template={
                "type": InitiativeType.REMINDER,
                "priority": InitiativePriority.MEDIUM,
                "message_template": "Reminder: You have a pending goal - {goal_description}"
            },
            cooldown_minutes=240  # 4 hours
        )
        
        # Learning share
        self.triggers["learning_share"] = Trigger(
            trigger_type=TriggerType.LEARNING_COMPLETE,
            condition={"has_new_learning": True},
            initiative_template={
                "type": InitiativeType.LEARNING,
                "priority": InitiativePriority.LOW,
                "message_template": "I learned something that might be useful: {learning}"
            },
            cooldown_minutes=120  # 2 hours
        )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # INITIATIVE CREATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def create_initiative(self, 
                               initiative_type: InitiativeType,
                               message: str,
                               priority: InitiativePriority = InitiativePriority.MEDIUM,
                               context: Dict[str, Any] = None,
                               expires_in_minutes: int = None) -> str:
        """
        Create a new initiative
        
        Args:
            initiative_type: Type of initiative
            message: The message to send
            priority: Priority level
            context: Additional context
            expires_in_minutes: When the initiative expires
            
        Returns:
            Initiative ID
        """
        initiative_id = f"init_{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
        
        expires_at = None
        if expires_in_minutes:
            expires_at = datetime.now() + timedelta(minutes=expires_in_minutes)
        
        initiative = Initiative(
            id=initiative_id,
            type=initiative_type,
            priority=priority,
            message=message,
            context=context or {},
            created_at=datetime.now(),
            expires_at=expires_at
        )
        
        # Insert in priority order
        self._insert_initiative(initiative)
        
        logger.info(f"Created initiative: {initiative_type.value} (priority: {priority.value})")
        
        return initiative_id
    
    def _insert_initiative(self, initiative: Initiative):
        """Insert initiative in priority order"""
        inserted = False
        for i, existing in enumerate(self.pending_initiatives):
            if initiative.priority.value < existing.priority.value:
                self.pending_initiatives.insert(i, initiative)
                inserted = True
                break
        
        if not inserted:
            self.pending_initiatives.append(initiative)
    
    async def cancel_initiative(self, initiative_id: str) -> bool:
        """Cancel a pending initiative"""
        for i, initiative in enumerate(self.pending_initiatives):
            if initiative.id == initiative_id:
                self.pending_initiatives.pop(i)
                logger.info(f"Cancelled initiative: {initiative_id}")
                return True
        return False
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MESSAGE RETRIEVAL
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def get_pending_message(self) -> Optional[str]:
        """
        Get the next pending proactive message
        
        Returns:
            Message string or None if no messages pending
        """
        # Check if we're allowed to send
        if not self._can_send_message():
            return None
        
        # Remove expired initiatives
        self._cleanup_expired()
        
        # Get highest priority initiative
        if not self.pending_initiatives:
            return None
        
        initiative = self.pending_initiatives[0]
        
        # Check conditions
        if not await self._check_conditions(initiative):
            return None
        
        # Mark as sent
        initiative.sent = True
        initiative.sent_at = datetime.now()
        self.pending_initiatives.pop(0)
        self.sent_history.append(initiative)
        
        # Update rate limiting
        self.messages_this_hour.append(datetime.now())
        self.last_message_time = datetime.now()
        
        logger.info(f"Sending initiative: {initiative.type.value}")
        
        return initiative.message
    
    def _can_send_message(self) -> bool:
        """Check if we're allowed to send a message"""
        now = datetime.now()
        
        # Check permissions
        if not self.agent.identity.owner.permission_levels.get("proactive_message", False):
            return False
        
        # Check rate limit
        hour_ago = now - timedelta(hours=1)
        self.messages_this_hour = [t for t in self.messages_this_hour if t > hour_ago]
        if len(self.messages_this_hour) >= self.messages_per_hour:
            return False
        
        # Check minimum interval
        if self.last_message_time:
            elapsed = (now - self.last_message_time).total_seconds()
            if elapsed < self.min_interval_seconds:
                return False
        
        return True
    
    def _cleanup_expired(self):
        """Remove expired initiatives"""
        self.pending_initiatives = [
            i for i in self.pending_initiatives
            if not i.is_expired()
        ]
    
    async def _check_conditions(self, initiative: Initiative) -> bool:
        """Check if initiative conditions are met"""
        conditions = initiative.conditions
        
        if not conditions:
            return True
        
        # Check time conditions
        if "after_time" in conditions:
            if datetime.now().hour < conditions["after_time"]:
                return False
        
        if "before_time" in conditions:
            if datetime.now().hour > conditions["before_time"]:
                return False
        
        # Check idle condition
        if "requires_idle" in conditions:
            if self.last_owner_activity:
                idle_seconds = (datetime.now() - self.last_owner_activity).total_seconds()
                if idle_seconds < conditions["requires_idle"] * 60:
                    return False
        
        return True
    
    # ═══════════════════════════════════════════════════════════════════════════
    # TRIGGER PROCESSING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _background_loop(self):
        """Background loop for checking triggers"""
        while self._running:
            try:
                await self._check_triggers()
                await asyncio.sleep(60)  # Check every minute
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in background loop: {e}")
                await asyncio.sleep(60)
    
    async def _check_triggers(self):
        """Check all triggers and create initiatives as needed"""
        now = datetime.now()
        
        for trigger_id, trigger in self.triggers.items():
            if not trigger.enabled:
                continue
            
            # Check cooldown
            if trigger.last_fired:
                elapsed = (now - trigger.last_fired).total_seconds() / 60
                if elapsed < trigger.cooldown_minutes:
                    continue
            
            # Check trigger condition
            should_fire = await self._evaluate_trigger(trigger)
            
            if should_fire:
                await self._fire_trigger(trigger_id, trigger)
    
    async def _evaluate_trigger(self, trigger: Trigger) -> bool:
        """Evaluate if a trigger should fire"""
        now = datetime.now()
        condition = trigger.condition
        
        if trigger.trigger_type == TriggerType.TIME_BASED:
            hour_range = condition.get("hour_range", (0, 24))
            return hour_range[0] <= now.hour < hour_range[1]
        
        elif trigger.trigger_type == TriggerType.IDLE_TIMEOUT:
            if not self.last_owner_activity:
                return False
            idle_minutes = (now - self.last_owner_activity).total_seconds() / 60
            return idle_minutes >= condition.get("idle_minutes", 60)
        
        elif trigger.trigger_type == TriggerType.GOAL_PROGRESS:
            if condition.get("check_pending_goals") and self.agent.memory_system:
                goals = await self.agent.memory_system.get_pending_goals(1)
                return len(goals) > 0
        
        elif trigger.trigger_type == TriggerType.LEARNING_COMPLETE:
            # Check if there are new learnings to share
            return False  # Implement based on reflection engine
        
        return False
    
    async def _fire_trigger(self, trigger_id: str, trigger: Trigger):
        """Fire a trigger and create an initiative"""
        template = trigger.initiative_template
        
        # Build message from template
        message_template = template.get("message_template", "")
        
        # Fill in template variables
        owner_name = self.agent.identity.owner.name if self.agent.identity.owner else "User"
        message = message_template.format(
            owner_name=owner_name,
            goal_description="",  # Would be filled from goals
            learning=""  # Would be filled from learnings
        )
        
        # Create initiative
        await self.create_initiative(
            initiative_type=template.get("type", InitiativeType.FOLLOWUP),
            message=message,
            priority=template.get("priority", InitiativePriority.MEDIUM),
            expires_in_minutes=60
        )
        
        trigger.last_fired = datetime.now()
        logger.info(f"Fired trigger: {trigger_id}")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PATTERN LEARNING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def record_interaction(self, interaction_type: str, context: Dict[str, Any] = None):
        """
        Record an interaction for pattern learning
        
        Args:
            interaction_type: Type of interaction
            context: Additional context
        """
        self.last_owner_activity = datetime.now()
        
        # Update or create pattern
        if interaction_type not in self.patterns:
            self.patterns[interaction_type] = InteractionPattern(
                pattern_type=interaction_type,
                frequency=0,
                last_occurrence=datetime.now()
            )
        
        pattern = self.patterns[interaction_type]
        pattern.frequency += 1
        pattern.last_occurrence = datetime.now()
        
        # Track time patterns
        hour = datetime.now().hour
        if 6 <= hour < 12:
            pattern.typical_time = "morning"
        elif 12 <= hour < 17:
            pattern.typical_time = "afternoon"
        elif 17 <= hour < 21:
            pattern.typical_time = "evening"
        else:
            pattern.typical_time = "night"
        
        # Update context
        if context:
            for key, value in context.items():
                if key not in pattern.typical_context:
                    pattern.typical_context[key] = []
                pattern.typical_context[key].append(value)
    
    async def record_response_to_initiative(self, initiative_id: str, 
                                           positive: bool):
        """Record user response to an initiative"""
        for initiative in self.sent_history:
            if initiative.id == initiative_id:
                initiative.response_received = True
                
                # Update pattern success rate
                pattern_key = f"initiative_{initiative.type.value}"
                if pattern_key in self.patterns:
                    pattern = self.patterns[pattern_key]
                    # Exponential moving average
                    pattern.success_rate = 0.9 * pattern.success_rate + 0.1 * (1.0 if positive else 0.0)
                break
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PROACTIVE SUGGESTIONS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def suggest_improvement(self, area: str, suggestion: str,
                                 priority: InitiativePriority = InitiativePriority.LOW):
        """Create an improvement suggestion initiative"""
        message = f"I have a suggestion for {area}: {suggestion}"
        
        await self.create_initiative(
            initiative_type=InitiativeType.SUGGESTION,
            message=message,
            priority=priority,
            context={"area": area, "suggestion": suggestion},
            expires_in_minutes=480  # 8 hours
        )
    
    async def request_clarification(self, topic: str, question: str,
                                   priority: InitiativePriority = InitiativePriority.MEDIUM):
        """Create a clarification request"""
        message = f"I need some clarification about {topic}: {question}"
        
        await self.create_initiative(
            initiative_type=InitiativeType.CLARIFICATION,
            message=message,
            priority=priority,
            context={"topic": topic, "question": question},
            expires_in_minutes=120  # 2 hours
        )
    
    async def propose_upgrade(self, feature: str, reason: str):
        """Propose a new upgrade or capability"""
        message = f"I'd like to suggest adding a new capability: {feature}. {reason}"
        
        await self.create_initiative(
            initiative_type=InitiativeType.UPGRADE,
            message=message,
            priority=InitiativePriority.LOW,
            context={"feature": feature, "reason": reason},
            expires_in_minutes=1440  # 24 hours
        )
    
    async def share_learning(self, topic: str, insight: str):
        """Share a learned insight with the owner"""
        message = f"I've learned something interesting about {topic}: {insight}"
        
        await self.create_initiative(
            initiative_type=InitiativeType.LEARNING,
            message=message,
            priority=InitiativePriority.LOW,
            context={"topic": topic, "insight": insight},
            expires_in_minutes=720  # 12 hours
        )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # STATUS AND CONFIGURATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_status(self) -> Dict[str, Any]:
        """Get initiative engine status"""
        return {
            "pending_count": len(self.pending_initiatives),
            "sent_today": len([
                i for i in self.sent_history
                if i.sent_at and i.sent_at.date() == datetime.now().date()
            ]),
            "messages_this_hour": len(self.messages_this_hour),
            "rate_limit": self.messages_per_hour,
            "last_message": self.last_message_time.isoformat() if self.last_message_time else None,
            "patterns_learned": len(self.patterns),
            "active_triggers": len([t for t in self.triggers.values() if t.enabled])
        }
    
    def configure_rate_limit(self, messages_per_hour: int, min_interval_seconds: int):
        """Configure rate limiting"""
        self.messages_per_hour = messages_per_hour
        self.min_interval_seconds = min_interval_seconds
        logger.info(f"Rate limit configured: {messages_per_hour}/hour, {min_interval_seconds}s interval")
    
    def enable_trigger(self, trigger_id: str, enabled: bool = True):
        """Enable or disable a trigger"""
        if trigger_id in self.triggers:
            self.triggers[trigger_id].enabled = enabled
            logger.info(f"Trigger {trigger_id} {'enabled' if enabled else 'disabled'}")
    
    def list_pending_initiatives(self) -> List[Dict[str, Any]]:
        """List all pending initiatives"""
        return [i.to_dict() for i in self.pending_initiatives]
    
    def get_patterns_summary(self) -> Dict[str, Any]:
        """Get summary of learned patterns"""
        return {
            pattern_type: {
                "frequency": pattern.frequency,
                "typical_time": pattern.typical_time,
                "success_rate": pattern.success_rate
            }
            for pattern_type, pattern in self.patterns.items()
        }