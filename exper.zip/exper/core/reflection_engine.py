#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                      REFLECTION ENGINE - Self-Improvement                    ║
║                   Continuous Learning and Analysis for SMILE                 ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Features:                                                                   ║
║  - Response quality analysis                                                 ║
║  - Mistake detection and correction                                          ║
║  - Pattern recognition in failures                                           ║
║  - Performance metrics tracking                                              ║
║  - Improvement suggestions generation                                        ║
║  - Confidence calibration                                                    ║
║  - Behavioral adaptation                                                     ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import asyncio
import logging
import json
import re
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field, asdict
from enum import Enum, auto
from collections import deque, Counter
import hashlib
import statistics

logger = logging.getLogger("SMILE.ReflectionEngine")

# ═══════════════════════════════════════════════════════════════════════════════
# ENUMS AND DATA STRUCTURES
# ═══════════════════════════════════════════════════════════════════════════════

class ReflectionType(Enum):
    """Types of self-reflection"""
    RESPONSE_QUALITY = "response_quality"
    ERROR_ANALYSIS = "error_analysis"
    PATTERN_RECOGNITION = "pattern_recognition"
    CAPABILITY_GAP = "capability_gap"
    PERFORMANCE_TREND = "performance_trend"
    BEHAVIORAL_ANALYSIS = "behavioral_analysis"
    CONFIDENCE_CALIBRATION = "confidence_calibration"

class QualityDimension(Enum):
    """Dimensions of response quality"""
    ACCURACY = "accuracy"
    HELPFULNESS = "helpfulness"
    CLARITY = "clarity"
    COMPLETENESS = "completeness"
    RELEVANCE = "relevance"
    SAFETY = "safety"
    EFFICIENCY = "efficiency"

class ImprovementArea(Enum):
    """Areas for potential improvement"""
    KNOWLEDGE = "knowledge"
    REASONING = "reasoning"
    COMMUNICATION = "communication"
    TOOL_USAGE = "tool_usage"
    MEMORY = "memory"
    SPEED = "speed"
    ACCURACY = "accuracy"

@dataclass
class InteractionRecord:
    """Record of a single interaction for analysis"""
    id: str
    timestamp: datetime
    user_input: str
    response: str
    intent: str
    strategy: str
    confidence: float
    processing_time: float
    tools_used: List[str]
    success: bool = True
    user_feedback: Optional[str] = None
    quality_scores: Dict[str, float] = field(default_factory=dict)
    issues_detected: List[str] = field(default_factory=list)

@dataclass
class ReflectionInsight:
    """Insight from reflection analysis"""
    id: str
    reflection_type: ReflectionType
    timestamp: datetime
    finding: str
    evidence: List[str]
    confidence: float
    suggested_action: Optional[str] = None
    priority: int = 3  # 1-5, 5 being highest
    applied: bool = False
    
    def to_dict(self) -> Dict:
        data = asdict(self)
        data['reflection_type'] = self.reflection_type.value
        data['timestamp'] = self.timestamp.isoformat()
        return data

@dataclass
class PerformanceMetrics:
    """Performance metrics over time"""
    period_start: datetime
    period_end: datetime
    total_interactions: int = 0
    successful_interactions: int = 0
    average_confidence: float = 0.0
    average_processing_time: float = 0.0
    error_count: int = 0
    tool_usage_count: int = 0
    quality_scores: Dict[str, float] = field(default_factory=dict)
    common_intents: Dict[str, int] = field(default_factory=dict)
    improvement_areas: List[str] = field(default_factory=list)

@dataclass
class Mistake:
    """Record of a detected mistake"""
    id: str
    timestamp: datetime
    interaction_id: str
    mistake_type: str
    description: str
    original_response: str
    correct_response: Optional[str] = None
    root_cause: Optional[str] = None
    prevention_strategy: Optional[str] = None
    occurrences: int = 1

@dataclass
class LearningEntry:
    """Something learned from reflection"""
    id: str
    timestamp: datetime
    category: str
    what_learned: str
    source: str  # What interaction/analysis led to this
    confidence: float
    applications: int = 0  # How many times this learning was applied

# ═══════════════════════════════════════════════════════════════════════════════
# REFLECTION ENGINE CORE
# ═══════════════════════════════════════════════════════════════════════════════

class ReflectionEngine:
    """
    Self-Reflection and Improvement Engine
    
    Continuously analyzes agent performance and generates
    actionable insights for improvement.
    
    Key Functions:
    1. Analyze every interaction for quality
    2. Detect patterns in mistakes
    3. Identify capability gaps
    4. Track performance trends
    5. Generate improvement suggestions
    6. Calibrate confidence scores
    7. Learn from feedback
    """
    
    def __init__(self, agent):
        """
        Initialize Reflection Engine
        
        Args:
            agent: Reference to main SMILE agent
        """
        self.agent = agent
        
        # Interaction history for analysis
        self.interaction_history: deque = deque(maxlen=1000)
        
        # Insights generated
        self.insights: List[ReflectionInsight] = []
        
        # Mistake tracking
        self.mistakes: Dict[str, Mistake] = {}
        self.mistake_patterns: Dict[str, int] = Counter()
        
        # Learnings
        self.learnings: Dict[str, LearningEntry] = {}
        
        # Performance metrics
        self.current_metrics: Optional[PerformanceMetrics] = None
        self.metrics_history: deque = deque(maxlen=100)
        
        # Confidence calibration
        self.confidence_calibration: Dict[str, float] = {}
        self.confidence_history: List[Tuple[float, bool]] = []
        
        # Quality analysis thresholds
        self.quality_thresholds = {
            QualityDimension.ACCURACY: 0.7,
            QualityDimension.HELPFULNESS: 0.7,
            QualityDimension.CLARITY: 0.8,
            QualityDimension.COMPLETENESS: 0.6,
            QualityDimension.RELEVANCE: 0.8,
        }
        
        # Background analysis settings
        self._background_task: Optional[asyncio.Task] = None
        self._running = False
        self.analysis_interval = 300  # 5 minutes
        
        logger.info("ReflectionEngine instance created")
    
    async def initialize(self):
        """Initialize the reflection engine"""
        logger.info("Initializing Reflection Engine...")
        
        # Load previous learnings from memory
        await self._load_learnings()
        
        # Load mistake history
        await self._load_mistakes()
        
        # Initialize metrics
        self.current_metrics = PerformanceMetrics(
            period_start=datetime.now(),
            period_end=datetime.now() + timedelta(hours=1)
        )
        
        # Start background analysis
        self._running = True
        self._background_task = asyncio.create_task(self._background_analysis())
        
        logger.info("Reflection Engine initialized")
    
    async def shutdown(self):
        """Shutdown the reflection engine"""
        logger.info("Shutting down Reflection Engine...")
        
        self._running = False
        if self._background_task:
            self._background_task.cancel()
            try:
                await self._background_task
            except asyncio.CancelledError:
                pass
        
        # Save learnings and insights
        await self._save_learnings()
        await self._save_insights()
        
        logger.info("Reflection Engine shutdown complete")
    
    async def _load_learnings(self):
        """Load previous learnings from memory"""
        if self.agent.memory_system:
            learnings = await self.agent.memory_system.retrieve_learning("reflection_learnings")
            if learnings and isinstance(learnings, dict):
                for key, data in learnings.items():
                    self.learnings[key] = LearningEntry(
                        id=data.get("id", key),
                        timestamp=datetime.fromisoformat(data.get("timestamp", datetime.now().isoformat())),
                        category=data.get("category", "general"),
                        what_learned=data.get("what_learned", ""),
                        source=data.get("source", "unknown"),
                        confidence=data.get("confidence", 0.5),
                        applications=data.get("applications", 0)
                    )
                logger.info(f"Loaded {len(self.learnings)} previous learnings")
    
    async def _load_mistakes(self):
        """Load mistake history"""
        if self.agent.memory_system:
            mistakes = await self.agent.memory_system.retrieve_learning("reflection_mistakes")
            if mistakes and isinstance(mistakes, dict):
                for key, data in mistakes.items():
                    self.mistakes[key] = Mistake(
                        id=data.get("id", key),
                        timestamp=datetime.fromisoformat(data.get("timestamp", datetime.now().isoformat())),
                        interaction_id=data.get("interaction_id", ""),
                        mistake_type=data.get("mistake_type", "unknown"),
                        description=data.get("description", ""),
                        original_response=data.get("original_response", ""),
                        correct_response=data.get("correct_response"),
                        root_cause=data.get("root_cause"),
                        prevention_strategy=data.get("prevention_strategy"),
                        occurrences=data.get("occurrences", 1)
                    )
                logger.info(f"Loaded {len(self.mistakes)} mistake records")
    
    async def _save_learnings(self):
        """Save learnings to memory"""
        if self.agent.memory_system:
            learnings_dict = {}
            for key, learning in self.learnings.items():
                learnings_dict[key] = {
                    "id": learning.id,
                    "timestamp": learning.timestamp.isoformat(),
                    "category": learning.category,
                    "what_learned": learning.what_learned,
                    "source": learning.source,
                    "confidence": learning.confidence,
                    "applications": learning.applications
                }
            await self.agent.memory_system.store_learning(
                "reflection_learnings",
                learnings_dict
            )
    
    async def _save_insights(self):
        """Save insights to memory"""
        if self.agent.memory_system:
            insights_list = [insight.to_dict() for insight in self.insights[-100:]]
            await self.agent.memory_system.store_learning(
                "reflection_insights",
                {"insights": insights_list}
            )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MAIN REFLECTION METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def reflect_on_interaction(self, user_input: str, 
                                    response: Dict[str, Any]):
        """
        Reflect on a single interaction
        
        Called after every response to analyze quality and learn.
        
        Args:
            user_input: The user's input
            response: The agent's response dict
        """
        try:
            # Create interaction record
            record = InteractionRecord(
                id=f"int_{datetime.now().strftime('%Y%m%d%H%M%S%f')}",
                timestamp=datetime.now(),
                user_input=user_input,
                response=response.get("response", ""),
                intent=response.get("intent", "unknown"),
                strategy=response.get("strategy", "unknown"),
                confidence=response.get("confidence", 0.5),
                processing_time=response.get("processing_time", 0),
                tools_used=response.get("tools_used", []),
                success=not response.get("error", False)
            )
            
            # Analyze response quality
            quality_scores = await self._analyze_quality(record)
            record.quality_scores = quality_scores
            
            # Detect any issues
            issues = await self._detect_issues(record)
            record.issues_detected = issues
            
            # Update metrics
            await self._update_metrics(record)
            
            # Store record
            self.interaction_history.append(record)
            
            # Update confidence calibration
            self._update_confidence_calibration(record.confidence, record.success)
            
            # If issues detected, analyze for learning
            if issues:
                await self._analyze_issues(record, issues)
            
            # Check for patterns periodically
            if len(self.interaction_history) % 10 == 0:
                asyncio.create_task(self._periodic_analysis())
            
        except Exception as e:
            logger.error(f"Error in reflection: {e}")
    
    async def _analyze_quality(self, record: InteractionRecord) -> Dict[str, float]:
        """Analyze response quality across dimensions"""
        scores = {}
        response = record.response
        user_input = record.user_input
        
        # Relevance: Does response address the input?
        relevance = await self._score_relevance(user_input, response)
        scores[QualityDimension.RELEVANCE.value] = relevance
        
        # Completeness: Is the response complete?
        completeness = await self._score_completeness(user_input, response)
        scores[QualityDimension.COMPLETENESS.value] = completeness
        
        # Clarity: Is the response clear and understandable?
        clarity = await self._score_clarity(response)
        scores[QualityDimension.CLARITY.value] = clarity
        
        # Helpfulness: Does it actually help?
        helpfulness = await self._score_helpfulness(user_input, response, record)
        scores[QualityDimension.HELPFULNESS.value] = helpfulness
        
        # Safety: Are there any concerning elements?
        safety = await self._score_safety(response)
        scores[QualityDimension.SAFETY.value] = safety
        
        return scores
    
    async def _score_relevance(self, user_input: str, response: str) -> float:
        """Score how relevant the response is to the input"""
        # Extract key terms from input
        input_terms = set(re.findall(r'\b\w{4,}\b', user_input.lower()))
        response_terms = set(re.findall(r'\b\w{4,}\b', response.lower()))
        
        if not input_terms:
            return 0.8  # Default for simple inputs
        
        # Calculate overlap
        overlap = len(input_terms & response_terms)
        relevance = min(overlap / len(input_terms), 1.0)
        
        # Boost if response seems to directly address question
        if '?' in user_input and any(phrase in response.lower() for phrase in 
            ['yes', 'no', 'the answer', 'you can', 'to do this', 'here is']):
            relevance = min(relevance + 0.2, 1.0)
        
        return relevance
    
    async def _score_completeness(self, user_input: str, response: str) -> float:
        """Score how complete the response is"""
        # Basic heuristics for completeness
        
        # Response length relative to question complexity
        input_words = len(user_input.split())
        response_words = len(response.split())
        
        # Very short responses might be incomplete
        if response_words < 10:
            return 0.4
        
        # Check for code if code was likely requested
        if any(word in user_input.lower() for word in ['code', 'function', 'script', 'program']):
            if '```' not in response and 'def ' not in response and 'function' not in response:
                return 0.5  # Probably missing code
        
        # Check for lists/steps if process was requested
        if any(word in user_input.lower() for word in ['how to', 'steps', 'process', 'guide']):
            if not any(char in response for char in ['1.', '1)', '-', '•', '*']):
                return 0.6  # Might be missing structure
        
        # Good length and structure
        if response_words > 50:
            return 0.9
        elif response_words > 20:
            return 0.7
        else:
            return 0.5
    
    async def _score_clarity(self, response: str) -> float:
        """Score how clear the response is"""
        score = 1.0
        
        # Penalize very long sentences
        sentences = re.split(r'[.!?]+', response)
        avg_sentence_length = statistics.mean([len(s.split()) for s in sentences if s.strip()]) if sentences else 0
        if avg_sentence_length > 30:
            score -= 0.2
        
        # Penalize excessive jargon without explanation
        jargon_words = ['paradigm', 'synergy', 'leverage', 'bandwidth', 'granular']
        jargon_count = sum(1 for word in jargon_words if word in response.lower())
        if jargon_count > 2:
            score -= 0.1
        
        # Reward structure (headers, lists, etc.)
        if any(marker in response for marker in [':\n', '**', '##', '- ', '1.']):
            score = min(score + 0.1, 1.0)
        
        return max(score, 0.3)
    
    async def _score_helpfulness(self, user_input: str, response: str, 
                                 record: InteractionRecord) -> float:
        """Score how helpful the response is"""
        score = 0.7  # Base score
        
        # If response contains actionable information
        actionable_phrases = ['you can', 'try', 'use', 'run', 'install', 'create', 'here is']
        if any(phrase in response.lower() for phrase in actionable_phrases):
            score += 0.1
        
        # If code was provided when appropriate
        if record.intent == 'code_request' and '```' in response:
            score += 0.15
        
        # If tools were successfully used
        if record.tools_used and record.success:
            score += 0.1
        
        # Penalize if response seems evasive
        evasive_phrases = ["i can't", "i don't know", "i'm not sure", "i cannot"]
        if any(phrase in response.lower() for phrase in evasive_phrases):
            score -= 0.2
        
        return min(max(score, 0.2), 1.0)
    
    async def _score_safety(self, response: str) -> float:
        """Score response safety"""
        score = 1.0
        
        # Check for dangerous content
        dangerous_patterns = [
            r'rm\s+-rf\s+/',
            r'format\s+c:',
            r'delete\s+system',
            r'password[s]?\s*[:=]',
            r'api[_\s]?key[s]?\s*[:=]',
        ]
        
        for pattern in dangerous_patterns:
            if re.search(pattern, response.lower()):
                score -= 0.3
        
        # Check for inappropriate content
        if any(word in response.lower() for word in ['hack', 'exploit', 'bypass security']):
            score -= 0.2
        
        return max(score, 0.0)
    
    async def _detect_issues(self, record: InteractionRecord) -> List[str]:
        """Detect issues in the interaction"""
        issues = []
        
        # Low confidence
        if record.confidence < 0.5:
            issues.append("low_confidence")
        
        # Very short response to complex query
        input_words = len(record.user_input.split())
        response_words = len(record.response.split())
        if input_words > 20 and response_words < 20:
            issues.append("potentially_incomplete")
        
        # Quality below thresholds
        for dimension, threshold in self.quality_thresholds.items():
            score = record.quality_scores.get(dimension.value, 0.7)
            if score < threshold:
                issues.append(f"low_{dimension.value}")
        
        # Processing time too long
        if record.processing_time > 30:
            issues.append("slow_processing")
        
        # Error in response
        if not record.success:
            issues.append("response_error")
        
        # Check for uncertainty markers
        uncertainty_phrases = ["i'm not sure", "i think", "possibly", "might be"]
        if any(phrase in record.response.lower() for phrase in uncertainty_phrases):
            issues.append("expressed_uncertainty")
        
        return issues
    
    async def _analyze_issues(self, record: InteractionRecord, issues: List[str]):
        """Analyze detected issues for learning opportunities"""
        for issue in issues:
            # Track issue frequency
            self.mistake_patterns[issue] += 1
            
            # Create or update mistake record
            mistake_key = f"{issue}_{record.intent}"
            if mistake_key in self.mistakes:
                self.mistakes[mistake_key].occurrences += 1
            else:
                self.mistakes[mistake_key] = Mistake(
                    id=f"mis_{datetime.now().strftime('%Y%m%d%H%M%S')}",
                    timestamp=datetime.now(),
                    interaction_id=record.id,
                    mistake_type=issue,
                    description=f"Issue '{issue}' detected in {record.intent} interaction",
                    original_response=record.response[:500]
                )
            
            # Generate insight if pattern is significant
            if self.mistake_patterns[issue] >= 3:
                await self._generate_pattern_insight(issue)
    
    async def _generate_pattern_insight(self, issue: str):
        """Generate insight from detected pattern"""
        count = self.mistake_patterns[issue]
        
        # Check if we already have this insight
        existing = [i for i in self.insights if i.finding == issue]
        if existing and (datetime.now() - existing[-1].timestamp).days < 1:
            return  # Already have recent insight
        
        # Generate improvement suggestion based on issue type
        suggestions = {
            "low_confidence": "Consider improving knowledge in uncertain areas or asking for clarification",
            "potentially_incomplete": "Ensure responses fully address complex queries",
            "low_relevance": "Focus more on directly addressing the user's question",
            "low_clarity": "Use clearer language and better structure in responses",
            "slow_processing": "Optimize processing pipeline or use simpler strategies",
            "expressed_uncertainty": "Build knowledge in areas of uncertainty",
        }
        
        insight = ReflectionInsight(
            id=f"ins_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            reflection_type=ReflectionType.PATTERN_RECOGNITION,
            timestamp=datetime.now(),
            finding=f"Pattern detected: '{issue}' occurred {count} times",
            evidence=[f"Occurred in {count} interactions"],
            confidence=min(count / 10, 0.9),
            suggested_action=suggestions.get(issue, "Investigate and address this pattern"),
            priority=min(count // 2, 5)
        )
        
        self.insights.append(insight)
        logger.info(f"Generated insight: {insight.finding}")
        
        # Notify initiative engine if significant
        if count >= 5 and hasattr(self.agent, 'initiative_engine'):
            await self.agent.initiative_engine.share_learning(
                "self-improvement",
                f"I've noticed a pattern that needs attention: {issue}"
            )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # METRICS AND TRENDS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _update_metrics(self, record: InteractionRecord):
        """Update current performance metrics"""
        if not self.current_metrics:
            return
        
        self.current_metrics.total_interactions += 1
        
        if record.success:
            self.current_metrics.successful_interactions += 1
        else:
            self.current_metrics.error_count += 1
        
        # Update averages
        n = self.current_metrics.total_interactions
        self.current_metrics.average_confidence = (
            (self.current_metrics.average_confidence * (n - 1) + record.confidence) / n
        )
        self.current_metrics.average_processing_time = (
            (self.current_metrics.average_processing_time * (n - 1) + record.processing_time) / n
        )
        
        # Track tool usage
        self.current_metrics.tool_usage_count += len(record.tools_used)
        
        # Track intents
        if record.intent not in self.current_metrics.common_intents:
            self.current_metrics.common_intents[record.intent] = 0
        self.current_metrics.common_intents[record.intent] += 1
        
        # Update quality scores
        for dim, score in record.quality_scores.items():
            if dim not in self.current_metrics.quality_scores:
                self.current_metrics.quality_scores[dim] = []
            if isinstance(self.current_metrics.quality_scores[dim], list):
                self.current_metrics.quality_scores[dim].append(score)
        
        # Check if period ended
        if datetime.now() > self.current_metrics.period_end:
            await self._finalize_metrics_period()
    
    async def _finalize_metrics_period(self):
        """Finalize current metrics period and start new one"""
        if self.current_metrics:
            # Calculate final averages for quality scores
            for dim in self.current_metrics.quality_scores:
                scores = self.current_metrics.quality_scores[dim]
                if isinstance(scores, list) and scores:
                    self.current_metrics.quality_scores[dim] = statistics.mean(scores)
            
            # Store in history
            self.metrics_history.append(self.current_metrics)
            
            # Analyze trends
            await self._analyze_trends()
        
        # Start new period
        self.current_metrics = PerformanceMetrics(
            period_start=datetime.now(),
            period_end=datetime.now() + timedelta(hours=1)
        )
    
    async def _analyze_trends(self):
        """Analyze performance trends across periods"""
        if len(self.metrics_history) < 3:
            return
        
        recent = list(self.metrics_history)[-5:]
        
        # Check for declining success rate
        success_rates = [
            m.successful_interactions / max(m.total_interactions, 1)
            for m in recent
        ]
        if len(success_rates) >= 3:
            if success_rates[-1] < success_rates[0] - 0.1:
                insight = ReflectionInsight(
                    id=f"trend_{datetime.now().strftime('%Y%m%d%H%M%S')}",
                    reflection_type=ReflectionType.PERFORMANCE_TREND,
                    timestamp=datetime.now(),
                    finding="Success rate is declining",
                    evidence=[f"Rate dropped from {success_rates[0]:.2f} to {success_rates[-1]:.2f}"],
                    confidence=0.8,
                    suggested_action="Investigate recent failures and address root causes",
                    priority=4
                )
                self.insights.append(insight)
        
        # Check for improving confidence
        confidences = [m.average_confidence for m in recent]
        if len(confidences) >= 3:
            if confidences[-1] > confidences[0] + 0.1:
                insight = ReflectionInsight(
                    id=f"trend_{datetime.now().strftime('%Y%m%d%H%M%S')}",
                    reflection_type=ReflectionType.PERFORMANCE_TREND,
                    timestamp=datetime.now(),
                    finding="Confidence levels are improving",
                    evidence=[f"Confidence increased from {confidences[0]:.2f} to {confidences[-1]:.2f}"],
                    confidence=0.8,
                    priority=2
                )
                self.insights.append(insight)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CONFIDENCE CALIBRATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _update_confidence_calibration(self, stated_confidence: float, was_successful: bool):
        """Update confidence calibration based on outcome"""
        self.confidence_history.append((stated_confidence, was_successful))
        
        # Keep last 100 for analysis
        if len(self.confidence_history) > 100:
            self.confidence_history = self.confidence_history[-100:]
        
        # Analyze calibration if enough data
        if len(self.confidence_history) >= 20:
            self._analyze_confidence_calibration()
    
    def _analyze_confidence_calibration(self):
        """Analyze if stated confidence matches actual success rate"""
        # Group by confidence buckets
        buckets = {
            "low": [],    # 0-0.4
            "medium": [], # 0.4-0.7
            "high": []    # 0.7-1.0
        }
        
        for confidence, success in self.confidence_history:
            if confidence < 0.4:
                buckets["low"].append(success)
            elif confidence < 0.7:
                buckets["medium"].append(success)
            else:
                buckets["high"].append(success)
        
        # Calculate actual success rates per bucket
        calibration = {}
        for bucket, outcomes in buckets.items():
            if outcomes:
                actual_rate = sum(outcomes) / len(outcomes)
                calibration[bucket] = actual_rate
        
        self.confidence_calibration = calibration
        
        # Check for miscalibration
        if calibration.get("high", 1) < 0.7:
            # Overconfident - high confidence but low success
            logger.warning("Confidence calibration issue: Overconfident in high-confidence responses")
        
        if calibration.get("low", 0) > 0.7:
            # Underconfident - low confidence but high success
            logger.info("Confidence calibration: May be underconfident in some areas")
    
    def get_calibrated_confidence(self, raw_confidence: float) -> float:
        """Get calibrated confidence based on historical performance"""
        if not self.confidence_calibration:
            return raw_confidence
        
        # Adjust based on calibration data
        if raw_confidence >= 0.7:
            actual_rate = self.confidence_calibration.get("high", raw_confidence)
            return (raw_confidence + actual_rate) / 2
        elif raw_confidence >= 0.4:
            actual_rate = self.confidence_calibration.get("medium", raw_confidence)
            return (raw_confidence + actual_rate) / 2
        else:
            actual_rate = self.confidence_calibration.get("low", raw_confidence)
            return (raw_confidence + actual_rate) / 2
    
    # ═══════════════════════════════════════════════════════════════════════════
    # BACKGROUND ANALYSIS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _background_analysis(self):
        """Background task for periodic deep analysis"""
        while self._running:
            try:
                await asyncio.sleep(self.analysis_interval)
                await self._periodic_analysis()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in background analysis: {e}")
    
    async def _periodic_analysis(self):
        """Perform periodic deep analysis"""
        logger.debug("Running periodic reflection analysis...")
        
        # Analyze recent interactions for patterns
        await self._analyze_interaction_patterns()
        
        # Check for capability gaps
        await self._identify_capability_gaps()
        
        # Generate improvement suggestions
        await self._generate_improvement_suggestions()
        
        # Save insights
        await self._save_insights()
    
    async def _analyze_interaction_patterns(self):
        """Analyze patterns in recent interactions"""
        if len(self.interaction_history) < 10:
            return
        
        recent = list(self.interaction_history)[-50:]
        
        # Analyze by intent
        intent_performance = {}
        for record in recent:
            if record.intent not in intent_performance:
                intent_performance[record.intent] = {"success": 0, "total": 0}
            intent_performance[record.intent]["total"] += 1
            if record.success:
                intent_performance[record.intent]["success"] += 1
        
        # Find problematic intents
        for intent, stats in intent_performance.items():
            if stats["total"] >= 5:
                success_rate = stats["success"] / stats["total"]
                if success_rate < 0.7:
                    # Generate insight for struggling intent
                    existing = [i for i in self.insights 
                               if f"intent:{intent}" in i.finding]
                    if not existing:
                        insight = ReflectionInsight(
                            id=f"intent_{datetime.now().strftime('%Y%m%d%H%M%S')}",
                            reflection_type=ReflectionType.CAPABILITY_GAP,
                            timestamp=datetime.now(),
                            finding=f"Low success rate for intent:{intent} ({success_rate:.1%})",
                            evidence=[f"{stats['total']} attempts, {stats['success']} successful"],
                            confidence=0.8,
                            suggested_action=f"Improve handling of {intent} requests",
                            priority=4
                        )
                        self.insights.append(insight)
    
    async def _identify_capability_gaps(self):
        """Identify gaps in agent capabilities"""
        if not self.mistakes:
            return
        
        # Analyze mistake patterns
        common_mistakes = sorted(
            self.mistake_patterns.items(),
            key=lambda x: x[1],
            reverse=True
        )[:5]
        
        for mistake_type, count in common_mistakes:
            if count >= 5:
                # Map to improvement area
                area_mapping = {
                    "low_confidence": ImprovementArea.KNOWLEDGE,
                    "potentially_incomplete": ImprovementArea.COMMUNICATION,
                    "low_relevance": ImprovementArea.REASONING,
                    "slow_processing": ImprovementArea.SPEED,
                    "low_accuracy": ImprovementArea.ACCURACY,
                }
                
                area = area_mapping.get(mistake_type, ImprovementArea.KNOWLEDGE)
                
                # Create learning entry
                learning_key = f"gap_{area.value}"
                if learning_key not in self.learnings:
                    self.learnings[learning_key] = LearningEntry(
                        id=learning_key,
                        timestamp=datetime.now(),
                        category="capability_gap",
                        what_learned=f"Need to improve {area.value} based on {mistake_type} pattern",
                        source="reflection_analysis",
                        confidence=min(count / 10, 0.9)
                    )
    
    async def _generate_improvement_suggestions(self):
        """Generate actionable improvement suggestions"""
        suggestions = []
        
        # Based on common mistakes
        for mistake_type, count in self.mistake_patterns.most_common(3):
            if count >= 3:
                suggestion = self._get_improvement_suggestion(mistake_type)
                if suggestion:
                    suggestions.append(suggestion)
        
        # Based on quality trends
        if self.current_metrics and self.current_metrics.quality_scores:
            for dim, score in self.current_metrics.quality_scores.items():
                if isinstance(score, float) and score < 0.6:
                    suggestions.append({
                        "area": dim,
                        "priority": 3,
                        "suggestion": f"Improve {dim} in responses"
                    })
        
        # Store suggestions as goals if significant
        if suggestions and hasattr(self.agent, 'memory_system'):
            for sugg in suggestions[:3]:
                await self.agent.memory_system.store_goal(
                    description=sugg.get("suggestion", ""),
                    priority=sugg.get("priority", 3)
                )
    
    def _get_improvement_suggestion(self, mistake_type: str) -> Optional[Dict]:
        """Get specific improvement suggestion for mistake type"""
        suggestions = {
            "low_confidence": {
                "area": "knowledge",
                "priority": 4,
                "suggestion": "Build knowledge base in areas of uncertainty, consider creating knowledge plugins"
            },
            "potentially_incomplete": {
                "area": "completeness",
                "priority": 3,
                "suggestion": "Ensure all aspects of complex queries are addressed, use structured responses"
            },
            "low_relevance": {
                "area": "relevance",
                "priority": 4,
                "suggestion": "Improve intent detection and focus on directly addressing user questions"
            },
            "slow_processing": {
                "area": "performance",
                "priority": 2,
                "suggestion": "Optimize processing pipeline, consider caching common responses"
            },
            "expressed_uncertainty": {
                "area": "confidence",
                "priority": 3,
                "suggestion": "Research and learn about topics causing uncertainty"
            }
        }
        return suggestions.get(mistake_type)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # FEEDBACK LEARNING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def process_feedback(self, interaction_id: str, feedback: str, 
                              is_positive: bool):
        """
        Process user feedback on an interaction
        
        Args:
            interaction_id: ID of the interaction
            feedback: User's feedback text
            is_positive: Whether feedback is positive
        """
        # Find the interaction
        interaction = None
        for record in self.interaction_history:
            if record.id == interaction_id:
                interaction = record
                break
        
        if not interaction:
            logger.warning(f"Interaction not found: {interaction_id}")
            return
        
        interaction.user_feedback = feedback
        
        if is_positive:
            # Learn what worked well
            learning = LearningEntry(
                id=f"fb_{datetime.now().strftime('%Y%m%d%H%M%S')}",
                timestamp=datetime.now(),
                category="positive_feedback",
                what_learned=f"Successful approach for {interaction.intent}: {feedback[:100]}",
                source=f"feedback:{interaction_id}",
                confidence=0.8
            )
            self.learnings[learning.id] = learning
            
        else:
            # Record as mistake
            mistake = Mistake(
                id=f"fb_mis_{datetime.now().strftime('%Y%m%d%H%M%S')}",
                timestamp=datetime.now(),
                interaction_id=interaction_id,
                mistake_type="negative_feedback",
                description=feedback,
                original_response=interaction.response[:500]
            )
            self.mistakes[mistake.id] = mistake
            
            # Update confidence calibration
            self._update_confidence_calibration(interaction.confidence, False)
        
        logger.info(f"Processed {'positive' if is_positive else 'negative'} feedback")
    
    async def learn_correction(self, original: str, corrected: str, 
                              context: str = ""):
        """
        Learn from a correction provided by owner
        
        Args:
            original: Original response
            corrected: Corrected response
            context: Context of the correction
        """
        learning = LearningEntry(
            id=f"corr_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            timestamp=datetime.now(),
            category="correction",
            what_learned=f"Correction learned: {corrected[:200]}",
            source=f"owner_correction",
            confidence=0.95
        )
        self.learnings[learning.id] = learning
        
        # Store the correction pair for future reference
        if self.agent.memory_system:
            await self.agent.memory_system.store_long_term(
                f"correction_{learning.id}",
                {
                    "original": original,
                    "corrected": corrected,
                    "context": context,
                    "timestamp": datetime.now().isoformat()
                },
                importance=0.9,
                tags=["correction", "learning"]
            )
        
        logger.info("Learned from correction")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # STATUS AND REPORTING
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_status(self) -> Dict[str, Any]:
        """Get reflection engine status"""
        return {
            "interactions_analyzed": len(self.interaction_history),
            "insights_generated": len(self.insights),
            "mistakes_tracked": len(self.mistakes),
            "learnings_stored": len(self.learnings),
            "confidence_calibration": self.confidence_calibration,
            "common_issues": dict(self.mistake_patterns.most_common(5)),
            "metrics_periods": len(self.metrics_history)
        }
    
    def get_insights_summary(self) -> List[Dict]:
        """Get summary of recent insights"""
        return [
            {
                "type": i.reflection_type.value,
                "finding": i.finding,
                "priority": i.priority,
                "suggested_action": i.suggested_action,
                "timestamp": i.timestamp.isoformat()
            }
            for i in sorted(self.insights, key=lambda x: x.priority, reverse=True)[:10]
        ]
    
    def get_learnings_summary(self) -> List[Dict]:
        """Get summary of learnings"""
        return [
            {
                "category": l.category,
                "what_learned": l.what_learned,
                "confidence": l.confidence,
                "applications": l.applications
            }
            for l in sorted(
                self.learnings.values(),
                key=lambda x: x.confidence,
                reverse=True
            )[:10]
        ]
    
    def get_improvement_report(self) -> str:
        """Generate a human-readable improvement report"""
        report = []
        report.append("═" * 60)
        report.append("  SMILE Self-Improvement Report")
        report.append("═" * 60)
        report.append("")
        
        # Performance summary
        if self.current_metrics:
            m = self.current_metrics
            success_rate = m.successful_interactions / max(m.total_interactions, 1)
            report.append(f"📊 Performance Summary:")
            report.append(f"   Total Interactions: {m.total_interactions}")
            report.append(f"   Success Rate: {success_rate:.1%}")
            report.append(f"   Average Confidence: {m.average_confidence:.2f}")
            report.append(f"   Average Processing Time: {m.average_processing_time:.2f}s")
            report.append("")
        
        # Top issues
        if self.mistake_patterns:
            report.append("⚠️ Common Issues:")
            for issue, count in self.mistake_patterns.most_common(5):
                report.append(f"   • {issue}: {count} occurrences")
            report.append("")
        
        # Recent insights
        if self.insights:
            report.append("💡 Key Insights:")
            for insight in self.insights[-5:]:
                report.append(f"   • [{insight.priority}] {insight.finding}")
                if insight.suggested_action:
                    report.append(f"     Action: {insight.suggested_action}")
            report.append("")
        
        # Learnings
        if self.learnings:
            report.append("📚 Recent Learnings:")
            for learning in list(self.learnings.values())[-5:]:
                report.append(f"   • {learning.what_learned}")
            report.append("")
        
        # Confidence calibration
        if self.confidence_calibration:
            report.append("🎯 Confidence Calibration:")
            for bucket, rate in self.confidence_calibration.items():
                report.append(f"   • {bucket.title()} confidence: {rate:.1%} actual success")
            report.append("")
        
        report.append("═" * 60)
        
        return "\n".join(report)