#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                         ROUTER ENGINE - Fast Task Routing                    ║
║                   Intelligent Request Classification for SMILE              ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Features:                                                                   ║
║  - Fast rule-based routing for simple tasks                                  ║
║  - ML-based classification for complex routing                               ║
║  - Tool matching and selection                                               ║
║  - Load balancing across processing paths                                    ║
║  - Latency optimization                                                      ║
║  - Learning from routing decisions                                           ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import asyncio
import logging
import re
import time
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple, Callable
from dataclasses import dataclass, field
from enum import Enum, auto
from collections import defaultdict
import json

logger = logging.getLogger("SMILE.RouterEngine")

# ═══════════════════════════════════════════════════════════════════════════════
# ENUMS AND DATA STRUCTURES
# ═══════════════════════════════════════════════════════════════════════════════

class RouteType(Enum):
    """Types of processing routes"""
    INSTANT = "instant"              # Immediate response (< 100ms)
    RULE_BASED = "rule_based"        # Pattern matching (< 500ms)
    TOOL_CALL = "tool_call"          # Use specific tool (< 2s)
    MULTI_TOOL = "multi_tool"        # Chain of tools (< 5s)
    THINKING = "thinking"            # Deep reasoning (< 30s)
    EXTERNAL = "external"            # External API call (< 60s)
    HYBRID = "hybrid"                # Combination approach

class TaskCategory(Enum):
    """Categories of tasks"""
    GREETING = "greeting"
    FAREWELL = "farewell"
    GRATITUDE = "gratitude"
    HELP = "help"
    STATUS = "status"
    CALCULATION = "calculation"
    SEARCH = "search"
    CODE = "code"
    FILE = "file"
    ANALYSIS = "analysis"
    CREATIVE = "creative"
    FACTUAL = "factual"
    CONVERSATIONAL = "conversational"
    SYSTEM = "system"
    UNKNOWN = "unknown"

class RoutePriority(Enum):
    """Priority levels for routing"""
    CRITICAL = 1
    HIGH = 2
    NORMAL = 3
    LOW = 4
    BACKGROUND = 5

@dataclass
class Route:
    """Represents a routing decision"""
    route_type: RouteType
    category: TaskCategory
    priority: RoutePriority
    handler: str                     # Handler identifier
    tools: List[str]                 # Tools to use
    confidence: float                # Confidence in routing decision
    estimated_time_ms: int           # Estimated processing time
    parameters: Dict[str, Any] = field(default_factory=dict)
    fallback_route: Optional['Route'] = None
    
    def to_dict(self) -> Dict:
        return {
            "route_type": self.route_type.value,
            "category": self.category.value,
            "priority": self.priority.value,
            "handler": self.handler,
            "tools": self.tools,
            "confidence": self.confidence,
            "estimated_time_ms": self.estimated_time_ms,
            "parameters": self.parameters
        }

@dataclass
class RoutingRule:
    """A rule for pattern-based routing"""
    name: str
    patterns: List[str]              # Regex patterns
    category: TaskCategory
    route_type: RouteType
    handler: str
    tools: List[str]
    priority: int = 100              # Lower = higher priority
    enabled: bool = True
    
    compiled_patterns: List = field(default_factory=list, repr=False)
    
    def __post_init__(self):
        self.compiled_patterns = [
            re.compile(p, re.IGNORECASE) for p in self.patterns
        ]
    
    def matches(self, text: str) -> Tuple[bool, float]:
        """Check if text matches this rule"""
        for pattern in self.compiled_patterns:
            if pattern.search(text):
                # Calculate confidence based on match quality
                match = pattern.search(text)
                match_ratio = len(match.group()) / len(text) if match else 0
                confidence = min(0.5 + match_ratio, 0.95)
                return True, confidence
        return False, 0.0

@dataclass
class RoutingDecision:
    """Complete routing decision with metadata"""
    route: Route
    input_text: str
    decided_at: datetime
    decision_time_ms: float
    rules_checked: int
    matched_rule: Optional[str] = None

# ═══════════════════════════════════════════════════════════════════════════════
# ROUTER ENGINE CORE
# ═══════════════════════════════════════════════════════════════════════════════

class RouterEngine:
    """
    Fast Task Routing Engine
    
    Routes incoming requests to appropriate handlers:
    - Instant responses for greetings/simple queries
    - Tool calls for specific operations
    - Deep thinking for complex analysis
    - External APIs for web searches
    """
    
    def __init__(self, agent):
        """
        Initialize Router Engine
        
        Args:
            agent: Reference to main SMILE agent
        """
        self.agent = agent
        
        # Routing rules (ordered by priority)
        self.rules: List[RoutingRule] = []
        
        # Handler registry
        self.handlers: Dict[str, Callable] = {}
        
        # Tool availability cache
        self.available_tools: Dict[str, bool] = {}
        
        # Routing history for learning
        self.routing_history: List[RoutingDecision] = []
        self.max_history = 1000
        
        # Performance tracking
        self.route_performance: Dict[str, Dict] = defaultdict(lambda: {
            "count": 0,
            "total_time_ms": 0,
            "avg_time_ms": 0,
            "success_rate": 1.0
        })
        
        # Cache for repeated queries
        self.route_cache: Dict[str, Route] = {}
        self.cache_max_size = 500
        self.cache_ttl_seconds = 300  # 5 minutes
        self.cache_timestamps: Dict[str, float] = {}
        
        logger.info("RouterEngine instance created")
    
    async def initialize(self):
        """Initialize the router engine"""
        logger.info("Initializing Router Engine...")
        
        # Setup default routing rules
        self._setup_default_rules()
        
        # Register default handlers
        self._register_default_handlers()
        
        # Update tool availability
        await self._update_tool_availability()
        
        logger.info(f"Router Engine initialized with {len(self.rules)} rules")
    
    def _setup_default_rules(self):
        """Setup default routing rules"""
        
        # ─────────────────────────────────────────────────────────────────────
        # INSTANT RESPONSE RULES (Highest Priority)
        # ─────────────────────────────────────────────────────────────────────
        
        self.rules.append(RoutingRule(
            name="greeting",
            patterns=[
                r"^(hi|hello|hey|greetings|good\s*(morning|afternoon|evening))[\s!.,]*$",
                r"^(howdy|sup|yo|hiya)[\s!.,]*$"
            ],
            category=TaskCategory.GREETING,
            route_type=RouteType.INSTANT,
            handler="instant_greeting",
            tools=[],
            priority=1
        ))
        
        self.rules.append(RoutingRule(
            name="farewell",
            patterns=[
                r"^(bye|goodbye|see\s*you|farewell|take\s*care)[\s!.,]*$",
                r"^(later|cya|ttyl)[\s!.,]*$"
            ],
            category=TaskCategory.FAREWELL,
            route_type=RouteType.INSTANT,
            handler="instant_farewell",
            tools=[],
            priority=2
        ))
        
        self.rules.append(RoutingRule(
            name="gratitude",
            patterns=[
                r"^(thanks?|thank\s*you|thx|ty|appreciate)[\s!.,]*",
                r"(thanks|thank\s*you)\s*(so\s*much|a\s*lot)?[\s!.,]*$"
            ],
            category=TaskCategory.GRATITUDE,
            route_type=RouteType.INSTANT,
            handler="instant_gratitude",
            tools=[],
            priority=3
        ))
        
        self.rules.append(RoutingRule(
            name="help_request",
            patterns=[
                r"^(help|help\s*me|\?\?+)[\s!.,]*$",
                r"^what\s*can\s*you\s*do[\s!.,?]*$",
                r"^show\s*(me\s*)?(your\s*)?(commands|capabilities|features)"
            ],
            category=TaskCategory.HELP,
            route_type=RouteType.INSTANT,
            handler="instant_help",
            tools=[],
            priority=4
        ))
        
        self.rules.append(RoutingRule(
            name="status_check",
            patterns=[
                r"^(status|how\s*are\s*you|you\s*ok|are\s*you\s*(there|alive|working))[\s!.,?]*$"
            ],
            category=TaskCategory.STATUS,
            route_type=RouteType.INSTANT,
            handler="instant_status",
            tools=[],
            priority=5
        ))
        
        # ─────────────────────────────────────────────────────────────────────
        # TOOL-BASED RULES
        # ─────────────────────────────────────────────────────────────────────
        
        self.rules.append(RoutingRule(
            name="calculation",
            patterns=[
                r"(calculate|compute|what\s*is)\s*[\d\+\-\*\/\(\)\.\s]+",
                r"^\s*[\d\+\-\*\/\(\)\.\s]+\s*=?\s*\??$",
                r"(sum|average|mean|median|percentage)\s*of"
            ],
            category=TaskCategory.CALCULATION,
            route_type=RouteType.TOOL_CALL,
            handler="tool_calculator",
            tools=["calculator.calculate"],
            priority=10
        ))
        
        self.rules.append(RoutingRule(
            name="web_search",
            patterns=[
                r"(search|google|look\s*up|find\s*(info|information))\s*(for|about)?",
                r"what\s*(is|are)\s*the\s*(latest|current|recent)",
                r"(news|updates)\s*(about|on|for)"
            ],
            category=TaskCategory.SEARCH,
            route_type=RouteType.TOOL_CALL,
            handler="tool_search",
            tools=["web_search.search"],
            priority=15
        ))
        
        self.rules.append(RoutingRule(
            name="file_read",
            patterns=[
                r"(read|show|display|open|cat)\s*(the\s*)?(file|content)",
                r"what('s|\s*is)\s*(in|inside)\s*(the\s*)?(file|document)"
            ],
            category=TaskCategory.FILE,
            route_type=RouteType.TOOL_CALL,
            handler="tool_file_read",
            tools=["file_manager.read_file"],
            priority=20
        ))
        
        self.rules.append(RoutingRule(
            name="file_write",
            patterns=[
                r"(write|save|create|make)\s*(a\s*)?(new\s*)?(file|document)",
                r"(save|write)\s*(this|that|it)\s*(to|as)\s*(a\s*)?(file)?"
            ],
            category=TaskCategory.FILE,
            route_type=RouteType.TOOL_CALL,
            handler="tool_file_write",
            tools=["file_manager.write_file"],
            priority=21
        ))
        
        self.rules.append(RoutingRule(
            name="code_execution",
            patterns=[
                r"(run|execute|eval)\s*(this\s*)?(code|script|python)",
                r"```(python|py)[\s\S]*```"
            ],
            category=TaskCategory.CODE,
            route_type=RouteType.TOOL_CALL,
            handler="tool_code_execute",
            tools=["code_executor.execute_python"],
            priority=25
        ))
        
        # ─────────────────────────────────────────────────────────────────────
        # THINKING-BASED RULES
        # ─────────────────────────────────────────────────────────────────────
        
        self.rules.append(RoutingRule(
            name="code_generation",
            patterns=[
                r"(write|create|generate|make|build)\s*(me\s*)?(a\s*)?(code|function|class|script|program)",
                r"(code|implement|program)\s*(for|to|that)",
                r"(python|javascript|java|c\+\+|rust)\s*(code|function|program)"
            ],
            category=TaskCategory.CODE,
            route_type=RouteType.THINKING,
            handler="thinking_code",
            tools=[],
            priority=30
        ))
        
        self.rules.append(RoutingRule(
            name="analysis",
            patterns=[
                r"(analyze|analyse|examine|evaluate|review|assess)\s+",
                r"(what\s+do\s+you\s+think|your\s+(opinion|thoughts))\s+(about|on)",
                r"(pros\s+and\s+cons|advantages\s+and\s+disadvantages)"
            ],
            category=TaskCategory.ANALYSIS,
            route_type=RouteType.THINKING,
            handler="thinking_analysis",
            tools=[],
            priority=35
        ))
        
        self.rules.append(RoutingRule(
            name="explanation",
            patterns=[
                r"(explain|describe|tell\s+me\s+about|how\s+does)\s+",
                r"(why|how)\s+(does|do|is|are|can|should)",
                r"what\s+(is|are)\s+.{10,}"  # Longer "what is" questions
            ],
            category=TaskCategory.FACTUAL,
            route_type=RouteType.THINKING,
            handler="thinking_explanation",
            tools=[],
            priority=40
        ))
        
        self.rules.append(RoutingRule(
            name="creative",
            patterns=[
                r"(write|create|compose|draft)\s*(me\s*)?(a\s*)?(story|poem|essay|article|blog)",
                r"(brainstorm|ideas?\s+for|suggest)",
                r"(imagine|pretend|roleplay|act\s+as)"
            ],
            category=TaskCategory.CREATIVE,
            route_type=RouteType.THINKING,
            handler="thinking_creative",
            tools=[],
            priority=45
        ))
        
        # ─────────────────────────────────────────────────────────────────────
        # SYSTEM RULES
        # ─────────────────────────────────────────────────────────────────────
        
        self.rules.append(RoutingRule(
            name="system_identity",
            patterns=[
                r"(who|what)\s*(are\s*you|is\s*your\s*name)",
                r"(your|about)\s*(yourself|identity|name)",
                r"^(identify\s*yourself|introduce\s*yourself)"
            ],
            category=TaskCategory.SYSTEM,
            route_type=RouteType.INSTANT,
            handler="instant_identity",
            tools=[],
            priority=50
        ))
        
        self.rules.append(RoutingRule(
            name="system_capabilities",
            patterns=[
                r"(what|list)\s*(are\s*)?(your\s*)?(capabilities|features|skills|tools)",
                r"(can\s*you|are\s*you\s*able\s*to)\s+\w+"
            ],
            category=TaskCategory.SYSTEM,
            route_type=RouteType.INSTANT,
            handler="instant_capabilities",
            tools=[],
            priority=51
        ))
        
        # Sort rules by priority
        self.rules.sort(key=lambda r: r.priority)
    
    def _register_default_handlers(self):
        """Register default response handlers"""
        
        # Instant handlers
        self.handlers["instant_greeting"] = self._handle_greeting
        self.handlers["instant_farewell"] = self._handle_farewell
        self.handlers["instant_gratitude"] = self._handle_gratitude
        self.handlers["instant_help"] = self._handle_help
        self.handlers["instant_status"] = self._handle_status
        self.handlers["instant_identity"] = self._handle_identity
        self.handlers["instant_capabilities"] = self._handle_capabilities
        
        # Tool handlers
        self.handlers["tool_calculator"] = self._handle_tool_call
        self.handlers["tool_search"] = self._handle_tool_call
        self.handlers["tool_file_read"] = self._handle_tool_call
        self.handlers["tool_file_write"] = self._handle_tool_call
        self.handlers["tool_code_execute"] = self._handle_tool_call
        
        # Thinking handlers
        self.handlers["thinking_code"] = self._handle_thinking
        self.handlers["thinking_analysis"] = self._handle_thinking
        self.handlers["thinking_explanation"] = self._handle_thinking
        self.handlers["thinking_creative"] = self._handle_thinking
        
        # Default handler
        self.handlers["default"] = self._handle_default
    
    async def _update_tool_availability(self):
        """Update cache of available tools"""
        if hasattr(self.agent, 'loaded_tools'):
            self.available_tools = {
                name: True for name in self.agent.loaded_tools.keys()
            }
        logger.info(f"Tool availability updated: {len(self.available_tools)} tools")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MAIN ROUTING LOGIC
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def route(self, text: str, context: Dict[str, Any] = None) -> Route:
        """
        Route incoming request to appropriate handler
        
        Args:
            text: Input text to route
            context: Additional context
            
        Returns:
            Route object with routing decision
        """
        start_time = time.time()
        
        # Check cache first
        cache_key = self._generate_cache_key(text)
        cached_route = self._get_cached_route(cache_key)
        if cached_route:
            logger.debug(f"Cache hit for routing: {text[:50]}")
            return cached_route
        
        # Try rule-based routing
        route, matched_rule = await self._route_by_rules(text)
        
        if route is None:
            # Fall back to classification-based routing
            route = await self._route_by_classification(text, context)
            matched_rule = None
        
        # Record decision
        decision_time = (time.time() - start_time) * 1000
        decision = RoutingDecision(
            route=route,
            input_text=text,
            decided_at=datetime.now(),
            decision_time_ms=decision_time,
            rules_checked=len(self.rules),
            matched_rule=matched_rule
        )
        self._record_decision(decision)
        
        # Cache the route
        self._cache_route(cache_key, route)
        
        logger.info(f"Routed to {route.route_type.value}/{route.handler} "
                   f"(confidence: {route.confidence:.2f}, time: {decision_time:.1f}ms)")
        
        return route
    
    async def _route_by_rules(self, text: str) -> Tuple[Optional[Route], Optional[str]]:
        """Attempt to route using pattern-based rules"""
        text_normalized = text.strip()
        
        for rule in self.rules:
            if not rule.enabled:
                continue
            
            matches, confidence = rule.matches(text_normalized)
            
            if matches:
                # Check if required tools are available
                tools_available = all(
                    tool in self.available_tools or 
                    tool.split('.')[0] in [t.split('.')[0] for t in self.available_tools]
                    for tool in rule.tools
                )
                
                if not tools_available and rule.tools:
                    logger.debug(f"Rule {rule.name} matched but tools unavailable")
                    continue
                
                route = Route(
                    route_type=rule.route_type,
                    category=rule.category,
                    priority=RoutePriority.NORMAL,
                    handler=rule.handler,
                    tools=rule.tools,
                    confidence=confidence,
                    estimated_time_ms=self._estimate_time(rule.route_type)
                )
                
                return route, rule.name
        
        return None, None
    
    async def _route_by_classification(self, text: str, 
                                       context: Dict[str, Any] = None) -> Route:
        """Route using classification when rules don't match"""
        
        # Analyze text characteristics
        text_lower = text.lower()
        word_count = len(text.split())
        has_question = '?' in text
        has_code = '```' in text or 'def ' in text or 'class ' in text
        
        # Determine category and route type
        if has_code or any(w in text_lower for w in ['code', 'function', 'program', 'script']):
            category = TaskCategory.CODE
            route_type = RouteType.THINKING
            handler = "thinking_code"
        
        elif word_count < 5 and not has_question:
            category = TaskCategory.CONVERSATIONAL
            route_type = RouteType.RULE_BASED
            handler = "default"
        
        elif any(w in text_lower for w in ['search', 'find', 'look up', 'google']):
            category = TaskCategory.SEARCH
            route_type = RouteType.TOOL_CALL
            handler = "tool_search"
        
        elif any(w in text_lower for w in ['analyze', 'explain', 'why', 'how does']):
            category = TaskCategory.ANALYSIS
            route_type = RouteType.THINKING
            handler = "thinking_analysis"
        
        elif word_count > 30 or any(w in text_lower for w in ['complex', 'detailed', 'comprehensive']):
            category = TaskCategory.ANALYSIS
            route_type = RouteType.THINKING
            handler = "thinking_explanation"
        
        else:
            category = TaskCategory.CONVERSATIONAL
            route_type = RouteType.THINKING
            handler = "thinking_explanation"
        
        # Get available tools for this category
        tools = self._get_tools_for_category(category)
        
        return Route(
            route_type=route_type,
            category=category,
            priority=RoutePriority.NORMAL,
            handler=handler,
            tools=tools,
            confidence=0.6,  # Lower confidence for classification-based
            estimated_time_ms=self._estimate_time(route_type)
        )
    
    def _get_tools_for_category(self, category: TaskCategory) -> List[str]:
        """Get relevant tools for a category"""
        category_tools = {
            TaskCategory.SEARCH: ["web_search.search"],
            TaskCategory.CALCULATION: ["calculator.calculate"],
            TaskCategory.FILE: ["file_manager.read_file", "file_manager.write_file"],
            TaskCategory.CODE: ["code_executor.execute_python"]
        }
        
        tools = category_tools.get(category, [])
        return [t for t in tools if t in self.available_tools or 
                t.split('.')[0] in [at.split('.')[0] for at in self.available_tools]]
    
    def _estimate_time(self, route_type: RouteType) -> int:
        """Estimate processing time in milliseconds"""
        estimates = {
            RouteType.INSTANT: 50,
            RouteType.RULE_BASED: 200,
            RouteType.TOOL_CALL: 2000,
            RouteType.MULTI_TOOL: 5000,
            RouteType.THINKING: 15000,
            RouteType.EXTERNAL: 30000,
            RouteType.HYBRID: 10000
        }
        return estimates.get(route_type, 5000)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # RESPONSE HANDLERS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _handle_greeting(self, text: str, route: Route, 
                               context: Dict = None) -> Dict[str, Any]:
        """Handle greeting messages"""
        owner_name = self.agent.identity.owner.name if self.agent.identity.owner else "there"
        
        greetings = [
            f"Hello {owner_name}! How can I help you today?",
            f"Hi {owner_name}! What would you like to work on?",
            f"Hey {owner_name}! Ready to assist you.",
            f"Greetings {owner_name}! What's on your mind?"
        ]
        
        import random
        response = random.choice(greetings)
        
        return {
            "response": response,
            "confidence": 1.0,
            "route_type": "instant"
        }
    
    async def _handle_farewell(self, text: str, route: Route,
                               context: Dict = None) -> Dict[str, Any]:
        """Handle farewell messages"""
        owner_name = self.agent.identity.owner.name if self.agent.identity.owner else ""
        
        farewells = [
            f"Goodbye{', ' + owner_name if owner_name else ''}! Have a great day!",
            f"See you later{', ' + owner_name if owner_name else ''}! Take care!",
            f"Bye for now! Don't hesitate to come back if you need anything.",
            f"Until next time! 👋"
        ]
        
        import random
        response = random.choice(farewells)
        
        return {
            "response": response,
            "confidence": 1.0,
            "route_type": "instant"
        }
    
    async def _handle_gratitude(self, text: str, route: Route,
                                context: Dict = None) -> Dict[str, Any]:
        """Handle thank you messages"""
        responses = [
            "You're welcome! Happy to help!",
            "My pleasure! Let me know if you need anything else.",
            "Glad I could help! 😊",
            "Anytime! That's what I'm here for."
        ]
        
        import random
        return {
            "response": random.choice(responses),
            "confidence": 1.0,
            "route_type": "instant"
        }
    
    async def _handle_help(self, text: str, route: Route,
                           context: Dict = None) -> Dict[str, Any]:
        """Handle help requests"""
        capabilities = []
        
        if hasattr(self.agent, 'loaded_tools'):
            for tool_name in list(self.agent.loaded_tools.keys())[:10]:
                capabilities.append(f"• {tool_name}")
        
        help_text = f"""I'm {self.agent.identity.name}, your AI assistant. Here's what I can help with:

**Core Capabilities:**
• Answer questions and explain concepts
• Write and analyze code
• Search the web for information
• Perform calculations
• Read and write files
• Have natural conversations

**Available Tools:**
{chr(10).join(capabilities) if capabilities else '• Tools loading...'}

Just ask me anything naturally! For example:
- "Write a Python function to sort a list"
- "Search for the latest news about AI"
- "Explain how neural networks work"
- "Calculate 15% of 250"
"""
        
        return {
            "response": help_text,
            "confidence": 1.0,
            "route_type": "instant"
        }
    
    async def _handle_status(self, text: str, route: Route,
                             context: Dict = None) -> Dict[str, Any]:
        """Handle status check messages"""
        health_score = self.agent.identity.health_score if hasattr(self.agent.identity, 'health_score') else 100
        
        if health_score >= 90:
            status = "I'm doing great! All systems are running smoothly. 🟢"
        elif health_score >= 70:
            status = "I'm doing well, with minor issues being handled. 🟡"
        else:
            status = "I'm operational but experiencing some difficulties. 🟠"
        
        return {
            "response": status,
            "confidence": 1.0,
            "route_type": "instant"
        }
    
    async def _handle_identity(self, text: str, route: Route,
                               context: Dict = None) -> Dict[str, Any]:
        """Handle identity questions"""
        owner_name = self.agent.identity.owner.name if self.agent.identity.owner else "my user"
        relationship = self.agent.identity.owner.relationship if self.agent.identity.owner else "assistant"
        
        response = f"""I'm {self.agent.identity.name}, an evolving AI agent.

**About Me:**
• Version: {self.agent.identity.version}
• Role: {relationship} to {owner_name}
• Created to learn, grow, and help

I'm designed to continuously improve and adapt to better serve you. I can think deeply about problems, learn from our interactions, and even upgrade my own capabilities over time."""

        return {
            "response": response,
            "confidence": 1.0,
            "route_type": "instant"
        }
    
    async def _handle_capabilities(self, text: str, route: Route,
                                   context: Dict = None) -> Dict[str, Any]:
        """Handle capability inquiries"""
        return await self._handle_help(text, route, context)
    
    async def _handle_tool_call(self, text: str, route: Route,
                                context: Dict = None) -> Dict[str, Any]:
        """Handle requests that need tool calls"""
        # This would be handled by the tool manager
        return {
            "response": None,  # Signal to use tool
            "route_type": "tool_call",
            "tools": route.tools,
            "confidence": route.confidence
        }
    
    async def _handle_thinking(self, text: str, route: Route,
                               context: Dict = None) -> Dict[str, Any]:
        """Handle requests that need deep thinking"""
        return {
            "response": None,  # Signal to use thinking engine
            "route_type": "thinking",
            "category": route.category.value,
            "confidence": route.confidence
        }
    
    async def _handle_default(self, text: str, route: Route,
                              context: Dict = None) -> Dict[str, Any]:
        """Default handler for unmatched requests"""
        return {
            "response": None,  # Signal to use AI
            "route_type": "default",
            "confidence": 0.5
        }
    
    # ═══════════════════════════════════════════════════════════════════════════
    # EXECUTION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def execute_route(self, text: str, route: Route,
                           context: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Execute the routing decision
        
        Args:
            text: Original input text
            route: Routing decision
            context: Additional context
            
        Returns:
            Response dict
        """
        start_time = time.time()
        
        try:
            handler = self.handlers.get(route.handler, self.handlers["default"])
            result = await handler(text, route, context)
            
            # Track performance
            elapsed_ms = (time.time() - start_time) * 1000
            self._track_performance(route.handler, elapsed_ms, True)
            
            return result
            
        except Exception as e:
            logger.error(f"Error executing route {route.handler}: {e}")
            elapsed_ms = (time.time() - start_time) * 1000
            self._track_performance(route.handler, elapsed_ms, False)
            
            return {
                "response": f"I encountered an error: {str(e)}",
                "error": True,
                "confidence": 0.1
            }
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CACHING AND PERFORMANCE
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _generate_cache_key(self, text: str) -> str:
        """Generate cache key from text"""
        normalized = text.lower().strip()
        # Simple hash for quick lookup
        return str(hash(normalized))
    
    def _get_cached_route(self, key: str) -> Optional[Route]:
        """Get route from cache if valid"""
        if key not in self.route_cache:
            return None
        
        # Check TTL
        timestamp = self.cache_timestamps.get(key, 0)
        if time.time() - timestamp > self.cache_ttl_seconds:
            del self.route_cache[key]
            del self.cache_timestamps[key]
            return None
        
        return self.route_cache[key]
    
    def _cache_route(self, key: str, route: Route):
        """Cache a routing decision"""
        # Evict old entries if needed
        if len(self.route_cache) >= self.cache_max_size:
            oldest_key = min(self.cache_timestamps.keys(), 
                           key=lambda k: self.cache_timestamps[k])
            del self.route_cache[oldest_key]
            del self.cache_timestamps[oldest_key]
        
        self.route_cache[key] = route
        self.cache_timestamps[key] = time.time()
    
    def _record_decision(self, decision: RoutingDecision):
        """Record routing decision for analysis"""
        self.routing_history.append(decision)
        
        # Trim history if needed
        if len(self.routing_history) > self.max_history:
            self.routing_history = self.routing_history[-self.max_history:]
    
    def _track_performance(self, handler: str, elapsed_ms: float, success: bool):
        """Track handler performance"""
        stats = self.route_performance[handler]
        stats["count"] += 1
        stats["total_time_ms"] += elapsed_ms
        stats["avg_time_ms"] = stats["total_time_ms"] / stats["count"]
        
        # Update success rate with exponential moving average
        stats["success_rate"] = 0.95 * stats["success_rate"] + 0.05 * (1.0 if success else 0.0)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # RULE MANAGEMENT
    # ═══════════════════════════════════════════════════════════════════════════
    
    def add_rule(self, rule: RoutingRule):
        """Add a new routing rule"""
        self.rules.append(rule)
        self.rules.sort(key=lambda r: r.priority)
        logger.info(f"Added routing rule: {rule.name}")
    
    def remove_rule(self, rule_name: str) -> bool:
        """Remove a routing rule by name"""
        for i, rule in enumerate(self.rules):
            if rule.name == rule_name:
                self.rules.pop(i)
                logger.info(f"Removed routing rule: {rule_name}")
                return True
        return False
    
    def enable_rule(self, rule_name: str, enabled: bool = True):
        """Enable or disable a rule"""
        for rule in self.rules:
            if rule.name == rule_name:
                rule.enabled = enabled
                logger.info(f"Rule {rule_name} {'enabled' if enabled else 'disabled'}")
                break
    
    def list_rules(self) -> List[Dict[str, Any]]:
        """List all routing rules"""
        return [
            {
                "name": rule.name,
                "category": rule.category.value,
                "route_type": rule.route_type.value,
                "priority": rule.priority,
                "enabled": rule.enabled,
                "patterns": len(rule.patterns)
            }
            for rule in self.rules
        ]
    
    # ═══════════════════════════════════════════════════════════════════════════
    # STATISTICS AND MONITORING
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_stats(self) -> Dict[str, Any]:
        """Get routing statistics"""
        total_decisions = len(self.routing_history)
        
        if total_decisions == 0:
            return {
                "total_decisions": 0,
                "cache_size": len(self.route_cache),
                "rules_count": len(self.rules)
            }
        
        # Calculate statistics
        route_type_counts = defaultdict(int)
        category_counts = defaultdict(int)
        avg_decision_time = 0
        rule_match_count = 0
        
        for decision in self.routing_history:
            route_type_counts[decision.route.route_type.value] += 1
            category_counts[decision.route.category.value] += 1
            avg_decision_time += decision.decision_time_ms
            if decision.matched_rule:
                rule_match_count += 1
        
        avg_decision_time /= total_decisions
        
        return {
            "total_decisions": total_decisions,
            "avg_decision_time_ms": round(avg_decision_time, 2),
            "rule_match_rate": round(rule_match_count / total_decisions, 2),
            "route_types": dict(route_type_counts),
            "categories": dict(category_counts),
            "cache_size": len(self.route_cache),
            "cache_hit_rate": 0,  # Would need to track this
            "rules_count": len(self.rules),
            "handler_performance": dict(self.route_performance)
        }
    
    def clear_cache(self):
        """Clear the routing cache"""
        self.route_cache.clear()
        self.cache_timestamps.clear()
        logger.info("Routing cache cleared")