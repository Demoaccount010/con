#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                        UPGRADE ENGINE - Safe Self-Modification               ║
║                   Autonomous Evolution System for SMILE Agent                ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Features:                                                                   ║
║  - Capability gap detection                                                  ║
║  - Automatic plugin generation                                               ║
║  - Safe sandbox testing                                                      ║
║  - Version management and rollback                                           ║
║  - Upgrade proposals and approval workflow                                   ║
║  - Self-healing and recovery                                                 ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import asyncio
import logging
import json
import shutil
import hashlib
import subprocess
import sys
import tempfile
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field, asdict
from enum import Enum, auto
from pathlib import Path
import traceback
import importlib

logger = logging.getLogger("SMILE.UpgradeEngine")

# ═══════════════════════════════════════════════════════════════════════════════
# ENUMS AND DATA STRUCTURES
# ═══════════════════════════════════════════════════════════════════════════════

class UpgradeType(Enum):
    """Types of upgrades"""
    NEW_PLUGIN = "new_plugin"
    PLUGIN_UPDATE = "plugin_update"
    TOOL_ADDITION = "tool_addition"
    KNOWLEDGE_UPDATE = "knowledge_update"
    CONFIG_CHANGE = "config_change"
    CORE_PATCH = "core_patch"
    DEPENDENCY_ADD = "dependency_add"
    BEHAVIOR_CHANGE = "behavior_change"

class UpgradeStatus(Enum):
    """Status of an upgrade"""
    PROPOSED = "proposed"
    APPROVED = "approved"
    REJECTED = "rejected"
    TESTING = "testing"
    TEST_PASSED = "test_passed"
    TEST_FAILED = "test_failed"
    APPLYING = "applying"
    APPLIED = "applied"
    ROLLED_BACK = "rolled_back"
    FAILED = "failed"

class ApprovalMode(Enum):
    """Approval modes for upgrades"""
    AUTO = "auto"           # Automatic approval for safe upgrades
    MANUAL = "manual"       # Require owner approval
    HYBRID = "hybrid"       # Auto for low-risk, manual for high-risk

@dataclass
class Upgrade:
    """Represents a system upgrade"""
    id: str
    upgrade_type: UpgradeType
    title: str
    description: str
    reason: str
    status: UpgradeStatus
    created_at: datetime
    risk_level: int  # 1-5, 5 being highest risk
    
    # Technical details
    code: Optional[str] = None
    target_path: Optional[str] = None
    dependencies: List[str] = field(default_factory=list)
    
    # Workflow
    approved_at: Optional[datetime] = None
    approved_by: Optional[str] = None
    applied_at: Optional[datetime] = None
    
    # Testing
    test_results: Dict[str, Any] = field(default_factory=dict)
    
    # Backup/Rollback
    backup_path: Optional[str] = None
    rollback_available: bool = False
    
    # Metadata
    version: str = "1.0.0"
    author: str = "SMILE"
    
    def to_dict(self) -> Dict:
        data = asdict(self)
        data['upgrade_type'] = self.upgrade_type.value
        data['status'] = self.status.value
        data['created_at'] = self.created_at.isoformat()
        if self.approved_at:
            data['approved_at'] = self.approved_at.isoformat()
        if self.applied_at:
            data['applied_at'] = self.applied_at.isoformat()
        return data

@dataclass
class CapabilityGap:
    """Identified capability gap"""
    id: str
    description: str
    detected_at: datetime
    occurrences: int = 1
    examples: List[str] = field(default_factory=list)
    proposed_solution: Optional[str] = None
    upgrade_id: Optional[str] = None

@dataclass
class VersionInfo:
    """Version information for tracking"""
    component: str
    version: str
    installed_at: datetime
    checksum: str
    previous_version: Optional[str] = None

# ═══════════════════════════════════════════════════════════════════════════════
# UPGRADE ENGINE CORE
# ═══════════════════════════════════════════════════════════════════════════════

class UpgradeEngine:
    """
    Safe Self-Modification Engine
    
    Enables SMILE to:
    1. Detect missing capabilities
    2. Propose new features
    3. Generate plugin code
    4. Test in sandbox
    5. Apply safely with rollback
    """
    
    def __init__(self, agent):
        """
        Initialize Upgrade Engine
        
        Args:
            agent: Reference to main SMILE agent
        """
        self.agent = agent
        
        # Paths
        self.base_dir = Path(__file__).parent.parent
        self.plugins_dir = self.base_dir / "plugins"
        self.backups_dir = self.base_dir / "backups"
        self.sandbox_dir = self.base_dir / "sandbox"
        
        # Ensure directories exist
        self.backups_dir.mkdir(parents=True, exist_ok=True)
        self.sandbox_dir.mkdir(parents=True, exist_ok=True)
        
        # Upgrade tracking
        self.upgrades: Dict[str, Upgrade] = {}
        self.upgrade_history: List[Upgrade] = []
        
        # Capability gaps
        self.capability_gaps: Dict[str, CapabilityGap] = {}
        
        # Version tracking
        self.versions: Dict[str, VersionInfo] = {}
        
        # Configuration
        self.approval_mode = ApprovalMode.HYBRID
        self.auto_approve_risk_threshold = 2  # Auto-approve if risk <= this
        self.max_pending_upgrades = 10
        
        # Safety limits
        self.max_upgrades_per_day = 5
        self.upgrades_today = 0
        self.last_reset_date = datetime.now().date()
        
        logger.info("UpgradeEngine instance created")
    
    async def initialize(self):
        """Initialize the upgrade engine"""
        logger.info("Initializing Upgrade Engine...")
        
        # Load existing upgrades from memory
        await self._load_upgrade_history()
        
        # Build version map
        await self._build_version_map()
        
        # Check for pending upgrades
        pending = [u for u in self.upgrades.values() 
                   if u.status == UpgradeStatus.PROPOSED]
        if pending:
            logger.info(f"Found {len(pending)} pending upgrade proposals")
        
        logger.info("Upgrade Engine initialized")
    
    async def _load_upgrade_history(self):
        """Load upgrade history from memory"""
        if self.agent.memory_system:
            history = await self.agent.memory_system.retrieve_long_term("upgrade_history")
            if history and isinstance(history, list):
                for data in history[-50:]:  # Load last 50
                    try:
                        upgrade = self._upgrade_from_dict(data)
                        self.upgrade_history.append(upgrade)
                        if upgrade.status in [UpgradeStatus.PROPOSED, UpgradeStatus.APPROVED]:
                            self.upgrades[upgrade.id] = upgrade
                    except Exception as e:
                        logger.warning(f"Failed to load upgrade: {e}")
    
    def _upgrade_from_dict(self, data: Dict) -> Upgrade:
        """Create Upgrade from dict"""
        return Upgrade(
            id=data.get("id", ""),
            upgrade_type=UpgradeType(data.get("upgrade_type", "new_plugin")),
            title=data.get("title", ""),
            description=data.get("description", ""),
            reason=data.get("reason", ""),
            status=UpgradeStatus(data.get("status", "proposed")),
            created_at=datetime.fromisoformat(data.get("created_at", datetime.now().isoformat())),
            risk_level=data.get("risk_level", 3),
            code=data.get("code"),
            target_path=data.get("target_path"),
            dependencies=data.get("dependencies", []),
            version=data.get("version", "1.0.0")
        )
    
    async def _build_version_map(self):
        """Build map of component versions"""
        # Core version
        self.versions["core"] = VersionInfo(
            component="core",
            version=self.agent.identity.version,
            installed_at=datetime.now(),
            checksum=self._calculate_checksum(self.base_dir / "core")
        )
        
        # Plugin versions
        if self.plugins_dir.exists():
            for plugin_dir in self.plugins_dir.iterdir():
                if plugin_dir.is_dir() and not plugin_dir.name.startswith('_'):
                    metadata_file = plugin_dir / "plugin.json"
                    if metadata_file.exists():
                        try:
                            with open(metadata_file) as f:
                                metadata = json.load(f)
                            self.versions[f"plugin:{metadata['name']}"] = VersionInfo(
                                component=f"plugin:{metadata['name']}",
                                version=metadata.get("version", "1.0.0"),
                                installed_at=datetime.now(),
                                checksum=self._calculate_checksum(plugin_dir)
                            )
                        except:
                            pass
    
    def _calculate_checksum(self, path: Path) -> str:
        """Calculate checksum for a file or directory"""
        if path.is_file():
            return hashlib.md5(path.read_bytes()).hexdigest()
        elif path.is_dir():
            checksums = []
            for file in sorted(path.rglob("*.py")):
                checksums.append(hashlib.md5(file.read_bytes()).hexdigest())
            return hashlib.md5("".join(checksums).encode()).hexdigest()
        return ""
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CAPABILITY GAP DETECTION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def detect_capability_gap(self, request: str, reason: str) -> str:
        """
        Record a detected capability gap
        
        Args:
            request: What was requested
            reason: Why we couldn't fulfill it
            
        Returns:
            Gap ID
        """
        # Create hash for deduplication
        gap_hash = hashlib.md5(f"{request[:100]}".encode()).hexdigest()[:8]
        gap_id = f"gap_{gap_hash}"
        
        if gap_id in self.capability_gaps:
            # Update existing gap
            gap = self.capability_gaps[gap_id]
            gap.occurrences += 1
            gap.examples.append(request[:200])
            gap.examples = gap.examples[-5:]  # Keep last 5 examples
        else:
            # Create new gap
            gap = CapabilityGap(
                id=gap_id,
                description=reason,
                detected_at=datetime.now(),
                occurrences=1,
                examples=[request[:200]]
            )
            self.capability_gaps[gap_id] = gap
        
        # If gap is significant, propose solution
        if gap.occurrences >= 3 and not gap.upgrade_id:
            await self._propose_gap_solution(gap)
        
        logger.info(f"Capability gap recorded: {gap_id} (occurrences: {gap.occurrences})")
        return gap_id
    
    async def _propose_gap_solution(self, gap: CapabilityGap):
        """Propose a solution for a capability gap"""
        # Analyze the gap and examples
        examples_text = "\n".join(gap.examples)
        
        # Generate solution proposal using AI
        proposal = await self._generate_solution_proposal(gap.description, examples_text)
        
        if proposal:
            gap.proposed_solution = proposal["description"]
            
            # Create upgrade proposal
            upgrade = await self.propose_upgrade(
                upgrade_type=UpgradeType.NEW_PLUGIN,
                title=proposal["title"],
                description=proposal["description"],
                reason=f"Detected capability gap: {gap.description}",
                code=proposal.get("code"),
                risk_level=proposal.get("risk_level", 3)
            )
            
            gap.upgrade_id = upgrade.id
    
    async def _generate_solution_proposal(self, description: str, 
                                         examples: str) -> Optional[Dict]:
        """Generate a solution proposal for a capability gap"""
        # Use AI to generate proposal
        if not self.agent.api_manager:
            return None
        
        prompt = f"""Analyze this capability gap and propose a plugin solution:

Gap Description: {description}

Examples of requests that couldn't be fulfilled:
{examples}

Generate a plugin proposal with:
1. A clear title
2. Description of what the plugin will do
3. Python code for a SMILE plugin that solves this

The plugin must inherit from BasePlugin and implement initialize() and shutdown() methods.
Include proper tool registration.

Respond in JSON format:
{{
    "title": "Plugin Name",
    "description": "What it does",
    "risk_level": 1-5,
    "code": "full python code"
}}
"""
        
        try:
            response = await self.agent.api_manager.generate([
                {"role": "system", "content": "You are a plugin developer for the SMILE AI agent system."},
                {"role": "user", "content": prompt}
            ])
            
            # Parse JSON from response
            import re
            json_match = re.search(r'\{[\s\S]*\}', response)
            if json_match:
                return json.loads(json_match.group())
        except Exception as e:
            logger.error(f"Failed to generate solution proposal: {e}")
        
        return None
    
    # ═══════════════════════════════════════════════════════════════════════════
    # UPGRADE PROPOSAL
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def propose_upgrade(self, upgrade_type: UpgradeType,
                             title: str, description: str,
                             reason: str, code: str = None,
                             risk_level: int = 3,
                             dependencies: List[str] = None) -> Upgrade:
        """
        Propose a new upgrade
        
        Args:
            upgrade_type: Type of upgrade
            title: Upgrade title
            description: What the upgrade does
            reason: Why the upgrade is needed
            code: Code for the upgrade (if applicable)
            risk_level: Risk level 1-5
            dependencies: Required dependencies
            
        Returns:
            Created Upgrade object
        """
        upgrade_id = f"upg_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        upgrade = Upgrade(
            id=upgrade_id,
            upgrade_type=upgrade_type,
            title=title,
            description=description,
            reason=reason,
            status=UpgradeStatus.PROPOSED,
            created_at=datetime.now(),
            risk_level=risk_level,
            code=code,
            dependencies=dependencies or []
        )
        
        self.upgrades[upgrade_id] = upgrade
        
        logger.info(f"Proposed upgrade: {title} (risk: {risk_level})")
        
        # Check for auto-approval
        if await self._should_auto_approve(upgrade):
            await self.approve_upgrade(upgrade_id, "SMILE (auto)")
        else:
            # Notify owner
            if hasattr(self.agent, 'initiative_engine'):
                await self.agent.initiative_engine.propose_upgrade(
                    title,
                    f"Risk level: {risk_level}/5. {reason}"
                )
        
        return upgrade
    
    async def _should_auto_approve(self, upgrade: Upgrade) -> bool:
        """Determine if upgrade should be auto-approved"""
        # Check permissions
        if not self.agent.identity.owner.permission_levels.get("self_upgrade", False):
            return False
        
        # Check approval mode
        if self.approval_mode == ApprovalMode.MANUAL:
            return False
        
        if self.approval_mode == ApprovalMode.AUTO:
            return True
        
        # Hybrid mode - check risk level
        if upgrade.risk_level <= self.auto_approve_risk_threshold:
            # Additional safety checks
            if upgrade.upgrade_type == UpgradeType.CORE_PATCH:
                return False  # Never auto-approve core patches
            
            if upgrade.upgrade_type == UpgradeType.NEW_PLUGIN:
                # Check daily limit
                if self.upgrades_today >= self.max_upgrades_per_day:
                    return False
                return True
        
        return False
    
    async def approve_upgrade(self, upgrade_id: str, 
                             approver: str = "owner") -> bool:
        """
        Approve an upgrade for testing and application
        
        Args:
            upgrade_id: ID of the upgrade to approve
            approver: Who is approving
            
        Returns:
            True if approved successfully
        """
        if upgrade_id not in self.upgrades:
            logger.error(f"Upgrade not found: {upgrade_id}")
            return False
        
        upgrade = self.upgrades[upgrade_id]
        
        if upgrade.status != UpgradeStatus.PROPOSED:
            logger.error(f"Upgrade {upgrade_id} is not in proposed state")
            return False
        
        upgrade.status = UpgradeStatus.APPROVED
        upgrade.approved_at = datetime.now()
        upgrade.approved_by = approver
        
        logger.info(f"Upgrade approved: {upgrade.title} by {approver}")
        
        # Proceed to testing
        await self._test_upgrade(upgrade)
        
        return True
    
    async def reject_upgrade(self, upgrade_id: str, reason: str = "") -> bool:
        """Reject an upgrade proposal"""
        if upgrade_id not in self.upgrades:
            return False
        
        upgrade = self.upgrades[upgrade_id]
        upgrade.status = UpgradeStatus.REJECTED
        
        logger.info(f"Upgrade rejected: {upgrade.title}. Reason: {reason}")
        
        # Move to history
        self.upgrade_history.append(upgrade)
        del self.upgrades[upgrade_id]
        
        return True
    
    # ═══════════════════════════════════════════════════════════════════════════
    # TESTING IN SANDBOX
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _test_upgrade(self, upgrade: Upgrade):
        """Test an upgrade in sandbox environment"""
        logger.info(f"Testing upgrade: {upgrade.title}")
        upgrade.status = UpgradeStatus.TESTING
        
        try:
            if upgrade.upgrade_type == UpgradeType.NEW_PLUGIN:
                success, results = await self._test_plugin(upgrade)
            elif upgrade.upgrade_type == UpgradeType.DEPENDENCY_ADD:
                success, results = await self._test_dependency(upgrade)
            else:
                success, results = await self._test_generic(upgrade)
            
            upgrade.test_results = results
            
            if success:
                upgrade.status = UpgradeStatus.TEST_PASSED
                logger.info(f"Upgrade tests passed: {upgrade.title}")
                
                # Proceed to apply
                await self._apply_upgrade(upgrade)
            else:
                upgrade.status = UpgradeStatus.TEST_FAILED
                logger.warning(f"Upgrade tests failed: {upgrade.title}")
                logger.warning(f"Results: {results}")
                
        except Exception as e:
            upgrade.status = UpgradeStatus.TEST_FAILED
            upgrade.test_results = {"error": str(e), "traceback": traceback.format_exc()}
            logger.error(f"Error testing upgrade: {e}")
    
    async def _test_plugin(self, upgrade: Upgrade) -> Tuple[bool, Dict]:
        """Test a new plugin in sandbox"""
        results = {"tests": [], "passed": 0, "failed": 0}
        
        if not upgrade.code:
            results["error"] = "No code provided"
            return False, results
        
        # Create sandbox plugin directory
        sandbox_plugin_dir = self.sandbox_dir / f"test_{upgrade.id}"
        sandbox_plugin_dir.mkdir(exist_ok=True)
        
        try:
            # Write plugin code
            plugin_file = sandbox_plugin_dir / "plugin.py"
            plugin_file.write_text(upgrade.code)
            
            # Write init
            (sandbox_plugin_dir / "__init__.py").write_text("")
            
            # Write metadata
            metadata = {
                "name": upgrade.title.lower().replace(" ", "_"),
                "version": upgrade.version,
                "description": upgrade.description,
                "author": "SMILE (auto-generated)",
                "plugin_type": "tool",
                "permissions": [],
                "entry_point": "plugin"
            }
            (sandbox_plugin_dir / "plugin.json").write_text(json.dumps(metadata, indent=2))
            
            # Test 1: Syntax check
            try:
                compile(upgrade.code, plugin_file, 'exec')
                results["tests"].append({"name": "syntax", "passed": True})
                results["passed"] += 1
            except SyntaxError as e:
                results["tests"].append({"name": "syntax", "passed": False, "error": str(e)})
                results["failed"] += 1
                return False, results
            
            # Test 2: Import test
            try:
                spec = importlib.util.spec_from_file_location("test_plugin", plugin_file)
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                results["tests"].append({"name": "import", "passed": True})
                results["passed"] += 1
            except Exception as e:
                results["tests"].append({"name": "import", "passed": False, "error": str(e)})
                results["failed"] += 1
                return False, results
            
            # Test 3: Class check
            plugin_class = None
            for name, obj in module.__dict__.items():
                if isinstance(obj, type) and name.endswith('Plugin'):
                    plugin_class = obj
                    break
            
            if plugin_class:
                results["tests"].append({"name": "class_found", "passed": True})
                results["passed"] += 1
            else:
                results["tests"].append({"name": "class_found", "passed": False, 
                                        "error": "No plugin class found"})
                results["failed"] += 1
                return False, results
            
            # Test 4: Method check
            required_methods = ['initialize', 'shutdown']
            for method in required_methods:
                if hasattr(plugin_class, method):
                    results["tests"].append({"name": f"has_{method}", "passed": True})
                    results["passed"] += 1
                else:
                    results["tests"].append({"name": f"has_{method}", "passed": False})
                    results["failed"] += 1
            
            # Test 5: Security check
            security_passed, security_issues = self._security_check(upgrade.code)
            if security_passed:
                results["tests"].append({"name": "security", "passed": True})
                results["passed"] += 1
            else:
                results["tests"].append({"name": "security", "passed": False, 
                                        "issues": security_issues})
                results["failed"] += 1
                return False, results
            
            # All tests passed
            upgrade.target_path = str(self.plugins_dir / metadata["name"])
            return results["failed"] == 0, results
            
        finally:
            # Cleanup sandbox
            shutil.rmtree(sandbox_plugin_dir, ignore_errors=True)
    
    def _security_check(self, code: str) -> Tuple[bool, List[str]]:
        """Perform security check on code"""
        issues = []
        
        # Check for dangerous patterns
        dangerous_patterns = [
            (r'__import__\s*\(', "Dynamic import detected"),
            (r'eval\s*\(', "eval() detected"),
            (r'exec\s*\(', "exec() detected"),
            (r'os\.system\s*\(', "os.system() detected"),
            (r'subprocess\.call\s*\(.*shell\s*=\s*True', "Shell execution detected"),
            (r'open\s*\([^)]*,\s*[\'"]w', "File write detected without context"),
        ]
        
        import re
        for pattern, message in dangerous_patterns:
            if re.search(pattern, code):
                issues.append(message)
        
        # Check for network access without permission
        if 'socket' in code or 'requests' in code or 'urllib' in code:
            if '"network"' not in code and "'network'" not in code:
                issues.append("Network access without declared permission")
        
        return len(issues) == 0, issues
    
    async def _test_dependency(self, upgrade: Upgrade) -> Tuple[bool, Dict]:
        """Test dependency installation"""
        results = {"tests": []}
        
        for dep in upgrade.dependencies:
            try:
                # Try to import first
                importlib.import_module(dep.split("==")[0].split(">=")[0])
                results["tests"].append({"name": f"import_{dep}", "passed": True, 
                                        "note": "Already installed"})
            except ImportError:
                # Would need to install - just validate name for now
                results["tests"].append({"name": f"validate_{dep}", "passed": True})
        
        return all(t["passed"] for t in results["tests"]), results
    
    async def _test_generic(self, upgrade: Upgrade) -> Tuple[bool, Dict]:
        """Generic test for other upgrade types"""
        return True, {"tests": [{"name": "basic", "passed": True}]}
    
    # ═══════════════════════════════════════════════════════════════════════════
    # APPLYING UPGRADES
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _apply_upgrade(self, upgrade: Upgrade):
        """Apply a tested upgrade"""
        logger.info(f"Applying upgrade: {upgrade.title}")
        upgrade.status = UpgradeStatus.APPLYING
        
        try:
            # Create backup
            upgrade.backup_path = await self._create_backup(upgrade)
            upgrade.rollback_available = True
            
            # Apply based on type
            if upgrade.upgrade_type == UpgradeType.NEW_PLUGIN:
                success = await self._apply_plugin(upgrade)
            elif upgrade.upgrade_type == UpgradeType.DEPENDENCY_ADD:
                success = await self._apply_dependency(upgrade)
            elif upgrade.upgrade_type == UpgradeType.KNOWLEDGE_UPDATE:
                success = await self._apply_knowledge(upgrade)
            else:
                success = True  # No-op for now
            
            if success:
                upgrade.status = UpgradeStatus.APPLIED
                upgrade.applied_at = datetime.now()
                self.upgrades_today += 1
                
                # Update version tracking
                if upgrade.target_path:
                    component = f"plugin:{Path(upgrade.target_path).name}"
                    self.versions[component] = VersionInfo(
                        component=component,
                        version=upgrade.version,
                        installed_at=datetime.now(),
                        checksum=self._calculate_checksum(Path(upgrade.target_path))
                    )
                
                # Record in memory
                if self.agent.memory_system:
                    await self.agent.memory_system.record_evolution(
                        event_type=upgrade.upgrade_type.value,
                        description=f"Applied upgrade: {upgrade.title}",
                        after_state={"version": upgrade.version}
                    )
                
                logger.info(f"Upgrade applied successfully: {upgrade.title}")
                
                # Reload plugins if applicable
                if upgrade.upgrade_type == UpgradeType.NEW_PLUGIN:
                    if hasattr(self.agent, 'plugin_system'):
                        plugin_name = Path(upgrade.target_path).name
                        await self.agent.plugin_system._discover_plugins()
                        await self.agent.plugin_system.load_plugin(plugin_name)
            else:
                upgrade.status = UpgradeStatus.FAILED
                logger.error(f"Upgrade failed: {upgrade.title}")
                
                # Attempt rollback
                await self._rollback_upgrade(upgrade)
                
        except Exception as e:
            upgrade.status = UpgradeStatus.FAILED
            logger.error(f"Error applying upgrade: {e}")
            traceback.print_exc()
            
            # Attempt rollback
            await self._rollback_upgrade(upgrade)
        
        finally:
            # Move to history
            self.upgrade_history.append(upgrade)
            if upgrade.id in self.upgrades:
                del self.upgrades[upgrade.id]
            
            # Save history
            await self._save_upgrade_history()
    
    async def _create_backup(self, upgrade: Upgrade) -> str:
        """Create backup before applying upgrade"""
        backup_name = f"{upgrade.id}_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        backup_path = self.backups_dir / backup_name
        backup_path.mkdir(exist_ok=True)
        
        # If upgrading existing component, backup it
        if upgrade.target_path and Path(upgrade.target_path).exists():
            target = Path(upgrade.target_path)
            if target.is_dir():
                shutil.copytree(target, backup_path / target.name)
            else:
                shutil.copy2(target, backup_path)
        
        # Save upgrade info
        (backup_path / "upgrade_info.json").write_text(
            json.dumps(upgrade.to_dict(), indent=2)
        )
        
        return str(backup_path)
    
    async def _apply_plugin(self, upgrade: Upgrade) -> bool:
        """Apply a new plugin"""
        if not upgrade.code or not upgrade.target_path:
            return False
        
        plugin_dir = Path(upgrade.target_path)
        plugin_dir.mkdir(parents=True, exist_ok=True)
        
        # Write plugin code
        (plugin_dir / "plugin.py").write_text(upgrade.code)
        (plugin_dir / "__init__.py").write_text("")
        
        # Write metadata
        metadata = {
            "name": plugin_dir.name,
            "version": upgrade.version,
            "description": upgrade.description,
            "author": "SMILE (auto-generated)",
            "plugin_type": "tool",
            "permissions": [],
            "entry_point": "plugin"
        }
        (plugin_dir / "plugin.json").write_text(json.dumps(metadata, indent=2))
        
        return True
    
    async def _apply_dependency(self, upgrade: Upgrade) -> bool:
        """Install dependencies"""
        for dep in upgrade.dependencies:
            try:
                subprocess.check_call([
                    sys.executable, "-m", "pip", "install", dep,
                    "--quiet", "--disable-pip-version-check"
                ])
            except subprocess.CalledProcessError as e:
                logger.error(f"Failed to install {dep}: {e}")
                return False
        return True
    
    async def _apply_knowledge(self, upgrade: Upgrade) -> bool:
        """Apply knowledge update"""
        if self.agent.memory_system:
            await self.agent.memory_system.store_long_term(
                f"knowledge_{upgrade.id}",
                {
                    "title": upgrade.title,
                    "content": upgrade.description,
                    "source": "upgrade_engine"
                },
                importance=0.8,
                tags=["knowledge", "upgrade"]
            )
        return True
    
    # ═══════════════════════════════════════════════════════════════════════════
    # ROLLBACK
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _rollback_upgrade(self, upgrade: Upgrade) -> bool:
        """Rollback a failed upgrade"""
        if not upgrade.rollback_available or not upgrade.backup_path:
            logger.warning(f"No rollback available for {upgrade.id}")
            return False
        
        logger.info(f"Rolling back upgrade: {upgrade.title}")
        
        try:
            backup_path = Path(upgrade.backup_path)
            
            if upgrade.target_path:
                target = Path(upgrade.target_path)
                
                # Remove failed upgrade
                if target.exists():
                    if target.is_dir():
                        shutil.rmtree(target)
                    else:
                        target.unlink()
                
                # Restore from backup
                for item in backup_path.iterdir():
                    if item.name != "upgrade_info.json":
                        if item.is_dir():
                            shutil.copytree(item, target)
                        else:
                            shutil.copy2(item, target)
            
            upgrade.status = UpgradeStatus.ROLLED_BACK
            logger.info(f"Rollback successful for {upgrade.title}")
            
            return True
            
        except Exception as e:
            logger.error(f"Rollback failed: {e}")
            return False
    
    async def rollback_to_version(self, component: str, version: str) -> bool:
        """Rollback a component to a specific version"""
        # Find backup with matching version
        for backup_dir in self.backups_dir.iterdir():
            if backup_dir.is_dir():
                info_file = backup_dir / "upgrade_info.json"
                if info_file.exists():
                    info = json.loads(info_file.read_text())
                    # Match component and version
                    # Implement version matching logic
                    pass
        
        return False
    
    # ═══════════════════════════════════════════════════════════════════════════
    # SELF-HEALING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def self_heal(self) -> bool:
        """
        Attempt to self-heal from errors
        
        Returns:
            True if healing was successful
        """
        logger.info("Initiating self-healing process...")
        
        healed = False
        
        # Check for broken plugins
        if hasattr(self.agent, 'plugin_system'):
            for plugin_name, plugin_info in self.agent.plugin_system.plugins.items():
                if plugin_info.status.value == "error":
                    logger.info(f"Attempting to heal plugin: {plugin_name}")
                    
                    # Try to reload
                    try:
                        await self.agent.plugin_system.reload_plugin(plugin_name)
                        healed = True
                    except:
                        # Try to restore from backup
                        restored = await self._restore_plugin_from_backup(plugin_name)
                        if restored:
                            healed = True
        
        # Check API health
        if hasattr(self.agent, 'api_manager'):
            await self.agent.api_manager.health_check_all()
        
        logger.info(f"Self-healing complete. Healed: {healed}")
        return healed
    
    async def _restore_plugin_from_backup(self, plugin_name: str) -> bool:
        """Restore a plugin from the most recent backup"""
        for backup_dir in sorted(self.backups_dir.iterdir(), reverse=True):
            if backup_dir.is_dir():
                plugin_backup = backup_dir / plugin_name
                if plugin_backup.exists():
                    target = self.plugins_dir / plugin_name
                    if target.exists():
                        shutil.rmtree(target)
                    shutil.copytree(plugin_backup, target)
                    logger.info(f"Restored plugin {plugin_name} from backup")
                    return True
        return False
    
    # ═══════════════════════════════════════════════════════════════════════════
    # SAVE/LOAD
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _save_upgrade_history(self):
        """Save upgrade history to memory"""
        if self.agent.memory_system:
            history_data = [u.to_dict() for u in self.upgrade_history[-50:]]
            await self.agent.memory_system.store_long_term(
                "upgrade_history",
                history_data,
                importance=0.9,
                tags=["system", "upgrades"]
            )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # STATUS AND REPORTING
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_status(self) -> Dict[str, Any]:
        """Get upgrade engine status"""
        return {
            "pending_upgrades": len([u for u in self.upgrades.values() 
                                    if u.status == UpgradeStatus.PROPOSED]),
            "approved_upgrades": len([u for u in self.upgrades.values() 
                                     if u.status == UpgradeStatus.APPROVED]),
            "applied_today": self.upgrades_today,
            "capability_gaps": len(self.capability_gaps),
            "total_upgrades_applied": len([u for u in self.upgrade_history 
                                          if u.status == UpgradeStatus.APPLIED]),
            "rollbacks": len([u for u in self.upgrade_history 
                            if u.status == UpgradeStatus.ROLLED_BACK]),
            "approval_mode": self.approval_mode.value,
            "component_versions": {k: v.version for k, v in self.versions.items()}
        }
    
    def list_pending_upgrades(self) -> List[Dict]:
        """List pending upgrade proposals"""
        return [
            {
                "id": u.id,
                "title": u.title,
                "type": u.upgrade_type.value,
                "risk_level": u.risk_level,
                "status": u.status.value,
                "reason": u.reason
            }
            for u in self.upgrades.values()
        ]
    
    def list_capability_gaps(self) -> List[Dict]:
        """List detected capability gaps"""
        return [
            {
                "id": gap.id,
                "description": gap.description,
                "occurrences": gap.occurrences,
                "has_proposed_solution": gap.upgrade_id is not None
            }
            for gap in self.capability_gaps.values()
        ]
    
    def get_version_info(self) -> Dict[str, str]:
        """Get version information for all components"""
        return {k: v.version for k, v in self.versions.items()}