#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                          MEMORY SYSTEM - 5-Layer Memory                      ║
║                   Persistent Memory for SMILE AI Agent                       ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Layers:                                                                     ║
║  1. Short-term Memory  - Current conversation context                        ║
║  2. Long-term Memory   - Owner preferences, facts, relationships             ║
║  3. Skill Memory       - Tools created, capabilities learned                 ║
║  4. Learning Memory    - Mistakes, corrections, improvements                 ║
║  5. Goal Memory        - Future improvements, pending tasks                  ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import asyncio
import json
import logging
import hashlib
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Any, List, Optional, Union
from dataclasses import dataclass, field, asdict
from collections import deque
import threading
import re

logger = logging.getLogger("SMILE.Memory")

# ═══════════════════════════════════════════════════════════════════════════════
# DATA STRUCTURES
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class MemoryEntry:
    """Base memory entry structure"""
    id: str
    content: Any
    memory_type: str
    created_at: str
    updated_at: str
    access_count: int = 0
    importance: float = 0.5
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'MemoryEntry':
        return cls(**data)

@dataclass
class ConversationTurn:
    """Single conversation turn"""
    role: str  # 'user' or 'assistant'
    content: str
    timestamp: str
    confidence: float = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class LearningEntry:
    """Entry for learning from mistakes/improvements"""
    id: str
    category: str
    original_action: str
    correction: str
    learned_pattern: str
    created_at: str
    applied_count: int = 0
    
@dataclass
class GoalEntry:
    """Entry for goals and improvements"""
    id: str
    description: str
    priority: int  # 1-5, 5 being highest
    status: str  # 'pending', 'in_progress', 'completed', 'cancelled'
    created_at: str
    target_date: Optional[str] = None
    progress: float = 0.0
    subtasks: List[Dict] = field(default_factory=list)

# ═══════════════════════════════════════════════════════════════════════════════
# MEMORY SYSTEM CORE
# ═══════════════════════════════════════════════════════════════════════════════

class MemorySystem:
    """
    5-Layer Persistent Memory System
    
    Features:
    - Multi-layer memory organization
    - SQLite backend for persistence
    - Semantic search capability
    - Importance-based retention
    - Automatic memory consolidation
    - Thread-safe operations
    """
    
    def __init__(self, memory_dir: Path):
        self.memory_dir = memory_dir
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        
        # Database paths
        self.db_path = memory_dir / "smile_memory.db"
        
        # In-memory caches
        self.short_term: deque = deque(maxlen=100)  # Last 100 turns
        self.long_term_cache: Dict[str, MemoryEntry] = {}
        self.skill_cache: Dict[str, MemoryEntry] = {}
        self.learning_cache: Dict[str, LearningEntry] = {}
        self.goal_cache: Dict[str, GoalEntry] = {}
        
        # Keyword index for semantic search
        self.keyword_index: Dict[str, List[str]] = {}  # keyword -> [memory_ids]
        
        # Lock for thread safety
        self._lock = threading.RLock()
        
        # Stats
        self.stats = {
            "short_term_count": 0,
            "long_term_count": 0,
            "skill_count": 0,
            "learning_count": 0,
            "goal_count": 0,
            "total_searches": 0,
            "last_consolidation": None
        }
        
        logger.info(f"MemorySystem initialized with directory: {memory_dir}")
    
    async def initialize(self):
        """Initialize the memory system"""
        logger.info("Initializing memory system...")
        
        # Initialize SQLite database
        await self._init_database()
        
        # Load caches from database
        await self._load_caches()
        
        # Build keyword index
        await self._build_keyword_index()
        
        logger.info("Memory system initialized successfully")
        logger.info(f"Loaded: {self.stats['long_term_count']} long-term, "
                   f"{self.stats['skill_count']} skills, "
                   f"{self.stats['learning_count']} learnings, "
                   f"{self.stats['goal_count']} goals")
    
    async def _init_database(self):
        """Initialize SQLite database schema"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        
        # Long-term memory table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS long_term_memory (
                id TEXT PRIMARY KEY,
                content TEXT NOT NULL,
                memory_type TEXT,
                created_at TEXT,
                updated_at TEXT,
                access_count INTEGER DEFAULT 0,
                importance REAL DEFAULT 0.5,
                tags TEXT,
                metadata TEXT
            )
        ''')
        
        # Short-term memory table (for persistence across restarts)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS short_term_memory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                timestamp TEXT,
                confidence REAL DEFAULT 1.0,
                metadata TEXT
            )
        ''')
        
        # Skill memory table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS skill_memory (
                id TEXT PRIMARY KEY,
                content TEXT NOT NULL,
                memory_type TEXT DEFAULT 'skill',
                created_at TEXT,
                updated_at TEXT,
                access_count INTEGER DEFAULT 0,
                importance REAL DEFAULT 0.5,
                tags TEXT,
                metadata TEXT
            )
        ''')
        
        # Learning memory table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS learning_memory (
                id TEXT PRIMARY KEY,
                category TEXT,
                original_action TEXT,
                correction TEXT,
                learned_pattern TEXT,
                created_at TEXT,
                applied_count INTEGER DEFAULT 0
            )
        ''')
        
        # Goal memory table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS goal_memory (
                id TEXT PRIMARY KEY,
                description TEXT,
                priority INTEGER DEFAULT 3,
                status TEXT DEFAULT 'pending',
                created_at TEXT,
                target_date TEXT,
                progress REAL DEFAULT 0.0,
                subtasks TEXT
            )
        ''')
        
        # Keyword index table for semantic search
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS keyword_index (
                keyword TEXT,
                memory_id TEXT,
                memory_table TEXT,
                weight REAL DEFAULT 1.0,
                PRIMARY KEY (keyword, memory_id)
            )
        ''')
        
        # Evolution history table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS evolution_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_type TEXT,
                description TEXT,
                before_state TEXT,
                after_state TEXT,
                timestamp TEXT,
                success INTEGER DEFAULT 1
            )
        ''')
        
        conn.commit()
        conn.close()
        
        logger.info("Database schema initialized")
    
    async def _load_caches(self):
        """Load memory caches from database"""
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        try:
            # Load recent short-term memory
            cursor.execute('''
                SELECT * FROM short_term_memory 
                ORDER BY id DESC LIMIT 100
            ''')
            rows = cursor.fetchall()
            for row in reversed(rows):
                self.short_term.append(ConversationTurn(
                    role=row['role'],
                    content=row['content'],
                    timestamp=row['timestamp'],
                    confidence=row['confidence'],
                    metadata=json.loads(row['metadata'] or '{}')
                ))
            self.stats['short_term_count'] = len(self.short_term)
            
            # Load long-term memory
            cursor.execute('SELECT * FROM long_term_memory')
            for row in cursor.fetchall():
                entry = MemoryEntry(
                    id=row['id'],
                    content=json.loads(row['content']),
                    memory_type=row['memory_type'],
                    created_at=row['created_at'],
                    updated_at=row['updated_at'],
                    access_count=row['access_count'],
                    importance=row['importance'],
                    tags=json.loads(row['tags'] or '[]'),
                    metadata=json.loads(row['metadata'] or '{}')
                )
                self.long_term_cache[entry.id] = entry
            self.stats['long_term_count'] = len(self.long_term_cache)
            
            # Load skill memory
            cursor.execute('SELECT * FROM skill_memory')
            for row in cursor.fetchall():
                entry = MemoryEntry(
                    id=row['id'],
                    content=json.loads(row['content']),
                    memory_type='skill',
                    created_at=row['created_at'],
                    updated_at=row['updated_at'],
                    access_count=row['access_count'],
                    importance=row['importance'],
                    tags=json.loads(row['tags'] or '[]'),
                    metadata=json.loads(row['metadata'] or '{}')
                )
                self.skill_cache[entry.id] = entry
            self.stats['skill_count'] = len(self.skill_cache)
            
            # Load learning memory
            cursor.execute('SELECT * FROM learning_memory')
            for row in cursor.fetchall():
                entry = LearningEntry(
                    id=row['id'],
                    category=row['category'],
                    original_action=row['original_action'],
                    correction=row['correction'],
                    learned_pattern=row['learned_pattern'],
                    created_at=row['created_at'],
                    applied_count=row['applied_count']
                )
                self.learning_cache[entry.id] = entry
            self.stats['learning_count'] = len(self.learning_cache)
            
            # Load goal memory
            cursor.execute('SELECT * FROM goal_memory')
            for row in cursor.fetchall():
                entry = GoalEntry(
                    id=row['id'],
                    description=row['description'],
                    priority=row['priority'],
                    status=row['status'],
                    created_at=row['created_at'],
                    target_date=row['target_date'],
                    progress=row['progress'],
                    subtasks=json.loads(row['subtasks'] or '[]')
                )
                self.goal_cache[entry.id] = entry
            self.stats['goal_count'] = len(self.goal_cache)
            
        finally:
            conn.close()
    
    async def _build_keyword_index(self):
        """Build in-memory keyword index for semantic search"""
        # Index long-term memories
        for entry_id, entry in self.long_term_cache.items():
            keywords = self._extract_keywords(str(entry.content))
            for keyword in keywords:
                if keyword not in self.keyword_index:
                    self.keyword_index[keyword] = []
                self.keyword_index[keyword].append(('long_term', entry_id))
        
        # Index skills
        for entry_id, entry in self.skill_cache.items():
            keywords = self._extract_keywords(str(entry.content))
            for keyword in keywords:
                if keyword not in self.keyword_index:
                    self.keyword_index[keyword] = []
                self.keyword_index[keyword].append(('skill', entry_id))
        
        logger.info(f"Built keyword index with {len(self.keyword_index)} keywords")
    
    def _extract_keywords(self, text: str) -> List[str]:
        """Extract keywords from text for indexing"""
        # Simple keyword extraction
        stop_words = {'a', 'an', 'the', 'is', 'are', 'was', 'were', 'be', 'been',
                      'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
                      'could', 'should', 'may', 'might', 'to', 'of', 'in', 'for',
                      'on', 'with', 'at', 'by', 'from', 'as', 'and', 'or', 'but',
                      'if', 'i', 'you', 'he', 'she', 'it', 'we', 'they', 'this',
                      'that', 'these', 'those', 'my', 'your', 'his', 'her', 'its'}
        
        words = re.findall(r'\b\w+\b', text.lower())
        keywords = [w for w in words if w not in stop_words and len(w) > 2]
        return list(set(keywords))[:50]  # Limit to 50 keywords
    
    def _generate_id(self, content: str) -> str:
        """Generate unique ID for memory entry"""
        timestamp = datetime.now().isoformat()
        content_hash = hashlib.md5(f"{content}{timestamp}".encode()).hexdigest()[:12]
        return f"mem_{content_hash}"
    
    # ═══════════════════════════════════════════════════════════════════════════
    # SHORT-TERM MEMORY OPERATIONS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def store_short_term(self, data: Dict[str, Any]):
        """Store a conversation turn in short-term memory"""
        with self._lock:
            turn = ConversationTurn(
                role=data.get('role', 'user'),
                content=data.get('content', ''),
                timestamp=data.get('timestamp', datetime.now().isoformat()),
                confidence=data.get('confidence', 1.0),
                metadata=data.get('metadata', {})
            )
            
            self.short_term.append(turn)
            self.stats['short_term_count'] = len(self.short_term)
            
            # Persist to database
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO short_term_memory (role, content, timestamp, confidence, metadata)
                VALUES (?, ?, ?, ?, ?)
            ''', (turn.role, turn.content, turn.timestamp, 
                  turn.confidence, json.dumps(turn.metadata)))
            conn.commit()
            conn.close()
    
    async def get_short_term_context(self, limit: int = 10) -> List[Dict]:
        """Get recent conversation context"""
        with self._lock:
            recent = list(self.short_term)[-limit:]
            return [
                {
                    "role": turn.role,
                    "content": turn.content,
                    "timestamp": turn.timestamp
                }
                for turn in recent
            ]
    
    async def clear_short_term(self):
        """Clear short-term memory (start fresh conversation)"""
        with self._lock:
            self.short_term.clear()
            self.stats['short_term_count'] = 0
            
            # Clear from database
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            cursor.execute('DELETE FROM short_term_memory')
            conn.commit()
            conn.close()
    
    # ═══════════════════════════════════════════════════════════════════════════
    # LONG-TERM MEMORY OPERATIONS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def store_long_term(self, key: str, content: Any, 
                             importance: float = 0.5,
                             tags: List[str] = None,
                             metadata: Dict = None) -> str:
        """Store information in long-term memory"""
        with self._lock:
            now = datetime.now().isoformat()
            
            # Check if key exists
            if key in self.long_term_cache:
                entry = self.long_term_cache[key]
                entry.content = content
                entry.updated_at = now
                entry.access_count += 1
                if importance:
                    entry.importance = importance
                if tags:
                    entry.tags = tags
                if metadata:
                    entry.metadata.update(metadata)
            else:
                entry = MemoryEntry(
                    id=key,
                    content=content,
                    memory_type='long_term',
                    created_at=now,
                    updated_at=now,
                    access_count=1,
                    importance=importance,
                    tags=tags or [],
                    metadata=metadata or {}
                )
                self.long_term_cache[key] = entry
            
            # Update keyword index
            keywords = self._extract_keywords(str(content))
            for keyword in keywords:
                if keyword not in self.keyword_index:
                    self.keyword_index[keyword] = []
                if ('long_term', key) not in self.keyword_index[keyword]:
                    self.keyword_index[keyword].append(('long_term', key))
            
            # Persist to database
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO long_term_memory 
                (id, content, memory_type, created_at, updated_at, access_count, importance, tags, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (entry.id, json.dumps(entry.content), entry.memory_type,
                  entry.created_at, entry.updated_at, entry.access_count,
                  entry.importance, json.dumps(entry.tags), json.dumps(entry.metadata)))
            conn.commit()
            conn.close()
            
            self.stats['long_term_count'] = len(self.long_term_cache)
            return entry.id
    
    async def retrieve_long_term(self, key: str) -> Optional[Any]:
        """Retrieve information from long-term memory"""
        with self._lock:
            if key in self.long_term_cache:
                entry = self.long_term_cache[key]
                entry.access_count += 1
                return entry.content
            return None
    
    async def search_relevant(self, query: str, limit: int = 10) -> List[Dict]:
        """Search for relevant memories using keyword matching"""
        self.stats['total_searches'] += 1
        
        query_keywords = self._extract_keywords(query)
        if not query_keywords:
            return []
        
        # Score memories based on keyword overlap
        memory_scores: Dict[str, float] = {}
        
        for keyword in query_keywords:
            if keyword in self.keyword_index:
                for memory_type, memory_id in self.keyword_index[keyword]:
                    key = f"{memory_type}:{memory_id}"
                    memory_scores[key] = memory_scores.get(key, 0) + 1
        
        # Sort by score and get top results
        sorted_memories = sorted(memory_scores.items(), key=lambda x: x[1], reverse=True)[:limit]
        
        results = []
        for key, score in sorted_memories:
            memory_type, memory_id = key.split(':', 1)
            
            if memory_type == 'long_term' and memory_id in self.long_term_cache:
                entry = self.long_term_cache[memory_id]
                results.append({
                    "id": memory_id,
                    "content": entry.content,
                    "type": "long_term",
                    "relevance": score / len(query_keywords),
                    "importance": entry.importance
                })
            elif memory_type == 'skill' and memory_id in self.skill_cache:
                entry = self.skill_cache[memory_id]
                results.append({
                    "id": memory_id,
                    "content": entry.content,
                    "type": "skill",
                    "relevance": score / len(query_keywords),
                    "importance": entry.importance
                })
        
        return results
    
    # ═══════════════════════════════════════════════════════════════════════════
    # SKILL MEMORY OPERATIONS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def store_skill(self, skill_id: str, skill_data: Dict,
                         importance: float = 0.7) -> str:
        """Store a learned skill"""
        with self._lock:
            now = datetime.now().isoformat()
            
            entry = MemoryEntry(
                id=skill_id,
                content=skill_data,
                memory_type='skill',
                created_at=now,
                updated_at=now,
                access_count=1,
                importance=importance,
                tags=skill_data.get('tags', []),
                metadata={
                    "tool_name": skill_data.get('name', ''),
                    "version": skill_data.get('version', '1.0'),
                    "source": skill_data.get('source', 'learned')
                }
            )
            
            self.skill_cache[skill_id] = entry
            
            # Update keyword index
            keywords = self._extract_keywords(str(skill_data))
            for keyword in keywords:
                if keyword not in self.keyword_index:
                    self.keyword_index[keyword] = []
                if ('skill', skill_id) not in self.keyword_index[keyword]:
                    self.keyword_index[keyword].append(('skill', skill_id))
            
            # Persist
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO skill_memory 
                (id, content, memory_type, created_at, updated_at, access_count, importance, tags, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (entry.id, json.dumps(entry.content), entry.memory_type,
                  entry.created_at, entry.updated_at, entry.access_count,
                  entry.importance, json.dumps(entry.tags), json.dumps(entry.metadata)))
            conn.commit()
            conn.close()
            
            self.stats['skill_count'] = len(self.skill_cache)
            logger.info(f"Stored skill: {skill_id}")
            return skill_id
    
    async def retrieve_skill(self, skill_id: str) -> Optional[Dict]:
        """Retrieve a skill"""
        with self._lock:
            if skill_id in self.skill_cache:
                return self.skill_cache[skill_id].content
            return None
    
    async def list_skills(self) -> List[Dict]:
        """List all stored skills"""
        return [
            {
                "id": entry.id,
                "name": entry.content.get('name', entry.id),
                "description": entry.content.get('description', ''),
                "created_at": entry.created_at
            }
            for entry in self.skill_cache.values()
        ]
    
    # ═══════════════════════════════════════════════════════════════════════════
    # LEARNING MEMORY OPERATIONS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def store_learning(self, category: str, learning_data: Any,
                            original_action: str = "",
                            correction: str = "") -> str:
        """Store a learning (mistake correction, improvement, pattern)"""
        with self._lock:
            learning_id = self._generate_id(str(learning_data))
            now = datetime.now().isoformat()
            
            entry = LearningEntry(
                id=learning_id,
                category=category,
                original_action=original_action,
                correction=correction,
                learned_pattern=json.dumps(learning_data) if isinstance(learning_data, dict) else str(learning_data),
                created_at=now,
                applied_count=0
            )
            
            self.learning_cache[learning_id] = entry
            
            # Persist
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO learning_memory 
                (id, category, original_action, correction, learned_pattern, created_at, applied_count)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (entry.id, entry.category, entry.original_action,
                  entry.correction, entry.learned_pattern, entry.created_at, entry.applied_count))
            conn.commit()
            conn.close()
            
            self.stats['learning_count'] = len(self.learning_cache)
            logger.info(f"Stored learning: {category}")
            return learning_id
    
    async def retrieve_learning(self, category: str) -> Optional[Any]:
        """Retrieve learnings by category"""
        results = []
        for entry in self.learning_cache.values():
            if entry.category == category:
                try:
                    data = json.loads(entry.learned_pattern)
                except:
                    data = entry.learned_pattern
                results.append(data)
        
        if len(results) == 1:
            return results[0]
        return results if results else None
    
    async def get_learnings_by_category(self, category: str) -> List[LearningEntry]:
        """Get all learning entries for a category"""
        return [
            entry for entry in self.learning_cache.values()
            if entry.category == category
        ]
    
    # ═══════════════════════════════════════════════════════════════════════════
    # GOAL MEMORY OPERATIONS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def store_goal(self, description: str, priority: int = 3,
                        target_date: str = None,
                        subtasks: List[Dict] = None) -> str:
        """Store a goal for future improvement"""
        with self._lock:
            goal_id = self._generate_id(description)
            now = datetime.now().isoformat()
            
            entry = GoalEntry(
                id=goal_id,
                description=description,
                priority=min(max(priority, 1), 5),
                status='pending',
                created_at=now,
                target_date=target_date,
                progress=0.0,
                subtasks=subtasks or []
            )
            
            self.goal_cache[goal_id] = entry
            
            # Persist
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO goal_memory 
                (id, description, priority, status, created_at, target_date, progress, subtasks)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (entry.id, entry.description, entry.priority, entry.status,
                  entry.created_at, entry.target_date, entry.progress, 
                  json.dumps(entry.subtasks)))
            conn.commit()
            conn.close()
            
            self.stats['goal_count'] = len(self.goal_cache)
            logger.info(f"Stored goal: {description[:50]}...")
            return goal_id
    
    async def update_goal_progress(self, goal_id: str, progress: float,
                                   status: str = None):
        """Update goal progress"""
        with self._lock:
            if goal_id in self.goal_cache:
                entry = self.goal_cache[goal_id]
                entry.progress = min(max(progress, 0), 1.0)
                if status:
                    entry.status = status
                
                # Persist
                conn = sqlite3.connect(str(self.db_path))
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE goal_memory SET progress = ?, status = ? WHERE id = ?
                ''', (entry.progress, entry.status, goal_id))
                conn.commit()
                conn.close()
    
    async def get_pending_goals(self, limit: int = 10) -> List[GoalEntry]:
        """Get pending goals sorted by priority"""
        pending = [
            g for g in self.goal_cache.values()
            if g.status in ['pending', 'in_progress']
        ]
        return sorted(pending, key=lambda x: x.priority, reverse=True)[:limit]
    
    async def get_goals_summary(self) -> Dict:
        """Get summary of goals"""
        return {
            "total": len(self.goal_cache),
            "pending": len([g for g in self.goal_cache.values() if g.status == 'pending']),
            "in_progress": len([g for g in self.goal_cache.values() if g.status == 'in_progress']),
            "completed": len([g for g in self.goal_cache.values() if g.status == 'completed']),
        }
    
    # ═══════════════════════════════════════════════════════════════════════════
    # EVOLUTION TRACKING
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def record_evolution(self, event_type: str, description: str,
                              before_state: Dict = None,
                              after_state: Dict = None,
                              success: bool = True):
        """Record an evolution event"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO evolution_history 
            (event_type, description, before_state, after_state, timestamp, success)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (
            event_type, description,
            json.dumps(before_state) if before_state else None,
            json.dumps(after_state) if after_state else None,
            datetime.now().isoformat(),
            1 if success else 0
        ))
        
        conn.commit()
        conn.close()
        
        logger.info(f"Recorded evolution event: {event_type}")
    
    async def get_evolution_history(self, limit: int = 50) -> List[Dict]:
        """Get evolution history"""
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT * FROM evolution_history 
            ORDER BY id DESC LIMIT ?
        ''', (limit,))
        
        rows = cursor.fetchall()
        conn.close()
        
        return [dict(row) for row in rows]
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PERSISTENCE AND MAINTENANCE
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def persist_all(self):
        """Persist all memory to disk"""
        logger.info("Persisting all memory to disk...")
        
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        
        try:
            # Persist long-term memory
            for entry in self.long_term_cache.values():
                cursor.execute('''
                    INSERT OR REPLACE INTO long_term_memory 
                    (id, content, memory_type, created_at, updated_at, access_count, importance, tags, metadata)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (entry.id, json.dumps(entry.content), entry.memory_type,
                      entry.created_at, entry.updated_at, entry.access_count,
                      entry.importance, json.dumps(entry.tags), json.dumps(entry.metadata)))
            
            # Persist skills
            for entry in self.skill_cache.values():
                cursor.execute('''
                    INSERT OR REPLACE INTO skill_memory 
                    (id, content, memory_type, created_at, updated_at, access_count, importance, tags, metadata)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (entry.id, json.dumps(entry.content), entry.memory_type,
                      entry.created_at, entry.updated_at, entry.access_count,
                      entry.importance, json.dumps(entry.tags), json.dumps(entry.metadata)))
            
            conn.commit()
            logger.info("All memory persisted successfully")
            
        except Exception as e:
            logger.error(f"Error persisting memory: {e}")
            conn.rollback()
            raise
        finally:
            conn.close()
    
    async def consolidate_memory(self):
        """Consolidate and optimize memory (remove low-value entries)"""
        logger.info("Starting memory consolidation...")
        
        now = datetime.now()
        
        # Remove old, unimportant short-term entries from database
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        
        # Keep only last 1000 short-term entries
        cursor.execute('''
            DELETE FROM short_term_memory 
            WHERE id NOT IN (
                SELECT id FROM short_term_memory 
                ORDER BY id DESC LIMIT 1000
            )
        ''')
        
        deleted = cursor.rowcount
        conn.commit()
        conn.close()
        
        self.stats['last_consolidation'] = now.isoformat()
        logger.info(f"Memory consolidation complete. Removed {deleted} old entries.")
    
    def get_stats(self) -> Dict:
        """Get memory system statistics"""
        return {
            **self.stats,
            "keyword_count": len(self.keyword_index)
        }
    
    async def export_memory(self, filepath: Path) -> bool:
        """Export all memory to a JSON file for backup"""
        try:
            export_data = {
                "exported_at": datetime.now().isoformat(),
                "version": "1.0",
                "long_term": {k: v.to_dict() for k, v in self.long_term_cache.items()},
                "skills": {k: v.to_dict() for k, v in self.skill_cache.items()},
                "learnings": {k: asdict(v) for k, v in self.learning_cache.items()},
                "goals": {k: asdict(v) for k, v in self.goal_cache.items()},
                "stats": self.stats
            }
            
            with open(filepath, 'w') as f:
                json.dump(export_data, f, indent=2)
            
            logger.info(f"Memory exported to {filepath}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to export memory: {e}")
            return False
    
    async def import_memory(self, filepath: Path) -> bool:
        """Import memory from a backup file"""
        try:
            with open(filepath, 'r') as f:
                import_data = json.load(f)
            
            # Import long-term
            for key, data in import_data.get('long_term', {}).items():
                entry = MemoryEntry.from_dict(data)
                self.long_term_cache[key] = entry
            
            # Import skills
            for key, data in import_data.get('skills', {}).items():
                entry = MemoryEntry.from_dict(data)
                self.skill_cache[key] = entry
            
            # Persist
            await self.persist_all()
            
            # Rebuild index
            await self._build_keyword_index()
            
            logger.info(f"Memory imported from {filepath}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to import memory: {e}")
            return False