#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                        PLUGIN SYSTEM - Dynamic Capability Extension          ║
║                   Modular Plugin Architecture for SMILE Agent                ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Features:                                                                   ║
║  - Dynamic plugin loading/unloading                                          ║
║  - Plugin sandboxing for safety                                              ║
║  - Dependency management                                                     ║
║  - Hot reloading support                                                     ║
║  - Plugin marketplace integration                                            ║
║  - Version management and rollback                                           ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import asyncio
import importlib
import importlib.util
import inspect
import json
import logging
import os
import shutil
import sys
import hashlib
from abc import ABC, abstractmethod
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional, Callable, Type
from dataclasses import dataclass, field, asdict
from enum import Enum, auto
import traceback

logger = logging.getLogger("SMILE.PluginSystem")

# ═══════════════════════════════════════════════════════════════════════════════
# PLUGIN BASE CLASSES AND INTERFACES
# ═══════════════════════════════════════════════════════════════════════════════

class PluginType(Enum):
    """Types of plugins"""
    TOOL = "tool"                    # Provides tools/functions
    INTEGRATION = "integration"      # External service integration
    PROCESSOR = "processor"          # Data processing
    UI = "ui"                        # UI enhancement
    CORE_EXTENSION = "core_extension" # Core functionality extension
    UTILITY = "utility"              # Utility functions

class PluginStatus(Enum):
    """Plugin lifecycle status"""
    DISCOVERED = "discovered"
    LOADING = "loading"
    ACTIVE = "active"
    DISABLED = "disabled"
    ERROR = "error"
    UNLOADING = "unloading"

@dataclass
class PluginMetadata:
    """Plugin metadata descriptor"""
    name: str
    version: str
    description: str
    author: str
    plugin_type: PluginType
    dependencies: List[str] = field(default_factory=list)
    python_requires: str = ">=3.8"
    permissions: List[str] = field(default_factory=list)
    entry_point: str = "plugin"
    config_schema: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        data = asdict(self)
        data['plugin_type'] = self.plugin_type.value
        return data
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'PluginMetadata':
        data['plugin_type'] = PluginType(data['plugin_type'])
        return cls(**data)

@dataclass
class PluginInfo:
    """Runtime plugin information"""
    metadata: PluginMetadata
    status: PluginStatus
    path: Path
    instance: Optional[Any] = None
    loaded_at: Optional[datetime] = None
    error: Optional[str] = None
    config: Dict[str, Any] = field(default_factory=dict)
    provided_tools: List[str] = field(default_factory=list)
    checksum: str = ""

class BasePlugin(ABC):
    """
    Base class for all SMILE plugins
    
    All plugins must inherit from this class and implement
    the required abstract methods.
    """
    
    # Plugin metadata - override in subclass
    METADATA = PluginMetadata(
        name="BasePlugin",
        version="1.0.0",
        description="Base plugin class",
        author="SMILE",
        plugin_type=PluginType.UTILITY
    )
    
    def __init__(self, agent: Any, config: Dict[str, Any] = None):
        """
        Initialize plugin
        
        Args:
            agent: Reference to the main SMILE agent
            config: Plugin configuration dict
        """
        self.agent = agent
        self.config = config or {}
        self.tools: Dict[str, Callable] = {}
        self.logger = logging.getLogger(f"SMILE.Plugin.{self.METADATA.name}")
        self._initialized = False
    
    @abstractmethod
    async def initialize(self) -> bool:
        """
        Initialize the plugin
        
        Returns:
            True if initialization successful, False otherwise
        """
        pass
    
    @abstractmethod
    async def shutdown(self) -> bool:
        """
        Shutdown the plugin gracefully
        
        Returns:
            True if shutdown successful, False otherwise
        """
        pass
    
    def register_tool(self, name: str, func: Callable, 
                     description: str = ""):
        """Register a tool provided by this plugin"""
        self.tools[name] = func
        func.__doc__ = description or func.__doc__
        self.logger.info(f"Registered tool: {name}")
    
    def get_tools(self) -> Dict[str, Callable]:
        """Get all tools provided by this plugin"""
        return self.tools
    
    async def on_message(self, message: Dict[str, Any]) -> Optional[Dict]:
        """
        Hook called when agent receives a message
        
        Override to intercept/process messages
        """
        return None
    
    async def on_response(self, response: Dict[str, Any]) -> Optional[Dict]:
        """
        Hook called before agent sends a response
        
        Override to modify/enhance responses
        """
        return None
    
    async def on_upgrade(self, from_version: str, to_version: str) -> bool:
        """
        Hook called when plugin is being upgraded
        
        Override to handle data migration
        """
        return True
    
    def get_status(self) -> Dict[str, Any]:
        """Get plugin status information"""
        return {
            "name": self.METADATA.name,
            "version": self.METADATA.version,
            "initialized": self._initialized,
            "tools_count": len(self.tools)
        }

# ═══════════════════════════════════════════════════════════════════════════════
# PLUGIN SANDBOX
# ═══════════════════════════════════════════════════════════════════════════════

class PluginSandbox:
    """
    Sandbox environment for plugin execution
    
    Provides isolated execution context and resource limits
    """
    
    def __init__(self, plugin_name: str, permissions: List[str]):
        self.plugin_name = plugin_name
        self.permissions = set(permissions)
        self.allowed_modules = {
            'json', 'datetime', 'typing', 'dataclasses',
            'asyncio', 'logging', 're', 'math', 'random',
            'collections', 'itertools', 'functools',
            'pathlib', 'hashlib', 'base64', 'urllib.parse'
        }
        
        # Add permissions-based modules
        if 'network' in self.permissions:
            self.allowed_modules.update({'aiohttp', 'requests', 'urllib'})
        if 'filesystem' in self.permissions:
            self.allowed_modules.update({'os', 'shutil'})
        if 'subprocess' in self.permissions:
            self.allowed_modules.add('subprocess')
    
    def check_import(self, module_name: str) -> bool:
        """Check if module import is allowed"""
        base_module = module_name.split('.')[0]
        return base_module in self.allowed_modules
    
    def validate_code(self, code: str) -> Tuple[bool, str]:
        """
        Validate plugin code for safety
        
        Returns:
            Tuple of (is_safe, error_message)
        """
        dangerous_patterns = [
            'eval(', 'exec(', '__import__',
            'compile(', 'open(', 'os.system',
            'subprocess.', 'shutil.rmtree'
        ]
        
        # Check for dangerous patterns if permissions not granted
        if 'filesystem' not in self.permissions:
            dangerous_patterns.extend(['open(', 'os.remove', 'os.unlink'])
        
        if 'subprocess' not in self.permissions:
            dangerous_patterns.extend(['subprocess', 'os.system', 'os.popen'])
        
        for pattern in dangerous_patterns:
            if pattern in code:
                return False, f"Dangerous pattern detected: {pattern}"
        
        return True, ""

# ═══════════════════════════════════════════════════════════════════════════════
# PLUGIN SYSTEM CORE
# ═══════════════════════════════════════════════════════════════════════════════

class PluginSystem:
    """
    Dynamic Plugin Management System
    
    Handles:
    - Plugin discovery and loading
    - Lifecycle management
    - Tool aggregation
    - Hot reloading
    - Version management
    """
    
    def __init__(self, plugins_dir: Path, agent: Any):
        """
        Initialize Plugin System
        
        Args:
            plugins_dir: Directory containing plugins
            agent: Reference to main SMILE agent
        """
        self.plugins_dir = plugins_dir
        self.agent = agent
        self.plugins: Dict[str, PluginInfo] = {}
        self.tools: Dict[str, Callable] = {}
        self.tool_to_plugin: Dict[str, str] = {}
        
        # Plugin hooks
        self.message_hooks: List[Callable] = []
        self.response_hooks: List[Callable] = []
        
        # Backup directory for rollbacks
        self.backups_dir = plugins_dir.parent / "backups" / "plugins"
        self.backups_dir.mkdir(parents=True, exist_ok=True)
        
        # Plugin registry for updates
        self.registry_url = "https://smile-plugins.example.com/registry"
        
        logger.info(f"PluginSystem initialized with directory: {plugins_dir}")
    
    async def initialize(self):
        """Initialize the plugin system"""
        logger.info("Initializing Plugin System...")
        
        # Ensure plugins directory exists
        self.plugins_dir.mkdir(parents=True, exist_ok=True)
        
        # Create __init__.py if not exists
        init_file = self.plugins_dir / "__init__.py"
        if not init_file.exists():
            init_file.write_text("# SMILE Plugins Package\n")
        
        # Add plugins directory to path
        if str(self.plugins_dir.parent) not in sys.path:
            sys.path.insert(0, str(self.plugins_dir.parent))
        
        # Discover and load plugins
        await self._discover_plugins()
        await self._load_all_plugins()
        
        # Create default plugins if none exist
        if not self.plugins:
            await self._create_default_plugins()
            await self._discover_plugins()
            await self._load_all_plugins()
        
        logger.info(f"Plugin System initialized with {len(self.plugins)} plugins")
    
    async def _discover_plugins(self):
        """Discover available plugins in the plugins directory"""
        logger.info("Discovering plugins...")
        
        for item in self.plugins_dir.iterdir():
            if item.is_dir() and not item.name.startswith('_'):
                # Look for plugin.json or metadata.json
                metadata_file = item / "plugin.json"
                if not metadata_file.exists():
                    metadata_file = item / "metadata.json"
                
                if metadata_file.exists():
                    try:
                        with open(metadata_file) as f:
                            metadata_dict = json.load(f)
                        
                        metadata = PluginMetadata.from_dict(metadata_dict)
                        
                        # Calculate checksum
                        checksum = self._calculate_plugin_checksum(item)
                        
                        plugin_info = PluginInfo(
                            metadata=metadata,
                            status=PluginStatus.DISCOVERED,
                            path=item,
                            checksum=checksum
                        )
                        
                        self.plugins[metadata.name] = plugin_info
                        logger.info(f"Discovered plugin: {metadata.name} v{metadata.version}")
                        
                    except Exception as e:
                        logger.error(f"Failed to load metadata for {item.name}: {e}")
            
            elif item.is_file() and item.suffix == '.py' and not item.name.startswith('_'):
                # Single-file plugin
                try:
                    metadata = await self._extract_metadata_from_file(item)
                    if metadata:
                        checksum = hashlib.md5(item.read_bytes()).hexdigest()
                        
                        plugin_info = PluginInfo(
                            metadata=metadata,
                            status=PluginStatus.DISCOVERED,
                            path=item,
                            checksum=checksum
                        )
                        
                        self.plugins[metadata.name] = plugin_info
                        logger.info(f"Discovered single-file plugin: {metadata.name}")
                        
                except Exception as e:
                    logger.error(f"Failed to process {item.name}: {e}")
    
    async def _extract_metadata_from_file(self, filepath: Path) -> Optional[PluginMetadata]:
        """Extract metadata from a single-file plugin"""
        try:
            content = filepath.read_text()
            
            # Try to find METADATA in the file
            spec = importlib.util.spec_from_file_location(
                filepath.stem, filepath
            )
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            
            # Look for plugin class
            for name, obj in inspect.getmembers(module):
                if inspect.isclass(obj) and issubclass(obj, BasePlugin) and obj != BasePlugin:
                    return obj.METADATA
            
            return None
            
        except Exception as e:
            logger.debug(f"Could not extract metadata from {filepath}: {e}")
            return None
    
    def _calculate_plugin_checksum(self, plugin_dir: Path) -> str:
        """Calculate checksum for plugin directory"""
        checksums = []
        for file in sorted(plugin_dir.rglob('*.py')):
            checksums.append(hashlib.md5(file.read_bytes()).hexdigest())
        return hashlib.md5(''.join(checksums).encode()).hexdigest()
    
    async def _load_all_plugins(self):
        """Load all discovered plugins"""
        for plugin_name, plugin_info in self.plugins.items():
            if plugin_info.status == PluginStatus.DISCOVERED:
                await self.load_plugin(plugin_name)
    
    async def load_plugin(self, plugin_name: str) -> bool:
        """
        Load a specific plugin
        
        Args:
            plugin_name: Name of the plugin to load
            
        Returns:
            True if loaded successfully
        """
        if plugin_name not in self.plugins:
            logger.error(f"Plugin not found: {plugin_name}")
            return False
        
        plugin_info = self.plugins[plugin_name]
        plugin_info.status = PluginStatus.LOADING
        
        try:
            # Check dependencies
            for dep in plugin_info.metadata.dependencies:
                if dep not in self.plugins or \
                   self.plugins[dep].status != PluginStatus.ACTIVE:
                    logger.warning(f"Missing dependency {dep} for {plugin_name}")
            
            # Load the plugin module
            if plugin_info.path.is_dir():
                module_path = plugin_info.path / f"{plugin_info.metadata.entry_point}.py"
                if not module_path.exists():
                    module_path = plugin_info.path / "__init__.py"
            else:
                module_path = plugin_info.path
            
            spec = importlib.util.spec_from_file_location(
                f"plugins.{plugin_name}",
                module_path
            )
            module = importlib.util.module_from_spec(spec)
            sys.modules[f"plugins.{plugin_name}"] = module
            spec.loader.exec_module(module)
            
            # Find plugin class
            plugin_class = None
            for name, obj in inspect.getmembers(module):
                if inspect.isclass(obj) and issubclass(obj, BasePlugin) and obj != BasePlugin:
                    plugin_class = obj
                    break
            
            if not plugin_class:
                raise ValueError(f"No plugin class found in {plugin_name}")
            
            # Load plugin config
            config = await self._load_plugin_config(plugin_info)
            
            # Create sandbox
            sandbox = PluginSandbox(
                plugin_name, 
                plugin_info.metadata.permissions
            )
            
            # Instantiate plugin
            instance = plugin_class(self.agent, config)
            
            # Initialize plugin
            success = await instance.initialize()
            
            if success:
                plugin_info.instance = instance
                plugin_info.status = PluginStatus.ACTIVE
                plugin_info.loaded_at = datetime.now()
                plugin_info.config = config
                
                # Register tools
                tools = instance.get_tools()
                for tool_name, tool_func in tools.items():
                    full_name = f"{plugin_name}.{tool_name}"
                    self.tools[full_name] = tool_func
                    self.tool_to_plugin[full_name] = plugin_name
                    plugin_info.provided_tools.append(full_name)
                
                # Register hooks
                if hasattr(instance, 'on_message'):
                    self.message_hooks.append(instance.on_message)
                if hasattr(instance, 'on_response'):
                    self.response_hooks.append(instance.on_response)
                
                logger.info(f"✓ Loaded plugin: {plugin_name} ({len(tools)} tools)")
                return True
            else:
                plugin_info.status = PluginStatus.ERROR
                plugin_info.error = "Initialization returned False"
                return False
                
        except Exception as e:
            logger.error(f"Failed to load plugin {plugin_name}: {e}")
            logger.error(traceback.format_exc())
            plugin_info.status = PluginStatus.ERROR
            plugin_info.error = str(e)
            return False
    
    async def unload_plugin(self, plugin_name: str) -> bool:
        """
        Unload a plugin
        
        Args:
            plugin_name: Name of the plugin to unload
            
        Returns:
            True if unloaded successfully
        """
        if plugin_name not in self.plugins:
            return False
        
        plugin_info = self.plugins[plugin_name]
        
        if plugin_info.status != PluginStatus.ACTIVE:
            return False
        
        plugin_info.status = PluginStatus.UNLOADING
        
        try:
            # Shutdown plugin
            if plugin_info.instance:
                await plugin_info.instance.shutdown()
            
            # Remove tools
            for tool_name in plugin_info.provided_tools:
                if tool_name in self.tools:
                    del self.tools[tool_name]
                if tool_name in self.tool_to_plugin:
                    del self.tool_to_plugin[tool_name]
            
            # Remove hooks
            if plugin_info.instance:
                if plugin_info.instance.on_message in self.message_hooks:
                    self.message_hooks.remove(plugin_info.instance.on_message)
                if plugin_info.instance.on_response in self.response_hooks:
                    self.response_hooks.remove(plugin_info.instance.on_response)
            
            # Clean up
            plugin_info.instance = None
            plugin_info.provided_tools = []
            plugin_info.status = PluginStatus.DISABLED
            
            # Remove from sys.modules
            module_name = f"plugins.{plugin_name}"
            if module_name in sys.modules:
                del sys.modules[module_name]
            
            logger.info(f"Unloaded plugin: {plugin_name}")
            return True
            
        except Exception as e:
            logger.error(f"Error unloading plugin {plugin_name}: {e}")
            plugin_info.status = PluginStatus.ERROR
            plugin_info.error = str(e)
            return False
    
    async def reload_plugin(self, plugin_name: str) -> bool:
        """Hot reload a plugin"""
        logger.info(f"Reloading plugin: {plugin_name}")
        
        # Backup current state
        old_checksum = self.plugins.get(plugin_name, {}).checksum
        
        # Unload
        await self.unload_plugin(plugin_name)
        
        # Rediscover (in case files changed)
        await self._discover_plugins()
        
        # Reload
        success = await self.load_plugin(plugin_name)
        
        if not success:
            logger.error(f"Failed to reload plugin: {plugin_name}")
        
        return success
    
    async def _load_plugin_config(self, plugin_info: PluginInfo) -> Dict[str, Any]:
        """Load plugin configuration"""
        config_file = plugin_info.path / "config.json" if plugin_info.path.is_dir() else \
                     plugin_info.path.parent / f"{plugin_info.path.stem}_config.json"
        
        if config_file.exists():
            try:
                with open(config_file) as f:
                    return json.load(f)
            except Exception as e:
                logger.warning(f"Failed to load config for {plugin_info.metadata.name}: {e}")
        
        return {}
    
    async def _create_default_plugins(self):
        """Create essential default plugins"""
        logger.info("Creating default plugins...")
        
        # Web Search Plugin
        await self._create_web_search_plugin()
        
        # File Manager Plugin
        await self._create_file_manager_plugin()
        
        # Code Executor Plugin
        await self._create_code_executor_plugin()
        
        # Calculator Plugin
        await self._create_calculator_plugin()
        
        logger.info("Default plugins created")
    
    async def _create_web_search_plugin(self):
        """Create the web search plugin"""
        plugin_dir = self.plugins_dir / "web_search"
        plugin_dir.mkdir(exist_ok=True)
        
        # Metadata
        metadata = {
            "name": "web_search",
            "version": "1.0.0",
            "description": "Web search capability using DuckDuckGo",
            "author": "SMILE",
            "plugin_type": "tool",
            "dependencies": [],
            "permissions": ["network"],
            "entry_point": "plugin"
        }
        
        with open(plugin_dir / "plugin.json", 'w') as f:
            json.dump(metadata, f, indent=2)
        
        # Plugin code
        plugin_code = '''#!/usr/bin/env python3
"""Web Search Plugin for SMILE Agent"""

import aiohttp
import urllib.parse
from typing import Dict, Any, List
from core.plugin_system import BasePlugin, PluginMetadata, PluginType


class WebSearchPlugin(BasePlugin):
    """Plugin providing web search capabilities"""
    
    METADATA = PluginMetadata(
        name="web_search",
        version="1.0.0",
        description="Web search capability using DuckDuckGo",
        author="SMILE",
        plugin_type=PluginType.TOOL,
        permissions=["network"]
    )
    
    def __init__(self, agent, config=None):
        super().__init__(agent, config)
        self.search_url = "https://api.duckduckgo.com/"
        self.session = None
    
    async def initialize(self) -> bool:
        """Initialize the web search plugin"""
        self.session = aiohttp.ClientSession()
        
        # Register tools
        self.register_tool(
            "search",
            self.search,
            "Search the web for information"
        )
        self.register_tool(
            "search_news",
            self.search_news,
            "Search for recent news articles"
        )
        
        self._initialized = True
        self.logger.info("Web Search Plugin initialized")
        return True
    
    async def shutdown(self) -> bool:
        """Shutdown the plugin"""
        if self.session:
            await self.session.close()
        return True
    
    async def search(self, query: str, num_results: int = 5) -> List[Dict[str, Any]]:
        """
        Search the web for information
        
        Args:
            query: Search query string
            num_results: Maximum number of results to return
            
        Returns:
            List of search results with title, url, and snippet
        """
        try:
            params = {
                "q": query,
                "format": "json",
                "no_html": "1",
                "skip_disambig": "1"
            }
            
            async with self.session.get(self.search_url, params=params) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    
                    results = []
                    
                    # Abstract (main result)
                    if data.get("Abstract"):
                        results.append({
                            "title": data.get("Heading", "Result"),
                            "url": data.get("AbstractURL", ""),
                            "snippet": data.get("Abstract", ""),
                            "source": data.get("AbstractSource", "")
                        })
                    
                    # Related topics
                    for topic in data.get("RelatedTopics", [])[:num_results-1]:
                        if isinstance(topic, dict) and "Text" in topic:
                            results.append({
                                "title": topic.get("Text", "")[:100],
                                "url": topic.get("FirstURL", ""),
                                "snippet": topic.get("Text", ""),
                                "source": "DuckDuckGo"
                            })
                    
                    self.logger.info(f"Search returned {len(results)} results for: {query}")
                    return results
                else:
                    self.logger.error(f"Search failed with status {resp.status}")
                    return []
                    
        except Exception as e:
            self.logger.error(f"Search error: {e}")
            return []
    
    async def search_news(self, query: str, num_results: int = 5) -> List[Dict[str, Any]]:
        """
        Search for recent news articles
        
        Args:
            query: News search query
            num_results: Maximum number of results
            
        Returns:
            List of news articles
        """
        # Add news-related terms to query
        news_query = f"{query} news latest"
        return await self.search(news_query, num_results)
'''
        
        with open(plugin_dir / "plugin.py", 'w') as f:
            f.write(plugin_code)
        
        (plugin_dir / "__init__.py").write_text(
            "from .plugin import WebSearchPlugin\n"
        )
    
    async def _create_file_manager_plugin(self):
        """Create the file manager plugin"""
        plugin_dir = self.plugins_dir / "file_manager"
        plugin_dir.mkdir(exist_ok=True)
        
        metadata = {
            "name": "file_manager",
            "version": "1.0.0",
            "description": "File system operations",
            "author": "SMILE",
            "plugin_type": "tool",
            "dependencies": [],
            "permissions": ["filesystem"],
            "entry_point": "plugin"
        }
        
        with open(plugin_dir / "plugin.json", 'w') as f:
            json.dump(metadata, f, indent=2)
        
        plugin_code = '''#!/usr/bin/env python3
"""File Manager Plugin for SMILE Agent"""

import os
import json
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime
from core.plugin_system import BasePlugin, PluginMetadata, PluginType


class FileManagerPlugin(BasePlugin):
    """Plugin providing file system operations"""
    
    METADATA = PluginMetadata(
        name="file_manager",
        version="1.0.0",
        description="File system operations",
        author="SMILE",
        plugin_type=PluginType.TOOL,
        permissions=["filesystem"]
    )
    
    def __init__(self, agent, config=None):
        super().__init__(agent, config)
        self.workspace = Path(config.get("workspace", ".")) if config else Path(".")
        self.allowed_extensions = config.get("allowed_extensions", None) if config else None
    
    async def initialize(self) -> bool:
        """Initialize the file manager plugin"""
        self.register_tool("read_file", self.read_file, "Read contents of a file")
        self.register_tool("write_file", self.write_file, "Write content to a file")
        self.register_tool("list_directory", self.list_directory, "List directory contents")
        self.register_tool("file_info", self.file_info, "Get file information")
        self.register_tool("search_files", self.search_files, "Search for files by pattern")
        
        self._initialized = True
        self.logger.info("File Manager Plugin initialized")
        return True
    
    async def shutdown(self) -> bool:
        return True
    
    def _validate_path(self, filepath: str) -> Path:
        """Validate and resolve file path"""
        path = Path(filepath)
        
        # Security: prevent path traversal
        try:
            resolved = path.resolve()
            workspace_resolved = self.workspace.resolve()
            
            # Check if path is within workspace
            resolved.relative_to(workspace_resolved)
            
            return resolved
        except ValueError:
            raise PermissionError(f"Access denied: {filepath} is outside workspace")
    
    async def read_file(self, filepath: str, encoding: str = "utf-8") -> Dict[str, Any]:
        """
        Read contents of a file
        
        Args:
            filepath: Path to the file
            encoding: File encoding (default: utf-8)
            
        Returns:
            Dict with file content and metadata
        """
        try:
            path = self._validate_path(filepath)
            
            if not path.exists():
                return {"success": False, "error": "File not found"}
            
            if not path.is_file():
                return {"success": False, "error": "Not a file"}
            
            content = path.read_text(encoding=encoding)
            
            return {
                "success": True,
                "content": content,
                "path": str(path),
                "size": path.stat().st_size,
                "lines": len(content.splitlines())
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def write_file(self, filepath: str, content: str, 
                        encoding: str = "utf-8") -> Dict[str, Any]:
        """
        Write content to a file
        
        Args:
            filepath: Path to the file
            content: Content to write
            encoding: File encoding (default: utf-8)
            
        Returns:
            Dict with operation result
        """
        try:
            path = self._validate_path(filepath)
            
            # Create parent directories if needed
            path.parent.mkdir(parents=True, exist_ok=True)
            
            # Backup if file exists
            if path.exists():
                backup_path = path.with_suffix(path.suffix + ".bak")
                path.rename(backup_path)
            
            path.write_text(content, encoding=encoding)
            
            return {
                "success": True,
                "path": str(path),
                "size": len(content),
                "lines": len(content.splitlines())
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def list_directory(self, dirpath: str = ".") -> Dict[str, Any]:
        """
        List directory contents
        
        Args:
            dirpath: Path to directory
            
        Returns:
            Dict with directory listing
        """
        try:
            path = self._validate_path(dirpath)
            
            if not path.is_dir():
                return {"success": False, "error": "Not a directory"}
            
            items = []
            for item in sorted(path.iterdir()):
                stat = item.stat()
                items.append({
                    "name": item.name,
                    "type": "directory" if item.is_dir() else "file",
                    "size": stat.st_size if item.is_file() else None,
                    "modified": datetime.fromtimestamp(stat.st_mtime).isoformat()
                })
            
            return {
                "success": True,
                "path": str(path),
                "items": items,
                "count": len(items)
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def file_info(self, filepath: str) -> Dict[str, Any]:
        """Get detailed file information"""
        try:
            path = self._validate_path(filepath)
            
            if not path.exists():
                return {"success": False, "error": "File not found"}
            
            stat = path.stat()
            
            return {
                "success": True,
                "path": str(path),
                "name": path.name,
                "extension": path.suffix,
                "size": stat.st_size,
                "created": datetime.fromtimestamp(stat.st_ctime).isoformat(),
                "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                "is_file": path.is_file(),
                "is_directory": path.is_dir()
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def search_files(self, pattern: str, directory: str = ".") -> Dict[str, Any]:
        """Search for files matching pattern"""
        try:
            path = self._validate_path(directory)
            
            matches = list(path.rglob(pattern))
            
            return {
                "success": True,
                "pattern": pattern,
                "matches": [str(m.relative_to(path)) for m in matches[:100]],
                "count": len(matches)
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
'''
        
        with open(plugin_dir / "plugin.py", 'w') as f:
            f.write(plugin_code)
        
        (plugin_dir / "__init__.py").write_text(
            "from .plugin import FileManagerPlugin\n"
        )
    
    async def _create_code_executor_plugin(self):
        """Create the code executor plugin"""
        plugin_dir = self.plugins_dir / "code_executor"
        plugin_dir.mkdir(exist_ok=True)
        
        metadata = {
            "name": "code_executor",
            "version": "1.0.0",
            "description": "Safe Python code execution in sandbox",
            "author": "SMILE",
            "plugin_type": "tool",
            "dependencies": [],
            "permissions": ["subprocess"],
            "entry_point": "plugin"
        }
        
        with open(plugin_dir / "plugin.json", 'w') as f:
            json.dump(metadata, f, indent=2)
        
        plugin_code = '''#!/usr/bin/env python3
"""Code Executor Plugin for SMILE Agent"""

import asyncio
import subprocess
import tempfile
import os
from pathlib import Path
from typing import Dict, Any
from core.plugin_system import BasePlugin, PluginMetadata, PluginType


class CodeExecutorPlugin(BasePlugin):
    """Plugin providing safe code execution"""
    
    METADATA = PluginMetadata(
        name="code_executor",
        version="1.0.0",
        description="Safe Python code execution in sandbox",
        author="SMILE",
        plugin_type=PluginType.TOOL,
        permissions=["subprocess"]
    )
    
    def __init__(self, agent, config=None):
        super().__init__(agent, config)
        self.timeout = config.get("timeout", 30) if config else 30
        self.max_output = config.get("max_output", 10000) if config else 10000
    
    async def initialize(self) -> bool:
        """Initialize the code executor plugin"""
        self.register_tool("execute_python", self.execute_python, "Execute Python code safely")
        self.register_tool("execute_shell", self.execute_shell, "Execute shell command")
        
        self._initialized = True
        self.logger.info("Code Executor Plugin initialized")
        return True
    
    async def shutdown(self) -> bool:
        return True
    
    async def execute_python(self, code: str, timeout: int = None) -> Dict[str, Any]:
        """
        Execute Python code in a sandboxed environment
        
        Args:
            code: Python code to execute
            timeout: Execution timeout in seconds
            
        Returns:
            Dict with execution results
        """
        timeout = timeout or self.timeout
        
        # Create temporary file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
            f.write(code)
            temp_file = f.name
        
        try:
            # Execute in subprocess with timeout
            process = await asyncio.create_subprocess_exec(
                'python', temp_file,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=timeout
                )
                
                return {
                    "success": process.returncode == 0,
                    "stdout": stdout.decode()[:self.max_output],
                    "stderr": stderr.decode()[:self.max_output],
                    "return_code": process.returncode
                }
                
            except asyncio.TimeoutError:
                process.kill()
                return {
                    "success": False,
                    "error": f"Execution timed out after {timeout} seconds",
                    "stdout": "",
                    "stderr": ""
                }
                
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "stdout": "",
                "stderr": ""
            }
        finally:
            os.unlink(temp_file)
    
    async def execute_shell(self, command: str, timeout: int = None) -> Dict[str, Any]:
        """
        Execute a shell command
        
        Args:
            command: Shell command to execute
            timeout: Execution timeout in seconds
            
        Returns:
            Dict with execution results
        """
        timeout = timeout or self.timeout
        
        # Security: block dangerous commands
        dangerous = ["rm -rf", "mkfs", "dd if=", "> /dev/", "chmod 777"]
        for pattern in dangerous:
            if pattern in command.lower():
                return {
                    "success": False,
                    "error": f"Blocked dangerous command pattern: {pattern}"
                }
        
        try:
            process = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=timeout
                )
                
                return {
                    "success": process.returncode == 0,
                    "stdout": stdout.decode()[:self.max_output],
                    "stderr": stderr.decode()[:self.max_output],
                    "return_code": process.returncode
                }
                
            except asyncio.TimeoutError:
                process.kill()
                return {
                    "success": False,
                    "error": f"Execution timed out after {timeout} seconds"
                }
                
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
'''
        
        with open(plugin_dir / "plugin.py", 'w') as f:
            f.write(plugin_code)
        
        (plugin_dir / "__init__.py").write_text(
            "from .plugin import CodeExecutorPlugin\n"
        )
    
    async def _create_calculator_plugin(self):
        """Create a simple calculator plugin"""
        plugin_dir = self.plugins_dir / "calculator"
        plugin_dir.mkdir(exist_ok=True)
        
        metadata = {
            "name": "calculator",
            "version": "1.0.0",
            "description": "Mathematical calculations",
            "author": "SMILE",
            "plugin_type": "tool",
            "dependencies": [],
            "permissions": [],
            "entry_point": "plugin"
        }
        
        with open(plugin_dir / "plugin.json", 'w') as f:
            json.dump(metadata, f, indent=2)
        
        plugin_code = '''#!/usr/bin/env python3
"""Calculator Plugin for SMILE Agent"""

import math
import ast
import operator
from typing import Dict, Any, Union
from core.plugin_system import BasePlugin, PluginMetadata, PluginType


class CalculatorPlugin(BasePlugin):
    """Plugin providing mathematical calculations"""
    
    METADATA = PluginMetadata(
        name="calculator",
        version="1.0.0",
        description="Mathematical calculations",
        author="SMILE",
        plugin_type=PluginType.TOOL,
        permissions=[]
    )
    
    # Safe operators
    OPERATORS = {
        ast.Add: operator.add,
        ast.Sub: operator.sub,
        ast.Mult: operator.mul,
        ast.Div: operator.truediv,
        ast.FloorDiv: operator.floordiv,
        ast.Mod: operator.mod,
        ast.Pow: operator.pow,
        ast.USub: operator.neg,
        ast.UAdd: operator.pos,
    }
    
    # Safe functions
    FUNCTIONS = {
        'abs': abs,
        'round': round,
        'min': min,
        'max': max,
        'sum': sum,
        'sqrt': math.sqrt,
        'sin': math.sin,
        'cos': math.cos,
        'tan': math.tan,
        'log': math.log,
        'log10': math.log10,
        'exp': math.exp,
        'floor': math.floor,
        'ceil': math.ceil,
        'pi': math.pi,
        'e': math.e,
    }
    
    async def initialize(self) -> bool:
        self.register_tool("calculate", self.calculate, "Evaluate mathematical expression")
        self.register_tool("convert_units", self.convert_units, "Convert between units")
        self._initialized = True
        return True
    
    async def shutdown(self) -> bool:
        return True
    
    async def calculate(self, expression: str) -> Dict[str, Any]:
        """
        Safely evaluate a mathematical expression
        
        Args:
            expression: Mathematical expression string
            
        Returns:
            Dict with result
        """
        try:
            # Parse expression to AST
            tree = ast.parse(expression, mode='eval')
            
            # Evaluate safely
            result = self._eval_node(tree.body)
            
            return {
                "success": True,
                "expression": expression,
                "result": result
            }
            
        except Exception as e:
            return {
                "success": False,
                "expression": expression,
                "error": str(e)
            }
    
    def _eval_node(self, node) -> Union[int, float]:
        """Recursively evaluate AST node"""
        if isinstance(node, ast.Constant):
            return node.value
            
        elif isinstance(node, ast.Name):
            if node.id in self.FUNCTIONS:
                return self.FUNCTIONS[node.id]
            raise ValueError(f"Unknown name: {node.id}")
            
        elif isinstance(node, ast.BinOp):
            left = self._eval_node(node.left)
            right = self._eval_node(node.right)
            op = self.OPERATORS.get(type(node.op))
            if op:
                return op(left, right)
            raise ValueError(f"Unsupported operator: {type(node.op)}")
            
        elif isinstance(node, ast.UnaryOp):
            operand = self._eval_node(node.operand)
            op = self.OPERATORS.get(type(node.op))
            if op:
                return op(operand)
            raise ValueError(f"Unsupported unary operator")
            
        elif isinstance(node, ast.Call):
            func = self._eval_node(node.func)
            args = [self._eval_node(arg) for arg in node.args]
            return func(*args)
            
        else:
            raise ValueError(f"Unsupported expression type: {type(node)}")
    
    async def convert_units(self, value: float, from_unit: str, to_unit: str) -> Dict[str, Any]:
        """Convert between units"""
        conversions = {
            # Length
            ("m", "km"): lambda x: x / 1000,
            ("km", "m"): lambda x: x * 1000,
            ("m", "ft"): lambda x: x * 3.28084,
            ("ft", "m"): lambda x: x / 3.28084,
            ("mi", "km"): lambda x: x * 1.60934,
            ("km", "mi"): lambda x: x / 1.60934,
            
            # Weight
            ("kg", "lb"): lambda x: x * 2.20462,
            ("lb", "kg"): lambda x: x / 2.20462,
            ("g", "kg"): lambda x: x / 1000,
            ("kg", "g"): lambda x: x * 1000,
            
            # Temperature
            ("c", "f"): lambda x: x * 9/5 + 32,
            ("f", "c"): lambda x: (x - 32) * 5/9,
            ("c", "k"): lambda x: x + 273.15,
            ("k", "c"): lambda x: x - 273.15,
        }
        
        key = (from_unit.lower(), to_unit.lower())
        
        if key in conversions:
            result = conversions[key](value)
            return {
                "success": True,
                "input": f"{value} {from_unit}",
                "result": f"{result:.4f} {to_unit}"
            }
        else:
            return {
                "success": False,
                "error": f"Unknown conversion: {from_unit} to {to_unit}"
            }
'''
        
        with open(plugin_dir / "plugin.py", 'w') as f:
            f.write(plugin_code)
        
        (plugin_dir / "__init__.py").write_text(
            "from .plugin import CalculatorPlugin\n"
        )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PLUGIN MANAGEMENT API
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_active_plugins(self) -> Dict[str, Any]:
        """Get all active plugins"""
        return {
            name: info.instance
            for name, info in self.plugins.items()
            if info.status == PluginStatus.ACTIVE and info.instance
        }
    
    def get_all_tools(self) -> Dict[str, Callable]:
        """Get all tools from all active plugins"""
        return self.tools.copy()
    
    def get_plugin_info(self, plugin_name: str) -> Optional[Dict[str, Any]]:
        """Get information about a specific plugin"""
        if plugin_name not in self.plugins:
            return None
        
        info = self.plugins[plugin_name]
        return {
            "name": info.metadata.name,
            "version": info.metadata.version,
            "description": info.metadata.description,
            "author": info.metadata.author,
            "type": info.metadata.plugin_type.value,
            "status": info.status.value,
            "tools": info.provided_tools,
            "loaded_at": info.loaded_at.isoformat() if info.loaded_at else None,
            "error": info.error
        }
    
    def list_plugins(self) -> List[Dict[str, Any]]:
        """List all plugins with their status"""
        return [
            self.get_plugin_info(name)
            for name in self.plugins
        ]
    
    async def create_plugin(self, name: str, description: str,
                           plugin_type: str = "tool",
                           code: str = None) -> bool:
        """
        Create a new plugin dynamically
        
        Args:
            name: Plugin name
            description: Plugin description
            plugin_type: Type of plugin
            code: Optional plugin code
            
        Returns:
            True if created successfully
        """
        try:
            plugin_dir = self.plugins_dir / name
            plugin_dir.mkdir(exist_ok=True)
            
            # Create metadata
            metadata = {
                "name": name,
                "version": "1.0.0",
                "description": description,
                "author": "SMILE (Auto-generated)",
                "plugin_type": plugin_type,
                "dependencies": [],
                "permissions": [],
                "entry_point": "plugin"
            }
            
            with open(plugin_dir / "plugin.json", 'w') as f:
                json.dump(metadata, f, indent=2)
            
            # Create plugin code
            if code:
                with open(plugin_dir / "plugin.py", 'w') as f:
                    f.write(code)
            else:
                # Create template
                template = f'''#!/usr/bin/env python3
"""Auto-generated plugin: {name}"""

from core.plugin_system import BasePlugin, PluginMetadata, PluginType


class {name.title().replace("_", "")}Plugin(BasePlugin):
    """{description}"""
    
    METADATA = PluginMetadata(
        name="{name}",
        version="1.0.0",
        description="{description}",
        author="SMILE",
        plugin_type=PluginType.TOOL,
        permissions=[]
    )
    
    async def initialize(self) -> bool:
        # Register your tools here
        # self.register_tool("my_tool", self.my_tool, "Description")
        self._initialized = True
        return True
    
    async def shutdown(self) -> bool:
        return True
    
    # Add your tool methods here
'''
                with open(plugin_dir / "plugin.py", 'w') as f:
                    f.write(template)
            
            (plugin_dir / "__init__.py").write_text("")
            
            logger.info(f"Created plugin: {name}")
            
            # Discover and optionally load
            await self._discover_plugins()
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to create plugin {name}: {e}")
            return False
    
    async def backup_plugin(self, plugin_name: str) -> Optional[str]:
        """Create a backup of a plugin"""
        if plugin_name not in self.plugins:
            return None
        
        plugin_info = self.plugins[plugin_name]
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"{plugin_name}_{timestamp}"
        backup_path = self.backups_dir / backup_name
        
        try:
            if plugin_info.path.is_dir():
                shutil.copytree(plugin_info.path, backup_path)
            else:
                shutil.copy2(plugin_info.path, backup_path)
            
            logger.info(f"Backed up plugin {plugin_name} to {backup_path}")
            return str(backup_path)
            
        except Exception as e:
            logger.error(f"Failed to backup plugin: {e}")
            return None
    
    async def shutdown(self):
        """Shutdown all plugins"""
        logger.info("Shutting down Plugin System...")
        
        for name in list(self.plugins.keys()):
            if self.plugins[name].status == PluginStatus.ACTIVE:
                await self.unload_plugin(name)
        
        logger.info("Plugin System shutdown complete")