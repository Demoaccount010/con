#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                        THINKING ENGINE - Deep Reasoning System               ║
║                   Advanced Cognitive Processing for SMILE Agent              ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Features:                                                                   ║
║  - Multi-step reasoning chains                                               ║
║  - Chain-of-thought processing                                               ║
║  - Hypothesis generation and testing                                         ║
║  - Problem decomposition                                                     ║
║  - Confidence scoring                                                        ║
║  - Self-verification and fact-checking                                       ║
║  - Reasoning trace logging                                                   ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import asyncio
import logging
import json
import re
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple, Union
from dataclasses import dataclass, field
from enum import Enum, auto
from collections import deque
import hashlib

logger = logging.getLogger("SMILE.ThinkingEngine")

# ═══════════════════════════════════════════════════════════════════════════════
# ENUMS AND DATA STRUCTURES
# ═══════════════════════════════════════════════════════════════════════════════

class ReasoningMode(Enum):
    """Types of reasoning approaches"""
    DIRECT = "direct"                    # Simple direct answer
    ANALYTICAL = "analytical"            # Break down and analyze
    COMPARATIVE = "comparative"          # Compare options/approaches
    CAUSAL = "causal"                    # Cause and effect analysis
    HYPOTHETICAL = "hypothetical"        # What-if scenarios
    CREATIVE = "creative"                # Creative problem solving
    CRITICAL = "critical"                # Critical evaluation
    SYSTEMATIC = "systematic"            # Step-by-step systematic
    ANALOGICAL = "analogical"            # Reasoning by analogy

class ThinkingPhase(Enum):
    """Phases of the thinking process"""
    UNDERSTANDING = "understanding"
    DECOMPOSITION = "decomposition"
    ANALYSIS = "analysis"
    SYNTHESIS = "synthesis"
    VERIFICATION = "verification"
    FORMULATION = "formulation"

class ConfidenceLevel(Enum):
    """Confidence levels with numeric values"""
    CERTAIN = (0.95, "I am certain")
    VERY_HIGH = (0.85, "I am very confident")
    HIGH = (0.75, "I am fairly confident")
    MEDIUM = (0.60, "I believe")
    LOW = (0.40, "I think")
    VERY_LOW = (0.25, "I'm not sure, but")
    UNCERTAIN = (0.10, "I'm uncertain")
    
    @property
    def score(self) -> float:
        return self.value[0]
    
    @property
    def prefix(self) -> str:
        return self.value[1]

@dataclass
class ThoughtNode:
    """Single node in a thought chain"""
    id: str
    phase: ThinkingPhase
    content: str
    confidence: float
    reasoning: str
    evidence: List[str] = field(default_factory=list)
    assumptions: List[str] = field(default_factory=list)
    uncertainties: List[str] = field(default_factory=list)
    parent_id: Optional[str] = None
    children_ids: List[str] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "phase": self.phase.value,
            "content": self.content,
            "confidence": self.confidence,
            "reasoning": self.reasoning,
            "evidence": self.evidence,
            "assumptions": self.assumptions,
            "uncertainties": self.uncertainties,
            "parent_id": self.parent_id,
            "children_ids": self.children_ids,
            "timestamp": self.timestamp
        }

@dataclass
class ThoughtChain:
    """Complete chain of reasoning"""
    id: str
    query: str
    mode: ReasoningMode
    nodes: List[ThoughtNode]
    final_answer: str
    overall_confidence: float
    reasoning_trace: List[str]
    start_time: datetime
    end_time: Optional[datetime] = None
    tokens_used: int = 0
    
    def get_summary(self) -> str:
        """Get a summary of the thought chain"""
        phases = [node.phase.value for node in self.nodes]
        return f"Reasoning chain with {len(self.nodes)} steps through phases: {' → '.join(phases)}"

@dataclass
class Problem:
    """Structured problem representation"""
    statement: str
    type: str
    constraints: List[str]
    objectives: List[str]
    context: Dict[str, Any]
    sub_problems: List['Problem'] = field(default_factory=list)
    
@dataclass
class Hypothesis:
    """A hypothesis to be tested"""
    id: str
    statement: str
    confidence: float
    supporting_evidence: List[str]
    contradicting_evidence: List[str]
    status: str = "untested"  # untested, supported, refuted, inconclusive

# ═══════════════════════════════════════════════════════════════════════════════
# THINKING ENGINE CORE
# ═══════════════════════════════════════════════════════════════════════════════

class ThinkingEngine:
    """
    Deep Reasoning and Thinking Engine
    
    Provides:
    - Chain-of-thought reasoning
    - Problem decomposition
    - Multi-step analysis
    - Hypothesis testing
    - Confidence calibration
    - Self-verification
    """
    
    def __init__(self, agent):
        """
        Initialize Thinking Engine
        
        Args:
            agent: Reference to main SMILE agent
        """
        self.agent = agent
        
        # Thought history
        self.thought_chains: deque = deque(maxlen=100)
        self.current_chain: Optional[ThoughtChain] = None
        
        # Reasoning templates
        self.reasoning_templates = self._init_reasoning_templates()
        
        # Knowledge base for fact-checking
        self.known_facts: Dict[str, Dict] = {}
        
        # Reasoning statistics
        self.stats = {
            "total_chains": 0,
            "avg_confidence": 0.0,
            "avg_chain_length": 0.0,
            "reasoning_modes_used": {}
        }
        
        logger.info("ThinkingEngine instance created")
    
    def _init_reasoning_templates(self) -> Dict[ReasoningMode, str]:
        """Initialize reasoning prompt templates"""
        return {
            ReasoningMode.ANALYTICAL: """
Analyze this step-by-step:
1. Identify the key components
2. Examine each component individually
3. Look for relationships between components
4. Draw conclusions based on the analysis
""",
            ReasoningMode.COMPARATIVE: """
Compare the options/aspects:
1. List all options/aspects to compare
2. Define comparison criteria
3. Evaluate each option against criteria
4. Summarize pros and cons
5. Make a reasoned recommendation
""",
            ReasoningMode.CAUSAL: """
Analyze cause and effect:
1. Identify the observed effect/outcome
2. List potential causes
3. Evaluate likelihood of each cause
4. Trace the causal chain
5. Identify root causes
""",
            ReasoningMode.HYPOTHETICAL: """
Explore hypothetical scenarios:
1. State the hypothesis clearly
2. Identify key assumptions
3. Project consequences if hypothesis is true
4. Consider alternative scenarios
5. Evaluate plausibility
""",
            ReasoningMode.SYSTEMATIC: """
Proceed systematically:
1. Define the problem precisely
2. Gather relevant information
3. Generate possible solutions
4. Evaluate each solution
5. Select and justify the best solution
6. Plan implementation
""",
            ReasoningMode.CRITICAL: """
Critically evaluate:
1. Identify claims being made
2. Examine evidence supporting claims
3. Look for logical fallacies
4. Consider alternative interpretations
5. Assess reliability of sources
6. Form a balanced judgment
"""
        }
    
    async def initialize(self):
        """Initialize the thinking engine"""
        logger.info("Initializing Thinking Engine...")
        
        # Load any cached knowledge
        if self.agent.memory_system:
            facts = await self.agent.memory_system.retrieve_learning("known_facts")
            if facts:
                self.known_facts = facts
        
        logger.info("Thinking Engine initialized")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MAIN THINKING INTERFACE
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def think(self, query: str, context: Dict[str, Any] = None,
                   mode: ReasoningMode = None,
                   depth: int = 3) -> Dict[str, Any]:
        """
        Main thinking method - performs deep reasoning on a query
        
        Args:
            query: The question or problem to think about
            context: Additional context information
            mode: Specific reasoning mode to use
            depth: How deep to reason (1-5)
            
        Returns:
            Dict with answer, confidence, and reasoning trace
        """
        start_time = datetime.now()
        chain_id = self._generate_id("chain")
        
        logger.info(f"Starting thought chain {chain_id} for: {query[:100]}...")
        
        # Determine reasoning mode if not specified
        if mode is None:
            mode = await self._select_reasoning_mode(query, context)
        
        # Initialize thought chain
        self.current_chain = ThoughtChain(
            id=chain_id,
            query=query,
            mode=mode,
            nodes=[],
            final_answer="",
            overall_confidence=0.0,
            reasoning_trace=[],
            start_time=start_time
        )
        
        try:
            # Phase 1: Understanding
            understanding = await self._phase_understanding(query, context)
            
            # Phase 2: Decomposition
            problem = await self._phase_decomposition(query, understanding, context)
            
            # Phase 3: Analysis
            analysis = await self._phase_analysis(problem, mode, depth, context)
            
            # Phase 4: Synthesis
            synthesis = await self._phase_synthesis(analysis, context)
            
            # Phase 5: Verification
            verified = await self._phase_verification(synthesis, query, context)
            
            # Phase 6: Formulation
            final_response = await self._phase_formulation(verified, context)
            
            # Finalize chain
            self.current_chain.final_answer = final_response["answer"]
            self.current_chain.overall_confidence = final_response["confidence"]
            self.current_chain.end_time = datetime.now()
            
            # Store chain
            self.thought_chains.append(self.current_chain)
            
            # Update statistics
            self._update_stats()
            
            # Build result
            result = {
                "answer": final_response["answer"],
                "confidence": final_response["confidence"],
                "confidence_level": self._get_confidence_level(final_response["confidence"]),
                "reasoning_mode": mode.value,
                "reasoning_trace": self.current_chain.reasoning_trace,
                "thought_chain_id": chain_id,
                "phases_completed": len(self.current_chain.nodes),
                "processing_time": (datetime.now() - start_time).total_seconds(),
                "uncertainties": final_response.get("uncertainties", []),
                "assumptions": final_response.get("assumptions", [])
            }
            
            logger.info(f"Thought chain {chain_id} completed with confidence {final_response['confidence']:.2f}")
            
            return result
            
        except Exception as e:
            logger.error(f"Error in thinking process: {e}")
            return {
                "answer": f"I encountered an error while reasoning: {str(e)}",
                "confidence": 0.1,
                "confidence_level": "uncertain",
                "reasoning_mode": mode.value if mode else "unknown",
                "error": str(e)
            }
    
    # ═══════════════════════════════════════════════════════════════════════════
    # THINKING PHASES
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _phase_understanding(self, query: str, 
                                   context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Phase 1: Understand the query"""
        node_id = self._generate_id("node")
        
        self._add_trace("Phase 1: Understanding the query")
        
        # Extract key elements
        understanding = {
            "original_query": query,
            "query_type": self._classify_query(query),
            "key_terms": self._extract_key_terms(query),
            "implicit_questions": [],
            "scope": "specific" if len(query.split()) < 20 else "broad",
            "requires_factual": self._requires_factual_knowledge(query),
            "requires_reasoning": self._requires_reasoning(query),
            "requires_creativity": self._requires_creativity(query)
        }
        
        # Check for implicit questions
        if "why" in query.lower():
            understanding["implicit_questions"].append("causal explanation needed")
        if "how" in query.lower():
            understanding["implicit_questions"].append("process or method needed")
        if "best" in query.lower() or "should" in query.lower():
            understanding["implicit_questions"].append("evaluation or recommendation needed")
        
        # Create thought node
        node = ThoughtNode(
            id=node_id,
            phase=ThinkingPhase.UNDERSTANDING,
            content=f"Query type: {understanding['query_type']}, Key terms: {understanding['key_terms'][:5]}",
            confidence=0.9,
            reasoning="Parsed and classified the input query"
        )
        self.current_chain.nodes.append(node)
        
        self._add_trace(f"  - Query type: {understanding['query_type']}")
        self._add_trace(f"  - Key terms identified: {len(understanding['key_terms'])}")
        
        return understanding
    
    async def _phase_decomposition(self, query: str, understanding: Dict,
                                   context: Dict[str, Any] = None) -> Problem:
        """Phase 2: Decompose the problem"""
        node_id = self._generate_id("node")
        
        self._add_trace("Phase 2: Decomposing the problem")
        
        # Create problem structure
        problem = Problem(
            statement=query,
            type=understanding["query_type"],
            constraints=self._identify_constraints(query, context),
            objectives=self._identify_objectives(query),
            context=context or {}
        )
        
        # Decompose into sub-problems if complex
        if understanding["scope"] == "broad" or len(understanding["key_terms"]) > 5:
            problem.sub_problems = await self._decompose_problem(query, understanding)
            self._add_trace(f"  - Decomposed into {len(problem.sub_problems)} sub-problems")
        
        # Create thought node
        node = ThoughtNode(
            id=node_id,
            phase=ThinkingPhase.DECOMPOSITION,
            content=f"Problem with {len(problem.constraints)} constraints and {len(problem.objectives)} objectives",
            confidence=0.85,
            reasoning="Structured the problem into manageable components",
            parent_id=self.current_chain.nodes[-1].id if self.current_chain.nodes else None
        )
        self.current_chain.nodes.append(node)
        
        return problem
    
    async def _phase_analysis(self, problem: Problem, mode: ReasoningMode,
                             depth: int, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Phase 3: Analyze the problem"""
        node_id = self._generate_id("node")
        
        self._add_trace(f"Phase 3: Analyzing using {mode.value} reasoning")
        
        analysis = {
            "mode": mode,
            "insights": [],
            "evidence": [],
            "hypotheses": [],
            "sub_analyses": []
        }
        
        # Get reasoning template
        template = self.reasoning_templates.get(mode, "")
        
        # Analyze main problem
        main_analysis = await self._analyze_with_mode(problem, mode, template, context)
        analysis["insights"].extend(main_analysis.get("insights", []))
        analysis["evidence"].extend(main_analysis.get("evidence", []))
        
        # Generate hypotheses if appropriate
        if mode in [ReasoningMode.HYPOTHETICAL, ReasoningMode.CAUSAL]:
            hypotheses = await self._generate_hypotheses(problem, main_analysis)
            analysis["hypotheses"] = hypotheses
            self._add_trace(f"  - Generated {len(hypotheses)} hypotheses")
        
        # Analyze sub-problems if they exist
        if problem.sub_problems and depth > 1:
            for sub_problem in problem.sub_problems[:depth]:
                sub_analysis = await self._analyze_with_mode(
                    sub_problem, mode, template, context
                )
                analysis["sub_analyses"].append(sub_analysis)
        
        # Create thought node
        node = ThoughtNode(
            id=node_id,
            phase=ThinkingPhase.ANALYSIS,
            content=f"Found {len(analysis['insights'])} insights using {mode.value} reasoning",
            confidence=0.75,
            reasoning=f"Applied {mode.value} analysis to the problem",
            evidence=analysis["evidence"][:3],
            parent_id=self.current_chain.nodes[-1].id
        )
        self.current_chain.nodes.append(node)
        
        self._add_trace(f"  - Generated {len(analysis['insights'])} insights")
        
        return analysis
    
    async def _phase_synthesis(self, analysis: Dict[str, Any],
                               context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Phase 4: Synthesize findings"""
        node_id = self._generate_id("node")
        
        self._add_trace("Phase 4: Synthesizing findings")
        
        synthesis = {
            "main_conclusion": "",
            "supporting_points": [],
            "confidence_factors": {},
            "remaining_uncertainties": [],
            "assumptions_made": []
        }
        
        # Combine insights
        all_insights = analysis.get("insights", [])
        for sub in analysis.get("sub_analyses", []):
            all_insights.extend(sub.get("insights", []))
        
        # Weight and rank insights
        ranked_insights = self._rank_insights(all_insights)
        
        # Form main conclusion
        if ranked_insights:
            synthesis["main_conclusion"] = ranked_insights[0]
            synthesis["supporting_points"] = ranked_insights[1:4]
        
        # Calculate confidence factors
        synthesis["confidence_factors"] = {
            "evidence_strength": min(len(analysis.get("evidence", [])) / 5, 1.0),
            "consistency": self._calculate_consistency(all_insights),
            "coverage": min(len(all_insights) / 3, 1.0)
        }
        
        # Identify uncertainties
        if analysis.get("hypotheses"):
            for h in analysis["hypotheses"]:
                if h.status == "inconclusive":
                    synthesis["remaining_uncertainties"].append(h.statement)
        
        # Create thought node
        node = ThoughtNode(
            id=node_id,
            phase=ThinkingPhase.SYNTHESIS,
            content=synthesis["main_conclusion"][:200] if synthesis["main_conclusion"] else "Synthesis in progress",
            confidence=0.8,
            reasoning="Combined and synthesized analytical findings",
            uncertainties=synthesis["remaining_uncertainties"][:3],
            parent_id=self.current_chain.nodes[-1].id
        )
        self.current_chain.nodes.append(node)
        
        self._add_trace(f"  - Main conclusion formed with {len(synthesis['supporting_points'])} supporting points")
        
        return synthesis
    
    async def _phase_verification(self, synthesis: Dict[str, Any],
                                  original_query: str,
                                  context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Phase 5: Verify and validate conclusions"""
        node_id = self._generate_id("node")
        
        self._add_trace("Phase 5: Verifying conclusions")
        
        verification = {
            "passes_checks": True,
            "issues_found": [],
            "corrections_made": [],
            "final_confidence": 0.0
        }
        
        # Check 1: Does conclusion address the query?
        relevance = self._check_relevance(synthesis["main_conclusion"], original_query)
        if relevance < 0.5:
            verification["issues_found"].append("Conclusion may not fully address the query")
            verification["passes_checks"] = False
        
        # Check 2: Internal consistency
        consistency = self._check_internal_consistency(synthesis)
        if consistency < 0.7:
            verification["issues_found"].append("Some inconsistencies detected in reasoning")
        
        # Check 3: Known fact verification
        fact_check = await self._verify_against_known_facts(synthesis["main_conclusion"])
        if not fact_check["verified"]:
            verification["issues_found"].extend(fact_check.get("issues", []))
        
        # Check 4: Logical validity
        logic_check = self._check_logical_validity(synthesis)
        if not logic_check["valid"]:
            verification["issues_found"].extend(logic_check.get("fallacies", []))
        
        # Calculate final confidence
        base_confidence = sum(synthesis["confidence_factors"].values()) / len(synthesis["confidence_factors"])
        penalty = len(verification["issues_found"]) * 0.1
        verification["final_confidence"] = max(0.1, min(0.95, base_confidence - penalty))
        
        # Create thought node
        node = ThoughtNode(
            id=node_id,
            phase=ThinkingPhase.VERIFICATION,
            content=f"Verification complete: {len(verification['issues_found'])} issues found",
            confidence=verification["final_confidence"],
            reasoning="Verified conclusions against multiple criteria",
            parent_id=self.current_chain.nodes[-1].id
        )
        self.current_chain.nodes.append(node)
        
        self._add_trace(f"  - Verification complete: confidence = {verification['final_confidence']:.2f}")
        
        # Add verification results to synthesis
        synthesis["verification"] = verification
        synthesis["final_confidence"] = verification["final_confidence"]
        
        return synthesis
    
    async def _phase_formulation(self, verified_synthesis: Dict[str, Any],
                                 context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Phase 6: Formulate final response"""
        node_id = self._generate_id("node")
        
        self._add_trace("Phase 6: Formulating response")
        
        confidence = verified_synthesis.get("final_confidence", 0.5)
        confidence_level = self._get_confidence_level(confidence)
        
        # Build response
        main_answer = verified_synthesis.get("main_conclusion", "")
        supporting = verified_synthesis.get("supporting_points", [])
        uncertainties = verified_synthesis.get("remaining_uncertainties", [])
        assumptions = verified_synthesis.get("assumptions_made", [])
        
        # Format answer based on confidence
        if confidence >= 0.8:
            answer = main_answer
        elif confidence >= 0.5:
            answer = f"{main_answer}"
            if uncertainties:
                answer += f"\n\nNote: There is some uncertainty regarding: {uncertainties[0]}"
        else:
            answer = f"Based on my analysis (with moderate confidence): {main_answer}"
            if uncertainties:
                answer += f"\n\nKey uncertainties: {', '.join(uncertainties[:2])}"
        
        # Add supporting points if helpful
        if supporting and len(main_answer) < 200:
            answer += "\n\nKey points:\n" + "\n".join(f"• {p}" for p in supporting[:3])
        
        # Create thought node
        node = ThoughtNode(
            id=node_id,
            phase=ThinkingPhase.FORMULATION,
            content="Final response formulated",
            confidence=confidence,
            reasoning="Structured findings into coherent response",
            assumptions=assumptions[:3],
            uncertainties=uncertainties[:3],
            parent_id=self.current_chain.nodes[-1].id
        )
        self.current_chain.nodes.append(node)
        
        self._add_trace(f"  - Response formulated with {confidence_level} confidence")
        
        return {
            "answer": answer,
            "confidence": confidence,
            "uncertainties": uncertainties,
            "assumptions": assumptions
        }
    
    # ═══════════════════════════════════════════════════════════════════════════
    # HELPER METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _select_reasoning_mode(self, query: str, 
                                     context: Dict[str, Any] = None) -> ReasoningMode:
        """Select appropriate reasoning mode based on query"""
        query_lower = query.lower()
        
        # Check for mode indicators
        if any(w in query_lower for w in ["compare", "versus", "vs", "difference", "better"]):
            return ReasoningMode.COMPARATIVE
        
        if any(w in query_lower for w in ["why", "cause", "because", "reason", "result"]):
            return ReasoningMode.CAUSAL
        
        if any(w in query_lower for w in ["what if", "suppose", "imagine", "hypothetically"]):
            return ReasoningMode.HYPOTHETICAL
        
        if any(w in query_lower for w in ["analyze", "examine", "break down", "explain"]):
            return ReasoningMode.ANALYTICAL
        
        if any(w in query_lower for w in ["evaluate", "assess", "critique", "review"]):
            return ReasoningMode.CRITICAL
        
        if any(w in query_lower for w in ["how to", "steps", "process", "method"]):
            return ReasoningMode.SYSTEMATIC
        
        if any(w in query_lower for w in ["create", "design", "invent", "imagine"]):
            return ReasoningMode.CREATIVE
        
        # Default to analytical for complex queries
        if len(query.split()) > 15:
            return ReasoningMode.ANALYTICAL
        
        return ReasoningMode.DIRECT
    
    def _classify_query(self, query: str) -> str:
        """Classify the type of query"""
        query_lower = query.lower()
        
        if query_lower.startswith(("what is", "what are", "who is", "who are")):
            return "definitional"
        if query_lower.startswith(("how do", "how to", "how can")):
            return "procedural"
        if query_lower.startswith(("why")):
            return "explanatory"
        if query_lower.startswith(("should", "is it", "would")):
            return "evaluative"
        if any(w in query_lower for w in ["best", "recommend", "suggest"]):
            return "advisory"
        if "?" in query:
            return "interrogative"
        
        return "general"
    
    def _extract_key_terms(self, query: str) -> List[str]:
        """Extract key terms from query"""
        # Remove common words
        stop_words = {'a', 'an', 'the', 'is', 'are', 'was', 'were', 'be', 'been',
                      'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
                      'could', 'should', 'may', 'might', 'to', 'of', 'in', 'for',
                      'on', 'with', 'at', 'by', 'from', 'what', 'how', 'why',
                      'when', 'where', 'which', 'who', 'i', 'you', 'me', 'my',
                      'can', 'please', 'want', 'need', 'like', 'and', 'or', 'but'}
        
        words = re.findall(r'\b\w+\b', query.lower())
        key_terms = [w for w in words if w not in stop_words and len(w) > 2]
        
        return list(dict.fromkeys(key_terms))  # Remove duplicates, preserve order
    
    def _requires_factual_knowledge(self, query: str) -> bool:
        """Check if query requires factual knowledge"""
        factual_indicators = ["what is", "who is", "when did", "where is",
                             "how many", "how much", "definition", "meaning"]
        return any(ind in query.lower() for ind in factual_indicators)
    
    def _requires_reasoning(self, query: str) -> bool:
        """Check if query requires reasoning"""
        reasoning_indicators = ["why", "how does", "explain", "analyze",
                               "compare", "evaluate", "what would happen"]
        return any(ind in query.lower() for ind in reasoning_indicators)
    
    def _requires_creativity(self, query: str) -> bool:
        """Check if query requires creative thinking"""
        creative_indicators = ["create", "design", "imagine", "invent",
                              "brainstorm", "ideas for", "suggest"]
        return any(ind in query.lower() for ind in creative_indicators)
    
    def _identify_constraints(self, query: str, context: Dict = None) -> List[str]:
        """Identify constraints in the problem"""
        constraints = []
        
        # Check for explicit constraints
        constraint_patterns = [
            (r"must\s+(\w+)", "must {}"),
            (r"cannot\s+(\w+)", "cannot {}"),
            (r"without\s+(\w+)", "without {}"),
            (r"only\s+(\w+)", "only {}"),
            (r"at least\s+(\d+)", "minimum {}"),
            (r"at most\s+(\d+)", "maximum {}"),
            (r"within\s+(\w+)", "within {}")
        ]
        
        for pattern, template in constraint_patterns:
            matches = re.findall(pattern, query.lower())
            for match in matches:
                constraints.append(template.format(match))
        
        # Add context constraints
        if context:
            if context.get("time_limit"):
                constraints.append(f"time limit: {context['time_limit']}")
            if context.get("scope"):
                constraints.append(f"scope: {context['scope']}")
        
        return constraints
    
    def _identify_objectives(self, query: str) -> List[str]:
        """Identify objectives in the problem"""
        objectives = []
        
        # Primary objective is usually what's being asked
        if "?" in query:
            objectives.append("Answer the question")
        
        # Look for goal indicators
        goal_patterns = [
            (r"want to\s+(\w+\s+\w+)", "{}"),
            (r"need to\s+(\w+\s+\w+)", "{}"),
            (r"goal is to\s+(\w+\s+\w+)", "{}"),
            (r"trying to\s+(\w+\s+\w+)", "{}")
        ]
        
        for pattern, template in goal_patterns:
            matches = re.findall(pattern, query.lower())
            for match in matches:
                objectives.append(template.format(match))
        
        return objectives if objectives else ["Provide helpful response"]
    
    async def _decompose_problem(self, query: str, 
                                 understanding: Dict) -> List[Problem]:
        """Decompose complex problem into sub-problems"""
        sub_problems = []
        
        # Split by conjunctions
        parts = re.split(r'\band\b|\bor\b|,|\;', query)
        
        for part in parts:
            part = part.strip()
            if len(part) > 10:  # Meaningful sub-problem
                sub_problems.append(Problem(
                    statement=part,
                    type=self._classify_query(part),
                    constraints=[],
                    objectives=[],
                    context={}
                ))
        
        return sub_problems[:5]  # Limit to 5 sub-problems
    
    async def _analyze_with_mode(self, problem: Problem, mode: ReasoningMode,
                                 template: str, context: Dict = None) -> Dict[str, Any]:
        """Analyze problem using specified reasoning mode"""
        analysis = {
            "insights": [],
            "evidence": [],
            "confidence": 0.7
        }
        
        # Generate insights based on mode
        if mode == ReasoningMode.ANALYTICAL:
            # Break down into components
            components = self._extract_key_terms(problem.statement)
            for comp in components[:3]:
                analysis["insights"].append(f"Key component: {comp}")
        
        elif mode == ReasoningMode.COMPARATIVE:
            # Look for things to compare
            analysis["insights"].append("Comparison analysis performed")
        
        elif mode == ReasoningMode.CAUSAL:
            # Look for cause-effect relationships
            if "because" in problem.statement.lower():
                analysis["insights"].append("Causal relationship identified")
        
        elif mode == ReasoningMode.SYSTEMATIC:
            # Generate systematic steps
            analysis["insights"].append("Systematic approach applied")
        
        return analysis
    
    async def _generate_hypotheses(self, problem: Problem,
                                   analysis: Dict) -> List[Hypothesis]:
        """Generate hypotheses for testing"""
        hypotheses = []
        
        # Generate hypothesis based on insights
        for i, insight in enumerate(analysis.get("insights", [])[:3]):
            h = Hypothesis(
                id=f"h_{i}",
                statement=f"Hypothesis based on: {insight}",
                confidence=0.5,
                supporting_evidence=[],
                contradicting_evidence=[],
                status="untested"
            )
            hypotheses.append(h)
        
        return hypotheses
    
    def _rank_insights(self, insights: List[str]) -> List[str]:
        """Rank insights by importance"""
        # Simple ranking by length and specificity
        scored = [(insight, len(insight) + insight.count(':')) for insight in insights]
        scored.sort(key=lambda x: x[1], reverse=True)
        return [insight for insight, score in scored]
    
    def _calculate_consistency(self, insights: List[str]) -> float:
        """Calculate consistency score among insights"""
        if not insights:
            return 0.5
        
        # Simple heuristic: check for contradicting words
        contradictions = 0
        positive_words = {'is', 'can', 'will', 'does', 'should'}
        negative_words = {'not', 'cannot', "can't", "won't", "doesn't", "shouldn't"}
        
        has_positive = any(any(pw in i.lower() for pw in positive_words) for i in insights)
        has_negative = any(any(nw in i.lower() for nw in negative_words) for i in insights)
        
        if has_positive and has_negative:
            return 0.6
        
        return 0.9
    
    def _check_relevance(self, conclusion: str, query: str) -> float:
        """Check if conclusion is relevant to query"""
        if not conclusion or not query:
            return 0.0
        
        query_terms = set(self._extract_key_terms(query))
        conclusion_terms = set(self._extract_key_terms(conclusion))
        
        if not query_terms:
            return 0.5
        
        overlap = len(query_terms & conclusion_terms)
        return min(overlap / len(query_terms), 1.0)
    
    def _check_internal_consistency(self, synthesis: Dict) -> float:
        """Check internal consistency of synthesis"""
        # Check if supporting points align with main conclusion
        main = synthesis.get("main_conclusion", "")
        supporting = synthesis.get("supporting_points", [])
        
        if not supporting:
            return 0.7
        
        # Simple check: do supporting points share terms with main?
        main_terms = set(self._extract_key_terms(main))
        
        alignments = 0
        for point in supporting:
            point_terms = set(self._extract_key_terms(point))
            if main_terms & point_terms:
                alignments += 1
        
        return alignments / len(supporting) if supporting else 0.7
    
    async def _verify_against_known_facts(self, conclusion: str) -> Dict[str, Any]:
        """Verify conclusion against known facts"""
        result = {"verified": True, "issues": []}
        
        # Check against stored facts
        for fact_key, fact_data in self.known_facts.items():
            if fact_key.lower() in conclusion.lower():
                # Found relevant fact
                if fact_data.get("contradicts"):
                    result["verified"] = False
                    result["issues"].append(f"May contradict known fact: {fact_key}")
        
        return result
    
    def _check_logical_validity(self, synthesis: Dict) -> Dict[str, Any]:
        """Check for logical fallacies"""
        result = {"valid": True, "fallacies": []}
        
        main = synthesis.get("main_conclusion", "").lower()
        
        # Check for common fallacies (simplified)
        if "always" in main or "never" in main:
            result["fallacies"].append("Possible overgeneralization")
        
        if "everyone" in main or "nobody" in main:
            result["fallacies"].append("Possible hasty generalization")
        
        if result["fallacies"]:
            result["valid"] = False
        
        return result
    
    def _get_confidence_level(self, confidence: float) -> str:
        """Convert confidence score to level string"""
        for level in ConfidenceLevel:
            if confidence >= level.score:
                return level.name.lower()
        return "uncertain"
    
    def _generate_id(self, prefix: str) -> str:
        """Generate unique ID"""
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S%f")
        return f"{prefix}_{timestamp}"
    
    def _add_trace(self, message: str):
        """Add message to reasoning trace"""
        if self.current_chain:
            self.current_chain.reasoning_trace.append(message)
    
    def _update_stats(self):
        """Update thinking statistics"""
        self.stats["total_chains"] += 1
        
        if self.current_chain:
            # Update average confidence
            total_conf = self.stats["avg_confidence"] * (self.stats["total_chains"] - 1)
            total_conf += self.current_chain.overall_confidence
            self.stats["avg_confidence"] = total_conf / self.stats["total_chains"]
            
            # Update average chain length
            total_len = self.stats["avg_chain_length"] * (self.stats["total_chains"] - 1)
            total_len += len(self.current_chain.nodes)
            self.stats["avg_chain_length"] = total_len / self.stats["total_chains"]
            
            # Track reasoning modes
            mode = self.current_chain.mode.value
            self.stats["reasoning_modes_used"][mode] = \
                self.stats["reasoning_modes_used"].get(mode, 0) + 1
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PUBLIC UTILITY METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def quick_think(self, query: str) -> str:
        """Quick thinking for simple queries"""
        result = await self.think(query, depth=1)
        return result["answer"]
    
    async def deep_think(self, query: str, context: Dict = None) -> Dict[str, Any]:
        """Deep thinking for complex problems"""
        return await self.think(query, context=context, depth=5)
    
    def get_last_thought_chain(self) -> Optional[ThoughtChain]:
        """Get the most recent thought chain"""
        return self.thought_chains[-1] if self.thought_chains else None
    
    def get_reasoning_trace(self, chain_id: str = None) -> List[str]:
        """Get reasoning trace for a thought chain"""
        if chain_id:
            for chain in self.thought_chains:
                if chain.id == chain_id:
                    return chain.reasoning_trace
            return []
        
        # Return latest
        if self.thought_chains:
            return self.thought_chains[-1].reasoning_trace
        return []
    
    def get_stats(self) -> Dict[str, Any]:
        """Get thinking engine statistics"""
        return {
            **self.stats,
            "chains_in_memory": len(self.thought_chains),
            "known_facts": len(self.known_facts)
        }
    
    async def add_known_fact(self, key: str, value: Any, source: str = "learned"):
        """Add a known fact for verification"""
        self.known_facts[key] = {
            "value": value,
            "source": source,
            "added_at": datetime.now().isoformat()
        }
        
        # Persist to memory
        if self.agent.memory_system:
            await self.agent.memory_system.store_learning("known_facts", self.known_facts)