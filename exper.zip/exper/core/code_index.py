#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                        CODE INDEX - Codebase Self-Awareness                  ║
║                   Internal Code Map for SMILE Agent                          ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Features:                                                                   ║
║  - Full codebase indexing                                                    ║
║  - Function and class discovery                                              ║
║  - Dependency mapping                                                        ║
║  - Code search and navigation                                                ║
║  - Documentation extraction                                                  ║
║  - Change detection                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import ast
import asyncio
import logging
import hashlib
import json
from datetime import datetime
from typing import Dict, Any, List, Optional, Set, Tuple
from dataclasses import dataclass, field, asdict
from pathlib import Path
from enum import Enum, auto
import re

logger = logging.getLogger("SMILE.CodeIndex")

# ═══════════════════════════════════════════════════════════════════════════════
# ENUMS AND DATA STRUCTURES
# ═══════════════════════════════════════════════════════════════════════════════

class SymbolType(Enum):
    """Types of code symbols"""
    MODULE = "module"
    CLASS = "class"
    FUNCTION = "function"
    METHOD = "method"
    VARIABLE = "variable"
    CONSTANT = "constant"
    IMPORT = "import"
    DECORATOR = "decorator"

@dataclass
class CodeSymbol:
    """Represents a code symbol (function, class, etc.)"""
    name: str
    symbol_type: SymbolType
    file_path: str
    line_number: int
    end_line: int
    docstring: Optional[str] = None
    signature: Optional[str] = None
    decorators: List[str] = field(default_factory=list)
    parent: Optional[str] = None  # Parent class/module
    children: List[str] = field(default_factory=list)  # Child methods/nested
    dependencies: List[str] = field(default_factory=list)
    is_async: bool = False
    complexity: int = 1  # Cyclomatic complexity estimate
    
    def to_dict(self) -> Dict:
        data = asdict(self)
        data['symbol_type'] = self.symbol_type.value
        return data

@dataclass
class FileInfo:
    """Information about a source file"""
    path: str
    relative_path: str
    checksum: str
    size: int
    lines: int
    last_modified: datetime
    symbols: List[str] = field(default_factory=list)  # Symbol names in this file
    imports: List[str] = field(default_factory=list)
    docstring: Optional[str] = None
    
    def to_dict(self) -> Dict:
        data = asdict(self)
        data['last_modified'] = self.last_modified.isoformat()
        return data

@dataclass
class DependencyEdge:
    """Represents a dependency between symbols"""
    source: str  # Who depends
    target: str  # What is depended on
    dependency_type: str  # import, call, inherit, etc.
    file_path: str
    line_number: int

# ═══════════════════════════════════════════════════════════════════════════════
# AST VISITOR FOR CODE ANALYSIS
# ═══════════════════════════════════════════════════════════════════════════════

class CodeAnalyzer(ast.NodeVisitor):
    """AST visitor for extracting code information"""
    
    def __init__(self, file_path: str, source: str):
        self.file_path = file_path
        self.source = source
        self.source_lines = source.split('\n')
        
        self.symbols: List[CodeSymbol] = []
        self.imports: List[str] = []
        self.dependencies: List[DependencyEdge] = []
        
        self.current_class: Optional[str] = None
        self.current_function: Optional[str] = None
    
    def get_docstring(self, node) -> Optional[str]:
        """Extract docstring from node"""
        try:
            return ast.get_docstring(node)
        except:
            return None
    
    def get_signature(self, node: ast.FunctionDef) -> str:
        """Get function signature"""
        args = []
        
        # Regular args
        for arg in node.args.args:
            arg_str = arg.arg
            if arg.annotation:
                try:
                    arg_str += f": {ast.unparse(arg.annotation)}"
                except:
                    pass
            args.append(arg_str)
        
        # *args
        if node.args.vararg:
            args.append(f"*{node.args.vararg.arg}")
        
        # **kwargs
        if node.args.kwarg:
            args.append(f"**{node.args.kwarg.arg}")
        
        signature = f"({', '.join(args)})"
        
        # Return type
        if node.returns:
            try:
                signature += f" -> {ast.unparse(node.returns)}"
            except:
                pass
        
        return signature
    
    def get_decorators(self, node) -> List[str]:
        """Get decorator names"""
        decorators = []
        for dec in node.decorator_list:
            try:
                if isinstance(dec, ast.Name):
                    decorators.append(dec.id)
                elif isinstance(dec, ast.Attribute):
                    decorators.append(ast.unparse(dec))
                elif isinstance(dec, ast.Call):
                    if isinstance(dec.func, ast.Name):
                        decorators.append(dec.func.id)
                    elif isinstance(dec.func, ast.Attribute):
                        decorators.append(ast.unparse(dec.func))
            except:
                pass
        return decorators
    
    def calculate_complexity(self, node) -> int:
        """Estimate cyclomatic complexity"""
        complexity = 1
        for child in ast.walk(node):
            if isinstance(child, (ast.If, ast.While, ast.For, ast.ExceptHandler,
                                 ast.With, ast.Assert, ast.comprehension)):
                complexity += 1
            elif isinstance(child, ast.BoolOp):
                complexity += len(child.values) - 1
        return complexity
    
    def visit_Import(self, node):
        """Handle import statements"""
        for alias in node.names:
            self.imports.append(alias.name)
            self.dependencies.append(DependencyEdge(
                source=self.file_path,
                target=alias.name,
                dependency_type="import",
                file_path=self.file_path,
                line_number=node.lineno
            ))
        self.generic_visit(node)
    
    def visit_ImportFrom(self, node):
        """Handle from ... import statements"""
        module = node.module or ""
        for alias in node.names:
            full_name = f"{module}.{alias.name}" if module else alias.name
            self.imports.append(full_name)
            self.dependencies.append(DependencyEdge(
                source=self.file_path,
                target=full_name,
                dependency_type="import_from",
                file_path=self.file_path,
                line_number=node.lineno
            ))
        self.generic_visit(node)
    
    def visit_ClassDef(self, node):
        """Handle class definitions"""
        class_name = node.name
        full_name = f"{self.current_class}.{class_name}" if self.current_class else class_name
        
        # Get base classes
        bases = []
        for base in node.bases:
            try:
                base_name = ast.unparse(base)
                bases.append(base_name)
                self.dependencies.append(DependencyEdge(
                    source=full_name,
                    target=base_name,
                    dependency_type="inherit",
                    file_path=self.file_path,
                    line_number=node.lineno
                ))
            except:
                pass
        
        symbol = CodeSymbol(
            name=full_name,
            symbol_type=SymbolType.CLASS,
            file_path=self.file_path,
            line_number=node.lineno,
            end_line=node.end_lineno or node.lineno,
            docstring=self.get_docstring(node),
            decorators=self.get_decorators(node),
            parent=self.current_class,
            dependencies=bases
        )
        
        self.symbols.append(symbol)
        
        # Visit children
        old_class = self.current_class
        self.current_class = full_name
        self.generic_visit(node)
        self.current_class = old_class
    
    def visit_FunctionDef(self, node):
        """Handle function definitions"""
        self._process_function(node, is_async=False)
    
    def visit_AsyncFunctionDef(self, node):
        """Handle async function definitions"""
        self._process_function(node, is_async=True)
    
    def _process_function(self, node, is_async: bool):
        """Process function/method definition"""
        func_name = node.name
        
        if self.current_class:
            full_name = f"{self.current_class}.{func_name}"
            symbol_type = SymbolType.METHOD
        else:
            full_name = func_name
            symbol_type = SymbolType.FUNCTION
        
        symbol = CodeSymbol(
            name=full_name,
            symbol_type=symbol_type,
            file_path=self.file_path,
            line_number=node.lineno,
            end_line=node.end_lineno or node.lineno,
            docstring=self.get_docstring(node),
            signature=self.get_signature(node),
            decorators=self.get_decorators(node),
            parent=self.current_class,
            is_async=is_async,
            complexity=self.calculate_complexity(node)
        )
        
        self.symbols.append(symbol)
        
        # Find function calls for dependencies
        for child in ast.walk(node):
            if isinstance(child, ast.Call):
                try:
                    if isinstance(child.func, ast.Name):
                        self.dependencies.append(DependencyEdge(
                            source=full_name,
                            target=child.func.id,
                            dependency_type="call",
                            file_path=self.file_path,
                            line_number=child.lineno
                        ))
                    elif isinstance(child.func, ast.Attribute):
                        self.dependencies.append(DependencyEdge(
                            source=full_name,
                            target=ast.unparse(child.func),
                            dependency_type="call",
                            file_path=self.file_path,
                            line_number=child.lineno
                        ))
                except:
                    pass
        
        # Visit nested functions
        old_function = self.current_function
        self.current_function = full_name
        self.generic_visit(node)
        self.current_function = old_function
    
    def visit_Assign(self, node):
        """Handle assignments (for constants/variables)"""
        # Check for module-level constants (ALL_CAPS)
        if not self.current_class and not self.current_function:
            for target in node.targets:
                if isinstance(target, ast.Name):
                    if target.id.isupper():
                        symbol = CodeSymbol(
                            name=target.id,
                            symbol_type=SymbolType.CONSTANT,
                            file_path=self.file_path,
                            line_number=node.lineno,
                            end_line=node.lineno
                        )
                        self.symbols.append(symbol)
        
        self.generic_visit(node)

# ═══════════════════════════════════════════════════════════════════════════════
# CODE INDEX CORE
# ═══════════════════════════════════════════════════════════════════════════════

class CodeIndex:
    """
    Codebase Self-Awareness System
    
    Maintains a complete index of the agent's own codebase,
    enabling self-understanding and navigation.
    """
    
    def __init__(self, base_dir: Path):
        """
        Initialize Code Index
        
        Args:
            base_dir: Root directory of the codebase
        """
        self.base_dir = base_dir
        
        # Index storage
        self.files: Dict[str, FileInfo] = {}
        self.symbols: Dict[str, CodeSymbol] = {}
        self.dependencies: List[DependencyEdge] = []
        
        # Search indices
        self.symbol_by_type: Dict[SymbolType, List[str]] = {t: [] for t in SymbolType}
        self.symbol_by_file: Dict[str, List[str]] = {}
        self.keyword_index: Dict[str, Set[str]] = {}  # keyword -> symbol names
        
        # Dependency graph
        self.dependency_graph: Dict[str, Set[str]] = {}  # symbol -> dependencies
        self.reverse_dependencies: Dict[str, Set[str]] = {}  # symbol -> dependents
        
        # Cache
        self.last_build: Optional[datetime] = None
        self.file_checksums: Dict[str, str] = {}
        
        # Ignore patterns
        self.ignore_patterns = [
            '__pycache__', '.git', '.venv', 'venv', 'env',
            'node_modules', '.eggs', '*.egg-info', 'dist', 'build'
        ]
        
        logger.info(f"CodeIndex initialized for: {base_dir}")
    
    async def build_index(self):
        """Build the complete code index"""
        logger.info("Building code index...")
        start_time = datetime.now()
        
        # Clear existing index
        self.files.clear()
        self.symbols.clear()
        self.dependencies.clear()
        for t in SymbolType:
            self.symbol_by_type[t] = []
        self.symbol_by_file.clear()
        self.keyword_index.clear()
        self.dependency_graph.clear()
        self.reverse_dependencies.clear()
        
        # Find all Python files
        python_files = self._find_python_files()
        logger.info(f"Found {len(python_files)} Python files")
        
        # Index each file
        for file_path in python_files:
            await self._index_file(file_path)
        
        # Build search indices
        self._build_search_indices()
        
        # Build dependency graph
        self._build_dependency_graph()
        
        self.last_build = datetime.now()
        build_time = (datetime.now() - start_time).total_seconds()
        
        logger.info(f"Code index built in {build_time:.2f}s")
        logger.info(f"  Files: {len(self.files)}")
        logger.info(f"  Symbols: {len(self.symbols)}")
        logger.info(f"  Dependencies: {len(self.dependencies)}")
    
    def _find_python_files(self) -> List[Path]:
        """Find all Python files in the codebase"""
        python_files = []
        
        for path in self.base_dir.rglob("*.py"):
            # Check ignore patterns
            should_ignore = False
            for pattern in self.ignore_patterns:
                if pattern in str(path):
                    should_ignore = True
                    break
            
            if not should_ignore:
                python_files.append(path)
        
        return python_files
    
    async def _index_file(self, file_path: Path):
        """Index a single Python file"""
        try:
            # Read file
            source = file_path.read_text(encoding='utf-8', errors='ignore')
            
            # Calculate checksum
            checksum = hashlib.md5(source.encode()).hexdigest()
            
            # Get relative path
            try:
                relative_path = str(file_path.relative_to(self.base_dir))
            except ValueError:
                relative_path = str(file_path)
            
            # Create file info
            file_info = FileInfo(
                path=str(file_path),
                relative_path=relative_path,
                checksum=checksum,
                size=len(source),
                lines=len(source.splitlines()),
                last_modified=datetime.fromtimestamp(file_path.stat().st_mtime)
            )
            
            # Parse AST
            try:
                tree = ast.parse(source, filename=str(file_path))
                
                # Get module docstring
                file_info.docstring = ast.get_docstring(tree)
                
                # Analyze code
                analyzer = CodeAnalyzer(relative_path, source)
                analyzer.visit(tree)
                
                # Store symbols
                for symbol in analyzer.symbols:
                    self.symbols[symbol.name] = symbol
                    file_info.symbols.append(symbol.name)
                
                # Store imports
                file_info.imports = analyzer.imports
                
                # Store dependencies
                self.dependencies.extend(analyzer.dependencies)
                
            except SyntaxError as e:
                logger.debug(f"Syntax error in {relative_path}: {e}")
            
            # Store file info
            self.files[relative_path] = file_info
            self.file_checksums[relative_path] = checksum
            
        except Exception as e:
            logger.error(f"Error indexing {file_path}: {e}")
    
    def _build_search_indices(self):
        """Build indices for fast searching"""
        for name, symbol in self.symbols.items():
            # Index by type
            self.symbol_by_type[symbol.symbol_type].append(name)
            
            # Index by file
            if symbol.file_path not in self.symbol_by_file:
                self.symbol_by_file[symbol.file_path] = []
            self.symbol_by_file[symbol.file_path].append(name)
            
            # Keyword index
            keywords = self._extract_keywords(name, symbol.docstring or "")
            for keyword in keywords:
                if keyword not in self.keyword_index:
                    self.keyword_index[keyword] = set()
                self.keyword_index[keyword].add(name)
    
    def _extract_keywords(self, name: str, docstring: str) -> List[str]:
        """Extract searchable keywords from name and docstring"""
        keywords = []
        
        # Split camelCase and snake_case
        words = re.findall(r'[a-z]+|[A-Z][a-z]*', name)
        keywords.extend([w.lower() for w in words if len(w) > 2])
        
        # Words from docstring
        if docstring:
            doc_words = re.findall(r'\b[a-zA-Z]{3,}\b', docstring)
            keywords.extend([w.lower() for w in doc_words[:20]])
        
        return list(set(keywords))
    
    def _build_dependency_graph(self):
        """Build dependency graph from edges"""
        for edge in self.dependencies:
            # Forward dependencies
            if edge.source not in self.dependency_graph:
                self.dependency_graph[edge.source] = set()
            self.dependency_graph[edge.source].add(edge.target)
            
            # Reverse dependencies
            if edge.target not in self.reverse_dependencies:
                self.reverse_dependencies[edge.target] = set()
            self.reverse_dependencies[edge.target].add(edge.source)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # SEARCH AND NAVIGATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    def search(self, query: str, limit: int = 20) -> List[Dict[str, Any]]:
        """
        Search for symbols matching query
        
        Args:
            query: Search query
            limit: Maximum results
            
        Returns:
            List of matching symbols with relevance scores
        """
        query_lower = query.lower()
        results = []
        
        # Exact name match
        if query in self.symbols:
            symbol = self.symbols[query]
            results.append({
                "name": symbol.name,
                "type": symbol.symbol_type.value,
                "file": symbol.file_path,
                "line": symbol.line_number,
                "relevance": 1.0,
                "match_type": "exact"
            })
        
        # Partial name match
        for name, symbol in self.symbols.items():
            if query_lower in name.lower() and name != query:
                relevance = len(query) / len(name)
                results.append({
                    "name": symbol.name,
                    "type": symbol.symbol_type.value,
                    "file": symbol.file_path,
                    "line": symbol.line_number,
                    "relevance": relevance,
                    "match_type": "partial"
                })
        
        # Keyword match
        keywords = query_lower.split()
        for keyword in keywords:
            if keyword in self.keyword_index:
                for name in self.keyword_index[keyword]:
                    if not any(r["name"] == name for r in results):
                        symbol = self.symbols[name]
                        results.append({
                            "name": symbol.name,
                            "type": symbol.symbol_type.value,
                            "file": symbol.file_path,
                            "line": symbol.line_number,
                            "relevance": 0.5,
                            "match_type": "keyword"
                        })
        
        # Sort by relevance
        results.sort(key=lambda x: x["relevance"], reverse=True)
        
        return results[:limit]
    
    def get_symbol(self, name: str) -> Optional[CodeSymbol]:
        """Get a symbol by name"""
        return self.symbols.get(name)
    
    def get_symbol_code(self, name: str) -> Optional[str]:
        """Get the source code for a symbol"""
        symbol = self.symbols.get(name)
        if not symbol:
            return None
        
        try:
            file_path = self.base_dir / symbol.file_path
            source = file_path.read_text()
            lines = source.splitlines()
            
            # Extract lines for this symbol
            start = symbol.line_number - 1
            end = symbol.end_line
            
            return '\n'.join(lines[start:end])
        except Exception as e:
            logger.error(f"Error getting code for {name}: {e}")
            return None
    
    def get_file_info(self, path: str) -> Optional[FileInfo]:
        """Get information about a file"""
        return self.files.get(path)
    
    def list_files(self) -> List[str]:
        """List all indexed files"""
        return list(self.files.keys())
    
    def list_symbols_in_file(self, path: str) -> List[CodeSymbol]:
        """List all symbols in a file"""
        if path not in self.symbol_by_file:
            return []
        
        return [self.symbols[name] for name in self.symbol_by_file[path]]
    
    def get_symbols_by_type(self, symbol_type: SymbolType) -> List[CodeSymbol]:
        """Get all symbols of a specific type"""
        return [self.symbols[name] for name in self.symbol_by_type[symbol_type]]
    
    # ═══════════════════════════════════════════════════════════════════════════
    # DEPENDENCY ANALYSIS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_dependencies(self, symbol_name: str) -> List[str]:
        """Get dependencies of a symbol"""
        return list(self.dependency_graph.get(symbol_name, set()))
    
    def get_dependents(self, symbol_name: str) -> List[str]:
        """Get symbols that depend on this one"""
        return list(self.reverse_dependencies.get(symbol_name, set()))
    
    def get_dependency_tree(self, symbol_name: str, max_depth: int = 3) -> Dict:
        """Get recursive dependency tree"""
        visited = set()
        
        def build_tree(name: str, depth: int) -> Dict:
            if depth > max_depth or name in visited:
                return {"name": name, "truncated": True}
            
            visited.add(name)
            deps = self.dependency_graph.get(name, set())
            
            return {
                "name": name,
                "dependencies": [build_tree(d, depth + 1) for d in deps]
            }
        
        return build_tree(symbol_name, 0)
    
    def find_circular_dependencies(self) -> List[List[str]]:
        """Find circular dependencies in the codebase"""
        cycles = []
        visited = set()
        path = []
        path_set = set()
        
        def dfs(node: str):
            if node in path_set:
                # Found cycle
                cycle_start = path.index(node)
                cycles.append(path[cycle_start:] + [node])
                return
            
            if node in visited:
                return
            
            visited.add(node)
            path.append(node)
            path_set.add(node)
            
            for dep in self.dependency_graph.get(node, set()):
                dfs(dep)
            
            path.pop()
            path_set.remove(node)
        
        for symbol in self.symbols:
            if symbol not in visited:
                dfs(symbol)
        
        return cycles
    
    def get_import_graph(self) -> Dict[str, List[str]]:
        """Get file-level import graph"""
        import_graph = {}
        
        for path, file_info in self.files.items():
            import_graph[path] = file_info.imports
        
        return import_graph
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CHANGE DETECTION
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def detect_changes(self) -> Dict[str, List[str]]:
        """
        Detect changes since last index build
        
        Returns:
            Dict with 'added', 'modified', 'deleted' file lists
        """
        changes = {
            "added": [],
            "modified": [],
            "deleted": []
        }
        
        current_files = {str(f.relative_to(self.base_dir)): f 
                        for f in self._find_python_files()}
        
        # Check for added and modified
        for rel_path, full_path in current_files.items():
            if rel_path not in self.file_checksums:
                changes["added"].append(rel_path)
            else:
                current_checksum = hashlib.md5(
                    full_path.read_bytes()
                ).hexdigest()
                if current_checksum != self.file_checksums[rel_path]:
                    changes["modified"].append(rel_path)
        
        # Check for deleted
        for rel_path in self.file_checksums:
            if rel_path not in current_files:
                changes["deleted"].append(rel_path)
        
        return changes
    
    async def update_index(self):
        """Update index incrementally based on changes"""
        changes = await self.detect_changes()
        
        # Handle deleted files
        for path in changes["deleted"]:
            if path in self.files:
                # Remove symbols from this file
                for symbol_name in self.files[path].symbols:
                    if symbol_name in self.symbols:
                        del self.symbols[symbol_name]
                del self.files[path]
                del self.file_checksums[path]
        
        # Handle added and modified files
        for path in changes["added"] + changes["modified"]:
            full_path = self.base_dir / path
            if full_path.exists():
                # Remove old symbols if modified
                if path in self.files:
                    for symbol_name in self.files[path].symbols:
                        if symbol_name in self.symbols:
                            del self.symbols[symbol_name]
                
                # Re-index file
                await self._index_file(full_path)
        
        # Rebuild indices if there were changes
        if any(changes.values()):
            self._build_search_indices()
            self._build_dependency_graph()
            logger.info(f"Index updated: {len(changes['added'])} added, "
                       f"{len(changes['modified'])} modified, "
                       f"{len(changes['deleted'])} deleted")
        
        return changes
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CODE ANALYSIS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_complexity_report(self) -> Dict[str, Any]:
        """Generate code complexity report"""
        functions = self.get_symbols_by_type(SymbolType.FUNCTION)
        methods = self.get_symbols_by_type(SymbolType.METHOD)
        
        all_funcs = functions + methods
        
        if not all_funcs:
            return {"error": "No functions found"}
        
        complexities = [f.complexity for f in all_funcs]
        
        high_complexity = [
            {"name": f.name, "complexity": f.complexity, "file": f.file_path}
            for f in all_funcs if f.complexity > 10
        ]
        
        return {
            "total_functions": len(all_funcs),
            "average_complexity": sum(complexities) / len(complexities),
            "max_complexity": max(complexities),
            "high_complexity_functions": sorted(
                high_complexity, 
                key=lambda x: x["complexity"], 
                reverse=True
            )[:10]
        }
    
    def get_documentation_coverage(self) -> Dict[str, Any]:
        """Analyze documentation coverage"""
        total = len(self.symbols)
        documented = len([s for s in self.symbols.values() if s.docstring])
        
        undocumented = [
            {"name": s.name, "type": s.symbol_type.value, "file": s.file_path}
            for s in self.symbols.values()
            if not s.docstring and s.symbol_type in [
                SymbolType.CLASS, SymbolType.FUNCTION, SymbolType.METHOD
            ]
        ]
        
        return {
            "total_symbols": total,
            "documented": documented,
            "undocumented": total - documented,
            "coverage_percent": (documented / total * 100) if total > 0 else 0,
            "undocumented_items": undocumented[:20]
        }
    
    def get_codebase_summary(self) -> Dict[str, Any]:
        """Get summary of the codebase"""
        total_lines = sum(f.lines for f in self.files.values())
        total_size = sum(f.size for f in self.files.values())
        
        return {
            "files": len(self.files),
            "total_lines": total_lines,
            "total_size_kb": total_size / 1024,
            "classes": len(self.symbol_by_type[SymbolType.CLASS]),
            "functions": len(self.symbol_by_type[SymbolType.FUNCTION]),
            "methods": len(self.symbol_by_type[SymbolType.METHOD]),
            "constants": len(self.symbol_by_type[SymbolType.CONSTANT]),
            "total_symbols": len(self.symbols),
            "total_dependencies": len(self.dependencies),
            "last_indexed": self.last_build.isoformat() if self.last_build else None
        }
    
    # ═══════════════════════════════════════════════════════════════════════════
    # EXPORT
    # ═══════════════════════════════════════════════════════════════════════════
    
    def export_index(self, output_path: Path):
        """Export index to JSON file"""
        export_data = {
            "generated_at": datetime.now().isoformat(),
            "base_dir": str(self.base_dir),
            "summary": self.get_codebase_summary(),
            "files": {k: v.to_dict() for k, v in self.files.items()},
            "symbols": {k: v.to_dict() for k, v in self.symbols.items()},
            "dependencies": [
                {
                    "source": d.source,
                    "target": d.target,
                    "type": d.dependency_type,
                    "file": d.file_path,
                    "line": d.line_number
                }
                for d in self.dependencies
            ]
        }
        
        with open(output_path, 'w') as f:
            json.dump(export_data, f, indent=2)
        
        logger.info(f"Index exported to {output_path}")
    
    def generate_documentation(self) -> str:
        """Generate markdown documentation from index"""
        doc = []
        doc.append("# SMILE Agent Codebase Documentation\n")
        doc.append(f"*Generated: {datetime.now().isoformat()}*\n")
        
        # Summary
        summary = self.get_codebase_summary()
        doc.append("## Summary\n")
        doc.append(f"- **Files**: {summary['files']}")
        doc.append(f"- **Total Lines**: {summary['total_lines']}")
        doc.append(f"- **Classes**: {summary['classes']}")
        doc.append(f"- **Functions**: {summary['functions']}")
        doc.append(f"- **Methods**: {summary['methods']}")
        doc.append("")
        
        # Classes
        doc.append("## Classes\n")
        for symbol in self.get_symbols_by_type(SymbolType.CLASS):
            doc.append(f"### `{symbol.name}`")
            doc.append(f"*File: {symbol.file_path}:{symbol.line_number}*\n")
            if symbol.docstring:
                doc.append(f"{symbol.docstring}\n")
            
            # List methods
            methods = [s for s in self.symbols.values() 
                      if s.parent == symbol.name and s.symbol_type == SymbolType.METHOD]
            if methods:
                doc.append("**Methods:**")
                for method in methods:
                    doc.append(f"- `{method.name.split('.')[-1]}{method.signature or '()'}`")
            doc.append("")
        
        # Functions
        doc.append("## Functions\n")
        for symbol in self.get_symbols_by_type(SymbolType.FUNCTION):
            doc.append(f"### `{symbol.name}{symbol.signature or '()'}`")
            doc.append(f"*File: {symbol.file_path}:{symbol.line_number}*\n")
            if symbol.docstring:
                # First line of docstring
                first_line = symbol.docstring.split('\n')[0]
                doc.append(f"{first_line}\n")
        
        return '\n'.join(doc)