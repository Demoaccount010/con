#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                         API MANAGER - Multi-Provider System                  ║
║                   Intelligent API Orchestration for SMILE Agent             ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Features:                                                                   ║
║  - Multiple AI provider support (OpenAI, Anthropic, Google, OpenRouter)      ║
║  - Automatic failover and rotation                                           ║
║  - Rate limiting and quota management                                        ║
║  - Response caching for efficiency                                           ║
║  - Health monitoring and auto-recovery                                       ║
║  - Cost tracking and optimization                                            ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import asyncio
import aiohttp
import json
import logging
import time
import hashlib
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path
from collections import deque
import traceback

logger = logging.getLogger("SMILE.APIManager")

# ═══════════════════════════════════════════════════════════════════════════════
# CONSTANTS AND CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

class APIProvider(Enum):
    """Supported API providers"""
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    GOOGLE = "google"
    OPENROUTER = "openrouter"
    LOCAL = "local"
    OLLAMA = "ollama"
    GROQ = "groq"

class APIStatus(Enum):
    """API health status"""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    RATE_LIMITED = "rate_limited"
    QUOTA_EXCEEDED = "quota_exceeded"
    UNKNOWN = "unknown"

# Provider configurations
PROVIDER_CONFIGS = {
    APIProvider.OPENAI: {
        "base_url": "https://api.openai.com/v1",
        "chat_endpoint": "/chat/completions",
        "models": ["gpt-4-turbo-preview", "gpt-4", "gpt-3.5-turbo"],
        "default_model": "gpt-4-turbo-preview",
        "max_tokens": 4096,
        "supports_streaming": True,
        "rate_limit_per_minute": 60,
        "headers_template": {
            "Authorization": "Bearer {api_key}",
            "Content-Type": "application/json"
        }
    },
    APIProvider.ANTHROPIC: {
        "base_url": "https://api.anthropic.com/v1",
        "chat_endpoint": "/messages",
        "models": ["claude-3-opus-20240229", "claude-3-sonnet-20240229", "claude-3-haiku-20240307"],
        "default_model": "claude-3-opus-20240229",
        "max_tokens": 4096,
        "supports_streaming": True,
        "rate_limit_per_minute": 60,
        "headers_template": {
            "x-api-key": "{api_key}",
            "Content-Type": "application/json",
            "anthropic-version": "2023-06-01"
        }
    },
    APIProvider.GOOGLE: {
        "base_url": "https://generativelanguage.googleapis.com/v1beta",
        "chat_endpoint": "/models/{model}:generateContent",
        "models": ["gemini-pro", "gemini-pro-vision"],
        "default_model": "gemini-pro",
        "max_tokens": 4096,
        "supports_streaming": True,
        "rate_limit_per_minute": 60,
        "headers_template": {
            "Content-Type": "application/json"
        }
    },
    APIProvider.OPENROUTER: {
        "base_url": "https://openrouter.ai/api/v1",
        "chat_endpoint": "/chat/completions",
        "models": ["auto", "openai/gpt-4-turbo", "anthropic/claude-3-opus"],
        "default_model": "auto",
        "max_tokens": 4096,
        "supports_streaming": True,
        "rate_limit_per_minute": 100,
        "headers_template": {
            "Authorization": "Bearer {api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://smile-agent.local",
            "X-Title": "SMILE Agent"
        }
    },
    APIProvider.GROQ: {
        "base_url": "https://api.groq.com/openai/v1",
        "chat_endpoint": "/chat/completions",
        "models": ["mixtral-8x7b-32768", "llama2-70b-4096"],
        "default_model": "mixtral-8x7b-32768",
        "max_tokens": 4096,
        "supports_streaming": True,
        "rate_limit_per_minute": 30,
        "headers_template": {
            "Authorization": "Bearer {api_key}",
            "Content-Type": "application/json"
        }
    },
    APIProvider.OLLAMA: {
        "base_url": "http://localhost:11434",
        "chat_endpoint": "/api/chat",
        "models": ["llama2", "codellama", "mistral"],
        "default_model": "llama2",
        "max_tokens": 4096,
        "supports_streaming": True,
        "rate_limit_per_minute": 1000,
        "headers_template": {
            "Content-Type": "application/json"
        }
    }
}

# ═══════════════════════════════════════════════════════════════════════════════
# DATA STRUCTURES
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class APIEndpoint:
    """Represents a single API endpoint configuration"""
    provider: APIProvider
    api_key: str
    model: str
    priority: int = 1
    active: bool = True
    base_url: Optional[str] = None  # Override default
    
    # Runtime state
    status: APIStatus = APIStatus.UNKNOWN
    last_used: Optional[datetime] = None
    last_error: Optional[str] = None
    request_count: int = 0
    error_count: int = 0
    total_tokens_used: int = 0
    total_cost: float = 0.0
    avg_latency_ms: float = 0.0
    
    # Rate limiting
    requests_this_minute: int = 0
    minute_reset_time: Optional[datetime] = None

@dataclass
class APIResponse:
    """Standardized API response"""
    success: bool
    content: str
    provider: str
    model: str
    tokens_used: int = 0
    latency_ms: float = 0.0
    cached: bool = False
    error: Optional[str] = None
    raw_response: Optional[Dict] = None

@dataclass
class CacheEntry:
    """Cache entry for API responses"""
    response: str
    created_at: datetime
    access_count: int = 1
    provider: str = ""
    tokens_saved: int = 0

# ═══════════════════════════════════════════════════════════════════════════════
# API MANAGER CORE CLASS
# ═══════════════════════════════════════════════════════════════════════════════

class APIManager:
    """
    Multi-Provider API Manager
    
    Handles:
    - Multiple AI API providers
    - Automatic failover
    - Rate limiting
    - Response caching
    - Cost tracking
    - Health monitoring
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize API Manager
        
        Args:
            config: Configuration dict with API keys and settings
        """
        self.config = config
        self.endpoints: Dict[str, APIEndpoint] = {}
        self.active_provider: Optional[str] = None
        
        # Response cache
        self.cache: Dict[str, CacheEntry] = {}
        self.cache_max_size = 1000
        self.cache_ttl_seconds = 3600  # 1 hour
        
        # Request history for analysis
        self.request_history: deque = deque(maxlen=1000)
        
        # Health check settings
        self.health_check_interval = 300  # 5 minutes
        self.last_health_check: Optional[datetime] = None
        
        # Session for async requests
        self.session: Optional[aiohttp.ClientSession] = None
        
        # Stats
        self.stats = {
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "cache_hits": 0,
            "failovers": 0,
            "total_tokens": 0,
            "total_cost": 0.0
        }
        
        logger.info("APIManager instance created")
    
    async def initialize(self):
        """Initialize the API manager"""
        logger.info("Initializing API Manager...")
        
        # Create aiohttp session
        timeout = aiohttp.ClientTimeout(total=120)
        self.session = aiohttp.ClientSession(timeout=timeout)
        
        # Parse and validate API configurations
        await self._parse_api_configs()
        
        # Validate at least one API is available
        if not self.endpoints:
            raise ValueError("No valid API endpoints configured")
        
        # Set initial active provider
        self._select_best_provider()
        
        # Perform initial health check
        await self.health_check_all()
        
        logger.info(f"API Manager initialized with {len(self.endpoints)} endpoints")
        logger.info(f"Active provider: {self.active_provider}")
    
    async def _parse_api_configs(self):
        """Parse API configurations from config dict"""
        apis = self.config.get("apis", {})
        
        for provider_name, api_config in apis.items():
            try:
                # Map provider name to enum
                provider = self._get_provider_enum(provider_name)
                if not provider:
                    logger.warning(f"Unknown provider: {provider_name}")
                    continue
                
                # Get API key
                api_key = api_config.get("key", "")
                if not api_key:
                    logger.warning(f"No API key for {provider_name}")
                    continue
                
                # Create endpoint
                endpoint = APIEndpoint(
                    provider=provider,
                    api_key=api_key,
                    model=api_config.get("model", PROVIDER_CONFIGS[provider]["default_model"]),
                    priority=api_config.get("priority", 1),
                    active=api_config.get("active", True),
                    base_url=api_config.get("base_url")
                )
                
                self.endpoints[provider_name] = endpoint
                logger.info(f"Configured endpoint: {provider_name} ({endpoint.model})")
                
            except Exception as e:
                logger.error(f"Failed to configure {provider_name}: {e}")
    
    def _get_provider_enum(self, name: str) -> Optional[APIProvider]:
        """Convert provider name string to enum"""
        name_lower = name.lower()
        for provider in APIProvider:
            if provider.value == name_lower:
                return provider
        return None
    
    def _select_best_provider(self):
        """Select the best available provider based on priority and health"""
        active_endpoints = [
            (name, ep) for name, ep in self.endpoints.items()
            if ep.active and ep.status not in [APIStatus.UNHEALTHY, APIStatus.QUOTA_EXCEEDED]
        ]
        
        if not active_endpoints:
            # Fall back to any active endpoint
            active_endpoints = [
                (name, ep) for name, ep in self.endpoints.items()
                if ep.active
            ]
        
        if active_endpoints:
            # Sort by priority (lower is better) and error rate
            sorted_endpoints = sorted(
                active_endpoints,
                key=lambda x: (x[1].priority, x[1].error_count)
            )
            self.active_provider = sorted_endpoints[0][0]
        else:
            self.active_provider = None
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MAIN GENERATION METHOD
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def generate(self, messages: List[Dict[str, str]], 
                      **kwargs) -> str:
        """
        Generate a response using the best available API
        
        Args:
            messages: List of message dicts with 'role' and 'content'
            **kwargs: Additional parameters (temperature, max_tokens, etc.)
            
        Returns:
            Generated response string
        """
        self.stats["total_requests"] += 1
        
        # Check cache first
        cache_key = self._generate_cache_key(messages)
        cached = self._get_from_cache(cache_key)
        if cached:
            self.stats["cache_hits"] += 1
            return cached
        
        # Try providers in order of preference
        providers_to_try = self._get_provider_order()
        last_error = None
        
        for provider_name in providers_to_try:
            try:
                response = await self._call_api(provider_name, messages, **kwargs)
                
                if response.success:
                    self.stats["successful_requests"] += 1
                    self.stats["total_tokens"] += response.tokens_used
                    
                    # Cache successful response
                    self._add_to_cache(cache_key, response.content, 
                                      response.provider, response.tokens_used)
                    
                    # Record success
                    self._record_request(provider_name, True, response.latency_ms)
                    
                    return response.content
                else:
                    last_error = response.error
                    self._record_request(provider_name, False, 0, response.error)
                    
            except Exception as e:
                last_error = str(e)
                logger.error(f"Error with {provider_name}: {e}")
                self._record_request(provider_name, False, 0, str(e))
                continue
        
        # All providers failed
        self.stats["failed_requests"] += 1
        error_msg = f"All API providers failed. Last error: {last_error}"
        logger.error(error_msg)
        
        return f"I apologize, but I'm experiencing technical difficulties. Please try again in a moment."
    
    async def _call_api(self, provider_name: str, 
                       messages: List[Dict[str, str]],
                       **kwargs) -> APIResponse:
        """Call a specific API provider"""
        endpoint = self.endpoints.get(provider_name)
        if not endpoint:
            return APIResponse(
                success=False,
                content="",
                provider=provider_name,
                model="",
                error=f"Unknown provider: {provider_name}"
            )
        
        # Check rate limiting
        if not self._check_rate_limit(endpoint):
            return APIResponse(
                success=False,
                content="",
                provider=provider_name,
                model=endpoint.model,
                error="Rate limit exceeded"
            )
        
        start_time = time.time()
        
        try:
            # Route to appropriate handler
            if endpoint.provider == APIProvider.OPENAI:
                response = await self._call_openai(endpoint, messages, **kwargs)
            elif endpoint.provider == APIProvider.ANTHROPIC:
                response = await self._call_anthropic(endpoint, messages, **kwargs)
            elif endpoint.provider == APIProvider.GOOGLE:
                response = await self._call_google(endpoint, messages, **kwargs)
            elif endpoint.provider == APIProvider.OPENROUTER:
                response = await self._call_openrouter(endpoint, messages, **kwargs)
            elif endpoint.provider == APIProvider.GROQ:
                response = await self._call_groq(endpoint, messages, **kwargs)
            elif endpoint.provider == APIProvider.OLLAMA:
                response = await self._call_ollama(endpoint, messages, **kwargs)
            else:
                return APIResponse(
                    success=False,
                    content="",
                    provider=provider_name,
                    model=endpoint.model,
                    error=f"Unsupported provider: {endpoint.provider}"
                )
            
            # Calculate latency
            latency = (time.time() - start_time) * 1000
            response.latency_ms = latency
            
            # Update endpoint stats
            if response.success:
                endpoint.status = APIStatus.HEALTHY
                endpoint.request_count += 1
                endpoint.total_tokens_used += response.tokens_used
                # Update average latency
                endpoint.avg_latency_ms = (
                    (endpoint.avg_latency_ms * (endpoint.request_count - 1) + latency) 
                    / endpoint.request_count
                )
            else:
                endpoint.error_count += 1
                endpoint.last_error = response.error
                
                # Check if we should mark as unhealthy
                if endpoint.error_count > 5:
                    endpoint.status = APIStatus.DEGRADED
                if endpoint.error_count > 10:
                    endpoint.status = APIStatus.UNHEALTHY
            
            endpoint.last_used = datetime.now()
            
            return response
            
        except Exception as e:
            logger.error(f"API call failed: {e}")
            logger.error(traceback.format_exc())
            
            endpoint.error_count += 1
            endpoint.last_error = str(e)
            
            return APIResponse(
                success=False,
                content="",
                provider=provider_name,
                model=endpoint.model,
                error=str(e)
            )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PROVIDER-SPECIFIC IMPLEMENTATIONS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def _call_openai(self, endpoint: APIEndpoint,
                          messages: List[Dict[str, str]],
                          **kwargs) -> APIResponse:
        """Call OpenAI API"""
        config = PROVIDER_CONFIGS[APIProvider.OPENAI]
        url = f"{endpoint.base_url or config['base_url']}{config['chat_endpoint']}"
        
        headers = {
            "Authorization": f"Bearer {endpoint.api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "model": endpoint.model,
            "messages": messages,
            "max_tokens": kwargs.get("max_tokens", config["max_tokens"]),
            "temperature": kwargs.get("temperature", 0.7)
        }
        
        async with self.session.post(url, headers=headers, json=payload) as resp:
            if resp.status == 200:
                data = await resp.json()
                content = data["choices"][0]["message"]["content"]
                tokens = data.get("usage", {}).get("total_tokens", 0)
                
                return APIResponse(
                    success=True,
                    content=content,
                    provider="openai",
                    model=endpoint.model,
                    tokens_used=tokens,
                    raw_response=data
                )
            elif resp.status == 429:
                endpoint.status = APIStatus.RATE_LIMITED
                return APIResponse(
                    success=False,
                    content="",
                    provider="openai",
                    model=endpoint.model,
                    error="Rate limited"
                )
            else:
                error_data = await resp.text()
                return APIResponse(
                    success=False,
                    content="",
                    provider="openai",
                    model=endpoint.model,
                    error=f"HTTP {resp.status}: {error_data}"
                )
    
    async def _call_anthropic(self, endpoint: APIEndpoint,
                             messages: List[Dict[str, str]],
                             **kwargs) -> APIResponse:
        """Call Anthropic Claude API"""
        config = PROVIDER_CONFIGS[APIProvider.ANTHROPIC]
        url = f"{endpoint.base_url or config['base_url']}{config['chat_endpoint']}"
        
        headers = {
            "x-api-key": endpoint.api_key,
            "Content-Type": "application/json",
            "anthropic-version": "2023-06-01"
        }
        
        # Convert messages to Anthropic format
        system_msg = ""
        claude_messages = []
        
        for msg in messages:
            if msg["role"] == "system":
                system_msg = msg["content"]
            else:
                claude_messages.append({
                    "role": msg["role"],
                    "content": msg["content"]
                })
        
        payload = {
            "model": endpoint.model,
            "messages": claude_messages,
            "max_tokens": kwargs.get("max_tokens", config["max_tokens"])
        }
        
        if system_msg:
            payload["system"] = system_msg
        
        async with self.session.post(url, headers=headers, json=payload) as resp:
            if resp.status == 200:
                data = await resp.json()
                content = data["content"][0]["text"]
                tokens = data.get("usage", {}).get("input_tokens", 0) + \
                        data.get("usage", {}).get("output_tokens", 0)
                
                return APIResponse(
                    success=True,
                    content=content,
                    provider="anthropic",
                    model=endpoint.model,
                    tokens_used=tokens,
                    raw_response=data
                )
            elif resp.status == 429:
                endpoint.status = APIStatus.RATE_LIMITED
                return APIResponse(
                    success=False,
                    content="",
                    provider="anthropic",
                    model=endpoint.model,
                    error="Rate limited"
                )
            else:
                error_data = await resp.text()
                return APIResponse(
                    success=False,
                    content="",
                    provider="anthropic",
                    model=endpoint.model,
                    error=f"HTTP {resp.status}: {error_data}"
                )
    
    async def _call_google(self, endpoint: APIEndpoint,
                          messages: List[Dict[str, str]],
                          **kwargs) -> APIResponse:
        """Call Google Gemini API"""
        config = PROVIDER_CONFIGS[APIProvider.GOOGLE]
        chat_endpoint = config['chat_endpoint'].format(model=endpoint.model)
        url = f"{endpoint.base_url or config['base_url']}{chat_endpoint}?key={endpoint.api_key}"
        
        headers = {"Content-Type": "application/json"}
        
        # Convert messages to Google format
        contents = []
        for msg in messages:
            if msg["role"] == "system":
                # Prepend to first user message
                continue
            role = "user" if msg["role"] == "user" else "model"
            contents.append({
                "role": role,
                "parts": [{"text": msg["content"]}]
            })
        
        payload = {
            "contents": contents,
            "generationConfig": {
                "maxOutputTokens": kwargs.get("max_tokens", config["max_tokens"]),
                "temperature": kwargs.get("temperature", 0.7)
            }
        }
        
        async with self.session.post(url, headers=headers, json=payload) as resp:
            if resp.status == 200:
                data = await resp.json()
                content = data["candidates"][0]["content"]["parts"][0]["text"]
                
                return APIResponse(
                    success=True,
                    content=content,
                    provider="google",
                    model=endpoint.model,
                    tokens_used=0,  # Google doesn't return token count easily
                    raw_response=data
                )
            else:
                error_data = await resp.text()
                return APIResponse(
                    success=False,
                    content="",
                    provider="google",
                    model=endpoint.model,
                    error=f"HTTP {resp.status}: {error_data}"
                )
    
    async def _call_openrouter(self, endpoint: APIEndpoint,
                               messages: List[Dict[str, str]],
                               **kwargs) -> APIResponse:
        """Call OpenRouter API (multi-model router)"""
        config = PROVIDER_CONFIGS[APIProvider.OPENROUTER]
        url = f"{endpoint.base_url or config['base_url']}{config['chat_endpoint']}"
        
        headers = {
            "Authorization": f"Bearer {endpoint.api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://smile-agent.local",
            "X-Title": "SMILE Agent"
        }
        
        payload = {
            "model": endpoint.model,
            "messages": messages,
            "max_tokens": kwargs.get("max_tokens", config["max_tokens"]),
            "temperature": kwargs.get("temperature", 0.7)
        }
        
        async with self.session.post(url, headers=headers, json=payload) as resp:
            if resp.status == 200:
                data = await resp.json()
                content = data["choices"][0]["message"]["content"]
                tokens = data.get("usage", {}).get("total_tokens", 0)
                
                return APIResponse(
                    success=True,
                    content=content,
                    provider="openrouter",
                    model=data.get("model", endpoint.model),
                    tokens_used=tokens,
                    raw_response=data
                )
            else:
                error_data = await resp.text()
                return APIResponse(
                    success=False,
                    content="",
                    provider="openrouter",
                    model=endpoint.model,
                    error=f"HTTP {resp.status}: {error_data}"
                )
    
    async def _call_groq(self, endpoint: APIEndpoint,
                        messages: List[Dict[str, str]],
                        **kwargs) -> APIResponse:
        """Call Groq API (fast inference)"""
        config = PROVIDER_CONFIGS[APIProvider.GROQ]
        url = f"{endpoint.base_url or config['base_url']}{config['chat_endpoint']}"
        
        headers = {
            "Authorization": f"Bearer {endpoint.api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "model": endpoint.model,
            "messages": messages,
            "max_tokens": kwargs.get("max_tokens", config["max_tokens"]),
            "temperature": kwargs.get("temperature", 0.7)
        }
        
        async with self.session.post(url, headers=headers, json=payload) as resp:
            if resp.status == 200:
                data = await resp.json()
                content = data["choices"][0]["message"]["content"]
                tokens = data.get("usage", {}).get("total_tokens", 0)
                
                return APIResponse(
                    success=True,
                    content=content,
                    provider="groq",
                    model=endpoint.model,
                    tokens_used=tokens,
                    raw_response=data
                )
            else:
                error_data = await resp.text()
                return APIResponse(
                    success=False,
                    content="",
                    provider="groq",
                    model=endpoint.model,
                    error=f"HTTP {resp.status}: {error_data}"
                )
    
    async def _call_ollama(self, endpoint: APIEndpoint,
                          messages: List[Dict[str, str]],
                          **kwargs) -> APIResponse:
        """Call local Ollama API"""
        config = PROVIDER_CONFIGS[APIProvider.OLLAMA]
        url = f"{endpoint.base_url or config['base_url']}{config['chat_endpoint']}"
        
        headers = {"Content-Type": "application/json"}
        
        payload = {
            "model": endpoint.model,
            "messages": messages,
            "stream": False
        }
        
        try:
            async with self.session.post(url, headers=headers, json=payload) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    content = data.get("message", {}).get("content", "")
                    
                    return APIResponse(
                        success=True,
                        content=content,
                        provider="ollama",
                        model=endpoint.model,
                        tokens_used=0,
                        raw_response=data
                    )
                else:
                    error_data = await resp.text()
                    return APIResponse(
                        success=False,
                        content="",
                        provider="ollama",
                        model=endpoint.model,
                        error=f"HTTP {resp.status}: {error_data}"
                    )
        except aiohttp.ClientConnectorError:
            return APIResponse(
                success=False,
                content="",
                provider="ollama",
                model=endpoint.model,
                error="Cannot connect to Ollama. Is it running?"
            )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # RATE LIMITING AND CACHING
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _check_rate_limit(self, endpoint: APIEndpoint) -> bool:
        """Check if request is within rate limits"""
        config = PROVIDER_CONFIGS.get(endpoint.provider, {})
        rate_limit = config.get("rate_limit_per_minute", 60)
        
        now = datetime.now()
        
        # Reset counter if minute has passed
        if endpoint.minute_reset_time is None or \
           now >= endpoint.minute_reset_time:
            endpoint.requests_this_minute = 0
            endpoint.minute_reset_time = now + timedelta(minutes=1)
        
        # Check limit
        if endpoint.requests_this_minute >= rate_limit:
            return False
        
        endpoint.requests_this_minute += 1
        return True
    
    def _generate_cache_key(self, messages: List[Dict[str, str]]) -> str:
        """Generate cache key from messages"""
        content = json.dumps(messages, sort_keys=True)
        return hashlib.md5(content.encode()).hexdigest()
    
    def _get_from_cache(self, key: str) -> Optional[str]:
        """Get response from cache if valid"""
        if key not in self.cache:
            return None
        
        entry = self.cache[key]
        
        # Check TTL
        age = (datetime.now() - entry.created_at).total_seconds()
        if age > self.cache_ttl_seconds:
            del self.cache[key]
            return None
        
        entry.access_count += 1
        return entry.response
    
    def _add_to_cache(self, key: str, response: str, 
                     provider: str, tokens: int):
        """Add response to cache"""
        # Evict oldest entries if cache is full
        if len(self.cache) >= self.cache_max_size:
            oldest_key = min(self.cache.keys(), 
                           key=lambda k: self.cache[k].created_at)
            del self.cache[oldest_key]
        
        self.cache[key] = CacheEntry(
            response=response,
            created_at=datetime.now(),
            provider=provider,
            tokens_saved=tokens
        )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PROVIDER MANAGEMENT
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _get_provider_order(self) -> List[str]:
        """Get ordered list of providers to try"""
        # Start with active provider
        if self.active_provider and self.active_provider in self.endpoints:
            order = [self.active_provider]
        else:
            order = []
        
        # Add other active providers sorted by priority
        other_providers = sorted(
            [(name, ep) for name, ep in self.endpoints.items() 
             if name != self.active_provider and ep.active],
            key=lambda x: (x[1].priority, x[1].error_count)
        )
        
        order.extend([name for name, _ in other_providers])
        
        return order
    
    def _record_request(self, provider: str, success: bool, 
                       latency: float, error: str = None):
        """Record request for analysis"""
        self.request_history.append({
            "provider": provider,
            "success": success,
            "latency_ms": latency,
            "error": error,
            "timestamp": datetime.now().isoformat()
        })
        
        # Check if we should failover
        if not success:
            self.stats["failovers"] += 1
            self._select_best_provider()
    
    async def health_check_all(self):
        """Perform health check on all endpoints"""
        logger.info("Performing health check on all API endpoints...")
        
        for name, endpoint in self.endpoints.items():
            await self._health_check_endpoint(name, endpoint)
        
        self.last_health_check = datetime.now()
        self._select_best_provider()
        
        logger.info("Health check complete")
    
    async def _health_check_endpoint(self, name: str, endpoint: APIEndpoint):
        """Health check a single endpoint"""
        try:
            # Simple test message
            test_messages = [
                {"role": "user", "content": "Say 'OK' and nothing else."}
            ]
            
            response = await self._call_api(name, test_messages, max_tokens=10)
            
            if response.success:
                endpoint.status = APIStatus.HEALTHY
                logger.info(f"✓ {name}: Healthy (latency: {response.latency_ms:.0f}ms)")
            else:
                endpoint.status = APIStatus.DEGRADED
                logger.warning(f"✗ {name}: Degraded - {response.error}")
                
        except Exception as e:
            endpoint.status = APIStatus.UNHEALTHY
            endpoint.last_error = str(e)
            logger.error(f"✗ {name}: Unhealthy - {e}")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # API MANAGEMENT METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def add_api(self, provider_name: str, api_key: str, 
                     model: str = None, priority: int = 5) -> bool:
        """Add a new API endpoint at runtime"""
        try:
            provider = self._get_provider_enum(provider_name)
            if not provider:
                logger.error(f"Unknown provider: {provider_name}")
                return False
            
            config = PROVIDER_CONFIGS.get(provider)
            if not config:
                logger.error(f"No configuration for provider: {provider_name}")
                return False
            
            endpoint = APIEndpoint(
                provider=provider,
                api_key=api_key,
                model=model or config["default_model"],
                priority=priority,
                active=True
            )
            
            self.endpoints[provider_name] = endpoint
            
            # Health check the new endpoint
            await self._health_check_endpoint(provider_name, endpoint)
            
            # Update provider selection
            self._select_best_provider()
            
            logger.info(f"Added new API endpoint: {provider_name}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to add API: {e}")
            return False
    
    async def remove_api(self, provider_name: str) -> bool:
        """Remove an API endpoint"""
        if provider_name in self.endpoints:
            del self.endpoints[provider_name]
            
            if self.active_provider == provider_name:
                self._select_best_provider()
            
            logger.info(f"Removed API endpoint: {provider_name}")
            return True
        return False
    
    async def set_active_provider(self, provider_name: str) -> bool:
        """Manually set the active provider"""
        if provider_name in self.endpoints:
            self.active_provider = provider_name
            logger.info(f"Active provider set to: {provider_name}")
            return True
        return False
    
    async def get_status(self) -> Dict[str, Any]:
        """Get status of all API endpoints"""
        status = {}
        for name, endpoint in self.endpoints.items():
            status[name] = {
                "active": endpoint.active,
                "status": endpoint.status.value,
                "model": endpoint.model,
                "priority": endpoint.priority,
                "request_count": endpoint.request_count,
                "error_count": endpoint.error_count,
                "avg_latency_ms": round(endpoint.avg_latency_ms, 2),
                "last_used": endpoint.last_used.isoformat() if endpoint.last_used else None,
                "last_error": endpoint.last_error
            }
        return status
    
    def get_stats(self) -> Dict[str, Any]:
        """Get overall statistics"""
        cache_stats = {
            "size": len(self.cache),
            "hit_rate": (self.stats["cache_hits"] / max(self.stats["total_requests"], 1)) * 100
        }
        
        return {
            **self.stats,
            "active_provider": self.active_provider,
            "endpoint_count": len(self.endpoints),
            "cache": cache_stats,
            "last_health_check": self.last_health_check.isoformat() if self.last_health_check else None
        }
    
    async def shutdown(self):
        """Graceful shutdown"""
        logger.info("Shutting down API Manager...")
        if self.session:
            await self.session.close()
        logger.info("API Manager shutdown complete")