# channel_watcher.py

import re
from telethon import events

from storage import load_map
from state import is_channel_watch_enabled
from logger import send_log
from user_worker import trigger_from_channel


# ---------------- EPISODE FILTER ----------------

EP_REGEX = re.compile(
    r'(episode|ep|e)\s*[-:]?\s*\d{1,4}',
    re.IGNORECASE
)

IGNORE_KEYWORDS = (
    "batch",
    "movie",
    "ova",
    "special",
    "complete",
    "season pack"
)


def is_episode_post(message) -> bool:
    """
    Return True only if message looks like an episode post
    """

    text = (
        (message.text or "") +
        " " +
        (message.message or "")
    ).lower().strip()

    if not text:
        return False

    # Ignore unwanted keywords
    for bad in IGNORE_KEYWORDS:
        if bad in text:
            return False

    # Episode regex match
    return bool(EP_REGEX.search(text))


# ---------------- CHANNEL WATCHER ----------------

def setup_channel_watcher(client):
    """
    Attach automatic channel watcher to Telethon client
    """

    @client.on(events.NewMessage)
    async def channel_handler(event):

        # Watcher OFF → do nothing
        if not is_channel_watch_enabled():
            return

        # Only channel posts
        if not event.is_channel:
            return

        channel_id = str(event.chat_id)

        # Only mapped channels
        if channel_id not in load_map():
            return

        message = event.message

        # Episode-only trigger
        if not is_episode_post(message):
            return

        await send_log(
            f"📡 Episode detected\n"
            f"Channel: {channel_id}"
        )

        try:
            # Same pipeline as /test
            await trigger_from_channel(
                channel_id=channel_id,
                message=message
            )
        except Exception as e:
            await send_log(f"❌ Channel watcher error: {e}")
