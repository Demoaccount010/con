# main.py

import asyncio
from telethon import TelegramClient
from telethon.sessions import StringSession

from config import API_ID, API_HASH, BOT_TOKEN
from logger import log
from controller_bot import setup_controller
from channel_watcher import setup_channel_watcher
from user_worker import start_worker


async def main():
    # ---------------- BOT CLIENT ----------------
    bot = TelegramClient(
        "controller_bot",
        API_ID,
        API_HASH
    )

    await bot.start(bot_token=BOT_TOKEN)

    # ---------------- LOGGER ----------------
    init_logger(bot)
    log.info("🤖 Controller bot running")

    # ---------------- CONTROLLER (COMMANDS) ----------------
    setup_controller(bot)

    # ---------------- CHANNEL WATCHER ----------------
    setup_channel_watcher(bot)
    log.info("📡 Channel watcher attached")

    # ---------------- USERBOT WORKER ----------------
    # DM watcher + file forward system
    asyncio.create_task(start_worker())

    # ---------------- RUN ----------------
    await bot.run_until_disconnected()


if __name__ == "__main__":
    asyncio.run(main())
