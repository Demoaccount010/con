# state.py

CHANNEL_WATCH_ENABLED = False


def enable_channel_watch():
    """
    Enable automatic channel watcher
    """
    global CHANNEL_WATCH_ENABLED
    CHANNEL_WATCH_ENABLED = True


def disable_channel_watch():
    """
    Disable automatic channel watcher
    """
    global CHANNEL_WATCH_ENABLED
    CHANNEL_WATCH_ENABLED = False


def is_channel_watch_enabled():
    """
    Return current watcher state
    """
    return CHANNEL_WATCH_ENABLED
