# channel_forwarder.py
# ==========================================
# ONLY CHANNEL → CHANNEL VIDEO FORWARDER
# - No bot
# - No buttons
# - No DM
# - No photos / docs
# ==========================================

import os
import re
import asyncio
from telethon import TelegramClient, events
from telethon.sessions import StringSession

from config import API_ID, API_HASH, DATA_DIR

# ================= CONFIG =================

SESSION_FILE = os.path.join(DATA_DIR, "user.session")

# SOURCE_CHANNEL_ID : [TARGET_CHANNEL_IDs]
CHANNEL_MAP = {
    -1001234567890: [-1009876543210],
    # add more if needed
}

# Rename format (optional)
RENAME_TEMPLATE = "Episode_{ep}_{quality}.mp4"

# ================= HELPERS =================

def detect_episode(text: str):
    if not text:
        return None

    patterns = [
        r"S\d{1,2}\s*E\s*(\d{1,3})",
        r"Episode\s*(\d{1,3})",
        r"\bEP\s*(\d{1,3})\b",
        r"\[(\d{1,3})\]"
    ]

    for p in patterns:
        m = re.search(p, text, re.I)
        if m:
            return m.group(1).zfill(2)

    return "NA"


def detect_quality(text: str):
    if not text:
        return "NA"

    m = re.search(r"(360p|480p|720p|1080p|2160p|4k)", text, re.I)
    if not m:
        return "NA"

    q = m.group(1).upper()
    return "2160p" if q == "4K" else q


# ================= MAIN =================

async def main():
    if not os.path.exists(SESSION_FILE):
        print("❌ user.session not found")
        return

    session = open(SESSION_FILE).read().strip()

    client = TelegramClient(
        StringSession(session),
        API_ID,
        API_HASH
    )

    await client.start()
    print("✅ Channel forwarder started")

    @client.on(events.NewMessage)
    async def handler(event):
        if not event.is_channel:
            return

        source_id = event.chat_id
        if source_id not in CHANNEL_MAP:
            return

        msg = event.message

        # ❌ ONLY VIDEO ALLOWED
        if not msg.video:
            return

        text = msg.text or msg.file.name or ""
        ep = detect_episode(text)
        q = detect_quality(text)

        filename = RENAME_TEMPLATE.format(ep=ep, quality=q)

        for target in CHANNEL_MAP[source_id]:
            try:
                await client.send_file(
                    target,
                    msg.video,
                    file_name=filename
                )
                print(f"✅ Video forwarded → {target}")

            except Exception as e:
                print(f"❌ Forward failed → {e}")

    await client.run_until_disconnected()


if __name__ == "__main__":
    asyncio.run(main())
                                             