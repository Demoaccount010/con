import asyncio
from telethon.tl.types import MessageMediaDocument, MessageMediaPhoto
from storage import load_map
from logger import log


class DMWatcher:
    def __init__(self, client):
        self.client = client
        self.last_ids = {}  # bot_username -> last_message_id

    async def watch_bot(self, bot_username):
        log.info(f"👀 Watching DM of @{bot_username}")

        while True:
            try:
                msgs = await self.client.get_messages(bot_username, limit=5)

                for msg in reversed(msgs):
                    last_id = self.last_ids.get(bot_username, 0)
                    if msg.id <= last_id:
                        continue

                    self.last_ids[bot_username] = msg.id

                    if not msg.media:
                        continue

                    if isinstance(msg.media, (MessageMediaDocument, MessageMediaPhoto)):
                        await self.forward_file(msg)

            except Exception as e:
                log.error(f"DM Watch error: {e}")

            await asyncio.sleep(1.5)

    async def forward_file(self, msg):
        mappings = load_map()
        if not mappings:
            return

        caption = msg.text or ""

        log.info("📥 File captured via DM watcher")

        for _, targets in mappings.items():
            for tgt in targets:
                try:
                    await self.client.send_file(
                        int(tgt),
                        msg.media,
                        caption=caption
                    )
                    log.info(f"📤 Forwarded to {tgt}")
                except Exception as e:
                    log.error(e)
