import asyncio
from pyrogram import Client

# 1. Enter your API ID and HASH from my.telegram.org
API_ID = 35965546       # Replace with your API_ID (Integer)
API_HASH = "204960f68e3b090929efbdfffe7e2223" # Replace with your API_HASH

async def main():
    async with Client("my_account", api_id=API_ID, api_hash=API_HASH) as app:
        # This will send the session string to your "Saved Messages" in Telegram
        session_string = await app.export_session_string()
        print("\n\n✅ HERE IS YOUR SESSION STRING (COPY THIS):")
        print(f"\n{session_string}\n")
        print("✅ It has also been sent to your Telegram Saved Messages.")

if __name__ == "__main__":
    asyncio.run(main())