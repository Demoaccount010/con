import logging
import asyncio
from pyrogram import Client, idle
from config import Config
from database import db

# Setup Logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

async def main():
    # 1. Initialize Bot
    logger.info("Initializing Bot...")
    bot = Client(
        "AnimeBot",
        api_id=Config.API_ID,
        api_hash=Config.API_HASH,
        bot_token=Config.BOT_TOKEN,
        plugins=dict(root="bot/plugins")
    )

    # 2. Initialize Userbot
    logger.info("Initializing Userbot...")
    userbot = Client(
        "AnimeUserbot",
        api_id=Config.API_ID,
        api_hash=Config.API_HASH,
        session_string=Config.USERBOT_SESSION
    )

    # 3. Attach Userbot to Bot instance for cross-communication
    bot.userbot = userbot

    # 4. Start Clients
    logger.info("Starting System...")
    
    try:
        await bot.start()
        await userbot.start()
        
        me_bot = await bot.get_me()
        me_user = await userbot.get_me()
        
        logger.info(f"Bot Started as @{me_bot.username}")
        logger.info(f"Userbot Started as {me_user.first_name}")
        
        # Send Startup Alert to Owner
        try:
            await bot.send_message(
                Config.OWNER_ID, 
                "🚀 **Anime System Online!**\nDatabase: JSON (Local)\nBot & Userbot Connected."
            )
        except Exception:
            pass
            
        await idle()
        
    except Exception as e:
        logger.error(f"Startup Error: {e}")
    finally:
        await bot.stop()
        await userbot.stop()
        logger.info("System Stopped.")

if __name__ == "__main__":
    try:
        import uvloop
        uvloop.install()
    except ImportError:
        pass
        
    asyncio.run(main())