import os

class Config:
    # Get from https://my.telegram.org
    API_ID = int(os.environ.get("API_ID", "35965546"))
    API_HASH = os.environ.get("API_HASH", "204960f68e3b090929efbdfffe7e2223")
    
    # Get from @BotFather
    BOT_TOKEN = os.environ.get("BOT_TOKEN", "8308219172:AAG7rvzF7PGlbSXg36wTHLbVgZdR7uOEulc")
    
    # Your Telegram User ID (Integer)
    OWNER_ID = int(os.environ.get("OWNER_ID", "2034253345"))
    
    # The Channel ID users must join (e.g., -100xxxxxx)
    FORCE_SUB_CHANNEL = int(os.environ.get("FORCE_SUB_CHANNEL", "-1001712308627"))
    FORCE_SUB_LINK = os.environ.get("FORCE_SUB_LINK", "https://t.me/crunchyroll_hindi_dub_yt")

    # Pyrogram Session String for Userbot (Run gen_session.py to get this)
    USERBOT_SESSION = os.environ.get("USERBOT_SESSION", "BQIkymoAOzDFMUyaDFkYbCUgzOm1sWXqzk0DfyxlDlNDhU1NRZwtDyinPGS1LWvbagpjWGzMvZVi6fHtnw3j6o8VYmmaLk09B_rbUSFMkDgQORyL94iHqatCbTeShqMpRewSfI32AgH9RQmzGKcfEHMpvLzFQ6DleqSl-nexYTVh7dBSScP33ge8yDC64UqliXSKhOGzD1oKyZ8XYSyKk3YH5wn2hD7KBINeCH5dncg6K0ilhrHOyTJK2jW-NN85ytgMKSCKWwnQ0utiiQHPm_oy8AR9usXqAtT3cBtxhEN2ndD-F45ou0TsO1OtqYiA75nc4ccXYXdHeDKFe1xNJvx5YpGnWgAAAAGp4TT3AA")
    
    REQUEST_CHANNEL_ID = int(os.environ.get("REQUEST_CHANNEL_ID", "-1003625165732"))
    
    REQUEST_CHANNEL_LINK = os.environ.get("REQUEST_CHANNEL_LINK", "https://t.me/+VH-PS9GLiAwyOGU1")

    # Paths for JSON Data
    SETTINGS_FILE = "data/settings.json"
    USERS_FILE = "data/users.json"