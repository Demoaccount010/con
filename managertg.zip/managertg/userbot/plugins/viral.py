from pyrogram import Client, filters, enums
from config import Config
from utils.viral_gen import generate_viral_name

# Triggered by owner sending ".makeviral"
@Client.on_message(filters.command("makeviral", prefixes=".") & filters.user(Config.OWNER_ID))
async def create_viral_channel(client, message):
    status_msg = await message.reply("🔄 **Generating Viral Channel...**")
    
    try:
        # 1. Generate Name
        channel_name = generate_viral_name()
        
        # 2. Create Channel
        chat = await client.create_channel(
            title=channel_name,
            description=f"Official {channel_name}. Join now!"
        )
        
        # 3. Set Username
        base_username = channel_name.replace(" ", "")
        final_username = f"{base_username}_{message.id}"
        await client.set_chat_username(chat.id, final_username)
        
        # 4. Link to Group (if applicable)
        link_txt = "Skipped (Not in group)"
        if message.chat.type in [enums.ChatType.SUPERGROUP, enums.ChatType.GROUP]:
            try:
                await client.set_chat_linked_chat(message.chat.id, chat.id)
                link_txt = "✅ Linked Successfully"
            except Exception as e:
                link_txt = f"❌ Link Failed: {e}"

        await status_msg.edit_text(
            f"✅ **VIRAL CHANNEL READY**\n\n"
            f"📛 Name: `{channel_name}`\n"
            f"🔗 User: @{final_username}\n"
            f"🔗 Group Link: {link_txt}"
        )

    except Exception as e:
        await status_msg.edit_text(f"❌ **Error:** {e}")