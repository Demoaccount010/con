from pyrogram import Client, types, enums
from config import Config
from database import db
from functools import wraps

def only_owner(func):
    @wraps(func)
    async def wrapper(client, message):
        if message.from_user.id != Config.OWNER_ID:
            try:
                await message.delete()
            except:
                pass
            return
        return await func(client, message)
    return wrapper

def feature_enabled(feature_name):
    """If feature is OFF in JSON, command is ignored."""
    def decorator(func):
        @wraps(func)
        async def wrapper(client, message):
            if not await db.is_feature_enabled(feature_name):
                return
            return await func(client, message)
        return wrapper
    return decorator

def admins_only(func):
    @wraps(func)
    async def wrapper(client, message):
        if message.from_user.id == Config.OWNER_ID:
            return await func(client, message)
            
        try:
            member = await client.get_chat_member(message.chat.id, message.from_user.id)
            if member.status not in [enums.ChatMemberStatus.ADMINISTRATOR, enums.ChatMemberStatus.OWNER]:
                try: await message.delete()
                except: pass
                return
        except:
            return
            
        return await func(client, message)
    return wrapper