import random
import re

EMOJIS = ["🔥", "⚡️", "✨", "🎬", "🇮🇳", "💿"]

def generate_viral_name(anime_name):
    """Generates names specifically with Hindi Dubbed keywords."""
    emoji = random.choice(EMOJIS)
    
    # Strict naming patterns requested
    formats = [
        f"{anime_name} Hindi Dubbed {emoji}",
        f"{anime_name} Official Hindi Dubbed 🇮🇳",
        f"{anime_name} Hindi Dubbed [Official] {emoji}",
        f"{anime_name} Hindi Dubbed Movies 🎬",
        f"{anime_name} All Episodes Hindi Dubbed {emoji}"
    ]
    return random.choice(formats)

def generate_viral_description(anime_name):
    desc = (
        f"📺 {anime_name} - Official Hindi Dubbed\n\n"
        f"🇮🇳 Language: Hindi + Japanese [Dual Audio]\n"
        f"💿 Quality: 480p, 720p, 1080p HEVC\n"
        f"✨ Status: Uploading Daily\n\n"
        f"👇 Join Channel for Updates:\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"🔥 Official Hindi Dubbed | No Ads ⚡️"
    )
    return desc

def generate_username_candidates(anime_name):
    clean = re.sub(r'[^a-zA-Z0-9]', '', anime_name)
    candidates = [
        f"{clean}HindiDubbed",
        f"{clean}OfficialHindi",
        f"{clean}_Hindi_Dubbed",
        f"Real{clean}Hindi",
        f"{clean}HindiDubbed_Official"
    ]
    # Add uniqueness
    final = [c + str(random.randint(1, 999)) for c in candidates]
    return final