import asyncio
import os
import aiohttp
import aiofiles
from pyrogram import Client, filters, errors
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from config import Config
from utils.viral import generate_viral_name, generate_username_candidates, generate_viral_description

# --- HELPERS ---
async def get_anime_photo(anime_name):
    url = f"https://api.jikan.moe/v4/anime?q={anime_name}&limit=1"
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    if data['data']: return data['data'][0]['images']['jpg']['large_image_url']
    except: pass
    return None

async def download_image(url, filename):
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                if resp.status == 200:
                    f = await aiofiles.open(filename, mode='wb')
                    await f.write(await resp.read()); await f.close()
                    return True
    except: pass
    return False
# ---------------

@Client.on_callback_query(filters.regex(r"^(accept|decline|already|mkpub|mkpvt)_"))
async def process_request(client, callback):
    if callback.from_user.id != Config.OWNER_ID:
        return await callback.answer("❌ Admins Only!", show_alert=True)

    action, user_id = callback.data.split("_")
    user_id = int(user_id)
    message = callback.message

    # 🚨 FIXED PARSING LOGIC (Handles Original AND Menu)
    anime_name = "Unknown"
    found = False
    
    # Check text and caption
    raw_text = message.text or message.caption or ""
    
    for line in raw_text.split("\n"):
        clean_line = line.replace("*", "").replace("`", "").replace("📺", "").strip()
        
        # 1. Look for Original Request ("Anime: Naruto")
        if "Anime:" in clean_line:
            anime_name = clean_line.replace("Anime:", "").strip()
            found = True
            break
            
        # 2. Look for Menu Header ("Setup: Naruto")
        if "Setup:" in clean_line:
            anime_name = clean_line.replace("Setup:", "").replace("⚙️", "").strip()
            found = True
            break

    if not found:
        # Debugging: Print what the bot saw
        print(f"DEBUG FAIL: {raw_text}")
        return await callback.answer("❌ Error: Could not read Anime Name. Check Logs.", show_alert=True)

    # --- ACTIONS ---

    if action == "accept":
        await message.edit_text(
            f"⚙️ **Setup: {anime_name}**\n👇 **Select Type:**",
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("📢 Public", callback_data=f"mkpub_{user_id}"),
                    InlineKeyboardButton("🔒 Private", callback_data=f"mkpvt_{user_id}")
                ],
                [InlineKeyboardButton("🔙 Cancel", callback_data=f"decline_{user_id}")]
            ])
        )
        return

    if action == "mkpub":
        await create_channel_logic(client, message, user_id, anime_name, is_public=True)
    elif action == "mkpvt":
        await create_channel_logic(client, message, user_id, anime_name, is_public=False)
    elif action == "already":
        await message.edit_text(f"✅ **Marked: Already Available**\n📺 `{anime_name}`")
        try: await client.send_message(user_id, f"🎉 **Good News!**\n**{anime_name}** is already available on our channel.")
        except: pass
    elif action == "decline":
        await message.edit_text(f"❌ **Declined**\n📺 `{anime_name}`")
        try: await client.send_message(user_id, f"❌ Request for **{anime_name}** declined.")
        except: pass

async def create_channel_logic(client, message, user_id, anime_name, is_public):
    type_text = "Public" if is_public else "Private"
    await message.edit_text(f"🔄 **Creating {type_text} Channel...**\n`{anime_name}`")
    
    userbot = client.userbot
    if not userbot: return await message.edit_text("❌ Userbot Disconnected.")
    
    try:
        # Create
        title = generate_viral_name(anime_name)
        desc = generate_viral_description(anime_name)
        chat = await userbot.create_channel(title, desc)
        
        await asyncio.sleep(2)

        # Photo
        photo_path = f"data/req_{anime_name.replace(' ', '_')}.jpg"
        img = await get_anime_photo(anime_name)
        if img and await download_image(img, photo_path):
            try: 
                await userbot.set_chat_photo(chat.id, photo=photo_path)
                os.remove(photo_path)
            except: pass
        
        await asyncio.sleep(1)

        # Link
        invite_link = "Error"
        if is_public:
            candidates = generate_username_candidates(anime_name)
            success = False
            for u in candidates:
                try:
                    await userbot.set_chat_username(chat.id, u)
                    invite_link = f"https://t.me/{u}"
                    success = True
                    break
                except errors.UsernameOccupied: continue
                except errors.UsernameInvalid: continue
                except errors.FloodWait as e: await asyncio.sleep(e.value)
            
            if not success: invite_link = "Username Limit/Taken"
        else:
            try: invite_link = await userbot.export_chat_invite_link(chat.id)
            except Exception as e: invite_link = f"Error: {e}"

        # Success
        await message.edit_text(
            f"✅ **{type_text} Channel Created!**\n"
            f"📺 **Name:** {title}\n"
            f"🔗 **Link:** {invite_link}"
        )
        
        try:
            await client.send_message(
                user_id,
                f"🎉 **Request Accepted!**\n\n"
                f"📺 **{title}**\n"
                f"🔗 **Join:** {invite_link}"
            )
        except: pass

    except errors.FloodWait as e:
        await message.edit_text(f"❌ **FloodWait:** {e.value}s")
    except Exception as e:
        await message.edit_text(f"❌ **Error:** `{str(e)}`")