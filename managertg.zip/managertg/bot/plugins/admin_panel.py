import asyncio
import time
from pyrogram import Client, filters, errors
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from config import Config
from database import db

# --------------------------
# 1. USERS STATS COMMAND
# --------------------------
@Client.on_message(filters.command("users") & filters.user(Config.OWNER_ID))
async def users_stats(client, message):
    users = await db.get_all_users()
    count = len(users)
    await message.reply(
        f"📊 **Database Statistics**\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"👤 **Verified Users:** `{count}`\n"
        f"🤖 **Status:** Active"
    )

# --------------------------
# 2. BROADCAST COMMAND (/brod)
# --------------------------
@Client.on_message(filters.command("brod") & filters.user(Config.OWNER_ID) & filters.private)
async def broadcast_handler(client, message):
    if not message.reply_to_message:
        return await message.reply("⚠️ **Usage:** Reply to a message you want to broadcast with `/brod`.")

    users = await db.get_all_users()
    msg = await message.reply(f"⏳ **Starting Broadcast...**\nTarget: `{len(users)}` users.")
    
    start_time = time.time()
    success = 0
    blocked = 0
    deleted = 0
    failed = 0
    
    for user_id in users:
        try:
            # COPY message hides the sender (Owner ID)
            await message.reply_to_message.copy(chat_id=user_id)
            success += 1
        except errors.FloodWait as e:
            await asyncio.sleep(e.value)
            await message.reply_to_message.copy(chat_id=user_id)
            success += 1
        except errors.InputUserDeactivated:
            deleted += 1
        except errors.UserIsBlocked:
            blocked += 1
        except Exception:
            failed += 1
        
        # Avoid flooding Telegram limits
        # await asyncio.sleep(0.1) 
    
    end_time = time.time()
    taken = round(end_time - start_time, 2)
    
    await msg.edit_text(
        f"✅ **Broadcast Complete!**\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"⏱ **Time:** `{taken}s`\n"
        f"👥 **Total Users:** `{len(users)}`\n"
        f"✅ **Success:** `{success}`\n"
        f"🚫 **Blocked:** `{blocked}`\n"
        f"💀 **Deleted:** `{deleted}`\n"
        f"⚠️ **Failed:** `{failed}`"
    )

# --------------------------
# 3. MASTER PANEL (Existing)
# --------------------------
@Client.on_callback_query(filters.regex("master_panel") & filters.user(Config.OWNER_ID))
async def master_panel(client, callback):
    settings = await db.get_settings()
    def btn(text, key):
        status = "✅" if settings.get(key) else "❌"
        return InlineKeyboardButton(f"{text} {status}", callback_data=f"toggle_{key}")

    buttons = [
        [btn("Welcome", "welcome"), btn("Anti-Link", "antilink")],
        [btn("Warns", "warn"), btn("Anti-Flood", "antiflood")],
        [btn("Force Sub", "force_sub"), btn("Media Lock", "media_lock")],
        [InlineKeyboardButton("🤖 Bot Groups (Manage)", callback_data="list_bot_groups")],
        [InlineKeyboardButton("🔙 Back", callback_data="verify_owner")]
    ]
    await callback.message.edit_text("🎛 **Master Panel**", reply_markup=InlineKeyboardMarkup(buttons))

@Client.on_callback_query(filters.regex(r"toggle_") & filters.user(Config.OWNER_ID))
async def toggle_setting(client, callback):
    key = callback.data.split("_", 1)[1]
    settings = await db.get_settings()
    await db.update_setting(key, not settings.get(key, False))
    await master_panel(client, callback)

# --- BOT GROUP MANAGER ---
@Client.on_callback_query(filters.regex("list_bot_groups") & filters.user(Config.OWNER_ID))
async def list_bot_groups(client, callback):
    groups = await db.get_all_groups()
    if not groups:
        return await callback.message.edit_text(
            "❌ **No Groups Found.**\nSend a message in a group to register.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="master_panel")]])
        )

    text = "📂 **Managed Groups:**\nSelect a group to manage:\n"
    buttons = []
    
    for chat_id, title in list(groups.items())[:10]:
        buttons.append([InlineKeyboardButton(f"{title}", callback_data=f"mangrp_{chat_id}")])
        
    buttons.append([InlineKeyboardButton("🔙 Back", callback_data="master_panel")])
    await callback.message.edit_text(text, reply_markup=InlineKeyboardMarkup(buttons))

@Client.on_callback_query(filters.regex(r"mangrp_") & filters.user(Config.OWNER_ID))
async def manage_specific_group(client, callback):
    chat_id = callback.data.split("_")[1]
    groups = await db.get_all_groups()
    title = groups.get(chat_id, "Unknown Group")
    
    text = (f"⚙️ **Managing:** {title}\n🆔 **ID:** `{chat_id}`\n\nWhat do you want to do?")
    buttons = [
        [InlineKeyboardButton("👋 Leave Group", callback_data=f"leave_{chat_id}")],
        [InlineKeyboardButton("🔙 Back", callback_data="list_bot_groups")]
    ]
    await callback.message.edit_text(text, reply_markup=InlineKeyboardMarkup(buttons))

@Client.on_callback_query(filters.regex(r"leave_") & filters.user(Config.OWNER_ID))
async def leave_group_handler(client, callback):
    chat_id = int(callback.data.split("_")[1])
    try:
        await client.leave_chat(chat_id)
        await db.remove_group(chat_id)
        await callback.answer("✅ Left group successfully!", show_alert=True)
        await list_bot_groups(client, callback)
    except Exception as e:
        await callback.answer(f"❌ Error: {e}", show_alert=True)