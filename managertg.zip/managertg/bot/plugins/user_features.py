import aiohttp
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from config import Config
from database import db

# --- JIKAN API & SEARCH HELPERS ---
async def search_anime_titles(query):
    url = f"https://api.jikan.moe/v4/anime?q={query}&limit=5"
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data['data']
    except: pass
    return []

async def get_anime_by_id(mal_id):
    url = f"https://api.jikan.moe/v4/anime/{mal_id}"
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data['data']
    except: pass
    return None

async def search_main_channel(userbot, query):
    results = []
    if not userbot: return []
    try:
        async for message in userbot.search_messages(Config.FORCE_SUB_CHANNEL, query=query, limit=20):
            if not (message.photo or message.video or message.document): continue 
            raw_text = message.caption or "Anime File"
            label = raw_text.split("\n")[0][:30] + "..."
            results.append({"label": label, "link": message.link})
            if len(results) >= 5: break     
    except: pass
    return results

# --------------------------
# 1. REPORT COMMAND (/report)
# --------------------------
@Client.on_message(filters.command("report") & filters.group)
async def report_handler(client, message):
    if not await db.is_verified(message.from_user.id):
        return await message.reply(
            f"❌ {message.from_user.mention}, Verify first!",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔐 Verify", url=f"https://t.me/{client.me.username}?start=verify")]])
        )

    # Get Report Reason
    if message.reply_to_message:
        reason = "Reported a message (See Forward)"
    elif len(message.command) > 1:
        reason = " ".join(message.command[1:])
    else:
        return await message.reply("⚠️ **Usage:** `/report <reason>` or reply to a message.")

    # Notify User
    await message.reply(f"✅ **Report Sent!** Admin has been notified.")

    # Send to Owner
    user = message.from_user
    chat = message.chat
    
    report_text = (
        f"🚨 **NEW GROUP REPORT**\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"👤 **Reporter:** {user.mention} (`{user.id}`)\n"
        f"📂 **Group:** {chat.title}\n"
        f"📝 **Reason:** {reason}\n"
        f"🔗 **Link:** {message.link}"
    )
    
    try:
        await client.send_message(Config.OWNER_ID, report_text)
        if message.reply_to_message:
            await message.reply_to_message.forward(Config.OWNER_ID)
    except Exception as e:
        print(f"Report Error: {e}")

# --------------------------
# 2. SEARCH COMMAND (/s)
# --------------------------
@Client.on_message(filters.command(["s", "search"]))
async def search_handler(client, message):
    user_id = message.from_user.id
    if not await db.is_verified(user_id):
        if message.chat.type == str(filters.private):
            return await message.reply("❌ Verify first.")
        return await message.reply("❌ Access Denied! Verify first.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔐 Verify", url=f"https://t.me/{client.me.username}?start=verify")]]))

    if len(message.command) < 2: return await message.reply("⚠️ **Usage:** `/s <Anime Name>`")
    query = " ".join(message.command[1:])
    status_msg = await message.reply(f"🔍 **Searching:** `{query}`...")

    results = await search_main_channel(client.userbot, query)

    if results:
        buttons = []
        for res in results:
            buttons.append([InlineKeyboardButton(f"🎬 {res['label']}", url=res['link'])])
        await status_msg.edit(f"✅ **Found {len(results)} Uploads:**", reply_markup=InlineKeyboardMarkup(buttons))
    else:
        short_query = query[:40]
        await status_msg.edit(f"❌ **Not Found.**\n👇 **Request:**", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("📨 Request Now", callback_data=f"autoreq_{short_query}")]]))

# --------------------------
# 3. REQUEST COMMAND
# --------------------------
@Client.on_message(filters.command("request"))
async def request_handler(client, message):
    user_id = message.from_user.id
    if not await db.is_verified(user_id):
        if message.chat.type == str(filters.private): return await message.reply("❌ Verify first.")
        return await message.reply("❌ Access Denied! Verify first.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔐 Verify", url=f"https://t.me/{client.me.username}?start=verify")]]))

    if len(message.command) < 2: return await message.reply("⚠️ **Usage:** `/request <Anime Name>`")
    query = " ".join(message.command[1:])
    status_msg = await message.reply(f"🔄 **Processing:** `{query}`...")

    existing = await search_main_channel(client.userbot, query)
    if existing:
        buttons = []
        for res in existing: buttons.append([InlineKeyboardButton(f"🎬 {res['label']}", url=res['link'])])
        return await status_msg.edit(f"🎉 **Already Available:**", reply_markup=InlineKeyboardMarkup(buttons))

    await start_jikan_flow(status_msg, query)

# --------------------------
# 4. CALLBACKS (Auto-Req, Jikan, Confirm)
# --------------------------
@Client.on_callback_query(filters.regex("autoreq_"))
async def auto_request_callback(client, callback):
    query = callback.data.split("_", 1)[1]
    await callback.message.edit_text(f"🔄 **Processing:** `{query}`...")
    await start_jikan_flow(callback.message, query)

async def start_jikan_flow(message, query):
    try: results = await search_anime_titles(query)
    except: results = []

    if not results: return await message.edit_text(f"❌ **Not Found.** Check spelling.")

    buttons = []
    for anime in results:
        title = anime['title_english'] or anime['title']
        mal_id = anime['mal_id']
        btn_text = f"{title[:30]} ({anime['type']})"
        buttons.append([InlineKeyboardButton(btn_text, callback_data=f"confreq_{mal_id}")])
    buttons.append([InlineKeyboardButton("❌ Cancel", callback_data=f"cancel_req")])

    await message.edit_text(f"🤔 **Did you mean?**", reply_markup=InlineKeyboardMarkup(buttons))

@Client.on_callback_query(filters.regex("confreq_"))
async def confirm_request_handler(client, callback):
    mal_id = callback.data.split("_")[1]
    user = callback.from_user
    chat_title = callback.message.chat.title if callback.message.chat.title else "Private Chat"
    
    anime_data = await get_anime_by_id(mal_id)
    if not anime_data: return await callback.message.edit_text("❌ Error fetching details.")
    final_title = anime_data.get('title_english') or anime_data.get('title')
    
    admin_text = (
        f"🔔 **NEW REQUEST**\n"
        f"══════════════════\n"
        f"👤 **Requester:** {user.mention} (`{user.id}`)\n"
        f"📂 **Source:** {chat_title}\n"
        f"📺 **Anime:** `{final_title}`\n"
        f"══════════════════\n"
        f"👇 **Action:**"
    )

    buttons = [
        [InlineKeyboardButton("✅ Accept", callback_data=f"accept_{user.id}"), InlineKeyboardButton("📂 Available", callback_data=f"already_{user.id}")],
        [InlineKeyboardButton("❌ Decline", callback_data=f"decline_{user.id}")]
    ]

    try:
        await client.send_message(Config.REQUEST_CHANNEL_ID, admin_text, reply_markup=InlineKeyboardMarkup(buttons))
        await callback.message.edit_text(f"✅ **Request Sent!**\n📺 `{final_title}`", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("👀 Track Status", url=Config.REQUEST_CHANNEL_LINK)]]))
    except Exception as e:
        await callback.message.edit_text(f"❌ Error: {e}")

@Client.on_callback_query(filters.regex("cancel_req"))
async def cancel_request(client, callback):
    await callback.message.edit_text("❌ Request Cancelled.")

@Client.on_callback_query(filters.regex("user_cmds"))
async def user_commands_panel(client, callback):
    text = (
        "📚 **USER COMMANDS**\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "🔹 **/s <name>** - Search Anime\n"
        "🔹 **/request <name>** - Request Anime\n"
        "🔹 **/report <text>** - Report to Admin\n"
        "🔹 **/start** - Verification\n"
        "🔹 **/info** - Bot Status"
    )
    await callback.message.edit_text(text, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="verify_user")]]))