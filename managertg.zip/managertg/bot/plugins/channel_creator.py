import asyncio
import os
import aiohttp
import aiofiles
from pyrogram import Client, filters, errors
from config import Config
from utils.viral import generate_viral_name, generate_username_candidates

# Helper to fetch Anime Image
async def get_anime_photo(anime_name):
    """Fetches the best image URL for an anime from Jikan API"""
    api_url = f"https://api.jikan.moe/v4/anime?q={anime_name}&limit=1"
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(api_url) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    if data['data']:
                        return data['data'][0]['images']['jpg']['large_image_url']
    except Exception as e:
        print(f"Image Fetch Error: {e}")
    return None

async def download_image(url, filename):
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                if resp.status == 200:
                    f = await aiofiles.open(filename, mode='wb')
                    await f.write(await resp.read())
                    await f.close()
                    return True
    except:
        return False
    return False

@Client.on_message(filters.command("create") & filters.private & filters.user(Config.OWNER_ID))
async def create_channel_handler(bot, message):
    if len(message.command) < 2:
        return await message.reply("Usage: `/create <Anime Name>`")
    
    anime_query = " ".join(message.command[1:])
    status_msg = await message.reply(f"⚡️ Processing creation for: **{anime_query}**...")
    
    userbot = bot.userbot 
    
    # 1. Generate Assets
    channel_title = generate_viral_name(anime_query)
    username_candidates = generate_username_candidates(anime_query)
    
    created_chat = None
    final_username = None
    photo_path = f"data/{anime_query.replace(' ', '_')}.jpg"

    try:
        # 2. Create Channel
        created_chat = await userbot.create_channel(
            title=channel_title, 
            description="Official Anime Channel | Hindi Dubbed & Subbed | Join for updates!"
        )
        await status_msg.edit(f"✅ Channel Created: `{channel_title}`\n🔄 Setting Photo & Username...")

        # 3. Set Channel Photo (From Anime Name)
        image_url = await get_anime_photo(anime_query)
        if image_url:
            if await download_image(image_url, photo_path):
                try:
                    await userbot.set_chat_photo(created_chat.id, photo=photo_path)
                    os.remove(photo_path) # Clean up
                except Exception as e:
                    print(f"Photo Set Error: {e}")
        
        # 4. Set Username
        for user in username_candidates:
            try:
                await userbot.set_chat_username(created_chat.id, user)
                final_username = user
                break
            except errors.UsernameOccupied:
                continue 
            except errors.UsernameInvalid:
                continue
            except errors.FloodWait as e:
                await asyncio.sleep(e.value)

        # 5. Final Report (No Group Info)
        report = (
            f"🎉 **Setup Complete!**\n\n"
            f"📺 **Name:** {channel_title}\n"
            f"🔗 **Username:** @{final_username if final_username else 'Not Set'}\n"
            f"🆔 **Channel ID:** `{created_chat.id}`"
        )
        await status_msg.edit(report)

    except errors.FloodWait as e:
        await status_msg.edit(f"⚠️ **FloodWait:** Sleeping for {e.value} seconds.")
    except Exception as e:
        await status_msg.edit(f"❌ **Error:** {str(e)}")
        # Cleanup file if exists
        if os.path.exists(photo_path):
            os.remove(photo_path)