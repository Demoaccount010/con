from pyrogram import Client, filters, errors
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, Message
from config import Config
from database import db

@Client.on_message(filters.command("start") & filters.private)
async def start_handler(client, message: Message):
    text = (
        f"👋 **Welcome {message.from_user.first_name}!**\n\n"
        "I am the Advanced Anime Automation System.\n"
        "Please verify your identity to proceed."
    )
    
    buttons = [
        [
            InlineKeyboardButton("🔐 Owner Verify", callback_data="verify_owner"),
            InlineKeyboardButton("👤 User Verify", callback_data="verify_user")
        ]
    ]
    await message.reply_text(text, reply_markup=InlineKeyboardMarkup(buttons))

@Client.on_callback_query(filters.regex("verify_owner"))
async def owner_verify(client, callback):
    if callback.from_user.id == Config.OWNER_ID:
        try:
            await callback.message.edit_text(
                "✅ **Owner Verified!**\n\nAccessing Master Control Panel...",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🎛 Master Panel", callback_data="master_panel")],
                    [InlineKeyboardButton("📜 Help", callback_data="help_cmds")]
                ])
            )
        except errors.MessageNotModified:
            pass # Ignore if clicked twice
    else:
        await callback.answer("❌ Access Denied. You are not the Owner.", show_alert=True)

@Client.on_callback_query(filters.regex("verify_user"))
async def user_verify(client, callback):
    user_id = callback.from_user.id
    
    # Check if already verified in DB to save API calls
    if await db.is_verified(user_id):
        return await show_user_panel(callback)

    try:
        # Check Force Sub
        # Note: The BOT must be an ADMIN in the channel to check members reliably
        try:
            member = await client.get_chat_member(Config.FORCE_SUB_CHANNEL, user_id)
        except errors.ChannelInvalid:
            await callback.answer("⚠️ System Error: Bot cannot access the Main Channel. Make sure Bot is Admin there.", show_alert=True)
            return
        except errors.PeerIdInvalid:
            await callback.answer("⚠️ Configuration Error: Invalid Channel ID.", show_alert=True)
            return

        if member.status in ["kicked", "left", "banned"]:
            raise Exception("Not Joined")
            
        await db.add_verified_user(user_id)
        await show_user_panel(callback)
        
    except Exception:
        # Handle "Not Joined" or other errors
        try:
            await callback.message.edit_text(
                "❌ **Access Denied!**\n\nYou must join our main channel first.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔔 Join Main Channel", url=Config.FORCE_SUB_LINK)],
                    [InlineKeyboardButton("🔄 Try Again", callback_data="verify_user")]
                ])
            )
        except errors.MessageNotModified:
            await callback.answer("❌ You still haven't joined the channel!", show_alert=True)

async def show_user_panel(callback):
    try:
        await callback.message.edit_text(
            "✅ **User Verified!**\n\nYou can now use the available commands.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("📜 User Commands", callback_data="user_cmds")]
            ])
        )
    except errors.MessageNotModified:
        pass

# Fix for User Commands Menu
@Client.on_callback_query(filters.regex("user_cmds"))
async def user_commands_panel(client, callback):
    text = (
        "📜 **User Command List:**\n\n"
        "• `/start` - Check verification status\n"
        "• `/id` - Get your ID\n"
        "• `/info` - Bot status\n"
        "(More commands coming soon)"
    )
    try:
        await callback.message.edit_text(
            text,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="verify_user")]])
        )
    except errors.MessageNotModified:
        pass