import asyncio
import time
from pyrogram import Client, filters, enums
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ChatPermissions
from database import db
from config import Config
import re

LINK_REGEX = r"(http|https|www\.|t\.me\/)"

# ---------------------------------------------------
# HELPER: PUNISHMENT LOGIC (3 STRIKES)
# ---------------------------------------------------
async def punish_user(client, message, reason):
    user = message.from_user
    chat = message.chat

    # 1. Delete the bad message
    try: await message.delete()
    except: pass # Bot might not have delete rights

    # 2. Add Warning
    count = await db.add_warning(chat.id, user.id)
    
    # 3. Warning Logic
    if count < 3:
        # --- WARNING MESSAGE (1/3 or 2/3) ---
        warn_text = (
            f"⚠️ **Warning Issued!**\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"👤 **User:** {user.mention}\n"
            f"🚫 **Reason:** {reason}\n"
            f"🔢 **Count:** `{count}/3`\n\n"
            f"__If you reach 3 warnings, you will be muted.__"
        )
        msg = await message.reply(warn_text)
        
        # Auto-delete warning after 10 seconds to keep chat clean
        await asyncio.sleep(10)
        try: await msg.delete()
        except: pass

    else:
        # --- PUNISHMENT (3/3) -> MUTE ---
        try:
            # Mute for 1 Hour (3600 seconds)
            await client.restrict_chat_member(
                chat.id, 
                user.id, 
                ChatPermissions(can_send_messages=False),
                until_date=time.time() + 3600 
            )
            
            punish_text = (
                f"⛔️ **Action Taken!**\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"👤 **User:** {user.mention}\n"
                f"🔇 **Punishment:** `Muted (1 Hour)`\n"
                f"📉 **Reason:** Reached 3/3 Warnings.\n\n"
                f"__Please read the group rules.__"
            )
            await message.reply(punish_text)
            
            # Reset Database Count
            await db.reset_warnings(chat.id, user.id)
            
        except Exception as e:
            # If bot fails to mute (e.g., User is Admin), just warn
            await message.reply(f"⚠️ **Admin/Error:** Could not mute {user.mention}. ({e})")

# ---------------------------------------------------
# PING COMMAND
# ---------------------------------------------------
@Client.on_message(filters.command("ping") & filters.group)
async def ping_group(client, message):
    await db.update_group(message.chat.id, message.chat.title)
    if not await db.is_verified(message.from_user.id):
        return await message.reply(
            f"❌ {message.from_user.mention}, verify first!",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔐 Verify Me", url=f"https://t.me/{client.me.username}?start=verify")]])
        )
    await message.reply("🏓 **Pong!** Monitoring for links & media.")

# ---------------------------------------------------
# GROUP FILTER (LINKS, MEDIA, FORWARDS)
# ---------------------------------------------------
@Client.on_message(filters.group, group=1)
async def global_group_filter(client, message):
    # Update DB
    try:
        if message.chat and message.chat.type in [enums.ChatType.GROUP, enums.ChatType.SUPERGROUP]:
            await db.update_group(message.chat.id, message.chat.title)
    except: pass

    # Ignore specific users
    if message.sender_chat or not message.from_user: return
    if message.from_user.id == Config.OWNER_ID: return

    # Check if "Warn System" is enabled globally
    warn_enabled = await db.is_feature_enabled("warn")
    
    violation_found = False
    violation_reason = ""

    # 1. CHECK LINKS (If Anti-Link Enabled)
    if await db.is_feature_enabled("antilink"):
        text = message.text or message.caption or ""
        if re.search(LINK_REGEX, text):
            violation_found = True
            violation_reason = "Sending Links"

    # 2. CHECK FORWARDS (Treat as Link/Spam)
    # Using existing settings, usually implicit with anti-link or media lock
    # But let's check if it has a forward header
    if not violation_found and (message.forward_date or message.forward_from or message.forward_from_chat):
         # Only punish if antilink is on (assuming strict mode)
         if await db.is_feature_enabled("antilink"): 
             violation_found = True
             violation_reason = "Forwarding Messages"

    # 3. CHECK MEDIA LOCK
    if not violation_found and await db.is_feature_enabled("media_lock"):
        if message.media:
            violation_found = True
            violation_reason = "Sending Media"

    # --- EXECUTE PUNISHMENT ---
    if violation_found:
        if warn_enabled:
            # 3-Strike System
            await punish_user(client, message, violation_reason)
        else:
            # Just Delete (No Warn)
            try: await message.delete()
            except: pass

# ---------------------------------------------------
# WELCOME MESSAGE
# ---------------------------------------------------
@Client.on_message(filters.new_chat_members, group=2)
async def welcome_handler(client, message):
    try: await db.update_group(message.chat.id, message.chat.title)
    except: pass
    
    if await db.is_feature_enabled("welcome"):
        for new_user in message.new_chat_members:
            if new_user.id == client.me.id: continue
            text = (
                f"👋 **Welcome {new_user.mention}!**\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"✨ Welcome to **{message.chat.title}**\n\n"
                f"🔒 **Verification Required:**\n"
                f"To request anime, verify yourself below.\n\n"
                f"👇 **Click below to verify:**"
            )
            buttons = InlineKeyboardMarkup([[InlineKeyboardButton("🔐 Verify Me", url=f"https://t.me/{client.me.username}?start=verify")]])
            try: await message.reply(text, reply_markup=buttons)
            except: pass