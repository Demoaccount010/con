import json
import os
import asyncio
from config import Config

class JsonDatabase:
    def __init__(self):
        self.lock = asyncio.Lock()
        self._ensure_files()

    def _ensure_files(self):
        if not os.path.exists("data"):
            os.makedirs("data")

        # Settings
        if not os.path.exists(Config.SETTINGS_FILE):
            default = {
                "welcome": True, "antilink": False, "warn": True,
                "force_sub": True, "media_lock": False, "antiflood": True
            }
            with open(Config.SETTINGS_FILE, 'w') as f: json.dump(default, f, indent=4)

        # Users
        if not os.path.exists(Config.USERS_FILE):
            with open(Config.USERS_FILE, 'w') as f: json.dump({"verified_ids": []}, f, indent=4)

        # Groups
        if not os.path.exists("data/groups.json"):
            with open("data/groups.json", 'w') as f: json.dump({}, f, indent=4)
            
        # WARNINGS (NEW)
        if not os.path.exists("data/warnings.json"):
            with open("data/warnings.json", 'w') as f: json.dump({}, f, indent=4)

    async def get_settings(self):
        async with self.lock:
            with open(Config.SETTINGS_FILE, 'r') as f: return json.load(f)

    async def is_feature_enabled(self, key):
        settings = await self.get_settings()
        return settings.get(key, False)

    async def update_setting(self, key, value):
        async with self.lock:
            with open(Config.SETTINGS_FILE, 'r') as f: data = json.load(f)
            data[key] = value
            with open(Config.SETTINGS_FILE, 'w') as f: json.dump(data, f, indent=4)

    # --- WARNING SYSTEM (NEW) ---
    async def add_warning(self, chat_id, user_id):
        """Increments warning count and returns current count."""
        async with self.lock:
            with open("data/warnings.json", 'r') as f: data = json.load(f)
            
            key = f"{chat_id}_{user_id}"
            current = data.get(key, 0)
            new_count = current + 1
            
            data[key] = new_count
            
            with open("data/warnings.json", 'w') as f: json.dump(data, f, indent=4)
            return new_count

    async def reset_warnings(self, chat_id, user_id):
        """Resets warnings to 0."""
        async with self.lock:
            with open("data/warnings.json", 'r') as f: data = json.load(f)
            
            key = f"{chat_id}_{user_id}"
            if key in data:
                del data[key]
                with open("data/warnings.json", 'w') as f: json.dump(data, f, indent=4)

    # --- USER & GROUP LOGIC (Existing) ---
    async def is_verified(self, user_id):
        if user_id == Config.OWNER_ID: return True
        async with self.lock:
            with open(Config.USERS_FILE, 'r') as f: data = json.load(f)
            return user_id in data.get("verified_ids", [])

    async def add_verified_user(self, user_id):
        async with self.lock:
            with open(Config.USERS_FILE, 'r') as f: data = json.load(f)
            if user_id not in data["verified_ids"]:
                data["verified_ids"].append(user_id)
                with open(Config.USERS_FILE, 'w') as f: json.dump(data, f, indent=4)

    async def get_all_users(self):
        async with self.lock:
            with open(Config.USERS_FILE, 'r') as f: data = json.load(f)
            return data.get("verified_ids", [])

    async def update_group(self, chat_id, title):
        async with self.lock:
            with open("data/groups.json", 'r') as f: data = json.load(f)
            str_id = str(chat_id)
            if str_id not in data or data[str_id] != title:
                data[str_id] = title
                with open("data/groups.json", 'w') as f: json.dump(data, f, indent=4)

    async def get_all_groups(self):
        async with self.lock:
            with open("data/groups.json", 'r') as f: return json.load(f)

    async def remove_group(self, chat_id):
        async with self.lock:
            with open("data/groups.json", 'r') as f: data = json.load(f)
            str_id = str(chat_id)
            if str_id in data:
                del data[str_id]
                with open("data/groups.json", 'w') as f: json.dump(data, f, indent=4)

db = JsonDatabase()