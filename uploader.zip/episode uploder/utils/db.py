import json

def load_json(f, default):
    try:
        return json.load(open(f))
    except:
        return default

def save_json(f, d):
    json.dump(d, open(f, "w"), indent=2)
