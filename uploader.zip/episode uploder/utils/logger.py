import json
import asyncio
from time import time
from datetime import datetime
from config import LOG_CHANNEL

LOG_FILE = "logs.json"

# ================= GLOBAL CACHE =================
_LOG_CACHE = {}          # src_id -> last_update_time
LOGS = {}                # runtime memory logs
_LOG_LOCK = asyncio.Lock()   # ✅ FILE SAFETY


# ================= FILE HELPERS =================
def load_logs():
    global LOGS
    try:
        with open(LOG_FILE, "r", encoding="utf-8") as f:
            LOGS = json.load(f)
    except:
        LOGS = {}
    return LOGS


async def save_logs():
    async with _LOG_LOCK:
        with open(LOG_FILE, "w", encoding="utf-8") as f:
            json.dump(LOGS, f, indent=2)


# load logs on import
load_logs()


# ================= REALTIME WATCHER LOG =================
async def log_update(bot, src_id, title, event):
    """
    Realtime watcher log
    - Same message EDIT
    - Throttled (1 update / 20 sec / channel)
    """
    now = time()
    src_id = str(src_id)

    # ⛔ THROTTLE (anti flood)
    last = _LOG_CACHE.get(src_id, 0)
    if now - last < 20:
        return
    _LOG_CACHE[src_id] = now

    data = LOGS.setdefault(src_id, {
        "videos": 0,
        "ignored": 0,
        "msg_id": None
    })

    if event == "video":
        data["videos"] += 1
    elif event == "ignored":
        data["ignored"] += 1

    text = (
        f"📡 **Channel Monitor**\n\n"
        f"🏷 **Name:** {title}\n"
        f"🆔 `{src_id}`\n\n"
        f"🎬 Videos Forwarded: `{data['videos']}`\n"
        f"🚫 Ignored: `{data['ignored']}`\n"
        f"⏱ Updated: just now\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"🔥 **ACTIVE**"
    )

    try:
        if not data["msg_id"]:
            msg = await bot.send_message(LOG_CHANNEL, text)
            data["msg_id"] = msg.id
        else:
            await bot.edit_message_text(
                chat_id=LOG_CHANNEL,
                message_id=data["msg_id"],
                text=text
            )
    except Exception:
        return

    await save_logs()


# ================= BACKGROUND SCAN LOG =================
async def log_scan(
    bot,
    src_id,
    mode,
    scanned,
    forwarded,
    ignored,
    forwarded_eps=None,
    ignored_eps=None,
    error=None
):
    """
    Background scanner summary
    - NEW message every scan
    """
    forwarded_eps = forwarded_eps or []
    ignored_eps = ignored_eps or []

    text = (
        f"🔍 **Channel Scan Report**\n\n"
        f"🆔 `{src_id}`\n"
        f"📊 Mode: **{mode}**\n\n"
        f"🔎 Scanned: `{scanned}`\n"
        f"✅ Forwarded: `{forwarded}`\n"
        f"🚫 Ignored: `{ignored}`\n"
    )

    if forwarded_eps:
        text += f"\n📤 Episodes Sent: `{', '.join(forwarded_eps)}`"

    if ignored_eps:
        text += f"\n⏭ Skipped: `{', '.join(ignored_eps)}`"

    if error:
        text += f"\n\n❌ **Error:**\n`{error}`"

    text += f"\n\n⏰ `{datetime.now().strftime('%d %b %Y %H:%M:%S')}`"

    try:
        await bot.send_message(LOG_CHANNEL, text)
    except Exception:
        pass
