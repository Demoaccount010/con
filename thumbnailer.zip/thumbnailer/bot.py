import os
import requests
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from io import BytesIO
from pyrogram import Client, filters
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from pyrogram.enums import ParseMode

from config import API_ID, API_HASH, BOT_TOKEN, WATERMARK, OMDB_API_KEY

# ================= APP =================
app = Client(
    "imdb_final_polished_bot",
    api_id=API_ID,
    api_hash=API_HASH,
    bot_token=BOT_TOKEN
)

# ================= GLOBAL =================
OWNER_ID = 2034253345          # 👈 apna Telegram user ID
MAIN_CHANNEL = -1001712308627 # 👈 apna main channel ID
user_state = {}

os.makedirs("output", exist_ok=True)

FONT = "fonts/bebas.ttf"
IMDB_YELLOW = (245, 197, 24)

# ================= UTILS =================
def resize_keep(img, mw, mh):
    w, h = img.size
    s = min(mw / w, mh / h)
    return img.resize((int(w * s), int(h * s)))

def is_owner(m):
    return m.from_user and m.from_user.id == OWNER_ID

def wrap_text(text, font, max_width, draw):
    words = text.split()
    lines, current = [], ""
    for word in words:
        test = current + " " + word if current else word
        if draw.textlength(test, font=font) <= max_width:
            current = test
        else:
            lines.append(current)
            current = word
        if len(lines) == 3:
            break
    if current and len(lines) < 3:
        lines.append(current)
    return lines

# ================= OMDB =================
def fetch_imdb(title):
    r = requests.get(
        f"https://www.omdbapi.com/?t={title}&plot=short&apikey={OMDB_API_KEY}",
        timeout=10
    ).json()

    if r.get("Response") != "True" or r.get("Poster") == "N/A":
        return None

    poster = Image.open(
        BytesIO(requests.get(r["Poster"], timeout=10).content)
    ).convert("RGB")

    return {
        "title": r["Title"],
        "year": r.get("Year", ""),
        "rating": r.get("imdbRating", "N/A"),
        "votes": r.get("imdbVotes", ""),
        "genres": [g.strip() for g in r.get("Genre", "").split(",") if g],
        "runtime": r.get("Runtime", ""),
        "type": r.get("Type", "").upper(),
        "plot": r.get("Plot", ""),
        "poster": poster
    }

# ================= CAPTION =================
def make_caption(data):
    return f"""
<b>😎 {data['title']} (S - 03)</b>
<b>╭──────────────────</b>
<b>├ ✔️Ratings - {data['rating']} IMDB</b>
<b>├ 🔊Audio - Hindi #Official</b>
<b>├ 🎼Quality - Multi</b>
<b>├ 🎭Genres - {", ".join(data["genres"])}</b>
<b>├──────────────────</b>
<b>├ 😎 @Hindi_Animes_Series 😎</b>
<b>╰──────────────────</b>
"""

def build_thumbnail(data, uid):
    # ---------- BASE POSTER ----------
    poster = resize_keep(data["poster"], 560, 820)

    # ---------- BACKGROUND (CINEMATIC DEPTH) ----------
    bg = poster.resize((1280, 720))
    bg = bg.filter(ImageFilter.GaussianBlur(40))

    # dark cinematic gradient
    gradient = Image.new("RGB", (1280, 720), (0, 0, 0))
    bg = Image.blend(bg, gradient, 0.65)

    draw = ImageDraw.Draw(bg)

    # ---------- LIGHT VIGNETTE ----------
    vignette = Image.new("L", (1280, 720), 0)
    vdraw = ImageDraw.Draw(vignette)
    vdraw.ellipse((-200, -200, 1480, 920), fill=255)
    vignette = vignette.filter(ImageFilter.GaussianBlur(180))
    bg.putalpha(vignette)
    bg = bg.convert("RGB")

    draw = ImageDraw.Draw(bg)

    # ---------- POSTER (RIGHT – HERO ELEMENT) ----------
    px = 1280 - poster.width - 70
    py = (720 - poster.height) // 2

    shadow = Image.new("RGBA", poster.size, (0, 0, 0, 240))
    bg.paste(shadow, (px + 22, py + 22), shadow)
    bg.paste(poster, (px, py))

    # ---------- FONTS ----------
    title_f = ImageFont.truetype(FONT, 90)
    big_f   = ImageFont.truetype(FONT, 42)
    mid_f   = ImageFont.truetype(FONT, 32)
    small_f = ImageFont.truetype(FONT, 26)

    x = 80
    y = 120

    # ---------- TITLE (DEPTH + SHADOW) ----------
    for ox, oy in [(2,2),(3,3)]:
        draw.text((x+ox, y+oy), data["title"].upper(),
                  font=title_f, fill=(0,0,0))
    draw.text((x, y), data["title"].upper(),
              font=title_f, fill=(255,255,255))
    y += 115

    # ---------- META ----------
    draw.text(
        (x, y),
        f"{data['type']} • {data['runtime']} • {data['year']}",
        font=small_f,
        fill=(200,200,200)
    )
    y += 70

    # ---------- IMDb RATING (PREMIUM BADGE) ----------
    badge_w, badge_h = 300, 70
    draw.rounded_rectangle(
        (x, y, x + badge_w, y + badge_h),
        radius=22,
        fill=(25,25,25),
        outline=IMDB_YELLOW,
        width=3
    )
    draw.text((x + 20, y + 12), "★",
              font=big_f, fill=IMDB_YELLOW)
    draw.text(
        (x + 70, y + 10),
        f"{data['rating']} IMDb",
        font=big_f,
        fill=(255,255,255)
    )
    y += 110

    # ---------- GENRES (HORIZONTAL PILLS) ----------
    gx = x
    for g in data["genres"][:3]:
        w, h = draw.textbbox((0,0), g, font=mid_f)[2:]
        draw.rounded_rectangle(
            (gx, y, gx + w + 36, y + h + 22),
            radius=24,
            fill=(35,35,35),
            outline=IMDB_YELLOW,
            width=2
        )
        draw.text(
            (gx + 18, y + 11),
            g.upper(),
            font=mid_f,
            fill=(255,255,255)
        )
        gx += w + 52

    y += 90

    # ---------- SHORT STORY (CINEMATIC BLOCK) ----------
    plot_lines = wrap_text(data["plot"], small_f, 520, draw)

    draw.rectangle(
        (x - 14, y - 8, x - 8, y + len(plot_lines) * 32),
        fill=IMDB_YELLOW
    )

    for line in plot_lines:
        draw.text(
            (x, y),
            line.upper(),
            font=small_f,
            fill=(225,225,225)
        )
        y += 32

    # ---------- WATERMARK (SUBTLE PREMIUM) ----------
    wm_font = ImageFont.truetype(FONT, 26)
    tw, th = draw.textbbox((0,0), WATERMARK, font=wm_font)[2:]

    draw.rounded_rectangle(
        (80, 650, 80 + tw + 26, 650 + th + 18),
        radius=16,
        fill=(20,20,20)
    )
    draw.text(
        (80 + 13, 650 + 9),
        WATERMARK,
        font=wm_font,
        fill=(210,210,210)
    )

    out = f"output/{uid}_style1_pro.jpg"
    bg.save(out, quality=98)
    return out

# ================= MAIN HANDLER =================
@app.on_message(filters.text)
async def handler(_, m):
    if not is_owner(m):
        return

    uid = m.from_user.id
    text = m.text.strip()

    if uid in user_state and "img" in user_state[uid] and "link" not in user_state[uid]:
        if not text.startswith("http"):
            await m.reply_text("❌ Valid link bhejo (http/https)")
            return

        user_state[uid]["link"] = text

        buttons = InlineKeyboardMarkup([
            [InlineKeyboardButton("Download Now ✅", url=text)],
            [
                InlineKeyboardButton("✅ YES", callback_data="post_yes"),
                InlineKeyboardButton("❌ NO", callback_data="post_no")
            ]
        ])

        await m.reply_photo(
            user_state[uid]["img"],
            caption=user_state[uid]["caption"],
            reply_markup=buttons,
            parse_mode=ParseMode.HTML
        )
        return

    await m.reply_text("🎬 IMDb se poster + full details la raha hoon...")
    data = fetch_imdb(text)
    if not data:
        await m.reply_text("❌ IMDb data nahi mila. Exact English naam try karo.")
        return

    img = build_thumbnail(data, uid)
    caption = make_caption(data)

    user_state[uid] = {"img": img, "caption": caption}

    await m.reply_photo(img, caption=caption, parse_mode=ParseMode.HTML)
    await m.reply_text("🔗 Join / Download channel link bhejo")

# ================= YES / NO =================
@app.on_callback_query()
async def callback_handler(_, cb):
    uid = cb.from_user.id
    if uid not in user_state:
        await cb.answer("Expired ❌", show_alert=True)
        return

    if cb.data == "post_no":
        user_state.pop(uid, None)
        await cb.message.edit_text("❌ Cancelled")
        return

    if cb.data == "post_yes":
        data = user_state[uid]
        btn = InlineKeyboardMarkup(
            [[InlineKeyboardButton("Download Now ✅", url=data["link"])]]
        )

        await app.send_photo(
            MAIN_CHANNEL,
            data["img"],
            caption=data["caption"],
            reply_markup=btn,
            parse_mode=ParseMode.HTML
        )

        user_state.pop(uid, None)
        await cb.answer("✅ Posted Successfully", show_alert=True)

print("🤖 FINAL POLISHED IMDb BOT STARTED")
app.run()
