API_ID = 35163791          # my.telegram.org se
API_HASH = "9ca25c5054cdb8ab4aec8f7041fd7757"    # my.telegram.org se
BOT_TOKEN = "8588196082:AAF-9P9wpjlNUlGTUpaq-NcjdcHw7p5gs9A"  # @BotFather se

WATERMARK = "@Hindi_Animes_Series"
OMDB_API_KEY = "21868ce3"
